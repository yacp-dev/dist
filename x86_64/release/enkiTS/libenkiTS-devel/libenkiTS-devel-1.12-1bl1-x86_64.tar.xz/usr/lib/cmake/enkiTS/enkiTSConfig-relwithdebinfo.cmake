#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "enkiTS::enkiTS" for configuration "RelWithDebInfo"
set_property(TARGET enkiTS::enkiTS APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(enkiTS::enkiTS PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libenkiTS.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygenkiTS-1.dll"
  )

list(APPEND _cmake_import_check_targets enkiTS::enkiTS )
list(APPEND _cmake_import_check_files_for_enkiTS::enkiTS "${_IMPORT_PREFIX}/lib/libenkiTS.dll.a" "${_IMPORT_PREFIX}/bin/cygenkiTS-1.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
