#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Nuspell::nuspell" for configuration "RelWithDebInfo"
set_property(TARGET Nuspell::nuspell APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(Nuspell::nuspell PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libnuspell.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygnuspell-5.dll"
  )

list(APPEND _cmake_import_check_targets Nuspell::nuspell )
list(APPEND _cmake_import_check_files_for_Nuspell::nuspell "${_IMPORT_PREFIX}/lib/libnuspell.dll.a" "${_IMPORT_PREFIX}/bin/cygnuspell-5.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
