
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was civetweb-config.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

# Use original install prefix when loaded through a "/usr move"
# cross-prefix symbolic link such as /lib -> /usr/lib.
get_filename_component(_realCurr "${CMAKE_CURRENT_LIST_DIR}" REALPATH)
get_filename_component(_realOrig "/usr/lib/cmake/civetweb" REALPATH)
if(_realCurr STREQUAL _realOrig)
  set(PACKAGE_PREFIX_DIR "/usr")
endif()
unset(_realOrig)
unset(_realCurr)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

####################################################################################
include(CMakeFindDependencyMacro)

set_and_check(civetweb_INCLUDE_DIR "${PACKAGE_PREFIX_DIR}/include")
set_and_check(civetweb_INCLUDE_DIRS "${PACKAGE_PREFIX_DIR}/include")
set_and_check(civetweb_LIBRARY_DIRS "${PACKAGE_PREFIX_DIR}/lib")
set(civetweb_LIBRARIES civetweb)

if(ON)
  set(civetweb-cpp_LIBRARIES civetweb-cpp)
endif()

find_dependency(Threads)

set(CIVETWEB_SAVED_MODULE_PATH ${CMAKE_MODULE_PATH})
list(APPEND CMAKE_MODULE_PATH ${CMAKE_CURRENT_LIST_DIR})

if(FALSE)
  find_dependency(LibDl)
endif()

if(TRUE)
  find_dependency(LibRt)
endif()

if(FALSE)
  find_dependency(WinSock)
endif()

set(CMAKE_MODULE_PATH ${CIVETWEB_SAVED_MODULE_PATH})
unset(CIVETWEB_SAVED_MODULE_PATH)

include("${CMAKE_CURRENT_LIST_DIR}/civetweb-targets.cmake")
