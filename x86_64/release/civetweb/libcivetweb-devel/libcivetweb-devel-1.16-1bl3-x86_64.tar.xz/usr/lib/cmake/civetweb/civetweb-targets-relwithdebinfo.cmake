#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "civetweb::civetweb" for configuration "RelWithDebInfo"
set_property(TARGET civetweb::civetweb APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(civetweb::civetweb PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libcivetweb.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygcivetweb-1.16.0.dll"
  )

list(APPEND _cmake_import_check_targets civetweb::civetweb )
list(APPEND _cmake_import_check_files_for_civetweb::civetweb "${_IMPORT_PREFIX}/lib/libcivetweb.dll.a" "${_IMPORT_PREFIX}/bin/cygcivetweb-1.16.0.dll" )

# Import target "civetweb::server" for configuration "RelWithDebInfo"
set_property(TARGET civetweb::server APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(civetweb::server PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/civetweb.exe"
  )

list(APPEND _cmake_import_check_targets civetweb::server )
list(APPEND _cmake_import_check_files_for_civetweb::server "${_IMPORT_PREFIX}/bin/civetweb.exe" )

# Import target "civetweb::civetweb-cpp" for configuration "RelWithDebInfo"
set_property(TARGET civetweb::civetweb-cpp APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(civetweb::civetweb-cpp PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libcivetweb-cpp.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygcivetweb-cpp-1.16.0.dll"
  )

list(APPEND _cmake_import_check_targets civetweb::civetweb-cpp )
list(APPEND _cmake_import_check_files_for_civetweb::civetweb-cpp "${_IMPORT_PREFIX}/lib/libcivetweb-cpp.dll.a" "${_IMPORT_PREFIX}/bin/cygcivetweb-cpp-1.16.0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
