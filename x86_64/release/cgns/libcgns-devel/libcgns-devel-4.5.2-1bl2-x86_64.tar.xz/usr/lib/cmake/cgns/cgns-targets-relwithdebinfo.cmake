#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "CGNS::cgns_shared" for configuration "RelWithDebInfo"
set_property(TARGET CGNS::cgns_shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(CGNS::cgns_shared PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libcgns.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygcgns-4.5.dll"
  )

list(APPEND _cmake_import_check_targets CGNS::cgns_shared )
list(APPEND _cmake_import_check_files_for_CGNS::cgns_shared "${_IMPORT_PREFIX}/lib/libcgns.dll.a" "${_IMPORT_PREFIX}/bin/cygcgns-4.5.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
