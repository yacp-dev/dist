
(define-library (chibi ast)
  (export
   analyze optimize env-cell ast->sexp macroexpand identifier-syntax
   type-of
   Object Input-Port Output-Port Opcode Procedure Bytecode Macro Env
   Number Bignum Flonum Integer Complex Char Boolean
   Symbol String Byte-Vector Vector Pair File-Descriptor
   Context Lam Cnd Set Set-Syn Ref Seq Lit Sc Exception Core
   syntactic-closure? lambda? cnd? set? ref? seq? lit? type? core?
   environment? bytecode? exception? macro? context? file-descriptor?
   syntactic-closure-expr syntactic-closure-env syntactic-closure-vars
   copy-lambda make-lambda make-cnd make-ref make-set make-seq make-lit
   make-macro
   lambda-name lambda-params lambda-body lambda-defs lambda-locals
   lambda-flags lambda-free-vars lambda-set-vars lambda-return-type
   lambda-param-types lambda-source
   lambda-name-set! lambda-params-set! lambda-body-set! lambda-defs-set!
   lambda-locals-set! lambda-flags-set! lambda-free-vars-set!
   lambda-set-vars-set! lambda-return-type-set! lambda-param-types-set!
   lambda-source-set!
   cnd-test cnd-pass cnd-fail
   cnd-test-set! cnd-pass-set! cnd-fail-set!
   set-var set-value set-var-set! set-value-set! set-source set-source-set!
   ref-name ref-cell ref-name-set! ref-cell-set!
   seq-ls seq-ls-set! lit-value lit-value-set!
   exception-kind exception-message exception-irritants exception-source
   opcode-name opcode-num-params opcode-return-type opcode-param-type
   opcode-class opcode-code opcode-data opcode-variadic? opcode?
   macro-procedure macro-env macro-source macro-aux macro-aux-set!
   procedure-code procedure-vars procedure-name procedure-name-set!
   procedure-arity procedure-variadic? procedure-variable-transformer?
   procedure-flags make-variable-transformer make-procedure procedure?
   bytecode-name bytecode-literals bytecode-source
   port-line port-line-set! port-source? port-source?-set!
   extend-env env-parent env-parent-set! env-lambda env-lambda-set!
   env-define! env-push! env-syntactic? env-syntactic?-set! core-code
   type-name type-cpl type-parent type-slots type-num-slots
   type-printer type-printer-set!
   object-size object->integer integer->immediate gc gc-usecs gc-count
   atomically thread-list abort
   string-contains string-cursor-copy! errno integer->error-string
   flatten-dot update-free-vars! setenv unsetenv safe-setenv
   immutable? immutable-string make-immutable!
   thread-interrupt!
   chibi-version)
  (import (chibi))
  (include-shared "ast")
  (include "ast.scm"))
