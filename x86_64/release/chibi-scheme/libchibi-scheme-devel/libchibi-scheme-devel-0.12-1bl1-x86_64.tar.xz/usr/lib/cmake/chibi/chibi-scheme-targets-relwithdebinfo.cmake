#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "chibi::libchibi-scheme" for configuration "RelWithDebInfo"
set_property(TARGET chibi::libchibi-scheme APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(chibi::libchibi-scheme PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libchibi-scheme.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/libchibi-scheme-0.dll"
  )

list(APPEND _cmake_import_check_targets chibi::libchibi-scheme )
list(APPEND _cmake_import_check_files_for_chibi::libchibi-scheme "${_IMPORT_PREFIX}/lib/libchibi-scheme.dll.a" "${_IMPORT_PREFIX}/bin/libchibi-scheme-0.dll" )

# Import target "chibi::chibi-scheme" for configuration "RelWithDebInfo"
set_property(TARGET chibi::chibi-scheme APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(chibi::chibi-scheme PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/chibi-scheme.exe"
  )

list(APPEND _cmake_import_check_targets chibi::chibi-scheme )
list(APPEND _cmake_import_check_files_for_chibi::chibi-scheme "${_IMPORT_PREFIX}/bin/chibi-scheme.exe" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
