#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "cifpp::cifpp" for configuration "RelWithDebInfo"
set_property(TARGET cifpp::cifpp APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(cifpp::cifpp PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libcifpp.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygcifpp-10.dll"
  )

list(APPEND _cmake_import_check_targets cifpp::cifpp )
list(APPEND _cmake_import_check_files_for_cifpp::cifpp "${_IMPORT_PREFIX}/lib/libcifpp.dll.a" "${_IMPORT_PREFIX}/bin/cygcifpp-10.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
