/*
 * Library to access the Transactional Registry (TxR) format
 *
 * Copyright (C) 2011-2026, Joachim Metz <joachim.metz@gmail.com>
 *
 * Refer to AUTHORS for acknowledgements.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#if !defined( _LIBFTXR_H )
#define _LIBFTXR_H

#include <libftxr/codepage.h>
#include <libftxr/definitions.h>
#include <libftxr/error.h>
#include <libftxr/extern.h>
#include <libftxr/features.h>
#include <libftxr/types.h>

#include <stdio.h>

#if defined( __cplusplus )
extern "C" {
#endif

/* -------------------------------------------------------------------------
 * Support functions
 * ------------------------------------------------------------------------- */

/* Returns the library version
 */
LIBFTXR_EXTERN \
const char *libftxr_get_version(
             void );

/* -------------------------------------------------------------------------
 * Error functions
 * ------------------------------------------------------------------------- */

/* Frees an error
 */
LIBFTXR_EXTERN \
void libftxr_error_free(
      libftxr_error_t **error );

/* Prints a descriptive string of the error to the stream
 * Returns the amount of printed characters if successful or -1 on error
 */
LIBFTXR_EXTERN \
int libftxr_error_fprint(
     libftxr_error_t *error,
     FILE *stream );

/* Prints a descriptive string of the error to the string
 * The end-of-string character is not included in the return value
 * Returns the amount of printed characters if successful or -1 on error
 */
LIBFTXR_EXTERN \
int libftxr_error_sprint(
     libftxr_error_t *error,
     char *string,
     size_t size );

/* Prints a backtrace of the error to the stream
 * Returns the amount of printed characters if successful or -1 on error
 */
LIBFTXR_EXTERN \
int libftxr_error_backtrace_fprint(
     libftxr_error_t *error,
     FILE *stream );

/* Prints a backtrace of the error to the string
 * The end-of-string character is not included in the return value
 * Returns the amount of printed characters if successful or -1 on error
 */
LIBFTXR_EXTERN \
int libftxr_error_backtrace_sprint(
     libftxr_error_t *error,
     char *string,
     size_t size );

/* -------------------------------------------------------------------------
 * Record functions
 * ------------------------------------------------------------------------- */

/* Creates a record
 * Make sure the value record is referencing, is set to NULL
 * Returns 1 if successful or -1 on error
 */
LIBFTXR_EXTERN \
int libftxr_record_initialize(
     libftxr_record_t **txr_record,
     libftxr_error_t **error );

/* Frees a record
 * Returns 1 if successful or -1 on error
 */
LIBFTXR_EXTERN \
int libftxr_record_free(
     libftxr_record_t **txr_record,
     libftxr_error_t **error );

/* Copies the record from the byte stream
 * Returns 1 if successful or -1 on error
 */
LIBFTXR_EXTERN \
int libftxr_record_copy_from_byte_stream(
     libftxr_record_t *txr_record,
     const uint8_t *byte_stream,
     size_t byte_stream_size,
     libftxr_error_t **error );

#if defined( __cplusplus )
}
#endif

#endif /* !defined( _LIBFTXR_H ) */

