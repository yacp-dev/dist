/*
 * Features of libftxr
 *
 * Copyright (C) 2011-2026, Joachim Metz <joachim.metz@gmail.com>
 *
 * Refer to AUTHORS for acknowledgements.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#if !defined( _LIBFTXR_FEATURES_H )
#define _LIBFTXR_FEATURES_H

/* The libftxr type support features
 */
#if !defined( LIBFTXR_DEPRECATED )
#if defined( __GNUC__ ) && __GNUC__ >= 3
#define LIBFTXR_DEPRECATED	__attribute__ ((__deprecated__))
#elif defined( _MSC_VER )
#define LIBFTXR_DEPRECATED	__declspec(deprecated)
#else
#define LIBFTXR_DEPRECATED
#endif
#endif

#endif /* !defined( _LIBFTXR_FEATURES_H ) */

