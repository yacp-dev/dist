
The Waffle bugfix release 1.8.2 is now available.

What is new in this release:
  - Resolve building c11/threads with C23 enabled compilers

The source is available at:

  https://waffle.freedesktop.org/files/release/waffle-1.8.2/waffle-1.8.2.tar.xz

You can also get the current source directly from the git
repository. See https://waffle.freedesktop.org for details.

----------------------------------------------------------------

Changes since 1.8.1:

Emil Velikov (2):
      c11/threads: properly handle c23 threads
      waffle: Bump version to 1.8.2

Khem Raj (1):
      c11/threads: fix build on c23

