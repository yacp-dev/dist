
The Waffle bugfix release 1.8.3 is now available.

What is new in this release:
  - meson: install cmake files on all host types

The source is available at:

  https://waffle.freedesktop.org/files/release/waffle-1.8.3/waffle-1.8.3.tar.xz

You can also get the current source directly from the git
repository. See https://waffle.freedesktop.org for details.

----------------------------------------------------------------

Changes since 1.8.2:

Emil Velikov (2):
      meson: install cmake files regardless of host type
      waffle: Bump version to 1.8.3

