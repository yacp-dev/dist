OVERVIEW
========

polkit is a toolkit for defining and handling authorizations.  It is
used for allowing unprivileged processes to speak to privileged
processes.


DOCUMENTATION
=============

Latest documentation, reference manual and API description of polkit can be still found  
on project's previous instance of Gitlab Pages  
https://polkit.pages.freedesktop.org/polkit


Older reference can be found at  
 https://www.freedesktop.org/software/polkit/docs/latest/


RELEASES
========

Latest releases are available at [the Release page](https://github.com/polkit-org/polkit/releases).

Older releases are still available as tarballs at  
 https://www.freedesktop.org/software/polkit/releases/

To verify the authenticity of the compressed tarball, use this command

``` bash
$ gpg --verify polkit-$(VERSION).tar.gz.sign polkit-$(VERSION).tar.gz
$ gpg: Signature made Tue 23 Apr 2019 04:19:29 PM CEST using RSA key ID FFDCE258
$ gpg: Good signature from "Jan Rybar (Red Hat) <jrybar@redhat.com>"
```

Public key available at

 https://keys.openpgp.org/vks/v1/by-fingerprint/7FFB7D6BD83147D74284E3178CEB3030FFDCE258


BUGS and DEVELOPMENT
====================

Please report non-security bugs via the polkit's GitHub issues at
https://github.com/polkit-org/polkit/issues

The other way, in case of **non**-security issues, is to contact developers via official polkit's FreeDesktop.org mailing list at

polkit-devel@lists.freedesktop.org  

SECURITY ISSUES
===============

Please report any security issues not yet known to public by sending mail to polkit-security@redhat.com or use GitHub's button for reporting a vulnerability when creating an issue.  
Thank you.


BUILD INSTRUCTIONS
==================

See [Building polkit](docs/BUILDING.md) for dependencies, Meson configuration,
compilation, and installation instructions.

I WANT TO CONTRIBUTE
====================
Your pull requests and patch suggestions are welcome! If you want to contribute, a pull request on this GitHub project is a preferred way, yet not the only one. Please consult other options with this upsteam's maintainers.

AI-ASSISTED CONTRIBUTIONS
-------------------------
If you use an AI tool (such as a language model or code assistant) to help write code, draft a bug report, or otherwise prepare your contribution, please state this in the description of your pull request or issue. A brief note mentioning which tool was used and the extent of its involvement is sufficient.

Please use AI assistance thoughtfully and with consideration for the reviewers. A large volume of auto-generated content — code, comments, or descriptions — tends to increase the review burden rather than reduce it, and may slow down rather than speed up the acceptance of your contribution.

Please keep in mind that **you remain fully responsible for any AI-generated content you submit**. By contributing it, you confirm that you have reviewed it and stand behind its correctness.

Thank you in advance.
