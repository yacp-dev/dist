
#include "polkitagenthelperprivate.h"

#include <stdio.h>

int
main (int argc, char *argv[])
{
  fprintf (stdout, "SUCCESS\n");
  flush_and_wait();
  return 0;
}
