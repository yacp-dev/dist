// ==================================================================
// @(#)buspirate.h
//
// @author Bruno Quoitin (bruno.quoitin@umons.ac.be)
// @date 18/09/2010
// $Id$
//
// libbuspirate
// Copyright (C) 2010 Bruno Quoitin
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
// 02111-1307  USA
// ==================================================================

/**
 * \file buspirate.h
 */

#ifndef __BUSPIRATE_H__
#define __BUSPIRATE_H__

#include <stdlib.h>

/**
 * This type is used as a Bus Pirate connection handle. It is an
 * "opaque" data structure. The data structure fields are only defined
 * within the library and should not be accessed by client code.
 *
 * BP instances are created by the bp_open() function and are required
 * by all the other library functions.
 */
typedef struct BP_t BP;


/**
 * @defgroup BP_PIN
 *
 * The following macros can be used in conjuction with the values
 * returned by bp_bin_pins_setup() and bp_bin_pins_set() to determine
 * the current state of the corresponding pins.
 *
 * @{
 */
/** Weight of the CS pin. */
#define BP_PIN_CS     0x01
/** Weight of the MISO pin. */
#define BP_PIN_MISO   0x02
/** Weight of the CLK pin. */
#define BP_PIN_CLK    0x04
/** Weight of the MOSI pin. */
#define BP_PIN_MOSI   0x08
/** Weight of the AUX pin. */
#define BP_PIN_AUX    0x10
/** @} */

/**
 * @defgroup BP
 *
 * The following macros define status codes that can be returned by
 * certain (most) of the library functions.
 *
 * @{
 */
/** Status code : indicates a success. */
#define BP_SUCCESS 1
/** Status code : indicates a failure. */
#define BP_FAILURE 0
/** @} */


#ifdef __cplusplus
extern "C" {
#endif

  BP * bp_open (const char * filename);
  int  bp_close(BP * bp);

  int bp_firmware_version_high(BP * bp);
  int bp_firmware_version_low(BP * bp);
  
  int  bp_reset(BP * bp);

  int  bp_bin_init(BP * bp, unsigned char * version);
  int  bp_bin_reset(BP * bp, unsigned char * version);
  int  bp_bin_pins_setup(BP * bp, int aux, int mosi, int clk, int miso,
			 int cs, unsigned char * value);
  int  bp_bin_pins_set(BP * bp, int power, int pullup, int aux, int mosi,
		       int clk, int miso, int cs, unsigned char * value);

  int  bp_bin_read_voltage(BP * bp, int * mV);
  int  bp_bin_mode_i2c(BP * bp, unsigned char * version);
  int  bp_bin_mode_spi(BP * bp, unsigned char * version);
  int  bp_bin_mode_raw(BP * bp, unsigned char * version);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
