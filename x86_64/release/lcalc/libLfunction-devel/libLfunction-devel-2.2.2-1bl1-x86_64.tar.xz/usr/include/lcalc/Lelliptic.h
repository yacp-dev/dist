/*

   Copyright (C) 2001,2002,2003,2004 Michael Rubinstein

   This file is part of the L-function package L.

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License along
   with this program; if not, see <https://www.gnu.org/licenses/>.

*/


#ifndef Lelliptic_H
#define Lelliptic_H


#include "L.h"             //for the L_function class
#include <iostream>


#if HAVE_LIBPARI
#include <pari/pari.h>     //for pari's elliptic curve functions
#undef init                //pari has a '#define init pari_init' which
                           //causes trouble with the stream.h init.
                           //pari also causes trouble with things like abs.
                           //we place the pari include first since otherwise it
                           //messes up.

void data_E(char *a1, char *a2, char *a3, char *a4, char *a6,int N_terms,Double * coeff);
#endif //if HAVE_LIBPARI



#endif
