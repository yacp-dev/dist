/*

   Copyright (C) 2001,2002,2003,2004 Michael Rubinstein

   This file is part of the L-function package L.

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License along
   with this program; if not, see <https://www.gnu.org/licenses/>.

*/


//Reiemann Siegel formula.
//http://www.dtc.umn.edu/~odlyzko/doc/arch/fast.zeta.eval.pdf
#ifndef Lriemannsiegel_H
#define Lriemannsiegel_H


Complex Zeta(Complex s, const char *return_type="pure");
Double rs_remainder_terms(Double z, Double tau);
Complex siegel(Complex s);

#endif
