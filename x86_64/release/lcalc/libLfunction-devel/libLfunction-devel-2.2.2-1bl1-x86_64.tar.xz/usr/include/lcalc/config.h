/* src/config.h.  Generated from config.h.in by configure.  */
/* src/config.h.in.  Generated from configure.ac by autoheader.  */

/* Define to 1 if you have the <dlfcn.h> header file. */
#define HAVE_DLFCN_H 1

/* Define to 1 if you have the <getopt.h> header file. */
#define HAVE_GETOPT_H 1

/* Define to 1 if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* Define to 1 if you have the 'mpfr' library (-lmpfr). */
/* #undef HAVE_LIBMPFR */

/* Define to 1 if you have the 'pari' library (-lpari). */
/* #undef HAVE_LIBPARI */

/* Define to 1 if you have the 'qd' library (-lqd). */
/* #undef HAVE_LIBQD */

/* Define to 1 if you have the <limits.h> header file. */
#define HAVE_LIMITS_H 1

/* Define to 1 if you have the <math.h> header file. */
#define HAVE_MATH_H 1

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if you have the <stdio.h> header file. */
#define HAVE_STDIO_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* Define to the sub-directory where libtool stores uninstalled libraries. */
#define LT_OBJDIR ".libs/"

/* Name of package */
#define PACKAGE "lcalc"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "https://gitlab.com/sagemath/lcalc/issues"

/* Define to the full name of this package. */
#define PACKAGE_NAME "lcalc"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "lcalc 2.2.2"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "lcalc"

/* Define to the home page for this package. */
#define PACKAGE_URL "https://gitlab.com/sagemath/lcalc"

/* Define to the version of this package. */
#define PACKAGE_VERSION "2.2.2"

/* Use double-precision arithmetic */
#define PRECISION_DOUBLE 1

/* Use double-double-precision arithmetic from libqd */
/* #undef PRECISION_DOUBLE_DOUBLE */

/* Use multiple-precision arithmetic from MPFR */
/* #undef PRECISION_MULTIPLE */

/* Use quad-double-precision arithmetic from libqd */
/* #undef PRECISION_QUAD_DOUBLE */

/* Define to 1 if all of the C89 standard headers exist (not just the ones
   required in a freestanding environment). This macro is provided for
   backward compatibility; new code need not use it. */
#define STDC_HEADERS 1

/* Version number of package */
#define VERSION "2.2.2"

/* Define as 'unsigned int' if <stddef.h> doesn't define. */
/* #undef size_t */
