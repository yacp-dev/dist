/*!
 ******************************************************************************
 *
 * \file
 *
 * \brief   RAJA header file containing user interface for RAJA::launch::hip
 *
 ******************************************************************************
 */

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
// Copyright (c) Lawrence Livermore National Security, LLC and other
// RAJA Project Developers. See top-level LICENSE and COPYRIGHT
// files for dates and other details. No copyright assignment is required
// to contribute to RAJA.
//
// SPDX-License-Identifier: (BSD-3-Clause)
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

#ifndef RAJA_pattern_launch_hip_HPP
#define RAJA_pattern_launch_hip_HPP

#include "RAJA/pattern/launch/launch_core.hpp"
#include "RAJA/pattern/detail/privatizer.hpp"
#include "RAJA/policy/hip/policy.hpp"
#include "RAJA/policy/hip/MemUtils_HIP.hpp"
#include "RAJA/policy/hip/raja_hiperrchk.hpp"
#include "RAJA/util/resource.hpp"
#include "RAJA/util/Jit.hpp"

namespace RAJA
{

/*!
 * LaunchContextT specialization that carries a backend-specific IndicesAndDims
 * instance, allowing IndexMapper objects to consume cached thread/block/grid
 * indices and dimensions when available.
 */
template<typename IndicesAndDimsT>
class LaunchContextT<hip::LaunchContextIndicesAndDimsPolicy<IndicesAndDimsT>>
    : public LaunchContextBase
{
public:
  using indices_and_dims_t = IndicesAndDimsT;

  indices_and_dims_t indices_and_dims;

  RAJA_HOST_DEVICE RAJA_INLINE LaunchContextT()
      : LaunchContextBase(),
        indices_and_dims()
  {}

  RAJA_HOST_DEVICE RAJA_INLINE indices_and_dims_t const& get_indices_and_dims()
      const
  {
    return indices_and_dims;
  }
};

template<typename BODY, typename ReduceParams>
__global__ RAJA_JIT_COMPILE void launch_new_reduce_global_fcn(
    const BODY body_in,
    ReduceParams reduce_params)
{

  using RAJA::internal::thread_privatize;
  auto privatizer = thread_privatize(body_in);
  auto& body      = privatizer.get_priv();

  // Set pointer to shared memory
  extern __shared__ char raja_shmem_ptr[];

  using LaunchContextType =
      typename RAJA::detail::launch_context_type<BODY>::type;

  LaunchContextType ctx;
  ctx.shared_mem_ptr = raja_shmem_ptr;
  RAJA::expt::invoke_body(reduce_params, body, ctx);

  // Using a flatten global policy as we may use all dimensions
  RAJA::expt::ParamMultiplexer::parampack_combine(
      RAJA::hip_flatten_global_xyz_direct {}, reduce_params);
}

template<bool async>
struct LaunchExecute<
    RAJA::policy::hip::hip_launch_t<async, named_usage::unspecified>>
{

  template<typename BODY_IN, typename ReduceParams>
  static concepts::enable_if_t<
      resources::EventProxy<resources::Resource>,
      RAJA::expt::type_traits::is_ForallParamPack<ReduceParams>>
  exec(RAJA::resources::Resource res,
       const LaunchParams& launch_params,
       BODY_IN&& body_in,
       ReduceParams& launch_reducers)
  {
    using BODY = camp::decay<BODY_IN>;
    using EXEC_POL =
        RAJA::policy::hip::hip_launch_t<async, named_usage::unspecified>;
    EXEC_POL pol {};

    auto func = reinterpret_cast<const void*>(
        &launch_new_reduce_global_fcn<BODY, camp::decay<ReduceParams>>);

    resources::Hip hip_res = res.get<RAJA::resources::Hip>();

    //
    // Compute the number of blocks and threads
    //

    hip_dim_t gridSize {
        static_cast<hip_dim_member_t>(launch_params.teams.value[0]),
        static_cast<hip_dim_member_t>(launch_params.teams.value[1]),
        static_cast<hip_dim_member_t>(launch_params.teams.value[2])};

    hip_dim_t blockSize {
        static_cast<hip_dim_member_t>(launch_params.threads.value[0]),
        static_cast<hip_dim_member_t>(launch_params.threads.value[1]),
        static_cast<hip_dim_member_t>(launch_params.threads.value[2])};

    // Only launch kernel if we have something to iterate over
    constexpr hip_dim_member_t zero = 0;
    if (gridSize.x > zero && gridSize.y > zero && gridSize.z > zero &&
        blockSize.x > zero && blockSize.y > zero && blockSize.z > zero)
    {

      size_t shared_mem_size = launch_params.shared_mem_size;
      RAJA::hip::detail::hipInfo launch_info;
      launch_info.gridDim      = gridSize;
      launch_info.blockDim     = blockSize;
      launch_info.dynamic_smem = &shared_mem_size;
      launch_info.res          = hip_res;

      {

        RAJA::expt::ParamMultiplexer::parampack_init(pol, launch_reducers,
                                                     launch_info);

        //
        // Privatize the loop_body, using make_launch_body to setup reductions
        //
        BODY body = RAJA::hip::make_launch_body(func, gridSize, blockSize,
                                                shared_mem_size, hip_res,
                                                std::forward<BODY_IN>(body_in));

        //
        // Launch the kernel
        //
        void* args[] = {(void*)&body, (void*)&launch_reducers};
        RAJA::hip::launch(func, gridSize, blockSize, args, shared_mem_size,
                          hip_res, async);

        RAJA::expt::ParamMultiplexer::parampack_resolve(pol, launch_reducers,
                                                        launch_info);
      }
    }

    return resources::EventProxy<resources::Resource>(res);
  }
};

template<typename BODY, int num_threads, typename ReduceParams>
__launch_bounds__(num_threads, 1) __global__ RAJA_JIT_COMPILE
    void launch_new_reduce_global_fcn_fixed(const BODY body_in,
                                            ReduceParams reduce_params)
{

  using RAJA::internal::thread_privatize;
  auto privatizer = thread_privatize(body_in);
  auto& body      = privatizer.get_priv();

  // Set pointer to shared memory
  extern __shared__ char raja_shmem_ptr[];

  using LaunchContextType =
      typename RAJA::detail::launch_context_type<BODY>::type;

  LaunchContextType ctx;
  ctx.shared_mem_ptr = raja_shmem_ptr;
  RAJA::expt::invoke_body(reduce_params, body, ctx);

  // Using a flatten global policy as we may use all dimensions
  RAJA::expt::ParamMultiplexer::parampack_combine(
      RAJA::hip_flatten_global_xyz_direct {}, reduce_params);
}

template<bool async, int nthreads>
struct LaunchExecute<RAJA::policy::hip::hip_launch_t<async, nthreads>>
{

  template<typename BODY_IN, typename ReduceParams>
  static concepts::enable_if_t<
      resources::EventProxy<resources::Resource>,
      RAJA::expt::type_traits::is_ForallParamPack<ReduceParams>>
  exec(RAJA::resources::Resource res,
       const LaunchParams& launch_params,
       BODY_IN&& body_in,
       ReduceParams& launch_reducers)
  {
    using BODY = camp::decay<BODY_IN>;
    // Use a generic block size policy here to match that used in
    // parampack_combine
    using EXEC_POL =
        RAJA::policy::hip::hip_launch_t<async, named_usage::unspecified>;
    EXEC_POL pol {};

    auto func = reinterpret_cast<const void*>(
        &launch_new_reduce_global_fcn_fixed<BODY, nthreads,
                                            camp::decay<ReduceParams>>);

    resources::Hip hip_res = res.get<RAJA::resources::Hip>();

    //
    // Compute the number of blocks and threads
    //

    hip_dim_t gridSize {
        static_cast<hip_dim_member_t>(launch_params.teams.value[0]),
        static_cast<hip_dim_member_t>(launch_params.teams.value[1]),
        static_cast<hip_dim_member_t>(launch_params.teams.value[2])};

    hip_dim_t blockSize {
        static_cast<hip_dim_member_t>(launch_params.threads.value[0]),
        static_cast<hip_dim_member_t>(launch_params.threads.value[1]),
        static_cast<hip_dim_member_t>(launch_params.threads.value[2])};

    // Only launch kernel if we have something to iterate over
    constexpr hip_dim_member_t zero = 0;
    if (gridSize.x > zero && gridSize.y > zero && gridSize.z > zero &&
        blockSize.x > zero && blockSize.y > zero && blockSize.z > zero)
    {


      size_t shared_mem_size = launch_params.shared_mem_size;
      RAJA::hip::detail::hipInfo launch_info;
      launch_info.gridDim      = gridSize;
      launch_info.blockDim     = blockSize;
      launch_info.dynamic_smem = &shared_mem_size;
      launch_info.res          = hip_res;

      {

        RAJA::expt::ParamMultiplexer::parampack_init(pol, launch_reducers,
                                                     launch_info);

        //
        // Privatize the loop_body, using make_launch_body to setup reductions
        //
        BODY body = RAJA::hip::make_launch_body(func, gridSize, blockSize,
                                                shared_mem_size, hip_res,
                                                std::forward<BODY_IN>(body_in));

        //
        // Launch the kernel
        //
        void* args[] = {(void*)&body, (void*)&launch_reducers};
        RAJA::hip::launch(func, gridSize, blockSize, args, shared_mem_size,
                          hip_res, async);

        RAJA::expt::ParamMultiplexer::parampack_resolve(pol, launch_reducers,
                                                        launch_info);
      }
    }

    return resources::EventProxy<resources::Resource>(res);
  }
};

template<typename IterationMapping,
         kernel_sync_requirement sync,
         typename... IndexMappers>
struct MaskExecute<
    RAJA::policy::hip::hip_indexer<IterationMapping, sync, IndexMappers...>>
{
  template<typename LaunchContextPolicy, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      BODY const& body)
  {
    auto const& indices_and_dims = ctx.get_indices_and_dims();
    if (((IndexMappers::template index<camp::idx_t>(indices_and_dims) == 0) &&
         ...))
    {
      body();
    }
  }
};

template<typename IterationMapping,
         kernel_sync_requirement sync,
         typename... IndexMappers>
struct MaskExecute<RAJA::policy::hip::hip_flatten_indexer<IterationMapping,
                                                          sync,
                                                          IndexMappers...>>
{
  template<typename LaunchContextPolicy, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      BODY const& body)
  {
    auto const& indices_and_dims = ctx.get_indices_and_dims();
    if (((IndexMappers::template index<camp::idx_t>(indices_and_dims) == 0) &&
         ...))
    {
      body();
    }
  }
};

/*
   HIP generic loop implementations
*/
template<typename SEGMENT, typename IndexMapper>
struct LoopExecute<
    RAJA::policy::hip::hip_indexer<RAJA::iteration_mapping::DirectUnchecked,
                                   kernel_sync_requirement::none,
                                   IndexMapper>,
    SEGMENT>
{

  using diff_t = typename std::iterator_traits<
      typename SEGMENT::iterator>::difference_type;

  template<typename LaunchContextPolicy, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      SEGMENT const& segment,
      BODY const& body)
  {
    const diff_t i =
        IndexMapper::template index<diff_t>(ctx.get_indices_and_dims());

    body(*(segment.begin() + i));
  }
};

template<typename SEGMENT, typename IndexMapper0, typename IndexMapper1>
struct LoopExecute<
    RAJA::policy::hip::hip_indexer<RAJA::iteration_mapping::DirectUnchecked,
                                   kernel_sync_requirement::none,
                                   IndexMapper0,
                                   IndexMapper1>,
    SEGMENT>
{

  using diff_t = typename std::iterator_traits<
      typename SEGMENT::iterator>::difference_type;

  template<typename LaunchContextPolicy, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      SEGMENT const& segment0,
      SEGMENT const& segment1,
      BODY const& body)
  {
    const diff_t i0 =
        IndexMapper0::template index<diff_t>(ctx.get_indices_and_dims());
    const diff_t i1 =
        IndexMapper1::template index<diff_t>(ctx.get_indices_and_dims());

    body(*(segment0.begin() + i0), *(segment1.begin() + i1));
  }
};

template<typename SEGMENT,
         typename IndexMapper0,
         typename IndexMapper1,
         typename IndexMapper2>
struct LoopExecute<
    RAJA::policy::hip::hip_indexer<RAJA::iteration_mapping::DirectUnchecked,
                                   kernel_sync_requirement::none,
                                   IndexMapper0,
                                   IndexMapper1,
                                   IndexMapper2>,
    SEGMENT>
{

  using diff_t = typename std::iterator_traits<
      typename SEGMENT::iterator>::difference_type;

  template<typename LaunchContextPolicy, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      SEGMENT const& segment0,
      SEGMENT const& segment1,
      SEGMENT const& segment2,
      BODY const& body)
  {
    const diff_t i0 =
        IndexMapper0::template index<diff_t>(ctx.get_indices_and_dims());
    const diff_t i1 =
        IndexMapper1::template index<diff_t>(ctx.get_indices_and_dims());
    const diff_t i2 =
        IndexMapper2::template index<diff_t>(ctx.get_indices_and_dims());

    body(*(segment0.begin() + i0), *(segment1.begin() + i1),
         *(segment2.begin() + i2));
  }
};

template<typename SEGMENT, typename IndexMapper>
struct LoopExecute<
    RAJA::policy::hip::hip_indexer<RAJA::iteration_mapping::Direct,
                                   kernel_sync_requirement::none,
                                   IndexMapper>,
    SEGMENT>
{

  using diff_t = typename std::iterator_traits<
      typename SEGMENT::iterator>::difference_type;

  template<typename LaunchContextPolicy, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      SEGMENT const& segment,
      BODY const& body)
  {
    const diff_t len = segment.end() - segment.begin();
    const diff_t i =
        IndexMapper::template index<diff_t>(ctx.get_indices_and_dims());

    if (i < len)
    {
      body(*(segment.begin() + i));
    }
  }
};

template<typename SEGMENT, typename IndexMapper0, typename IndexMapper1>
struct LoopExecute<
    RAJA::policy::hip::hip_indexer<RAJA::iteration_mapping::Direct,
                                   kernel_sync_requirement::none,
                                   IndexMapper0,
                                   IndexMapper1>,
    SEGMENT>
{

  using diff_t = typename std::iterator_traits<
      typename SEGMENT::iterator>::difference_type;

  template<typename LaunchContextPolicy, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      SEGMENT const& segment0,
      SEGMENT const& segment1,
      BODY const& body)
  {
    const int len0 = segment0.end() - segment0.begin();
    const int len1 = segment1.end() - segment1.begin();

    const diff_t i0 =
        IndexMapper0::template index<diff_t>(ctx.get_indices_and_dims());
    const diff_t i1 =
        IndexMapper1::template index<diff_t>(ctx.get_indices_and_dims());

    if (i0 < len0 && i1 < len1)
    {
      body(*(segment0.begin() + i0), *(segment1.begin() + i1));
    }
  }
};

template<typename SEGMENT,
         typename IndexMapper0,
         typename IndexMapper1,
         typename IndexMapper2>
struct LoopExecute<
    RAJA::policy::hip::hip_indexer<RAJA::iteration_mapping::Direct,
                                   kernel_sync_requirement::none,
                                   IndexMapper0,
                                   IndexMapper1,
                                   IndexMapper2>,
    SEGMENT>
{

  using diff_t = typename std::iterator_traits<
      typename SEGMENT::iterator>::difference_type;

  template<typename LaunchContextPolicy, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      SEGMENT const& segment0,
      SEGMENT const& segment1,
      SEGMENT const& segment2,
      BODY const& body)
  {
    const int len0 = segment0.end() - segment0.begin();
    const int len1 = segment1.end() - segment1.begin();
    const int len2 = segment2.end() - segment2.begin();

    const diff_t i0 =
        IndexMapper0::template index<diff_t>(ctx.get_indices_and_dims());
    const diff_t i1 =
        IndexMapper1::template index<diff_t>(ctx.get_indices_and_dims());
    const diff_t i2 =
        IndexMapper2::template index<diff_t>(ctx.get_indices_and_dims());

    if (i0 < len0 && i1 < len1 && i2 < len2)
    {
      body(*(segment0.begin() + i0), *(segment1.begin() + i1),
           *(segment2.begin() + i2));
    }
  }
};

template<typename SEGMENT, typename IndexMapper>
struct LoopExecute<
    RAJA::policy::hip::hip_indexer<
        RAJA::iteration_mapping::StridedLoop<named_usage::unspecified>,
        kernel_sync_requirement::none,
        IndexMapper>,
    SEGMENT>
{

  using diff_t = typename std::iterator_traits<
      typename SEGMENT::iterator>::difference_type;

  template<typename LaunchContextPolicy, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      SEGMENT const& segment,
      BODY const& body)
  {
    const diff_t len = segment.end() - segment.begin();
    const diff_t i_init =
        IndexMapper::template index<diff_t>(ctx.get_indices_and_dims());
    const diff_t i_stride =
        IndexMapper::template size<diff_t>(ctx.get_indices_and_dims());

    for (diff_t i = i_init; i < len; i += i_stride)
    {
      body(*(segment.begin() + i));
    }
  }
};

template<typename SEGMENT, typename IndexMapper0, typename IndexMapper1>
struct LoopExecute<
    RAJA::policy::hip::hip_indexer<
        RAJA::iteration_mapping::StridedLoop<named_usage::unspecified>,
        kernel_sync_requirement::none,
        IndexMapper0,
        IndexMapper1>,
    SEGMENT>
{

  using diff_t = typename std::iterator_traits<
      typename SEGMENT::iterator>::difference_type;

  template<typename LaunchContextPolicy, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      SEGMENT const& segment0,
      SEGMENT const& segment1,
      BODY const& body)
  {
    const int len0 = segment0.end() - segment0.begin();
    const int len1 = segment1.end() - segment1.begin();

    const diff_t i0_init =
        IndexMapper0::template index<diff_t>(ctx.get_indices_and_dims());
    const diff_t i1_init =
        IndexMapper1::template index<diff_t>(ctx.get_indices_and_dims());

    const diff_t i0_stride =
        IndexMapper0::template size<diff_t>(ctx.get_indices_and_dims());
    const diff_t i1_stride =
        IndexMapper1::template size<diff_t>(ctx.get_indices_and_dims());

    for (diff_t i0 = i0_init; i0 < len0; i0 += i0_stride)
    {

      for (diff_t i1 = i1_init; i1 < len1; i1 += i1_stride)
      {

        body(*(segment0.begin() + i0), *(segment1.begin() + i1));
      }
    }
  }
};

template<typename SEGMENT,
         typename IndexMapper0,
         typename IndexMapper1,
         typename IndexMapper2>
struct LoopExecute<
    RAJA::policy::hip::hip_indexer<
        RAJA::iteration_mapping::StridedLoop<named_usage::unspecified>,
        kernel_sync_requirement::none,
        IndexMapper0,
        IndexMapper1,
        IndexMapper2>,
    SEGMENT>
{

  using diff_t = typename std::iterator_traits<
      typename SEGMENT::iterator>::difference_type;

  template<typename LaunchContextPolicy, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      SEGMENT const& segment0,
      SEGMENT const& segment1,
      SEGMENT const& segment2,
      BODY const& body)
  {
    const int len0 = segment0.end() - segment0.begin();
    const int len1 = segment1.end() - segment1.begin();
    const int len2 = segment2.end() - segment2.begin();

    const diff_t i0_init =
        IndexMapper0::template index<diff_t>(ctx.get_indices_and_dims());
    const diff_t i1_init =
        IndexMapper1::template index<diff_t>(ctx.get_indices_and_dims());
    const diff_t i2_init =
        IndexMapper2::template index<diff_t>(ctx.get_indices_and_dims());

    const diff_t i0_stride =
        IndexMapper0::template size<diff_t>(ctx.get_indices_and_dims());
    const diff_t i1_stride =
        IndexMapper1::template size<diff_t>(ctx.get_indices_and_dims());
    const diff_t i2_stride =
        IndexMapper2::template size<diff_t>(ctx.get_indices_and_dims());

    for (diff_t i0 = i0_init; i0 < len0; i0 += i0_stride)
    {

      for (diff_t i1 = i1_init; i1 < len1; i1 += i1_stride)
      {

        for (diff_t i2 = i2_init; i2 < len2; i2 += i2_stride)
        {

          body(*(segment0.begin() + i0), *(segment1.begin() + i1),
               *(segment2.begin() + i2));
        }
      }
    }
  }
};

/*
   HIP generic loop_icount implementations
*/
template<typename SEGMENT, typename IndexMapper>
struct LoopICountExecute<
    RAJA::policy::hip::hip_indexer<RAJA::iteration_mapping::DirectUnchecked,
                                   kernel_sync_requirement::none,
                                   IndexMapper>,
    SEGMENT>
{

  using diff_t = typename std::iterator_traits<
      typename SEGMENT::iterator>::difference_type;

  template<typename LaunchContextPolicy, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      SEGMENT const& segment,
      BODY const& body)
  {
    const diff_t i =
        IndexMapper::template index<diff_t>(ctx.get_indices_and_dims());

    body(*(segment.begin() + i), i);
  }
};

template<typename SEGMENT, typename IndexMapper0, typename IndexMapper1>
struct LoopICountExecute<
    RAJA::policy::hip::hip_indexer<RAJA::iteration_mapping::DirectUnchecked,
                                   kernel_sync_requirement::none,
                                   IndexMapper0,
                                   IndexMapper1>,
    SEGMENT>
{

  using diff_t = typename std::iterator_traits<
      typename SEGMENT::iterator>::difference_type;

  template<typename LaunchContextPolicy, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      SEGMENT const& segment0,
      SEGMENT const& segment1,
      BODY const& body)
  {
    const diff_t i0 =
        IndexMapper0::template index<diff_t>(ctx.get_indices_and_dims());
    const diff_t i1 =
        IndexMapper1::template index<diff_t>(ctx.get_indices_and_dims());

    body(*(segment0.begin() + i0), *(segment1.begin() + i1), i0, i1);
  }
};

template<typename SEGMENT,
         typename IndexMapper0,
         typename IndexMapper1,
         typename IndexMapper2>
struct LoopICountExecute<
    RAJA::policy::hip::hip_indexer<RAJA::iteration_mapping::DirectUnchecked,
                                   kernel_sync_requirement::none,
                                   IndexMapper0,
                                   IndexMapper1,
                                   IndexMapper2>,
    SEGMENT>
{

  using diff_t = typename std::iterator_traits<
      typename SEGMENT::iterator>::difference_type;

  template<typename LaunchContextPolicy, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      SEGMENT const& segment0,
      SEGMENT const& segment1,
      SEGMENT const& segment2,
      BODY const& body)
  {
    const diff_t i0 =
        IndexMapper0::template index<diff_t>(ctx.get_indices_and_dims());
    const diff_t i1 =
        IndexMapper1::template index<diff_t>(ctx.get_indices_and_dims());
    const diff_t i2 =
        IndexMapper2::template index<diff_t>(ctx.get_indices_and_dims());

    body(*(segment0.begin() + i0), *(segment1.begin() + i1),
         *(segment2.begin() + i2), i0, i1, i2);
  }
};

template<typename SEGMENT, typename IndexMapper>
struct LoopICountExecute<
    RAJA::policy::hip::hip_indexer<RAJA::iteration_mapping::Direct,
                                   kernel_sync_requirement::none,
                                   IndexMapper>,
    SEGMENT>
{

  using diff_t = typename std::iterator_traits<
      typename SEGMENT::iterator>::difference_type;

  template<typename LaunchContextPolicy, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      SEGMENT const& segment,
      BODY const& body)
  {
    const diff_t len = segment.end() - segment.begin();
    const diff_t i =
        IndexMapper::template index<diff_t>(ctx.get_indices_and_dims());

    if (i < len)
    {
      body(*(segment.begin() + i), i);
    }
  }
};

template<typename SEGMENT, typename IndexMapper0, typename IndexMapper1>
struct LoopICountExecute<
    RAJA::policy::hip::hip_indexer<RAJA::iteration_mapping::Direct,
                                   kernel_sync_requirement::none,
                                   IndexMapper0,
                                   IndexMapper1>,
    SEGMENT>
{

  using diff_t = typename std::iterator_traits<
      typename SEGMENT::iterator>::difference_type;

  template<typename LaunchContextPolicy, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      SEGMENT const& segment0,
      SEGMENT const& segment1,
      BODY const& body)
  {
    const int len0 = segment0.end() - segment0.begin();
    const int len1 = segment1.end() - segment1.begin();

    const diff_t i0 =
        IndexMapper0::template index<diff_t>(ctx.get_indices_and_dims());
    const diff_t i1 =
        IndexMapper1::template index<diff_t>(ctx.get_indices_and_dims());

    if (i0 < len0 && i1 < len1)
    {
      body(*(segment0.begin() + i0), *(segment1.begin() + i1), i0, i1);
    }
  }
};

template<typename SEGMENT,
         typename IndexMapper0,
         typename IndexMapper1,
         typename IndexMapper2>
struct LoopICountExecute<
    RAJA::policy::hip::hip_indexer<RAJA::iteration_mapping::Direct,
                                   kernel_sync_requirement::none,
                                   IndexMapper0,
                                   IndexMapper1,
                                   IndexMapper2>,
    SEGMENT>
{

  using diff_t = typename std::iterator_traits<
      typename SEGMENT::iterator>::difference_type;

  template<typename LaunchContextPolicy, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      SEGMENT const& segment0,
      SEGMENT const& segment1,
      SEGMENT const& segment2,
      BODY const& body)
  {
    const int len0 = segment0.end() - segment0.begin();
    const int len1 = segment1.end() - segment1.begin();
    const int len2 = segment2.end() - segment2.begin();

    const diff_t i0 =
        IndexMapper0::template index<diff_t>(ctx.get_indices_and_dims());
    const diff_t i1 =
        IndexMapper1::template index<diff_t>(ctx.get_indices_and_dims());
    const diff_t i2 =
        IndexMapper2::template index<diff_t>(ctx.get_indices_and_dims());

    if (i0 < len0 && i1 < len1 && i2 < len2)
    {
      body(*(segment0.begin() + i0), *(segment1.begin() + i1),
           *(segment2.begin() + i2), i0, i1, i2);
    }
  }
};

template<typename SEGMENT, typename IndexMapper>
struct LoopICountExecute<
    RAJA::policy::hip::hip_indexer<
        RAJA::iteration_mapping::StridedLoop<named_usage::unspecified>,
        kernel_sync_requirement::none,
        IndexMapper>,
    SEGMENT>
{

  using diff_t = typename std::iterator_traits<
      typename SEGMENT::iterator>::difference_type;

  template<typename LaunchContextPolicy, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      SEGMENT const& segment,
      BODY const& body)
  {
    const diff_t len = segment.end() - segment.begin();
    const diff_t i_init =
        IndexMapper::template index<diff_t>(ctx.get_indices_and_dims());
    const diff_t i_stride =
        IndexMapper::template size<diff_t>(ctx.get_indices_and_dims());

    for (diff_t i = i_init; i < len; i += i_stride)
    {
      body(*(segment.begin() + i), i);
    }
  }
};

template<typename SEGMENT, typename IndexMapper0, typename IndexMapper1>
struct LoopICountExecute<
    RAJA::policy::hip::hip_indexer<
        RAJA::iteration_mapping::StridedLoop<named_usage::unspecified>,
        kernel_sync_requirement::none,
        IndexMapper0,
        IndexMapper1>,
    SEGMENT>
{

  using diff_t = typename std::iterator_traits<
      typename SEGMENT::iterator>::difference_type;

  template<typename LaunchContextPolicy, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      SEGMENT const& segment0,
      SEGMENT const& segment1,
      BODY const& body)
  {
    const int len0 = segment0.end() - segment0.begin();
    const int len1 = segment1.end() - segment1.begin();

    const diff_t i0_init =
        IndexMapper0::template index<diff_t>(ctx.get_indices_and_dims());
    const diff_t i1_init =
        IndexMapper1::template index<diff_t>(ctx.get_indices_and_dims());

    const diff_t i0_stride =
        IndexMapper0::template size<diff_t>(ctx.get_indices_and_dims());
    const diff_t i1_stride =
        IndexMapper1::template size<diff_t>(ctx.get_indices_and_dims());

    for (diff_t i0 = i0_init; i0 < len0; i0 += i0_stride)
    {

      for (diff_t i1 = i1_init; i1 < len1; i1 += i1_stride)
      {

        body(*(segment0.begin() + i0), *(segment1.begin() + i1), i0, i1);
      }
    }
  }
};

template<typename SEGMENT,
         typename IndexMapper0,
         typename IndexMapper1,
         typename IndexMapper2>
struct LoopICountExecute<
    RAJA::policy::hip::hip_indexer<
        RAJA::iteration_mapping::StridedLoop<named_usage::unspecified>,
        kernel_sync_requirement::none,
        IndexMapper0,
        IndexMapper1,
        IndexMapper2>,
    SEGMENT>
{

  using diff_t = typename std::iterator_traits<
      typename SEGMENT::iterator>::difference_type;

  template<typename LaunchContextPolicy, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      SEGMENT const& segment0,
      SEGMENT const& segment1,
      SEGMENT const& segment2,
      BODY const& body)
  {
    const int len0 = segment0.end() - segment0.begin();
    const int len1 = segment1.end() - segment1.begin();
    const int len2 = segment2.end() - segment2.begin();

    const diff_t i0_init =
        IndexMapper0::template index<diff_t>(ctx.get_indices_and_dims());
    const diff_t i1_init =
        IndexMapper1::template index<diff_t>(ctx.get_indices_and_dims());
    const diff_t i2_init =
        IndexMapper2::template index<diff_t>(ctx.get_indices_and_dims());

    const diff_t i0_stride =
        IndexMapper0::template size<diff_t>(ctx.get_indices_and_dims());
    const diff_t i1_stride =
        IndexMapper1::template size<diff_t>(ctx.get_indices_and_dims());
    const diff_t i2_stride =
        IndexMapper2::template size<diff_t>(ctx.get_indices_and_dims());

    for (diff_t i0 = i0_init; i0 < len0; i0 += i0_stride)
    {

      for (diff_t i1 = i1_init; i1 < len1; i1 += i1_stride)
      {

        for (diff_t i2 = i2_init; i2 < len2; i2 += i2_stride)
        {

          body(*(segment0.begin() + i0), *(segment1.begin() + i1),
               *(segment2.begin() + i2), i0, i1, i2);
        }
      }
    }
  }
};

/*
   HIP generic flattened loop implementations
*/
template<typename SEGMENT, kernel_sync_requirement sync, typename IndexMapper0>
struct LoopExecute<RAJA::policy::hip::hip_flatten_indexer<
                       RAJA::iteration_mapping::DirectUnchecked,
                       sync,
                       IndexMapper0>,
                   SEGMENT>
    : LoopExecute<RAJA::policy::hip::hip_indexer<
                      RAJA::iteration_mapping::DirectUnchecked,
                      sync,
                      IndexMapper0>,
                  SEGMENT>
{};

template<typename SEGMENT, typename IndexMapper0, typename IndexMapper1>
struct LoopExecute<RAJA::policy::hip::hip_flatten_indexer<
                       RAJA::iteration_mapping::DirectUnchecked,
                       kernel_sync_requirement::none,
                       IndexMapper0,
                       IndexMapper1>,
                   SEGMENT>
{
  using diff_t = typename std::iterator_traits<
      typename SEGMENT::iterator>::difference_type;

  template<typename LaunchContextPolicy, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      SEGMENT const& segment,
      BODY const& body)
  {
    const int i0 =
        IndexMapper0::template index<diff_t>(ctx.get_indices_and_dims());
    const int i1 =
        IndexMapper1::template index<diff_t>(ctx.get_indices_and_dims());

    const diff_t i0_stride =
        IndexMapper0::template size<diff_t>(ctx.get_indices_and_dims());

    const int i = i0 + i0_stride * i1;

    body(*(segment.begin() + i));
  }
};

template<typename SEGMENT,
         typename IndexMapper0,
         typename IndexMapper1,
         typename IndexMapper2>
struct LoopExecute<RAJA::policy::hip::hip_flatten_indexer<
                       RAJA::iteration_mapping::DirectUnchecked,
                       kernel_sync_requirement::none,
                       IndexMapper0,
                       IndexMapper1,
                       IndexMapper2>,
                   SEGMENT>
{
  using diff_t = typename std::iterator_traits<
      typename SEGMENT::iterator>::difference_type;

  template<typename LaunchContextPolicy, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      SEGMENT const& segment,
      BODY const& body)
  {
    const int i0 =
        IndexMapper0::template index<diff_t>(ctx.get_indices_and_dims());
    const int i1 =
        IndexMapper1::template index<diff_t>(ctx.get_indices_and_dims());
    const int i2 =
        IndexMapper2::template index<diff_t>(ctx.get_indices_and_dims());

    const diff_t i0_stride =
        IndexMapper0::template size<diff_t>(ctx.get_indices_and_dims());
    const diff_t i1_stride =
        IndexMapper1::template size<diff_t>(ctx.get_indices_and_dims());

    const int i = i0 + i0_stride * (i1 + i1_stride * i2);

    body(*(segment.begin() + i));
  }
};

template<typename SEGMENT, kernel_sync_requirement sync, typename IndexMapper0>
struct LoopExecute<
    RAJA::policy::hip::hip_flatten_indexer<RAJA::iteration_mapping::Direct,
                                           sync,
                                           IndexMapper0>,
    SEGMENT>
    : LoopExecute<
          RAJA::policy::hip::
              hip_indexer<RAJA::iteration_mapping::Direct, sync, IndexMapper0>,
          SEGMENT>
{};

template<typename SEGMENT, typename IndexMapper0, typename IndexMapper1>
struct LoopExecute<
    RAJA::policy::hip::hip_flatten_indexer<RAJA::iteration_mapping::Direct,
                                           kernel_sync_requirement::none,
                                           IndexMapper0,
                                           IndexMapper1>,
    SEGMENT>
{
  using diff_t = typename std::iterator_traits<
      typename SEGMENT::iterator>::difference_type;

  template<typename LaunchContextPolicy, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      SEGMENT const& segment,
      BODY const& body)
  {
    const int len = segment.end() - segment.begin();

    const int i0 =
        IndexMapper0::template index<diff_t>(ctx.get_indices_and_dims());
    const int i1 =
        IndexMapper1::template index<diff_t>(ctx.get_indices_and_dims());

    const diff_t i0_stride =
        IndexMapper0::template size<diff_t>(ctx.get_indices_and_dims());

    const int i = i0 + i0_stride * i1;

    if (i < len)
    {
      body(*(segment.begin() + i));
    }
  }
};

template<typename SEGMENT,
         typename IndexMapper0,
         typename IndexMapper1,
         typename IndexMapper2>
struct LoopExecute<
    RAJA::policy::hip::hip_flatten_indexer<RAJA::iteration_mapping::Direct,
                                           kernel_sync_requirement::none,
                                           IndexMapper0,
                                           IndexMapper1,
                                           IndexMapper2>,
    SEGMENT>
{
  using diff_t = typename std::iterator_traits<
      typename SEGMENT::iterator>::difference_type;

  template<typename LaunchContextPolicy, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      SEGMENT const& segment,
      BODY const& body)
  {
    const int len = segment.end() - segment.begin();

    const int i0 =
        IndexMapper0::template index<diff_t>(ctx.get_indices_and_dims());
    const int i1 =
        IndexMapper1::template index<diff_t>(ctx.get_indices_and_dims());
    const int i2 =
        IndexMapper2::template index<diff_t>(ctx.get_indices_and_dims());

    const diff_t i0_stride =
        IndexMapper0::template size<diff_t>(ctx.get_indices_and_dims());
    const diff_t i1_stride =
        IndexMapper1::template size<diff_t>(ctx.get_indices_and_dims());

    const int i = i0 + i0_stride * (i1 + i1_stride * i2);

    if (i < len)
    {
      body(*(segment.begin() + i));
    }
  }
};

template<typename SEGMENT, kernel_sync_requirement sync, typename IndexMapper0>
struct LoopExecute<
    RAJA::policy::hip::hip_flatten_indexer<
        RAJA::iteration_mapping::StridedLoop<named_usage::unspecified>,
        sync,
        IndexMapper0>,
    SEGMENT>
    : LoopExecute<
          RAJA::policy::hip::hip_indexer<
              RAJA::iteration_mapping::StridedLoop<named_usage::unspecified>,
              sync,
              IndexMapper0>,
          SEGMENT>
{};

template<typename SEGMENT, typename IndexMapper0, typename IndexMapper1>
struct LoopExecute<
    RAJA::policy::hip::hip_flatten_indexer<
        RAJA::iteration_mapping::StridedLoop<named_usage::unspecified>,
        kernel_sync_requirement::none,
        IndexMapper0,
        IndexMapper1>,
    SEGMENT>
{
  using diff_t = typename std::iterator_traits<
      typename SEGMENT::iterator>::difference_type;

  template<typename LaunchContextPolicy, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      SEGMENT const& segment,
      BODY const& body)
  {
    const int len = segment.end() - segment.begin();

    const int i0 =
        IndexMapper0::template index<diff_t>(ctx.get_indices_and_dims());
    const int i1 =
        IndexMapper1::template index<diff_t>(ctx.get_indices_and_dims());

    const int i0_stride =
        IndexMapper0::template size<diff_t>(ctx.get_indices_and_dims());
    const int i1_stride =
        IndexMapper1::template size<diff_t>(ctx.get_indices_and_dims());

    for (int i = i0 + i0_stride * i1; i < len; i += i0_stride * i1_stride)
    {
      body(*(segment.begin() + i));
    }
  }
};

template<typename SEGMENT,
         typename IndexMapper0,
         typename IndexMapper1,
         typename IndexMapper2>
struct LoopExecute<
    RAJA::policy::hip::hip_flatten_indexer<
        RAJA::iteration_mapping::StridedLoop<named_usage::unspecified>,
        kernel_sync_requirement::none,
        IndexMapper0,
        IndexMapper1,
        IndexMapper2>,
    SEGMENT>
{
  using diff_t = typename std::iterator_traits<
      typename SEGMENT::iterator>::difference_type;

  template<typename LaunchContextPolicy, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      SEGMENT const& segment,
      BODY const& body)
  {
    const int len = segment.end() - segment.begin();

    const int i0 =
        IndexMapper0::template index<diff_t>(ctx.get_indices_and_dims());
    const int i1 =
        IndexMapper1::template index<diff_t>(ctx.get_indices_and_dims());
    const int i2 =
        IndexMapper2::template index<diff_t>(ctx.get_indices_and_dims());

    const int i0_stride =
        IndexMapper0::template size<diff_t>(ctx.get_indices_and_dims());
    const int i1_stride =
        IndexMapper1::template size<diff_t>(ctx.get_indices_and_dims());
    const int i2_stride =
        IndexMapper2::template size<diff_t>(ctx.get_indices_and_dims());

    for (int i = i0 + i0_stride * (i1 + i1_stride * i2); i < len;
         i += i0_stride * i1_stride * i2_stride)
    {
      body(*(segment.begin() + i));
    }
  }
};

/*
   HIP generic tile implementations
*/
template<typename SEGMENT, typename IndexMapper>
struct TileExecute<
    RAJA::policy::hip::hip_indexer<RAJA::iteration_mapping::DirectUnchecked,
                                   kernel_sync_requirement::none,
                                   IndexMapper>,
    SEGMENT>
{

  using diff_t = typename std::iterator_traits<
      typename SEGMENT::iterator>::difference_type;

  template<typename LaunchContextPolicy, typename TILE_T, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      TILE_T tile_size,
      SEGMENT const& segment,
      BODY const& body)
  {
    const diff_t i =
        IndexMapper::template index<diff_t>(ctx.get_indices_and_dims()) *
        static_cast<diff_t>(tile_size);

    body(segment.slice(i, static_cast<diff_t>(tile_size)));
  }
};

template<typename SEGMENT, typename IndexMapper0, typename IndexMapper1>
struct TileExecute<
    RAJA::policy::hip::hip_indexer<RAJA::iteration_mapping::DirectUnchecked,
                                   kernel_sync_requirement::none,
                                   IndexMapper0,
                                   IndexMapper1>,
    SEGMENT>
{

  using diff_t = typename std::iterator_traits<
      typename SEGMENT::iterator>::difference_type;

  template<typename LaunchContextPolicy, typename TILE_T, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      TILE_T tile_size0,
      TILE_T tile_size1,
      SEGMENT const& segment0,
      SEGMENT const& segment1,
      BODY const& body)
  {
    const diff_t i0 =
        IndexMapper0::template index<diff_t>(ctx.get_indices_and_dims()) *
        static_cast<diff_t>(tile_size0);
    const diff_t i1 =
        IndexMapper1::template index<diff_t>(ctx.get_indices_and_dims()) *
        static_cast<diff_t>(tile_size1);

    body(segment0.slice(i0, static_cast<diff_t>(tile_size0)),
         segment1.slice(i1, static_cast<diff_t>(tile_size1)));
  }
};

template<typename SEGMENT,
         typename IndexMapper0,
         typename IndexMapper1,
         typename IndexMapper2>
struct TileExecute<
    RAJA::policy::hip::hip_indexer<RAJA::iteration_mapping::DirectUnchecked,
                                   kernel_sync_requirement::none,
                                   IndexMapper0,
                                   IndexMapper1,
                                   IndexMapper2>,
    SEGMENT>
{

  using diff_t = typename std::iterator_traits<
      typename SEGMENT::iterator>::difference_type;

  template<typename LaunchContextPolicy, typename TILE_T, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      TILE_T tile_size0,
      TILE_T tile_size1,
      TILE_T tile_size2,
      SEGMENT const& segment0,
      SEGMENT const& segment1,
      SEGMENT const& segment2,
      BODY const& body)
  {
    const diff_t i0 =
        IndexMapper0::template index<diff_t>(ctx.get_indices_and_dims()) *
        static_cast<diff_t>(tile_size0);
    const diff_t i1 =
        IndexMapper1::template index<diff_t>(ctx.get_indices_and_dims()) *
        static_cast<diff_t>(tile_size1);
    const diff_t i2 =
        IndexMapper2::template index<diff_t>(ctx.get_indices_and_dims()) *
        static_cast<diff_t>(tile_size2);

    body(segment0.slice(i0, static_cast<diff_t>(tile_size0)),
         segment1.slice(i1, static_cast<diff_t>(tile_size1)),
         segment2.slice(i2, static_cast<diff_t>(tile_size2)));
  }
};

template<typename SEGMENT, typename IndexMapper>
struct TileExecute<
    RAJA::policy::hip::hip_indexer<RAJA::iteration_mapping::Direct,
                                   kernel_sync_requirement::none,
                                   IndexMapper>,
    SEGMENT>
{

  using diff_t = typename std::iterator_traits<
      typename SEGMENT::iterator>::difference_type;

  template<typename LaunchContextPolicy, typename TILE_T, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      TILE_T tile_size,
      SEGMENT const& segment,
      BODY const& body)
  {
    const diff_t len = segment.end() - segment.begin();
    const diff_t i =
        IndexMapper::template index<diff_t>(ctx.get_indices_and_dims()) *
        static_cast<diff_t>(tile_size);

    if (i < len)
    {
      body(segment.slice(i, static_cast<diff_t>(tile_size)));
    }
  }
};

template<typename SEGMENT, typename IndexMapper0, typename IndexMapper1>
struct TileExecute<
    RAJA::policy::hip::hip_indexer<RAJA::iteration_mapping::Direct,
                                   kernel_sync_requirement::none,
                                   IndexMapper0,
                                   IndexMapper1>,
    SEGMENT>
{

  using diff_t = typename std::iterator_traits<
      typename SEGMENT::iterator>::difference_type;

  template<typename LaunchContextPolicy, typename TILE_T, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      TILE_T tile_size0,
      TILE_T tile_size1,
      SEGMENT const& segment0,
      SEGMENT const& segment1,
      BODY const& body)
  {
    const diff_t len0 = segment0.end() - segment0.begin();
    const diff_t len1 = segment1.end() - segment1.begin();

    const diff_t i0 =
        IndexMapper0::template index<diff_t>(ctx.get_indices_and_dims()) *
        static_cast<diff_t>(tile_size0);
    const diff_t i1 =
        IndexMapper1::template index<diff_t>(ctx.get_indices_and_dims()) *
        static_cast<diff_t>(tile_size1);

    if (i0 < len0 && i1 < len1)
    {
      body(segment0.slice(i0, static_cast<diff_t>(tile_size0)),
           segment1.slice(i1, static_cast<diff_t>(tile_size1)));
    }
  }
};

template<typename SEGMENT,
         typename IndexMapper0,
         typename IndexMapper1,
         typename IndexMapper2>
struct TileExecute<
    RAJA::policy::hip::hip_indexer<RAJA::iteration_mapping::Direct,
                                   kernel_sync_requirement::none,
                                   IndexMapper0,
                                   IndexMapper1,
                                   IndexMapper2>,
    SEGMENT>
{

  using diff_t = typename std::iterator_traits<
      typename SEGMENT::iterator>::difference_type;

  template<typename LaunchContextPolicy, typename TILE_T, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      TILE_T tile_size0,
      TILE_T tile_size1,
      TILE_T tile_size2,
      SEGMENT const& segment0,
      SEGMENT const& segment1,
      SEGMENT const& segment2,
      BODY const& body)
  {
    const diff_t len0 = segment0.end() - segment0.begin();
    const diff_t len1 = segment1.end() - segment1.begin();
    const diff_t len2 = segment2.end() - segment2.begin();

    const diff_t i0 =
        IndexMapper0::template index<diff_t>(ctx.get_indices_and_dims()) *
        static_cast<diff_t>(tile_size0);
    const diff_t i1 =
        IndexMapper1::template index<diff_t>(ctx.get_indices_and_dims()) *
        static_cast<diff_t>(tile_size1);
    const diff_t i2 =
        IndexMapper2::template index<diff_t>(ctx.get_indices_and_dims()) *
        static_cast<diff_t>(tile_size2);

    if (i0 < len0 && i1 < len1 && i2 < len2)
    {
      body(segment0.slice(i0, static_cast<diff_t>(tile_size0)),
           segment1.slice(i1, static_cast<diff_t>(tile_size1)),
           segment2.slice(i2, static_cast<diff_t>(tile_size2)));
    }
  }
};

template<typename SEGMENT, typename IndexMapper>
struct TileExecute<
    RAJA::policy::hip::hip_indexer<
        RAJA::iteration_mapping::StridedLoop<named_usage::unspecified>,
        kernel_sync_requirement::none,
        IndexMapper>,
    SEGMENT>
{

  using diff_t = typename std::iterator_traits<
      typename SEGMENT::iterator>::difference_type;

  template<typename LaunchContextPolicy, typename TILE_T, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      TILE_T tile_size,
      SEGMENT const& segment,
      BODY const& body)
  {
    const diff_t len = segment.end() - segment.begin();
    const diff_t i_init =
        IndexMapper::template index<diff_t>(ctx.get_indices_and_dims()) *
        static_cast<diff_t>(tile_size);
    const diff_t i_stride =
        IndexMapper::template size<diff_t>(ctx.get_indices_and_dims()) *
        static_cast<diff_t>(tile_size);

    for (diff_t i = i_init; i < len; i += i_stride)
    {
      body(segment.slice(i, static_cast<diff_t>(tile_size)));
    }
  }
};

template<typename SEGMENT, typename IndexMapper0, typename IndexMapper1>
struct TileExecute<
    RAJA::policy::hip::hip_indexer<
        RAJA::iteration_mapping::StridedLoop<named_usage::unspecified>,
        kernel_sync_requirement::none,
        IndexMapper0,
        IndexMapper1>,
    SEGMENT>
{

  using diff_t = typename std::iterator_traits<
      typename SEGMENT::iterator>::difference_type;

  template<typename LaunchContextPolicy, typename TILE_T, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      TILE_T tile_size0,
      TILE_T tile_size1,
      SEGMENT const& segment0,
      SEGMENT const& segment1,
      BODY const& body)
  {
    const diff_t len0 = segment0.end() - segment0.begin();
    const diff_t len1 = segment1.end() - segment1.begin();

    const diff_t i0_init =
        IndexMapper0::template index<diff_t>(ctx.get_indices_and_dims()) *
        static_cast<diff_t>(tile_size0);
    const diff_t i1_init =
        IndexMapper1::template index<diff_t>(ctx.get_indices_and_dims()) *
        static_cast<diff_t>(tile_size1);

    const diff_t i0_stride =
        IndexMapper0::template size<diff_t>(ctx.get_indices_and_dims()) *
        static_cast<diff_t>(tile_size0);
    const diff_t i1_stride =
        IndexMapper1::template size<diff_t>(ctx.get_indices_and_dims()) *
        static_cast<diff_t>(tile_size1);

    for (diff_t i0 = i0_init; i0 < len0; i0 += i0_stride)
    {
      for (diff_t i1 = i1_init; i1 < len1; i1 += i1_stride)
      {
        body(segment0.slice(i0, static_cast<diff_t>(tile_size0)),
             segment1.slice(i1, static_cast<diff_t>(tile_size1)));
      }
    }
  }
};

template<typename SEGMENT,
         typename IndexMapper0,
         typename IndexMapper1,
         typename IndexMapper2>
struct TileExecute<
    RAJA::policy::hip::hip_indexer<
        RAJA::iteration_mapping::StridedLoop<named_usage::unspecified>,
        kernel_sync_requirement::none,
        IndexMapper0,
        IndexMapper1,
        IndexMapper2>,
    SEGMENT>
{

  using diff_t = typename std::iterator_traits<
      typename SEGMENT::iterator>::difference_type;

  template<typename LaunchContextPolicy, typename TILE_T, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      TILE_T tile_size0,
      TILE_T tile_size1,
      TILE_T tile_size2,
      SEGMENT const& segment0,
      SEGMENT const& segment1,
      SEGMENT const& segment2,
      BODY const& body)
  {
    const diff_t len0 = segment0.end() - segment0.begin();
    const diff_t len1 = segment1.end() - segment1.begin();
    const diff_t len2 = segment2.end() - segment2.begin();

    const diff_t i0_init =
        IndexMapper0::template index<diff_t>(ctx.get_indices_and_dims()) *
        static_cast<diff_t>(tile_size0);
    const diff_t i1_init =
        IndexMapper1::template index<diff_t>(ctx.get_indices_and_dims()) *
        static_cast<diff_t>(tile_size1);
    const diff_t i2_init =
        IndexMapper2::template index<diff_t>(ctx.get_indices_and_dims()) *
        static_cast<diff_t>(tile_size2);

    const diff_t i0_stride =
        IndexMapper0::template size<diff_t>(ctx.get_indices_and_dims()) *
        static_cast<diff_t>(tile_size0);
    const diff_t i1_stride =
        IndexMapper1::template size<diff_t>(ctx.get_indices_and_dims()) *
        static_cast<diff_t>(tile_size1);
    const diff_t i2_stride =
        IndexMapper2::template size<diff_t>(ctx.get_indices_and_dims()) *
        static_cast<diff_t>(tile_size2);

    for (diff_t i0 = i0_init; i0 < len0; i0 += i0_stride)
    {
      for (diff_t i1 = i1_init; i1 < len1; i1 += i1_stride)
      {
        for (diff_t i2 = i2_init; i2 < len2; i2 += i2_stride)
        {
          body(segment0.slice(i0, static_cast<diff_t>(tile_size0)),
               segment1.slice(i1, static_cast<diff_t>(tile_size1)),
               segment2.slice(i2, static_cast<diff_t>(tile_size2)));
        }
      }
    }
  }
};

/*
   HIP generic tile_tcount implementations
*/
template<typename SEGMENT, typename IndexMapper>
struct TileTCountExecute<
    RAJA::policy::hip::hip_indexer<RAJA::iteration_mapping::DirectUnchecked,
                                   kernel_sync_requirement::none,
                                   IndexMapper>,
    SEGMENT>
{

  using diff_t = typename std::iterator_traits<
      typename SEGMENT::iterator>::difference_type;

  template<typename LaunchContextPolicy, typename TILE_T, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      TILE_T tile_size,
      SEGMENT const& segment,
      BODY const& body)
  {
    const diff_t t =
        IndexMapper::template index<diff_t>(ctx.get_indices_and_dims());
    const diff_t i = t * static_cast<diff_t>(tile_size);

    body(segment.slice(i, static_cast<diff_t>(tile_size)), t);
  }
};

template<typename SEGMENT, typename IndexMapper0, typename IndexMapper1>
struct TileTCountExecute<
    RAJA::policy::hip::hip_indexer<RAJA::iteration_mapping::DirectUnchecked,
                                   kernel_sync_requirement::none,
                                   IndexMapper0,
                                   IndexMapper1>,
    SEGMENT>
{

  using diff_t = typename std::iterator_traits<
      typename SEGMENT::iterator>::difference_type;

  template<typename LaunchContextPolicy, typename TILE_T, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      TILE_T tile_size0,
      TILE_T tile_size1,
      SEGMENT const& segment0,
      SEGMENT const& segment1,
      BODY const& body)
  {
    const diff_t t0 =
        IndexMapper0::template index<diff_t>(ctx.get_indices_and_dims());
    const diff_t t1 =
        IndexMapper1::template index<diff_t>(ctx.get_indices_and_dims());

    const diff_t i0 = t0 * static_cast<diff_t>(tile_size0);
    const diff_t i1 = t1 * static_cast<diff_t>(tile_size1);

    body(segment0.slice(i0, static_cast<diff_t>(tile_size0)),
         segment1.slice(i1, static_cast<diff_t>(tile_size1)), t0, t1);
  }
};

template<typename SEGMENT,
         typename IndexMapper0,
         typename IndexMapper1,
         typename IndexMapper2>
struct TileTCountExecute<
    RAJA::policy::hip::hip_indexer<RAJA::iteration_mapping::DirectUnchecked,
                                   kernel_sync_requirement::none,
                                   IndexMapper0,
                                   IndexMapper1,
                                   IndexMapper2>,
    SEGMENT>
{

  using diff_t = typename std::iterator_traits<
      typename SEGMENT::iterator>::difference_type;

  template<typename LaunchContextPolicy, typename TILE_T, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      TILE_T tile_size0,
      TILE_T tile_size1,
      TILE_T tile_size2,
      SEGMENT const& segment0,
      SEGMENT const& segment1,
      SEGMENT const& segment2,
      BODY const& body)
  {
    const diff_t t0 =
        IndexMapper0::template index<diff_t>(ctx.get_indices_and_dims());
    const diff_t t1 =
        IndexMapper1::template index<diff_t>(ctx.get_indices_and_dims());
    const diff_t t2 =
        IndexMapper2::template index<diff_t>(ctx.get_indices_and_dims());

    const diff_t i0 = t0 * static_cast<diff_t>(tile_size0);
    const diff_t i1 = t1 * static_cast<diff_t>(tile_size1);
    const diff_t i2 = t2 * static_cast<diff_t>(tile_size2);

    body(segment0.slice(i0, static_cast<diff_t>(tile_size0)),
         segment1.slice(i1, static_cast<diff_t>(tile_size1)),
         segment2.slice(i2, static_cast<diff_t>(tile_size2)), t0, t1, t2);
  }
};

template<typename SEGMENT, typename IndexMapper>
struct TileTCountExecute<
    RAJA::policy::hip::hip_indexer<RAJA::iteration_mapping::Direct,
                                   kernel_sync_requirement::none,
                                   IndexMapper>,
    SEGMENT>
{

  using diff_t = typename std::iterator_traits<
      typename SEGMENT::iterator>::difference_type;

  template<typename LaunchContextPolicy, typename TILE_T, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      TILE_T tile_size,
      SEGMENT const& segment,
      BODY const& body)
  {
    const diff_t len = segment.end() - segment.begin();
    const diff_t t =
        IndexMapper::template index<diff_t>(ctx.get_indices_and_dims());
    const diff_t i = t * static_cast<diff_t>(tile_size);

    if (i < len)
    {
      body(segment.slice(i, static_cast<diff_t>(tile_size)), t);
    }
  }
};

template<typename SEGMENT, typename IndexMapper0, typename IndexMapper1>
struct TileTCountExecute<
    RAJA::policy::hip::hip_indexer<RAJA::iteration_mapping::Direct,
                                   kernel_sync_requirement::none,
                                   IndexMapper0,
                                   IndexMapper1>,
    SEGMENT>
{

  using diff_t = typename std::iterator_traits<
      typename SEGMENT::iterator>::difference_type;

  template<typename LaunchContextPolicy, typename TILE_T, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      TILE_T tile_size0,
      TILE_T tile_size1,
      SEGMENT const& segment0,
      SEGMENT const& segment1,
      BODY const& body)
  {
    const diff_t len0 = segment0.end() - segment0.begin();
    const diff_t len1 = segment1.end() - segment1.begin();

    const diff_t t0 =
        IndexMapper0::template index<diff_t>(ctx.get_indices_and_dims());
    const diff_t t1 =
        IndexMapper1::template index<diff_t>(ctx.get_indices_and_dims());

    const diff_t i0 = t0 * static_cast<diff_t>(tile_size0);
    const diff_t i1 = t1 * static_cast<diff_t>(tile_size1);

    if (i0 < len0 && i1 < len1)
    {
      body(segment0.slice(i0, static_cast<diff_t>(tile_size0)),
           segment1.slice(i1, static_cast<diff_t>(tile_size1)), t0, t1);
    }
  }
};

template<typename SEGMENT,
         typename IndexMapper0,
         typename IndexMapper1,
         typename IndexMapper2>
struct TileTCountExecute<
    RAJA::policy::hip::hip_indexer<RAJA::iteration_mapping::Direct,
                                   kernel_sync_requirement::none,
                                   IndexMapper0,
                                   IndexMapper1,
                                   IndexMapper2>,
    SEGMENT>
{

  using diff_t = typename std::iterator_traits<
      typename SEGMENT::iterator>::difference_type;

  template<typename LaunchContextPolicy, typename TILE_T, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      TILE_T tile_size0,
      TILE_T tile_size1,
      TILE_T tile_size2,
      SEGMENT const& segment0,
      SEGMENT const& segment1,
      SEGMENT const& segment2,
      BODY const& body)
  {
    const diff_t len0 = segment0.end() - segment0.begin();
    const diff_t len1 = segment1.end() - segment1.begin();
    const diff_t len2 = segment2.end() - segment2.begin();

    const diff_t t0 =
        IndexMapper0::template index<diff_t>(ctx.get_indices_and_dims());
    const diff_t t1 =
        IndexMapper1::template index<diff_t>(ctx.get_indices_and_dims());
    const diff_t t2 =
        IndexMapper2::template index<diff_t>(ctx.get_indices_and_dims());

    const diff_t i0 = t0 * static_cast<diff_t>(tile_size0);
    const diff_t i1 = t1 * static_cast<diff_t>(tile_size1);
    const diff_t i2 = t2 * static_cast<diff_t>(tile_size2);

    if (i0 < len0 && i1 < len1 && i2 < len2)
    {
      body(segment0.slice(i0, static_cast<diff_t>(tile_size0)),
           segment1.slice(i1, static_cast<diff_t>(tile_size1)),
           segment2.slice(i2, static_cast<diff_t>(tile_size2)), t0, t1, t2);
    }
  }
};

template<typename SEGMENT, typename IndexMapper>
struct TileTCountExecute<
    RAJA::policy::hip::hip_indexer<
        RAJA::iteration_mapping::StridedLoop<named_usage::unspecified>,
        kernel_sync_requirement::none,
        IndexMapper>,
    SEGMENT>
{

  using diff_t = typename std::iterator_traits<
      typename SEGMENT::iterator>::difference_type;

  template<typename LaunchContextPolicy, typename TILE_T, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      TILE_T tile_size,
      SEGMENT const& segment,
      BODY const& body)
  {
    const diff_t len = segment.end() - segment.begin();
    const diff_t t_init =
        IndexMapper::template index<diff_t>(ctx.get_indices_and_dims());
    const diff_t i_init = t_init * static_cast<diff_t>(tile_size);
    const diff_t t_stride =
        IndexMapper::template size<diff_t>(ctx.get_indices_and_dims());
    const diff_t i_stride = t_stride * static_cast<diff_t>(tile_size);

    for (diff_t i = i_init, t = t_init; i < len; i += i_stride, t += t_stride)
    {
      body(segment.slice(i, static_cast<diff_t>(tile_size)), t);
    }
  }
};

template<typename SEGMENT, typename IndexMapper0, typename IndexMapper1>
struct TileTCountExecute<
    RAJA::policy::hip::hip_indexer<
        RAJA::iteration_mapping::StridedLoop<named_usage::unspecified>,
        kernel_sync_requirement::none,
        IndexMapper0,
        IndexMapper1>,
    SEGMENT>
{

  using diff_t = typename std::iterator_traits<
      typename SEGMENT::iterator>::difference_type;

  template<typename LaunchContextPolicy, typename TILE_T, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      TILE_T tile_size0,
      TILE_T tile_size1,
      SEGMENT const& segment0,
      SEGMENT const& segment1,
      BODY const& body)
  {
    const diff_t len0 = segment0.end() - segment0.begin();
    const diff_t len1 = segment1.end() - segment1.begin();

    const diff_t t0_init =
        IndexMapper0::template index<diff_t>(ctx.get_indices_and_dims());
    const diff_t t1_init =
        IndexMapper1::template index<diff_t>(ctx.get_indices_and_dims());

    const diff_t i0_init = t0_init * static_cast<diff_t>(tile_size0);
    const diff_t i1_init = t1_init * static_cast<diff_t>(tile_size1);

    const diff_t t0_stride =
        IndexMapper0::template size<diff_t>(ctx.get_indices_and_dims());
    const diff_t t1_stride =
        IndexMapper1::template size<diff_t>(ctx.get_indices_and_dims());

    const diff_t i0_stride = t0_stride * static_cast<diff_t>(tile_size0);
    const diff_t i1_stride = t1_stride * static_cast<diff_t>(tile_size1);

    for (diff_t i0 = i0_init, t0 = t0_init; i0 < len0;
         i0 += i0_stride, t0 += t0_stride)
    {
      for (diff_t i1 = i1_init, t1 = t1_init; i1 < len1;
           i1 += i1_stride, t1 += t1_stride)
      {
        body(segment0.slice(i0, static_cast<diff_t>(tile_size0)),
             segment1.slice(i1, static_cast<diff_t>(tile_size1)), t0, t1);
      }
    }
  }
};

template<typename SEGMENT,
         typename IndexMapper0,
         typename IndexMapper1,
         typename IndexMapper2>
struct TileTCountExecute<
    RAJA::policy::hip::hip_indexer<
        RAJA::iteration_mapping::StridedLoop<named_usage::unspecified>,
        kernel_sync_requirement::none,
        IndexMapper0,
        IndexMapper1,
        IndexMapper2>,
    SEGMENT>
{

  using diff_t = typename std::iterator_traits<
      typename SEGMENT::iterator>::difference_type;

  template<typename LaunchContextPolicy, typename TILE_T, typename BODY>
  static RAJA_INLINE RAJA_DEVICE void exec(
      LaunchContextT<LaunchContextPolicy> const& ctx,
      TILE_T tile_size0,
      TILE_T tile_size1,
      TILE_T tile_size2,
      SEGMENT const& segment0,
      SEGMENT const& segment1,
      SEGMENT const& segment2,
      BODY const& body)
  {
    const diff_t len0 = segment0.end() - segment0.begin();
    const diff_t len1 = segment1.end() - segment1.begin();
    const diff_t len2 = segment2.end() - segment2.begin();

    const diff_t t0_init =
        IndexMapper0::template index<diff_t>(ctx.get_indices_and_dims());
    const diff_t t1_init =
        IndexMapper1::template index<diff_t>(ctx.get_indices_and_dims());
    const diff_t t2_init =
        IndexMapper2::template index<diff_t>(ctx.get_indices_and_dims());

    const diff_t i0_init = t0_init * static_cast<diff_t>(tile_size0);
    const diff_t i1_init = t1_init * static_cast<diff_t>(tile_size1);
    const diff_t i2_init = t2_init * static_cast<diff_t>(tile_size2);

    const diff_t t0_stride =
        IndexMapper0::template size<diff_t>(ctx.get_indices_and_dims());
    const diff_t t1_stride =
        IndexMapper1::template size<diff_t>(ctx.get_indices_and_dims());
    const diff_t t2_stride =
        IndexMapper2::template size<diff_t>(ctx.get_indices_and_dims());

    const diff_t i0_stride = t0_stride * static_cast<diff_t>(tile_size0);
    const diff_t i1_stride = t1_stride * static_cast<diff_t>(tile_size1);
    const diff_t i2_stride = t2_stride * static_cast<diff_t>(tile_size2);

    for (diff_t i0 = i0_init, t0 = t0_init; i0 < len0;
         i0 += i0_stride, t0 += t0_stride)
    {
      for (diff_t i1 = i1_init, t1 = t1_init; i1 < len1;
           i1 += i1_stride, t1 += t1_stride)
      {
        for (diff_t i2 = i2_init, t2 = t2_init; i2 < len2;
             i2 += i2_stride, t2 += t2_stride)
        {
          body(segment0.slice(i0, static_cast<diff_t>(tile_size0)),
               segment1.slice(i1, static_cast<diff_t>(tile_size1)),
               segment2.slice(i2, static_cast<diff_t>(tile_size2)), t0, t1, t2);
        }
      }
    }
  }
};

}  // namespace RAJA
#endif
