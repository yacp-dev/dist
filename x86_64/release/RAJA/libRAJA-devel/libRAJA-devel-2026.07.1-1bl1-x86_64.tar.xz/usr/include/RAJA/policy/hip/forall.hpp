/*!
 ******************************************************************************
 *
 * \file
 *
 * \brief   Header file containing RAJA segment template methods for
 *          execution via HIP kernel launch.
 *
 *          These methods should work on any platform that supports
 *          HIP devices.
 *
 ******************************************************************************
 */

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
// Copyright (c) Lawrence Livermore National Security, LLC and other
// RAJA Project Developers. See top-level LICENSE and COPYRIGHT
// files for dates and other details. No copyright assignment is required
// to contribute to RAJA.
//
// SPDX-License-Identifier: (BSD-3-Clause)
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

#ifndef RAJA_forall_hip_HPP
#define RAJA_forall_hip_HPP

#include "RAJA/config.hpp"
#include "RAJA/pattern/concepts.hpp"

#if defined(RAJA_ENABLE_HIP)

#include <algorithm>
#include "hip/hip_runtime.h"

#include "RAJA/pattern/forall.hpp"

#include "RAJA/pattern/params/forall.hpp"

#include "RAJA/util/macros.hpp"
#include "RAJA/util/types.hpp"
#include "RAJA/util/Jit.hpp"

#include "RAJA/policy/hip/MemUtils_HIP.hpp"
#include "RAJA/policy/hip/policy.hpp"
#include "RAJA/policy/hip/raja_hiperrchk.hpp"

#include "RAJA/index/IndexSet.hpp"

#include "RAJA/util/resource.hpp"

namespace RAJA
{
namespace policy
{
namespace hip
{

namespace impl
{

/*!
 ******************************************************************************
 *
 * \brief  Hip kernel block and grid dimension calculator template.
 *
 * \tparam IterationMapping Way of mapping from threads in the kernel to
 *         iterates of the forall loop. For example StridedLoop uses a grid
 *         stride loop to run multiple iterates in a single thread.
 * \tparam IterationGetter Way of getting iteration indices from the underlying
 *         runtime using threadIdx, blockIdx, etc.
 * \tparam UniqueMarker Used in occupancy calculator methods to store and get
 *         data for this specific kernel.
 *
 ******************************************************************************
 */
template<typename IterationMapping,
         typename IterationGetter,
         typename Concretizer,
         typename UniqueMarker>
struct ForallDimensionCalculator;

// The general cases handle fixed BLOCK_SIZE > 0 and/or GRID_SIZE > 0
// there are specializations for named_usage::unspecified
// but named_usage::ignored is not supported so no specializations are provided
// and static_asserts in the general case catch unsupported values
template<named_dim dim,
         int BLOCK_SIZE,
         int GRID_SIZE,
         typename Concretizer,
         typename UniqueMarker>
struct ForallDimensionCalculator<
    ::RAJA::iteration_mapping::Direct,
    ::RAJA::hip::IndexGlobal<dim, BLOCK_SIZE, GRID_SIZE>,
    Concretizer,
    UniqueMarker>
{
  static_assert(
      BLOCK_SIZE > 0,
      "block size must be > 0 or named_usage::unspecified with forall");
  static_assert(
      GRID_SIZE > 0,
      "grid size must be > 0 or named_usage::unspecified with forall");

  using IndexGetter = ::RAJA::hip::IndexGlobal<dim, BLOCK_SIZE, GRID_SIZE>;

  template<typename IdxT>
  static void set_dimensions(internal::HipDims& dims,
                             IdxT len,
                             const void* RAJA_UNUSED_ARG(func),
                             size_t RAJA_UNUSED_ARG(dynamic_shmem_size))
  {
    const IdxT block_size = static_cast<IdxT>(IndexGetter::block_size);
    const IdxT grid_size  = static_cast<IdxT>(IndexGetter::grid_size);

    if (len > (block_size * grid_size))
    {
      RAJA_ABORT_OR_THROW(
          "len exceeds the size of the directly mapped index space");
    }

    internal::set_hip_dim<dim>(dims.threads,
                               static_cast<IdxT>(IndexGetter::block_size));
    internal::set_hip_dim<dim>(dims.blocks,
                               static_cast<IdxT>(IndexGetter::grid_size));
  }
};

template<named_dim dim,
         int GRID_SIZE,
         typename Concretizer,
         typename UniqueMarker>
struct ForallDimensionCalculator<
    ::RAJA::iteration_mapping::Direct,
    ::RAJA::hip::IndexGlobal<dim, named_usage::unspecified, GRID_SIZE>,
    Concretizer,
    UniqueMarker>
{
  static_assert(
      GRID_SIZE > 0,
      "grid size must be > 0 or named_usage::unspecified with forall");

  using IndexGetter =
      ::RAJA::hip::IndexGlobal<dim, named_usage::unspecified, GRID_SIZE>;

  template<typename IdxT>
  static void set_dimensions(internal::HipDims& dims,
                             IdxT len,
                             const void* func,
                             size_t dynamic_shmem_size)
  {
    ::RAJA::hip::ConcretizerImpl<IdxT, Concretizer, UniqueMarker> concretizer {
        func, dynamic_shmem_size, len};

    const IdxT grid_size  = static_cast<IdxT>(IndexGetter::grid_size);
    const IdxT block_size = concretizer.get_block_size_to_fit_len(grid_size);

    if (block_size == IdxT(0))
    {
      RAJA_ABORT_OR_THROW(
          "len exceeds the size of the directly mapped index space");
    }

    internal::set_hip_dim<dim>(dims.threads, block_size);
    internal::set_hip_dim<dim>(dims.blocks, grid_size);
  }
};

template<named_dim dim,
         int BLOCK_SIZE,
         typename Concretizer,
         typename UniqueMarker>
struct ForallDimensionCalculator<
    ::RAJA::iteration_mapping::Direct,
    ::RAJA::hip::IndexGlobal<dim, BLOCK_SIZE, named_usage::unspecified>,
    Concretizer,
    UniqueMarker>
{
  static_assert(
      BLOCK_SIZE > 0,
      "block size must be > 0 or named_usage::unspecified with forall");

  using IndexGetter =
      ::RAJA::hip::IndexGlobal<dim, BLOCK_SIZE, named_usage::unspecified>;

  template<typename IdxT>
  static void set_dimensions(internal::HipDims& dims,
                             IdxT len,
                             const void* func,
                             size_t dynamic_shmem_size)
  {
    ::RAJA::hip::ConcretizerImpl<IdxT, Concretizer, UniqueMarker> concretizer {
        func, dynamic_shmem_size, len};

    const IdxT block_size = static_cast<IdxT>(IndexGetter::block_size);
    const IdxT grid_size  = concretizer.get_grid_size_to_fit_len(block_size);

    internal::set_hip_dim<dim>(dims.threads, block_size);
    internal::set_hip_dim<dim>(dims.blocks, grid_size);
  }
};

template<named_dim dim, typename Concretizer, typename UniqueMarker>
struct ForallDimensionCalculator<
    ::RAJA::iteration_mapping::Direct,
    ::RAJA::hip::
        IndexGlobal<dim, named_usage::unspecified, named_usage::unspecified>,
    Concretizer,
    UniqueMarker>
{
  using IndexGetter = ::RAJA::hip::
      IndexGlobal<dim, named_usage::unspecified, named_usage::unspecified>;

  template<typename IdxT>
  static void set_dimensions(internal::HipDims& dims,
                             IdxT len,
                             const void* func,
                             size_t dynamic_shmem_size)
  {
    ::RAJA::hip::ConcretizerImpl<IdxT, Concretizer, UniqueMarker> concretizer {
        func, dynamic_shmem_size, len};

    const auto sizes = concretizer.get_block_and_grid_size_to_fit_len();

    internal::set_hip_dim<dim>(dims.threads, sizes.first);
    internal::set_hip_dim<dim>(dims.blocks, sizes.second);
  }
};

template<named_dim dim,
         int BLOCK_SIZE,
         int GRID_SIZE,
         typename Concretizer,
         typename UniqueMarker>
struct ForallDimensionCalculator<
    ::RAJA::iteration_mapping::StridedLoop<named_usage::unspecified>,
    ::RAJA::hip::IndexGlobal<dim, BLOCK_SIZE, GRID_SIZE>,
    Concretizer,
    UniqueMarker>
{
  static_assert(
      BLOCK_SIZE > 0,
      "block size must be > 0 or named_usage::unspecified with forall");
  static_assert(
      GRID_SIZE > 0,
      "grid size must be > 0 or named_usage::unspecified with forall");

  using IndexGetter = ::RAJA::hip::IndexGlobal<dim, BLOCK_SIZE, GRID_SIZE>;

  template<typename IdxT>
  static void set_dimensions(internal::HipDims& dims,
                             IdxT RAJA_UNUSED_ARG(len),
                             const void* RAJA_UNUSED_ARG(func),
                             size_t RAJA_UNUSED_ARG(dynamic_shmem_size))
  {
    const IdxT block_size = static_cast<IdxT>(IndexGetter::block_size);
    const IdxT grid_size  = static_cast<IdxT>(IndexGetter::grid_size);

    internal::set_hip_dim<dim>(dims.threads, block_size);
    internal::set_hip_dim<dim>(dims.blocks, grid_size);
  }
};

template<named_dim dim,
         int GRID_SIZE,
         typename Concretizer,
         typename UniqueMarker>
struct ForallDimensionCalculator<
    ::RAJA::iteration_mapping::StridedLoop<named_usage::unspecified>,
    ::RAJA::hip::IndexGlobal<dim, named_usage::unspecified, GRID_SIZE>,
    Concretizer,
    UniqueMarker>
{
  static_assert(
      GRID_SIZE > 0,
      "grid size must be > 0 or named_usage::unspecified with forall");

  using IndexGetter =
      ::RAJA::hip::IndexGlobal<dim, named_usage::unspecified, GRID_SIZE>;

  template<typename IdxT>
  static void set_dimensions(internal::HipDims& dims,
                             IdxT len,
                             const void* func,
                             size_t dynamic_shmem_size)
  {
    ::RAJA::hip::ConcretizerImpl<IdxT, Concretizer, UniqueMarker> concretizer {
        func, dynamic_shmem_size, len};

    const IdxT grid_size  = static_cast<IdxT>(IndexGetter::grid_size);
    const IdxT block_size = concretizer.get_block_size_to_fit_device(grid_size);

    internal::set_hip_dim<dim>(dims.threads, block_size);
    internal::set_hip_dim<dim>(dims.blocks, grid_size);
  }
};

template<named_dim dim,
         int BLOCK_SIZE,
         typename Concretizer,
         typename UniqueMarker>
struct ForallDimensionCalculator<
    ::RAJA::iteration_mapping::StridedLoop<named_usage::unspecified>,
    ::RAJA::hip::IndexGlobal<dim, BLOCK_SIZE, named_usage::unspecified>,
    Concretizer,
    UniqueMarker>
{
  static_assert(
      BLOCK_SIZE > 0,
      "block size must be > 0 or named_usage::unspecified with forall");

  using IndexGetter =
      ::RAJA::hip::IndexGlobal<dim, BLOCK_SIZE, named_usage::unspecified>;

  template<typename IdxT>
  static void set_dimensions(internal::HipDims& dims,
                             IdxT len,
                             const void* func,
                             size_t dynamic_shmem_size)
  {
    ::RAJA::hip::ConcretizerImpl<IdxT, Concretizer, UniqueMarker> concretizer {
        func, dynamic_shmem_size, len};

    const IdxT block_size = static_cast<IdxT>(IndexGetter::block_size);
    const IdxT grid_size  = concretizer.get_grid_size_to_fit_device(block_size);

    internal::set_hip_dim<dim>(dims.threads, block_size);
    internal::set_hip_dim<dim>(dims.blocks, grid_size);
  }
};

template<named_dim dim, typename Concretizer, typename UniqueMarker>
struct ForallDimensionCalculator<
    ::RAJA::iteration_mapping::StridedLoop<named_usage::unspecified>,
    ::RAJA::hip::
        IndexGlobal<dim, named_usage::unspecified, named_usage::unspecified>,
    Concretizer,
    UniqueMarker>
{
  using IndexGetter = ::RAJA::hip::
      IndexGlobal<dim, named_usage::unspecified, named_usage::unspecified>;

  template<typename IdxT>
  static void set_dimensions(internal::HipDims& dims,
                             IdxT len,
                             const void* func,
                             size_t dynamic_shmem_size)
  {
    ::RAJA::hip::ConcretizerImpl<IdxT, Concretizer, UniqueMarker> concretizer {
        func, dynamic_shmem_size, len};

    const auto sizes = concretizer.get_block_and_grid_size_to_fit_device();

    internal::set_hip_dim<dim>(dims.threads, sizes.first);
    internal::set_hip_dim<dim>(dims.blocks, sizes.second);
  }
};

//
//////////////////////////////////////////////////////////////////////
//
// HIP kernel templates.
//
//////////////////////////////////////////////////////////////////////
//

/*
 * __launch_bounds__ block size constraint does not change the
 * intended behavior because the requires > 0 constraint prevents the
 * overload from being selected for zero. It only ensures that NVCC or
 * Clang CUDA cannot encounter an invalid attribute argument of zero while
 * substituting or processing a discarded candidate.
 */

template<typename EXEC_POL,
         typename Iterator,
         typename LOOP_BODY,
         typename IndexType,
         typename ForallParam,
         typename IterationGetter = typename EXEC_POL::IterationGetter>
  requires concepts::DirectBasePolicy<EXEC_POL> &&
           (IterationGetter::block_size > 0)
__launch_bounds__(IterationGetter::block_size > 0 ? IterationGetter::block_size
                                                  : 1,
                  1) __global__
    RAJA_JIT_COMPILE_ARGS(3) void forallp_hip_kernel(const LOOP_BODY loop_body,
                                                     const Iterator idx,
                                                     const IndexType length,
                                                     ForallParam f_params)
{
  using RAJA::internal::thread_privatize;
  auto privatizer = thread_privatize(loop_body);
  auto& body      = privatizer.get_priv();
  auto ii         = IterationGetter::template index<IndexType>();

  if (ii < length)
  {
    RAJA::expt::invoke_body(f_params, body, idx[ii]);
  }

  RAJA::expt::ParamMultiplexer::parampack_combine(EXEC_POL {}, f_params);
}

template<typename EXEC_POL,
         typename Iterator,
         typename LOOP_BODY,
         typename IndexType,
         typename ForallParam,
         typename IterationGetter = typename EXEC_POL::IterationGetter>
  requires concepts::DirectBasePolicy<EXEC_POL> &&
           (IterationGetter::block_size <= 0)
__global__
    RAJA_JIT_COMPILE_ARGS(3) void forallp_hip_kernel(const LOOP_BODY loop_body,
                                                     const Iterator idx,
                                                     const IndexType length,
                                                     ForallParam f_params)
{
  using RAJA::internal::thread_privatize;
  auto privatizer = thread_privatize(loop_body);
  auto& body      = privatizer.get_priv();
  auto ii         = IterationGetter::template index<IndexType>();
  ;
  if (ii < length)
  {
    RAJA::expt::invoke_body(f_params, body, idx[ii]);
  }
  RAJA::expt::ParamMultiplexer::parampack_combine(EXEC_POL {}, f_params);
}

template<typename EXEC_POL,
         typename Iterator,
         typename LOOP_BODY,
         typename IndexType,
         typename ForallParam,
         typename IterationGetter = typename EXEC_POL::IterationGetter>
  requires concepts::StridedLoopPolicy<EXEC_POL> &&
           concepts::UnsizedLoopPolicy<EXEC_POL> &&
           (IterationGetter::block_size > 0)
__launch_bounds__(IterationGetter::block_size > 0 ? IterationGetter::block_size
                                                  : 1,
                  1) __global__
    RAJA_JIT_COMPILE_ARGS(3) void forallp_hip_kernel(const LOOP_BODY loop_body,
                                                     const Iterator idx,
                                                     const IndexType length,
                                                     ForallParam f_params)
{
  using RAJA::internal::thread_privatize;
  auto privatizer = thread_privatize(loop_body);
  auto& body      = privatizer.get_priv();

  for (auto ii = IterationGetter::template index<IndexType>(); ii < length;
       ii += IterationGetter::template size<IndexType>())
  {
    RAJA::expt::invoke_body(f_params, body, idx[ii]);
  }
  RAJA::expt::ParamMultiplexer::parampack_combine(EXEC_POL {}, f_params);
}

template<typename EXEC_POL,
         typename Iterator,
         typename LOOP_BODY,
         typename IndexType,
         typename ForallParam,
         typename IterationGetter = typename EXEC_POL::IterationGetter>
  requires concepts::StridedLoopPolicy<EXEC_POL> &&
           concepts::UnsizedLoopPolicy<EXEC_POL> &&
           (IterationGetter::block_size <= 0)
__global__
    RAJA_JIT_COMPILE_ARGS(3) void forallp_hip_kernel(const LOOP_BODY loop_body,
                                                     const Iterator idx,
                                                     const IndexType length,
                                                     ForallParam f_params)
{
  using RAJA::internal::thread_privatize;
  auto privatizer = thread_privatize(loop_body);
  auto& body      = privatizer.get_priv();

  for (auto ii = IterationGetter::template index<IndexType>(); ii < length;
       ii += IterationGetter::template size<IndexType>())
  {

    RAJA::expt::invoke_body(f_params, body, idx[ii]);
  }

  RAJA::expt::ParamMultiplexer::parampack_combine(EXEC_POL {}, f_params);
}

}  // namespace impl

//
////////////////////////////////////////////////////////////////////////
//
// Function templates for HIP execution over iterables.
//
////////////////////////////////////////////////////////////////////////
//


template<typename Iterable,
         typename LoopBody,
         typename IterationMapping,
         typename IterationGetter,
         typename Concretizer,
         bool Async,
         concepts::ForallParams ForallParam>
RAJA_INLINE resources::EventProxy<resources::Hip> forall_impl(
    resources::Hip hip_res,
    ::RAJA::policy::hip::
        hip_exec<IterationMapping, IterationGetter, Concretizer, Async> const&
            pol,
    Iterable&& iter,
    LoopBody&& loop_body,
    ForallParam f_params)
{
  using Iterator  = camp::decay<decltype(std::begin(iter))>;
  using LOOP_BODY = camp::decay<LoopBody>;
  using IndexType =
      camp::decay<decltype(std::distance(std::begin(iter), std::end(iter)))>;
  using EXEC_POL     = camp::decay<decltype(pol)>;
  using UniqueMarker = ::camp::list<IterationMapping, IterationGetter,
                                    LOOP_BODY, Iterator, ForallParam>;
  using DimensionCalculator =
      impl::ForallDimensionCalculator<IterationMapping, IterationGetter,
                                      Concretizer, UniqueMarker>;

  //
  // Compute the requested iteration space size
  //
  Iterator begin = std::begin(iter);
  Iterator end   = std::end(iter);
  IndexType len  = std::distance(begin, end);

  // Only launch kernel if we have something to iterate over
  if (len > 0)
  {
    auto func = reinterpret_cast<const void*>(
        &impl::forallp_hip_kernel<EXEC_POL, Iterator, LOOP_BODY, IndexType,
                                  camp::decay<ForallParam>>);

    //
    // Setup shared memory buffers
    //
    size_t shmem = 0;

    //
    // Compute the kernel dimensions
    //
    internal::HipDims dims(1);
    DimensionCalculator::set_dimensions(dims, len, func, shmem);


    RAJA::hip::detail::hipInfo launch_info;
    launch_info.gridDim  = dims.blocks;
    launch_info.blockDim = dims.threads;
    launch_info.res      = hip_res;

    {
      RAJA::expt::ParamMultiplexer::parampack_init(pol, f_params, launch_info);

      //
      // Privatize the loop_body, using make_launch_body to setup reductions
      //
      LOOP_BODY body = RAJA::hip::make_launch_body(
          func, dims.blocks, dims.threads, shmem, hip_res,
          std::forward<LoopBody>(loop_body));

      //
      // Launch the kernels
      //
      void* args[] = {(void*)&body, (void*)&begin, (void*)&len,
                      (void*)&f_params};
      RAJA::hip::launch(func, dims.blocks, dims.threads, args, shmem, hip_res,
                        Async);

      RAJA::expt::ParamMultiplexer::parampack_resolve(pol, f_params,
                                                      launch_info);
    }
  }

  return resources::EventProxy<resources::Hip>(hip_res);
}

//
//////////////////////////////////////////////////////////////////////
//
// The following function templates iterate over index set segments
// using the explicitly named segment iteration policy and execute
// segments as HIP kernels.
//
//////////////////////////////////////////////////////////////////////
//

/*!
 ******************************************************************************
 *
 * \brief  Sequential iteration over segments of index set and
 *         HIP execution for segments.
 *
 ******************************************************************************
 */
template<typename LoopBody,
         typename IterationMapping,
         typename IterationGetter,
         typename Concretizer,
         bool Async,
         typename... SegmentTypes>
RAJA_INLINE resources::EventProxy<resources::Hip> forall_impl(
    resources::Hip r,
    ExecPolicy<
        seq_segit,
        ::RAJA::policy::hip::
            hip_exec<IterationMapping, IterationGetter, Concretizer, Async>>,
    const TypedIndexSet<SegmentTypes...>& iset,
    LoopBody&& loop_body)
{
  int num_seg = iset.getNumSegments();
  for (int isi = 0; isi < num_seg; ++isi)
  {
    iset.segmentCall(
        r, isi, detail::CallForall(),
        ::RAJA::policy::hip::hip_exec<IterationMapping, IterationGetter,
                                      Concretizer, true>(),
        loop_body);
  }  // iterate over segments of index set

  if (!Async) RAJA::hip::synchronize(r);
  return resources::EventProxy<resources::Hip>(r);
}

}  // namespace hip

}  // namespace policy

}  // namespace RAJA

#endif  // closing endif for RAJA_ENABLE_HIP guard

#endif  // closing endif for header file include guard
