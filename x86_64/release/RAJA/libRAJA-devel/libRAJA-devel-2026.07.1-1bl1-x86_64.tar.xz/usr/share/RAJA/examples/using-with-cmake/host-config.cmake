###############################################################################
# Copyright (c) Lawrence Livermore National Security, LLC and other
# RAJA Project Developers. See top-level LICENSE and COPYRIGHT
# files for dates and other details. No copyright assignment is required
# to contribute to RAJA.
#
# SPDX-License-Identifier: (BSD-3-Clause)
###############################################################################

# Config related to compiler
set(CMAKE_C_COMPILER              "/usr/bin/gcc.exe"       CACHE PATH "")
set(CMAKE_CXX_COMPILER            "/usr/bin/g++.exe"     CACHE PATH "")
set(CMAKE_Fortran_COMPILER        "" CACHE PATH "")
set(CMAKE_CXX_STANDARD            "20"     CACHE STRING "")

set(CMAKE_C_FLAGS            " -Wall -Wextra  -ggdb -O2 -pipe -Wall -Werror=format-security -Wp,-D_FORTIFY_SOURCE=3 -fstack-protector-strong --param=ssp-buffer-size=4 -fdiagnostics-color -ffile-prefix-map=/cygdrive/d/a/dist/dist/yacp/RAJA/RAJA-2026.07.1-1bl1.x86_64/build=/usr/src/debug/RAJA-2026.07.1-1bl1 -ffile-prefix-map=/cygdrive/d/a/dist/dist/yacp/RAJA/RAJA-2026.07.1-1bl1.x86_64/src/RAJA=/usr/src/debug/RAJA-2026.07.1-1bl1  -D_GNU_SOURCE"          CACHE STRING "")
set(CMAKE_CXX_FLAGS          " -Wall -Wextra  -ggdb -O2 -pipe -Wall -Werror=format-security -Wp,-D_FORTIFY_SOURCE=3 -fstack-protector-strong --param=ssp-buffer-size=4 -fdiagnostics-color -Werror=return-type -ffile-prefix-map=/cygdrive/d/a/dist/dist/yacp/RAJA/RAJA-2026.07.1-1bl1.x86_64/build=/usr/src/debug/RAJA-2026.07.1-1bl1 -ffile-prefix-map=/cygdrive/d/a/dist/dist/yacp/RAJA/RAJA-2026.07.1-1bl1.x86_64/src/RAJA=/usr/src/debug/RAJA-2026.07.1-1bl1  -D_GNU_SOURCE"        CACHE STRING "")
set(CMAKE_Fortran_FLAGS      "-ggdb -O2 -pipe -Wall -Werror=format-security -Wp,-D_FORTIFY_SOURCE=3 -fstack-protector-strong --param=ssp-buffer-size=4 -fdiagnostics-color -ffile-prefix-map=/cygdrive/d/a/dist/dist/yacp/RAJA/RAJA-2026.07.1-1bl1.x86_64/build=/usr/src/debug/RAJA-2026.07.1-1bl1 -ffile-prefix-map=/cygdrive/d/a/dist/dist/yacp/RAJA/RAJA-2026.07.1-1bl1.x86_64/src/RAJA=/usr/src/debug/RAJA-2026.07.1-1bl1  -D_GNU_SOURCE"    CACHE STRING "")
set(CMAKE_EXE_LINKER_FLAGS   "" CACHE STRING "")

# CUDA
set(CMAKE_CUDA_COMPILER      ""       CACHE PATH "")
set(CMAKE_CUDA_HOST_COMPILER "/usr/bin/g++.exe"        CACHE PATH "")
set(CUDA_TOOLKIT_ROOT_DIR    ""          CACHE PATH "")
set(CMAKE_CUDA_ARCHITECTURES ""  CACHE STRING "")

# HIP
set(ROCM_PATH               ""               CACHE PATH "")
set(CMAKE_HIP_COMPILER      ""      CACHE PATH "")
set(CMAKE_HIP_ARCHITECTURES "gfx900" CACHE STRING "")
set(_raja_rocm_root "")
if(_raja_rocm_root MATCHES "/include/?$")
  get_filename_component(_raja_rocm_root "" DIRECTORY)
endif()
if(EXISTS "/lib/cmake/hip/hip-config.cmake")
  set(hip_DIR "/lib/cmake/hip" CACHE PATH "")
endif()
unset(_raja_rocm_root)

# MPI
set(ENABLE_MPI             OFF               CACHE BOOL "")
set(MPI_C_COMPILER         ""         CACHE PATH "")
set(MPI_CXX_COMPILER       ""       CACHE PATH "")
set(MPI_Fortran_COMPILER   ""   CACHE PATH "")
set(MPIEXEC_EXECUTABLE     ""     CACHE PATH "")
set(MPIEXEC_NUMPROC_FLAG   ""   CACHE STRING "")

set(RAJA_DIR        "/usr" CACHE PATH "")
