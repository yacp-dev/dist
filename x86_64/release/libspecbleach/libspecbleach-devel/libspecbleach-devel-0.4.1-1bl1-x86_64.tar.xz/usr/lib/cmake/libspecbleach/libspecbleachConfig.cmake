
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was libspecbleachConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

# Use original install prefix when loaded through a "/usr move"
# cross-prefix symbolic link such as /lib -> /usr/lib.
get_filename_component(_realCurr "${CMAKE_CURRENT_LIST_DIR}" REALPATH)
get_filename_component(_realOrig "/usr/lib/cmake/libspecbleach" REALPATH)
if(_realCurr STREQUAL _realOrig)
  set(PACKAGE_PREFIX_DIR "/usr")
endif()
unset(_realOrig)
unset(_realCurr)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

include(CMakeFindDependencyMacro)

# Public dependencies: libspecbleach has no public CMake dependencies.
# If any public dependencies are added in the future, find_dependency() calls go here.

include("${CMAKE_CURRENT_LIST_DIR}/libspecbleachTargets.cmake")

# Optional extras component: find_package(libspecbleach COMPONENTS extras)
if("extras" IN_LIST libspecbleach_FIND_COMPONENTS)
  if(EXISTS "${CMAKE_CURRENT_LIST_DIR}/libspecbleachExtrasTargets.cmake")
    include("${CMAKE_CURRENT_LIST_DIR}/libspecbleachExtrasTargets.cmake")
    set(libspecbleach_extras_FOUND TRUE)
  else()
    set(libspecbleach_extras_FOUND FALSE)
  endif()
endif()

check_required_components(libspecbleach)
