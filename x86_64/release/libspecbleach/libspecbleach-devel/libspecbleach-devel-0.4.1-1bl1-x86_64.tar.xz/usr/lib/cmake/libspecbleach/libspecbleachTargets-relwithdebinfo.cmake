#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "libspecbleach::libspecbleach" for configuration "RelWithDebInfo"
set_property(TARGET libspecbleach::libspecbleach APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(libspecbleach::libspecbleach PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libspecbleach.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygspecbleach-0.dll"
  )

list(APPEND _cmake_import_check_targets libspecbleach::libspecbleach )
list(APPEND _cmake_import_check_files_for_libspecbleach::libspecbleach "${_IMPORT_PREFIX}/lib/libspecbleach.dll.a" "${_IMPORT_PREFIX}/bin/cygspecbleach-0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
