#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "libspecbleach::libspecbleach_extras" for configuration "RelWithDebInfo"
set_property(TARGET libspecbleach::libspecbleach_extras APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(libspecbleach::libspecbleach_extras PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libspecbleach_extras.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygspecbleach_extras-0.dll"
  )

list(APPEND _cmake_import_check_targets libspecbleach::libspecbleach_extras )
list(APPEND _cmake_import_check_files_for_libspecbleach::libspecbleach_extras "${_IMPORT_PREFIX}/lib/libspecbleach_extras.dll.a" "${_IMPORT_PREFIX}/bin/cygspecbleach_extras-0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
