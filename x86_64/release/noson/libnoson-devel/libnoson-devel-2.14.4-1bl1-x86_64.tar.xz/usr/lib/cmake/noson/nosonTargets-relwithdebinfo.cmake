#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "noson" for configuration "RelWithDebInfo"
set_property(TARGET noson APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(noson PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "/usr/lib/libnoson.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "/usr/bin/cygnoson-2.dll"
  )

list(APPEND _cmake_import_check_targets noson )
list(APPEND _cmake_import_check_files_for_noson "/usr/lib/libnoson.dll.a" "/usr/bin/cygnoson-2.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
