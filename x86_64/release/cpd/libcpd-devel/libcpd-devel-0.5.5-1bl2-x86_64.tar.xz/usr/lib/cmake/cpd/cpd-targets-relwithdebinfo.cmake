#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Cpd::Library-C++" for configuration "RelWithDebInfo"
set_property(TARGET Cpd::Library-C++ APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(Cpd::Library-C++ PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libcpd.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygcpd-0.dll"
  )

list(APPEND _cmake_import_check_targets Cpd::Library-C++ )
list(APPEND _cmake_import_check_files_for_Cpd::Library-C++ "${_IMPORT_PREFIX}/lib/libcpd.dll.a" "${_IMPORT_PREFIX}/bin/cygcpd-0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
