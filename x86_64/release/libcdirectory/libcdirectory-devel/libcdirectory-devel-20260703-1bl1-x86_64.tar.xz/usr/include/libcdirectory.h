/*
 * Library to support cross-platform C directory functions
 *
 * Copyright (C) 2008-2026, Joachim Metz <joachim.metz@gmail.com>
 *
 * Refer to AUTHORS for acknowledgements.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#if !defined( _LIBCDIRECTORY_H )
#define _LIBCDIRECTORY_H

#include <libcdirectory/codepage.h>
#include <libcdirectory/definitions.h>
#include <libcdirectory/error.h>
#include <libcdirectory/extern.h>
#include <libcdirectory/features.h>
#include <libcdirectory/types.h>

#include <stdio.h>

#if defined( __cplusplus )
extern "C" {
#endif

/* -------------------------------------------------------------------------
 * Support functions
 * ------------------------------------------------------------------------- */

/* Returns the library version as a string
 */
LIBCDIRECTORY_EXTERN \
const char *libcdirectory_get_version(
             void );

/* Retrieves the narrow system string codepage
 * A value of 0 represents no codepage, UTF-8 encoding is used instead
 * Returns 1 if successful or -1 on error
 */
LIBCDIRECTORY_EXTERN \
int libcdirectory_get_codepage(
     int *codepage,
     libcdirectory_error_t **error );

/* Sets the narrow system string codepage
 * A value of 0 represents no codepage, UTF-8 encoding is used instead
 * Returns 1 if successful or -1 on error
 */
LIBCDIRECTORY_EXTERN \
int libcdirectory_set_codepage(
     int codepage,
     libcdirectory_error_t **error );

/* -------------------------------------------------------------------------
 * Error functions
 * ------------------------------------------------------------------------- */

/* Frees an error
 */
LIBCDIRECTORY_EXTERN \
void libcdirectory_error_free(
      libcdirectory_error_t **error );

/* Prints a descriptive string of the error to the stream
 * Returns the number of printed characters if successful or -1 on error
 */
LIBCDIRECTORY_EXTERN \
int libcdirectory_error_fprint(
     libcdirectory_error_t *error,
     FILE *stream );

/* Prints a descriptive string of the error to the string
 * Returns the number of printed characters if successful or -1 on error
 */
LIBCDIRECTORY_EXTERN \
int libcdirectory_error_sprint(
     libcdirectory_error_t *error,
     char *string,
     size_t size );

/* Prints a backtrace of the error to the stream
 * Returns the number of printed characters if successful or -1 on error
 */
LIBCDIRECTORY_EXTERN \
int libcdirectory_error_backtrace_fprint(
     libcdirectory_error_t *error,
     FILE *stream );

/* Prints a backtrace of the error to the string
 * Returns the number of printed characters if successful or -1 on error
 */
LIBCDIRECTORY_EXTERN \
int libcdirectory_error_backtrace_sprint(
     libcdirectory_error_t *error,
     char *string,
     size_t size );

/* -------------------------------------------------------------------------
 * Directory functions
 * ------------------------------------------------------------------------- */

/* Creates a directory
 * Make sure the value directory is referencing, is set to NULL
 * Returns 1 if successful or -1 on error
 */
LIBCDIRECTORY_EXTERN \
int libcdirectory_directory_initialize(
     libcdirectory_directory_t **directory,
     libcdirectory_error_t **error );

/* Frees a directory
 * Returns 1 if successful or -1 on error
 */
LIBCDIRECTORY_EXTERN \
int libcdirectory_directory_free(
     libcdirectory_directory_t **directory,
     libcdirectory_error_t **error );

/* Opens a directory
 * Returns 1 if successful or -1 on error
 */
LIBCDIRECTORY_EXTERN \
int libcdirectory_directory_open(
     libcdirectory_directory_t *directory,
     const char *directory_name,
     libcdirectory_error_t **error );

#if defined( LIBCDIRECTORY_HAVE_WIDE_CHARACTER_TYPE )

/* Opens a directory
 * Returns 1 if successful or -1 on error
 */
LIBCDIRECTORY_EXTERN \
int libcdirectory_directory_open_wide(
     libcdirectory_directory_t *directory,
     const wchar_t *directory_name,
     libcdirectory_error_t **error );

#endif /* defined( LIBCDIRECTORY_HAVE_WIDE_CHARACTER_TYPE ) */

/* Closes a directory
 * Returns 0 if successful or -1 on error
 */
LIBCDIRECTORY_EXTERN \
int libcdirectory_directory_close(
     libcdirectory_directory_t *directory,
     libcdirectory_error_t **error );

/* Reads a directory
 * Returns 1 if successful, 0 if no such entry or -1 on error
 */
LIBCDIRECTORY_EXTERN \
int libcdirectory_directory_read_entry(
     libcdirectory_directory_t *directory,
     libcdirectory_directory_entry_t *directory_entry,
     libcdirectory_error_t **error );

/* Determines if a directory has a specific entry
 * Returns 1 if the directory has the corresponding entry, 0 if not or -1 on error
 */
LIBCDIRECTORY_EXTERN \
int libcdirectory_directory_has_entry(
     libcdirectory_directory_t *directory,
     libcdirectory_directory_entry_t *directory_entry,
     const char *entry_name,
     size_t entry_name_length,
     uint8_t entry_type,
     uint8_t compare_flags,
     libcdirectory_error_t **error );

#if defined( LIBCDIRECTORY_HAVE_WIDE_CHARACTER_TYPE )

/* Determines if a directory has a specific entry
 * Returns 1 if the directory has the corresponding entry, 0 if not or -1 on error
 */
LIBCDIRECTORY_EXTERN \
int libcdirectory_directory_has_entry_wide(
     libcdirectory_directory_t *directory,
     libcdirectory_directory_entry_t *directory_entry,
     const wchar_t *entry_name,
     size_t entry_name_length,
     uint8_t entry_type,
     uint8_t compare_flags,
     libcdirectory_error_t **error );

#endif /* defined( LIBCDIRECTORY_HAVE_WIDE_CHARACTER_TYPE ) */

/* -------------------------------------------------------------------------
 * Directory entry functions
 * ------------------------------------------------------------------------- */

/* Creates a directory entry
 * Make sure the value directory_entry is referencing, is set to NULL
 * Returns 1 if successful or -1 on error
 */
LIBCDIRECTORY_EXTERN \
int libcdirectory_directory_entry_initialize(
     libcdirectory_directory_entry_t **directory_entry,
     libcdirectory_error_t **error );

/* Frees a directory entry
 * Returns 1 if successful or -1 on error
 */
LIBCDIRECTORY_EXTERN \
int libcdirectory_directory_entry_free(
     libcdirectory_directory_entry_t **directory_entry,
     libcdirectory_error_t **error );

/* Retrieves the directory entry type
 * Returns 1 if successful or -1 on error
 */
LIBCDIRECTORY_EXTERN \
int libcdirectory_directory_entry_get_type(
     libcdirectory_directory_entry_t *directory_entry,
     uint8_t *type,
     libcdirectory_error_t **error );

/* Retrieves the directory entry name
 * Returns 1 if successful or -1 on error
 */
LIBCDIRECTORY_EXTERN \
int libcdirectory_directory_entry_get_name(
     libcdirectory_directory_entry_t *directory_entry,
     char **name,
     libcdirectory_error_t **error );

#if defined( LIBCDIRECTORY_HAVE_WIDE_CHARACTER_TYPE )

/* Retrieves the directory entry name
 * Returns 1 if successful or -1 on error
 */
LIBCDIRECTORY_EXTERN \
int libcdirectory_directory_entry_get_name_wide(
     libcdirectory_directory_entry_t *directory_entry,
     wchar_t **name,
     libcdirectory_error_t **error );

#endif /* defined( LIBCDIRECTORY_HAVE_WIDE_CHARACTER_TYPE ) */

#if defined( __cplusplus )
}
#endif

#endif /* !defined( _LIBCDIRECTORY_H ) */

