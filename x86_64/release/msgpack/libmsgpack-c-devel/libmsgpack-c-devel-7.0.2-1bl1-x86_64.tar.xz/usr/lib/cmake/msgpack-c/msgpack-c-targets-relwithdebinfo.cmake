#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "msgpack-c" for configuration "RelWithDebInfo"
set_property(TARGET msgpack-c APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(msgpack-c PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libmsgpack-c.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygmsgpack-c-2.dll"
  )

list(APPEND _cmake_import_check_targets msgpack-c )
list(APPEND _cmake_import_check_files_for_msgpack-c "${_IMPORT_PREFIX}/lib/libmsgpack-c.dll.a" "${_IMPORT_PREFIX}/bin/cygmsgpack-c-2.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
