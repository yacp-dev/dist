#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "AWS::aws-lambda-runtime" for configuration "RelWithDebInfo"
set_property(TARGET AWS::aws-lambda-runtime APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(AWS::aws-lambda-runtime PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libaws-lambda-runtime.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygaws-lambda-runtime-0.dll"
  )

list(APPEND _cmake_import_check_targets AWS::aws-lambda-runtime )
list(APPEND _cmake_import_check_files_for_AWS::aws-lambda-runtime "${_IMPORT_PREFIX}/lib/libaws-lambda-runtime.dll.a" "${_IMPORT_PREFIX}/bin/cygaws-lambda-runtime-0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
