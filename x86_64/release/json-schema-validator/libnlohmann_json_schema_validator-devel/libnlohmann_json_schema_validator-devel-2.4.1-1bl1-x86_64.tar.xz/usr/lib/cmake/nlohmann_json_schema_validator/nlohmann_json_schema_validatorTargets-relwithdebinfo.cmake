#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "nlohmann_json_schema_validator::validator" for configuration "RelWithDebInfo"
set_property(TARGET nlohmann_json_schema_validator::validator APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(nlohmann_json_schema_validator::validator PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libnlohmann_json_schema_validator.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygnlohmann_json_schema_validator-2.dll"
  )

list(APPEND _cmake_import_check_targets nlohmann_json_schema_validator::validator )
list(APPEND _cmake_import_check_files_for_nlohmann_json_schema_validator::validator "${_IMPORT_PREFIX}/lib/libnlohmann_json_schema_validator.dll.a" "${_IMPORT_PREFIX}/bin/cygnlohmann_json_schema_validator-2.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
