#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "superlu::superlu" for configuration "RelWithDebInfo"
set_property(TARGET superlu::superlu APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(superlu::superlu PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libsuperlu.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygsuperlu-7.dll"
  )

list(APPEND _cmake_import_check_targets superlu::superlu )
list(APPEND _cmake_import_check_files_for_superlu::superlu "${_IMPORT_PREFIX}/lib/libsuperlu.dll.a" "${_IMPORT_PREFIX}/bin/cygsuperlu-7.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
