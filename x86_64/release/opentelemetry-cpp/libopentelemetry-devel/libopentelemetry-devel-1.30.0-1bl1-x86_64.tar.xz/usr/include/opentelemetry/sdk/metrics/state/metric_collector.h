// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0

#pragma once

#include <chrono>
#include <cstddef>
#include <memory>

#include "opentelemetry/nostd/function_ref.h"
#include "opentelemetry/sdk/metrics/cardinality_limits.h"
#include "opentelemetry/sdk/metrics/export/metric_filter.h"
#include "opentelemetry/sdk/metrics/export/metric_producer.h"
#include "opentelemetry/sdk/metrics/instruments.h"
#include "opentelemetry/sdk/metrics/metric_reader.h"
#include "opentelemetry/version.h"

OPENTELEMETRY_BEGIN_NAMESPACE
namespace sdk
{
namespace metrics
{

class MetricReader;
class MeterContext;

class CollectorHandle
{
public:
  CollectorHandle() = default;

  CollectorHandle(const CollectorHandle &)            = delete;
  CollectorHandle(CollectorHandle &&)                 = delete;
  CollectorHandle &operator=(const CollectorHandle &) = delete;
  CollectorHandle &operator=(CollectorHandle &&)      = delete;

  virtual ~CollectorHandle() = default;

  virtual AggregationTemporality GetAggregationTemporality(
      InstrumentType instrument_type) noexcept = 0;

  /**
   * Get the cardinality limit for a given instrument type.
   *
   * @param instrument_type The instrument type to get the limit for
   * @return The cardinality limit for the requested instrument type
   */
  virtual std::size_t GetCardinalityLimit(InstrumentType instrument_type) const noexcept = 0;
};

/**
 * An internal opaque interface that the MetricReader receives as
 * MetricProducer. It acts as the storage key to the internal metric stream
 * state for each MetricReader.
 */

class MetricCollector : public MetricProducer, public CollectorHandle
{
public:
  MetricCollector(MeterContext *context,
                  std::shared_ptr<MetricReader> metric_reader,
                  std::unique_ptr<MetricFilter> metric_filter = nullptr);

  MetricCollector(const MetricCollector &)            = delete;
  MetricCollector(MetricCollector &&)                 = delete;
  MetricCollector &operator=(const MetricCollector &) = delete;
  MetricCollector &operator=(MetricCollector &&)      = delete;

  ~MetricCollector() override = default;

  AggregationTemporality GetAggregationTemporality(
      InstrumentType instrument_type) noexcept override;

  std::size_t GetCardinalityLimit(InstrumentType instrument_type) const noexcept override;

  /**
   * The callback to be called for each metric exporter. This will only be those
   * metrics that have been produced since the last time this method was called.
   *
   * @return a status of completion of method.
   */
  Result Produce() noexcept override;

  bool ForceFlush(std::chrono::microseconds timeout = (std::chrono::microseconds::max)()) noexcept;

  bool Shutdown(std::chrono::microseconds timeout = (std::chrono::microseconds::max)()) noexcept;

private:
  MeterContext *meter_context_;
  std::shared_ptr<MetricReader> metric_reader_;
  std::unique_ptr<MetricFilter> metric_filter_;
};
}  // namespace metrics
}  // namespace sdk
OPENTELEMETRY_END_NAMESPACE
