#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "iniparser-shared" for configuration "RelWithDebInfo"
set_property(TARGET iniparser-shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(iniparser-shared PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libiniparser.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cyginiparser-4.dll"
  )

list(APPEND _cmake_import_check_targets iniparser-shared )
list(APPEND _cmake_import_check_files_for_iniparser-shared "${_IMPORT_PREFIX}/lib/libiniparser.dll.a" "${_IMPORT_PREFIX}/bin/cyginiparser-4.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
