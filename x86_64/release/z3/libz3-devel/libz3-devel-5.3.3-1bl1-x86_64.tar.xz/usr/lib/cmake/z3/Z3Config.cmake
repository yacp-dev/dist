################################################################################
# Automatically generated. DO NOT EDIT
#
# This file is intended to be consumed by clients who wish to use Z3 from CMake.
# It can be used by doing `find_package(Z3 config)` from within a
# `CMakeLists.txt` file. If CMake doesn't find this package automatically you
# can give it a prefix hint through the `Z3_ROOT` CMake variable or environment
# variable.
#
# This file was built for the install tree.
################################################################################



####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was Z3Config.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

# Use original install prefix when loaded through a "/usr move"
# cross-prefix symbolic link such as /lib -> /usr/lib.
get_filename_component(_realCurr "${CMAKE_CURRENT_LIST_DIR}" REALPATH)
get_filename_component(_realOrig "/usr/lib/cmake/z3" REALPATH)
if(_realCurr STREQUAL _realOrig)
  set(PACKAGE_PREFIX_DIR "/usr")
endif()
unset(_realOrig)
unset(_realCurr)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

set(_Z3_known_components static shared)
set(_Z3_find_static FALSE)
set(_Z3_find_shared FALSE)
foreach (_Z3_component IN LISTS ${CMAKE_FIND_PACKAGE_NAME}_FIND_COMPONENTS)
  if (_Z3_component IN_LIST _Z3_known_components)
    set(_Z3_find_${_Z3_component} TRUE)
  else()
    set(${CMAKE_FIND_PACKAGE_NAME}_NOT_FOUND_MESSAGE
      "Z3 does not recognize component `${_Z3_component}`.")
    set(${CMAKE_FIND_PACKAGE_NAME}_FOUND FALSE)
    return()
  endif()
endforeach()

if (_Z3_find_static AND _Z3_find_shared)
  set(${CMAKE_FIND_PACKAGE_NAME}_NOT_FOUND_MESSAGE
    "Z3 components `static` and `shared` are mutually exclusive.")
  set(${CMAKE_FIND_PACKAGE_NAME}_FOUND FALSE)
  return()
endif()

set(_Z3_static_targets "${CMAKE_CURRENT_LIST_DIR}/Z3-static-targets.cmake")
set(_Z3_shared_targets "${CMAKE_CURRENT_LIST_DIR}/Z3-shared-targets.cmake")

if (_Z3_find_static)
  set(_Z3_variant static)
elseif (_Z3_find_shared)
  set(_Z3_variant shared)
elseif (DEFINED Z3_SHARED_LIBS)
  if (Z3_SHARED_LIBS)
    set(_Z3_variant shared)
  else()
    set(_Z3_variant static)
  endif()
elseif (DEFINED BUILD_SHARED_LIBS)
  if (BUILD_SHARED_LIBS AND EXISTS "${_Z3_shared_targets}")
    set(_Z3_variant shared)
  elseif (NOT BUILD_SHARED_LIBS AND EXISTS "${_Z3_static_targets}")
    set(_Z3_variant static)
  elseif (EXISTS "${_Z3_shared_targets}")
    set(_Z3_variant shared)
  else()
    set(_Z3_variant static)
  endif()
elseif (EXISTS "${_Z3_shared_targets}")
  set(_Z3_variant shared)
else()
  set(_Z3_variant static)
endif()

set(_Z3_targets "${_Z3_${_Z3_variant}_targets}")
if (NOT EXISTS "${_Z3_targets}")
  set(${CMAKE_FIND_PACKAGE_NAME}_NOT_FOUND_MESSAGE
    "Z3 `${_Z3_variant}` libraries were requested but not found.")
  set(${CMAKE_FIND_PACKAGE_NAME}_FOUND FALSE)
  return()
endif()

if (TARGET z3::libz3)
  get_target_property(_Z3_loaded_type z3::libz3 TYPE)
  if (_Z3_variant STREQUAL "static")
    set(_Z3_requested_type STATIC_LIBRARY)
  else()
    set(_Z3_requested_type SHARED_LIBRARY)
  endif()
  if (NOT _Z3_loaded_type STREQUAL _Z3_requested_type)
    set(${CMAKE_FIND_PACKAGE_NAME}_NOT_FOUND_MESSAGE
      "Z3 `${_Z3_variant}` libraries were requested, but z3::libz3 was already loaded as a ${_Z3_loaded_type} target.")
    set(${CMAKE_FIND_PACKAGE_NAME}_FOUND FALSE)
    return()
  endif()
endif()

if (_Z3_variant STREQUAL "static")
  include("${CMAKE_CURRENT_LIST_DIR}/Z3-static-dependencies.cmake")
  if (DEFINED ${CMAKE_FIND_PACKAGE_NAME}_FOUND
      AND NOT ${CMAKE_FIND_PACKAGE_NAME}_FOUND)
    return()
  endif()
  set(Z3_SHARED_LIBS FALSE)
else()
  set(Z3_SHARED_LIBS TRUE)
endif()
include("${_Z3_targets}")

# Version information
set(Z3_VERSION_MAJOR 5)
set(Z3_VERSION_MINOR 3)
set(Z3_VERSION_PATCH 3)
set(Z3_VERSION_TWEAK 0)
set(Z3_VERSION_STRING "${Z3_VERSION_MAJOR}.${Z3_VERSION_MINOR}.${Z3_VERSION_PATCH}.${Z3_VERSION_TWEAK}")

# NOTE: We can't use `set_and_check()` here because this a list of paths.
# List of include directories
set(Z3_C_INCLUDE_DIRS ${PACKAGE_PREFIX_DIR}/include )
set(Z3_CXX_INCLUDE_DIRS  ${Z3_C_INCLUDE_DIRS})
# List of libraries to link against
set(Z3_LIBRARIES "z3::libz3")
