// automatically generated file.
#define Z3_MAJOR_VERSION   5
#define Z3_MINOR_VERSION   3
#define Z3_BUILD_NUMBER    3
#define Z3_REVISION_NUMBER 0

#define Z3_FULL_VERSION    "5.3.3.0"
/* #undef Z3GITHASH */
