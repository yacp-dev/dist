
#ifndef NETWORKIT_GRAPH_BFS_HPP_
#define NETWORKIT_GRAPH_BFS_HPP_

#include <array>
#include <cstddef>
#include <queue>
#include <stdexcept>
#include <vector>

#include <networkit/Globals.hpp>
#include <networkit/graph/Graph.hpp>
#include <networkit/graph/TraversalImpl.hpp>

namespace NetworKit {

namespace Traversal {

namespace Impl {

/**
 * Calls the given BFS handle with distance parameter
 */
template <class F, class NodeT>
auto callBFSHandle(F &f, NodeT u, count dist) -> decltype(f(u, dist)) {
    return f(u, dist);
}

/**
 * Calls the given BFS handle without distance parameter
 */
template <class F, class NodeT>
auto callBFSHandle(F &f, NodeT u, count) -> decltype(f(u)) {
    return f(u);
}

} // namespace Impl

/**
 * Iterate over nodes in breadth-first search order starting from the unique nodes within the
 * given range. All start nodes are visited at distance 0. Duplicate start nodes are ignored.
 *
 * @param G The input graph.
 * @param first The first element of the start node range.
 * @param last The end of the start node range.
 * @param handle Takes a node, or a node and its distance from the nearest start node.
 * @throws std::runtime_error If a start node is not in the graph.
 */
template <class InputIt, typename L, class GraphT>
void BFSfrom(const GraphT &G, InputIt first, InputIt last, L handle) {
    using NodeT = typename GraphT::NodeT;

    std::vector<Visit> marked(static_cast<std::size_t>(G.upperNodeIdBound()), Visit::Unvisited);
    std::queue<NodeT> q, qNext;
    count dist = 0;
    // enqueue start nodes, do not enqueue duplicates
    for (; first != last; ++first) {
        if (!Impl::isValidNode(G, *first))
            throw std::runtime_error("Error: source node not in the graph.");
        const std::size_t uIndex = Impl::nodeIndex(*first);
        if (marked[uIndex] == Visit::Unvisited) {
            q.push(*first);
            marked[uIndex] = Visit::Visited;
        }
    }
    while (!q.empty()) {
        const auto u = q.front();
        q.pop();
        // apply function
        Impl::callBFSHandle(handle, u, dist);
        G.forNeighborsOf(u, [&](NodeT v) {
            const std::size_t vIndex = Impl::nodeIndex(v);
            if (marked[vIndex] == Visit::Unvisited) {
                qNext.push(v);
                marked[vIndex] = Visit::Visited;
            }
        });
        if (q.empty() && !qNext.empty()) {
            q.swap(qNext);
            ++dist;
        }
    }
}

/**
 * Iterate over nodes in breadth-first search order starting from the given source node.
 *
 * @param G The input graph.
 * @param source The source node.
 * @param handle Takes a node as input parameter.
 * @throws std::runtime_error If the source node is not in the graph.
 */
template <typename L, class GraphT>
void BFSfrom(const GraphT &G, typename GraphT::NodeT source, L handle) {
    using NodeT = typename GraphT::NodeT;

    std::array<NodeT, 1> startNodes{{source}};
    BFSfrom(G, startNodes.begin(), startNodes.end(), handle);
}

/**
 * Iterate over edges in breadth-first search order starting from the given source node.
 *
 * @param G The input graph.
 * @param source The source node.
 * @param handle Takes a node as input parameter.
 * @throws std::runtime_error If the source node is not in the graph.
 */
template <typename L, class GraphT>
void BFSEdgesFrom(const GraphT &G, typename GraphT::NodeT source, L handle) {
    using NodeT = typename GraphT::NodeT;
    using EdgeWeightT = typename GraphT::EdgeWeightT;

    std::vector<Visit> marked(static_cast<std::size_t>(G.upperNodeIdBound()), Visit::Unvisited);
    std::queue<NodeT> q;
    if (!Impl::isValidNode(G, source))
        throw std::runtime_error("Error: source node not in the graph.");
    q.push(source); // enqueue root
    marked[Impl::nodeIndex(source)] = Visit::Visited;
    do {
        const auto u = q.front();
        q.pop();
        // apply function
        G.forNeighborsOf(u, [&](NodeT, NodeT v, EdgeWeightT w, edgeid eid) {
            const std::size_t vIndex = Impl::nodeIndex(v);
            if (marked[vIndex] == Visit::Unvisited) {
                handle(u, v, w, eid);
                q.push(v);
                marked[vIndex] = Visit::Visited;
            }
        });
    } while (!q.empty());
}

} // namespace Traversal

} // namespace NetworKit

#endif // NETWORKIT_GRAPH_BFS_HPP_
