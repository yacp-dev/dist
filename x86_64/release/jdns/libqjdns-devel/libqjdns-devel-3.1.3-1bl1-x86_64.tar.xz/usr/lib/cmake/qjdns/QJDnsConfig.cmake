
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was QJDns-qtConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

# Use original install prefix when loaded through a "/usr move"
# cross-prefix symbolic link such as /lib -> /usr/lib.
get_filename_component(_realCurr "${CMAKE_CURRENT_LIST_DIR}" REALPATH)
get_filename_component(_realOrig "/usr/lib/cmake/qjdns" REALPATH)
if(_realCurr STREQUAL _realOrig)
  set(PACKAGE_PREFIX_DIR "/usr")
endif()
unset(_realOrig)
unset(_realCurr)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

set(QJDns_QT_MAJOR_VERSION 5)
if((DEFINED QT_DEFAULT_MAJOR_VERSION AND NOT QT_DEFAULT_MAJOR_VERSION EQUAL QJDns_QT_MAJOR_VERSION)
   OR (TARGET Qt5::Core AND NOT TARGET Qt6::Core AND NOT QJDns_QT_MAJOR_VERSION EQUAL 5)
   OR (TARGET Qt6::Core AND NOT TARGET Qt5::Core AND NOT QJDns_QT_MAJOR_VERSION EQUAL 6))
    set(QJDns_FOUND FALSE)
    set(QJDns-qt5_FOUND FALSE)
    set(QJDns_NOT_FOUND_MESSAGE "QJDns was built for a different Qt major version")
    return()
endif()

include(CMakeFindDependencyMacro)
find_dependency(JDns "3.1.3")
find_dependency(Qt5 REQUIRED COMPONENTS Core Network)

if(NOT TARGET qjdns)
    include("${CMAKE_CURRENT_LIST_DIR}/QJDnsTargets.cmake")
endif()

if(TARGET qjdns AND NOT TARGET QJDns::QJDns)
    add_library(QJDns::QJDns ALIAS qjdns)
endif()

set(QJDns_LIBRARY qjdns)
set(QJDns_VERSION "3.1.3")
