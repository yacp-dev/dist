#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "qjdns" for configuration "RelWithDebInfo"
set_property(TARGET qjdns APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(qjdns PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "/usr/lib/libqjdns.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "/usr/bin/cygqjdns-3.dll"
  )

list(APPEND _cmake_import_check_targets qjdns )
list(APPEND _cmake_import_check_files_for_qjdns "/usr/lib/libqjdns.dll.a" "/usr/bin/cygqjdns-3.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
