#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "jdns" for configuration "RelWithDebInfo"
set_property(TARGET jdns APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(jdns PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "/usr/lib/libjdns.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "/usr/bin/cygjdns-3.dll"
  )

list(APPEND _cmake_import_check_targets jdns )
list(APPEND _cmake_import_check_files_for_jdns "/usr/lib/libjdns.dll.a" "/usr/bin/cygjdns-3.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
