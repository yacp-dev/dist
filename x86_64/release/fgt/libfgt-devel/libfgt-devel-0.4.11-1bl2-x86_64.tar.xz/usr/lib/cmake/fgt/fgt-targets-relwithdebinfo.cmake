#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Fgt::Library-C++" for configuration "RelWithDebInfo"
set_property(TARGET Fgt::Library-C++ APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(Fgt::Library-C++ PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libfgt.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygfgt-0.dll"
  )

list(APPEND _cmake_import_check_targets Fgt::Library-C++ )
list(APPEND _cmake_import_check_files_for_Fgt::Library-C++ "${_IMPORT_PREFIX}/lib/libfgt.dll.a" "${_IMPORT_PREFIX}/bin/cygfgt-0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
