#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "h3::h3_bin" for configuration "RelWithDebInfo"
set_property(TARGET h3::h3_bin APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(h3::h3_bin PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/h3.exe"
  )

list(APPEND _cmake_import_check_targets h3::h3_bin )
list(APPEND _cmake_import_check_files_for_h3::h3_bin "${_IMPORT_PREFIX}/bin/h3.exe" )

# Import target "h3::latLngToCell" for configuration "RelWithDebInfo"
set_property(TARGET h3::latLngToCell APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(h3::latLngToCell PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/latLngToCell.exe"
  )

list(APPEND _cmake_import_check_targets h3::latLngToCell )
list(APPEND _cmake_import_check_files_for_h3::latLngToCell "${_IMPORT_PREFIX}/bin/latLngToCell.exe" )

# Import target "h3::h3ToComponents" for configuration "RelWithDebInfo"
set_property(TARGET h3::h3ToComponents APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(h3::h3ToComponents PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/h3ToComponents.exe"
  )

list(APPEND _cmake_import_check_targets h3::h3ToComponents )
list(APPEND _cmake_import_check_files_for_h3::h3ToComponents "${_IMPORT_PREFIX}/bin/h3ToComponents.exe" )

# Import target "h3::cellToLatLng" for configuration "RelWithDebInfo"
set_property(TARGET h3::cellToLatLng APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(h3::cellToLatLng PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cellToLatLng.exe"
  )

list(APPEND _cmake_import_check_targets h3::cellToLatLng )
list(APPEND _cmake_import_check_files_for_h3::cellToLatLng "${_IMPORT_PREFIX}/bin/cellToLatLng.exe" )

# Import target "h3::cellToLocalIj" for configuration "RelWithDebInfo"
set_property(TARGET h3::cellToLocalIj APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(h3::cellToLocalIj PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cellToLocalIj.exe"
  )

list(APPEND _cmake_import_check_targets h3::cellToLocalIj )
list(APPEND _cmake_import_check_files_for_h3::cellToLocalIj "${_IMPORT_PREFIX}/bin/cellToLocalIj.exe" )

# Import target "h3::localIjToCell" for configuration "RelWithDebInfo"
set_property(TARGET h3::localIjToCell APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(h3::localIjToCell PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/localIjToCell.exe"
  )

list(APPEND _cmake_import_check_targets h3::localIjToCell )
list(APPEND _cmake_import_check_files_for_h3::localIjToCell "${_IMPORT_PREFIX}/bin/localIjToCell.exe" )

# Import target "h3::cellToBoundary" for configuration "RelWithDebInfo"
set_property(TARGET h3::cellToBoundary APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(h3::cellToBoundary PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cellToBoundary.exe"
  )

list(APPEND _cmake_import_check_targets h3::cellToBoundary )
list(APPEND _cmake_import_check_files_for_h3::cellToBoundary "${_IMPORT_PREFIX}/bin/cellToBoundary.exe" )

# Import target "h3::gridDiskUnsafe" for configuration "RelWithDebInfo"
set_property(TARGET h3::gridDiskUnsafe APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(h3::gridDiskUnsafe PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/gridDiskUnsafe.exe"
  )

list(APPEND _cmake_import_check_targets h3::gridDiskUnsafe )
list(APPEND _cmake_import_check_files_for_h3::gridDiskUnsafe "${_IMPORT_PREFIX}/bin/gridDiskUnsafe.exe" )

# Import target "h3::gridDisk" for configuration "RelWithDebInfo"
set_property(TARGET h3::gridDisk APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(h3::gridDisk PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/gridDisk.exe"
  )

list(APPEND _cmake_import_check_targets h3::gridDisk )
list(APPEND _cmake_import_check_files_for_h3::gridDisk "${_IMPORT_PREFIX}/bin/gridDisk.exe" )

# Import target "h3::cellToBoundaryHier" for configuration "RelWithDebInfo"
set_property(TARGET h3::cellToBoundaryHier APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(h3::cellToBoundaryHier PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cellToBoundaryHier.exe"
  )

list(APPEND _cmake_import_check_targets h3::cellToBoundaryHier )
list(APPEND _cmake_import_check_files_for_h3::cellToBoundaryHier "${_IMPORT_PREFIX}/bin/cellToBoundaryHier.exe" )

# Import target "h3::cellToLatLngHier" for configuration "RelWithDebInfo"
set_property(TARGET h3::cellToLatLngHier APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(h3::cellToLatLngHier PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cellToLatLngHier.exe"
  )

list(APPEND _cmake_import_check_targets h3::cellToLatLngHier )
list(APPEND _cmake_import_check_files_for_h3::cellToLatLngHier "${_IMPORT_PREFIX}/bin/cellToLatLngHier.exe" )

# Import target "h3::h3ToHier" for configuration "RelWithDebInfo"
set_property(TARGET h3::h3ToHier APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(h3::h3ToHier PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/h3ToHier.exe"
  )

list(APPEND _cmake_import_check_targets h3::h3ToHier )
list(APPEND _cmake_import_check_files_for_h3::h3ToHier "${_IMPORT_PREFIX}/bin/h3ToHier.exe" )

# Import target "h3::h3" for configuration "RelWithDebInfo"
set_property(TARGET h3::h3 APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(h3::h3 PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libh3.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygh3-1.dll"
  )

list(APPEND _cmake_import_check_targets h3::h3 )
list(APPEND _cmake_import_check_files_for_h3::h3 "${_IMPORT_PREFIX}/lib/libh3.dll.a" "${_IMPORT_PREFIX}/bin/cygh3-1.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
