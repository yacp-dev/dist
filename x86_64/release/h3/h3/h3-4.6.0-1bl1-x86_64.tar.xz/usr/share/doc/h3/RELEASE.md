# Release Process

1. Create a PR "Preparing for release X.Y.Z" against master branch
    * Alter CHANGELOG.md from `[Unreleased]` to `[X.Y.Z] YYYY-MM-DD`
    * In the `build` directory, run `make update-version` and give `X.Y.Z` when
      prompted (this updates the VERSION file, so don't change it manually)
    * Check that all merges that need to be in the changelog are present
    * Get reviews and merge the PR

2. Create a release "Release X.Y.Z" on Github
    * Create Tag `vX.Y.Z`
    * Copy CHANGELOG.md into the release notes

3. Publish the website to display the latest docs
    * This should now be done automatically via Github Actions.
