#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "ambit::ambit" for configuration "RelWithDebInfo"
set_property(TARGET ambit::ambit APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(ambit::ambit PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libambit.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygambit-0.dll"
  )

list(APPEND _cmake_import_check_targets ambit::ambit )
list(APPEND _cmake_import_check_files_for_ambit::ambit "${_IMPORT_PREFIX}/lib/libambit.dll.a" "${_IMPORT_PREFIX}/bin/cygambit-0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
