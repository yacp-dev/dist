#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "suzume::suzume_shared" for configuration "RelWithDebInfo"
set_property(TARGET suzume::suzume_shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(suzume::suzume_shared PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libsuzume.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygsuzume-0.dll"
  )

list(APPEND _cmake_import_check_targets suzume::suzume_shared )
list(APPEND _cmake_import_check_files_for_suzume::suzume_shared "${_IMPORT_PREFIX}/lib/libsuzume.dll.a" "${_IMPORT_PREFIX}/bin/cygsuzume-0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
