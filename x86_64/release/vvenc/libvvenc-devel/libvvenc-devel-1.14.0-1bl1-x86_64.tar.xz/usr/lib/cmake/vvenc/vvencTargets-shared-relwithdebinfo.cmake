#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "vvenc::vvenc" for configuration "RelWithDebInfo"
set_property(TARGET vvenc::vvenc APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(vvenc::vvenc PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libvvenc.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygvvenc-1.14.dll"
  )

list(APPEND _cmake_import_check_targets vvenc::vvenc )
list(APPEND _cmake_import_check_files_for_vvenc::vvenc "${_IMPORT_PREFIX}/lib/libvvenc.dll.a" "${_IMPORT_PREFIX}/bin/cygvvenc-1.14.dll" )

# Import target "vvenc::vvencapp" for configuration "RelWithDebInfo"
set_property(TARGET vvenc::vvencapp APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(vvenc::vvencapp PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/vvencapp.exe"
  )

list(APPEND _cmake_import_check_targets vvenc::vvencapp )
list(APPEND _cmake_import_check_files_for_vvenc::vvencapp "${_IMPORT_PREFIX}/bin/vvencapp.exe" )

# Import target "vvenc::vvencFFapp" for configuration "RelWithDebInfo"
set_property(TARGET vvenc::vvencFFapp APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(vvenc::vvencFFapp PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/vvencFFapp.exe"
  )

list(APPEND _cmake_import_check_targets vvenc::vvencFFapp )
list(APPEND _cmake_import_check_files_for_vvenc::vvencFFapp "${_IMPORT_PREFIX}/bin/vvencFFapp.exe" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
