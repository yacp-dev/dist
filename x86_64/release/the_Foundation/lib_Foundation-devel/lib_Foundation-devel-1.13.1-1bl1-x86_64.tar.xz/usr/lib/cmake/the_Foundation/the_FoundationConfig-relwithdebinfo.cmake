#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "the_Foundation::the_Foundation" for configuration "RelWithDebInfo"
set_property(TARGET the_Foundation::the_Foundation APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(the_Foundation::the_Foundation PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/lib_Foundation.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cyg_Foundation-1.dll"
  )

list(APPEND _cmake_import_check_targets the_Foundation::the_Foundation )
list(APPEND _cmake_import_check_files_for_the_Foundation::the_Foundation "${_IMPORT_PREFIX}/lib/lib_Foundation.dll.a" "${_IMPORT_PREFIX}/bin/cyg_Foundation-1.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
