#pragma once

/** @file the_Foundation/networkproxy.h  Network proxy configuration.

@authors Copyright (c) 2026 Jaakko Keränen <jaakko.keranen@iki.fi>

@par License

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

<small>THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</small>
*/

#include "string.h"

iBeginPublic

iDeclareType(NetworkProxy)
iDeclareTypeConstructionArgs(NetworkProxy, const iString *host, uint16_t port)

/**
 * Sets optional authentication credentials for the SOCKS v5 proxy.
 */
void  setCredentials_NetworkProxy   (iNetworkProxy *, const iString *username, const iString *password);

/**
 * Installs a network proxy globally. Takes ownership of the proxy object; any
 * existing proxy is deleted first. Pass NULL to uninstall the current proxy.
 *
 * When a proxy is installed, address lookups performed via the Address class are
 * deferred: instead of DNS resolution, the proxy will resolve the hostname during
 * the SOCKS v5 handshake when the socket connects.
 *
 * This function is thread-safe.
 */
void  use_NetworkProxy  (iNetworkProxy *);

iEndPublic
