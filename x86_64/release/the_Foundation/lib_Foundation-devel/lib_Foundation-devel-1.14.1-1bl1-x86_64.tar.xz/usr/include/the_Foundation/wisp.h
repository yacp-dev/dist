#pragma once

/** @file the_Foundation/wisp.h  Wisp relay configuration (WebAssembly).

In web builds, browsers do not allow opening TCP connections. All Socket connections
are made through a relay server using the Wisp protocol (version 2) over a WebSocket.

@authors Copyright (c) 2026 Jaakko Keränen <jaakko.keranen@iki.fi>

@par License

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

<small>THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</small>
*/

#include "block.h"

iBeginPublic

/**
 * Sets the WebSocket URL of the Wisp relay, e.g., "wss://example.com/wisp/". The
 * default is "/wisp/" on the host that served the page. An open relay connection is
 * closed if the URL changes.
 *
 * This function is thread-safe.
 */
void    setUrl_Wisp     (const char *url);

/**
 * Sets the credentials used when the relay requires authentication. The key and the
 * password are both offered if the relay allows them. An open relay connection is
 * closed if the credentials change.
 *
 * This function is thread-safe.
 *
 * @param user        Username (may be NULL).
 * @param password    Password (may be NULL).
 * @param privateKey  Raw 32-byte Ed25519 private key (may be NULL).
 */
void    setCredentials_Wisp (const char *user, const char *password, const iBlock *privateKey);

/**
 * Generates a new Ed25519 private key for relay authentication.
 *
 * @return Raw 32-byte private key. Caller gets ownership.
 */
iBlock *newPrivateKey_Wisp  (void);

/**
 * Returns the raw 32-byte Ed25519 public key of a private key. The relay identifies
 * clients by the public key. Caller gets ownership. Returns NULL if the key is invalid.
 */
iBlock *newPublicKey_Wisp   (const iBlock *privateKey);

iEndPublic
