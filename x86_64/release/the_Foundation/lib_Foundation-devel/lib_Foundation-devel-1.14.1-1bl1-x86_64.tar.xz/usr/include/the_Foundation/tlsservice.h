#pragma once

/** @file the_Foundation/tlsservice.h  TLS server for accepting incoming connections.

@authors Copyright (c) 2026 Jaakko Keränen <jaakko.keranen@iki.fi>

@par License

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

<small>THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</small>
*/

#include "address.h"
#include "audience.h"
#include "tlsrequest.h"

iBeginPublic

/* An incoming connection. Notifications are sent in the connection's own thread. */
iDeclareClass(TlsConnection)

iDeclareNotifyFunc(TlsConnection, ReadyRead)
iDeclareNotifyFunc(TlsConnection, Disconnected)
iDeclareAudienceGetter(TlsConnection, readyRead)
iDeclareAudienceGetter(TlsConnection, disconnected)

const iAddress *        address_TlsConnection           (const iTlsConnection *);
const iTlsCertificate * clientCertificate_TlsConnection (const iTlsConnection *); /* NULL if none */
iBool                   isOpen_TlsConnection            (const iTlsConnection *);
size_t                  receivedBytes_TlsConnection     (const iTlsConnection *);
iBlock *                readAll_TlsConnection           (iTlsConnection *);
void                    writeData_TlsConnection         (iTlsConnection *, const void *data, size_t size);
void                    close_TlsConnection             (iTlsConnection *); /* after sending everything */
void                    setDeadline_TlsConnection       (iTlsConnection *, double seconds); /* from now; zero: none */

iLocalDef void write_TlsConnection(iTlsConnection *d, const iBlock *data) {
    writeData_TlsConnection(d, constData_Block(data), size_Block(data));
}

/*----------------------------------------------------------------------------------------------*/

enum iTlsProtocolVersion {
    tls1_2_TlsProtocolVersion,
    tls1_3_TlsProtocolVersion,
};

/* Listens on a port and performs TLS handshakes with incoming connections. Clients may
   present certificates, which are accepted without verification. Handshakes must complete
   within 10 seconds. */
iDeclareClass(TlsService)
iDeclareObjectConstructionArgs(TlsService, uint16_t port)

/* Sent after a successful handshake, in the connection's thread. */
iDeclareNotifyFuncArgs(TlsService, Accepted, iTlsConnection *connection)
iDeclareAudienceGetter(TlsService, accepted)

iBool   setCertificate_TlsService   (iTlsService *, const iTlsCertificate *cert); /* needs private key */
void    setMaxConnections_TlsService(iTlsService *, size_t maxConnections); /* zero: no limit */
void    setMaxConnectionsPerAddress_TlsService(iTlsService *, size_t maxConnections); /* zero: no limit */
iBool   setMinProtocolVersion_TlsService(iTlsService *, enum iTlsProtocolVersion); /* default: TLS 1.2 */
iBool   open_TlsService             (iTlsService *);
void    close_TlsService            (iTlsService *);
iBool   isOpen_TlsService           (const iTlsService *);

iEndPublic
