#pragma once

/** @file the_Foundation/crypto.h  Cryptographic primitives (requires OpenSSL).

@authors Copyright (c) 2026 Jaakko Keränen <jaakko.keranen@iki.fi>

@par License

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

<small>THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</small>
*/

#include "block.h"

iBeginPublic

#define iAesGcmNonceSize    12
#define iAesGcmTagSize      16

iBlock *    newRandom_Block     (size_t size); /* cryptographically secure */
void        sha256_Block        (const iBlock *, uint8_t sha256_out[32]);
iBlock *    hmacSha256_Block    (const iBlock *, const iBlock *key);

/* AES-256-GCM. The key is 32 bytes and the nonce is iAesGcmNonceSize bytes. The encrypted
   output has the authentication tag (iAesGcmTagSize bytes) appended to the ciphertext.
   Decryption returns NULL if authentication fails. `aad` may be NULL. */
iBlock *    encryptAesGcm_Block (const iBlock *plain, const iBlock *key, const iBlock *nonce,
                                 const iBlock *aad);
iBlock *    decryptAesGcm_Block (const iBlock *cipherAndTag, const iBlock *key,
                                 const iBlock *nonce, const iBlock *aad);

iEndPublic
