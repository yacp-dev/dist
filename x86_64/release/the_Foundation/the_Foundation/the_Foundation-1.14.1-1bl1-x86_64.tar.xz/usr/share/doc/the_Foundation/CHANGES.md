# Changelog

## 1.14.1
* TlsRequest: Fixed possible crash due to heap use-after-free.

## 1.14 - 2026-11-07
* Archive: Added `setCompressionLevel`.
* Block: Added encryption using AES-256-GCM (requires OpenSSL).
* Block: Fixed hang when decompressing truncated data.
* Socket: Fixed sender getting stuck when buffer is full (on Windows).
* StringList: Added `newArray` to construct a StringList out of StringArray.
* Pipe: Fixed issue with file descriptors after spawning a child.
* Process: PATH is searched to find child executable.
* Process: Fixed overriding environment variables.
* Process: Added `communicate` to handle both writing to and reading from child process.
* RegExp: Improve performance by reusing match data (per thread) and allow JIT compilation.
* String: Added faster case-insensitive comparisons `iFastCmpStrCase`, `iFastCmpStrNCase`, `startWithCaseFast`, `endsWithCaseFast`, `equalCaseFast`. (These attempt a simple ASCII comparison first, falling back to expensive UTF-8 locale-aware comparison if they have to. Suitable for URLs, for example.)
* TlsCertificate: Support for Ed25519 and ECDSA P-512 keys.
* TlsRequest: Session resumption reuses each ticket only once (RFC 8446, Appendix C.4).
* TlsRequest: Added `waitForFinishedTimeout`.
* TlsRequest: Fixed bug in `waitForFinished` (wait for all I/O to be actually finished).
* TlsRequest: Fixed a small memory leak.
* TlsService: Expands on Service with TLS connections. Supports per-address limits and timeouts on handshake/transport.
* TomlParser: Support for string arrays (StringArray value) and single-quoted string literals.
* New platform: Emscripten.

## 1.13.1
* Archive: Fixed detecting and reading ZIP archives with extra prepended data (e.g., a self-extracting archive).
* TlsRequest: OpenSSL 4 compatibility.
* TlsRequest: Detect a clean close of connection more robustly.

## 1.13
* Address: Fixed converting a proxied address into text.
* Address: Don't allow literal localhost addresses through the network proxy.
* Address: Querying interface-specific UDP broadcast addresses.
* Address: Added `equalHost` to compare the host address, ignoring different ports.
* Block: Added `compressZlib` and `decompressZlib` (non-raw zlib deflate).
* FileInfo: Added `isExecutable` method.
* FileInfo: Fixed check for file writability in `FileInfo`.
* Service: Allow local address reuse (set SO_REUSEADDR).
* Socket: Fixed closing the socket during the Connecting phase if a network proxy is in use.
* Improved C++ compatibility: fixed `iFunctionCast`, added `iCompoundLiteral` that works for both C and C++.
* Windows: Improved support for compiling with Visual Studio (with vcpkg).

## 1.12.2
* c11threads: Fixing build issue with glibc 2.43 or newer. (Contributed by Michel Lind.)

## 1.12.1
* Windows: Fixed socket connections opened via NetworkProxy.

## 1.12 - 2026-03-18
* Added NetworkProxy: support for a SOCKS v5 proxy when opening TCP connections via Socket.
* Address: When a network proxy is enabled, defer address lookup so it occurs via the proxy when connecting.
* TlsRequest: Only print OpenSSL errors to stderr in debug builds.

## 1.11 - 2025-11-27
* Added `iSignf` and `iSigni`. `iSign` no longer forces the value to integer.
* String: The local encoding API has changed. The character set encoding to use for the "local" variant of String methods is set with `setLocalEncoding`. A separate "console" encoding was added for Windows, although it is available on all platforms. The `setConsoleEncoding` method sets the character set encoding for the "console" String methods.
* Windows: By default, the ANSI code page is used as the local character encoding, and the console output code page is used as the console encoding.
* Windows: UTF-16 is used with native APIs that handle file paths.
* Windows: Support for compiling with Visual Studio (dependencies via vcpkg). Contributed by gim913.

## 1.10.1 - 2025-09-13
* Time: Check the size of `time_t` (32 or 64 bits).
* TlsCertificate: Added helper method to check for undefined dates.

## 1.10 - 2025-09-06
* Array: Disregard `fill` when size is zero.
* Datagram: Implementation for missing methods on Windows (`isConnected`, `openRandom`).
* Garbage: Minor performance optimization when releasing memory.
* Path: Recognize and resolve "~" in a file path for better portability.
* String: Added `rangeN` and `rangeFrom` methods (partial ranges).
* Syntax definition files for the jked text editor.
* Bumped minimum CMake requirement to 3.10 as old versions of CMake are being deprecated.

## 1.9.1 - 2024-10-13
* TlsCertificate: Calculate SHA256 fingerprint when initializing (it will never change).

## 1.9 - 2024-09-20
* Added CMake build option `TFDN_ENABLE_STATIC_LINK` for linking dependencies statically.
* CommandLine: Query executable path via Linux /proc/ filesystem.
* Datagram: Added `isConnected` and `openRandom` methods.
* Datagram: Fixed premature termination of the UDP worker thread when an error occurs with one socket.
* Datagram: Handle UDP-related errors on Linux (e.g., ICMP port unreachable).
* TlsCertificate: Added method for querying subject alternative names.
* TlsRequest: Replaced use of deprecated OpenSSL API function.
* TlsRequest: Fixed a possible memory leak.
* XmlDocument: The `<?xml` header line is no longer required by the parser.

## 1.8.1 - 2024-04-14
* Fixed library version number in the CMakeLists file.

## 1.8 - 2024-04-14
* PtrArray: Added `back`, `constBack`, `popBack`, and `popFront` methods.
* String: Added `concat`, `concatCStr`, and `quoteDelim` methods.
* String: Added a function for setting the locale for 8-bit charset conversions.
* String: Added a method for converting a `Rangecc` to the local charset.
* String: Fixed issue with the `mid` method when starting position is at or past the end.
* StringList: Implemented missing iterator `remove` and `take` methods.
* TlsRequest: TLS 1.2 is the minimum accepted protocol version.
* TlsRequest: Adjusted ifdefs for improved LibreSSL compatibility.
* pkg-config: Compiler flag for SSE 4.1 added into the .pc file (if enabled in the build).
* Fixed warnings (errors) abouts implicit conversions.

## 1.7 - 2023-09-09
* Native Windows build using MinGW64: Winsock2 for sockets, IP addresses.
* Minimum CMake version requirement is now 3.5.
* Mat4 (generic): Fixed translating a matrix with `translate_Mat4`.
* Mat4: Fixed `scale` and `scalef` methods.
* Math: Added `xy_F3`, `initRotate_Mat4`.
* SSE: Fixed incorrect order of components when calling `initv_F4`.
* StringArray: Added serialization methods, reverse const iterator.
* StringList: Added serialization methods.

## 1.6.1 - 2023-03-09
* Library SOVERSION uses the major version number only. Minor versions do not break ABI compatibility.

## 1.6 - 2023-01-21
* Block: Added a method to encode contents in Base64.
* PtrArray: Added `copy` method.
* Process: Minor changes in how I/O is handled with the child process. Calling `writeInput` more than once is now possible.
* Process: Added a test where processes are started concurrently from threads.
* TlsRequest: Avoid possible crash when reusing TLS sessions.
* TlsRequest: Added a method to query the SSL library name (OpenSSL/LibreSSL).

## 1.5 - 2022-11-25
* RegExp: PCRE2 can be used as an alternative to the older PCRE.

## 1.4 - 2022-04-28
* Block: Fixed crash when checking size of zero-initialized instance.
* Char: Added `width` method.

## 1.3 - 2022-04-05
* Archive: Opening as writable, serializing with compression.
* Block: Handle possible vprintf encoding errors.
* String: Upper/lower-casing in a specific language.
* Time: Added `max` method.
* TlsCertificate: Avoid repeated verification of the same certificate.
* TlsRequest: TLS session cache can be disabled per request.

## 1.2.1
* SOVERSION includes the minor version, since new symbols may be added in minor releases.

## 1.2 - 2022-03-05
* String: Added replacing/substituting with a regular expression.
* TlsCertificate: Fixed copying of X509 chains.
* TlsRequest: Added a session cache to avoid repeat handshakes.

## 1.1 - 2022-01-20
* Detect Android as a variant of Linux. Some features like starting child processes are disabled in Android.
* Block: gzip-compatible decompression.
* Char: Querying script of a Unicode code point.
* Process: Remember exit status code.

## 1.0.3
* TlsRequest: Set "valid from" time using UTC instead of local time.

## 1.0 - 2021-11-06
* Initial release.
