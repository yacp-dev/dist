# N-Prolog User's Manual

## Built-in Operators

### □ ,
Represents conjunction (AND).  
`P, Q` succeeds if both `P` and `Q` succeed.

### □ ;
Represents disjunction (OR).  
`P ; Q` tries `P`, and on backtracking (or if `P` fails) tries `Q`.  
Note: At the top level, `;` is also used to request the next solution.

### □ E1 < E2
Checks if the numeric value of `E1` is less than the numeric value of `E2`.

### □ T1 = T2
Attempts to unify `T1` and `T2`.

### □ T1 \= T2
Succeeds if `T1` does not unify with `T2`.

### □ Struct =.. List
Known as "univ". Converts a structure to a list or a list to a structure.

### □ E1 =< E2
Checks if `E1` is less than or equal to `E2`.

### □ E1 > E2
Checks if `E1` is greater than `E2`.

### □ E1 >= E2
Checks if `E1` is greater than or equal to `E2`.

### □ E1 =:= E2
Checks if the numeric values of `E1` and `E2` are equal.

### □ E1 =\= E2
Checks if the numeric values of `E1` and `E2` are not equal.

### □ T1 == T2
Checks if `T1` and `T2` are identical (no unification performed).

### □ T1 \== T2
Checks if `T1` and `T2` are not identical.

### □ T1 @< T2
Checks if `T1` precedes `T2` in standard order.

### □ T1 @=< T2
Checks if `T1` precedes or is identical to `T2` in standard order.

### □ T1 @> T2
Checks if `T1` succeeds `T2` in standard order.

### □ T1 @>= T2
Checks if `T1` succeeds or is identical to `T2` in standard order.

---

## File Loading

### □ ['File']
Loads Prolog code from a file using consult behavior.
You can specify multiple files:
['file1.pl', 'file2.pl'].


### □ [-'File']
Loads Prolog code using reconsult behavior.  
Existing clauses of the same predicate are replaced.
Example:
[-'program.pl'].
Multiple files are also allowed:
[-'file1.pl', -'file2.pl'].

### □ abolish(Name/Arity)
Removes all clauses of the specified predicate from the database.

### □ abort
Stops the current program and returns to the interpreter.  
If the program is compiled, `abort` restarts its goal.

### □ ansi_cuu(N)
Move the cursor up N lines. 

### □ ansi_cud(N)
Move the cursor down N lines. 

### □ ansi_cuf(N)
Move the cursor forward N digits. 

### □ ansi_cub(N)
Move the cursor back N digits. 

### □ ansi_cpr(Row,Col)
The predicate ansi_cpr is used to know the current cursor position.
If the arguments Row and Col are not assigned, the coordinates of the current cursor position are in rows and columns.
Unify each argument.
If it has been assigned, compare that number with the coordinates of the current position. 

### □ ansi_scp
The predicate ansi_scp saves the current cursor position and the character attributes at that position. 

### □ ansi_rcp
The predicate ansi_rcp restores the cursor position and attributes saved by ansi_scp. 

### □ ansi_ed
The predicate ansi_ed erases the display.

### □ ansi_el
The predicate ansi_el erases from the cursor position to end of line.

### □ ansi_sgr(G)
The predicate ansi_sgr sets graphic attributes. G can be an integer or a list of integers.
The following are standard values only and may differ depending on the model. 

- 0 Reset all attributes to default.
- 1 emphasis
- 4 Underline
- 5 Blink
- 7 Reverse
- 8 secret
- 30 black
- 31 Red
- 32 green
- 33 yellow
- 34 blue
- 35 Magenta
- 36 Light blue
- 37 white
- 40 Background color black
- 41 Background color red
- 42 Background color green
- 43 Background color yellow
- 44 Background color blue
- 45 Background color Magenta
- 46 Background color light blue
- 47 Background color white 

### □ arg(N, Term, X)
Unifies `X` with the Nth argument of `Term`.  
Arguments are numbered from 1.

### □ arg0(N, Term, X)
Unifies `X` with the argument at index N (0-based).


### □ assert(Clause)
Add a clause to the end of the predicate. 

### □ asserta(Clause)
Add a clause to the top of the predicate. 

### □ assertz(Clause)
Add a clause to the end of the predicate.

### □ atom(X)
Check if X is an atom. 

### □ atom_string(Atom,String)
Convert an atom to a string or convert a string to an atom. 

### □ atomic(X)
Check if X is an atom data type.

### □ break
Suspends execution and displays an interpreter prompt.  
Type `end_of_file` to resume execution.

### □ call(P)
Call the interpreted goal P. 

### □ case([A1 -> B1, A2 -> B2, ...|C])
If A1 succeeds, execute B1. If A1 fails and A2 succeeds, execute B2.
The process continues similarly for subsequent steps. If nothing succeeds, execute C.

### □ chdir(Path)
Change or revert to the current directory.

### □ clause(Head, Body)
Unifies `Body` with the body of a clause whose head unifies with `Head`.  
`Head` must be instantiated.
example 

```
?- assert((foo(X) :- write(X))).
yes
?- clause(foo(X),B).
X = v_1
B = (write(v_1));
no
?- 
```

### □ close(Handle)
Closes the file specified by Handle. 

### □ ctr_dec(Ctr,X)
Decreases the value of a counter and returns the previous value of that counter. 

### □ ctr_inc(Ctr,X)
Increases the value of a counter and returns the previous value of that counter. 

### □ ctr_is(Ctr,X)
Returns the current counter value. 

### □ ctr_set(Ctr,X)
Set the counter to the specified value. 

### □ current_op(Proc,Assoc,Op)
Returns the operator constants currently defined in the database while backtracking. 

### □ current_predicate(Predicate)
Returns the predicate currently defined in the database while backtracking.

### □ date(date(Year,Month,Day))
Set the year, month, and day. 

### □ date_day(date(Year,Month,Day),WeekDay)
Returns the day of the week on a given date as a number between 0 (Sunday) and 6 (Saturday). 

### □ dec(N,X)
Unify X with the result of subtracting 1 from N.

### □ delete(Filename)
Delete the specified file. 

### □ directory(Path,Name,Mode,Time,Date,Size)
List the directory files specified by Path.

example 

```
?- directory('./',A,B,C,D,E).
A = 'link.c'
B = file
C = time(13,20,47)
D = date(2020,10,4)
E = 4281 ;
A = 'compute.o'
B = file
C = time(7,54,38)
D = date(2020,10,18)
E = 37544 .
```

### □ display(Term)
Write the term to standard output with prefix notation. 

### □ dpu(Handlein,Handleout)
Allocate a second fundle to the open file.

### □ edit(Filename)
Switch from the interpreter to the editor for editing the file specified by Filename.
Call Edlog as an editor. When you exit Edlog, the contents of the file will be read into the interpreter.
If the environment variable EDITOR has a value, call that editor.

example 

```
EDITOR=emacs
```

### □ edit(Filename, Option)
Option is an atom, either `r` or `c`. If it's `r`, the file is loaded using `reconsult`. If it's `c`, the file is loaded using `consult`.

### □ eq(X, Y)
Succeeds if `X` and `Y` are the same object (same address).


### □ erase(Ref)
Removes the entry stored under the specified reference number.

### □ eraseall(Key)
Removes all entries stored under the specified key.

### □ errcode(Code)
Returns the code of the most recent error message.

### □ expand_term(Term, NewTerm)
DCG: Converts a DCG rule into an equivalent Prolog clause.


### □ fileerrors(Old, New)
Specifies whether or not to output Linux I/O error messages, or checks the status of this setting.

### □ float(X)
Check if X is a floating point number.

### □ float_text(Float,Text,Format)
Converts a floating point number to a string according to the Format specification, or converts a string to a floating point number.

format is one of the following:

- general 0s following are suppressed.
- fixed (N) N gives the position of the decimal point (0-15).
- scientific (N) N gives the number of decimal places in exponential notation. 

### □ flush
Remove all characters in the type-ahead buffer.

### □ functor(Struct,Name,Arity)
Deconstruct the structure Struct into its name Name and arity Arity, or construct a structure Struct from the given Name and Arity.

### □ gc(Amount)
Launch garbage collection.
When the argument is full, the cells that are no longer needed in the heap area are collected. 

Extension: Providing the atom on as an argument enables message display upon garbage collection. Providing the atom off disables the message.

### □ get(Char)
Reads the next printable character from standard input and unifies its ASCII value with `Char`.

 
### □ get0(Char)
Reads the next character from standard input and unifies its ASCII value with `Char`.  
Unlike `get/1`, it does not skip non-printing characters.

### □ get0_noecho(Char)
Read the following characters from the standard input device and unify the ASCII value to Char.
get0_noecho does not display the character on the standard output device. 

### □ halt
Exits the interpreter. 

### □ ifthen(P, Q)
Execute goal Q if goal P succeeds.

### □ ifthenelse(P, Q, R)
Execute goal Q if goal P succeeds; if P fails, execute R.

### □ in(Port, Byte)
Read one byte from the specified port.

### □ inc(N, X)
Add 1 to number N and assign the result to X.

### □ instance(Ref,Term)
Returns the term for that reference number. 

### □ integer(X)
Check if X is an integer. 

### □int_text(Integer,String)
Convert an integer to a string, or convert a string to an integer. 

### □ X is E 
Evaluate the arithmetic expression E and unify the result with X.

### □ key(Key)
Returns the name and arity of the key in the current database.

### □ key(Key, Ref)
Returns the reference number for the key.

### □ keysort(L1,L2)
Sort the list L1 in standard order. List elements must be in the form Key_Value.
The sorted list is returned to L2. Even if it is duplicated, it won't be united. 

### □ leash(Mode)
Constrain the port to the specified Mode. 

### □ length(List, N)
Succeeds if `List` has length `N`.  
Can also generate a list of length `N`.


### □ listing
Write all current database predicates to standard output. 

### □ listing(Name/Arith)
### □ listing([Name/Arity,Name/Arity])
Write all clauses to the specified predicate or list of predicates in the current database to standard output. 

### □ list_text(List, AtomOrString)
Converts between a character list and an atom or string.

### □ mkdir(Path)
Create a new directory. 

### □ name(Atom,List)
Convert a list to an atom, or convert an atom or an integer to a list. 

### □ nth_char(N, String, Char)
Return the ASCII (or Unicode) value of the character that is N positions from the start of the string.

### □ nth_ref(Key, N, Ref)
Returns the reference number of the Nth item from the start of the chain of items.

### □ open(Handle,Filename,Access)
Open an existing file. 

Access is one of the following 

```
r read (text)
w write (text)
rw read and write (text)
a append (text)
ra read and append (text)
rb read (binary)
wb write (binary)
```

### □ read(Term)
Read terms from standard input devices. 

### □ read(Handle,Term)
Read terms from a file. 

### □ read_line(Handle,X)
Read one line from the file specified by Handle.

### □ read_string(MaxLength, X)
Reads a string from the standard input device.

### □ read_string(Handle, MaxLength, X)
Reads a string from the specified file.

### □ record_after(Ref, Term, Newref)
Adds a term after Ref and returns the new reference number for that term.

### □ recorda(Key, Term, Ref)
Records `Term` under `Key` and returns the reference number `Ref`.


### □ recorded(Key, Term, Ref)
Returns the term stored under the specified key and its reference number while backtracking.

### □ recordz(Key,Term,Ref)
Adds a term at the end of the predicate and returns the reference number assigned to that term. 

### □ recordh(Table_name,Sort_key,Term)
Record the term in the hash table. 



### □ ref(X)
Check if X is a reference number. 

### □ removeallh(Table_name)
Delete the hash table. 

### □ removeh(Table_name,Sort_key,Term)
Remove a term from the hash table.

### □ replace(Ref, Term)
Replaces the item with the specified reference number with the item provided in Term.

### □ reset_op
Returns the operator definition to its default value.

### □ retract (Clause)
Remove a clause from the database. 

### □ retrieveh(Table_name,Sort_key,Term)
Returns a term from the hash table.

### □ rename(Filename,Newname)
Rename the file. 

### □ rmdir(Path)
Delete the directory. 

### □ save
Save all changes made to the database since the last save.
Load the saved file when starting N-Prolog.

### □ save(Name)
Save the internal database with the specified program name, Name.

### □ shell(Command)
Execute the shell command and succeed.

### □ sort(L1, L2)
Sorts list `L1` into standard order, removes duplicates, and returns the result in `L2`.


### □ spy(Name/Arity)
Set a predicate as a debug spy point. 

### □ statistics(Atom/Val)
Returns information about system usage.

Atom -> Val
free -> The number of free cells in the heap area
wp -> The value of the working pointer
sp -> The value of the stack pointer
gc -> The number of times the garbage collector (GC) has been triggered
ac -> The value of th variant pointer

### □ stdin(FileHandle, Goal)
Temporarily redirects standard input while executing `Goal`.

### □ stdout(FileHandle, Goal)
Temporarily redirects standard output while executing `Goal`.

### □ stdinout(InFile, OutFile, Goal)
Temporarily redirects standard input and output while executing `Goal`.

### □ string(X)
Check if X is a string. 

### □ string_length(String,Length)
Returns the length of the string. 

### □ string_term(String,Term)
Change the string to a term.

### □ substring(InString,N,Length,OutString)
Extract substrings from strings.
N is a natural number starting from the starting position 1.
Length is the length of the character string to be extracted 

### □ syntaxerrors(Old,New)
Specify whether to output the syntax error message or check the current setting.
An error message is output with yes, and no error message is output with no. 

### □ system(P)
Check if P is an embedded predicate. 

### □ tab(N)
Write the specified number of space characters to the standard output device. 

### □ tab(Handle,N)
Write the specified number of space characters in the file. 

### □ tell(Filename)
Open a file for output and make it the current output file. 

### □ telling(X) 
Returns the name of the output file opened by tell.

### □ time(time(Hours,Minutes,Seconds))
Returns hour, minute, and second. 

```
hour   [0-23]
minute [0-59]
second [0-61]
```

### □ trace
Turn on the debugger. 

### □ true
Goals are always successful. 

### □ var(X)
Succeeds if `X` is an unbound variable.


### □ write(Term)
Write to standard output device. 

### □ write(Handle,Term)
Write the term in the specified file. 

### □ writeq(Term)
Write to standard output device so that the term can be read as a Prolog term
Enclose the atom and function in quotation marks. 

### □ writeq(Time,Term)
Write the term to the specified file so that the term can be read as a Prolog term
Enclose the atom and function in quotation marks. 



## Extended Predicates

- `compile_file(fn)`  
  Compiles the Prolog code from the file `fn` and generates an object file.

- `heapd(start, end)`  
  Displays the heap region addresses from `start` to `end`.

- `measure(E)`  
  Measures and displays the execution time of the predicate `E`.

## ISO-Derived Built-in Predicates

### □ \\+(Goal)
Executes Goal. If Goal succeeds, this predicate fails.  
If Goal fails, this predicate succeeds (negation as failure).  
Variable bindings created inside Goal do not affect the outer context.

### □ atom_concat(A1,A2,A3)
Concatenates atoms A1 and A2 and unifies the result with A3.  
*Note:* In N-Prolog, decomposition mode (e.g. `atom_concat(X,b,ab)`) is not supported.

### □ append(L1,L2,L3)
Unifies L3 with the list obtained by concatenating lists L1 and L2.

### □ member(E,List)
Succeeds if E is an element of List.

### □ between(Low,High,N)
Succeeds if integer N is between Low and High (inclusive).  
If N is a variable, integers from Low to High are generated sequentially.

### □ select(E,L1,L2)
Unifies L2 with the list obtained by removing one occurrence of E from L1.

### □ succ(N0,N1)
Succeeds if N1 is N0+1.

### □ maplist(Goal,List)
Calls Goal on each element X of List as `call(Goal,X)`.  
Succeeds if all calls succeed.

### □ compound(Term)
Succeeds if Term is a compound term (structure).

### □ ground(Term)
Succeeds if Term contains no variables.

### □ once(Goal)
Executes Goal and returns only the first solution.  
Prevents further backtracking.

### □ atom_codes(Atom,Codes)
Converts between Atom and its list of character codes Codes.

### □ atom_chars(Atom,Chars)
Converts between Atom and its list of one-character atoms Chars.

### □ char_code(Char,Code)
Converts between a one-character atom Char and its character code Code.

### □ number_codes(Number,Codes)
Converts between Number and its character code representation Codes.

### □ number_chars(Number,Chars)
Converts between Number and its list of character atoms Chars.

### □ predicate_property(Pred,Property)
Retrieves or enumerates the property Property of predicate Pred.

### □ bagof(Template,Goal,Bag)
Collects all instances of Template for which Goal succeeds into Bag.  
Results are grouped by free variables.  
Fails if there are no solutions.

### □ setof(Template,Goal,Set)
Like bagof/3, but removes duplicates and returns the results sorted.  
Fails if there are no solutions.

### □ findall(Template,Goal,List)
Collects all instances of Template for which Goal succeeds into List.  
Returns an empty list if there are no solutions.

### □ write_canonical(Term)
Writes Term in canonical form (without operators).

### □ write_canonical(Stream,Term)
Writes Term in canonical form to the specified Stream.

### □ atom_length(Atom,Length)
Unifies Length with the number of characters in Atom.

### □ get_code(Code)
Reads the next character code from the current input stream.

### □ get_code(Stream,Code)
Reads the next character code from Stream.

### □ get_char(Char)
Reads the next character from the current input stream.

### □ get_char(Stream,Char)
Reads the next character from Stream.

### □ get_byte(Byte)
Reads the next byte from the current input stream.

### □ get_byte(Stream,Byte)
Reads the next byte from Stream.

### □ put_char(Char)
Writes a character Char to the current output stream.

### □ put_char(Stream,Char)
Writes a character Char to Stream.

### □ put_code(Code)
Writes character code Code to the current output stream.

### □ put_code(Stream,Code)
Writes character code Code to Stream.

### □ put_byte(Byte)
Writes byte Byte to the current output stream.

### □ put_byte(Stream,Byte)
Writes byte Byte to Stream.

### □ peek_code(Code)
Reads the next character code without consuming it from the current input stream.

### □ peek_code(Stream,Code)
Reads the next character code from Stream without consuming it.

### □ peek_char(Char)
Reads the next character without consuming it from the current input stream.

### □ peek_char(Stream,Char)
Reads the next character from Stream without consuming it.

### □ peek_byte(Byte)
Reads the next byte without consuming it from the current input stream.

### □ peek_byte(Stream,Byte)
Reads the next byte from Stream without consuming it.

### □ flush_output
Flushes the current output stream.

### □ flush_output(Stream)
Flushes the specified Stream.

### □ catch(Goal,Catcher,Recovery)
Executes Goal. If an exception thrown by throw/1 unifies with Catcher, Recovery is executed.

### □ throw(Exception)
Throws the exception Exception.

### □ unify_with_occurs_check(T1,T2)
Performs unification with occurs-check, preventing cyclic terms.

### □ current_input(Stream)
Unifies Stream with the current input stream.

### □ current_output(Stream)
Unifies Stream with the current output stream.

### □ set_input(Stream)
Sets the current input stream to Stream.

### □ set_output(Stream)
Sets the current output stream to Stream.

### □ use_module(File)
Loads the specified File.

### □ module(Module)
Declares or sets the current module.

### □ copy_term(T1,T2)
Unifies T2 with a copy of T1.  
Variables in T2 are fresh and not shared with T1.


### □ at_end_of_stream(Stream)
Succeeds if Stream has reached end-of-file.

### □ stream_property(Stream,Property)
Retrieves or enumerates Property of Stream.

### □ dynamic(PredSpec)
Declares PredSpec as a dynamic predicate.  
*Note:* In N-Prolog, if `foo/1` is specified, the entire predicate `foo` becomes dynamic.

### □ initialization(Goal)
Executes Goal when the file is loaded.


### □ retractall(Head)
Removes all clauses that match Head.


### □ subsumes_term(General,Specific)
Succeeds if General subsumes (is more general than) Specific.


## Arithmetic Operators and Functions

- pi Constant representing the value of π (pi).
- X + Y Addition.
- X - Y Subtraction.
- X * Y Multiplication.
- X / Y Division resulting in a floating-point number.
- X // Y Integer division resulting in an integer.
- X ^ Y Exponentiation (power).
- X ** Y Exponentiation (power).
- X << Y Bitwise left shift of X by Y positions (integers only).
- X >> Y Bitwise right shift of X by Y positions (integers only).
- X mod Y Modulo operation, returning the remainder of X divided by Y (integers only).
- X /\ Y Logical AND.
- X \/ Y Logical OR.
- \X Complement (bitwise NOT).
- X xor Y Exlusive OR.
- abs(X) Absolute value of X.
- sin(X) Sine of X.
- asin(X) Arcsine (inverse sine) of X.
- cos(X) Cosine of X.
- acos(X) Arccosine (inverse cosine) of X.
- tan(X) Tangent of X.
- atan(X) Arctangent (inverse tangent) of X.
- exp(X) Exponential function of X.
- ln(X) Logarithm of X.
- log(X) Base-10 logarithm of X.
- sqrt(X) Square root of X.
- round(X,Y) Round X to N decimal places. N is an integer between 0 and 15.
- integer(X) Transform X to integer.
- float(X) Transform X to float. 
- randi(n) Random integer between 0 and n (inclusive).
- random Random floating-point number between 0 and 1 (inclusive).

## Debugger command
Start debugging by running the program. When the program reaches a spy point, it will be executed. At that point, the debugger will pause the program and display the port and goal at the current position. For example, enable the debugger, set a spy point on the predicate my_appendn, and then start debugging my_append.


```
?- ['tests/test.pl'].
yes
?- trace.
yes
?- spy(my_append/3).
yes
?- my_append([1,2,3],[4,5],X).
** (0) CALL: my_append([1,2,3],[4,5],X)?> 
** (0) REDO: my_append([1,2,3],[4,5],X)?> 
** (1) CALL: my_append([2,3],[4,5],v_4)?> 
** (1) REDO: my_append([2,3],[4,5],v_4)?> 
** (2) CALL: my_append([3],[4,5],v_8)?> 
** (2) REDO: my_append([3],[4,5],v_8)?> 
** (3) CALL: my_append([],[4,5],v_12)?> 
X = [1,2,3,4,5] .
** (3) EXIT: my_append([],[4,5],v_12)?> 
** (2) EXIT: my_append([3],[4,5],v_8)?> 
** (1) EXIT: my_append([2,3],[4,5],v_4)?> 
** (0) EXIT: my_append([1,2,3],[4,5],X)?> 
yes
?- 
```

After finishing debugging, run the notrace command. If you forget to do this, it will slow down the execution of your program.

prolog

```
?- notrace.
```

The following symbols indicate how the debugger has reached the current goal:

    **: Indicates that the goal is a spy point.
    *>: Indicates that the goal is a spy point, and the goal was reached due to the skip command.
    >: The goal is not a spy point, but it was reached due to the skip command.
    -> x: Indicates that the debugger is backtracking to a previous choice point.

There are four ports:

    CALL: The port where the goal is called. The interpreter assigns a number to each goal call. The numbering starts at 0 when the debugger is called and ends at 0 when debugging finishes.
    EXIT: The port where the program exits when the goal succeeds.
    REDO: The port where the program re-enters the goal through backtracking.
    FAIL: The port where the program exits when the goal fails.

- a
Suspend and terminate the program. Turn off the debugger and return to the interpreter prompt.

- b
The program being debugged does not exit but returns to the interpreter prompt. By typing end_of_file, you can exit the suspended state and continue debugging. Multiple interpreter prompts will be displayed for each valid interruption. For example, if there are three interruptions enabled, the interpreter prompt will display:

prolog

```
???-
```

- c
Instruct the debugger to creep to the next port, allowing you to step through the execution. Pressing the Enter key has the same effect as entering the c command.

- d
Display the current goal.

- e
Exit the interpreter and return to the Linux prompt.

- f
Directly advance the debugger to the FAIL port. This command is valid if you know that the goal will fail.

- h
Display the help screen.

- l
Leap from one spy point to another. This allows you to skip the step-by-step execution and jump to the next spy point.

- n
Turn off the debugger.

- q
Skip to the EXIT or FAIL port of the goal. However, if there is a spy point set within that goal, execution will stop at that spy point.

- s
Skip to the EXIT or FAIL port of the goal, even if there are other spy points in the goal. This command can only be used from the CALL or REDO ports.
<esc>
This is the same as pressing the escape key or entering the s command.

- w
Write the current goal to the output.

- X
This command can be used at the FAIL or REDO port. It causes the debugger to continue failing until it reaches a CALL or EXIT port.

- @
Call a secondary goal and return to the debugger when that goal finishes.

- ;
At the EXIT port, this command causes the debugger to proceed to the REDO port of the current goal.


## DCG
To use DCG call module.
use_module(dcg).

The following is an example from Professor Hideyuki Nakashima's "Prolog".

A dog bites a postman.

This English sentence has a structure. Its structure follows certain grammatical rules. 


```
Sentence-> noun phrase, verb phrase
Noun phrases-> articles, nouns
Article-> a
Noun-> dog
Noun-> postman
Verb phrase-> verb, noun phrase
Verb-> bits 
```
It's possible to write this directly in Prolog, but there's an easier way.
That is DCG. It is possible to write the above rules almost as they are.

Write the following code to a file and load it with consult in the same way as the Prolog code. 


```
s --> np,vp.
np --> det,n.
det -->[a].
n -->[dog].
n -->[postman].
vp --> v,np.
v -->[bites].
```

The grammar category is abbreviated. 

```
sentence　s
noun　n
noun　phrase　np
verb　v
determiner　det
verb　phrase
```

Let's run this on the N-Prolog processing system.
You can check if the sentence is correct with the predicate phrase. 


```
?- phrase(s,[a,dog,bites,a,postman]).
yes
```

In this way, it was confirmed that the sentence given in the list has the given sentence structure. What if you give the wrong sentence? 


```
?- phrase(s,[bites,a,dog,a,postman]).
no
```

False is returned. It violates the grammar rules.

Interestingly, you can also generate sentences that meet grammatical rules. 

```
?- phrase(s,X).
X = [a,dog,bites,a,dog];
X = [a,dog,bites,a,postman];
X = [a,postman,bites,a,dog];
X = [a,postman,bites,a,postman];
no
```

When I typed a semicolon and backtracked, some sentences came out.
The meaning is strange, but it follows the grammatical rules. 


## compiler
To use compiler call module.
use_module(compiler).

and...
compile_file(filename)

Make a file with the Prolog code to compile in this way.
Convert to C language and compile to object file with GCC.

For example, when compiling 9queens

compile_file('tests/queens.pl').

will do. This will generate a file called queens.o.

Enter ['tests/queens.o']. Or consult('queens.o'). To load it.
After that, you can use it like a normal predicate.

Partially processed tail recursive optimization. With queens, the execution speed is close to that of SWI-Prolog. 

## Multiple World Mechanism
:- use_module(mpworld).

The multiple world mechanism similar to that implemented in Dr. Hideyuki Nakajima's Prolog/KR is extended. Use the with/2 predicate.
There is an example in the mpw.pl file in the tests folder.
See Chapter 7 https://stacks.stanford.edu/file/druid:bv252vf8932/bv252vf8932.pdf

## Edlog editor
Edlog is editor for N-Prolog.


### invoke
`edlog`  or `edlog filename` onterminal.

For more details, enter ctrl+h. see help. 


# builtin predicate

```
<
=/
\=
= ..
=<
> 
>=
=:=
=\=
==
\==
@<
@=<
@>
@>=
abolish/1
abort/0
ansi_cuu/1
ansi_cud/1
ansi_cuf/1
ansi_cub/1
ansi_sgr/1
ansi_cpr/2
ansi_scp/0
ansi_rcp/0
ansi_ed/0
ansi_el/0
arg/3
arg0/3
assert/1
asserta/1
assertz/1
atom/1
atomic/1
break/0
call/1
chdir/1
clause/2
close/1
compare/3
concat/3
consult/1
ctr_set/2
ctr_dec/2
ctr_inc/2
ctr_is/2
current_op/3
current_predicate/1
date/1
date_day/2
dec/2
delete/1
directory/6
display/1
dup/2
edit/1
eq/2
erase/1
eraseall/1
expand_term/2
fail/0
float/1
float_text/3
flush/0 
gc/1
get/1
get/2
get0/1
get0/2
get0_noecho/1
halt/0
ifthen/2
ifthenelse/3
in/2
inc/2
instance/2
integer/1
int_text/2
is/2
keysort/2
length/2
listing/0
listing/1
list_text/2
mkdir/1
name/2
nl/0
nl/1
nonvar/1
nospy/1
notrace/0
number/1
not/1
out/1
open/3
read/1
read_line/2
reconsult/1
recorda/3
recordh/3
recordz/3
ref/1
reset_op/0
retrieveh/3
rmdir/1
see/1
seeing/1
seen/0
shell/1
sort/2
spy/1
string/1
string_length/2
string_term/2
syntaxerrors/2
system/1
tell/1
telling/1
told/0
time/1
trace/0
true/0
var/1
write/1
write/2
writeq/1
writeq/2
```

# builtin (extension)
See document/SUPERSET.md


# Arithmetic Operators and Functions
```
pi  constant 3.1415...
X + Y
X - Y
X * Y
X / Y
X // Y
X div Y
X ^ Y  expt
X ** Y expt
X << Y leftshift
X >> Y rightshift
X /\ Y logical and
X \/ Y logical or
\  complement
X mod Y 
abs(X) 
sin(X)
asin(X)
cos(X)
acos(X)
tan(X)
atan(X)
exp(X)
ln(X)
log(X)
sqrt(X)
round(X,N)　Round X to N decimal places. N is an integer between 0 and 15.　
randi(n)    generate random integer (n >= x >= 0) 
random generate random float (1 >= x >= 0)
```
