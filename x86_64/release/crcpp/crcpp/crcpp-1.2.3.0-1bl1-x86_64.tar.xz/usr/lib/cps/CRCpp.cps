{
  "compat_version" : "1.0.0.0",
  "components" : 
  {
    "CRCpp" : 
    {
      "compile_features" : [ "c++11" ],
      "includes" : [ "@prefix@/include" ],
      "type" : "interface"
    }
  },
  "cps_path" : "@prefix@/lib/cps",
  "cps_version" : "0.14.1",
  "description" : "Easy to use and fast C++ CRC library.",
  "license" : "BSD-3-Clause",
  "name" : "CRCpp",
  "version" : "1.2.3.0",
  "website" : "https://github.com/d-bahr/CRCpp"
}