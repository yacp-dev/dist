#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "libmonome::monome" for configuration "RelWithDebInfo"
set_property(TARGET libmonome::monome APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(libmonome::monome PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libmonome.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygmonome-1.dll"
  )

list(APPEND _cmake_import_check_targets libmonome::monome )
list(APPEND _cmake_import_check_files_for_libmonome::monome "${_IMPORT_PREFIX}/lib/libmonome.dll.a" "${_IMPORT_PREFIX}/bin/cygmonome-1.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
