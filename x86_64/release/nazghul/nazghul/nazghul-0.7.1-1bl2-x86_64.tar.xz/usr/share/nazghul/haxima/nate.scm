;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------
(define nate-start-lvl 2)

;;----------------------------------------------------------------------------
;; Schedule
;;
;;----------------------------------------------------------------------------

;;----------------------------------------------------------------------------
;; Gob
;;
;; Quest flags, etc, go here.
;;----------------------------------------------------------------------------
(define (nate-mk) (list #f #f))
(define (nate-caught? gob) (car gob))
(define (nate-caught! gob) (set-car! gob #t))
(define (nate-met? gob) (cadr gob))
(define (nate-met! gob) (set-car! (cdr gob) #t))

;;----------------------------------------------------------------------------
;; Conv
;;
;; Nate is a ranger of the Fens. He camps at the Enchanter's Tower.
;;----------------------------------------------------------------------------
(define (nate-hail knpc kpc)
  (let ((nate (kobj-gob-data knpc)))
    (define (join)
      (say knpc "Quand cela vous conviendra, demandez-moi le secret, milord. "
           "En attendant, vous pouvez me faire confiance pour ne pas vous échapper.")
      (join-player knpc)
      (give kpc t_arrow 20)
      (nate-caught! nate)
      (quest-data-update-with 'questentry-bandits 'captured-nate 1 (quest-notify nil))
      )
    (nate-met! nate)
    (cond ((nate-caught? nate)
           (say knpc "Comment puis-je vous aider ?")
           )
          (else
           (say knpc "Il n'est pas nécessaire de me tuer, aventurier. "
                "J'ai peut-être volé, mais je n'ai tué personne. "
                "Laissez-moi me rendre, et je vous dirai un grand secret. "
                "Vous êtes d'accord ?")
           (cond ((yes? kpc) (join))
                 (else
                  (say knpc "Seigneur ! Tuez-moi et le secret sera perdu avec moi. "
                       "Épargnez-moi et je vous rejoindrai, me battrai pour vous et vous mènerai à une source de pouvoir ancienne. "
                       "Je n'essaierai pas de m'échapper. "
                       "Ensuite, vous pouvez me dénoncer ou me libérer, comme vous le souhaitez. "
                       "Vous êtes d'accord ?")
                  (cond ((yes? kpc) (join))
                        (else
                         (say knpc "C'est un monstre assoiffé de sang qui tue ceux qui se sont rendus !")
                         (kern-conv-end)
                         ))))))))

(define (nate-secr knpc kpc)
  (cond ((is-player-party-member? knpc)
         (cond ((equal? (get-place knpc) p_shard)
                (say knpc "Je vais vous dire où se trouve l'entrée cachée de Brundegarde !"))
               (else
                (say knpc "Homme miséricodieux ! Ce n'est pas sûr ici ! Fuyons dans les étendues désertes et je vous "
                     "le dirai là bas.")
                )))
        (else
         (say knpc "Le secret est bien gardé avec moi.")
         )))

(define (nate-brun knpc kpc)
  (if (is-player-party-member? knpc)
      (say knpc "Mon Lord, nous devons chercher Brundegarde là où la route forestière passe au nord à travers les montagnes. "
           "Je vous donnerai le mot de passe quand nous y serons.")
      (say knpc "Oui le mot!")))

(define (nate-pass knpc kpc)
  (if (is-player-party-member? knpc)
      (cond ((equal? (get-place knpc) p_brundegardt)
             (say knpc "Oui, nous y sommes. Vous avez bien fait, milord. Le mot de passe... "
                  "[il serre les dents] "
                  "...NOOR. [Il soupire] C'est NOOR.")
             (prompt-for-key)
             (say knpc "Je vous demanderai une faveur, homme miséricordieux."
                  "J'ai longtemps désiré entrer à Brundegarde et apprendre son "
                  "secrets. Allons ensemble, et si nous sommes en vie, vous "
                  "pourrez faire de moi ce que vous voulez. Me l'accorderez-vous ?")
             (cond ((yes? kpc)
                    (say knpc "Je vous suis à jamais redevable ! Mais cet endroit "
                         "est resté caché pendant des lustres. Nous ne savons pas ce qui nous attend à l'intérieur. "
                         "Nous avons fait de notre mieux pour nous approvisionner du mieux que nous pouvions, avec "
                         "des torches, de la nourriture et des crochets de serrure.")
                    (prompt-for-key)
                    (say knpc "Mais par-dessus tout, nous aurons besoin d'une bonne réserve de "
                         "réactifs magiques pour la préparation des sortilèges. "
                         "J'espère que vous avez un peu de talent de magicien, "
                         "car notez mes paroles : nous en aurons besoin avant d'avoir fini."))
                   (else
                    (say knpc "Je vous prie de reconsidérer votre position, mais si vous ne tenez pas compte "
                         "de mon avertissement, car je ne vous en voudrait pas, "
                         "vous n'êtes qu'un simple soldat de fortune comme moi : "
                         "n'entrez pas seul dans Brundegarde, "
                         "et emportez avec vous les fournitures que vous pouvez voler ou acheter.")
                    )))
             (else
              (say knpc "Mais monsieur ! Nous n'avons pas atteint Brundegarde !")
              ))
      (say knpc "Mot de passe ? Quel mot de passe ?")
      ))

(define nate-conv
  (ifc basic-conv
       (method 'nom (lambda (knpc kpc) (say knpc "Je m'appelle Nate.")))
       (method 'brun nate-brun )
       (method 'bonj nate-hail )
	   (method 'hail nate-hail )
	   
       (method 'mot nate-pass )
       (method 'secr nate-secr )
       ))

(define nate-greetings
  (list
   "Je me rends !"
   "Ne me tuez pas !"
   "Vous m'avez attrapé !"
   "Je vous en prie, faites-moi prisonnier !"
   ))

(define (nate-ai knpc)
  (let ((nate (kobj-gob-data knpc)))
    (cond ((nate-met? nate) (std-ai knpc))
          ((any-player-party-member-visible? knpc)
           (taunt knpc nil nate-greetings)
           #t)
          (else
           (std-ai knpc)
           )
          )))

;;----------------------------------------------------------------------------
;; First-time constructor
;;----------------------------------------------------------------------------
(define (mk-nate)
  (bind 
   (kern-char-arm-self
    (kern-mk-char 
     'ch_nate ;;..........tag
     "Nate" ;;.......name
     sp_human ;;.....species
     oc_wrogue ;;.. .occupation
     s_companion_bard ;;..sprite
     faction-outlaw ;;..faction
     +1 ;;...........custom strength modifier
     0 ;;...........custom intelligence modifier
     +6 ;;...........custom dexterity modifier
     pc-hp-off ;;............custom base hp modifier
     pc-hp-gain ;;............custom hp multiplier (per-level)
     0 ;;............custom base mp modifier
     0 ;;............custom mp multiplier (per-level)
     max-health ;;..current hit points
     -1  ;;...........current experience points
     max-health ;;..current magic points
     0
     nate-start-lvl  ;;..current level
     #f ;;...........dead?
     'nate-conv ;;...conversation (optional)
     nil ;;sch_nate ;;.....schedule (optional)
     'nate-ai ;;..........custom ai (optional)

     ;;..............container (and contents)
     (mk-inventory
      (list
       (list 20 t_arrow)
       (list 1   t_bow)
       (list 1   t_dagger)
       (list 1   t_sword)
       (list 1   t_leather_helm)
       (list 1   t_armor_leather)
       (list 5   t_heal_potion)
       ))

     nil ;;.........readied arms (in addition to the container contents)
     nil ;;..........hooks in effect
     ))
   (nate-mk)))
