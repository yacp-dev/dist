;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------
(define kathryn-start-lvl  6)

;;----------------------------------------------------------------------------
;; Schedule
;; 
;; In Bole.
;;----------------------------------------------------------------------------
(kern-mk-sched 'sch_kathryn
               (list 0  0  bole-bed-kathryn "dort")
               (list 9  0  bole-table-1 "mange")
               (list 10 0  bole-courtyard   "suis en pause")
               (list 12 0  bole-table-1 "mange")
               (list 13 0  bole-dining-hall "suis en pause")
               (list 18 0  bole-table-1 "mange")
               (list 19 0  bole-dining-hall "suis en pause")
               (list 23 0  bole-bed-kathryn "dort")
               )

;;----------------------------------------------------------------------------
;; Gob
;;
;; Quest flags, etc, go here.
;;----------------------------------------------------------------------------
(define (kathryn-mk) nil)

;;----------------------------------------------------------------------------
;; Conv
;; 
;; Kathryn is a female mercenary wizard, currently in Bole on a mission
;; to retrieve the Rune of Knowledge from the thief (Mouse) contracted to 
;; purloin it from the Enchanter...and ensure he tells no tales.
;; She is manipulative and ruthless.
;; 
;; Kathryn is a potential party member (and an eventual betrayer).
;; She is accompanied by the brute Thud, who will join the party if she does.
;;----------------------------------------------------------------------------
(define (kathryn-hail knpc kpc)
  (say knpc "[Vous rencontrez une femme charmante qui vous considère avec mépris]. Oui ?"))

(define (kathryn-default knpc kpc)
  (say knpc "[Elle vous ignore consciencieusement]"))

(define (kathryn-name knpc kpc)
  (say knpc "Je ne donne pas mon nom aux étrangers. Dites, pourquoi ne pas aller POMPER "
       "un des habitants pour avoir des informations ? J'ai vu des animaux de ferme "
       "en chemin ..."))

(define (kathryn-join knpc kpc)
  (say knpc "[Elle étouffe de rire]"))

(define (kathryn-job knpc kpc)
  (say knpc "[ricanements] Je suis une nonne. Les pipes, c'est 500 pièces d'or."))


(define (kathryn-blowjob knpc kpc)
  (say knpc "Ca s'appelle du SARCASME. Dégage, sale type."))

(define (kathryn-clients knpc kpc)
  (say knpc "Mes clients préfèrent rester anonymes. Tout ce que vous devez savoir, c'est "
       "que vous ne devez pas les énerver."))

(define (kathryn-things knpc kpc)
  (say knpc "J'ai peur qu'un minable comme toi ne comprenne pas."))

(define (kathryn-thief knpc kpc)
  (say knpc "[Elle vous lance un regard rusé] Vous savez, nous pouvons peut-être nous aider "
       "l'un l'autre. Je suis venue ici au nom de mes clients pour acheter un article "
       "en toute bonne foi de la part d'un vendeur anonyme."))

(define (kathryn-seller knpc kpc)
  (say knpc "Imaginez mon choc lorsque j'ai découvert que l'objet avait été vole ! "
       "Bien entendu, j'ai exigé qu'il me remette immédiatement l'objet afin que "
       "je puisse le rendre à son propriétaire légitime. A peine ai-je fait "
       "comprendre clairement mes intentions quand il a disparu sous mes yeux !"))

(define (kathryn-vanish knpc kpc)
  (say knpc "Pouf ! Parti ! Le vilain devais avoir un anneau d'invisibilité. "
       "Thud et moi l'avons cherché partout."))

(define (kathryn-search knpc kpc)
  (define (do-join)
    (say knpc "Excellent ! Voyons si quelqu'un ici sait qu'il y a un voleur.")
    (if (in-inventory? knpc t_wis_quas_scroll)
        (begin
          (say knpc "Oh, ce parchemin peut être utile. "
               "Prenez le, je ne comprends vraiment pas ces "
               "bidules magiques très bien.")    
          (kern-obj-remove-from-inventory knpc t_wis_quas_scroll 1)
          (kern-obj-add-to-inventory kpc t_wis_quas_scroll 1)))
    (kern-char-join-player knpc)
    (if (and (defined? 'ch_thud)
             (is-alive? ch_thud))
        (begin
          (say knpc "Vous ne verrez pas d'inconvénient à ce que mon cousin Thud se joigne à nous. "
               "C'est vraiment un enfant, et il est tout à fait démuni sans moi.")
          (kern-char-join-player ch_thud)))
    (kern-conv-end))
  (say knpc "Il semble que nous ayons un objectif commun. Rejoignez-nous, et quand nous aurons attrapé le "
       "vilain nous allons tous rendre l'objet. Vous pouvez avoir une récompense. "
       "Le fait de savoir que nous avons fait ce qu'il fallait "
       "sera suffisant pour moi et Thud. Qu'en dis-vous, le dur à cuire, allez-vous nous "
       "rejoindre?")
  (if (kern-conv-get-yes-no? kpc)
      (do-join)
      (begin
        (say knpc "[Elle est en détresse] Oh, s'il vous plaît, ne m'aideriez-vous pas ! "
             "Mes maîtres sont puissants et cruels ! Si je ne reviens pas avec "
             "l'objet qu'ils cherchent il n'y aura nulle part où je puisse me cacher dans cette vie "
             "ou dans la suivante! Voulez-vous vous joindre à moi ?")
        (if (kern-conv-get-yes-no? kpc)
            (do-join)
            (begin
              (say knpc "[Elle se penche, les lèvres fendues et les yeux fermés] "
                   "Ok, le gros dur, tu gagnes. Je ne veux pas de cet objet idiot. "
                   "Je te trouve tout simplement irrésistible. Laisse-moi t'accompagner, "
                   "mon mignon, s'il te plait ? Je peux être Oooh... si... reconnaissante ...")
              (if (kern-conv-get-yes-no? kpc)
                  (do-join)
                  (say knpc "[Elle devient rouge et crie de rage] Crétin ! "
                       "Vous n'avez aucune idée à qui vous avez affaire ! Ce que vous cherchez "
                       "attire le regard des sorciers les plus sombres de tout le  "
                       "pays ! Ce voleur connaîtra des tourments éternels lorsque nous "
                       "l'auront attrapé ! Et TU AURAIS MIEUX FAIT DE RESTER EN DEHORS DE NOTRE CHEMIN!")
                  (kern-conv-end)))))))

(define (kathryn-tavern knpc kpc)
  (say knpc "Un bel endroit. Si vous êtes un cafard."))

(define (kathryn-companion knpc kpc)
  (say knpc "Thud ? C'est mon... cousin."))

(define (kathryn-cousin knpc kpc)
  (say knpc "Un cousin DISTANT."))

(define (kathryn-bill knpc kpc)
  (say knpc "L'idiot du village ? Il est probablement sorti utiliser son outil dans la "
       "forêt. Pourquoi n'allez-vous pas lui donner un coup de main ?"))

(define (kathryn-hackle knpc kpc)
  (say knpc "Cette folle ? Elle vit de l'autre côté du ruisseau ! J'ai peur qu'elle ne puisse pas guérir "
       "la laideur. Désolée."))

(define (kathryn-may knpc kpc)
  (say knpc "L'aubergiste ? Une vieille bique curieuse. Il est évident que vous n'avez pas d'argent, "
       "mais si vous le faisiez, je vous conseillerais de dormir avec sous votre oreiller."))

(define (kathryn-melvin knpc kpc)
  (say knpc "Le cuisinier ? Un vieil homme sale et un ivrogne."))

(define (kathryn-sorceress knpc kpc)
  (say knpc "[Elle se couvre la bouche d'une fausse frayeur] Ooh ! Tu as deviné mon sale "
       "petit secret ! Maintenant, bats-toi ou je t'utiliserai comme une torche."))

(define (kathryn-scro knpc kpc)
  (if (is-player-party-member? knpc)
      (say knpc "Mais je t'ai déjà donné le seul que j'avais. "
           "Je ne sais même pas où je l'ai eu !")
      (say knpc "Un parchemin ? [Elle rit] Dois-je vider mes poches ? "
           "Mêlez-vous de vos affaires.")))


(define kathryn-conv
  (ifc nil
       (method 'default kathryn-default )
       (method 'bonj kathryn-hail )
	   (method 'hail kathryn-hail )
	   
       (method 'adie (lambda (knpc kpc) (say knpc "Bon débarras !")))
       (method 'trav kathryn-job )
       (method 'nom kathryn-name )
       (method 'join kathryn-join )

       (method 'pipe kathryn-blowjob )
       (method 'bill kathryn-bill )
       (method 'clie kathryn-clients )
       (method 'comp kathryn-companion )
       (method 'cous kathryn-cousin )
       (method 'foi kathryn-seller )
       (method 'hack kathryn-hackle )
       (method 'arti kathryn-seller )
       (method 'aube kathryn-tavern )
       (method 'may kathryn-may )
       (method 'renc kathryn-thief )
       (method 'melv kathryn-melvin )
       (method 'nonn kathryn-blowjob )
       (method 'bagu kathryn-search )
       (method 'cher kathryn-search )
       (method 'vend kathryn-seller )
       (method 'sorc kathryn-sorceress )
       (method 'tave kathryn-tavern )
       (method 'thud kathryn-companion )
       (method 'vole kathryn-thief )
       (method 'disp kathryn-vanish )
       (method 'vila kathryn-search )
       (method 'parc kathryn-scro )
       ))

;;----------------------------------------------------------------------------
;; First-time constructor
;;----------------------------------------------------------------------------
(define (mk-kathryn)
  (bind 
   (kern-char-force-drop
    (kern-char-arm-self
     (kern-mk-char 
      'ch_kathryn ;;..tag
      "Kathryn" ;;....name
      sp_human ;;.....species
      oc_wizard ;;....occupation
      s_wizard ;;.....sprite
      faction-men ;;..faction
      0 ;;............custom strength modifier
      4 ;;............custom intelligence modifier
      0 ;;............custom dexterity modifier
      2 ;;............custom base hp modifier
      1 ;;............custom hp multiplier (per-level)
      4 ;;............custom base mp modifier
      2 ;;............custom mp multiplier (per-level)
      max-health ;; current hit points
      -1  ;;...........current experience points
      max-health ;; current magic points
      0
      kathryn-start-lvl  ;;..current level
      #f ;;...........dead?
      'kathryn-conv ;;conversation (optional)
      sch_kathryn ;;..schedule (optional)
      'spell-sword-ai ;;...custom ai (optional)
      ;;..............container (and contents)
      (mk-inventory
       (list
        (list 1 t_kathryns_letter)
        (list 100 t_gold_coins)
        (list 5 sulphorous_ash )
        (list 5 ginseng )
        (list 5 garlic )
        (list 3 spider_silk )
        (list 3 blood_moss )
        (list 2 black_pearl )
        (list 1 nightshade )
        (list 1 mandrake )
        (list 1 t_wis_quas_scroll)
        ))
      ;;..............readied arms (in addition to the container contents)
      (list
       t_staff
       )
      nil ;;..........hooks in effect
      ))
    #t)
   (kathryn-mk)))
