;;----------------------------------------------------------------------------
;; Terrains
;;----------------------------------------------------------------------------

(define (terrain-effect-burn obj)
  (kern-obj-apply-damage obj "burning" 10))

(define (terrain-effect-poison obj)
  (if (and (> (kern-dice-roll "1d20") 10)
           (kern-obj-is-being? obj)
           (kern-obj-add-effect obj ef_poison nil))
      (kern-log-msg "Des fumées nocives!")))
	
;; swamp logic:
;; 1) swamp only effects you on your turn (ie the 'slow progress' doesnt mean you get whacked 3 times before your next turn)
;;			this is calculated by whether your character speed is enough to bring your ap positive in your next turn
;; 2) swamp is weaker in the worldmap, where you are assumed to have some lattitude to go around the noxious bits
;; 3) swamp gives 'noxious fumes' feedback if someone in your party gets poisoned, or you see an individual critter get poisoned
;;       you dont get feedback when a npc party moves over swamp
(define (terrain-effect-swamp obj)
  (if (and (kern-obj-is-being? obj)
			(if (kern-place-is-wilderness? (loc-place (kern-obj-get-location obj)))
				(> (kern-obj-get-ap (kern-char-get-party obj)) (- 0 (kern-char-get-speed obj)))
				(> (kern-obj-get-ap obj) (- 0 (kern-char-get-speed obj)))
				))
	(let* (
			(difficulty
				(cond ((< (kern-obj-get-movecost obj pclass-canfly) cant) 1)
					((kern-place-is-wilderness? (loc-place (kern-obj-get-location obj))) 4)
					(else 6)
				))
			(avoid (* 2 (occ-ability-dexdefend obj)))
			(avoidroll (- (kern-dice-roll (mkdice 1 (+ avoid difficulty))) avoid ))
			(strength (kern-char-get-strength obj))
			(resistroll (- (kern-dice-roll (mkdice 1 (+ strength 10))) strength ))
			)
		(if (> avoidroll 0)
			(if (> resistroll 0)
				(begin
					(kern-obj-add-effect obj ef_poison nil)
					(if (kern-place-is-wilderness? (loc-place (kern-obj-get-location obj)))
						(if (is-player-party-member? obj)
							(kern-log-msg "Des fumées nocives !"))
						(msg-log-visible (kern-obj-get-location obj) "Des fumées nocives !")
					)			
				)
			))
	)))
	
(define (terrain-effect-lava obj)
  (if (eqv? (kern-obj-get-movecost obj pclass-canfly) cant)
	(if (and (kern-obj-is-being? obj)
			(kern-place-is-wilderness? (loc-place (kern-obj-get-location obj))))
		(let* ((avoid (* 2 (occ-ability-dexdefend obj)))
				(avoidroll (- (kern-dice-roll (mkdice 1 (+ avoid 5))) avoid)))
			(if (> avoidroll 0)
				(generic-burn obj (mkdice avoidroll 4)))
		)
		(burn obj))))

(define (terrain-effect-torch obj)
	(generic-burn obj "1d4"))

;; opacity constants:
(define opq 12) ;; opaque
(define hvy 5)  ;; heavy
(define dns 3)  ;; dense
(define lgt 2)  ;; light (density)
(define trn 0)  ;; transparent

(define terrains
  (list
   ;;    tag                name            pclass           sprite               t light step-on
   ;;    =================  ==============  =============    ==============       = ===== =======
   (list 't_stars           "les étoiles"         pclass-space     s_stars             trn 0 'chasm-fall)
   (list 't_deep            "des eaux profondes"    pclass-deep      s_deep              trn 0 nil)
   (list 't_sunlit_deep     "des eaux profondes"    pclass-deep      s_deep              trn 64 nil)
   (list 't_shallow         "de l'eau"          pclass-deep      s_shallow          trn 0 nil)
   (list 't_blendable_shoals "des eaux peu profondes" pclass-shoals    s_shoals           trn 0 nil)
   (list 't_shoals          "des eaux peu profondes" pclass-shoals    s_shoals            trn 0 nil)
   (list 't_sludge          "de la boue huileuse"   pclass-sludge    s_sludge            trn 0 nil)
   (list 't_shallow_sludge  "de la boue huileuse"   pclass-shallows  s_shallow_sludge    trn 0 nil)
   (list 't_grass           "l'herbe"         pclass-grass     s_grass             trn 0 nil)
   (list 't_sunlit_grass    "l'herbe"         pclass-grass     s_grass             trn 64 nil)
   (list 't_dirt            "la terre"          pclass-grass     s_dirt              trn 0 nil)
   (list 't_gravel          "du gravier"        pclass-grass     s_gravel            trn 0 nil)
   (list 't_trees_v         "des arbres"         pclass-trees     s_trees             trn 0 nil)
   (list 't_trees           "des arbres"         pclass-trees     s_trees             lgt 0 nil)
   (list 't_trees_d         "des arbres"         pclass-trees     s_trees             dns 0 nil)

   (list 't_forest_v        "la forêt"        pclass-forest    s_forest            trn 0 nil)
   (list 't_forest          "la forêt"        pclass-forest    s_forest            hvy 0 nil)
   (list 't_forest_d        "la forêt"        pclass-forest    s_forest            7   0 nil)
   (list 't_forest_l        "la forêt"        pclass-forest    s_forest            dns 0 nil)
   (list 't_forest_b        "la forêt"        pclass-forest    s_forest            opq 0 nil)

   (list 't_hills           "les collines"         pclass-hills     s_hills             dns 0 nil)
   (list 't_mountains_v     "les montagnes"     pclass-vmountains s_mountains         trn 0 nil)
   (list 't_mountains_b     "les montagnes (en bas)"     pclass-space s_mountains         trn 0 nil)
   (list 't_mountains       "les montagnes"     pclass-mountains s_mountains         opq 0 nil)
   (list 't_fake_mountains  "les montagnes"     pclass-grass     s_mountains         opq 0 nil)
   (list 't_bog             "un bourbier"           pclass-hills    s_bog               trn 0 'terrain-effect-swamp)
   (list 't_lava            "la lave"          pclass-hills     s_lava              trn  128 'terrain-effect-lava)
   (list 't_fake_lava       "la lave"          pclass-grass     s_lava              trn  128 nil)
   (list 't_deep_lava       "la lave profonde"     pclass-deep      s_deep_lava         trn   16 'great-burn)
   (list 't_fire_terrain    "le feu"          pclass-grass     s_field_fire        trn  512 'burn)
   (list 't_fireplace       "un feu de camp"     pclass-grass     s_fireplace         trn 2048 'burn)

   (list 't_cobblestone     "un pavé"   pclass-grass     s_cobblestone       trn 0 nil)
   (list 't_gold_cobble     "un pavé"   pclass-grass     s_gold_cobble       trn 0 nil)
   (list 't_cyan_cobble     "un pavé"   pclass-grass     s_cyan_cobble       trn 0 nil)
   (list 't_gray_cobble     "un pavé"   pclass-grass     s_gray_cobble       trn 0 nil)
   (list 't_blue_cobble     "un pavé"   pclass-grass     s_blue_cobble       trn 0 nil)
   (list 't_olive_cobble     "un pavé"   pclass-grass     s_olive_cobble       trn 0 nil)
   (list 't_white_cobble     "un pavé"   pclass-grass     s_white_cobble       trn 0 nil)
   (list 't_black_tile     "un carrelage de sol"   pclass-grass     s_black_tile       trn 0 nil)
   (list 't_gold_spiral_tile     "un carrelage de sol"   pclass-grass     s_gold_spiral_tile       trn 0 nil)
   (list 't_blue_spiral_tile     "un carrelage de sol"   pclass-grass     s_blue_spiral_tile       trn 0 nil)
   (list 't_tombstone       "une pierre tombale"     pclass-boulder s_tombstone trn 0 nil)
   (list 't_tombstone2       "une pierre tombale"     pclass-boulder s_tombstone2 trn 0 nil)

   (list 't_impassable_cobblestone    "un pavé"   pclass-wall     s_cobblestone       trn 0 nil)
   (list 't_flagstones      "des dalles"    pclass-grass     s_flagstone         trn 0 nil)
   (list 't_inv_wall        "des dalles"    pclass-repel     s_flagstone         trn 0 'burn)
   (list 't_doorway         "une embrasure de porte"       pclass-grass     s_stone_arch        trn 0 nil) ;;dont use this if poss
   (list 't_leftwing        "un mur du château"   pclass-wall      s_leftwing          trn 0 nil)
   (list 't_rightwing       "un mur du château"   pclass-wall      s_rightwing         trn 0 nil)
   (list 't_ship_hull       "le pavois du navire"   pclass-wall      s_wall           trn 0 nil)
   (list 't_ship_hull2      "la coque du navire"   pclass-wall      s_wall              opq 0 nil)
   (list 't_sh_hull_NE      "la coque du navire"   pclass-wall      s_wall_b            trn 0 nil)
   (list 't_sh_hull_NW      "la coque du navire"   pclass-wall      s_wall_a            trn 0 nil)
   (list 't_sh_hull_SE      "la coque du navire"   pclass-wall      s_wall_c            trn 0 nil)
   (list 't_sh_hull_SW      "la coque du navire"   pclass-wall      s_wall_d            trn 0 nil)
   (list 't_mast            "un poteau"          pclass-wall      s_mast              trn 0 nil)
   (list 't_ships_wheel     "la barre de gouvernail"  pclass-wall   s_ships_wheel       trn 0 nil)
   (list 't_deck            "le pont"          pclass-grass     s_deck              trn 0 nil)
   (list 't_boulder         "un rocher"       pclass-boulder   s_boulder           lgt 0 nil)
   (list 't_wall_rock_v     "la paroi rocheuse"     pclass-wall      s_wall_rock         trn 0 nil)
   (list 't_wall_rock       "la paroi rocheuse"     pclass-wall      s_wall_rock         opq 0 nil)
   (list 't_fake_wall_rock  "la paroi rocheuse"     pclass-forest    s_secret_rock       opq 0 nil)
   (list 't_wall_v          "le mur"          pclass-wall      s_wall_stone        trn 0 nil)
   (list 't_wall            "le mur"          pclass-wall      s_wall_stone        opq 0 nil)
   (list 't_fake_wall       "le mur"          pclass-forest    s_wall_stone        opq 0 nil)
   (list 't_wall_torch      "une torche murale"    pclass-wall      s_wall_torch        opq 1024 'terrain-effect-torch)
   (list 't_arrow_slit      "une meurtrière"    pclass-bars      s_arrow_slit        trn 0 nil)
   (list 't_window_in_stone "une fenêtre"        pclass-bars      s_window_in_stone   trn 0 nil)
   (list 't_window_in_rock  "une fenêtre"        pclass-bars      s_window_in_rock    trn 0 nil)
   (list 't_secret_door     "une porte secrète"   pclass-grass     s_secret_door       opq 0 nil)
   (list 't_sea_wall_v      "une muraille de mer"      pclass-wall      s_wall              trn 0 nil)
   (list 't_sea_wall        "une muraille de mer"      pclass-wall      s_wall              opq 0 nil)
   (list 't_sea_wall_NE     "une muraille de mer"      pclass-wall      s_wall_b            opq 0 nil)
   (list 't_sea_wall_NW     "une muraille de mer"      pclass-wall      s_wall_a            opq 0 nil)
   (list 't_sea_wall_SE     "une muraille de mer"      pclass-wall      s_wall_c            opq 0 nil)
   (list 't_sea_wall_SW     "une muraille de mer"      pclass-wall      s_wall_d            opq 0 nil)
   (list 't_ankh            "une ankh"          pclass-wall      s_ankh              trn 0 nil)
   (list 't_statue          "une statue"        pclass-wall      s_statue            trn 0 nil)
   (list 't_altar           "un autel"         pclass-boulder      s_altar             trn 0 nil)
   (list 't_rune_altar      "un autel runique"    pclass-boulder      s_altar             trn 64 nil)
   (list 't_active_altar    "un autel runique activé" pclass-boulder s_active_altar    trn 512 nil)
   (list 't_pillar          "un pilier"        pclass-wall      s_pillar            trn 0 nil)
   (list 't_false_pillar    "un pilier"        pclass-grass     s_pillar            trn 0 nil)
   (list 't_counter_2x1_w   "un comptoir"       pclass-boulder   s_counter_2x1_w     trn 0 nil)
   (list 't_counter_2x1_c   "un comptoir"       pclass-boulder   s_counter_2x1_c     trn 0 nil)
   (list 't_counter_2x1_e   "un comptoir"       pclass-boulder   s_counter_2x1_e     trn 0 nil)
   (list 't_counter_1x1     "un comptoir"       pclass-boulder   s_counter_1x1       trn 0 nil)
   (list 't_bridge_WE       "un pont"        pclass-bridge    s_ew_bridge         trn 0 nil)
   (list 't_bridge_NS       "un pont"        pclass-bridge    s_ns_bridge         trn 0 nil)
   (list 't_lava_bridge_NS  "un pont"        pclass-bridge    s_ns_bridge         trn 0 nil)
   (list 't_chasm           "un trou"         pclass-space     s_null              trn 0 nil)
   (list 't_void            "le Néant"   pclass-space     s_null       trn 0 nil)
   (list 't_trail_0         "un sentier"         pclass-grass     s_trail_0           trn 0 nil)
   (list 't_trail_1         "un sentier"         pclass-grass     s_trail_1           trn 0 nil)
   (list 't_trail_2         "un sentier"         pclass-grass     s_trail_2           trn 0 nil)
   (list 't_trail_3         "un sentier"         pclass-grass     s_trail_3           trn 0 nil)
   (list 't_trail_4         "un sentier"         pclass-grass     s_trail_4           trn 0 nil)
   (list 't_trail_5         "un sentier"         pclass-grass     s_trail_5           trn 0 nil)
   (list 't_trail_6         "un sentier"         pclass-grass     s_trail_6           trn 0 nil)
   (list 't_trail_7         "un sentier"         pclass-grass     s_trail_7           trn 0 nil)
   (list 't_trail_8         "un sentier"         pclass-grass     s_trail_8           trn 0 nil)
   (list 't_trail_9         "un sentier"         pclass-grass     s_trail_9           trn 0 nil)
   (list 't_trail_a         "un sentier"         pclass-grass     s_trail_a           trn 0 nil)
   (list 't_trail_b         "un sentier"         pclass-grass     s_trail_b           trn 0 nil)
   (list 't_trail_c         "un sentier"         pclass-grass     s_trail_c           trn 0 nil)
   (list 't_trail_d         "un sentier"         pclass-grass     s_trail_d           trn 0 nil)
   (list 't_trail_e         "un sentier"         pclass-grass     s_trail_e           trn 0 nil)
   (list 't_trail_f         "un sentier"         pclass-grass     s_trail_f           trn 0 nil)
   (list 't_A               "un A"          pclass-wall      s_A                 trn 0 nil)
   (list 't_B               "un B"           pclass-wall      s_B                 trn 0 nil)
   (list 't_fake_B          "un B"           pclass-forest    s_B                 trn 0 nil)
   (list 't_C               "un C"           pclass-wall      s_C                 trn 0 nil)
   (list 't_D               "un D"           pclass-wall      s_D                 trn 0 nil)
   (list 't_E               "un E"          pclass-wall      s_E                 trn 0 nil)
   (list 't_F               "un F"          pclass-wall      s_F                 trn 0 nil)
   (list 't_G               "un G"           pclass-wall      s_G                 trn 0 nil)
   (list 't_H               "un H"          pclass-wall      s_H                 trn 0 nil)
   (list 't_I               "un I"          pclass-wall      s_I                 trn 0 nil)
   (list 't_J               "un J"           pclass-wall      s_J                 trn 0 nil)
   (list 't_K               "un K"           pclass-wall      s_K                 trn 0 nil)
   (list 't_L               "un L"          pclass-wall      s_L                 trn 0 nil)
   (list 't_M               "un M"          pclass-wall      s_M                 trn 0 nil)
   (list 't_N               "un N"          pclass-wall      s_N                 trn 0 nil)
   (list 't_O               "un O"          pclass-wall      s_O                 trn 0 nil)
   (list 't_fake_O          "un O"          pclass-forest    s_O                 trn 0 nil)
   (list 't_P               "un P"           pclass-wall      s_P                 trn 0 nil)
   (list 't_Q               "un Q"           pclass-wall      s_Q                 trn 0 nil)
   (list 't_R               "un R"          pclass-wall      s_R                 trn 0 nil)
   (list 't_S               "un S"          pclass-wall      s_S                 trn 0 nil)
   (list 't_T               "un T"           pclass-wall      s_T                 trn 0 nil)
   (list 't_U               "un U"           pclass-wall      s_U                 trn 0 nil)
   (list 't_V               "un V"           pclass-wall      s_V                 trn 0 nil)
   (list 't_W               "un W"           pclass-wall      s_W                 trn 0 nil)
   (list 't_X               "un X"          pclass-wall      s_X                 trn 0 nil)
   (list 't_Y               "un Y"           pclass-wall      s_Y                 trn 0 nil)
   (list 't_Z               "un Z"           pclass-wall      s_Z                 trn 0 nil)
   (list 't_rune_A          "un A runique"        pclass-wall      s_rune_A      trn 0 nil)
   (list 't_rune_B          "un B runique"        pclass-wall      s_rune_B      trn 0 nil)
   (list 't_rune_C          "un C runique"        pclass-wall      s_rune_C      trn 0 nil)
   (list 't_rune_D          "un D runique"        pclass-wall      s_rune_D      trn 0 nil)
   (list 't_rune_E          "un E runique"        pclass-wall      s_rune_E      trn 0 nil)
   (list 't_rune_F          "un F runique"        pclass-wall      s_rune_F      trn 0 nil)
   (list 't_rune_G          "un G runique"        pclass-wall      s_rune_G      trn 0 nil)
   (list 't_rune_H          "un H runique"        pclass-wall      s_rune_H      trn 0 nil)
   (list 't_rune_I          "un I runique"        pclass-wall      s_rune_I      trn 0 nil)
   (list 't_rune_J          "un J runique"        pclass-wall      s_rune_J      trn 0 nil)
   (list 't_rune_K          "un K runique"        pclass-wall      s_rune_K      trn 0 nil)
   (list 't_rune_L          "un L runique"        pclass-wall      s_rune_L      trn 0 nil)
   (list 't_rune_M          "un M runique"        pclass-wall      s_rune_M      trn 0 nil)
   (list 't_rune_N          "un N runique"        pclass-wall      s_rune_N      trn 0 nil)
   (list 't_rune_O          "un O runique"        pclass-wall      s_rune_O      trn 0 nil)
   (list 't_rune_P          "un P runique"        pclass-wall      s_rune_P      trn 0 nil)
   (list 't_rune_Q          "un Q runique"        pclass-wall      s_rune_Q      trn 0 nil)
   (list 't_rune_R          "un R runique"        pclass-wall      s_rune_R      trn 0 nil)
   (list 't_rune_S          "un S runique"        pclass-wall      s_rune_S      trn 0 nil)
   (list 't_rune_T          "un T runique"        pclass-wall      s_rune_T      trn 0 nil)
   (list 't_rune_U          "un U runique"        pclass-wall      s_rune_U      trn 0 nil)
   (list 't_rune_V          "un V runique"        pclass-wall      s_rune_V      trn 0 nil)
   (list 't_rune_W          "un W runique"        pclass-wall      s_rune_W      trn 0 nil)
   (list 't_rune_X          "un X runique"        pclass-wall      s_rune_X      trn 0 nil)
   (list 't_rune_Y          "un Y runique"        pclass-wall      s_rune_Y      trn 0 nil)
   (list 't_rune_Z          "un Z runique"        pclass-wall      s_rune_Z      trn 0 nil)
   (list 't_rune_TH         "un TH runique"        pclass-wall      s_rune_TH     trn 0 nil)
   (list 't_rune_EE         "un EE runique"        pclass-wall      s_rune_EE     trn 0 nil)
   (list 't_rune_NG         "un NG runique"        pclass-wall      s_rune_NG     trn 0 nil)
   (list 't_rune_EA         "un EA runique"        pclass-wall      s_rune_EA     trn 0 nil)
   (list 't_rune_ST         "un ST runique"        pclass-wall      s_rune_ST     trn 0 nil)
   (list 't_rune_DOT        "un . runique"        pclass-wall      s_rune_DOTSEP trn 0 nil)
   (list 't_equip_sign    "une enseigne de magasin d'équipement" pclass-wall s_torch_sign      opq 0 nil)
   (list 't_weapon_sign   "une enseigne de magasin d'armes" pclass-wall s_shield_sign          opq 0 nil)
   (list 't_healer_sign   "une enseigne d'hôpital" pclass-wall s_ankh_sign              opq 0 nil)
   (list 't_tavern_sign   "un panneau de taverne" pclass-wall s_beer_sign                opq 0 nil)
   (list 't_inn_sign      "une enseigne d'auberge" pclass-wall s_bed_sign                   opq 0 nil) 
   (list 't_alchemy_sign      "une enseigne d'alchimiste" pclass-wall s_potion_sign        opq 0 nil) 
   (list 't_magic_sign      "une enseigne de magasin de réactifs" pclass-wall s_mushroom_sign    opq 0 nil) 
   (list 't_str_sign      "un signe de puissance" pclass-wall s_axe_sign            trn 1024 nil) 
   (list 't_dex_sign      "un signe de dextérité" pclass-wall s_key_sign           trn 1024 nil) 
   (list 't_wis_sign      "un signe de sagesse" pclass-wall s_book_sign             trn 1024 nil) 
   (list 't_nat_rock      "un mur en pierre naturelle" pclass-wall s_nat_rock            opq 0 nil) 
   (list 't_fake_wall_nrock  "un mur en pierre naturelle" pclass-forest  s_secret_nrock   opq 0 nil)
   ))

(map (lambda (terrain) (apply kern-mk-terrain terrain)) terrains)

;;----------------------------------------------------------------------------
;; Make some blended shore terrain types

(define (mk-shore-terrain tag . sprites)
  (kern-mk-terrain tag "eaux peu profondes" pclass-shoals
                   (mk-composite-sprite (cons s_shoals sprites))
                   trn 0 nil))

(mk-shore-terrain 't_shore_n  s_grass_n )
(mk-shore-terrain 't_shore_w  s_grass_w )
(mk-shore-terrain 't_shore_nw s_grass_nw)
(mk-shore-terrain 't_shore_e  s_grass_e )
(mk-shore-terrain 't_shore_ne s_grass_ne)
(mk-shore-terrain 't_shore_we s_grass_e s_grass_w)
(mk-shore-terrain 't_shore_nwe s_grass_ne s_grass_nw)
(mk-shore-terrain 't_shore_s  s_grass_s )
(mk-shore-terrain 't_shore_ns s_grass_s s_grass_n)
(mk-shore-terrain 't_shore_ws s_grass_sw)
(mk-shore-terrain 't_shore_nws s_grass_sw s_grass_nw)
(mk-shore-terrain 't_shore_es s_grass_se)
(mk-shore-terrain 't_shore_nes s_grass_se s_grass_ne)
(mk-shore-terrain 't_shore_wes s_grass_se s_grass_sw)
(mk-shore-terrain 't_shore_c s_grass_se s_grass_sw s_grass_ne s_grass_nw)

(define tset_shore
(list
   t_shoals    ;; 0: none
   t_shore_n   ;; 1: north
   t_shore_w   ;; 2: west
   t_shore_nw  ;; 3: north west
   t_shore_e   ;; 4: east
   t_shore_ne  ;; 5: east north
   t_shore_we  ;; 6: east west
   t_shore_nwe ;; 7: east west north
   t_shore_s   ;; 8: south
   t_shore_ns  ;; 9: south north
   t_shore_ws  ;; 10: south west
   t_shore_nws ;; 11: south west north
   t_shore_es  ;; 12: south east
   t_shore_nes ;; 13: south east north
   t_shore_wes ;; 14: south east west
   t_shore_c ;; 15: south east west north
   ))
   
(define tset_water
(append tset_shore
          (list t_shoals
                t_shallow
                t_deep
                t_sunlit_deep
                t_bridge_WE
                t_bridge_NS)))

;;----------------------------------------------------------------------------
;; bits of ship

;; regular terrains

(map
	(lambda (terrainentry)
		(apply
			(lambda (tag name pclass opacity sprite)
				(kern-mk-terrain tag name pclass sprite
					opacity 0 nil)
			)
			terrainentry
		)
	)
	(list
	
(list 't_bulwark_x_ns "pavois latéral" pclass-wall opq s_bulwark_ns)
(list 't_bulwark_x_ew "pavois latéral" pclass-wall opq s_bulwark_ew)
	
(list 't_bulwark_v_ne "rempart" pclass-boulder trn s_bulwark_sw)
(list 't_bulwark_v_nw "rempart" pclass-boulder trn s_bulwark_se)
(list 't_bulwark_v_se "rempart" pclass-boulder trn s_bulwark_nw)
(list 't_bulwark_v_sw "rempart" pclass-boulder trn s_bulwark_ne)
	
(list 't_bulwark_x_ne "pavois latéral" pclass-wall opq s_bulwark_sw)
(list 't_bulwark_x_nw "pavois latéral" pclass-wall opq s_bulwark_se)
(list 't_bulwark_x_se "pavois latéral" pclass-wall opq s_bulwark_nw)
(list 't_bulwark_x_sw "pavois latéral" pclass-wall opq s_bulwark_ne)

(list 't_stair_un "escaliers" pclass-grass trn s_stair_n)
(list 't_stair_uw "escaliers" pclass-grass trn s_stair_w)
(list 't_stair_ue "escaliers" pclass-grass trn s_stair_e)
(list 't_stair_us "escaliers" pclass-grass trn s_stair_s)

(list 't_tank_l "réservoir en métal" pclass-mountains opq s_tank_l)
(list 't_tank_d "réservoir en métal" pclass-mountains opq s_tank_d)
(list 't_tank_nw "réservoir en métal" pclass-mountains opq s_tank_nw)
(list 't_tank_ne "réservoir en métal" pclass-mountains opq s_tank_ne)
(list 't_tank_sw "réservoir en métal" pclass-mountains opq s_tank_sw)
(list 't_tank_se "réservoir en métal" pclass-mountains opq s_tank_se)

	)
)
	
		
;; composite terrains
(map
	(lambda (terrainentry)
		(apply
			(lambda (tag name pclass opacity sprites)
				(kern-mk-terrain tag name pclass (mk-composite-sprite sprites)
					opacity 0 nil)
				)
			terrainentry
		)
	)
	(list
	
(list 't_rail_ew "rambarde" pclass-boulder trn (list s_deck s_bulwark_ew))
(list 't_rail_ns "rambarde" pclass-boulder trn (list s_deck s_bulwark_ns))

(list 't_bulwark_n "rempart" pclass-boulder trn (list s_shallow s_deck_s s_bulwark_ew))
(list 't_bulwark_w "rempart" pclass-boulder trn (list s_shallow s_deck_e s_bulwark_ns))
(list 't_bulwark_e "rempart" pclass-boulder trn (list s_shallow s_deck_w s_bulwark_ns))
(list 't_bulwark_s "rempart" pclass-boulder trn (list s_shallow s_deck_n s_bulwark_ew))

(list 't_bulwark_v_n "rempart" pclass-boulder trn (list s_deck_s s_bulwark_ew))
(list 't_bulwark_v_w "rempart" pclass-boulder trn (list s_deck_e s_bulwark_ns))
(list 't_bulwark_v_e "rempart" pclass-boulder trn (list s_deck_w s_bulwark_ns))
(list 't_bulwark_v_s "rempart" pclass-boulder trn (list s_deck_n s_bulwark_ew))

(list 't_bulwark_w_ne "rempart" pclass-boulder trn (list s_shallow s_bulwark_sw))
(list 't_bulwark_w_nw "rempart" pclass-boulder trn (list s_shallow s_bulwark_se))
(list 't_bulwark_w_se "rempart" pclass-boulder trn (list s_shallow s_bulwark_nw))
(list 't_bulwark_w_sw "rempart" pclass-boulder trn (list s_shallow s_bulwark_ne))

(list 't_bulwark_d_ne "rempart" pclass-boulder trn (list s_deck s_bulwark_ne))
(list 't_bulwark_d_nw "rempart" pclass-boulder trn (list s_deck s_bulwark_nw))
(list 't_bulwark_d_se "rempart" pclass-boulder trn (list s_deck s_bulwark_se))
(list 't_bulwark_d_sw "rempart" pclass-boulder trn (list s_deck s_bulwark_sw))

(list 't_tank_d_nw "réservoir en métal" pclass-mountains opq (list s_deck s_tank_nw))
(list 't_tank_d_ne "réservoir en métal" pclass-mountains opq (list s_deck s_tank_ne))
(list 't_tank_d_sw "réservoir en métal" pclass-mountains opq (list s_deck s_tank_sw))
(list 't_tank_d_se "réservoir en métal" pclass-mountains opq (list s_deck s_tank_se))

	)
)
                                    
;;----------------------------------------------------------------------------

(define bad-terrain-list
  (list t_bog
        t_lava
        t_deep_lava
        t_fire_terrain
        t_fireplace
        t_inv_wall
        t_wall_torch
        ))

(define inflammable-terrain-list
  (list t_bog
        t_deep
        t_shallow
        t_shoals
        t_sunlit_deep
        t_stars
		t_void
		t_chasm
        ))
		
(load "blendterrains.scm")

(define (is-bad-terrain? kter)
  (in-list? kter bad-terrain-list))

(define (is-inflammable-terrain? kter)
  (in-list? kter inflammable-terrain-list))

(define (is-deck? kter)
	(in-list? kter 
		(list
			t_deck
			t_ship_hull
			t_ship_hull2
			t_mast
			t_ships_wheel
			
			t_bulwark_v_ne
			t_bulwark_v_nw
			t_bulwark_v_se
			t_bulwark_v_sw
			
			t_bulwark_n
			t_bulwark_w
			t_bulwark_e
			t_bulwark_s
			
			t_bulwark_w_ne
			t_bulwark_w_nw
			t_bulwark_w_se
			t_bulwark_w_sw
			
			t_bulwark_d_ne
			t_bulwark_d_nw
			t_bulwark_d_se
			t_bulwark_d_sw
			
			t_bulwark_v_n
			t_bulwark_v_w
			t_bulwark_v_e
			t_bulwark_v_s
	)))
