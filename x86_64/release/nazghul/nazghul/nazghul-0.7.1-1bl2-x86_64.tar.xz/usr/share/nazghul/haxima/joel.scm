;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------
(define joel-lvl 3)
(define joel-species sp_human)
(define joel-occ nil)

;;----------------------------------------------------------------------------
;; Schedule
;; 
;; In front of the Gate to Absalot.
;;----------------------------------------------------------------------------
(define joel-bed (list 'p_gate_to_absalot 8 9 1 1))
(define joel-mealplace joel-bed)
(define joel-workplace (list 'p_gate_to_absalot 7 10 5 5))
(define joel-leisureplace joel-workplace)
(kern-mk-sched 'sch_joel
               (list 0  0 joel-bed          "dort")
               (list 5  0 joel-mealplace    "mange")
               (list 6  0 joel-workplace    "travaille")
               (list 12 0 joel-mealplace    "mange")
               (list 13 0 joel-workplace    "travaille")
               (list 18 0 joel-mealplace    "mange")
               (list 19 0 joel-leisureplace "suis en pause")
               (list 21 0 joel-bed          "dort")
               )

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (joel-mk) nil)

;;----------------------------------------------------------------------------
;; Conv
;; 
;; Joel is a simple cowherd, whose stock is grazing in front of
;; the gates to the destroyed city of Absalot.
;;----------------------------------------------------------------------------

;; Basics...
(define (joel-hail knpc kpc)
  (kern-log-msg "Vous rencontrez un berger laconique.")
  (say knpc "Salut")
  )

(define (joel-default knpc kpc)
  (say knpc "Je ne sais pas, mon pote."))

(define (joel-name knpc kpc)
  (say knpc "Joel."))

(define (joel-join knpc kpc)
  (say knpc "Non."))

(define (joel-job knpc kpc)
  (say knpc "Je garde mes vaches ici. C'est agreable et paisible."))

(define (joel-peac knpc kpc)
  (say knpc "Oui. C'est l'ancienne porte d'Absalot."))

(define (joel-absa knpc kpc)
  (say knpc "Vous ne pensez pas à entrer là-dedans, n'est-ce pas ?")
  (if (yes? kpc)
      (say knpc "Faut être fou. Il y a des trucs degueulasses en bas.")
      (say knpc "Je ne vous blâme pas.")))

(define (joel-nast knpc kpc)
  (say knpc "Hypnotiseur ? Morts-vivants ? Qui sait ce qu'il y a d'autre ? L'endroit était déjà assez mauvais avant "
       "que les paladins l'ont scellé et l'ont laissé pourrir."))

(define (joel-fest knpc kpc)
  (say knpc "Les paladins de Glasdrin ont détruit Absalot. Et quand les humains se mettent à l'abri, "
	"les monstres s'y installent."))
	
(define (joel-gaze knpc kpc)
  (say knpc "Ils emprisonnent l'esprit. Et tout ce qu'ils contrôlent. "
       "Si vous ne faites pas attention, vous deviendrez aussi leur esclave."))
	   
(define (joel-unde knpc kpc)
  (say knpc "Des fantômes, des squelettes, et je préfère ne pas savoir quoi d'autre."))

(define (joel-bye knpc kpc)
  (say knpc "Au revoir."))

(define joel-conv
  (ifc basic-conv

       ;; basics
       (method 'default joel-default )
       (method 'bonj joel-hail )
	   (method 'hail joel-hail )
	   
       (method 'adie joel-bye )
       (method 'trav joel-job )
       (method 'nom joel-name )
       (method 'join joel-join )

       (method 'pais joel-peac )
       (method 'agre joel-peac )
       (method 'absa joel-absa )
       (method 'degu joel-nast )
       (method 'truc joel-nast )
       (method 'mons joel-nast )
       (method 'pour joel-fest )
       (method 'pala joel-fest )
       (method 'mort joel-unde )
       (method 'hypn joel-gaze )	   
       ))

(define (mk-joel)
  (bind 
   (kern-mk-char 
    'ch_joel           ; tag
    "Joel"             ; name
    joel-species         ; species
    joel-occ              ; occ
    s_companion_shepherd     ; sprite
    faction-men      ; starting alignment
    1 0 1            ; str/int/dex
    0 0              ; hp mod/mult
    0 0              ; mp mod/mult
    max-health ; hp
    -1                   ; xp
    max-health ; mp
    0
    joel-lvl
    #f               ; dead
    'joel-conv         ; conv
    sch_joel           ; sched
    'townsman-ai              ; special ai
    nil              ; container
    (list t_staff
					         )              ; readied
    )
   (joel-mk)))
