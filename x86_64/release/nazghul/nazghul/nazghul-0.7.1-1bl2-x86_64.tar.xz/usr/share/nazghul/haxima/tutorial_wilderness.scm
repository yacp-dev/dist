

(kern-mk-place 
 'p_tutorial_wilderness
 "le tutoriel 'Dans la nature sauvage'"
 nil          ; sprite 
 (kern-mk-map
  nil 19 19 pal_expanded
  (list
      "__ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ ^^ ^^ ^^ "
      "__ __ __ .. .. .. .. .. .. .. .. .. .. .. __ __ ^^ .. ^^ "
      "__ __ .. .. .. .. .. .. .. .. .. .. .. .. __ __ __ ee __ "
      "__ .. .. .. .. .. .. .. .. .. .. .. .. .. __ __ __ __ __ "
      "__ .. .. .. .. .. .. .. .. .. .. .. .. .. __ __ __ __ __ "
      "__ .. .. .. .. .. .. .. .. .. .. .. .. .. ee __ __ __ __ "
      "__ .. .. .. .. .. .. .. .. .. .. .. .. .. __ __ __ __ __ "
      "__ .. .. .. .. .. .. .. .. .. .. .. .. .. __ __ __ __ __ "
      "__ .. .. .. .. .. .. .. ^^ ^^ ^^ .. .. .. __ __ __ __ __ "
      "__ .. .. .. .. .. .. .. ^^ .. ^^ .. .. .. __ __ __ __ __ "
      "__ .. .. .. .. .. .. .. ^^ .. ^^ .. .. .. __ __ __ __ __ "
      "__ .. .. .. .. .. .. .. .. .. .. .. .. .. __ __ __ __ __ "
      "__ .. .. .. .. .. .. .. .. .. .. .. .. .. __ __ __ __ __ "
      "__ .. .. .. .. .. .. .. .. .. .. .. .. .. __ .. .. .. __ "
      "__ .. .. .. .. .. .. .. ^^ .. ^^ .. .. .. __ .. .. .. __ "
      "__ .. .. .. .. .. .. ^^ ^^ .. ^^ ^^ .. .. __ .. .. .. __ "
      "__ __ .. .. .. .. .. .. ^^ ^^ ^^ .. .. .. __ __ .. __ __ "
      "__ __ __ .. .. .. .. .. .. .. .. .. .. .. __ __ __ __ __ "
      "__ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ "
  )  )
 #f  ;; wraps
 #f  ;; underground
 #t  ;; wilderness
 #f  ;; tmp combat place

 ;; subplaces:
 (list
  (list p_tutorial_town 9 9)
  )

 nil ; neighborss

 ;; objects:
 (list

  (put (mk-step-clue "Attaquez les bandits au sud. (touche 'A')"
                     "Les combats se dérouleront sur une carte spéciale. "
                     "Lorsque le combat est terminé, appuyez sur '<' ou quittez simplement le bord de la carte.")
       9 10)
  (put (mk-npc-party 'bandit-party-l1) 9 13)
  (put (mk-step-clue "Vous pouvez camper dans la nature pour soigner votre équipe. Essayez-le maintenant. (touche 'K')") 9 13)
 
  (put (mk-step-clue "Entrez dans la grotte ci-dessous en y posant le pied.")
       9 14)
  (put (mk-dungeon 'p_tutorial_cave 7 17) 9 15)

  (put (mk-step-clue "Montez à bord du navire en marchant dessus et en appuyant sur la touche 'B'. "
                     "Ensuite, naviguez vers le quai dans le coin nord-est en utilisant les touches fléchées.") 14 5)
  (put (mk-step-clue "Faites feu avec vos canons sur les bandits de l'île en appuyant sur la touche 'F' et une flèche. "
                     "Un navire ne peut tirer que par le coté, vous devrez donc peut-être manoeuvrer un peu.") 
       15 4)
  (put (mk-step-clue "Faites feu avec vos canons sur les bandits de l'île en appuyant sur la touche 'F' et une flèche. "
                     "Un navire ne peut tirer que par le coté, vous devrez donc peut-être manoeuvrer un peu.") 
       15 6)
  (put (mk-step-clue "Faites feu avec vos canons sur les bandits de l'île en appuyant sur la touche 'F' et une flèche. "
                     "Un navire ne peut tirer que par le coté, vous devrez donc peut-être manoeuvrer un peu.") 
       16 5)

  (put (mk-ship) 15 5)
  (put (mk-npc-party 'bandit-party-l1) 16 14)

  (put (mk-step-clue "C'est tout pour le tutoriel. Vous trouverez de nombreuses autres informations dans le GUIDE_UTILISATEUR. "
                     "Vous le trouverez dans le répertoire 'doc' où vous avez installé le jeu, ou "
                     "vous pouvez en trouver un en ligne sur le site du projet. "
                     "Vous pouvez quitter le tutoriel maintenant en quittant le jeu avec la touche 'Q'. "
                     "Amusez-vous bien !") 17 1)
       
  ) ;; end of objects

 nil ; hooks
 nil ; edge entrances
 )
