;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------
(define thud-start-lvl  6)

;;----------------------------------------------------------------------------
;; Schedule
;; 
;; In Bole
;;----------------------------------------------------------------------------
(kern-mk-sched 'sch_thud
               (list 0  0  bole-bedroom-thud "suis en pause")
               (list 9  0  bole-dining-hall  "suis en pause")
               (list 10 0  bole-courtyard   "suis en pause")
               (list 12 0  bole-dining-hall   "suis en pause")
               (list 23 0  bole-bedroom-thud "suis en pause")
               )

;;----------------------------------------------------------------------------
;; Gob
;;
;; Quest flags, etc, go here.
;;----------------------------------------------------------------------------
(define (thud-mk) nil)

;;----------------------------------------------------------------------------
;; Conv
;; 
;; Thud is the bodyguard of Kathryn, and currently abides in Bole,
;; where they seek a certain thief.  Various other NPCs suggest
;; that Thud is at best half human, perhaps having ogre blood,
;; or a sorcerous (summoned or vat-born) origin...
;; 
;; Thud is a potential party member (and an eventual betrayer).
;; He accompanies Kathrun, and joins the party when and if she does.
;;----------------------------------------------------------------------------
(define (thud-hail knpc kpc)
  (say knpc "[Vous êtes certain que le personnage qui se trouve devant vous est en partie un ogre. "
       "Trois mètres de haut et brûlant de menace, il vous regarde "
       "avec des yeux à moitié fermés.]"))

(define (thud-default knpc kpc)
  (say knpc "[Son regard menaçant ne faiblit pas]"))

(define (thud-name knpc kpc)
  (say knpc "THUD pas aimer toi."))

(define (thud-join knpc kpc)
  (if (is-player-party-member? ch_kathryn)
      (begin
        (say knpc "[En voyant Kathryn avec vous, il grogne son consentement]")
        (kern-char-join-player knpc)
        (kern-conv-end))
      (say knpc "[il se moque]")))

(define (thud-job knpc kpc)
  (say knpc "Thud aimer tuer."))

(define (thud-kathryn knpc kpc)
  (say knpc "Thud pas tuer elle."))

(define (thud-thud knpc kpc)
  (say knpc "Toi parler à moi ? TOI PARLER A MOI ?! THUD VA GOUTER TES OS !!"))

(define (thud-thief knpc kpc)
  (say knpc "[Il devient furieux] Voleur jouer mauvais tour à THUD! THUD trouver VOLEUR!! THUD TUER VOLEUR !!!"))

(define (thud-find knpc kpc)
  (say knpc "[Il se calme un peu] dame rouge trouver voleur. Lui peut plus se cacher."))

(define (thud-red-lady knpc kpc)
  (say knpc "[Il vous donne un regard meurtrier] Toi pas approcher dame rouge !!!"))

(define thud-conv
  (ifc nil
       (method 'default thud-default )
       (method 'bonj thud-hail )
	   (method 'hail thud-hail )
	   
       (method 'adie (lambda (knpc kpc) 
                 (say knpc "[Ses yeux se plongent dans votre dos alors que vous vous éloignez]")))
       (method 'trav thud-job )
       (method 'nom thud-name )
       (method 'join thud-join )

       (method 'trou thud-find )
       (method 'kath thud-kathryn )
       (method 'tuer thud-job )
       (method 'dame thud-red-lady )
       (method 'aime thud-job )
       (method 'roug thud-red-lady )
       (method 'vole thud-thief )
       (method 'thud thud-thud )
       ))

;;----------------------------------------------------------------------------
;; First-time constructor
;;----------------------------------------------------------------------------
(define (mk-thud)
  (bind 
    (kern-char-arm-self
     (kern-mk-char 
      'ch_thud ;;.....tag
      "Thud" ;;.......name
      sp_troll ;;.....species
      oc_warrior ;;...occupation
      s_troll ;;......sprite
      faction-men ;;..faction
      4 ;;............custom strength modifier
      0 ;;............custom intelligence modifier
      2 ;;............custom dexterity modifier
      2 ;;............custom base hp modifier
      1 ;;............custom hp multiplier (per-level)
      0 ;;............custom base mp modifier
      0 ;;............custom mp multiplier (per-level)
      max-health;;..current hit points
      -1  ;;...........current experience points
      max-health ;;..current magic points
      0
      thud-start-lvl  ;;..current level
      #f ;;...........dead?
      'thud-conv ;;...conversation (optional)
      sch_thud ;;.....schedule (optional)
      'townsman-ai ;;..........custom ai (optional)
      nil ;;..........container (and contents)
      ;;.........readied arms (in addition to the container contents)
      (list
       t_2h_axe
       t_iron_helm
       t_armor_plate
       )
      nil ;;..........hooks in effect
      ))
   (thud-mk)))
