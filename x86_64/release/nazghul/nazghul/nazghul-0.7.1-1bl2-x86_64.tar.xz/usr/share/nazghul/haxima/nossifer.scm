;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------
(define nossifer-x 16)
(define nossifer-y 6)
(define noss-lvl 20)
(define noss-species sp_balron)
(define noss-occ oc_wizard)

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (noss-mk) (list #f))
(define (noss-spoke? gob) (car gob))
(define (noss-spoke! gob) (set-car! gob #t))

;;----------------------------------------------------------------------------
;; Conv
;;----------------------------------------------------------------------------

;; Basics...
(define (noss-hail knpc kpc)
  (say knpc "Je suis enfin invoqué ! Qui dois-je punir pour ce retard ?"))

(define (noss-default knpc kpc)
  (say knpc "Je tue les imbéciles qui gaspillent les mots avec moi."))

(define (noss-name knpc kpc)
  (say knpc "Je suis Nossifer, le Dormeur."))

(define (begin-last-battle knpc kpc)
  (say knpc "Votre âme ne connaîtra jamais la béatitude du Néant. "
       "Je la tourmenterai à JAMAIS !")
  (kern-being-set-base-faction knpc faction-demon)
  (kern-conv-end))

(define (noss-job knpc kpc)
  (say knpc "J'apporte l'oubli aux mondes. Vous avez entendu parler de sorciers qui invoquent des démons pour obéir à leurs ordres ?")
  (yes? kpc)
  (say knpc "Je convoque des hommes pour faire mon travail. Que pensez-vous être ?")
  (kern-log-msg "Il rit, et l'air pue le soufre.")
  (say knpc "Vous avez ouvert la voie et bien servi votre objectif. "
       "Maintenant, recevez votre récompense... ")
  (quest-data-update 'questentry-whereami 'nossifer 1)
  (kern-being-set-base-faction knpc faction-demon)
  (kern-conv-end))

(define (noss-bye knpc kpc)
  (say knpc "Pas encore. Nous avons des affaires non terminées à discuter.")
  (prompt-for-key)
  (noss-job knpc kpc))

(define noss-conv
  (ifc nil

       ;; basics
       (method 'default noss-default )
       (method 'bonj noss-hail )
	   (method 'hail noss-hail )
	   
       (method 'adie noss-bye )
       (method 'trav noss-job )
       (method 'nom noss-name )

       ))

(define (noss-ai kchar)
  (warlock-ai kchar))

(define (mk-nossifer)
  (let ((kchar (bind 
                 (kern-mk-char 
                  'ch_nossifer           ; tag
                  "Nossifer"             ; name
                  noss-species         ; species
                  noss-occ              ; occ
                  s_balron          ; sprite
                  faction-men      ; starting alignment
                  20 5 20            ; str/int/dex
                  0 5              ; hp mod/mult
                  0 2              ; mp mod/mult
                  max-health ; hp
                  0                   ; xp
                  max-health ; mp
                  0
                  noss-lvl
                  #f               ; dead
                  'noss-conv       ; conv
                  nil           ; sched
                  'noss-ai  ; special ai
                  nil              ; container
                  (list
                   t_flaming_sword
                   t_armor_plate
                   ))
                (noss-mk))))
    (map (lambda (eff) (kern-obj-add-effect kchar eff nil))
         demon-effects)
    (kern-obj-add-effect kchar ef_charm_immunity nil)
    kchar
    ))
