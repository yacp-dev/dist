;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------
(define mesmeme-lvl 2)
(define mesmeme-species sp_gazer)
(define mesmeme-occ oc_wizard)

;;----------------------------------------------------------------------------
;; Schedule
;;----------------------------------------------------------------------------
(kern-mk-sched 'sch_mesmeme
               (list 0  0 campfire-1 "dort")
               (list 9  0 cantina-6 "suis en pause")
               )

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (mesmeme-mk) nil)

;;----------------------------------------------------------------------------
;; Conv
;;----------------------------------------------------------------------------

;; Basics...
(define (mesmeme-hail knpc kpc)
  (kern-log-msg "Vous rencontrez un Hypnotiseur malmené.")
  (say knpc "Je te vois.")
  )

(define (mesmeme-default knpc kpc)
  (say knpc "Aucune connaissance. Pas demandé. Seul.")
  )

(define (mesmeme-name knpc kpc)
  (say knpc "Moi Mesmeme.")
  )

(define (mesmeme-leav knpc kpc)
  (if (is-player-party-member? knpc)
      (begin
		(say knpc "Être seul ?")
        (if (yes? kpc)
            (begin
              (if (kern-char-leave-player knpc)
                  (begin
                    (say knpc "Ici, attendre. Jusqu'au néant.")
                    (kern-conv-end))
                  (say knpc "Pas maintenant !")))
            (say knpc "Pas seul !")))
      (begin
		(say knpc "Jusqu'au néant.")
	    (kern-conv-end)))
  )

(define (mesmeme-join knpc kpc)
  (say knpc "Oui ! Moi seul.")
  (join-player knpc)
  (kern-conv-end)
  )

(define (mesmeme-job knpc kpc)
  (say knpc "Pas de travail. Pas de famille. Seul.")
  )

(define (mesmeme-bye knpc kpc)
  (say knpc "Jusqu'au néant.")
  )

(define (mesmeme-alon knpc kpc)
  (say knpc "Moi paralysé. Non ... penser une voix? Voix de l'esprit? Parle pas famille. Seul.")
  )

(define (mesmeme-kind knpc kpc)
  (say knpc "Famille. Hypnotiseur. Essaim.")
  )

(define (mesmeme-crip knpc kpc)
  (say knpc "Géant esclave, à moi. Trop fort. Libéré, blessé !")
  )

(define (mesmeme-slav knpc kpc)
  (say knpc "Outils. Mains. Un corps trop peu !")
  )

(define mesmeme-conv
  (ifc nil

       ;; basics
       (method 'default mesmeme-default )
       (method 'bonj mesmeme-hail )
	   (method 'hail mesmeme-hail )
	   
       (method 'adie mesmeme-bye )
       (method 'trav mesmeme-job )
       (method 'nom mesmeme-name )
       (method 'join mesmeme-join )
       (method 'part mesmeme-leav )
       
       (method 'seul mesmeme-alon )
       (method 'fami mesmeme-kind )
       (method 'para mesmeme-crip )
       (method 'escl mesmeme-slav )
       ))

(define (mk-mesmeme)
  (bind 
   (kern-mk-char 
    'ch_mesmeme           ; tag
    "Mesmeme"             ; name
    mesmeme-species         ; species
    mesmeme-occ              ; occ
    s_gazer     ; sprite
    faction-men      ; starting alignment
    0 0 0            ; str/int/dex
    (/ pc-hp-off 2)  ; hp bonus
    (/ pc-hp-gain 2) ; hp per-level bonus
    0 ; mp off
    1 ; mp gain
    max-health ; hp
    -1                   ; xp
    max-health ; mp
    0
    mesmeme-lvl
    #f               ; dead
    'mesmeme-conv         ; conv
    sch_mesmeme           ; sched
    'townsman-ai              ; special ai
    nil              ; container
    nil              ; readied
    )
   (mesmeme-mk)))
