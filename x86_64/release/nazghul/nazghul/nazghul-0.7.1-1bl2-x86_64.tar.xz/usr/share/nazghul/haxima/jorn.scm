;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------
(define jorn-lvl 5)
(define jorn-species sp_human)
(define jorn-occ oc_wrogue)

;;----------------------------------------------------------------------------
;; Schedule
;; 
;; In Green Tower.
;;----------------------------------------------------------------------------
(define jorn-bed gt-jorn-bed)
(define jorn-mealplace gt-ws-tbl1)
(define jorn-workplace gt-jorn-hut)
(define jorn-leisureplace gt-ws-hall)
(kern-mk-sched 'sch_jorn
               (list 0  0 jorn-bed          "dort")
               (list 11 0 jorn-mealplace    "mange")
               (list 12 0 jorn-workplace    "travaille")
               (list 18 0 jorn-mealplace    "mange")
               (list 19 0 jorn-leisureplace "suis en pause")
               (list 24 0 jorn-workplace    "travaille")               
               )

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (jorn-mk) nil)

(define (jorn-on-death knpc)
	(kern-obj-put-at (kern-mk-obj t_skull_ring_j 1) (kern-obj-get-location knpc))
	)

;;----------------------------------------------------------------------------
;; Conv
;; 
;; Jorn is a bravo and former pirate, currently living in Green Tower.
;; He was once a member of the crew of the Merciful Death, 
;; and is sought for vengeance by the ghost Ghertie.
;;----------------------------------------------------------------------------

;; Basics...
(define (jorn-hail knpc kpc)
  (say knpc "[Vous rencontrez un homme rude et revêche] Qu'est ce que vous voulez?"))

(define (jorn-default knpc kpc)
  (say knpc "Va embêter quelqu'un d'autre."))

(define (jorn-name knpc kpc)
  (say knpc "Je m'appelle Jorn. Déjà entendu parler de moi ?")
   (quest-data-update 'questentry-ghertie 'jorn-loc 1)
  (if (yes? kpc)
      (say knpc "Bien, alors vous êtes prévenu.")
      (say knpc "Dommage. Ne m'obligez pas à faire de vous un exemple.")))

(define (jorn-join knpc kpc)
  (say knpc "[Il rit grossièrement]"))

(define (jorn-job knpc kpc)
  (say knpc "Cela ne vous regarde pas."))

(define (jorn-bye knpc kpc)
  (say knpc "[Il ne vous regarde pas partir]"))


;; Town & Townspeople

;; Quest-related
(define (jorn-pira knpc kpc)
  (say knpc "Vous commencez à me taper sur les nerfs."))

(define (jorn-ring knpc kpc)
      (quest-data-update 'questentry-ghertie 'jorn-loc 1)
        (say knpc "[Il vous regarde froidement] Et alors ? La voulez-vous ?")
        (if (no? kpc)
            (say knpc "Alors, arrêtez de la regarder.")
            (begin
              (say knpc "Eh bien, faudra me couper le doigt "
                   "pour l'avoir. Qu'est ce que vous dites de ça ? Êtes-vous prêt à "
                   "essayer de me couper le doigt ?")
              (if (no? kpc)
                  (say knpc "[Il ricane] Je ne pense pas.")
                  (begin
                    (say knpc "[Avec un rugissement, trop rapide pour que vous puissiez voir, "
                         "il tire son épée et vous pousse dans le même "
                         "mouvement!]")
                    (kern-being-set-base-faction knpc faction-outlaw)
                    (kern-conv-end))))))

(define jorn-conv
  (ifc basic-conv

       ;; basics
       (method 'default jorn-default )
       (method 'bonj jorn-hail )
	   (method 'hail jorn-hail )
	   
       (method 'adie jorn-bye )
       (method 'trav jorn-job )
       (method 'nom jorn-name )
       (method 'join jorn-join )
       
       ;; other responses
       (method 'pira jorn-pira )
       (method 'gher jorn-pira )
       (method 'merc jorn-pira )
       (method 'bagu jorn-ring )

       ))

(define (mk-jorn)
	(let ((knpc
		(kern-mk-char 
			'ch_jorn           ; tag
			"Jorn"             ; name
			jorn-species     ; species
			jorn-occ         ; occ
			s_brigand        ; sprite
			faction-men      ; starting alignment
			2 0 1            ; str/int/dex
			0 0              ; hp mod/mult
			0 0              ; mp mod/mult
			max-health ; hp
			-1                ; xp
			max-health ; mp
			0
			jorn-lvl
			#f               ; dead
			'jorn-conv       ; conv
			sch_jorn           ; sched
			'spell-sword-ai  ; special ai

			;; container
			(mk-inventory (list
				(list 1 t_sword_2)
				(list 1 t_dagger_4)
				(list 1 t_armor_leather_2)
				(list 1 t_leather_helm_2)
				(list 67 t_gold_coins)
				(list 3 t_picklock)
				(list 3 t_heal_potion)
			))
			nil              ; readied
		)))
		(bind knpc  (jorn-mk))
		(kern-char-force-drop knpc #t)
		(kern-char-arm-self knpc)
		(kern-obj-add-effect knpc 
			ef_generic_death
			'jorn-on-death)
		knpc
	))
