;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------

;;----------------------------------------------------------------------------
;; Schedule
;; 
;; In Glasdrin.
;;----------------------------------------------------------------------------
(kern-mk-sched 'sch_ches
               (list 0  0  gc-bed       "dort")
               (list 7  0  ghg-s3       "mange")
               (list 8  0  gas-counter "travaille")
               (list 11 0  ghg-s3       "mange")
               (list 12 0  gas-counter "travaille")
               (list 18 0  ghg-s3       "mange")
               (list 19 0  ghg-hall     "suis en pause")
               (list 21 0  gc-bed       "dort")
               )

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (ches-mk) (list 'townsman))

;;----------------------------------------------------------------------------
;; Conv
;; 
;; Chester is a burly weaponsmith who lives in Glasdrin.
;;----------------------------------------------------------------------------

;; Basics...
(define (ches-hail knpc kpc)
  (say knpc "[Vous rencontrez un homme énorme avec des bras qui ressemblent à des troncs d'arbre] "
       "Salut, guerrier !"))

(define (ches-default knpc kpc)
  (say knpc "C'est au-delà de mes forces."))

(define (ches-name knpc kpc)
  (say knpc "Je m'appelle Chester, de la Hache et du Bouclier. "
       "Vous avez l'air d'un personnage sérieux, "
       "qui a besoin d'un armement sérieux. "
       "Je peux peut-être vous intéresser à quelque chose ?")
  (if (kern-conv-get-yes-no? kpc)
      (ches-trade knpc kpc)))

(define (ches-join knpc kpc)
  (say knpc "Non, mon ami, il faut bien que quelqu'un approvisionne les aventuriers !"))

(define (ches-job knpc kpc)
  (say knpc "Je vends les meilleures armes et armures du pays. "
       "Vous voulez jeter un coup d'oeil ?")
       (if (kern-conv-get-yes-no? kpc)
           (ches-trade knpc kpc)
           (say knpc "Pas de problème, c'est vous qui décidez. Vous ne trouverez pas mieux, "
                "Je vous l'assure.")))

(define (ches-bye knpc kpc)
  (say knpc "Adieu, et parlez à vos amis de ma boutique !"))

(define ches-catalog
  (list
   (list t_staff            20 "Equipez vos mages de baton pour qu'ils puissent se sentir utiles.")
   (list t_dagger           65 "Gardez toujours un ou deux poignards supplémentaires dans vos bottes.")
   (list t_mace             80 "La massue est une bonne arme pour broyer des crânes et casser des os.")
   (list t_axe              85 "Cette hache est tout indiquée pour fendre les boucliers.")
   (list t_sword            85 "L'épée est le cheval de labour de la classe combattante.")
   (list t_2H_axe           90 "Tu vas faucher tes ennemis autant que s'ils étaient de l'herbe avec mes haches à deux mains.")
   (list t_2H_sword        100 "Ah oui, mon préféré est le puissant sabre à deux mains.")
   (list t_morning_star    105 "Vos ennemis vous laisseront une grande marge de manœuvre lorsque vous donnerez un coup avec ce fléau d'arme.")
   (list t_halberd         150 "Avec la hallebarde, vos arrières peuvent renforcer votre front.")
   
   (list t_sling            50 "Si vous avez des enfants, une fronde fera une bonne arme de départ.")
   (list t_spear            15 "La lance est très populaire auprès des gobelins et autres sauvages.")

   (list t_self_bow        120 "Ces petits arcs sont parfaits pour la chasse aux petits animaux.")
   (list t_bow             200 "Les rangers aiment se faufiler dans les bois avec des arcs tels que  celui-ci.")
   (list t_arrow             1 "Si vous ne souhaitez pas affronter vos ennemis dans un combat viril, veillez à emporter beaucoup de flèches.")
   
   (list t_crossbow        380 "Lorsque vos ennemis fuient votre lame, faites-les tomber à l'aide d'une arbalète.")
   (list t_hvy_crossbow    600 "Lorsqu'il est assiégé, le guerrier viril se tourne vers l'une de ces beautés.")
   (list t_bolt              1 "La milice de Glasdrin exige les meilleures armes, et je suis leur seul fournisseur de carreaux.")
   
   (list t_leather_helm     50 "Le casque léger est parfait pour tous les combattants de votre équipe.")
   (list t_chain_coif      100 "La coiffe en chaîne protégera votre cou sans obstruer votre vision.")
   (list t_iron_helm       150 "Avec un casque de fer, vous pouvez charger la tête la première dans la mêlée la plus dense.")
   (list t_armor_leather   150 "L'armure en cuir ne vous ralentira pas, mais elle n'offre qu'une protection minimale.")
   (list t_armor_chain     330 "L'armure de chaînes est la préférée des paladins, et ils connaissent leur affaire.")
   (list t_armor_plate    1000 "Avec une armure de plaque, vous serez invincible au combat.")
   
   (list t_shield           30 "Un solide bouclier vous sauvera des ennemis féroces qui tirent de loin.")
   
   (list t_spiked_helm     250 "La meilleure défense est une bonne attaque ! Ce casque à pointes va prouver mon point de vue. Sans jeu de mots.")
   (list t_spiked_shield   250 "Avec le bouclier à pointes, vous n'avez pratiquement pas besoin d'arme.")
   ))

(define ches-merch-msgs
  (list "Passez à la Hache et au Bouclier quand je travaille, et je vous fournirai les meilleures armes et armures qu'on puisse acheter entre 9h00 et 18h00."
        "Venez voir mon armurerie !" ;; buy
        "Je vous offre une valeur de reprise sur vos armes usagées." ;; sell
        "J'équipe les meilleurs guerriers du pays. Que puis-je faire pour vous ?" ;; trade
        "Maintenant, allez frapper quelques crânes ! Et revenez quand vous aurez besoin d'une mise à niveau." ;; sold-something
        "Votre équipement semble un peu délabré, vous devriez y réfléchir." ;; sold-nothing
        "Maintenant, vous devriez acheter quelque chose pour remplacer cette vieille camelote." ;; bought-something
        "J'essayais seulement d'aider. Je pense que personne d'autre ne voudra de ces bêtises." ;; bought-nothing
        "Maintenant, vous êtes prêt à prendre d'assaut le Longeron des Géants !" ;; traded-something
        "Inspectez tout ce que vous voulez." ;; traded-nothing
        ))

;; Trade...
(define (ches-trade knpc kpc) (conv-trade knpc kpc "trade" ches-merch-msgs ches-catalog))
(define (ches-buy knpc kpc) (conv-trade knpc kpc "buy" ches-merch-msgs ches-catalog))
(define (ches-sell knpc kpc) (conv-trade knpc kpc "sell" ches-merch-msgs ches-catalog))

;; Paladins...
(define (ches-pala knpc kpc)
  (say knpc "J'ai servi plusieurs fois avec les paladins, mais ce n'est pas possible "
       "de faire fortune, j'ai donc pris ma retraite et ouvert mon magasin."))

;; Townspeople...
(define (ches-glas knpc kpc)
  (say knpc "Pas une mauvaise ville. Les affaires sont bonnes ici, "
       "avec les paladins et tout le reste."))

(define (ches-ange knpc kpc)
  (say knpc "Belle femme. Mais je les préfère un peu plus sauvages.")) 

(define (ches-patc knpc kpc)
  (say knpc "Je n'ai jamais été malade, mais on dit que c'est un bon guérisseur."))

(define (ches-jess knpc kpc)
  (say knpc "Voilà un beau morceau de chair de femme ! "
       "Dommage pour cette cicatrice, "
       "mais dans l'obscurité, tout est pareil, non ?"))

(define ches-conv
  (ifc glasdrin-conv

       ;; basics
       (method 'default ches-default )
       (method 'bonj ches-hail )
	   (method 'hail ches-hail )
	   
       (method 'adie ches-bye )
       (method 'trav ches-job )
       (method 'nom ches-name )
       (method 'join ches-join )
       
       ;; trade
       (method 'comm ches-trade )
       (method 'ache ches-buy )
       (method 'vend ches-sell )

       ;; paladin
       (method 'pala ches-pala )

       ;; town & people
       (method 'glas ches-glas )
       (method 'ange ches-ange )
       (method 'patc ches-patc )
       (method 'jess ches-jess )

       ))

(define (mk-chester)
  (bind 
   (kern-mk-char 'ch_chester         ; tag
                 "Chester"           ; name
                 sp_human            ; species
                 oc_warrior          ; occ
                 s_townsman          ; sprite
                 faction-glasdrin         ; starting alignment
                 5 0 2               ; str/int/dex
                 0 0                 ; hp mod/mult
                 0 0                 ; mp mod/mult
                 max-health -1 max-health 0 3  ; hp/xp/mp/AP_per_turn/lvl
                 #f                  ; dead
                 'ches-conv          ; conv
                 sch_ches            ; sched
                 'townsman-ai                 ; special ai
                 (mk-inventory (list (list 1 t_mace)
                                     (list 1 t_armor_chain))) ; container
                 nil ;;  readied
                 )
   (ches-mk)))
