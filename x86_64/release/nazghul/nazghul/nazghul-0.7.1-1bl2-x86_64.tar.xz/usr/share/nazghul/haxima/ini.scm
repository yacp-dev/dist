;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------

;;----------------------------------------------------------------------------
;; Schedule
;; 
;; In Glasdrin.
;;----------------------------------------------------------------------------
(kern-mk-sched 'sch_ini
               (list 0  0  gi-bed      "dort")
               (list 5  0  gs-altar    "suis en pause")
               (list 6  0  gc-train    "travaille")
               (list 12 0  ghg-s2      "mange")
               (list 13 0  gc-hall     "travaille")
               (list 18 0  ghg-s2      "mange")
               (list 19 0  ghg-hall    "suis en pause")
               (list 21 0  gi-bed      "dort")
               )

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (ini-mk) (list 'townsman #f))
(define (ini-will-join? ini) (cadr ini))
(define (ini-will-join! ini) (set-car! (cdr ini) #t))

;;----------------------------------------------------------------------------
;; Conv
;; 
;; Ini is a dispirited paladin, dwelling in Glasdrin.
;; He is loyal to the ideals lived by the Warritrix,
;; and offended by the corruption which produced her
;; assassination.
;; Ini is a potential party member.
;;----------------------------------------------------------------------------

;; Basics...
(define (ini-hail knpc kpc)
  (say knpc "[Vous rencontrez un paladin morose] Salut."))

(define (ini-default knpc kpc)
  (say knpc "Je ne peux pas vous aider à ce sujet."))

(define (ini-notyet knpc kpc)
  (say knpc "Je ne devrais probablement pas parler de cela à des civils."))

(define (ini-name knpc kpc)
  (say knpc "Je suis Inago, mais tout le monde m'appelle Ini."))

(define (ini-join knpc kpc)
  (if (is-player-party-member? knpc)
      (say knpc "Je suis déjà dans votre équipe. Maintenant, allons-y !")
      (let ((ini (kobj-gob-data knpc)))
        (if (ini-will-join? ini)
            (begin
              (say knpc "Je vous remercie ! Ne gaspillons pas de temps à trouver "
                   "la Warritrix !")
              (kern-conv-end)
              (join-player knpc))
            (say knpc "[Soupir] Mon devoir est avec les paladins.")
            ))))
        
(define (ini-lost knpc kpc)
   (let ((ini (kobj-gob-data knpc)))
     (if (ini-will-join? ini)
			(begin
  			(say knpc "L'entree des Salles Perdues est une caverne située loin au sud-ouest. "
  				"Trouvez un navire et naviguez vers ["
           (loc-x lost-halls-loc) ","
           (loc-y lost-halls-loc) "].")
			(quest-data-update-with 'questentry-rune-l 'know-hall 1 (quest-notify nil))
			(quest-data-update 'questentry-warritrix 'lost-hall-loc 1)
			)
  			(say knpc "Les Salles Perdues est un lieu très dangereux. Je vous conseille de rester à l'écart !"))))
     		
(define (ini-cave knpc kpc)
   (let ((ini (kobj-gob-data knpc)))
     (if (ini-will-join? ini)
     		(begin
     			(say knpc "Les Salles Perdues elles-mêmes sont au fond des cavernes.")
     			(say knpc (if (is-player-party-member? knpc) "Nous aurons" "Vous aurez") " besoin de chercher les grands escaliers, dans la partie nord des grottes.")
     			(say knpc "Faites très attention aux habitants qui peuplent le donjon !")
     			)
     		(ini-notyet knpc kpc))))
     		
(define (ini-inha knpc kpc)
   (let ((ini (kobj-gob-data knpc)))
     (if (ini-will-join? ini)
     		(begin
     			(say knpc "Chaque fois que nous essayons de nettoyer l'endroit, une autre bande de Géants ou de trolls décide de s'y installer.")
     			(say knpc (if (is-player-party-member? knpc) "Nous ferions" "Vous feriez") " mieux d'être préparé pour une longue et difficile bataille.")
     			)
     		(ini-notyet knpc kpc))))

(define (ini-stair knpc kpc)
   (let ((ini (kobj-gob-data knpc)))
     (if (ini-will-join? ini)
     		(begin
     			(say knpc "Je sais que les escaliers sont situés au nord, mais j'ai peur de n'avoir jamais été aussi loin, donc je ne connais pas leur emplacement précis.")
     			)
     		(ini-notyet knpc kpc))))
     			
(define (ini-job knpc kpc)
  (say knpc "Je suis un paladin. Mais je n'aime pas beaucoup ça."))

(define (ini-bye knpc kpc)
  (say knpc "Au revoir."))

(define (ini-warr knpc kpc)
  (cond ((player-stewardess-trial-done?)
                (say knpc "La justice a été rendue, et je peux maintenant pleurer sa perte." ))
	((player-found-warritrix?)
                (if (ask? knpc kpc "La Régisseuse est puissante, mais il y a un moyen de faire en sorte que justice soit faite. Un ancien chemin. Une voie dangereuse. Ecouterez-vous mes ordres ?")
                    (say knpc "Il y a une statue au centre de Glasdrin. "
                         "Si vous la frappez avec votre épée, vous invoquerez la plus ancienne loi de la ville, et un procès aura lieu. "
                         "Mais nous n'osons pas la frapper tant que nous n'avons pas de preuves convaincantes contre la Régisseuse, car si nos preuves font défaut, le jugement sera porté sur nous à la place !")
                    (say knpc "Nous ne pouvons pas laisser la Régisseuse s'en tirer comme ça. Quelqu'un doit lui demander des comptes !")))
	((quest-data-assigned? 'questentry-wise)
		 (say knpc "[Il se redresse un peu] Quelque chose ne va pas ! La Warritrix "
		      "est partie trop longtemps sans laisser de nouvelles. Le Commandant aurait dû envoyer "
		      "des équipes de recherche. Au lieu de cela, il reste assis sans rien faire, prétendant être "
		      "occupé par d'autres problèmes. Je sens un acte criminel. Allez-vous  "
		      "la chercher?")
		 (if (kern-conv-get-yes-no? kpc)
		     (begin
		       (say knpc "Je me joindrais à vous ! Je connais bien les profondeurs, et bien que mon "
			    "devoir soit ici, je n'obéirai pas à un ordre qui la laisse mourir.")
		       (ini-will-join! (kobj-gob-data knpc)))
		     (say knpc "Quelqu'un doit faire quelque chose ! Le royaume a une grande dette "
			  "envers elle.")))
	(else
		(say knpc "Vous cherchez la Warritrix ?")
		(if (kern-conv-get-yes-no? kpc)
			(begin
				(say knpc "Elle peut être difficile à trouver. Je crois qu'elle est en patrouille en ce moment même. ")
				(say knpc "Si vous voulez revenir plus tard, je jetterai un oeil et vous ferai savoir si elle est de retour")
			)
		))
	))

;; Paladin...
(define (ini-pala knpc kpc)
  (say knpc "J'ai été un paladin toute ma vie. Je ne suis pas très doué pour cela ; "
       "Je suis malade avant et après chaque bataille. Je suis surpris "
       "qu'ils me gardent ici, mais je suppose qu'ils ont juste besoin d'hommes. "
       "J'aurais arreté il y a longtemps, mais je ne sais pas quoi faire d'autre."
       ))

(define (ini-quit knpc kpc)
  (say knpc "J'ai réussi à économiser un peu de salaire. Je vais bientôt prendre ma retraite, acheter une ferme "
       "près de Trigrave, éloignez-vous de cet endroit. Réflechissez seulement : plus jamais de longues "
       "marches, plus besoin de dormir sur un sol pierreux dans les profondeurs sans lumière, "
       "plus besoin de se réveiller en voyant des monstres dévorer votre équipe au petit déjeuner."
       ))

;; Townspeople...
(define (ini-glas knpc kpc)
  (say knpc "C'est un endroit plutôt morne, vous ne trouvez pas ?")
  (kern-conv-get-yes-no? kpc)
  (say knpc "J'ai toujours voulu visiter la Tour verte, voir les arbres."))

(define (ini-ange knpc kpc)
  (say knpc "Une dame modeste. Une fois, je l'ai vue embrocher un gobelin des cavernes avec un poignard."))

(define (ini-spit knpc kpc)
  (say knpc "Elle a été affectée à mon escouade lors d'une patrouille de reconnaissance dans les "
       "collines. Nous venions à peine de survivre à une rencontre avec des Géants quand quelques "
       "gobelins des cavernes ont vu nous avions l'air de proies faciles. "
       "C'était risqué pendant un certain temps."))

(define (ini-patc knpc kpc)
  (say knpc "Je lui dois la vie."))

(define (ini-life knpc kpc)
  (say knpc "J'ai été tué une fois. Nous étions en patrouille dans les profondeurs, morts de fatigue "
       "après avoir fui un groupe de chevaliers de la mort qui a tué notre médecin, "
       "et nous avions campé en plein milieu d'un groupe de trolls endormis. ")
  (prompt-for-key)
  (say knpc
       "Ils se sont réveillés les premiers. En une minute, je me battais pour ma survie, "
       "et l'instant d'après, j'étais à l'hôpital en train de regarder Patch. "
       "Personne d'autre dans mon escouade n'a survécu."
       ))

(define ini-conv
  (ifc glasdrin-conv

       ;; basics
       (method 'default ini-default )
       (method 'bonj ini-hail )
	   (method 'hail ini-hail )
	   
       (method 'adie ini-bye )
       (method 'trav ini-job )
       (method 'nom ini-name )
       (method 'join ini-join )

       (method 'warr ini-warr )
       (method 'pala ini-pala )
       (method 'arre ini-quit )
       (method 'glas ini-glas )
       (method 'ange ini-ange )
       (method 'embr ini-spit )
       (method 'poig ini-spit )
       (method 'patc ini-patc )
       (method 'vie ini-life )
       
       (method 'perd ini-lost )
       (method 'sall ini-lost )
       (method 'cave ini-cave )
       (method 'entr ini-cave )
       (method 'esca ini-stair )
       (method 'nord ini-stair )
       (method 'fond ini-stair )
       (method 'gran ini-stair )
       (method 'habi ini-inha )
       (method 'atte ini-inha )
       (method 'donj ini-inha )
       
       ))
       
(define (mk-ini)
  (bind 
   (kern-mk-char 'ch_ini           ; tag
                 "Ini"             ; name
                 sp_human            ; species
                 oc_warrior          ; occ
                 s_companion_paladin ; sprite
                 faction-glasdrin         ; starting alignment
                 5 0 5               ; str/int/dex
                  pc-hp-off  ; hp bonus
                  pc-hp-gain ; hp per-level bonus
                  0 ; mp off
                  0 ; mp gain
                 max-health -1 max-health 0 3  ; hp/xp/mp/AP_per_turn/lvl
                 #f                  ; dead
                 'ini-conv         ; conv
                 sch_ini           ; sched
                 'townsman-ai                 ; special ai
                 nil                 ; container
                 (list t_armor_chain
                       t_chain_coif
                       t_halberd
                       ))         ; readied
   (ini-mk)))
