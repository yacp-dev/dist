;;----------------------------------------------------------------------------
;; Gob
;;
;; Quest flags, etc, go here.
;;----------------------------------------------------------------------------
(define (roland-mk free? joined? greeted?) (list free? joined? greeted?))
(define (roland-is-free? knpc) (car (kobj-gob-data knpc)))
(define (roland-joined? knpc) (cadr (kobj-gob-data knpc)))
(define (roland-greeted? knpc) (caddr (kobj-gob-data knpc)))
(define (roland-set-free! knpc) (set-car! (kobj-gob-data knpc) #t))
(define (roland-set-joined! knpc) (set-car! (cdr (kobj-gob-data knpc)) #t))
(define (roland-set-greeted! knpc) (set-car! (cddr (kobj-gob-data knpc)) #t))

(define roland-greetings
  (list
   "Enchanté !"
   "Salut, Vagabond !"
   ))

;;----------------------------------------------------------------------------
;; Custom AI
;; 
;; This AI controls Roland until he is freed. It constantly tries to pathfind
;; to the prison exit. Once it gets outside the cell it sets the "freed" flag
;; and resorts to the default kernel AI.
;;----------------------------------------------------------------------------
(define (roland-exit-point knpc)
  (mk-loc (kobj-place knpc)
          (rect-x slimey-cavern-prison-cell-exit)
          (rect-y slimey-cavern-prison-cell-exit)))

(define (roland-ai knpc)
  (define (out-of-cell?)
    (not (loc-in-rect? (kern-obj-get-location knpc)
                       slimey-cavern-prison-cell)))
  (define (try-to-escape)
    (kern-log-enable #f)
    (pathfind knpc (roland-exit-point knpc))
    (kern-log-enable #t))
  (define (set-free)
    (roland-set-free! knpc)
    (kern-char-set-ai knpc nil)
    (kern-being-set-base-faction knpc faction-men)
    )
  (or (roland-greeted? knpc)
      (and (any-player-party-member-visible? knpc)
           (begin
             (taunt knpc nil roland-greetings)
             (roland-set-greeted! knpc))))
  (if (out-of-cell?)
      (set-free knpc)
      (try-to-escape)))

;; Note: (can-pathfind? ...) will pathfind through the locked door nowadays, so
;; it cannot be relied on. Let's just let Roland try to get out and he'll know
;; he's free.
(define (roland-is-or-can-be-free? knpc)
  (roland-is-free? knpc))

(define (roland-join-player knpc)
  (or (roland-joined? knpc)
      (begin
        (join-player knpc)
        (roland-set-joined! knpc #t))))

;;----------------------------------------------------------------------------
;; Conv
;;
;; Roland is a knight errant, serving Lord Froederick.
;; He is currently imprisoned by bandits in a cell in the slimy cave.
;; Roland is a potential party member.
;;----------------------------------------------------------------------------
(define (roland-join knpc kpc)
  (if (is-player-party-member? knpc)
      (say knpc "Oui, je suis toujours avec vous. Continuons !")
      (if (roland-joined? knpc)
          (begin
            (say knpc "Je suis honoré de me joindre à vous.")
            (join-player knpc)
            (kern-conv-end)
            )
          (if (roland-is-or-can-be-free? knpc)
              ;; yes - will the player accept his continued allegiance to
              ;; Froederick?
              (begin
                (say knpc "Je vous remercie de m'avoir liberé ! Je vous dois la vie, et je me joindrai volontiers à vous. Qu'en dites-vous ?")
                (if (yes? kpc)
                    (begin
                      (say knpc "Je suis honoré ! Ces vils voyous ont pris mon "
                           "coffre en fer qui contient mon matériel. Il devrait être "
                           "dans un endroit par ici.")
                      (roland-join-player knpc))
                    (say knpc "[Triste] Comme vous voulez.")))
              (say knpc "Je suis enfermé dans cette cellule ! Liberez-moi de ce déshonneur, "
                   "et vous gagnerez un allié.")
              ))))
  
(define roland-conv
  (ifc basic-conv
       ;; default if the only "keyword" which may (indeed must!) be longer than
       ;; 4 characters. The 4-char limit arises from the kernel's practice of
       ;; truncating all player queries to the first four characters. Default,
       ;; on the other hand, is a feature of the ifc mechanism (see ifc.scm).
       (method 'default (lambda (knpc kpc) 
                 (say knpc "Je crains de ne pas pouvoir vous aider à ce sujet.")))
       (method 'bonj (lambda (knpc kpc) 
                 (if (roland-joined? knpc)
                     (say knpc "Je vous aiderai de toutes les manières possibles.")
                     (roland-join knpc kpc))))

       (method 'hail (lambda (knpc kpc) 
                 (if (roland-joined? knpc)
                     (say knpc "Je vous aiderai de toutes les manières possibles.")
                     (roland-join knpc kpc))))



       (method 'adie (lambda (knpc kpc) (say knpc "Adieu.")))
       (method 'trav (lambda (knpc kpc) 
                 (say knpc "Je suis un chevalier errant.")))
       (method 'nom (lambda (knpc kpc) (say knpc "Je suis Roland.")))
       (method 'join roland-join )

       (method 'cell (lambda (knpc kpc)
                 (say knpc "Pour ouvrir une porte verrouillée, utilisez des crochets. Ou bien, lancez "
                      "un sortilège de déverrouillage.")))
       (method 'clov (lambda (knpc kpc)
                 (say knpc "J'étais avec lui le jour où il est tombé au combat. "
                      "L'ennemi nous a tendu une embuscade, et j'ai été assommé. "
                      "J'ai rêvé qu'une bête hideuse entraînait le roi dans Tartos. "
                      "Quand je me suis réveillé, j'étais dans un hôpital du camp.")))
       (method 'libe (lambda (knpc kpc)
                 (say knpc "J'ai été piégé et kidnappé par les bandits dans cette "
                      "grotte. Ils m'ont enfermé dans cette cellule pour me m'échanger "
                      "contre une rançon.")))
       (method 'croc (lambda (knpc kpc)
                 (say knpc "Les bandits et les voleurs portent généralement des crochets de serrures.")))
       (method 'sort (lambda (knpc kpc)
                 (say knpc "Vous devriez vous renseigner auprès d'un sorcier sur les sorts.")))
       (method 'trig (lambda (knpc kpc) 
                 (say knpc "Je sais que Trigave est une petite ville, un carrefour au "
                      "nord, avec beaucoup d'histoires.")))
       (method 'chev (lambda (knpc kpc)
                 (say knpc "J'étais un écuyer du roi Clovis dans les guerres des gobelins. "
                      "Quand les guerres ont pris fin, je me suis mis à errer.")
                 ))
       ))

;;----------------------------------------------------------------------------
;; First-time constructor
;;----------------------------------------------------------------------------
(define (mk-roland)
  (bind 
    (kern-mk-char 
     'ch_roland          ; tag
     "Roland"            ; name
     sp_human            ; species
     oc_warrior          ; occ
     s_knight            ; sprite
     faction-prisoner    ; starting alignment
     6 0 6               ; str/int/dex
     pc-hp-off           ; hp bonus
     pc-hp-gain          ; hp per-level bonus
     0                   ; mp off
     0                   ; mp gain
     max-health          ; hp
     -1                  ; xp
     max-health          ; mp
     0                   ; ap
     3                   ; lvl
     #f                  ; dead
     'roland-conv        ; conv
     nil                 ; sched
     'roland-ai          ; special ai
     nil                 ; container
     nil                 ; readied
     )
    (roland-mk #f #f #f)))
