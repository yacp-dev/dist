;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------

;;----------------------------------------------------------------------------
;; Schedule
;; 
;; In Glasdrin
;;----------------------------------------------------------------------------
(kern-mk-sched 'sch_stew
               (list 0  0  gv-bed       "dort")
               (list 7  0  ghg-s4       "mange")
               (list 8  0  gc-hall "suis en pause")
               (list 12 0  ghg-s1       "mange")
               (list 13 0  gc-hall "suis en pause")
               (list 18 0  ghg-s1       "mange")
               (list 19 0  gc-hall "suis en pause")
               (list 20 0  gv-bed       "dort")
               )

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (stew-mk) (list 'townsman #f))
(define (stew-met? stew) (cadr stew))
(define (stew-met! stew) (set-car! (cdr stew) #t))

;;----------------------------------------------------------------------------
;; Conv
;; 
;; Victoria is the temporal ruler of Glasdrin, 
;; bearing the title of Stewardess.
;;----------------------------------------------------------------------------

;; Basics...
(define (stew-hail knpc kpc)
  (if (not (stew-met? (kobj-gob-data knpc)))
      (begin
        (say knpc "[Vous rencontrez une femme majestueuse avec un air d'autorité] "
             "Salut, Vagabond. J'ai entendu parler de ta venue.")
        (stew-met! (kobj-gob-data knpc)))
      (say knpc "[Vous rencontrez une femme majestueuse avec un air d'autorité] "
           "Je te salue encore, Vagabond.")))

(define (stew-default knpc kpc)
  (say knpc "Je ne peux pas t'aider à ce sujet."))

(define (stew-name knpc kpc)
  (say knpc "Je suis Victoria, Regisseuse de Glasdrin."))

(define (stew-join knpc kpc)
  (say knpc "Quelle audace !"))

(define (stew-job knpc kpc)
  (say knpc "Je suis la Regisseuse de Glasdrin."))

(define (stew-bye knpc kpc)
  (say knpc "Reste sur le chemin, Vagabond."))

;; Warritrix...
(define (stew-warr knpc kpc)
  (cond ((player-found-warritrix?)
      (if (ask? knpc kpc "J'ai entendu parler de sa mort. Vous ne pensez sûrement pas que j'ai quelque chose à voir avec cela ?")
          (begin
            (say knpc "Si vous osez m'accuser, frappez la statue dans la cour. "
                 "Mais je vous préviens : vous êtes un itinérant sans abri, et je suis la dirigeante de la ville la plus puissante du pays. "
                 "Ce sera ma parole contre la vôtre, et nous traitons sévèrement les faux accusateurs.")
            (aside kpc 'ch_ini "Ne doute pas, sorcière perfide, que nous t'accuserons, "
                   "et avec plus que des paroles.")
            )
          (say knpc "Bien sûr que non. Ignorez les rumeurs. Elles sont propagées par des rivaux politiques jaloux.")
          ))
      ((quest-data-assigned? 'questentry-wise)
		(say knpc "Je ne l'ai pas vue depuis un certain temps. Je crois qu'elle a été appelée pour une mission.")
		(quest-data-update 'questentry-warritrix 'assignment 1)
		)
	(else
		(say knpc "Un de nos meilleurs guerriers. Je crois qu'elle est en patrouille en ce moment.")
		 (quest-data-update 'questentry-warritrix 'general-loc 1)
		 )
      ))

(define (stew-erra knpc kpc)
  (say knpc "Parlez avec le commandant Jeffries, il connaît peut-être les détails."))

;; Steward...
(define (stew-stew knpc kpc)
  (say knpc "Glasdrin est dirigée par un Regisseur élu, "
       "qui est chargé de la garde de la ville et du royaume. "
       ))

(define (stew-real knpc kpc)
  (say knpc "Le royaume de Glasdrin s'étend à l'ouest jusqu'aux Marais et au sud-est jusqu'à "
       "la Grande Forêt. Nous maintenons également une présence entre la surface et "
       "le monde Souterrain."))

;; Rune...
(define (stew-rune knpc kpc)
	(if (quest-data-assigned? 'questentry-wise)
		(say knpc "Je sais que la Warritrix avait ...heu.. a une Rune autour de son cou, "
			"mais je ne sais pas ce que cela signifie.")
		(say knpc "Je sais que la Warritrix porte une rune autour de son cou, "
			"mais je ne sais pas ce que cela signifie.")
		)
       (quest-data-assign-once 'questentry-rune-l)
       )

(define (stew-wore knpc kpc)
	(if (quest-data-assigned? 'questentry-wise)
		(say knpc "Qu'est-ce que vous insinuez ? Ce n'était qu'un lapsus.")
		(stew-default knpc kpc)
	))

;; Absalot...
(define (stew-absa knpc kpc)
  (say knpc "Absalot était un cancer de la terre. Il fallait l'enlever "
       "complètement avant que son mal ne se répande. Vous voyez sûrement la sagesse "
       "de cela ?")
  (if (kern-conv-get-yes-no? kpc)
      (say knpc "La perte de vies innocentes est toujours une tragédie, mais c'est "
           "impossible de faire la guerre sans elles.")
      (say knpc "Que savez-vous des affaires de l'État ? Vous n'êtes guère plus "
           "qu'un simple voyou.")))

(define (stew-inno knpc kpc)
  (say knpc "Tous les citoyens d'Absalot n'étaient pas mechants, "
       "mais ils toléraient la mechanceté en leur sein."))

(define (stew-wick knpc kpc)
  (say knpc "Le peuple d'Absalot s'est engagé dans des sacrifices humains et "
       "le culte du démon. Ils ont commencé à avoir des convertis dans d'autres villes, "
       "même ici."))

(define (stew-conv knpc kpc)
  (say knpc "Lorsque nous avons appris leur existence, nous les avons brûlés sur le bûcher. "
       "J'ai rencontré les Sages et les dirigeants des autres villes pour décider "
       "de ce qu'il faut faire.")
  (prompt-for-key)
  (say knpc "Certains des Sages étaient délicats, mais en fin de compte "
       "nous avons passé outre leur dissidence et avons formé une armée de coalition. "
       "Elle a marché sur Absalot, l'a rasé et a scellé "
       "le passage afin que plus jamais personne ne puisse construire sur ce site."))

(define (stew-wise knpc kpc)
  (say knpc "Les Sages sont une aide aux dirigeants des villes, mais seuls ils "
       "ont peu de pouvoir. Même l'Enchanteur ne pouvait pas s'opposer à la "
       "la puissance armée de Glasdrin si jamais il se mettait en travers de notre chemin.")
       (quest-wise-subinit 'questentry-enchanter)
       )

(define (stew-rogu knpc kpc)
  (say knpc "D'où venez-vous ? Quel est votre but dans notre pays ? "
       "Pour autant que nous sachions, vous êtes un espion, un éclaireur à l'avant-garde d'une "
       "larmée étrangère. L'êtes-vous ?")
  (if (kern-conv-get-yes-no? kpc)
      (say knpc "Hmm. Si je vous croyais, je vous jetterais aux inquisiteurs "
           "et vous tortureront pour faire sortir la vérité. Mais je pense que vous êtes un vantard "
           "et un imbécile gonflé d'orgueil. Vous disparaîtrez dans l'obscurité comme "
           "les Vagabonds qui vous ont précédé.")
      (say knpc "Non, je pense que vous n'êtes qu'un Vagabond, ici par "
           "accident. Néanmoins, je vous surveillerai de près, "
           "Vagabond. Si tu trahis ma ville, tu connaîtras ma colère "
           "aux mains de nos tortionnaires."))
  (kern-conv-end))

;; Townspeople...
(define (stew-glas knpc kpc)
  (say knpc "Glasdrin est un phare de lumière en ces temps sombres. "
       "À maintes reprises, ses paladins se sont sacrifiés pour le bien "
       "du royaume, et a fait reculer la marée des ténèbres. La Péninsule "
       "doit beaucoup à cette ville."))

(define (stew-unde knpc kpc)
  (say knpc "Le monde souterrain est un royaume sans soleil où les monstres se reproduisent. "
       "Je m'engage à la purger de ces créatures maléfiques, "
       "car ils sont une menace pour tous."))

(define stew-conv
  (ifc glasdrin-conv

       ;; basics
       (method 'default stew-default )
       (method 'bonj stew-hail )
	   (method 'hail stew-hail )
	   
       (method 'adie stew-bye )
       (method 'trav stew-job )
       (method 'nom stew-name )
       (method 'join stew-join )

       (method 'vill stew-glas )
       (method 'glas stew-glas )
       (method 'warr stew-warr )
       (method 'miss stew-erra )
       (method 'regi stew-stew )
       (method 'roya stew-real )
       (method 'absa stew-absa )
       (method 'avai stew-wore )
       (method 'rune stew-rune )
       (method 'inno stew-inno )
       (method 'mech stew-wick )
       (method 'conv stew-conv )
       (method 'sage stew-wise )
       (method 'voyo stew-rogu )
       (method 'sout stew-unde )
       ))

(define (mk-steward)
  (bind 
   (kern-char-force-drop
    (kern-mk-char 'ch_steward         ; tag
                  "Victoria"          ; name
                  sp_human            ; species
                  nil                 ; occ
                  s_lady              ; sprite
                  faction-glasdrin         ; starting alignment
                  1 3 0               ; str/int/dex
                  0 0                 ; hp mod/mult
                  0 0                 ; mp mod/mult
                  max-health -1 max-health 0 6  ; hp/xp/mp/AP_per_turn/lvl
                  #f                  ; dead
                  'stew-conv          ; conv
                  sch_stew            ; sched
                  'townsman-ai                 ; special ai
                  (mk-inventory (list (list 1 t_sword_4)
                                      (list 1 t_stewardess_chest_key)
                                      ))    ; container
                  nil                 ; readied
                  )
    #t)
   (stew-mk)))
