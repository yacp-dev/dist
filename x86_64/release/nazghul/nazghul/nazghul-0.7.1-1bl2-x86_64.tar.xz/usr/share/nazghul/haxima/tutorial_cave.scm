;;----------------------------------------------------------------------------
;; Map
;;----------------------------------------------------------------------------
(mk-dungeon-room
 'p_tutorial_cave "le Tutoriel 'Dans la grotte'"
 (list
      "rr rr rr rr rr rr rr rr rr rr rr rr rr rr rr rr rr rr rr "
      "rr rr rr rr rr rr rr rr rr rr rr rr rr rr rr rr rr rr rr "
      "rr rr rr rr rr rr rr rr rr rr rr rr rr rr rr rr rr rr rr "
      "rr rr rr rr rr rr rr rr rr rr rr rr rr rr rr rr rr rr rr "
      "rr %% %% rr rr tt .. .. .. tt rr rr rr {{ rr rr rr rr rr "
      "rr %% rr rr || .. .. .. .. .. || rr rr tt {{ rr rr rr rr "
      "rr %% rr tt %% bb .. .. .. bb %% || rr .. tt rr rr rr rr "
      "rr %% rr %% %% %% %% .. .. %% %% tt rr .. tt rr rr rr rr "
      "rr rr rr tt %% bb %% .. .. bb %% %% rr .. {{ rr rr rr rr "
      "rr .. || || %% %% .. .. .. %% %% %% rr {{ {{ rr rr rr rr "
      "rr .. rr || %% bb .. %% %% bb %% %% rr {{ {{ rr rr rr rr "
      "rr tt rr tt %% .. .. .. %% %% tt tt rr .. {{ rr rr rr rr "
      "rr tt rr %% %% bb .. .. .. bb || || rr .. {{ rr rr rr rr "
      "rr tt rr rr tt %% .. .. .. tt || rr rr .. tt rr rr rr rr "
      "rr .. tt rr rr rr .. .. .. rr rr rr .. .. tt rr rr rr rr "
      "rr .. .. .. && rr .. .. .. rr .. .. .. tt || rr rr rr rr "
      "rr .. .. .. .. rr .. .. .. rr .. .. tt || rr rr rr rr rr "
      "rr rr tt .. .. rr rr .. rr rr tt tt || rr rr rr rr rr rr "
      "rr rr rr rr rr rr rr rr rr rr rr rr rr rr rr rr rr rr rr "
  )
 (put (spawn-pt 'bat) 7 7)
 (put (mk-step-clue "Ce serait le bon moment pour U)tiliser une torche !") 7 15)
 (put (mk-step-clue "Tuez la chauve-souris, puis passez en mode 'Suivre' (touche F) et regardez autour de vous. "
                    "Lorsque vous avez terminé, retournez à l'échelle et appuyez sur la touche E pour pour remonter.")
      7 14)
 (put (mk-ladder-up 'p_tutorial_wilderness 9 15) 7 17)
 )
