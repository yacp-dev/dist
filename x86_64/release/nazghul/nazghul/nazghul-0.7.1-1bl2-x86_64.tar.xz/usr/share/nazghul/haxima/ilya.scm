;;----------------------------------------------------------------------------
;; Schedule
;;
;; The schedule below is for the place "Gregor's Hut".
;;----------------------------------------------------------------------------
(kern-mk-sched 'sch_ilya
               (list 0  0  gh-ilyas-bed   "dort")
               (list 6  0  gh-stable      "travaille")
               (list 7  0  gh-kitchen     "travaille")
               (list 12 0  gh-table-1     "mange")
               (list 13 0  gh-pasture     "travaille")
               (list 15 0  gh-all         "suis en pause")
               (list 17 0  gh-table-1     "mange")
               (list 18 0  gh-living-room "suis en pause")
               (list 20 0  gh-ilyas-bed   "dort"))

;;----------------------------------------------------------------------------
;; Gob
;;
;; Ilya's quest is to find her stuffed horse, which she left behind at the
;; homestead when she fled the trolls that killed her family. The quest flags
;; are stored in her gob.
;;----------------------------------------------------------------------------
(define (ilya-mk gave-quest? finished-quest?) 
  (list gave-quest? finished-quest?))
(define (ilya-gave-quest? ilya) (car ilya))
(define (ilya-quest-done? ilya) (cadr ilya))
(define (ilya-give-quest ilya) (set-car! ilya #t))
(define (ilya-finish-quest ilya) (set-car! (cdr ilya) #t))

;;----------------------------------------------------------------------------
;; Puska
;;
;; Puska -- ilya's stuffed horse toy -- is a quest item. Nothing special about
;; it really but it is unique and needs its own object type. The object itself
;; is declared in the p_abandoned_cellar constructor. But the type declaration
;; needs to be in a file that is reloaded, so here is as good a place as any.
;;----------------------------------------------------------------------------
(define puska-ifc
  (ifc '()
       (method 'get (lambda (kobj getter)
                      (kern-log-msg "Un enfant a probablement perdu ce jouet !")
                      (kobj-get kobj getter)))))

(mk-obj-type 't_puska "cheval en peluche" s_toy_horse layer-item puska-ifc)

;;----------------------------------------------------------------------------
;; Quest
;;
;; This is a single response in Ilya's conversation. I've called it our here
;; separately to make it obvious.
;;----------------------------------------------------------------------------
(define (ilya-quest knpc kpc)
  (let ((ilya (kobj-gob-data knpc)))
    (display ilya)(newline)
    (if (ilya-gave-quest? ilya)

        ;; yes - gave quest already
        (if (ilya-quest-done? ilya)
            (say knpc "Puska est heureuse maintenant !")
            (begin
              (say knpc "Avez-vous trouvé Puska ?")
              (if (kern-conv-get-yes-no? kpc)

                  ;; yes - puska found
                  (begin 
                    (say knpc "Puis-je l'avoir, s'il vous plaît ?")
                    (if (kern-conv-get-yes-no? kpc)

                        ;; yes - ilya may have puska
                        (if (kern-obj-has? kpc t_puska)

                            ;; yes - player has puska
                            (begin
                              (kern-obj-remove-from-inventory kpc t_puska 1)
                              (say knpc "Là, là, Puska. "
                                   "Tu es en sécurité avec moi. [Elle se tourne vers vous] Merci beaucoup ! J'aimerais pouvoir vous payer. "
                                   "Attends, prends ça, maman a dit que les sorciers s'en servaient, alors je les choisis quand je peux.")
                              (ilya-finish-quest ilya)
                              (kern-obj-add-to-inventory kpc nightshade 23)
                              )

                            ;; no - puska not in player inventory
                            (begin
                              (say knpc "[Snif!] Vous ne l'avez pas !")
                              (kern-conv-end)))

                        ;; no - ilya can't have puska
                        (begin
                          (say knpc "Quand je serai grande, je serai une sorcière ! "
                               "Et je TE BRULERAI COMME UN BOUT DE CHARBON!")
                          (kern-conv-end))))

                  ;; no - didn't find her yet
                  (begin
                    (say knpc "Vous souvenez-vous de l'endroit où se trouvait notre ferme ?")
                    (if (kern-conv-get-yes-no? kpc)
                        (say knpc "Elle doit être là pas très loin !")
                        (say knpc "A l'ouest par le col, puis au nord contre les collines."))))))

        ;; no - didn't give quest yet
        (begin
          (say knpc "Puska est mon cheval en peluche. Mais je l'ai perdu ! "
               "Si vous la trouvez, vous me le direz ?")
          (if (kern-conv-get-yes-no? kpc)
              (begin
                (say knpc "Notre ferme était à l'ouest par le col, puis au nord contre les collines. "
                     "Faites attention aux trolls !")
                (ilya-give-quest ilya))
              (begin
                (say knpc "Si tu la gardes, je te retrouverai quand je serai grande.")
                (kern-conv-end)))))))

(define (ilya-join knpc kpc)
  (say knpc "Je ne suis qu'une petite fille, idiot!")
  )

;;----------------------------------------------------------------------------
;; Animals
;;
;; Ilya has an odd relationship with spiders. She'll teach the player a spell
;; to ward off spiders if he plays along. Spiders will dominate the woods
;; around the Abandoned Farm (Ilya's old home). In fact, I intend to have them
;; locked in a battle with the trolls the first time the player enters the
;; Abandoned Farm. I'm planning on having a "great mother" spider known around
;; these parts as Angril or Angriss, perhaps she was one of Ilya's pets as a
;; child - I'm not sure how I want to play that one out yet.
;;----------------------------------------------------------------------------
(define (ilya-animals knpc kpc)
  (say knpc "Nous avons quelques moutons, et Charm le chat, et quelques poulets. "
       "Aimez-vous les animaux ?")
  (if (kern-conv-get-yes-no? kpc)

      ;; yes - the player likes animals
      (begin
        (say knpc "Quel est votre animal préféré ?")
        (let ((fav (kern-conv-get-reply kpc)))
          (if (eq? fav 'spid)

              ;; yes - the player's favorite animal is spiders
              (begin
                (say knpc "Le mien aussi ! Je sais comment les rendre inoffensifs. "
                     "Tu veux que je t'apprenne ?")
                (if (kern-conv-get-yes-no? kpc)

                    ;; yes - the player wants to learn the spider ward
                    (say knpc "C'est facile ! Mélangez de la soie d'araignée et de l'ail, "
                         "et chantez An Xen Bet.")

                    ;; no - the player does not want to learn the spider ward
                    (say knpc "D'accord, mais ils attaquent parfois les gens.")))
                    

              ;; no - the player's favorite animal is NOT spiders
              (say knpc "Les araignées sont mes préférées !"))))

      ;; no - the player does not like animals
      (say knpc "Eh bien, ne leur faites pas de mal !")))

(define (ilya-fire knpc kpc)
  (say knpc "Faire du feu, c'est facile. Il suffit de mélanger de la perle noire et des sulfreux ..."
       " sulefreux...heu ... ce truc comme de la cendre vous savez ? "
       "Et dites Vas Flam!"))

;;----------------------------------------------------------------------------
;; Conv
;;----------------------------------------------------------------------------
(define ilya-conv
  (ifc basic-conv
       ;; default if the only "keyword" which may (indeed must!) be longer than
       ;; 4 characters. The 4-char limit arises from the kernel's practice of
       ;; truncating all player queries to the first four characters. Default,
       ;; on the other hand, is a feature of the ifc mechanism (see ifc.scm).
       (method 'default (lambda (knpc kpc) (say knpc "Je ne sais pas.")))
       (method 'bonj (lambda (knpc kpc) (say knpc "Salut.")))
	   (method 'hail (lambda (knpc kpc) (say knpc "Salut.")))
	   
       (method 'adie (lambda (knpc kpc) (say knpc "Bye-bye.")))
       (method 'trav (lambda (knpc kpc) (say knpc "J'aide grand-père avec les taches ménagères.")))
       (method 'nom (lambda (knpc kpc) (say knpc "Je m'appelle Ilya.")))
       (method 'age (lambda (knpc kpc) (say knpc "J'ai huit ans.")))
       (method 'tach (lambda (knpc kpc) (say knpc "Je nourris les animaux, j'entretiens le feu et j'aide à faire la cuisine.")))
       (method 'anim ilya-animals )
       (method 'gran (lambda (knpc kpc) (say knpc "Je vis avec grand-père maintenant parce que maman et papa sont morts.")))
       (method 'mort (lambda (knpc kpc) (say knpc "Les trolls ont attaqué notre ferme ! "
                                                "Maman m'a caché dans la cave, "
                                                "et je me suis faufilé dehors quand les trolls dormaient. "
                                                "Mais j'ai perdu ma Puska...")))
       (method 'trol (lambda (knpc kpc) (say knpc "Je les deteste ! Quand je serai grande, je veux tous les tuer.")))
       (method 'dete (lambda (knpc kpc) (say knpc "Un jour, je serai une sorcière et je tuerai tous ceux que je deteste ! "
                                              "Je n'aurai plus jamais peur de rien !")))
       (method 'peur (lambda (knpc kpc) (say knpc "J'avais peur dans la cave. "
                                                "J'ai entendu maman et papa pleurer quand les trolls les ont mangés ... "
                                                "[Sniff!] Je pensais qu'ils me trouveraient et me mangeraient aussi...")))
       (method 'mama (lambda (knpc kpc) (say knpc "Ma maman me manque. Elle m'a appris à faire du feu avec mon esprit. "
                                               "Elle a brûlé un des trolls quand ils ont attaqué !")))
       (method 'papa (lambda (knpc kpc) (say knpc "Papa me manque. Il a essayé de combattre les trolls mais "
                                               "il n'était qu'un fermier.")))
       (method 'pusk ilya-quest )
       (method 'ferm (lambda (knpc kpc) (say knpc "Notre ferme était au nord et au sud, à travers les bois.")))
       (method 'arai (lambda (knpc kpc) (say knpc "Il y a beaucoup d'araignées dans les bois par ici.")))
       (method 'bois (lambda (knpc kpc) (say knpc "Grand-père dit de rester hors des bois.")))
       
       (method 'feu ilya-fire )
       (method 'vas ilya-fire )
       (method 'flam ilya-fire )
       (method 'greg (lambda (knpc kpc) (say knpc "C'est mon grand-père.")))
       (method 'join ilya-join )
       ))

