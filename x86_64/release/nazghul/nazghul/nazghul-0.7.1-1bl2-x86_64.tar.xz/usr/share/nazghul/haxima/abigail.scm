;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------
(define abigail-lvl 1)
(define abigail-species sp_forest_goblin)
(define abigail-occ oc_wrogue)

;;----------------------------------------------------------------------------
;; Schedule
;; 
;; In Green Tower
;;----------------------------------------------------------------------------
(kern-mk-sched 'sch_abigail
               (list 0 0 abigail-bed "dort")
               (list 7 0 gt-ws-hall "suis en pause")
               (list 8 0 gt-woods "suis en pause")
               (list 12 0 gt-ws-hall "suis en pause")
               (list 13 0 gt-ruins "suis en pause")
               (list 18 0 gt-ws-hall "suis en pause")
               (list 19 0 gt-tower "suis en pause")
               (list 20 0 abigail-bed "dort")
               )

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (abigail-mk) nil)

;;----------------------------------------------------------------------------
;; Conv
;; 
;; Abigail is a female goblin child, who lives in Green Tower.
;;----------------------------------------------------------------------------

;; Basics...
(define (abigail-hail knpc kpc)
  (kern-log-msg "Vous rencontrez une enfant gobelin.")
  (say knpc "Salut.")
  )

(define (abigail-default knpc kpc)
  (say knpc "[Elle hausse les épaules]")
  )

(define (abigail-name knpc kpc)
  (say knpc "Guto dit que mon nom est Abigail.")
  )

(define (abigail-bye knpc kpc)
  (say knpc "Adieu!")
  )

(define (abigail-guto knpc kpc)
  (say knpc "Doris est mon Guto."))

(define (abigail-dori knpc kpc)
  (say knpc "C'est mon Guto !"))

(define (abigail-gobl knpc kpc)
  (say knpc "Les gens verts, comme moi. Je suis les deux !"))

(define (abigail-both knpc kpc)
  (say knpc "Je parle aux gobelins. Je parle aux gens. Tu vois ? Les deux !"))

(define abigail-conv
  (ifc nil

       ;; basics
       (method 'default abigail-default )
       (method 'bonj abigail-hail )
	   (method 'hail abigail-hail )
	   
       (method 'adie abigail-bye )
       (method 'nom abigail-name )

       (method 'guto abigail-guto )
       (method 'dori abigail-dori )
       (method 'gobe abigail-gobl )
       (method 'deux abigail-both )
       ))

(define (mk-abigail)
  (bind 
   (kern-mk-char 
    'ch_abigail           ; tag
    "Abigail"             ; name
    abigail-species         ; species
    abigail-occ              ; occ
    s_goblin_child     ; sprite
    faction-men      ; starting alignment
    0 0 1            ; str/int/dex
    0  ; hp bonus
    0 ; hp per-level bonus
    0 ; mp off
    1 ; mp gain
    max-health ; hp
    0                   ; xp
    max-health ; mp
    0
    abigail-lvl
    #f               ; dead
    'abigail-conv         ; conv
    sch_abigail           ; sched
    'townsman-ai              ; special ai
    nil
    nil              ; readied
    )
   (abigail-mk)))
