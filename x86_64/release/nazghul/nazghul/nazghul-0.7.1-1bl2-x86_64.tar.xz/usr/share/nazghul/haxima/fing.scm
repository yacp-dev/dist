;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------

;;----------------------------------------------------------------------------
;; Schedule
;; 
;; In Oparine.
;;----------------------------------------------------------------------------
(kern-mk-sched 'sch_fing
               (list 0  0  sea-witch-bay        "suis en pause")
               (list 6  0  sea-witch-shore      "suis en pause")
               (list 8  0  sea-witch-bay        "suis en pause")
               (list 20 0  sea-witch-shore      "suis en pause")
               )

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (fing-mk) nil)

;;----------------------------------------------------------------------------
;; Conv
;; 
;; Fing is a male Nixie, who is a Prince among his people.
;; He dwells in Oparine, to be close to his true love, the human woman Lia.
;;----------------------------------------------------------------------------

;; Basics...
(define (fing-hail knpc kpc)
  (say knpc "[Tu rencontres un Nixie] Salut, Homme de la terre."))

(define (fing-default knpc kpc)
  (say knpc "Peut-être qu'un autre Homme de la terre serait au courant de cela."))

(define (fing-name knpc kpc)
  (say knpc "Je m'appelle Fing."))

(define (fing-join knpc kpc)
  (say knpc "Je ne peux pas m'éloigner de ces rivages."))

(define (fing-job knpc kpc)
  (say knpc "Je suis un prince parmi les marins de cette vallée... euh, de la baie."))

(define (fing-bye knpc kpc)
  (say knpc "Adieu, Homme de la terre."))

;; Shores...
(define (fing-shor knpc kpc)
  (say knpc "Je dois rester sur le rivage pour pouvoir être près de mon amour."))

(define (fing-love knpc kpc)
  (say knpc "Bien que ma bien-aimée ne puisse pas quitter la terre, "
       "elle est une princesse parmi les Gens de la Mer. "
       "Elle est gentille et vraie, et n'a pas désespéré, même avec sa malediction."))

(define (fing-sea knpc kpc)
  (say knpc "Il y a beaucoup de royaumes sous la mer, une multitudes de ruines et des grottes, "
       "des navires coulés et de grands trésors. Il y a des magiciens, "
       "et des guerriers, et des bêtes puissantes ! Sans vouloir vous offenser, mais la terre ferme "
       "doit être très ennuyeuse en comparaison."
       ))

(define (fing-curs knpc kpc)
  (say knpc "C'est une question qui concerne les Gens de Mer."))

;; Townspeople...
(define (fing-opar knpc kpc)
  (say knpc "C'est bon pour vous Homme de la terre, je suppose."))

(define (fing-gher knpc kpc)
  (say knpc "Nous l'avons admirée d'en bas ! Si rapide, si brutal ! "
       "Comme une tempête déguisée en femme. Son equipage, semble-t-il, est venu à "
       "une mauvaise fin."))

(define (fing-crew knpc kpc)
  (say knpc "L'equipage de Ghertie a navigué vers l'est jusqu'à une île, s'est rendu à terre et n'est "
       "jamais revenu. Son navire n'est plus."))

(define (fing-alch knpc kpc)
  (say knpc "Il parle à mon amour mais je ne suis pas jaloux. "
       "Il est trop vieux et trop gros pour qu'un philtre d'amour puisse décimer ses yeux !"))

(define (fing-osca knpc kpc)
  (say knpc "Je ne le connais pas."))

(define (fing-henr knpc kpc)
  (say knpc "Un brave Homme de la terre, d'après ce que j'entends."))

(define (fing-bart knpc kpc)
  (say knpc "Je n'ai pas vu beaucoup de gobelins. Je pense qu'ils ont peur de la mer. "
       "Il est une curiosité parmi eux."))


(define fing-conv
  (ifc nil

       ;; basics
       (method 'default fing-default )
       (method 'bonj fing-hail )
	   (method 'hail fing-hail )
	   
       (method 'adie fing-bye )
       (method 'trav fing-job )
       (method 'nom fing-name )
       (method 'join fing-join )
       
       ;; Shores
       (method 'riva fing-shor )
       (method 'amou fing-love )
       (method 'mer fing-sea )
       (method 'prof fing-sea )
       (method 'baie fing-sea )
       (method 'male fing-curs )

       ;; town & people
       (method 'opar fing-opar )
       (method 'alch fing-alch )
       (method 'gher fing-gher )
       (method 'equi fing-crew )
       (method 'osca fing-osca )
       (method 'henr fing-henr )
       (method 'bart fing-bart )
       (method 'lia fing-love )

       ))

(define (mk-fing)
  (bind 
   (kern-mk-char 'ch_fing           ; tag
                 "Fing"             ; name
                 sp_nixie           ; species
                 oc_warrior         ; occ
                 s_nixie_civilian    ; sprite
                 faction-men         ; starting alignment
                 1 2 0               ; str/int/dex
                 0 0                 ; hp mod/mult
                 0 0                 ; mp mod/mult
                 max-health -1 max-health 0 3  ; hp/xp/mp/AP_per_turn/lvl
                 #f                  ; dead
                 'fing-conv         ; conv
                 sch_fing           ; sched
                 'townsman-ai                 ; special ai
                 (mk-inventory (list (list 10 t_spear)))                ; container
                 nil                 ; readied
                 )
   (fing-mk)))
