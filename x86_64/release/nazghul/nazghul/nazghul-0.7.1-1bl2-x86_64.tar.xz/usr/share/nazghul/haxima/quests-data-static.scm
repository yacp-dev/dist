;;----------------------------------------------------
;; this is a collection place for updates to quests
;;
;; the function is an arbitary method call, but )the ones here tend to
;; basically boil down to retreiving a bunch of flags from the quest payload
;; and updating the quest via (qst-set-descr! text)
;;
;; the boilerplate at the front of the methods just makes the quest data easily accessible
;; via a tbl-flag? method without needing )to go through several level of redirection each time
;;

;;---------------
;; bandits
(define (quest-bandits-update)
  (println "quest-bandits-update")
  (let* ((quest (quest-data-get 'questentry-bandits))
         (quest-tbl (car (qst-payload quest)))
         (header (kern-ui-paginate-text
                  "Gregor, un vieux brûleur de charbon, a demandé votre aide pour lutter "
				  "contre les bandits qui sévissent dans la grande forêt."
                  "")))
    (println "quest-tbl:" quest-tbl)
    (define (tbl-flag? tag) 
      (not (null? (tbl-get quest-tbl tag)))
      )
    (qst-set-descr! quest
                    (cond ((tbl-flag? 'done)
                           (kern-ui-paginate-text
                            "Vous avez livré Nate aux Rangers de la Tour Verte et il devient maintenant leur problème."
                            ))
                          ((tbl-flag? 'nate-given-to-jailor)
                           (append header
                                   (kern-ui-paginate-text
                                    "Rapportez le reçu du prisonnier à Deric, le commandant des rangers de la Tour Verte, "
									"pour qu'il récupère la récompense."
                                    )))
                          ((tbl-flag? 'captured-nate-and-talked-to-deric)
                           (append header
                                   (kern-ui-paginate-text
                                    "Livrez Nate au gardien de prison de la Tour Verte et il vous remettra un reçu."
                                    )))
                          ((tbl-flag? 'captured-nate)
                           (append header
                                   (kern-ui-paginate-text 
                                    "Ramenez Nate à la Tour Verte et parlez au commandant des Rangers."
                                    )))
                          ((tbl-flag? 'talked-to-deric)
                           (append header
                                   (kern-ui-paginate-text 
                                    "Deric, commandant des rangers, n'a pas été d'une grande aide. "
									"Mais il vous a donné des ordres signés pour enrôler un de ses hommes."
                                    )))
                          (else
                           (append header
                                   (kern-ui-paginate-text
                                    "Gregor a dit de poser des questions sur les bandits de la Tour Verte."
                                    )))
                          )

		)
	))

;;---------------
;; whereami

    (define (quest-whereami-update)
      (let* ((quest (quest-data-get 'questentry-whereami))
             (quest-tbl (car (qst-payload quest)))
             (qp-shard (tbl-get quest-tbl 'shard))
             (qp-wanderer (tbl-get quest-tbl 'wanderer)))

        (qst-set-descr! quest
                        
                        (if (not (null? (tbl-get quest-tbl 'nossifer)))

                            (kern-ui-paginate-text
                             "Tu t'es retrouvé sur le Tesson, un petit fragment de monde, qui flotte entouré d'un grand vide."
                             ""
							 "Le seigneur démon Nossifer a organisé ton arrivée, pour mettre en route "
							 "des événements qui permettraient son propre passage vers le Tesson. "
							 ""
							 "Maintenant la Porte du Démon est ouverte, et la seule chose qui reste sur le chemin de Nossifer, c'est toi..."
                             )
                            
                            (append
                             ;;1 where
                             (cond ((null? qp-shard)
                                    (kern-ui-paginate-text
                                     "Vous vous êtes retrouvé dans un monde que vous ne connaissez pas, "
									 "avec des impressions très sommaires de ce qui aurait pu se passer avant."
                                     ""
                                     ))
                                   ((equal? 1 qp-shard)
                                    (kern-ui-paginate-text
                                     "Vous vous êtes retrouvé dans un monde dont vous n'avez pas connaissance. "
									 "Les habitants l'appellent le Tesson."
                                     ""
                                     ))
                                   (#t (kern-ui-paginate-text
                                        "Vous vous êtes retrouvé sur le Tesson, un petit fragment de monde, qui flotte entouré d'un grand vide."
                                        ""
                                        ))
                                   )


                             ;; how
                             (if (and (null? qp-wanderer) (null? qp-shard))
                                 (kern-ui-paginate-text "Où êtes-vous ?")
                                 nil
                                 )
                             
                             (cond ((null? qp-wanderer)
                                    (kern-ui-paginate-text
                                     "Comment et pourquoi êtes-vous ici ? Et qu'allez-vous faire maintenant ?"
                                     ))
                                   ((equal? 1 qp-wanderer)
                                    (kern-ui-paginate-text
                                     "D'autres, comme vous, ont été retrouvés par le passé en train de trébucher dans ce monde. "
									 "Les habitants vous connaissent sous le nom de 'Vagabond', "
									 "mais maintenant que vous êtes là, qu'allez-vous faire ?"
                                     ))
                                   (#t (kern-ui-paginate-text
                                        "Les Vagabonds comme vous, qui sont parfois tombés sur ce monde, "
										"ont par le passé été responsables de grandes actions. "
										"Comment allez-vous faire votre réputation ?"
                                        ))
                                   )

                             )
                            )
                        )
	))

;;-----------------------
;; calltoarms

(define (quest-calltoarms-update)
	(let* ((quest (quest-data-get 'questentry-calltoarms))
			(quest-tbl (car (qst-payload quest)))
			(header (kern-ui-paginate-text
					"Vous avez reçu un message urgent pour contacter quelqu'un appelé l'Enchanteur dès que possible."
					"")))
		(define (tbl-flag? tag) (not (null? (tbl-get quest-tbl tag))))
		(qst-set-descr! quest
		
(cond ((tbl-flag? 'done)
		(kern-ui-paginate-text
			"Vous vous êtes allié avec l'Enchanteur, un des Sages qui veillent sur le Tesson."
		))
	((tbl-flag? 'talked)
		(append header
		(kern-ui-paginate-text
			"Vous avez rencontré l'Enchanteur, mais vous et lui n'êtes parvenus à aucun accord."
		)))
	((tbl-flag? 'tower)
		(append header
		(kern-ui-paginate-text
			"Vous avez trouvé la Tour de l'Enchanteur dans les Fagnes. "
			"Cependant, il pourrait être plus difficile d'y pénétrer que de l'atteindre."
		)))
	((tbl-flag? 'directions)
		(append header
		(kern-ui-paginate-text
			"La Tour de l'Enchanteur se trouve dans les Fagnes, un marécage au nord de la ville de Trigrave, "
			"dans la partie ouest du Tesson."
		)))
	(#t
		(append header
		(kern-ui-paginate-text
			"Le message vous suggère de demander votre chemin au gardien de la clairière dans laquelle vous êtes arrivé."
		)))
)

		)
	))

;; give some xp for reaching the tower
(define (quest-calltoarms-tower kplace kplayer)
	(quest-data-update-with 'questentry-calltoarms 'tower 1 (quest-notify (grant-xp-fn 5)))
	)

;;-----------------------
;; thiefrune

;; TODO: make the theft appear not to happen until the player is on the scene, by altering convs based on quest status

(define (quest-thiefrune-update)
	(let* ((quest (quest-data-get 'questentry-thiefrune))
			(quest-tbl (car (qst-payload quest)))
			(header (kern-ui-paginate-text
					"L'Enchanteur vous a demandé d'enquêter sur un vol dans sa tour."
					"")))
		(define (tbl-flag? tag) (not (null? (tbl-get quest-tbl tag))))
		(qst-set-descr! quest
		
(cond ((tbl-flag? 'recovered) 
		(append header
		(kern-ui-paginate-text
			"Vous avez retrouvé le voleur et récupéré une rune appartenant à l'Enchanteur."
		)))
	((tbl-flag? 'talked)
		(append header
		(kern-ui-paginate-text
			"Le coupable, Mouse, semble être prêt à négocier."
		)))
	((tbl-flag? 'den5)
		(append header
		(kern-ui-paginate-text
			"Vous avez trouvé la cachette du voleur à Bole, et avez ouvert une brèche dans les niveaux supérieurs de la défense."
		)))
	((tbl-flag? 'den4)
		(append header
		(kern-ui-paginate-text
			"Vous avez trouvé la cachette du voleur à Bole, et avez passé trois niveaux de pièges."
		)))
	((tbl-flag? 'den3)
		(append header
		(kern-ui-paginate-text
			"Vous avez trouvé la cachette du voleur à Bole, et avez passé deux niveaux de pièges."
		)))
	((tbl-flag? 'den2)
		(append header
		(kern-ui-paginate-text
			"Vous avez trouvé la cachette du voleur à Bole, mais vous n'avez passé que le premier niveau."
		)))
	((tbl-flag? 'den1)
		(append header
		(kern-ui-paginate-text
			"Vous avez trouvé la cachette du voleur à Bole, mais vous n'avez pas encore percé ses défenses."
		)))
	((tbl-flag? 'bole)
		(append header
		(kern-ui-paginate-text
			"Le ^c+mvoleur^c- a été vu se dirigeant vers le nord-est à travers la Grande Forêt. Bole serait l'endroit le plus probable pour regarder."
		)))
	((tbl-flag? 'tower)
		(append header
		(kern-ui-paginate-text
			"Le ^c+mvoleur^c- a été vu se dirigeant vers l'est à travers les cols de montagne. "
			"La Tour Verte serait le meilleur endroit pour commencer à chercher."
		)))
	(#t
		(append header
		(kern-ui-paginate-text
			"Le ^c+mvoleur^c- a été suivi jusqu'à Trigrave. "
			"Les habitants de cette ville pourront peut-être vous donner de plus amples informations."
		)))
)

		)
	))

;; give some xp for getting through the dungeon
(define (quest-thiefrune-den1 kplace kplayer)
	(quest-data-update 'questentry-thiefrune 'tower 1)
	(quest-data-update 'questentry-thiefrune 'bole 1)
	(quest-data-update-with 'questentry-thiefrune 'den1 1 (quest-notify (grant-party-xp-fn 10)))
	)
(define (quest-thiefrune-den2 kplace kplayer)
	(quest-data-update-with 'questentry-thiefrune 'den2 1 (quest-notify (grant-party-xp-fn 10)))
	)
(define (quest-thiefrune-den3 kplace kplayer)
	(quest-data-update-with 'questentry-thiefrune 'den3 1 (quest-notify (grant-party-xp-fn 10)))
	)
(define (quest-thiefrune-den4 kplace kplayer)
	(quest-data-update-with 'questentry-thiefrune 'den4 1 (quest-notify (grant-party-xp-fn 10)))
	)
(define (quest-thiefrune-den5 kplace kplayer)
	(quest-data-update-with 'questentry-thiefrune 'den5 1 (quest-notify (grant-party-xp-fn 10)))
	)


;;-----------------------
;; runeinfo

;; TODO: runes are unidentified until you check in with abe?

(define (quest-runeinfo-update)
	(let* ((quest (quest-data-get 'questentry-runeinfo))
			(quest-tbl (car (qst-payload quest)))
			(header (kern-ui-paginate-text
				"La rune volée que vous avez récupérée doit avoir une grande importance pour qu'elle soit volée. "
				"L'Enchanteur vous a confié la tâche de rechercher cette raison."
				""
				)))
		(define (tbl-flag? tag) (not (null? (tbl-get quest-tbl tag))))
		(qst-set-descr! quest
		
(cond 
	((tbl-flag? 'done)
		(kern-ui-paginate-text
			"La rune que vous portez est l'une des clés de la Porte des Démons. "
			"La porte elle-même se trouve à un certain endroit au nord. "
			"Elle a été scellée par les sages dans les temps passés, et les Clés ont été dispersées et cachées."
		))
	((tbl-flag? 'gate)
		(append header
		(kern-ui-paginate-text
			"Les runes sont également connues sous le nom de 'clés de la porte des démons'. "
			"La porte elle-même se trouve à un certain endroit au nord. "
			"Elle a été scellée par les sages dans les temps passés, et les Clés ont été dispersées et cachées."
		)))
	((tbl-flag? 'keys)
		(append header
		(kern-ui-paginate-text
			"Les runes sont également connues sous le nom de 'clés de la porte des démons'. Ce que cela signifie reste inconnu."
		)))
	((tbl-flag? 'abe)
		(append header
		(kern-ui-paginate-text
			"L'alchimiste vous a informé que ^c+mAbe^c-, à la Tour Verte, a étudié la nature des runes."
		)))
	(#t
		(append header
		(kern-ui-paginate-text
			"Il vous suggère de commencer avec l' ^c+mAlchimiste^c-, qui se trouve peut-être à Oparine."
		)))
)

		)
	))


;;-----------------------
;; dragon blood

(define (quest-dragon-update quest)
	(let* ((quest-tbl (car (qst-payload quest)))
			(header (kern-ui-paginate-text
				"L'alchimiste a proposé de vous échanger des informations sur le lieu où se trouve une rune, en échange du sang d'un dragon."
				)))
		(define (tbl-flag? tag) (not (null? (tbl-get quest-tbl tag))))
		(qst-set-descr! quest
		
(cond 
	((tbl-flag? 'done)
		(kern-ui-paginate-text
			"L'alchimiste vous a échangé des informations sur le lieu où se trouve une rune, en échange du sang d'un dragon."
		))
	((in-inventory? (car (kern-party-get-members (kern-get-player))) t_dragons_blood 1)
		(append header
		(kern-ui-paginate-text
			""
			"Vous avez une fiole de sang de dragon en votre possession."
		)))
	((tbl-flag? 'sea)
		(append header
		(kern-ui-paginate-text
			""
			"Il suggère que la Mer de Feu pourrait être le meilleur endroit pour les rechercher."
		)))
	(#t
		header
		)
)

		)
	))

;;-----------------------
;; deeps rune

(define (quest-rune-p-update)
	(let* ((quest (quest-data-get 'questentry-rune-p))
			(quest-tbl (car (qst-payload quest))))
		(define (tbl-flag? tag) (not (null? (tbl-get quest-tbl tag))))
		(qst-set-descr! quest
		
(cond 
	((tbl-flag? 'done)
		(kern-ui-paginate-text
			"Une rune a été trouvée dans les profondeurs de Kurpolis."
		))
	(#t
		(kern-ui-paginate-text
			"L'alchimiste vous a fourni des informations sur une rune enterrée dans les profondeurs de Kurpolis :"
			""
		   "\"Les paladins ont construit plusieurs fortifications dans les profondeurs de Kurpolis. L'une des runes a été enterrée dans les fondations du fort le plus profond.\""
		   ""
	   		"\"Une pioche et une pelle peuvent suffire pour la sortir à nouveau, mais cela peut être difficile avec une douzaine de paladins qui n'arrêtent pas de s'essouffler derrière votre dos.\""
		))
)

		)
	))
	
	
;;-----------------------
;; spider rune

(define (quest-rune-f-update)
	(let* ((quest (quest-data-get 'questentry-rune-f))
			(quest-tbl (car (qst-payload quest))))
		(define (tbl-flag? tag) (not (null? (tbl-get quest-tbl tag))))
		(qst-set-descr! quest
		
(cond 
	((tbl-flag? 'done)
		(kern-ui-paginate-text
			"La rune perdue du roi Clovis a été récupérée de la reine araignée Angriss."
		))
	((and (tbl-flag? 'angrisslair) (tbl-flag? 'angriss))
		(kern-ui-paginate-text
			"Le roi Clovis possédait autrefois une rune, mais il fut tué pendant les guerres des gobelins. "
			"Les informations fournies par les gobelins vous ont conduit à la tanière d'Angriss, où se trouve peut-être la rune aujourd'hui."
		))	
	((tbl-flag? 'angriss)
		(kern-ui-paginate-text
			"Le roi Clovis possédait autrefois une rune, mais il fut tué pendant les guerres des gobelins."
			""
			"Le gobelin Kama vous a donné un indice de son emplacement : quelque chose (peut-être une araignée ?) "
			"se trouve à l'endroit où la bordure sud de la Grande forêt rencontre les montagnes à l'est."
		))		
	((tbl-flag? 'kama)
		(kern-ui-paginate-text
			"Le roi Clovis possédait une rune, mais il fut tué pendant les guerres des gobelins."
			""
			"Les Gobelins savent peut-être ce qu'elle est devenue. Le gobelin Kama peut vous aider, si vous le trouvez."
		))		
	((tbl-flag? 'gen)
		(kern-ui-paginate-text
			"Le roi Clovis possédait une rune, mais il fut tué pendant les guerres des gobelins"
			""
			"Les Gobelins savent peut-être ce qu'elle est devenue. "
			"Parmi les humains, le ranger Gen possède la plus grande connaissance de leur espèce."
		))		
	(#t
		(kern-ui-paginate-text
			"Le roi Clovis possédait une rune, mais il fut tué pendant les guerres des gobelins."
			""
			"Les gobelins savent peut-être ce qu'elle est devenue, mais pourraient-ils vous le dire ?"
		))
)

		)
	))
	
(define (quest-rune-f-lair kplace kplayer)
	(if (not (null? (quest-data-getvalue 'questentry-rune-f 'angriss)))
		(quest-data-update-with 'questentry-rune-f 'angrisslair 1 (quest-notify nil))
	))

;;-----------------------
;; void rune

;; todo add more sections? info on voidships, etc?

(define (quest-rune-d-update)
	(let* ((quest (quest-data-get 'questentry-rune-d))
			(quest-tbl (car (qst-payload quest))))
		(define (tbl-flag? tag) (not (null? (tbl-get quest-tbl tag))))
		(qst-set-descr! quest
		
(cond 
	((tbl-flag? 'done)
		(kern-ui-paginate-text
			"Une rune a été récupérée dans le Temple du Néant."
		))
	(#t
		(kern-ui-paginate-text
			"Les légendes parlent d'un temple dans le Néant, qui abritait une rune."
		))
)

		)
	))

;;-----------------------
;; pirate rune

(define (quest-rune-c-update)
	(let* ((quest (quest-data-get 'questentry-rune-c))
			(quest-tbl (car (qst-payload quest))))
		(define (tbl-flag? tag) (not (null? (tbl-get quest-tbl tag))))
		(qst-set-descr! quest
		
(cond 
	((tbl-flag? 'done)
		(kern-ui-paginate-text
			"Une rune a été récupérée sur l'épave de la Mort Miséricordieuse."
		))
	((tbl-flag? 'shiploc)
		(append
			(kern-ui-paginate-text
			"Le capitaine pirate Ghertie a un jour tenu une rune à bord de son navire, la Mort Miséricordieuse."
			""
			)
			(kern-ui-paginate-text (string-append "Son fantôme a révélé l'emplacement du navire : [" (number->string merciful-death-x) ", " (number->string merciful-death-y) "]."))
			(if (tbl-flag? 'shipraise)
				(kern-ui-paginate-text
				""
				"Le navire peut être soulevé avec le sort Vas Uus Ylem, mélangé à l'aide de mandragore, de mousse de sang et de soie d'araignée."
				)
				nil
			)
		))
	((tbl-flag? 'info)
		(kern-ui-paginate-text
			"Le capitaine pirate Ghertie a un jour tenu une rune à bord de son navire, la Mort Miséricordieuse. "
			"Son fantôme hante maintenant Oparine, cherchant à se ^c+mvenger^c- de son équipage."
		))
	(#t
		(kern-ui-paginate-text
			"Le capitaine pirate Ghertie a un jour possédé une rune."
		))
)

		)
	))

;;-----------------------
;; pirate quest

(define (quest-ghertie-update)
	(let* ((quest (quest-data-get 'questentry-ghertie))
			(quest-tbl (car (qst-payload quest))))
		(define (tbl-flag? tag) (not (null? (tbl-get quest-tbl tag))))
		(qst-set-descr! quest
		
(cond 
	((tbl-flag? 'done)
		(kern-ui-paginate-text
			(string-append "Le fantôme de Ghertie le pirate hantait autrefois l'auberge d'Oparine. "
			"En échange de sa vengeance, elle a révélé l'emplacement de son navire coulé : [" (number->string merciful-death-x) ", " (number->string merciful-death-y) "].")
		))
	((tbl-flag? 'questinfo)
		(append
			(kern-ui-paginate-text
				"Le fantôme de Ghertie le pirate hante l'auberge d'Oparine. Elle cherche à se venger des survivants de l'équipage qui l'ont trahie." 
				""
				"Gholet, Jorn et Meaney portent chacun une bague qui les désigne comme l'équipage de Ghertie. "
				"Ghertie acceptera les bagues comme preuve que vous les avez traqués, en échange de l'emplacement de son trésor englouti."
			)
			(if (and (tbl-flag? 'ring-jorn)
						(tbl-flag? 'ring-meaney)
						(tbl-flag? 'ring-gholet))
				(kern-ui-paginate-text
					""
					"Vous avez récupéré les trois bague en forme de crâne."
				)
				(append
					(cond 
						((tbl-flag? 'ring-gholet)
							(kern-ui-paginate-text
								""
								"Vous avez récupéré une bague en forme de crâne à Gholet."
							))
						((tbl-flag? 'gholet-price)
							(kern-ui-paginate-text
								""
								"Gholet est détenu dans les donjons sous Glasdrin, et échangera la bague contre une douzaine de crochets de serrure."
							))
						((tbl-flag? 'gholet-dungeon)
							(kern-ui-paginate-text
								""
								"Gholet est détenu dans les donjons sous Glasdrin."
							))
						((tbl-flag? 'gholet-prison)
							(kern-ui-paginate-text
								""
								"Si Gholet peut être trouvé n'importe où, ce sera dans une prison ou une autre."
							))
						(#t nil)
					)
					(cond 
						((tbl-flag? 'ring-jorn)
							(kern-ui-paginate-text
								""
								"Vous avez récupéré de Jorn une bague en forme de crâne."
							))
						((tbl-flag? 'jorn-loc)
							(kern-ui-paginate-text
								""
								"Jorn se trouve à l'auberge du Cerf Blanc de la Tour Verte."
							))
						((tbl-flag? 'jorn-forest)
							(kern-ui-paginate-text
								""
								"Jorn est un bandit quit vit dans la Grande Forêt."
							))
						(#t nil)
					)
					(cond 
						((tbl-flag? 'ring-meaney)
							(kern-ui-paginate-text
								""
								"Vous avez récupéré une bague en forme de crâne chez Meaney."
							))
						((tbl-flag? 'meaney-loc)
							(kern-ui-paginate-text
								""
								"Meaney dirige le Foyer des pauvres, au nord d'Oparine."
							))
						(#t nil)
					)
				)
			)
		))
	(#t
		(kern-ui-paginate-text
			(string-append
				(if (tbl-flag? 'ghertieid)
					"Le fantôme de Ghertie le pirate " 
					"Un fantôme")
				(if (tbl-flag? 'ghertieloc)
					"hante l'auberge à Oparine. "
					"peut être trouvé dans Oparine. ")
				(if (tbl-flag? 'revenge)
					"Elle cherche à se ^c+venger^c-, et peut vous aider si vous vous occupez de ses affaires en suspens."
					(string-append "Pourquoi s'attarde-t-"
						(if (tbl-flag? 'ghertieid) "elle" "il")
						" dans la non-mort ?"
					)
				))
		))
)

		)
	))


;;------------------------------------------------------------------------ 
;; Warritrix rune
;; 

(define (quest-rune-l-update)
	(let* ((quest (quest-data-get 'questentry-rune-l))
			(quest-tbl (car (qst-payload quest))))
		(define (tbl-flag? tag) (not (null? (tbl-get quest-tbl tag))))
		(qst-set-descr! quest
		
(cond 
	((tbl-flag? 'done)
		(kern-ui-paginate-text
			"Une rune a été récupérée sur la Warritrix tuée au combat."
		))
	((and (tbl-flag? 'located) (tbl-flag? 'know-hall))
		(kern-ui-paginate-text
			(string-append
			"L'une des runes est portée par la Warritrix. "
			"On peut la retrouver dans les Salles Perdues, à [ " 
			(number->string (loc-x lost-halls-loc)) " , " (number->string (loc-y lost-halls-loc))
			" ]."
			)
		))
	((and (tbl-flag? 'located) (tbl-flag? 'approx-hall))
		(kern-ui-paginate-text
			(string-append
			"L'une des runes est portée par la Warritrix. "
			"Elle peut être trouvée dans les Salles Perdues, sur la côte sud du Tesson."
			)
		))
	((tbl-flag? 'located)
		(kern-ui-paginate-text
			"L'une des runes est portée par la Warritrix, que l'on peut trouver dans les Salles Perdues."
		))
	(#t
		(kern-ui-paginate-text
			"L'une des runes est portée par la Warritrix."
		))
)		

		)
	))

;;-----------------------
;; absalot rune

(define (quest-rune-s-update)
	(let* ((quest (quest-data-get 'questentry-rune-s))
			(quest-tbl (car (qst-payload quest))))
		(define (tbl-flag? tag) (not (null? (tbl-get quest-tbl tag))))
		(qst-set-descr! quest
		
(cond 
	((tbl-flag? 'done)
		(kern-ui-paginate-text
			"Une rune a été récupérée dans les ruines d'Absalot."
		))
	((tbl-flag? 'silasinfo)
		(kern-ui-paginate-text
			"Silas a une rune cachée dans les ruines d'Absalot."
		))
	(#t
		(kern-ui-paginate-text
			"Une rune se trouve peut-être cachée à un certain endroit à Absalot."
		))
)

		)
	))

;;-----------------------
;; enchanter rune
;; tracks if the player has gotten the rune back from the enchanter

(define (quest-rune-k-update)
	(let* ((quest (quest-data-get 'questentry-rune-k))
			(quest-tbl (car (qst-payload quest))))
		(define (tbl-flag? tag) (not (null? (tbl-get quest-tbl tag))))
		(qst-set-descr! quest
		
(cond 
	((tbl-flag? 'entrusted-with-rune)
		(kern-ui-paginate-text
			"L'Enchanteur a confié la Rune de la Connaissance à vos soins."
		))
	((tbl-flag? 'player-got-rune)
		(kern-ui-paginate-text
			"La Rune de la Connaissance appartenait à l'Enchanteur, mais elle est depuis tombée entre vos mains."
		))
	((tbl-flag? 'ench-should-have-rune)
		(kern-ui-paginate-text
			"La Rune de la Connaissance appartient à l'Enchanteur. Vous pourrez peut-être le convaincre de vous la remettre."
		))
	(#t
		(kern-ui-paginate-text
			"La Rune de la Connaissance appartenait à l'Enchanteur."
		))
)

		)
	))

	
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; Search for the Wise quest group

(define (quest-wise-init)
	(quest-data-assign-once 'questentry-wise)
	(map (lambda (tag)
		 (if (not (null? (quest-data-getvalue tag 'name)))
			(quest-data-assign-once tag)
		))
		(list 'questentry-enchanter 'questentry-warritrix  'questentry-alchemist
						'questentry-the-man 'questentry-engineer  'questentry-necromancer)
	))

(define (quest-wise-subinit tag)
	(quest-data-update tag 'name 1)
	(if (quest-data-assigned? 'questentry-wise)
		(quest-data-assign-once tag)
	)
	)

;; TODO- merge lost hall location info with rune quest	
(define (quest-warritrix-update)
	(let* ((quest (quest-data-get 'questentry-warritrix))
			(quest-tbl (car (qst-payload quest))))
		(define (tbl-flag? tag) (not (null? (tbl-get quest-tbl tag))))
		(qst-set-descr! quest
		
(cond
	((tbl-flag? 'avenged)
		(kern-ui-paginate-text
			"La Warritrix était la guerrière la plus rusée de l'époque, mais elle a été tuée dans une embuscade dans les Salles Perdues. Depuis, vous avez traduit ses traîtres en justice."
		))
	((tbl-flag? 'found)
		(kern-ui-paginate-text
			"La Warritrix était la guerrière la plus rusée de l'époque, mais elle a été tuée dans une embuscade dans les Salles Perdues."
		))
	((tbl-flag? 'slain)
		(cond
			((tbl-flag? 'lost-hall-loc)
				(kern-ui-paginate-text
					(string-append
					"La Warritrix était la guerrière la plus rusée de l'époque, mais son esprit a été aperçu dans le Néant."
					""
					"Sa dépouille mortelle se trouve peut-être encore dans les Salles Perdues, à [..."
					(number->string (loc-x lost-halls-loc)) "," (number->string (loc-y lost-halls-loc))
					"]."
					)
				))
			((tbl-flag? 'lost-hall)
				(kern-ui-paginate-text
					"La Warritrix était la guerrière la plus rusée de l'époque, "
					"mais son esprit a été vu dans le Néant et ses restes mortels reposent peut-être encore dans les Salles perdues."
				))
			(#t
				(kern-ui-paginate-text
					"La Warritrix était la guerrière la plus rusée de l'époque, "
					"mais son esprit a été vu dans le Néant. De son vivant, elle a servi la ville de Glasdrin."
				))
		))
	((tbl-flag? 'lost-hall-loc)
		(kern-ui-paginate-text
			(string-append
			"La Warritrix est la guerrière la plus rusée de l'époque. Elle est en retard sur sa mission dans les Salles Perdues, qui se trouvent à ["
			(number->string (loc-x lost-halls-loc)) "," (number->string (loc-y lost-halls-loc))
			"]."
			)
		))
	((tbl-flag? 'lost-hall)
		(kern-ui-paginate-text
			"La Warritrix est la guerrière la plus rusée de l'époque. Une mission l'a conduite dans les Salles perdues."
		))
	((tbl-flag? 'assignment)
		(kern-ui-paginate-text
			"La Warritrix est la guerrière la plus rusée de l'époque. Elle est actuellement en mission loin de Glasdrin."
		))
	((tbl-flag? 'general-loc)
		(kern-ui-paginate-text
			"La Warritrix est la guerrière la plus rusée de l'époque. On peut normalement la trouver autour de Glasdrin."
		))
	((tbl-flag? 'common)
		(kern-ui-paginate-text
			"La Warritrix est la guerrière la plus rusée de l'époque."
		))
	(#t
		(kern-ui-paginate-text
			"La Warritrix fait partie des Sages."
		))
)

		)
	))
