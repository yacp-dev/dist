;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------
(define bill-start-lvl 3)

;;----------------------------------------------------------------------------
;; Schedule
;; 
;; In Bole.
;;----------------------------------------------------------------------------
(kern-mk-sched 'sch_bill
               (list 0  0  bole-bed-bill "dort")
               (list 6  0  bole-table-1  "suis en pause")
               (list 7  0  bole-n-woods  "travaille")
               (list 12 0  bole-table-2  "mange")
               (list 13 0  bole-n-woods  "travaille")
               (list 18 0  bole-table-2  "mange")
               (list 19 0  bole-dining-hall "suis en pause")
               (list 21 0  bole-bills-hut "suis en pause")
               (list 22 0  bole-bed-bill "dort")
               )

;;----------------------------------------------------------------------------
;; Gob
;;
;; Quest flags, etc, go here.
;;----------------------------------------------------------------------------
(define (bill-mk) nil)

;;----------------------------------------------------------------------------
;; Conv
;;
;; Bill is a woodcutter who lives in Bole.
;; Not the sharpest tool in the shed.
;;----------------------------------------------------------------------------
(define bill-catalog
  (list
   (list t_staff 10 "Il est difficile de trouver des branches assez droites pour fabriquer un gourdin.") ;; rather cheap
   (list t_torch  3 "Ah, j'aime voir clair la nuit, alors je fais des torches.") ;; rather cheap
   (list t_arrow  3 "Les rangers de la Tour Verte achètent parfois mes fleches.")
   (list t_bolt   4 "Peu de gens utilisent les arbalètes par ici.")
   ))

(define bill-merch-msgs
  (list nil ;; closed
        "Je fais tout ça moi-même." ;; buy
        nil ;; sell
        nil ;; trade
        "J'espère qu'ils fonctionnent bien pour vous." ;; sold-something
        "Si vous changez d'avis, je serai là." ;; sold-nothing
        nil ;; bought-something
        nil ;; bought-nothing
        nil ;; traded-something
        nil ;; traded-nothing
        ))


(define (bill-buy knpc kpc) (conv-trade knpc kpc "buy" bill-merch-msgs bill-catalog))

(define (bill-goods knpc kpc)
  (say knpc "Vous souhaitez en acheter ?")
  (if (kern-conv-get-yes-no? kpc)
      (bill-buy knpc kpc)
      (say knpc "Il suffit de demander si un jour vous souhaitez en acheter.")))

(define (bill-may knpc kpc)
  (say knpc "Elle tient la taverne en ville et elle est une bonne dame."))

(define (bill-lady knpc kpc)
  (say knpc "Il y a une dame en ville maintenant. Elle est très jolie. Mais elle a "
       "un grand et méchant petit ami."))

(define (bill-bole knpc kpc)
  (say knpc "Ouais, Ah! comme Bole. "
       "Il y a une taverne, où on mange et on peut rencontrer des gueules d'enterrement. "
       "Ma maison est la bas."))

(define (bill-wolves knpc kpc)
  (say knpc "Je dois faire attention à eux. "
       "Ils restent la plupart du temps dans le sud, loin de la ville."))

(define (bill-scared knpc kpc)
  (say knpc "Ah, ils étaient à l'ouest de la ville, "
       "C'est la où je vais presque jamais à cause des loups. "
       "Il y avait un grand et vieux chêne mort. "
       "A peine la hache a-t-elle mordu l'écorce "
       "que l'arbre se reveille !"))

(define (bill-thie knpc kpc)
  (say knpc "Il y a peu de temps, un type très nerveux était à la taverne. "
       "Il a eu quelques mots avec la jolie dame. Je pense qu'ils se sont, euh ... "
       "disputés pour quelque chose. Je l'ai vu aller dans les collines "
       "vers un coin au nord-est de la ville , vous savez ? Et il n'est jamais ressorti. "
       "Je ne sais pas où il est allé ! Ces collines sont une impasse ! Tout à fait étrange "
       "si vous me le demandez."))

(define (bill-mous knpc kpc)
  (say knpc "Il y a des souris partout. L'autre jour, j'ai vu un homme qui "
       "s'est precipité comme une souris !"))

(define bill-conv
  (ifc nil
       (method 'default (lambda (knpc kpc) (say knpc "[Il hausse les épaules]")))
       (method 'bonj (lambda (knpc kpc) (say knpc "Salut.")))
	   (method 'hail (lambda (knpc kpc) (say knpc "Salut.")))
	   
       (method 'adie (lambda (knpc kpc) (say knpc "Adieu à toi.")))
       (method 'trav (lambda (knpc kpc) 
                      (say knpc "Je suis bûcheron.")))
       (method 'nom (lambda (knpc kpc) (say knpc "Moi c'est Bill.")))
       (method 'join (lambda (knpc kpc) 
                       (say knpc "Ah non, monsieur ! Espèce de bouffon, "
                            "moi je suis bûcheron. Ca va pas ensemble !, "
                            "ne me vexez pas.")))

       (method 'flec bill-goods )
       (method 'hach (lambda (knpc kpc)
                 (say knpc "Elle fonctionne mieux que mon couteau sur la plupart des arbres.")))
       (method 'ache bill-buy )
       (method 'bole bill-bole )
       (method 'coup (lambda (knpc kpc)
                 (say knpc "Ah j'aime utiliser ma hache.")))
       (method 'fore (lambda (knpc kpc)
                 (say knpc "Oui, la foret est remplie d'arbres. "
                      "Et de loups aussi.")))
       (method  'hant (lambda (knpc kpc)
                 (say knpc "[Il se penche de près et murmure] "
                      "Il y a un arbre hanté à l'ouest de la ville. "
                      "J'ai fait peur aux jinkins! Ha Ha !!")))
       (method 'jink bill-scared )
       (method 'dame bill-lady )
       (method 'demo bill-lady )
       
       (method 'may bill-may )

       (method 'bois (lambda (knpc kpc)
                 (say knpc "Je coupe les arbres et je les transforme en bois de chauffage. "
                      "Parfois, je fabrique aussi des torches ou des fleches. ")))
       (method 'gueu (lambda (knpc kpc)
                 (say knpc "Oups ! Désolé. Je ne suis pas censé dire ça. "
                      "May me dit toujours de ne pas dire des gros mots. "
                      " Les dames n'aiment pas ça, tu sais.")))
       (method 'peur bill-scared )
       (method 'vole bill-thie )
       (method 'sour bill-mous )
       (method 'type bill-thie )
       (method 'prec bill-thie )
       (method 'torc bill-goods )
       (method 'vill bill-bole )
       (method 'echa bill-buy )
       (method 'arbr (lambda (knpc kpc)
                 (say knpc "Il y a toutes sortes d'arbres dans cette foret. "
                      "Tiens, l'autre jour je suis même tombé sur un "
                      "arbre hanté  !")))
       (method 'reve (lambda (knpc kpc)
                 (say knpc "Ahhh ! Ce vieux chêne mort est devenu vivant ! "
                      "Il hurlait comme un taureau et deux grands yeux se sont ouverts "
                      "et me fixaient du regard ! J'ai sauté de ma culotte !"
                      "J'ai lâché ma hache et j'ai couru comme un moins que rien !")))
       (method 'loup bill-wolves )
       ))

;;----------------------------------------------------------------------------
;; First-time constructor
;;----------------------------------------------------------------------------
(define (mk-bill)
  (bind 
   (kern-char-arm-self
    (kern-mk-char 
     'ch_bill ;;......tag
     "Bill" ;;.......name
     sp_human ;;.....species
     nil ;;..........occupation
     s_townsman ;;...sprite
     faction-men ;;..faction
     2 ;;............custom strength modifier
     0 ;;............custom intelligence modifier
     0 ;;............custom dexterity modifier
     0 ;;............custom base hp modifier
     0 ;;............custom hp multiplier (per-level)
     0 ;;............custom base mp modifier
     0 ;;............custom mp multiplier (per-level)
     max-health ;;..current hit points
     -1  ;;...........current experience points
     max-health ;;..current magic points
     0
     bill-start-lvl  ;;..current level
     #f ;;...........dead?
     'bill-conv ;;...conversation (optional)
     sch_bill ;;.....schedule (optional)
     'townsman-ai ;;..........custom ai (optional)

     ;;..............container (and contents)
     (mk-inventory
      (list
       (list 10  t_torch)
       (list 100 t_arrow)
       (list 1   t_2h_axe)
       ))
     nil ;;.........readied arms (in addition to the container contents)
     nil ;;..........hooks in effect
     ))
   (bill-mk)))
