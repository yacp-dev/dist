;;----------------------------------------------------------------------------
;; Schedule
;;
;; The schedule below is for the place "Trigrave"
;;----------------------------------------------------------------------------
(kern-mk-sched 'sch_earl
               (list 0  0  trigrave-earls-bed        "dort")
               (list 5  0  trigrave-tavern-table-3a  "mange")
               (list 6  0  trigrave-earls-counter    "travaille")
               (list 12 0  trigrave-tavern-table-3a  "mange")
               (list 13 0  trigrave-earls-counter    "travaille")
               (list 18 0  trigrave-tavern-table-3a  "mange")
               (list 19 0  trigrave-tavern-hall      "suis en pause")
               (list 20 0  trigrave-earls-room       "suis en pause")
               (list 21 0  trigrave-earls-bed        "dort")
               )

;;----------------------------------------------------------------------------
;; Gob
;;
;; Quest flags, etc, go here.
;;----------------------------------------------------------------------------
(define (earl-mk) nil)

;;----------------------------------------------------------------------------
;; Conv
;;
;; Earl is a merchant, and will trade with the player if he's at work. 
;; ...(removed some text which seems to have come from Jim.scm)...
;;----------------------------------------------------------------------------
(define earl-merch-msgs
  (list "Passez dans ma boutique quand je suis ouvert. C'est le magasin de produits secs dans le coin sud-ouest, ouvert de 6h à 18h."
        "Voici ce que j'ai en stock en ce moment."
        "Bien, ok, laissez-moi voir ce que vous avez à proposer."
        "Approchez-vous du guichet."
        "Dites-leur que vous l'avez eu chez Earl."
        "Juste du lèche-vitrine ? Très bien."
        "Je vais mettre ça à l'arrière et le nettoyer plus tard."
        "Revenez plus tard quand vous aurez autre chose à proposer, alors."
        "Vous avez déjà terminé ? C'est votre choix."
        "Faites-moi savoir s'il y a autre chose."
   ))

(define earl-catalog
  (list
   (list t_torch               5 "Vous ne voulez pas manquer de torches au fond d'un donjon.")
   (list t_sling              50 "La fronde est juste ce qu'il faut pour les radins qui ne veulent pas acheter de munitions.")
   (list t_staff              25 "Un mage sans bâton est semblable à un chien sans aboiement.")
   
   (list t_heal_potion        22 "Vous voulez en mettre beaucoup dans votre trousse d'urgence.")
   (list t_cure_potion        22 "Vous vous dirigez vers le nord ? Vous en aurez besoin pour vos déplacements dans les Marais.")
   (list t_mana_potion        22 "C'est justement ce qui se passe lorsque vous êtes dans un endroit où vous ne pouvez pas camper et que vos mages sont épuisés.")
   
   (list t_arrow               1 "Si vous avez un arc, vous ne pouvez pas avoir trop de flèches.")
   (list t_bolt                1 "J'ai les carreaux d'arbalètes les moins chers du coin.")
   (list t_smoke_bomb          3 "Il suffit de lancer ces bombes fumigènes sur les archers ennemis pour qu'ils ne puissent pas vous voir.")
   
   (list t_shovel             50 "Quand vous trouverez ce trésor enfoui, vous aurez besoin d'une pelle pour le déterrer.")
   (list t_pick               50 "Un piolet est indispensable pour briser les rochers qui vous bloquent le chemin.")
   
   (list t_sextant           500 "Vous pouvez déterminer votre emplacement n'importe où dans la nature avec l'un de ces outils sans égarer de réactifs ni de parchemins.")
   (list t_chrono            300 "Cette petite montre est inestimable quand il n'y a pas d'horloges aux alentours.")
   (list t_grease             23 "Les Voyous semblent aimer ce genre de choses. J'ai peur de demander pourquoi.")
   ))

(define (earl-trade knpc kpc) (conv-trade knpc kpc "trade" earl-merch-msgs earl-catalog))

(define earl-conv
  (ifc trigrave-conv
       ;; default if the only "keyword" which may (indeed must!) be longer than
       ;; 4 characters. The 4-char limit arises from the kernel's practice of
       ;; truncating all player queries to the first four characters. Default,
       ;; on the other hand, is a feature of the ifc mechanism (see ifc.scm).
       (method 'default (lambda (knpc kpc) (say knpc "Désolé j'ai oublié.")))
	   
       (method 'bonj (lambda (knpc kpc) (say knpc "Bienvenue, étranger !")))
       (method 'hail (lambda (knpc kpc) (say knpc "Bienvenue, étranger !")))
       
	   (method 'adie (lambda (knpc kpc) (say knpc "Oh, est-ce qu'on parlait ? Hé bien Adieu.")))
       (method 'trav (lambda (knpc kpc) (say knpc "Je garde le magasin. Vous avez besoin de quelque chose ?")
                            (if (kern-conv-get-yes-no? kpc)
                                (earl-trade knpc kpc)
                                (say knpc "D'accord."))))
       (method 'nom (lambda (knpc kpc) (say knpc "[Il pense une minute] Earl ! C'est ça !")))
       (method 'ache (lambda (knpc kpc) (conv-trade knpc kpc "buy"  earl-merch-msgs earl-catalog)))
       (method 'vend (lambda (knpc kpc) (conv-trade knpc kpc "sell"  earl-merch-msgs earl-catalog)))
       (method 'comm earl-trade )
       (method 'join (lambda (knpc kpc) (say knpc "Vous arrivez trop tard ! J'ai oublié tous mes sortilèges.")))

       (method 'comb 
               (lambda (knpc kpc)
                 (say knpc "Oui. J'ai combattu avec Lord Calvin contre "
                      "la horde de gobelins !")))
       (method 'calv 
               (lambda (knpc kpc)
                 (say knpc "Voilà un seigneur de guerre ! Calvin a conquis "
                      "tout, de la Mer Grise jusqu'à la Rive Nord !")))
       (method 'hord 
               (lambda (knpc kpc)
                 (say knpc "À cette époque, les gobelins étaient unis sous un seul "
                      "chef, et a menacé toute la Péninsule ! "
                      "Lorsque le Seigneur Calvin en a eu fini avec eux, ils ont été dispersés "
                      "et se sont caché dans les collines. Ils ne s'en sont jamais remis !")))
       (method 'mage 
               (lambda (knpc kpc)
                 (say knpc "J'ai oublié toute ma magie. J'ai même égaré ma baguette ! "
                      "J'ai connu un jour des sortilèges qui pouvaient tuer des armées entières.")))
       (method 'sort 
               (lambda (knpc kpc) 
                 (say knpc "J'ai été un mage de guerre autrefois. Il y a longtemps.")))
       (method 'vole 
               (lambda (knpc kpc)
                 (say knpc "J'ai vu un étranger qui fuyait vers l'ouest ! Non, au sud ! Non... Oh, mince, je ne m'en souviens pas.")))
       ))
