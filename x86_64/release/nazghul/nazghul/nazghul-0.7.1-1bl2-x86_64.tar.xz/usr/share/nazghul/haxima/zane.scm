;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------
(define zane-start-lvl 8)

;;----------------------------------------------------------------------------
;; Schedule
;;
;; The schedule below is for the place "Enchanter's Tower Ground Floor"
;;----------------------------------------------------------------------------
(kern-mk-sched 'sch_zane
               (list 0  0  enchtwr-zane-bed        "dort")
               (list 6  0  enchtwr-campsite        "suis en pause")
               (list 8  0  enchtwr-dining-room-1   "mange")
               (list 9  0  enchtwr-campsite        "suis en pause")
               (list 12 0  enchtwr-dining-room-1   "mange")
               (list 13 0  enchtwr-hall            "suis en pause")
               (list 19 0  enchtwr-dining-room-1   "mange")
               (list 20 0  enchtwr-dining-room     "suis en pause")
               (list 21 0  enchtwr-campsite        "suis en pause")
               (list 22 0  enchtwr-zane-bed        "dort")
               )

;;----------------------------------------------------------------------------
;; Gob
;;
;; Quest flags, etc, go here.
;;----------------------------------------------------------------------------
(define (zane-mk) nil)

;;----------------------------------------------------------------------------
;; Conv
;;
;; Zane is a ranger of the Fens. He camps at the Enchanter's Tower,
;; where he sells various outdoorsman gear needful for questing among 
;; the poisonous swamps of the region.
;;----------------------------------------------------------------------------
(define zane-merch-msgs
  (list nil ;; closed
        "Je ne fais pas confiance à ces armureries de ville. Je fabrique mon propre équipement. Laissez-moi vous montrer ce que j'ai." ;; buy
        nil ;; sell
        nil ;; trade
        "Faites attention à la marche." ;; bought-something
        "C'est ton choix, mon gars." ;; bought-nothing
        nil
        nil
        nil
        nil
        ))

(define zane-catalog
  (list
   ;; reagents
   (list ginseng        (* 5 reagent-price-mult) "C'est bon pour la guérison.")
   (list garlic         (* 4 reagent-price-mult) "Il faut avoir de l'ail pour la protection.")
   (list blood_moss     (* 6 reagent-price-mult) "Difficile de trouver ce genre de choses.")
   (list nightshade     (* 8 reagent-price-mult) "Cela ne pousse que dans les endroits vraiment humides.")
   (list mandrake       (* 10 reagent-price-mult) "Tous les sorts puissants nécessitent de ces racines en forme de bonhomme.")
   
   ;; potions
   (list t_heal_potion            21 "Cette potion est vraiment utile en cas d'urgence.")
   (list t_cure_potion            21 "Même les meilleurs sont parfois empoisonnés. Il faut en transporter plus.")
   (list t_poison_immunity_potion 21 "Si vous savez que vous devez marcher sur un terrain empoisonné, buvez d'abord cette potion d'immunité.")
   
   ;; bows, arrows and bolts 
   ;; (as an accomplished Ranger, he is also a bowyer and fletcher)
   (list t_self_bow    30 "Ce petit arc est léger et rapide à tirer.")
   (list t_bow         90 "L'arc de base est l'arme polyvalente parfaite. Bon marché, léger, avec une bonne portée.")
   (list t_long_bow   300 "Ils sont parfaits pour la chasse au gibier rapide en plein air.")
   (list t_great_bow  700 "Le pire cauchemar du paladin. Ce bébé va détruire les troupes blindées à longue portée.")
   
   (list t_arrow        2 "Je les rends spéciaux, mais je peux m'en séparer avec un petit frisson.")
   (list t_bolt         2 "Je fabrique des carreaux d'arbalète pour faire du commerce avec les milices de la ville.")
   ))

(define (zane-trade knpc kpc) (conv-trade knpc kpc "buy" zane-merch-msgs zane-catalog))

(define (zane-ench knpc kpc)
  (say knpc "Oui, il s'est enfermé à l'intérieur, vous voyez. "
       "Il n'a pas besoin que les gens l'interrompent "
       "tout le temps. Si vous êtes sincère, vous trouverez un moyen d'entrer."))

(define (zane-fens knpc kpc)
  (say knpc "Tu es en plein dedans, mon gars. Ils peuvent être dangereux, "
       "alors fais attention à toi."))
  
(define zane-conv
  (ifc ranger-conv
       ;; default if the only "keyword" which may (indeed must!) be longer than
       ;; 4 characters. The 4-char limit arises from the kernel's practice of
       ;; truncating all player queries to the first four characters. Default,
       ;; on the other hand, is a feature of the ifc mechanism (see ifc.scm).
       (method 'default (lambda (knpc kpc) (say knpc "Demande à quelqu'un d'autre.")))
       (method 'bonj (lambda (knpc kpc) (say knpc "[Il hoche la tête]")))
	   (method 'hail (lambda (knpc kpc) (say knpc "[Il hoche la tête]")))
       (method 'adie (lambda (knpc kpc) (say knpc "A bientôt, mon pote")))
       (method 'trav (lambda (knpc kpc) 
                      (say knpc "Je suis un Ranger. Je patrouille dans les Marecages.")))
       (method 'nom (lambda (knpc kpc) (say knpc "C'est Zane, mon pote.")))
       (method 'join (lambda (knpc kpc) 
                       (say knpc "Désolé, mon gars, j'ai déjà un travail à faire.")))
       (method 'ench zane-ench )
       (method 'mare zane-fens )
       (method 'dang (lambda (knpc kpc)
                 (say knpc "Empoisonné et regorgeant de monstres. "
                      "Tu comptes y passer beaucoup de temps ?")
                 (if (kern-conv-get-yes-no? kpc)
                     (begin
                       (say knpc "Tu auras besoin du sort d'immunité au poison. "
                            "Tu le connait ?")
                       (if (kern-conv-get-yes-no? kpc)
                           (say knpc "Bien. Je peux te vendre alors.")
                           (say knpc "Mélange l'Ombre Nocturne, l'Ail et chante "
                                "Sanct Nox. J'ai des reactifs supplémentaires que je peux "
                                "te vendre.")
                           ))
                     (say knpc "D'accord.")
                     )))
       (method 'pois (lambda (knpc kpc)
                 (say knpc "Une potion verte ou le sort 'An Nox' permettra de guérir "
                      "le poison.")))
       (method 'poti (lambda (knpc kpc)
                 (say knpc "J'en ai un peu plus que je peux te vendre.")))
       (method 'mons (lambda (knpc kpc)
                 (say knpc "Surtout des ectoplasmes, les bandits et les morts-vivants.")))
       (method 'reac (lambda (knpc kpc)
                 (say knpc "Je les ramasse où je peux. "
                      "Je peux te vendre mes suppléments.")))
       (method 'ache zane-trade )
       (method 'vend zane-trade )
       (method 'comm zane-trade )
       ))

;;----------------------------------------------------------------------------
;; First-time constructor
;;----------------------------------------------------------------------------
(define (mk-zane-first-time tag)
  (bind 
   (kern-char-arm-self
    (kern-mk-char 
     tag ;;..........tag
     "Zane" ;;.......name
     sp_human ;;.....species
     oc_ranger ;;.. .occupation
     s_companion_ranger ;;..sprite
     faction-men ;;..faction
     +1 ;;...........custom strength modifier
     0 ;;...........custom intelligence modifier
     +1 ;;...........custom dexterity modifier
     +1 ;;............custom base hp modifier
     +1 ;;............custom hp multiplier (per-level)
     0 ;;............custom base mp modifier
     0 ;;............custom mp multiplier (per-level)
     max-health ;;..current hit points
     -1  ;;...........current experience points
     max-health ;;..current magic points
     0 ;; AP_per_turn
     zane-start-lvl  ;;..current level
     #f ;;...........dead?
     'zane-conv ;;...conversation (optional)
     sch_zane ;;.....schedule (optional)
     'townsman-ai ;;..........custom ai (optional)

     ;;..............container (and contents)
     (mk-inventory
      (list
       (list 10  t_food)
       (list 100 t_arrow)
       (list 1   t_great_bow)
       (list 1   t_dagger)
       (list 1   t_sword)
       (list 1   t_leather_helm)
       (list 1   t_armor_leather)
       (list 5   t_torch)
       (list 5   t_cure_potion)
       (list 5   t_heal_potion)
       ))

     nil ;;.........readied arms (in addition to the container contents)
     nil ;;..........hooks in effect
     ))
   (zane-mk)))
