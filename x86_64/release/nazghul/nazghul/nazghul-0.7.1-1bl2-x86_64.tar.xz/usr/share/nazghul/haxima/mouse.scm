;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------
(define mouse-start-lvl 8)

;;----------------------------------------------------------------------------
;; Schedule
;;----------------------------------------------------------------------------

;;----------------------------------------------------------------------------
;; Gob
;;
;; Quest flags, etc, go here.
;;----------------------------------------------------------------------------
(define (mouse-mk) (list #t))
(define (mouse-first-meeting? mouse) (car mouse))
(define (mouse-set-first-meeting! mouse val) (set-car! mouse val))
(define (mouse-talked)
	(quest-data-update-with 'questentry-thiefrune 'talked 1 (quest-notify (grant-party-xp-fn 10)))
	)


(define (mouse-meet-first-time knpc kpc)

  (define (mouse-disappear)
    (say knpc "Oh, bon sang. Pas encore !")
    (kern-obj-add-effect knpc ef_invisibility nil)
    (kern-conv-end kpc)
    )

  (define (mouse-query)
    (say knpc "Salut. Vous n'avez pas été envoyé par la Dame Rouge, n'est-ce pas ?")
    (if (yes? kpc)
        (mouse-disappear)
        (begin
        	(say knpc "Pfiouu!! Tu m'as fait peur pendant un moment.")
        	(mouse-talked)
        )
    ))

  (define (mouse-gratitude)
    (say knpc "Loué soit Alopex ! La Dame Rouge est morte ! "
         "Vous m'avez rendu un grand service.")
         (mouse-talked)
         )

  (define (kathryn-speech)
    (say ch_kathryn "Idiot, tu m'as mené tout droit au voleur !")
    (kern-obj-set-conv ch_kathryn nil)
    (kern-being-set-base-faction ch_kathryn faction-monster))

  (define (thud-speech)
    (say ch_thud "Le voleur ici ! Tuez ! A mort ! A mort !")
    (kern-obj-set-conv ch_thud nil)
    (kern-being-set-base-faction ch_thud faction-monster))

  (define (open-gate)
    (open-moongate (mk-loc (loc-place (kern-obj-get-location knpc)) 7 2)))
  
  (define (warp-in-kathryn kgate)
    (warp-in ch_kathryn 
             (kern-obj-get-location kgate)
             south
             faction-monster))

  (define (warp-in-thud kgate)
    (warp-in ch_thud 
             (kern-obj-get-location kgate)
             west
             faction-monster))

  (mouse-set-first-meeting! (kobj-gob-data knpc) #f)
  (if (defined? 'ch_kathryn)
      (if (is-alive? ch_kathryn)
          (if (is-player-party-member? ch_kathryn)

              ;; kathryn is alive in the party (if thud is defined then he must
              ;; be in the party, too; see kathryn.scm)
              (begin
                (kern-char-leave-player ch_kathryn)
                (kathryn-speech)
                (if (defined? 'ch_thud)
                    (begin
                      (if (is-alive? ch_thud)
                          (thud-speech))
                      (kern-char-leave-player ch_thud)))
                (mouse-disappear))

              ;; kathryn is alive but not in the party so gate her in, and
              ;; thud, too, if he's alive
              (let ((kgate (open-gate))
                    (use-thud? (and (defined? 'ch_thud)
                                    (is-alive? ch_thud))))
                (kern-sleep 1000)
                (warp-in-kathryn kgate)
                (if use-thud?
                    (warp-in-thud kgate))
                (kathryn-speech)
                (if use-thud?
                    (thud-speech))
                (kern-sleep 1000)
                (close-moongate kgate)
                (mouse-disappear)))

          ;; kathryn is dead
          (if (is-player-party-member? ch_kathryn)

              ;; but in the party so remove her and thud, too, if he's defined
              (begin
                (kern-char-leave-player ch_kathryn)
                (if (defined? 'ch_thud)
                    (if (is-alive? ch_thud)
                        (begin
                          (thud-speech)
                          (kern-char-leave-player ch_thud)
                          (mouse-disappear))
                        (begin
                          (kern-char-leave-player ch_thud)
                          (mouse-gratitude)))
                    (mouse-gratitude)))

              ;; kathryn is dead but not in the party (since she is not in the
              ;; party, thud cannot be either)
              (mouse-query)))

      ;; kathryn is undefined (so she could never have been in the party, and
      ;; thus neither could thud)
      (mouse-query)))

;;----------------------------------------------------------------------------
;; Conv
;;----------------------------------------------------------------------------
(define (mouse-hail knpc kpc)
  (let ((mouse (kobj-gob-data knpc)))
    (if (mouse-first-meeting? mouse)
        (mouse-meet-first-time knpc kpc)
        (begin
        	(say knpc "Ah, bonjour. Hé")
   	        (mouse-talked)
	    )
        )))

(define (mouse-default knpc kpc)
  (say knpc "Je ne vois pas..."))

(define (mouse-name knpc kpc)
  (say knpc "Je suis Mouse."))

(define (mouse-join knpc kpc)
  (say knpc "Désolé, je ne suis pas un joueur en équipe. Hé"))

(define (mouse-job knpc kpc)
  (say knpc "Je... euh... collectionne des choses."))


(define (mouse-coll knpc kpc)
  (say knpc "Certains pourraient même me traiter de voleur."))

(define (mouse-thie knpc kpc)
  (say knpc "Jusqu'à maintenant, c'est un très bon boulot. Les gens veulent "
       "des choses, ils me paient pour l'obtenir. Mais ensuite, j'ai été engagé par cette "
       "étrange dame en rouge."))

(define (mouse-lady knpc kpc)
  (say knpc "La dame m'a engagé pour obtenir quelque chose et ensuite la rencontrer pour "
       "l'échanger contre un paiement. Tout cela est très typique, vous savez ? Mais au lieu de cela "
       "de me payer, elle a essayé de me tuer !"))

(define (mouse-kill knpc kpc)
  (say knpc "Cette dame rouge et sa brute étaient implacables ! Je ne saurais trop vous remercier "
       "de m'en débarrasser, mais j'ai le mauvais pressentiment qu'ils ne "
       "travaillaient pas seul. Je serai chassé pour le reste de ma vie, à moins que je ne puisse "
       "me débarrasser de cette rune stupide !"))

(define (mouse-rune knpc kpc)
  (if (not (in-inventory? knpc t_rune_k))
      (say knpc "C'est ton problème maintenant, mon pote !")
      (begin

        (define (give-rune gold)
          (let* ((pgold (kern-player-get-gold)))
            (if (> pgold gold)
                (kern-obj-add-gold kpc (- 0 gold))
                (let ((price (min pgold gold)))
                  (say knpc "Tu n'en avez pas assez ! Eh bien, je vais juste prendre "
                       "tout ce que tu peux me donner pour ça.")
                  (kern-obj-add-gold kpc (- 0 price)))))
          (kern-obj-remove-from-inventory knpc t_rune_k 1)
          (kern-obj-add-to-inventory kpc t_rune_k 1)
          (quest-data-update-with 'questentry-thiefrune 'recovered 1 (quest-notify (grant-party-xp-fn 50)))
          )
        
        (say knpc "Cette rune que j'ai obtenue pour la dame rouge n'a été que "
             "des ennuis depuis que j'en ai entendu parler pour la première fois. Je ne sais même pas à "
             "quoi elle sert! Je vais t'en faire une très bonne affaire. Disons, "
             "500 pièces d'or ?")
        (if (kern-conv-get-yes-no? kpc)
            (give-rune 500)
            (begin
              (say knpc "Eh bien, je suppose que je te suis redevable de m'avoir sauvé de "
                   "cette dame rouge. Que dis-tu de 250 pièces d'or ?")
              (if (kern-conv-get-yes-no? kpc)
                  (give-rune 250)
                  (begin
                    (say knpc "Hé t'es dur en affaires, mon pote. 100 pièces d'or à prendre ou à laisser ?")
                    (if (kern-conv-get-yes-no? kpc)
                        (give-rune 100)
                        (begin
                          (say knpc "50 ?")
                          (if (kern-conv-get-yes-no? kpc)
                              (give-rune 50)
                              (begin
                                (say knpc "Regarde, prenez-la c'est tout, d'accord ?")
                                (if (kern-conv-get-yes-no? kpc)
                                    (give-rune 0)
                                    (begin
                                      (say knpc "Je suis désespéré ! Tiens, "
                                           "Je TE paierai pour la prendre ! "
                                           "Eloigne-la loin de moi !")
                                      (give-rune (- 0 100))))))
                          )))))))))
      
(define (mouse-bye knpc kpc)
  (say knpc "Sans vouloir vous offenser, j'espère que nous ne nous reverrons plus jamais."))

(define (mouse-alopex knpc kpc)
  (say knpc "Alopex ? Oh, le vieux dieu des voleurs. "
       "C'est ce que j'ai entendu dire."))

(define mouse-conv
  (ifc nil
       (method 'default mouse-default )
       (method 'bonj mouse-hail )
	   (method 'hail mouse-hail )
	   
       (method 'adie mouse-bye )
       (method 'trav mouse-job )
       (method 'nom mouse-name )
       (method 'join mouse-join )

       (method 'coll mouse-coll )
       (method 'tuer mouse-kill )
       (method 'dame mouse-lady )
       (method 'rune mouse-rune )
       (method 'vole mouse-thie )
       (method 'alop mouse-alopex )
       ))

;;----------------------------------------------------------------------------
;; First-time constructor
;;----------------------------------------------------------------------------
(define (mk-mouse)
  (bind 
   (kern-char-force-drop
    (kern-char-arm-self
     (kern-mk-char 
      'ch_mouse ;;..tag
      "Mouse" ;;....name
      sp_human ;;.....species
      nil ;;..........occupation
      s_brigand ;;.....sprite
      faction-men ;;..faction
      0 ;;............custom strength modifier
      0 ;;............custom intelligence modifier
      6 ;;............custom dexterity modifier
      2 ;;............custom base hp modifier
      2 ;;............custom hp multiplier (per-level)
      1 ;;............custom base mp modifier
      1 ;;............custom mp multiplier (per-level)
      max-health ;;..current hit points
      -1 ;;...........current experience points
      max-health ;;..current magic points
      0
      mouse-start-lvl  ;;..current level
      #f ;;...........dead?
      'mouse-conv ;;...conversation (optional)
      nil ;;..........schedule (optional)
      nil ;;..........custom ai (optional)
      
      ;;..........container (and contents)
      (mk-inventory
       (list
        (list 1 t_rune_k)
        (list 1 t_armor_leather)
        (list 1 t_leather_helm)
        (list 1 t_sword)
        (list 1 t_bow)
        (list 50 t_arrow)))
      
      nil ;;..........readied arms (in addition to the container contents)
      nil ;;..........hooks in effect
      ))
    #t)
   (mouse-mk)))
