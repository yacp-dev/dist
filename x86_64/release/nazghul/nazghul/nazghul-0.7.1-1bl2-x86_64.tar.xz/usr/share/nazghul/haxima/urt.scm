;; ----------------------------------------------------------------------------
;; Urt
;;
;; Urt is a troll ensnared and paralyzed in the abandoned cellar. Although
;; paralyzed, he can speak.
;; ----------------------------------------------------------------------------

;;----------------------------------------------------------------------------
;; Conv
;;----------------------------------------------------------------------------
(define urt-conv
  (ifc basic-conv
       ;; default if the only "keyword" which may (indeed must!) be longer than
       ;; 4 characters. The 4-char limit arises from the kernel's practice of
       ;; truncating all player queries to the first four characters. Default,
       ;; on the other hand, is a feature of the ifc mechanism (see ifc.scm).
       (method 'default (lambda (knpc kpc) (say knpc "(semble confus)")))
       (method 'bonj (lambda (knpc kpc) (say knpc "(grognements)")))
	   (method 'hail (lambda (knpc kpc) (say knpc "(grognements)")))
       (method 'adie (lambda (knpc kpc) (say knpc "(encore des grognements)")))
       (method 'trav (lambda (knpc kpc) (say knpc "Coincé")))
       (method 'nom (lambda (knpc kpc) (say knpc "Urt")))

       (method 'mang (lambda (knpc kpc) (say knpc "Urt mange homme")))
       (method 'nour (lambda (knpc kpc) (say knpc "Tous mangent de la nourriture pour d'autres")))
       (method 'fill (lambda (knpc kpc) (say knpc "Elle HRENGI, UG THROGNI")))
       (method 'mont (lambda (knpc kpc) (say knpc "VLARDOGNI dans les montagnes, "
                                              "tuer les trolls. Les trolls s'en vont.")))
       (method 'hren (lambda (knpc kpc) (say knpc "Urt pas connaitre mot homme")))
       (method 'homm (lambda (knpc kpc) (say knpc "Urt cherche homme enfant. " 
                                            "Elle est délicieuse, tendre. "
                                            "Elle a trompé Urt. "
                                            "URN SEGESTRUM, UG VIGIDUS!")))
       (method 'sege (lambda (knpc kpc) (say knpc "'mangeur' en langage troll")))
       (method 'arai (lambda (knpc kpc) (say knpc "Urt déteste araignées")))
       (method 'coin lamda )(knpc kpc) (say knpc "Araignées manger Urt")))
       (method 'thro (lambda (knpc kpc) (say knpc "Urt pas connaître langage homme")))
       (method 'trol (lambda (knpc kpc) (say knpc "Trolls affamés. "
                                              "Nourriture dans les montagnes."
                                              "Maison dans les montagnes.")))
       (method 'ug (lambda (knpc kpc) (say knpc "'sera' en langage troll")))
       (method 'urn (lambda (knpc kpc) (say knpc "'était' en langage troll")))
       (method 'vigi (lambda (knpc kpc) (say kpnc "nourriture en langage troll")))
       (method 'vlar (lambda (knpc kpc) (say knpc "Urt pas connaitre langage homme")))
       ))

