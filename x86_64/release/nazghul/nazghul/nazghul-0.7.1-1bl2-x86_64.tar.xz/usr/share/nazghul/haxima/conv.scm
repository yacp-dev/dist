;;----------------------------------------------------------------------------
;; Generic conversation
;;----------------------------------------------------------------------------

;; fundamentals
(define (generic-hail knpc kpc)
  (say knpc "Ravi de vous rencontrer"))

(define (generic-unknown knpc kpc)
  (say knpc "Je ne peux pas vous aider à ce sujet"))

(define (generic-bye knpc kpc)
  (say knpc "Adieu")
  (kern-conv-end))

(define (generic-join knpc kpc)
  (say knpc "Je ne peux pas me joindre à vous."))

(define (generic-leav knpc kpc)
  (cond ((is-player-party-member? knpc)
         (cond ((is-only-living-party-member? knpc)
                (say knpc "Je devrais peut-être d'abord ressusciter le Vagabond... "
                     "ou vendre les parties de son corps à un thaumaturge, au moins."))
               (else
                (say knpc "Vous voulez que je parte de votre équipe maintenant ?")
                (cond ((yes? kpc)
                       (cond ((kern-char-leave-player knpc)
                              (say knpc "Si vous changez d'avis, je serai là à vous attendre.")
                              (kern-conv-end)
                              )
                             (else 
                              (say knpc "Je ne peux pas partir maintenant !"))))
                      (else
                       (say knpc "Vous m'avez rendu nerveux pendant une minute."))))))
         (else
          (say knpc "Je ne suis pas membre de votre équipe !"))))

;; wise
(define (basic-ench knpc kpc)
  (say knpc "L'enchanteur est le Magicien sage."
       "Il vit dans une tour près des Marais, vous avez besoin d'indications ?")
  (quest-wise-subinit 'questentry-enchanter)
  (quest-data-update 'questentry-enchanter 'general-loc 1)
  (if (yes? kpc)
      (let ((kplace (get-place knpc)))
        (cond ((equal? kplace p_westpass)
               (say knpc "Descendez l'échelle. Vous sortirez par le Col de l'Est. "
                    "Les chevaliers peuvent vous aider à partir de là."))
              ((equal? kplace p_eastpass)
               (say knpc "Prenez la route vers l'ouest jusqu'à Trigrave et renseignez-vous là-bas."))
              ((equal? kplace p_trigrave)
              	(quest-data-update 'questentry-calltoarms 'directions 1)
               (say knpc "Prenez la route du nord vers les Marais."))
              (else 
               (say knpc "Les Marais sont situés dans le nord-ouest."))
        ))))

;; towns
(define (basic-trig knpc kpc)
  (say knpc "Trigrave est une petite ville de l'ouest, "
       "elle est installée là où deux rivières se rejoignent."))

(define (basic-gree knpc kpc)
  (say knpc "La Tour verte, foyer des Rangers, se trouve au coeur de la Grande forêt. "
       "Vous avez besoin d'indications ?")
  (if (yes? kpc)
      (let ((kplace (get-place knpc)))
        (cond ((equal? kplace p_westpass)
               (say knpc "Prenez la route vers l'est dans la forêt. "
                    "Il finit par se transformer en piste, suivez-la du mieux que vous pouvez."))
              ((equal? kplace p_eastpass)
               (say knpc "Prenez l'échelle pour descendre au Col de l'Ouest et demandez aux Rangers là-bas."))
              ((equal? kplace p_trigrave)
               (say knpc "Prenez la route vers l'est en direction des montagnes et passez par le Col de l'Est."
                    "Après cela, vous devrez vous renseigner."))
              ((equal? kplace p_enchanters_tower)
               (say knpc "Allez au sud de Trigrave et demandez là-bas."))
              ((equal? kplace p_oparine)
               (say knpc "Prenez la route du nord vers Trigrave et demandez là-bas."))
              ((equal? kplace p_moongate_clearing)
               (say knpc "Suivez la route vers le sud jusqu'à la jonction, puis dirigez-vous vers l'est. "
                    "Lorsque la route tourne vers le nord, continuez vers l'est dans les bois."))
              (else 
               (say knpc "C'est au milieu de la Grande Forêt."))
              ))))

(define (basic-bole knpc kpc)
  (say knpc "Le hameau de Bole est situé dans un canyon dans les montagnes au nord de "
       "la Grande Forêt. Avez-vous besoin d'un itinéraire ?")
  (if (yes? kpc)
      (let ((kplace (get-place knpc)))
        (cond ((equal? kplace p_westpass)
               (say knpc "C'est au nord-est d'ici. Suivez les montagnes."))
              ((equal? kplace p_eastpass)
               (say knpc "Prenez l'échelle pour descendre au Col de l'Ouest et demandez aux Rangers là-bas."))
              ((equal? kplace p_trigrave)
               (say knpc "Prenez la route vers l'est en direction des montagnes et passez par le Col de l'Est."
                    "Après cela, vous devrez vous renseigner."))
              ((equal? kplace p_green_tower)
               (say knpc "Allez vers le nord à travers la forêt jusqu'à ce que vous atteigniez les montagnes, "
                    "puis les suivre vers l'est pendant un court moment."))
              ((equal? kplace p_enchanters_tower)
               (say knpc "Allez au sud de Trigrave et demandez là-bas."))
              (else 
               (say knpc "Je crois que c'est près des montagnes au nord de la Grande Forêt."))
              ))))
              
(define (basic-absa knpc kpc)
  (say knpc "Absalot, une grande et méchante ville, a été détruite pour ses péchés."))

(define (basic-opar knpc kpc)
  (say knpc "La ville d'Oparine se trouve dans le sud-ouest près d'un "
       "grand port. Vous avez besoin d'indications ?")
  (if (yes? kpc)
      (let ((kplace (get-place knpc)))
        (cond ((equal? kplace p_westpass)
               (say knpc "Prenez l'échelle pour descendre au Col de l'Est et suivez la route vers l'ouest."))
              ((equal? kplace p_eastpass)
               (say knpc "Suivez la route vers l'ouest."))
              ((equal? kplace p_trigrave)
               (say knpc "Suivez la route vers l'ouest et le sud jusqu'à la mer."))
              ((equal? kplace p_green_tower)
               (say knpc "Suivez la piste vers le sud et l'ouest jusqu'au Col de l'Ouest et demandez aux rangers quand vous y serez."))
              ((equal? kplace p_enchanters_tower)
               (say knpc "Allez au sud de Trigrave et demandez là-bas."))
              ((equal? kplace p_glasdrin)
               (say knpc "Prenez la route vers le sud."))
              ((equal? kplace p_oparine)
               (say knpc "Eh bien, vous êtes déjà là !"))
              (else 
               (say knpc "C'est un endroit situé sur la côte sud."))
              ))))

(define (basic-east knpc kpc)
  (say knpc "Le Col de l'Est garde le passage oriental dans la plaine fluviale. Vous avez besoin d'indications ?")
  (if (yes? kpc)
      (let ((kplace (get-place knpc)))
        (cond ((equal? kplace p_westpass)
               (say knpc "Descendez l'échelle, vous sortirez dans le Col de l'Est."))
              ((equal? kplace p_eastpass)
               (say knpc "Vous êtes déjà là."))
              ((equal? kplace p_trigrave)
               (say knpc "Suivez la route vers l'est et vous la rencontrerez sur votre droite."))
              ((equal? kplace p_green_tower)
               (say knpc "Voyagez vers l'ouest à travers les bois, puis suivez la route vers l'ouest jusqu'au Col de l'Ouest et demandez là."))
              ((equal? kplace p_enchanters_tower)
               (say knpc "Allez au sud de Trigrave et demandez là-bas."))
              ((equal? kplace p_glasdrin)
               (say knpc "Prenez la route du sud aussi loin que vous le pouvez et demandez là."))
              ((equal? kplace p_oparine)
               (say knpc "Prenez la route du nord vers Trigrave et demandez là-bas."))
              (else 
               (say knpc "C'est près des montagnes à l'ouest de la Grande Forêt."))
              ))))

(define (basic-west knpc kpc)
  (say knpc "Le Col de l'Ouest garde le passage ouest dans la Grande Forêt. Vous avez besoin d'indications ?")
  (if (yes? kpc)
      (let ((kplace (get-place knpc)))
        (cond ((equal? kplace p_westpass)
               (say knpc "Nous y sommes."))
              ((equal? kplace p_eastpass)
               (say knpc "Descendez l'échelle et vous y serez."))
              ((equal? kplace p_trigrave)
               (say knpc "Suivez la route vers l'est et demandez une fois au Col de l'Est."))
              ((equal? kplace p_green_tower)
               (say knpc "Voyagez vers l'ouest à travers les bois, puis suivez la route vers l'ouest."))
              ((equal? kplace p_enchanters_tower)
               (say knpc "Allez au sud de Trigrave et demandez là-bas."))
              ((equal? kplace p_glasdrin)
               (say knpc "Prenez la route du sud aussi loin que vous le pouvez."))
              ((equal? kplace p_oparine)
               (say knpc "Prenez la route du nord vers Trigrave et demandez là-bas."))
              (else 
               (say knpc "Suivez la route vers l'est à partir de Trigrave."))
              ))))

(define (basic-glas knpc kpc)
  (say knpc "Glasdrin est la ville fortifiée des Paladins. Avez-vous besoin d'un itinéraire ?")
  (if (yes? kpc)
      (let ((kplace (get-place knpc)))
        (cond ((equal? kplace p_westpass)
               (say knpc "Suivez la route vers l'est et le nord."))
              ((equal? kplace p_eastpass)
               (say knpc "Allez à l'est du Col de l'Ouest et demandez là-bas."))
              ((equal? kplace p_trigrave)
               (say knpc "Allez à l'est jusqu'au Col de l'Est et demandez là-bas."))
              ((equal? kplace p_green_tower)
               (say knpc "Allez vers l'ouest à travers les bois jusqu'à ce que vous atteigniez la route, puis suivez-la vers le nord."))
              ((equal? kplace p_enchanters_tower)
               (say knpc "Passez à l'est par le col et suivez la rivière."))
              ((equal? kplace p_oparine)
               (say knpc "Suivez la route vers le nord jusqu'à Trigave et demandez là, ou prenez un bateau et suivez la côte jusqu'au nord."))
              (else 
               (say knpc "Il se trouve près de la côte nord-est, sur une île."))
              ))))

(define (basic-fens knpc kpc)
  (say knpc "Les Marais sont une zone marécageuse au nord-ouest."))

(define (basic-kurp knpc kpc)
  (say knpc "Kurpolis est une ancienne ruine souterraine. "
       "L'entrée est située dans les montagnes du nord."))

(define (basic-lost knpc kpc)
  (say knpc "Les Salles perdues ? Je ne les ai entendues que dans les chansons des troubadours. "
       "Je ne savais pas qu'elles existaient vraiment."))

;; establishments
(define (basic-whit knpc kpc)
  (say knpc "Le Cerf Blanc est dans la Tour verte."))

;; quests
(define (basic-thie knpc kpc)
  (say knpc "Non, je ne sais rien sur les voleurs."))

(define (basic-rune knpc kpc)
  (say knpc "Je ne connais pas beaucoup les runes. Essayez de demander à l'un des Sages."))

(define (basic-wise knpc kpc)
	(say knpc "Les Sages ont une grande influence sur les affaires du Tesson. Vous voulez connaître leurs noms ?")
	(if (yes? kpc)
		(begin
			(say knpc "Il y a l'Enchanteur, le Nécromancien, l'Alchimiste, le MEC, l'Ingénieur et la Warritrix.")
			(map quest-wise-subinit
				(list 'questentry-enchanter 'questentry-warritrix  'questentry-alchemist
						'questentry-the-man 'questentry-engineer  'questentry-necromancer)
			)
		)
	))

(define (basic-shar knpc kpc)
  (say knpc "Le Tesson est ce que nous appelons notre monde.")
  (quest-data-update 'questentry-whereami 'shard 1)
  )

(define (basic-peni knpc kpc)
  (say knpc "La Peninsule est notre petit coin du Tesson."))

(define (basic-warr knpc kpc)
  (say knpc "La Warritrix est le Guerrier Sage. Si vous la cherchez, essayez à Glasdrin.")
  (quest-wise-subinit 'questentry-warritrix)
  (quest-data-update 'questentry-warritrix 'general-loc 1)
  )

(define (basic-engi knpc kpc)
  (say knpc "J'ai entendu dire que l'Ingenieur est le plus grand Fabricant du pays, "
       "mais je ne sais pas grand-chose sur lui.")
       (quest-wise-subinit 'questentry-engineer)
       (quest-data-update 'questentry-engineer 'common 1)
       )

(define (basic-man knpc kpc)
  (say knpc "Le MEC est un maître de l'escroquerie. Personne ne sait où se trouve sa cachette. "
       "La rumeur dit qu'il voyage déguisé.")
       (quest-wise-subinit 'questentry-the-man)
       (quest-data-update 'questentry-the-man 'common 1)
       )

(define (basic-alch knpc kpc)
  (say knpc "L'alchimiste est un Sage spécialisé dans les potions. "
       "Vous trouverez sa boutique à Oparine.")
       (quest-wise-subinit 'questentry-alchemist)
       (quest-data-update 'questentry-alchemist 'general-loc 1)
       )

(define (basic-necr knpc kpc)
  (say knpc "Le Necromancien est un Sorcier Sage qui se spécialise dans la magie de la mort. "
       "J'ai entendu dire qu'il vit dans une grotte cachée.")
       (quest-wise-subinit 'questentry-necromancer)
       (quest-data-update 'questentry-necromancer 'general-loc 1)
       )

(define (basic-drag knpc kpc)
  (say knpc "On raconte qu'un puissant dragon terrorise les bateaux sur "
       "la côte est."))

(define (basic-fire knpc kpc)
  (say knpc "La Mer de Feu ? C'est un volcan situé sur une île au large de la côte est."))

(define basic-conv
  (ifc '()
       ;; fundamentals
       (method 'bonj generic-hail )
	   (method 'hail generic-hail )	   
       (method 'default generic-unknown )
       (method 'adie generic-bye )
       (method 'join generic-join )
       (method 'part generic-leav )
       
       ;; wise
       (method 'ench basic-ench )
       (method 'sage basic-wise )
       (method 'warr basic-warr )
       (method 'mec basic-man )
       (method 'inge basic-engi )
       (method 'alch basic-alch )
       (method 'necr basic-necr )

       ;; towns & regions
       (method 'absa basic-absa )
       (method 'bole basic-bole )
       (method 'vert basic-gree )
       (method 'trig basic-trig )
       (method 'perd basic-lost )
	   (method 'sall basic-lost )
       (method 'opar basic-opar )
       (method 'mara basic-fens )
       (method 'tess basic-shar )
       (method 'peni basic-peni )
       (method 'kurp basic-kurp )
       (method 'glas basic-glas )
       (method 'feu  basic-fire )
	   (method 'mer  basic-fire )

       ;; establishments
       (method 'blan basic-whit )
	   (method 'cerf basic-whit )

       ;; quests
       (method 'vole basic-thie )
       (method 'rune basic-rune )

       ;; monsters
       (method 'drag basic-drag )

       ))

;; Helper(s)
(define (say knpc . msg) (kern-conv-say knpc msg))
(define (yes? kpc) (kern-conv-get-yes-no? kpc))
(define (no? kpc) (not (kern-conv-get-yes-no? kpc)))
(define (reply? kpc) (kern-conv-get-reply kpc))
(define (ask? knpc kpc . msg)
  (kern-conv-say knpc msg)
  (kern-conv-get-yes-no? kpc))
(define (prompt-for-key)
  (kern-log-msg "<Appuyez sur une touche pour continuer>")
  (kern-ui-waitkey))
(define (meet msg)
  (kern-log-msg msg))
(define (get-gold-donation knpc kpc)
  (let ((give (kern-conv-get-amount kpc))
        (have (kern-player-get-gold)))
    (cond ((> give have)
           (say knpc "Vous n'avez pas tant que ça !")
           0)
          (else
           (kern-player-set-gold (- have give))
           give))))
(define (get-food-donation knpc kpc)
  (let ((give (kern-conv-get-amount kpc))
        (have (kern-player-get-food)))
    (cond ((> give have)
           (say knpc "Vous n'avez pas tant que ça !")
           0)
          (else
           (kern-player-set-food (- have give))
           give))))
(define (working? knpc)
  (string=? "travaille" (kern-obj-get-activity knpc)))

;; Not really an aside in the theatrical sense, this routine causes a party
;; member to interject something into the conversation. kpc is the character
;; being conversed with, mem-tag is either nil or the party member who should
;; do the interjection. If mem-tag is nil then a party member (other than the
;; speaker) will be chosen at random. msg is the text of the comment. If kpc is
;; the only member of the party then the aside will not do anything.
(define (aside kpc kchar-tag . msg)
  ;;(println msg)
  (if (null? kchar-tag)
      (let ((members (filter (lambda (kchar)
                               (not (eqv? kchar kpc)))
                             (kern-party-get-members (kern-get-player)))
                     ))
        (if (not (null? members))
            (let ((kchar (random-select members)))
              (say kchar msg)
              #t)
            #f)
        )
      (if (in-player-party? kchar-tag)
          (begin
            (kern-conv-say (eval kchar-tag) msg)
            #t)
          #f)
      ))
         
;;----------------------------------------------------------------------------
;; Quests
;;----------------------------------------------------------------------------
(define (mk-quest) (list #f #f #f))
(define (quest-offered? qst) (car qst))
(define (quest-accepted? qst) (cadr qst))
(define (quest-done? qst) (caddr qst))
(define (quest-offered! qst val) (set-car! qst val))
(define (quest-accepted! qst val) (set-car! (cdr qst) val))
(define (quest-done! qst val) (set-car! (cddr qst) val))


;;----------------------------------------------------------------------------
;; Ranger Conversation
;;----------------------------------------------------------------------------
(define (ranger-ranger knpc kpc)
  (say knpc "Les Rangers gardent les frontières entre la nature sauvage et "
       "la civilisation. Nous patrouillons à la frontière et apportons notre aide là où nous le pouvons aux  "
       "Sages."))

(define (ranger-wise knpc kpc)
  (say knpc "Les Rangers ont une alliance informelle avec les Sages. Ils nous donnent "
       "l'aide et l'hospitalité. En retour, nous leur donnons des nouvelles. Parfois, nous servons "
       "en tant que messagers et éclaireurs."))

(define (ranger-join knpc kpc)
  (cond ((has? kpc t_ranger_orders 1)
         (say knpc "Voyons voir ces ordres  ..... D'accord. On dirait que nous sommes partenaires "
              "pendant un certain temps.")
         (take kpc t_ranger_orders 1)
         (join-player knpc)
         ;; NOTE: the following only permits one ranger at a time to join the
         ;; player!
         (kern-tag 'ch_ranger_merc knpc)
         (give kpc t_arrow 20)
         (kern-conv-end)
         )
        (else
         (say knpc "Désolé, je dois retourner à ma patrouille."))))

(define (ranger-band knpc kpc)
  (say knpc "Quand les hommes ont des problèmes avec la loi, ils s'enfuient dans les bois. "
       "Il y a toujours des bandits dans la forêt."))

(define ranger-conv
  (ifc basic-conv
       (method 'join ranger-join )
       (method 'rang ranger-ranger )
       (method 'sage ranger-wise )
       (method 'band ranger-band )
       ))


;; Knight conversation -- used by Lord Froederick's troops
(define knight-conv basic-conv)

;; Glasdrin
(define (glasdrin-warr knpc kpc)
  (if (player-found-warritrix?)
      (say knpc "Nous pleurons tous sa perte.")
      (say knpc "La Warritrix est la guerrière la plus rusée de l'époque. Je ne sais pas trop où elle se trouve en ce moment, demandez au Regisseur ou au commandant Jeffries.")
  	)
  	(quest-data-update 'questentry-warritrix 'general-loc 1)
  )

(define (glasdrin-stew knpc kpc)
  (if (player-stewardess-trial-done?)
      (say knpc "Son nom de Regisseuse est une malédiction parmi nous maintenant. Le nouveau Regisseur est Valus, un ancien commandant.")
      (say knpc "Le Regisseur est le gardien de la ville et des royaumes de Glasdrin. Vous la trouverez généralement dans la Citadelle.")))

(define (glasdrin-jeff knpc kpc)
  (if (player-stewardess-trial-done?)
      (say knpc "Au mieux, Jeffries a manqué à ses devoirs de commandant pour protéger ceux qui étaient sous son commandement. "
           "Au pire, il était complice de la trahison de la Warritrix. "
           "Notre nouveau chef est Janice.")
      (say knpc "Jeffries est le commandant de la milice de Glasdrin. Il est généralement à l'oeuvre dans la Citadelle.")
      ))

(define (glasdrin-kurp knpc kpc)
         (say knpc "Prenez le pont vers le nord pour traverser la rivière, puis suivez les "
              "montagnes à l'est et au nord dans un canyon."))
(define (glasdrin-cita knpc kpc)
  (say knpc "La Citadelle est le donjon intérieur dans la partie nord du château."))
(define (glasdrin-ghol knpc kpc)
  (say knpc "Il me semble qu'un homme du nom de Gholet a été arrêté pour vol. Vous pourriez vérifier le donjon de la Citadelle.")
   (quest-data-update 'questentry-ghertie 'gholet-dungeon 1)
   )
(define (glasdrin-kurp knpc kpc)
  (say knpc "Le donjon de Kurpolis est l'endroit où se trouve actuellement la plupart de nos troupes. Suivez les montagnes vers l'ouest, vous trouverez l'entrée dans un canyon."))

(define (glasdrin-glas knpc kpc)
  (say knpc "Glasdrin est la ville des Paladins."))

(define (glasdrin-pala knpc kpc)
  (say knpc "Les Paladins de Glasdrin sont la plus grande force militaire du royaume."))

(define glasdrin-conv
  (ifc basic-conv
       (method 'warr glasdrin-warr )
       (method 'regi glasdrin-stew )
       (method 'jeff glasdrin-jeff )
       (method 'kurp glasdrin-kurp )
       (method 'cita glasdrin-cita )
       (method 'ghol glasdrin-ghol )
       (method 'kurp glasdrin-kurp )
       (method 'glas glasdrin-glas )
       (method 'pala glasdrin-pala )
       (method 'jani (lambda (knpc kpc) 
                 (if (player-stewardess-trial-done?)
                      (say knpc "Le conseil militaire a élu Janice pour remplacer Jeffries en tant que commandant de la milice.")
                      (say knpc "Jeffries est un leader compétent, mais tout le monde sait que son assistante Janice est le 'cerveau' idéal."))))
       (method 'valu (lambda (knpc kpc)
                 (if (player-stewardess-trial-done?)
                     (say knpc "Valus a été disculpé par le journal de la Regisseuse."
                          "Il est dommage que nous ayons jamais cru à de tels mensonges à son sujet. "
                          "Nous l'avons élu pour être le nouveau Regisseur.")
                     (say knpc "Valus a été emprisonné pour des raisons de honte et d'indécence. "
                          "C'est vraiment dommage. C'était un général très respecté."))))
       ))

;; Kurpolis
(define kurpolis-conv
  (ifc basic-conv
       ))

;; Green Tower
(define (gt-gobl knpc kpc)
  (say knpc "Depuis les guerres des gobelins, il y a une trêve précaire. Parfois, ils font du commerce en ville, mais si vous les rencontrez dans la forêt, faites attention."))
(define (gt-towe knpc kpc)
  (say knpc "La tour qui donne son nom à cette ville est aujourd'hui le quartier général des Rangers."))
(define (gt-ruin knpc kpc)
  (say knpc "Les anciennes ruines se trouvent dans le coin sud-ouest de la ville."))
(define (gt-band knpc kpc)
  (say knpc "Demandez à Deric de vous parler des bandits. "
       "C'est lui seul qui peut traiter avec eux."))


(define green-tower-conv
  (ifc basic-conv
       (method 'vert (lambda (knpc kpc)
                 (say knpc "Oui, cette ville tire son nom de la vieille tour qui se trouve en son centre.")))
       (method 'gobl gt-gobl )
       (method 'tour gt-towe )
       (method 'ruin gt-ruin )
       (method 'band gt-band )
       ))

;; Trigrave
(define trigrave-conv
  (ifc basic-conv
       (method 'vole (lambda (knpc kpc) 
                 (say knpc "Je ne sais rien sur les voleurs. Demandez à Gwen, peut-être que des gens lui ont dit quelque chose.")))                       
       ))

;;----------------------------------------------------------------------------
;; Merchant

;; Indices into the merchant message list
(define merch-closed           0)
(define merch-buy              1)
(define merch-sell             2)
(define merch-trade            3)
(define merch-sold-something   4)
(define merch-sold-nothing     5)
(define merch-bought-something 6)
(define merch-bought-nothing   7)
(define merch-traded-something 8)
(define merch-traded-nothing   9)

(define (conv-trade knpc kpc menu msgs catalog)
  (println "conversation-commerce: " (kern-obj-get-activity knpc))
  ;;(println "conv-trade: " menu msgs catalog)
  (if (and (not (string=? "travaille" (kern-obj-get-activity knpc)))
           (not (null? (list-ref msgs merch-closed))))
      (say knpc (list-ref msgs merch-closed) 
           " Je " (kern-obj-get-activity knpc) " en ce moment.")
      (cond ((string=? menu "buy")
             (say knpc (list-ref msgs merch-buy))
             (if (kern-conv-trade knpc kpc "acheter" catalog)
                 (say knpc (list-ref msgs merch-sold-something))
                 (say knpc (list-ref msgs merch-sold-nothing))))
            ((string=? menu "sell")
             (say knpc (list-ref msgs merch-sell))
             (if (kern-conv-trade knpc kpc "vendre" catalog)
                 (say knpc (list-ref msgs merch-bought-something))
                 (say knpc (list-ref msgs merch-bought-nothing))))
            (else
             (say knpc (list-ref msgs merch-trade))
             (if (kern-conv-trade knpc kpc "faire du commerce" catalog)
                 (say knpc (list-ref msgs merch-traded-something))
                 (say knpc (list-ref msgs merch-traded-nothing))))
            )))

