;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------

;;----------------------------------------------------------------------------
;; Schedule
;; 
;; In Glasdrin
;;----------------------------------------------------------------------------
(kern-mk-sched 'sch_patch
               (list 0  0  gdp-bed "dort")
               (list 7  0  ghg-s1  "mange")
               (list 8  0  gh-ward "travaille")
               (list 11 0  ghg-s1  "mange")
               (list 12 0  gh-ward "travaille")
               (list 17 0  ghg-s1  "mange")
               (list 18 0  gc-hall "suis en pause")
               (list 21 0  gdp-hut "suis en pause")
               (list 22 0  gdp-bed "dort")
               )

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (patch-mk) (list 'townsman))

;;----------------------------------------------------------------------------
;; Conv
;; 
;; An old wizard living in Glasdrin, who works as a healer.
;; He wears an eyepatch, and is known as "Doc Patch".
;;----------------------------------------------------------------------------

;; Basics...
(define (patch-hail knpc kpc)
  (say knpc "[Vous rencontrez un vieux sorcier plein d'entrain avec un cache-oeil] "
       "Salut, voyageur."))

(define (patch-default knpc kpc)
  (say knpc "Je ne peux pas vous aider à ce sujet."))

(define (patch-name knpc kpc)
  (say knpc "Les gens m'appellent Doc Patch."))

(define (patch-join knpc kpc)
  (say knpc "Non, mon devoir est ici, Vagabond."))

(define (patch-job knpc kpc)
  (say knpc "Je dirige l'hopital. Avez-vous besoin de soins ?")
  (if (kern-conv-get-yes-no? kpc)
      (patch-trade knpc kpc)
      (say knpc "Si jamais vous avez besoin, je peux vous arranger.")))

(define (patch-bye knpc kpc)
  (say knpc "Bonne continuation !"))

;; Trade...
(define (patch-trade knpc kpc)
  (if (trade-services knpc kpc
                      (list
                       (svc-mk "Guerir les blessures" 30 heal-service)
                       (svc-mk "Guerir le poison" 30 cure-service)
                       (svc-mk "Ressusciter" 100 resurrect-service)))
      (begin
        (say knpc "Que puis-je faire d'autre pour vous ?")
        (patch-trade knpc kpc))
      (begin
        (say knpc "Y aura-t-il autre chose ?")
        (if (kern-conv-get-yes-no? kpc)
            (patch-trade knpc kpc)
            (say knpc "Très bien.")))))
  
;; Patch...
(define (patch-patc knpc kpc)
  (say knpc "J'ai perdu mon oeil à Kurpolis. Il fait si sombre là-bas que je n'ai pas vraiment "
       "besoin. [Il cligne des yeux. Avec son bon oeil.]"))

(define (patch-kurp knpc kpc)
  (say knpc "Les paladins gardent un avant-poste dans le donjon, et "
       "J'ai fait mon service militaire là-bas dans ma jeunesse."))

(define (patch-tour knpc kpc)
  (say knpc "Tous les citoyens de Glasdrin sont tenus d'effectuer le service militaire. "
       "J'étais un medic."))

(define (patch-medi knpc kpc)
  (say knpc "Un medic est un mage qui se spécialise dans les arts de la guerison. "
       "Les escouades de paladins sont toutes dotées d'un medic pour les soutenir dans la bataille. "
       "Nous avons reçu un entraînement de base au combat, mais je n'ai eu qu'à utiliser mon poignard "
       "une seule fois."))

(define (patch-dagg knpc kpc)
  (say knpc "Oui, j'ai porté ce poignard pendant six mois et j'ai finalement pu "
       "l'utiliser ... pour l'épluchage des pommes de terre et le travail en cuisine."))

(define (patch-dung knpc kpc)
  (say knpc "Les monstres se reproduisent dans les profondeurs, et il vaut mieux les combattre la bas  "
       "de peur qu'ils ne puissent remonter à la surface. N'êtes-vous pas d'accord ?")
  (if (kern-conv-get-yes-no? kpc)
      (say knpc "Alors les paladins y tiennent donc une compagnie  "
           "pour patrouiller les niveaux intermédiaires. Si jamais vous avez besoin "
           "de l'aide là-bas, cherchez-les. Ils auront un medic.")
      (say knpc "Hummm ! Je suppose que vous préférez les laisser se déchaîner "
           "dans la campagne !")))

(define (patch-doc knpc kpc)
  (say knpc "Je suis un medic. Avez-vous besoin d'une guerison ?")
  (if (kern-conv-get-yes-no? kpc)
      (patch-trade knpc kpc)
      (say knpc "Ok. Passez à l'hopital si jamais vous avez besoin d'aide. "
           "Je sais de quelle façon, vous, les aventuriers, vous vous blessez dans les combats !")))

(define (patch-hosp knpc kpc)
  (say knpc "Oui. Les paladins de Glasdrin finissent toujours en lambeaux. "
       "Je reçois aussi les rares aventuriers et les villageois malades."))

;; Townspeople...

(define patch-conv
  (ifc glasdrin-conv

       ;; basics
       (method 'default patch-default )
       (method 'bonj patch-hail )
	   (method 'hail patch-hail )
	   
       (method 'adie patch-bye )
       (method 'trav patch-job )
       (method 'nom patch-name )
       (method 'join patch-join )
       
       ;; trade
       (method 'comm patch-trade )
       (method 'guer patch-trade )
       (method 'pois patch-trade )
       (method 'ress patch-trade )
       (method 'aide patch-trade )

       ;; patch
       (method 'cach patch-patc )
       (method 'kurp patch-kurp )
       (method 'serv patch-tour )
       (method 'medi patch-medi )
       (method 'poig patch-dagg )
       (method 'donj patch-dung )
       (method 'doc patch-doc )
       (method 'hopi patch-hosp )
       (method 'avan patch-dung )

       ;; town & people

       ))

(define (mk-patch)
  (bind 
   (kern-mk-char 'ch_patch           ; tag
                 "Patch"             ; name
                 sp_human            ; species
                 oc_wizard           ; occ
                 s_companion_wizard  ; sprite
                 faction-glasdrin         ; starting alignment
                 1 3 0               ; str/int/dex
                 0 0                 ; hp mod/mult
                 0 0                 ; mp mod/mult
                 max-health -1 max-health 0 6            ; hp/xp/mp/AP_per_turn/lvl
                 #f                  ; dead
                 'patch-conv         ; conv
                 sch_patch           ; sched
                 'townsman-ai                 ; special ai
                 (mk-inventory (list (list 1 t_staff)))                 ; container
                 (list t_dagger)                 ; readied
                 )
   (patch-mk)))
