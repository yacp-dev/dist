;;----------------------------------------------------------------------------
;; Schedule
;; 
;; In Green Tower.
;;----------------------------------------------------------------------------
(kern-mk-sched 'sch_doris
               (list 0  0  doris-bed "dort")
               (list 8  0  white-stag-counter "travaille"))

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (doris-mk) nil)

;;----------------------------------------------------------------------------
;; Conv
;; 
;; Doris is the female innkeeper of the White Stag Lodge in Green Tower.
;;----------------------------------------------------------------------------
(define (doris-name kdoris kplayer)
  (say kdoris "Bonjour, je suis Doris, aubergiste de la loge du Cerf Blanc."))

(define (doris-default)
  (say kdoris "Laisse-moi réfléchir... non, je ne peux pas t'aider là."))

(define (doris-join kdoris kplayer)
  (say kdoris "Non merci ! J'ai les mains occupée avec la loge."))

(define (doris-doris knpc kpc)
  (say knpc "Oui. C'est moi."))

(define (doris-trade knpc kpc)
  (let ((door (eval 'white-stag-door))
        (price 15))
    ;; is the room still open?
    (if (not (door-locked? (kobj-gob door)))
        ;; yes - remind player
        (say knpc "Ta chambre est toujours ouverte, idiot ! Tu peux l'utiliser tant que "
             "tu es en ville.")
        ;; no - ask if player needs a room
        (begin
          (say knpc "La chambre coûte " price " pièces d'or. Je déverrouille la porte et tu "
               "peut l'utiliser aussi longtemps que tu es en ville. Tu es d'accord ?")
          (if (kern-conv-get-yes-no? kpc)
              ;; yes - player agrees to the price
              (let ((gold (kern-player-get-gold)))
                ;; does player have enough gold?
                (if (>= gold price)
                    ;; yes - player has enough gold
                    (begin
                      (kern-player-set-gold (- gold price))
                      (say knpc "Très bien. Prend le passage ouest. Première chambre "
                           "au bout du couloir.")
                      (send-signal knpc door 'unlock)
                      (kern-conv-end)
                      )
                    ;; no - player does not have enouvh gold)
                    (say knpc "Il semble que tes poches sont vides. Pourquoi tu n'irais  "
                         "pas te promener et tuer quelques trucs jusqu'à ce que tu pilles suffisament "
                         "de cadavres ? Ou quoi que vous fassiez d'autre, vous les aventuriers audacieux. [Elle "
                         "sourit un peu trop gentiment]")))
              ;; no - player does not want the room
              (say knpc "Peut-être une autre fois, alors"))))))

(define (doris-lodge knpc kpc)
  (say knpc "Oui. Tout m'appartient. Elle était à mon père, Dieu ait son âme. "
       "La plupart de mes clients sont des gens du pays, des bucherons ou des voyageurs "
       "errant par ici."))

(define (doris-daddy knpc kpc)
  (say knpc "Papa a chassé et dirigé son chemin vers une petite fortune puis il "
       "a construit cette loge. Quand il est mort, j'ai eu la loge."))

(define (doris-local knpc kpc)
  (say knpc "Les gens ici sont variés, étranges et secrets. Ils sont aussi "
       "digne de confiance, compétent et intéressant. Vous ne trouverez pas meilleurs "
       "amis ou de pires ennemis que ceux que vous vous faites ici."))

(define (doris-woodsman knpc kpc)
  (say knpc "Les chasseurs, bucherons et maraudeurs passent généralement par ici si "
       "ils sont dans la région. Les chasseurs sportifs les plus riches de la ville "
       "se logent ici, mais généralement ceux qui travaillent dans les bois campent dans la "
       "forêt. Ils viennent ici pour un peu de boisson, de la compagnie et un repas décent."))

(define (doris-travelers knpc kpc)
  (say knpc "Oui, des gens comme vous."))

(define (doris-gen knpc kpc)
  (say knpc "Un vieux combattant de de gobelins. Une sorte de légende locale. Vous pouvez "
       "le trouver en train de vadrouiller dans les bois, et il s'arrête généralement "
       "la nuit pour boire un verre."))

(define (doris-deric knpc kpc)
  (say knpc "Oui, Deric. Si vous avez rencontré Deric, alors vous connaissez Deric. Il est... "
       "suffisamment compétent mais ne veut pas passer sa vie dans l'ombre "
       "d'un poste de frontière."))

(define (doris-shroom knpc kpc)
  (say knpc "Champignon? Certains disent que c'est une sorcière, et qu'elle connaît un peu de magie gobelin. "
       "Elle est certainement utile lorsque quelqu'un tombe malade. Elle prend souvent son "
       "repas ici."))

(define (doris-abe knpc kpc)
  (say knpc "Une sorte d'érudit de Glasdrin. Il passe tout son temps "
       "à l'étude des ruines. Un type qui aime les livres."))

(define (doris-abigail knpc kpc)
  (say knpc "Elle était orpheline, alors je l'ai adoptée. J'ai toujours voulu un enfant, "
       "mais cela ne devait pas se faire. Je m'inquiète pour son avenir... Je sais qu'elle... "
       "appartient à sa propre espèce mais je ne peux pas supporter l'idée de "
       "la perdre."))

(define (doris-goblins knpc kpc)
  (say knpc "Ils font du commerce avec les citadins, j'en ai même un comme client "
       "de temps en temps. Mais la loi leur interdit d'entrer dans les villes "
       "en grand nombre, de sorte qu'ils sont toujours en infériorité numérique. La plupart d'entre eux ont hâte "
       "de conclure leurs affaires et retourner dans les bois."))

(define (doris-orphaned knpc kpc)
  (say knpc "Champignon me l'a amenée quand elle n'était qu'un bébé. Elle m'a dit qu'elle "
       "l'a trouvée dans les bois à côté de ses parents morts. Je ne sais pas qu'est ce - "
       "ou qui - les a tués, Champignon ne le dira jamais. Peut-être que je ne veux pas "
       "savoir."))

(define (doris-hail knpc kpc)
  (say knpc "Bienvenue au Cerf Blanc"))

(define (doris-bye knpc kpc)
  (say knpc "Revenez quand vous voulez"))

(define (doris-default knpc kpc)
  (say knpc "Je ne peux pas vous aider"))

(define (doris-thie knpc kpc)
  (say knpc "Je n'ai pas eu d'invités étranges ces derniers temps. Vérifiez avec Deric, qui reçoit "
       "les rapports des patrouilles de rangers. Et Gen a peut-être vu quelque chose dans son "
       "entourage aussi."))

(define (doris-band knpc kpc)
  (say knpc "Les voyageurs se sont plaints à leur sujet ! "
       "J'aimerais que Deric fasse quelque chose, c'est mauvais pour les affaires !"))

(define doris-conv
  (ifc green-tower-conv
       (method 'band doris-band )
       (method 'bonj doris-hail )
	   (method 'hail doris-hail )
	   
       (method 'adie doris-bye )
       (method 'default doris-default )
       (method 'nom doris-name )
       (method 'trav doris-trade )
       (method 'join doris-join )
       (method 'dori doris-doris )
       (method 'ache doris-trade )
       (method 'aube doris-trade )
       (method 'blan doris-lodge )
       (method 'cerf doris-lodge )
       (method 'loge doris-lodge )
       (method 'papa doris-daddy )
       (method 'pays doris-local )
       (method 'buch doris-woodsman )
       (method 'voya doris-travelers )
       (method 'gen  doris-gen )
       (method 'deri doris-deric )
       (method 'cham doris-shroom )
       (method 'abe doris-abe )
       (method 'abig doris-abigail )
       (method 'orph doris-orphaned )
       (method 'gobe doris-goblins )
       (method 'vole doris-thie )
       ))

;;----------------------------------------------------------------------------
;; First-time constructor
;;----------------------------------------------------------------------------
(define (mk-doris tag)
  (bind 
   (kern-mk-char tag                 ; tag
                 "Doris"             ; name
                 sp_human            ; species
                 nil                 ; occ
                 s_townswoman   ; sprite
                 faction-men         ; starting alignment
                 0 1 0               ; str/int/dex
                 0 0                 ; hp mod/mult
                 0 0                 ; mp mod/mult
                 max-health -1 max-health 0 2  ; hp/xp/mp/AP_per_turn/lvl
                 #f                  ; dead
                 'doris-conv         ; conv
                 sch_doris           ; sched
                 'townsman-ai        ; special ai
                 nil                 ; container
                 (list t_dagger)     ; readied
                 )
   (doris-mk)))
