;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------
(define the-man-start-lvl 9)

;;----------------------------------------------------------------------------
;; Schedule
;; 
;; In The MAN's hideout, a secure undisclosed location.
;;----------------------------------------------------------------------------
(kern-mk-sched 'sch_man
               (list 0  0 mans-bed    "dort")
               (list 7  0 mans-supper "mange")
               (list 8  0 mans-hall   "suis en pause")
               (list 12 0 mans-supper "mange")
               (list 13 0 mans-tools  "suis en pause")
               (list 15 0 mans-hall   "suis en pause")
               (list 18 0 mans-supper "mange")
               (list 19 0 mans-dock   "suis en pause")
               (list 22 0 mans-bed    "dort")
               )

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (man-mk) nil)

;;----------------------------------------------------------------------------
;; Conv
;; 
;; Yvonne, known as "The MAN", is a female rogue of pre-eminent skill,
;; living in a secure undisclosed location (The MAN's hideout).
;; 
;;----------------------------------------------------------------------------

;; Basics...
(define (man-hail knpc kpc)
  (say knpc "[Vous rencontrez une femme séduisante, d'âge moyen, avec une allure de chat "
       "et une tenue facile] Bonjour, mon beau."))

(define (man-default knpc kpc)
  (say knpc "Tu m'as eu là, champion."))

(define (man-name knpc kpc)
  (say knpc "Je m'appelle Yvonne. Mais tout le monde m'appelle le MEC."))

(define (man-join knpc kpc)
  (say knpc "Je ne peux pas dire que je ne suis pas tentée, beau gosse, mais quand il s'agit de "
       "boulot j'aime travailler seule."))

(define (man-job knpc kpc)
  (say knpc "Hm. Comment dire ? Je suppose que la vérité est plus facile : "
       "Je suis un Malfrat."))

(define (man-bye knpc kpc)
  (say knpc "Bye bye beau gosse..."))


;; Misc
(define (man-man knpc kpc)
  (say knpc "[Elle rit facilement] Vous attendiez-vous à quelqu'un... de plus viril ?")
  (kern-conv-get-yes-no? kpc)
  (say knpc "MEC est un acronyme pour Maitre des Envies "
       "de Choses. Vous aimez ?")
  (kern-conv-get-yes-no? kpc)
  (say knpc "Je pense que c'est l'Ingenieur qui l'a inventé à l'origine. "
       "Vous connaissez ces types d'ingenieurs, leur acronyme c'est 'bandes de gogos'."))

(define (man-wrog knpc kpc)
  (say knpc "Un Malfrat est spécialisé dans la violation des regles. Dis-moi, étranger, "
       "aimes-tu briser les regles ?")
  (if (kern-conv-get-yes-no? kpc)
      (say knpc "[Elle feint un regard choqué. C'est vraiment très attirant.]"
           "Vilain garçon ! Je vais peut-être devoir édifier ton personnage avec une "
           "fessée avant ton départ.")
      (say knpc "Oh, alors vous êtes un carré ? J'aime les carrés. Peut-être que vous allez "
           "deteindre sur moi. [Elle vous donne un regard innocent et mignon]")))

(define (man-rule knpc kpc)
  (say knpc "Une regle, une serrure, un secret, une énigme. J'aime les briser tous "
       "et voir ce qui se cache derrière. C'est surtout la curiosité, et le défi "
       "de la casse. Regardez autour de vous, voyez-vous beaucoup de richesses ici chez moi ?")
  (if (kern-conv-get-yes-no? kpc)
      (say knpc "Soupir. Soit vous venez d'une enfance pauvre, soit vous n'avez pas "
           "pris la peine de regarder.")
      (say knpc "Non, malgré mon surnom, je ne suis pas si avide. Il n'y a pas de "
           "plaisir pour moi d'AVOIR, seulement de FAIRE. Une fois qu'une chose est faite "
           "Je ne m'y intéresse plus. Les choses les plus intéressantes et les plus précieuses "
           "que j'ai acquises sont des secrets.")))

(define (man-secr knpc kpc)
  (say knpc "Essayez-moi."))

(define (man-enem knpc kpc)
  (say knpc "La Warritrix a un ennemi puissant en la personne de  "
       "la Regisseuse de Glasdrin."))

(define (man-stew knpc kpc)
  (say knpc "J'ai lu son journal une fois. Elle ferait mieux de le garder enfermé. "
       "Elle deteste la Warritrix pour l'avoir défiée à Absalot."))

(define (man-hate knpc kpc)
  (say knpc "Vous pouvez lire le journal de la Regisseuse par vous-même. "
       "Vous voulez savoir comment ?")
  (if (yes? kpc)
      (say knpc "Souvenez-vous juste de deux petits mots : Wis Quas. "
           "Je suis sûr qu'un type pointu comme vous peut comprendre le reste.")
      (say knpc "Oh, mais vous ratez quelque chose ! "
           "C'est tout simplement dégoulinant d'intrigue politique.")))


;; Wise Queries
(define (man-wiza knpc kpc)
  (say knpc "Oui, ils sont puissants. Mais j'ai volé leurs secrets."))

(define (man-wrig knpc kpc)
  (say knpc "Une bande de malins, mais ils doivent encore concevoir une nouvelle serrure que je ne puisse pas forcer."))

(define (man-warr knpc kpc)
  (say knpc "La Warritrix est légendaire pour son noble comportement. Je ne la connait pas "
       "personnellement, mais je connais ses ennemis, peut-être mieux qu'elle."))

(define (man-necr knpc kpc)
  (say knpc "Un homme utile, les morts savent beaucoup de choses oubliées par les "
       "vivants, et il sait comment les charmer."))

(define (man-alch knpc kpc)
  (say knpc "Je comprends que c'est un petit ver intelligent, mais je n'ai pas beaucoup "
       "à faire avec lui."))

(define (man-engi knpc kpc)
  (say knpc "J'adorerais me mettre au défi avec une serrure de sa conception, mais "
       "hélas, il ne garde aucun secret ni trésor à enfermer !"))

(define (man-ench knpc kpc)
  (say knpc "Mon magicien préféré. J'adore l'entendre continuer encore et encore "
       "dans sa veine vertueuse! Mais il devrait vraiment garder ses affaires plus "
       "en sécurité."))

;; Accursed Queries
(define (man-accu knpc kpc)
  (say knpc "Ils parlent de liberté, par laquelle ils entendent la liberté d'asservir les autres. "
       "Certains qui enfreignent les regles les rejoignent, pour se retrouver enchaînés. "
       "Une bande de mauvais garnements."))


;; Rune
(define (man-rune knpc kpc)
  (say knpc "Runes... J'ai connu un pirate qui portait une rune. Avez-vous... "
       "entendu l'histoire de Ghertie et de la Mort Miséricordieuse ?")
  (if (kern-conv-get-yes-no? kpc)
      (say knpc "Vous avez déjà bien voyagé. J'aime les hommes d'expérience.")
      (say knpc "Renseignez-vous sur Ghertie auprès d'Oparine."))
  (say knpc "Si vous pouvez trouver où se trouve la Mort Miséricordieuse, vous pouvez la faire remonter "
       "avec un sortilège. Connaissez-vous le sort ?")
  (if (kern-conv-get-yes-no? kpc)
      (say knpc "Ne sommes-nous pas magicien accompli ? J'espère que vous ne connaissez "
           "aucun sortilège d'amour, sorcier!")
      (begin
			(say knpc "Mélangez la racine_de_mandragore, la mousse de sang et la soie d'araignée, puis prononcez Vas "
			"Uus Ylem à côté de l'endroit où le bateau a coulé.")
			(quest-data-update 'questentry-rune-c 'shipraise 1)
		)
	)
  (say knpc "Ghertie ne donnera pas gratuitement l'endroit de son navire. Mais "
       "même les morts ont des désirs, c'est d'ailleurs la pire facette de "
       "mort! Et Ghertie ne désire rien de plus que la ^c+mvengeance^c-. Marquez bien "
       "ce mot, et souvenez vous-en au moment de rencontrer son fantôme.")
	(quest-data-update 'questentry-rune-c 'info 1)
	(quest-data-assign-once 'questentry-rune-c)
	(quest-data-update 'questentry-ghertie 'ghertieid 1)
	(quest-data-update-with 'questentry-ghertie 'revenge 1 (quest-notify nil))
	(quest-data-assign-once 'questentry-ghertie)
	)

(define (man-chan knpc kpc)
  (say knpc "Vous avez donc rencontré Chanteclair ? C'est sans doute lui qui vous a dit où me trouver ! "
       "[Soupir] Eh bien, j'espère que l'irresponsable fripouille va bien."))

(define man-conv
  (ifc basic-conv

       ;; basics
       (method 'default man-default )
       (method 'bonj man-hail )
	   (method 'hail man-hail )
	   
       (method 'adie man-bye )
       (method 'trav man-job )
       (method 'nom man-name )
       (method 'join man-join )
       
       ;; special
       (method 'mec man-man )
       (method 'malf man-wrog )
       (method 'voyo man-wrog )  ;; a synonym
       (method 'regl man-rule )
       (method 'secr man-secr )
       (method 'enne man-enem )
       (method 'regi man-stew )
       (method 'jour man-hate )
       (method 'evid man-hate )
       (method 'dete man-hate )
       (method 'magi man-wiza )
       (method 'fabr man-wrig )
       (method 'warr man-warr )
       (method 'necr man-necr )
       (method 'alch man-alch )
       (method 'inge man-engi )
       (method 'ench man-ench )
       (method 'maud man-accu )
       (method 'rune man-rune )
       (method 'chan man-chan )
       ))

(define (mk-the-man)
  (bind 
   (kern-mk-char 'ch_man           ; tag
                 "Le MEC"             ; name
                 sp_human            ; species
                 oc_wrogue           ; occ
                 s_brigandess        ; sprite
                 faction-men         ; starting alignment
                 0 3 10               ; str/int/dex
                 0 0                 ; hp mod/mult
                 0 0                 ; mp mod/mult
                 max-health ; hp
                 -1                   ; xp
                 max-health ; mp
                 0
                 the-man-start-lvl
                 #f                  ; dead
                 'man-conv         ; conv
                 sch_man           ; sched
                 'townsman-ai                 ; special ai
                 nil                 ; container
                 (list t_armor_leather_4
                 		t_leather_helm_2
                 		t_magic_axe)                 ; readied
                 )
   (man-mk)))
