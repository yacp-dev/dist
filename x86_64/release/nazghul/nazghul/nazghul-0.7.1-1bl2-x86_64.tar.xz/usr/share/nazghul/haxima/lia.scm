;; Reagent-seller
;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------

;;----------------------------------------------------------------------------
;; Schedule
;; 
;; In Oparine.
;;----------------------------------------------------------------------------
(kern-mk-sched 'sch_lia
               (list 0  0  sea-witch-bed        "dort")
               (list 6  0  sea-witch-beach      "suis en pause")
               (list 8  0  sea-witch-counter    "travaille")
               (list 20 0  sea-witch-beach      "suis en pause")
               )

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (lia-mk) nil)

;;----------------------------------------------------------------------------
;; Conv
;; 
;; Lia is a female wizard and reagent-seller who dwells in Oparine,
;; so that she may remain in the proximity to her true love,
;; the Nixie prince Fing.
;; 
;; She is said to be under a curse, of obscure nature.
;; One likely interpretation is that she is only in human form through 
;; having been transformed, being born a Nixie or some other water-folk.
;;----------------------------------------------------------------------------

;; Basics...
(define (lia-hail knpc kpc)
  (say knpc "[Vous rencontrez une beauté troublante] Bienvenue."))

(define (lia-default knpc kpc)
  (say knpc "Je ne peux pas vous aider à ce sujet."))

(define (lia-name knpc kpc)
  (say knpc "Je suis Lia."))

(define (lia-join knpc kpc)
  (say knpc "Je ne peux pas quitter ces rivages."))

(define (lia-job knpc kpc)
  (say knpc "Je vends des reactifs, dont la rare perle noire."))

(define (lia-bye knpc kpc)
  (say knpc "Adieu, Vagabond."))

;; Trade...
(define lia-merch-msgs
  (list "Mon magasin est ouvert de 8h00 à 20h00."
        "Voici mes marchandises."
        "J'acheterai des ingrédients rares s'ils sont d'un bon rapport qualité-prix."
        "Vous souhaitez acheter ou vous avez quelque chose à vendre ?"
        "Une bénédiction pour votre magie."
        "Très bien."
        "Je serai heureuse d'en acheter d'autres."
        "Je n'offre que ce qui est juste."
        "Que les dieux des profondeurs vous favorisent."
        "Entendu, c'est vous qui décidez."
   ))

(define lia-catalog
  (list
   (list sulphorous_ash         (*  2 reagent-price-mult) "Cette cendre provient du lit des dragons dans la Mer de Feu.")
   (list garlic                 (*  4 reagent-price-mult) "L'ail est une herbe assez commune, mais utile pour les sorts.")
   (list ginseng                (*  4 reagent-price-mult) "Je cultive moi-même ce ginseng à côté de la mandragore.")
   (list black_pearl            (*  4 reagent-price-mult) "Elles proviennent de ma propre culture. Vous n'en trouverez pas d'autres semblables.")
   (list blood_moss             (*  6 reagent-price-mult) "Il est difficile d'obtenir de la mousse de sang ici.")
   (list nightshade             (* 11 reagent-price-mult) "L'Ombre Nocturne est rare dans ces régions.")
   (list mandrake               (* 11 reagent-price-mult) "Je fais pousser de la mandragore avec mon ginseng.")
   
   (list t_in_an_scroll         (*  3 base-scroll-cost) "Lorsque vous êtes confronté à une magie plus forte que la vôtre, utilisez-la pour égaliser le score.")
   (list t_in_mani_corp_scroll  (*  8 base-scroll-cost) "Vous n'avez pas besoin de pleurer un compagnon mort lorsque vous en portez un.")
   (list t_vas_rel_por_scroll   (*  3 base-scroll-cost) "Vous pouvez parcourir de grandes distances ou échapper à de terribles circonstances grâce à ce parchemin de voyage par les portes.")
   (list t_vas_mani_scroll      (*  2 base-scroll-cost) "Si vous êtes gravement blessé, cela vous permettra de retrouver la santé.")
   (list t_wis_quas_scroll      (*  2 base-scroll-cost) "Ce parchemin vous ouvrira les yeux sur le monde invisible.")
   ))

(define (lia-trade knpc kpc)  (conv-trade knpc kpc "trade" lia-merch-msgs lia-catalog))
(define (lia-buy knpc kpc)  (conv-trade knpc kpc "buy" lia-merch-msgs lia-catalog))
(define (lia-sell knpc kpc)  (conv-trade knpc kpc "sell" lia-merch-msgs lia-catalog))

(define (lia-pear knpc kpc)
  (say knpc "J'ai ma propre culture de perle noire rare. "
       "Vous souhaitez en acheter ?")
  (if (kern-conv-get-yes-no? kpc)
      (lia-buy knpc kpc)
      (say knpc "Vous ne trouverez cette qualité nulle part ailleurs !")))

;; Shores...
(define (lia-shor knpc kpc)
  (say knpc "Je dois rester sur le rivage pour pouvoir être près de mon amour."))

(define (lia-love knpc kpc)
  (say knpc "Mon bien-aimé ne peut pas quitter la mer, "
       "il est un prince parmi les Gens de la Mer. "
       "Il est audacieux et vrai, et ne m'a pas quitté malgré ma malediction."
       ))

;; Sea
(define (lia-sea knpc kpc)
  (say knpc "J'aspire de tout mon coeur à rentrer chez moi! "
       "Les patios des profondeurs me manquent, "
       "et regarder les bateaux sillonner mon plafond, "
       "et entendre les conversations des Hommes tel un murmure lointain."))

(define (lia-curs knpc kpc)
  (say knpc "Je préfère ne pas en parler."))

;; Townspeople...
(define (lia-opar knpc kpc)
  (say knpc "Toutes les villes des Hommes sont trop sèches à mon goût."))

(define (lia-gher knpc kpc)
  (say knpc "Les charognards de la mer avaient l'habitude de suivre son navire. "
       "Ils ont été bien nourris avec ses victimes."))

(define (lia-alch knpc kpc)
  (say knpc "Il me rend parfois visite, et nous discutons de magie. "
       "J'ai peu d'autres amis parmi les Hommes."))

(define (lia-osca knpc kpc)
  (say knpc "Je le connais peu, sauf qu'il n'a jamais été en mer."))

(define (lia-henr knpc kpc)
  (say knpc "C'était un bon marin autrefois. Les grands des profondeurs parfois "
       "ont parlé de son courage."))

(define (lia-bart knpc kpc)
  (say knpc "Ses navires sont très respectés, mais tous les navires sont maladroits et "
       "ennuyeux à mes yeux."))

(define lia-conv
  (ifc basic-conv

       ;; basics
       (method 'default lia-default )
       (method 'bonj lia-hail )
	   (method 'hail lia-hail )
	   
       (method 'adie lia-bye )
       (method 'trav lia-job )
       (method 'nom lia-name )
       (method 'join lia-join )
       
       ;; Shores
       (method 'riva lia-shor )
       (method 'amou lia-love )
       (method 'mer lia-sea )
       (method 'prof lia-sea )
       (method 'male lia-curs )

       ;; trade
       (method 'comm lia-trade )
       (method 'reac lia-buy )
       (method 'ache lia-buy )
       (method 'vend lia-sell )
       (method 'noir lia-buy )
       (method 'perl lia-buy )

       ;; town & people
       (method 'opar lia-opar )
       (method 'alch lia-alch )
       (method 'gher lia-gher )
       (method 'osca lia-osca )
       (method 'henr lia-henr )
       (method 'bart lia-bart )
       (method 'fing lia-love )

       ))

(define (mk-lia)
  (bind 
   (kern-mk-char 'ch_lia           ; tag
                 "Lia"             ; name
                 sp_human            ; species
                 oc_wizard           ; occ
                 s_townswoman        ; sprite
                 faction-men         ; starting alignment
                 0 2 1               ; str/int/dex
                 0 0                 ; hp mod/mult
                 0 0                 ; mp mod/mult
                 max-health -1 max-health 0 3  ; hp/xp/mp/AP_per_turn/lvl
                 #f                  ; dead
                 'lia-conv         ; conv
                 sch_lia           ; sched
                 'townsman-ai                 ; special ai
                 (mk-inventory (list (list 1 t_dagger)))    ; container
                 nil                 ; readied
                 )
   (lia-mk)))
