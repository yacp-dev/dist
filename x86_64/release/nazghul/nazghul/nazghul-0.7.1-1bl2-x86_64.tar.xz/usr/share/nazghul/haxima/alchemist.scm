;;----------------------------------------------------------------------------
;; The Alchemist is numbered among the Wise, but he's not a very nice person.
;; He's very clever, very greedy and likes to trick people. He is also very
;; knowledgeable. He knows there is a rune buried in trigrave, and that the
;; enchanter knows what the runes are for. He also knows that one of then
;; entrances to the MAN's hideout is in the northwest.
;;
;; The Alchemist would be very happy to obtain the blood of a hydra, dragon and
;; lich. He will also teach the player how to make potions for gold?
;;----------------------------------------------------------------------------
;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------

;;----------------------------------------------------------------------------
;; Schedule
;; 
;; In Oparine
;;----------------------------------------------------------------------------
(kern-mk-sched 'sch_alch
               (list 0   0  alkemist-shop "suis en pause")
               (list 2   0  alkemist-bed  "dort")
               (list 8   0  bilge-water-seat-9   "mange")
               (list 9   0  alkemist-shop "travaille")
               (list 12  0  bilge-water-seat-9 "mange")
               (list 13  0  alkemist-shop "travaille")
               (list 17  0  bilge-water-seat-9 "mange")
               (list 18  0  bilge-water-hall "suis en pause")
               (list 19  0  sea-witch-shop   "suis en pause")
               (list 20  0  alkemist-shop "suis en pause")
               )

;;----------------------------------------------------------------------------
;; Gob
;;
;; Quest flags, etc, go here.
;;----------------------------------------------------------------------------
(define (alch-mk)
	(list
        (mk-quest) ;; dragon
        #f ;; lich
        #f ;; hydra
        ))


(define (alchq-dragon gob) (car gob))
(define (alchq-lich? gob) (cadr gob))
(define (alchq-hydra? gob) (caddr gob))
(define (alchq-lich! gob val) (set-car! (cdr gob) val))
(define (alchq-hydra! gob val) (set-car! (cddr gob) val))

;;----------------------------------------------------------------------------
;; Conv
;;----------------------------------------------------------------------------

(define alch-catalog
  (list
   (list t_heal_potion             18 "Lorsque vous serez à court de Mani ou de mana sur le champ de bataille, ceux-ci vous sauveront la vie !")
   (list t_cure_potion             18 "An Nox est peut-être moins cher, mais rien ne fonctionne mieux que mes potions de guérison!")
   (list t_mana_potion             18 "Aucune autre potion ne regénère votre mana comme le fait la mienne !")
   
   (list t_poison_immunity_potion  18 "Mieux vaut prévenir que guérir ! Avec mes potions d'immunité, vous ne devez plus jamais craindre le poison !")
   (list t_invisibility_potion    100 "Une gorgée de celà et vos ennemis ne vous retrouveront jamais !")
   (list t_str_potion             999 "La force d'un troll sera la vôtre avec cette potion !" )  ;; limited stock would be nice...
   (list t_dex_potion             999 "Vos flèches voleront droit comme la vérité quand vous boirez cette potion !")  ;; limited stock would be nice...
   (list t_int_potion             999 "L'homme sage cherche plus de sagesse ! Avec cette potion, elle peut être à vous pour un prix très raisonnable !")  ;; limited stock would be nice...
   (list t_info_potion            150 "Le sage a dit : Connais-toi toi-même. Cette potion vous aidera !")
   
   (list t_oil                      6 "Jetez du feu à vos ennemis ! Protégez vos côtés ou couvrez votre repli avec des champs de feu de la mort !")
   (list t_slime_vial              25 "Plus amusant qu'un tonneau de singes !  Déconcertez vos ennemis avec une armée d'ectoplasmes qui se multiplie !")
   ))

(define alch-merch-msgs
  (list "J'ai bien peur que mon magasin soit fermé maintenant. Passez me voir entre 9h et 17h."
        "Je suis sûr que j'ai quelque chose qui vous plaira ! [Il se frotte les mains vivement]"
        "J'achète parfois des marchandises d'occasion... au rabais bien sûr."
        "Oui, passons aux choses sérieuses !"
        "Vous en redemanderez quand vous verrez par vous-même combien mes potions sont bonnes !"
        "J'espère que vous ne regretterez pas d'avoir laissé passer ces belles potions."
        "Je peux probablement leur trouver une utilité."
        "Je doute que vous trouviez une meilleure offre ailleurs."
        "Un plaisir de faire des affaires avec vous !"
        "Peut-être une prochaine fois."
        ))

;; Basics...
(define (alch-hail knpc kpc)
  (say knpc "[Vous rencontrez un vieil homme petit et gros avec un long nez] "
       "Bonjour et bienvenue, Vagabond !"))

(define (alch-default knpc kpc)
  (say knpc "Je crains de ne pas pouvoir vous aider à ce sujet."))

(define (alch-name knpc kpc)
  (say knpc "On m'appelle l'Alchimiste.")
  (quest-data-update 'questentry-alchemist 'found 1)
  (quest-data-complete 'questentry-alchemist)
  )

(define (alch-join knpc kpc)
  (say knpc "Trop occupé ! Et bien trop vieux pour les aventures."))

(define (alch-job knpc kpc)
  (say knpc "Je fais des potions, j'explore des mystères, ce genre de choses. "
       "Si vous voulez acheter quelque chose, il suffit de le dire !"))

(define (alch-bye knpc kpc)
  (say knpc "Adieu ! Revenez bientôt !"))

;; Trade...
(define (alch-trade knpc kpc) (conv-trade knpc kpc "trade" alch-merch-msgs alch-catalog))
(define (alch-buy knpc kpc) (conv-trade knpc kpc "buy" alch-merch-msgs alch-catalog))
(define (alch-sell knpc kpc) (conv-trade knpc kpc "sell" alch-merch-msgs alch-catalog))

;; Rune...
;; offered: shown k rune
;; accepted: sent to find p rune
;; done: known to have found p rune
(define (alch-dragon-reward knpc kpc)
  (say knpc "Oh, oui, la rune...")
	(prompt-for-key)
  (say knpc
	   "Les paladins ont construit plusieurs fortifications dans les "
	   "profondeurs de Kurpolis. L'une des runes a été enterrée dans "
	   "les fondations du fort le plus profond.")
	(prompt-for-key)
  (say knpc
	   "Une pioche et une pelle peuvent suffire pour la sortir à nouveau, "
	   "mais cela pourrait être difficile avec une douzaine de paladins qui s'essouflent "
	   "derrière votre dos.")
	   (quest-data-assign-once 'questentry-rune-p)
	   (quest-rune-p-update)
	   )
	   
(define (alch-dragon-done knpc kpc)
  (say knpc "Je crains de ne pas connaître l'emplacement des autres "
					"runes. Essayez de demander au reste des Sages."))
		
(define (alch-dragon-quest knpc kpc qstat)
	(if (kern-conv-get-yes-no? kpc)
		(cond
			((quest-done? qstat)
				(alch-dragon-done knpc kpc)
				)
			((in-inventory? kpc t_rune_p)
				(quest-done! qstat #t)
				(say knpc "Je vois que vous avez trouvé la Rune de la Puissance.")
				(alch-dragon-done knpc kpc)
				)
			((quest-accepted? qstat)
				(alch-dragon-reward knpc kpc qstat)
				)
			((in-inventory? kpc t_dragons_blood 1)
			  (begin
				(say knpc "Je sais où elles sont enterrées, "
					 "et je vous le dirai en échange de cette fiole de "
					 "sang de dragon que vous portez. Marché conclu ?")
				(if (kern-conv-get-yes-no? kpc)
					(begin
						  (quest-accepted! qstat #t)
						  (kern-obj-remove-from-inventory kpc 
														  t_dragons_blood 
														  1)
						  (kern-obj-add-to-inventory knpc
													 t_dragons_blood
													 1)
						  (say knpc "[Il regarde avidement la fiole] "
							   "Oui ! C'est exactement ce dont j'ai besoin !")
							(quest-data-update 'questentry-dragon 'done 1)
							(quest-data-complete 'questentry-dragon)
							(quest-data-assign-once 'questentry-dragon)
						  (alch-dragon-reward knpc kpc))
					(begin
						(say knpc "Eh bien, je suppose que si vous déterrez le "
						"Tesson en entier, vous le trouverez un jour sans "
						"mon aide. Bonne chance !")
						(quest-data-assign-once 'questentry-dragon)
					))
				))
			(#t
				(say knpc "Nous pourrons alors peut-être échanger des faveurs. "
				   "Il se trouve que je sais où se cache une de ces runes. "
				   "Je vous dirai son emplacement si vous "
				   "m'apportez une fiole de sang de dragon. ")
				(quest-data-assign-once 'questentry-dragon)))
		(say knpc "Si c'est le cas, il se trouve que je sais où une est "
		   "cachée.")))

(define (alch-more knpc kpc)
	(let ((qstat (alchq-dragon (gob knpc))))
		(say knpc "Abe en sait plus sur les runes elles-mêmes. Êtes-vous "
			"intéressé de trouver les autres ?")
		(quest-data-update-with 'questentry-runeinfo 'abe 1 (quest-notify nil))
		(alch-dragon-quest knpc kpc qstat)
	))
		   
(define (alch-rune knpc kpc)
	(if (not (null? (quest-data-getvalue 'questentry-dragon 'rerune)))
		(alch-more knpc kpc)
		(begin
			(say knpc "[Il a un regard malin] Les Runes, hein? J'en ai vu quelques-unes de mon temps. "
			   "En avez-vous une pour l'examiner ?")
			(if (kern-conv-get-yes-no? kpc)
				(if (in-inventory? kpc t_rune_k 1)
					(begin
					  (say knpc "Oui, je vois. Celle-ci a appartenu à l'Enchanteur, "
						   "Je crois. J'espère que vous ne l'avez pas volé ! "
						   "J'en ai vu plusieurs autres de ce genre, "
						   "mais la personne à qui vous devriez vraiment parler "
						   "c'est Abe.")
							(quest-data-update 'questentry-dragon 'rerune 1)
						   (quest-data-update-with 'questentry-runeinfo 'abe 1 (quest-notify nil))
					  )
					(say knpc "Je ne la vois pas. Peut-être l'avez-vous fait tomber ?"))
				(say knpc "Je pourrais vous aider si vous pouviez me montrer.")))
		))

(define (alch-abe knpc kpc)
  (say knpc "Une vieille connaissance à moi. "
       "Aux dernières nouvelles, il étudiait les ruines de la Tour verte."))

(define (alch-drag knpc kpc)
  (say knpc "Je ne l'ai jamais fait personnellement, mais si l'on veut obtenir "
       "du sang de dragon, je crois comprendre qu'il faut tuer un dragon ! "
       "J'ai entendu dire qu'on les trouve comme les vaches dans les régions de la mer de feu."
			)
	(quest-data-update-with 'questentry-dragon 'sea 1 (quest-notify nil)))


;; The Wise...
(define (alch-necr knpc kpc)
  (say knpc "Le Necromancien est une vieille connaissance. "
       "Depuis qu'Absalot a été rasé, il s'est retiré dans les mondes souterrains."
       "C'est dommage, mais nous avons perdu le contact."))

(define (alch-ench knpc kpc)
  (say knpc "L'Enchanteur est un grand sorcier bien informé. "
       "J'ai bien peur que nous ne soyons pas toujours d'accord. "
       "Ces derniers temps, il est préoccupé par les Maudits."
       ))

(define (alch-man-reward knpc kpc)
	(say knpc "Dans les montagnes "
	   "au nord-est, le long de leur face sud, "
	   "il y a un passage secret. Les coordonnées de l'emplacement sont "
	   "[92 10]."))

(define (alch-man knpc kpc)
  (let ((qstat (gob knpc)))
	  (say knpc "Je n'ai jamais rencontré le MEC. "
		   "C'est le plus accomplit des tous les Malfrats, "
		   "il a probablement une fortune dissimulée dans sa cachette. "
		   "Si j'étais du genre aventureux, j'irais peut-être la chercher moi-même. "
		   "Qu'en est-il de vous ?")
	  (if (kern-conv-get-yes-no? kpc)
		(cond
			((alchq-hydra? qstat)
				(say knpc "J'ai entendu parler, de source sûre, d'une entrée "
					"dans la cachette secrète du MEC.")
				(alch-man-reward knpc kpc))
			((in-inventory? kpc t_hydras_blood 1)
				(begin
					(say knpc "J'ai entendu parler, de source sûre, d'une entrée "
						"dans la cachette secrète du MEC. Je vous le dirai en échange "
						"de cette fiole de sang d'hydre dans votre sacoche. C'est d'accord?")
					(if (kern-conv-get-yes-no? kpc)
						(begin
							(alchq-hydra! qstat #t)
							(kern-obj-remove-from-inventory kpc 
								t_hydras_blood 
								1)
							(kern-obj-add-to-inventory knpc
								t_hydras_blood
								1)
							(say knpc "[Il bave pas mal sur les substances nocives] "
								"Oh, charmant... charmant !")
							(say knpc "Heu..mhmm..")
							(alch-man-reward knpc kpc))
						(say knpc "C'est dommage. Vous n'avez pas besoin de la "
							"fiole, et je suis trop vieux pour aller à la chasse au trésor."))))
			(#t 
				(say knpc "Eh bien, j'entends beaucoup de choses, dont la pluspart ne sont "
					"que des rumeurs. Mais une source fiable m'a indiqué où trouver "
					"une entrée dans la cachette du MEC. Si vous m'apportez une fiole de "
					"sang d'hydre, je vais vous le révéler.")))
	   (say knpc "Quel outrage, Vagabond! "
			"Je pensais que vous étiez du genre aventurier."))))

(define (alch-hydr knpc kpc)
  (say knpc "L'hydre est un ennemi des plus difficiles. "
       "J'ai compris que les frapper ne fait qu'augmenter leur force ! "
       "Mais si vous réussissez à en tuer une, son sang est très utile "
       "pour les arts de la magie."))

(define (alch-warr knpc kpc)
  (say knpc "J'ai pu rencontrer la Warritrix à quelques occasions. "
       "Sa férocité est légendaire, "
       "mais je l'ai trouvée très calme et gracieuse dans son comportement. "
       "Je crois savoir qu'elle a refusé de collaborer à la destruction "
       "d'Absalot."))

(define (alch-engi knpc kpc)
  (say knpc "Je n'ai jamais rencontré l'Ingenieur, "
       "Je comprends qu'il est un peu reclus."))

(define (alch-alch knpc kpc)
  (say knpc "Oui, c'est moi. Je suis l'Alchimiste.")
  (quest-data-update 'questentry-alchemist 'found 1)
  (quest-data-complete 'questentry-alchemist)
  )


;; Absalot...
(define (alch-absa-reward knpc kpc)
	(say knpc "Il y avait une forteresse surplombant une rivière de feu. "
		 "Dommage qu'elle n'ait pas été habitée, cela aurait pu changer l'invasion de Glasdrin."
		 "Cela fera un voyage périlleux si des monstres s'en sont emparés.")
	(prompt-for-key)
	(say knpc 
		 "Il existe cependant une route plus ancienne qui contourne la forteresse. "
		 "Sondez le mur est de la première caverne, "
		 "vous trouverez un passage caché.")
	(prompt-for-key)
	(say knpc
		 "Il vous faudra encore passer la rivière de feu. "
		 "Il y a une statue sur la rivière. Dites le mot de passe 'ONUS' pour passer indemne. "
		 "Ecrivez ce mot de passe !")
	(prompt-for-key)
	(say knpc
		 "Le passage rejoint l'itinéraire principal près de l'escalier qui mène à "
		 "la cité perdue. Vous n'échapperez pas à tous les dangers du voyage, "
		 "mais cela devrait vous rendre la vie un peu plus facile."))

(define (alch-absa knpc kpc)
  (let ((qstat (gob knpc)))
    (say knpc "Le passage vers Absalot a toujours été dangereux, même lorsqu'il était maintenu. "
         "Vous ne penseriez pas à y aller par hasard ?")
    (if (kern-conv-get-yes-no? kpc)
        (cond
         ((alchq-lich? qstat)
          (alch-absa-reward knpc kpc))
         ((in-inventory? kpc t_lichs_blood 1)
          (say knpc "En échange de cette fiole de sang de Liche, je serais "
               "heureux de vous parler d'une porte dérobée. Qu'en dites-vous ?")
          (if (kern-conv-get-yes-no? kpc)
              (begin
                (alchq-lich! qstat #t)
                (kern-obj-remove-from-inventory kpc 
                                                t_lichs_blood 
                                                1)
                (kern-obj-add-to-inventory knpc
                                           t_lichs_blood
                                           1)
                (say knpc "[Il sourit et cligne des yeux] Juste ce qu'il me faut !")
                (alch-absa-reward knpc kpc))
              (say knpc "Je vois. Il ne fait aucun doute que vous avez des projets IMPORTANTS pour "
                   "le sang de cette Liche. Je peux toujours en obtenir "
                   "d'un autre aventurier.")))
         (else
          (say knpc "Apportez-moi une fiole de sang de Liche et je vous dirai "
               "un chemin secret.")))
        (say knpc "Ce n'est plus qu'une ruine maintenant de toute façon. Tout a été détruit "
             "quand elle a été pillée."))))

(define (alch-sack knpc kpc)
  (say knpc "Oh oui, vous ne le saviez pas ? Absalot a été pillé par les armées "
       "de Glasdrin, la Tour Verte et Oparine. Détruite pour sa malfaisance, "
       "disent-ils. [Il glousse sans humour]"))

(define (alch-esca knpc kpc)
  (say knpc "Euh... j'ai dit ça ? Je ne peux pas imaginer pourquoi. Toute personne qui s'est evadée "
       "d'Absalot aurait la peine de mort sur sa tête."))

(define (alch-wick knpc kpc)
  (say knpc "Oui, Absalot était si malfaisante que chaque homme, femme et enfant "
       "qui y habitaient devaient être mis à l'épée. Nous avons eu la chance d'avoir "
       "des paladins désireux de réaliser ce travail vertueux ! "
       "[Vous détectez une pointe d'ironie dans ses sourcils levés et son expression "
       "innocente]"))

(define (alch-lich knpc kpc)
  (say knpc "Une liche est un sorcier mort-vivant. Cette chose immonde corrompt tout "
       "ce qu'elle touche et commande les armées des morts. Son sang a beaucoup d'utilisations "
       "dans la nécromancie, qui n'est pas ma spécialité."))

;; The Accursed...
(define (alch-accu knpc kpc)
  (say knpc "Les soi-disant Maudits sont une société secrète à laquelle on reproche "
       "une multitude d'actes odieux, mais qui peut dire dans quelle mesure il s'agit de rumeurs ?"))

;; Townsfolk
(define (alch-lia knpc kpc)
  (say knpc "Une créature envoûtante ! "
       "Si je le pouvais, je briserais sa malédiction. En fait, je le ferais gratuitement. "
       "Appelez-moi un vieux fou !"))

(define alch-conv
  (ifc basic-conv
       (method 'default alch-default )
       (method 'bonj alch-hail )
	   (method 'hail alch-hail )
       (method 'adie alch-bye ) 
       (method 'trav alch-job )
       (method 'nom alch-name )
       (method 'join alch-join )

       (method 'echa alch-trade )
       (method 'ache alch-buy )
       (method 'vend alch-sell )
       (method 'poti alch-buy )

       (method 'rune alch-rune )
       (method 'plus alch-more )
       (method 'drag alch-drag )

       (method 'necr alch-necr )
       (method 'ench alch-ench )
       (method 'mec alch-man )
       (method 'hydr alch-hydr )
       (method 'warr alch-warr )
       (method 'inge alch-engi )
       (method 'alch alch-alch )

       (method 'absa alch-absa )
       (method 'pill alch-sack )
       (method 'evad alch-esca )
       (method 'malf alch-wick )
       (method 'lich alch-lich )

       (method 'maud alch-accu )

       (method 'lia alch-lia )
       (method 'abe alch-abe )

       ))

;;----------------------------------------------------------------------------
;; First-time constructor
;;----------------------------------------------------------------------------
(define (mk-alchemist)
  (bind 
   (kern-char-arm-self
    (kern-mk-char 
     'ch_alchemist ;;.....tag
     "L'Alchimiste" ;;.......name
     sp_human ;;.....species
     oc_wright ;;...occupation
     s_companion_tinker ;;......sprite
     faction-men ;;..faction
     0 ;;............custom strength modifier
     4 ;;............custom intelligence modifier
     1 ;;............custom dexterity modifier
     0 ;;............custom base hp modifier
     0 ;;............custom hp multiplier (per-level)
     0 ;;............custom base mp modifier
     0 ;;............custom mp multiplier (per-level)
     max-health ;;..current hit points
     -1  ;;...........current experience points
     max-health ;;..current magic points
     0
     8  ;;..current level
     #f ;;...........dead?
     'alch-conv ;;...conversation (optional)
     sch_alch ;;.....schedule (optional)
     'townsman-ai ;;..........custom ai (optional)
     nil ;;..........container (and contents)
     (list t_dagger
				t_armor_leather
				)  ;;......... readied arms (in addition to the container contents)
     nil ;;..........hooks in effect
     ))
   (alch-mk)))
