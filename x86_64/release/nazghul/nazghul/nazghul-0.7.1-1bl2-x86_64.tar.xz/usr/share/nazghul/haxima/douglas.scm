;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------

;;----------------------------------------------------------------------------
;; Schedule
;; 
;; In the Entrance to Kurpolis.
;;----------------------------------------------------------------------------
(define doug-bed ke-bed1)
(define doug-mealplace ke-tbl1)
(define doug-workplace ke-hall)
(define doug-leisureplace ke-dine)
(kern-mk-sched 'sch_doug
               (list 0  0 doug-bed          "dort")
               (list 11 0 doug-mealplace    "mange")
               (list 12 0 doug-workplace    "travaille")
               (list 18 0 doug-mealplace    "mange")
               (list 19 0 doug-leisureplace "suis en pause")
               (list 24 0 doug-workplace    "travaille")               
               )

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (doug-mk) nil)

;;----------------------------------------------------------------------------
;; Conv
;; 
;; Douglas is the Commander of the First Kurpolis Garrison,
;; stationed at the Entrance to Kurpolis, guarding the Goblin Kingdoms level.
;;----------------------------------------------------------------------------

;; Basics...
(define (doug-hail knpc kpc)
  (say knpc "[Vous rencontrez un sinistre paladin] Bienvenue aux portes de l'enfer, voyageur.")
  (if (and (in-player-party? 'ch_mesmeme)
           (is-alive? ch_mesmeme))
      (begin
        (say knpc "[Il montre du doigt Mesmeme] Vous emmenez ça au donjon ?")
        (if (yes? kpc)
            (say knpc "C'est au troisième niveau, sous le Repaire de Paladin. "
                 "Mais je ne pense pas qu'une prison puisse contenir un Hypnotiseur, "
                 "il serait préférable de le tuer.")
            (say knpc "Je n'en ai jamais vu un d'apprivoisé. Attention qu'il ne vous trahisse pas.")))))

(define (doug-default knpc kpc)
  (say knpc "Je ne peux pas vous aider à ce sujet."))

(define (doug-name knpc kpc)
  (say knpc "Je suis le capitaine Douglas, commandant de la première garnison de Kurpolis."))

(define (doug-join knpc kpc)
  (say knpc "Et déserter mon poste ? Je ne pense pas, et ne demandez pas à mes soldats, ou je vous ferai renvoyer à la surface."))

(define (doug-job knpc kpc)
  (say knpc "Je commande cette garnison."))

(define (doug-bye knpc kpc)
  (say knpc "Faites attention lorsque vous voyagez dans les profondeurs."))

;; Special
(define (doug-garr knpc kpc)
  (say knpc "Glasdrin maintient cette garnison ici pour réprimer les monstres de Kurpolis. Il y a une deuxième garnison plus loin."))

(define (doug-mons knpc kpc)
  (say knpc "A ce niveau, on trouve surtout des gobelins et des trolls. De temps en temps, quelque chose de pire surgit des profondeurs."))

(define (doug-gobl knpc kpc)
  (say knpc "Les gobelins des cavernes dominent ce niveau. Ils sont sauvages mais mal équipés. "
       "Il y a aussi une grotte où l'on peut trouver quelques gobelins des forêts qui ne sont généralement pas aussi hostiles. "
       "Les gobelins des forêts et des grottes ne s'entendent pas, ce qui permet de les contrôler."))

(define (doug-trol knpc kpc)
  (say knpc "Ces créatures crasseuses ont une grotte au-delà du village des gobelins. "
       "Nous les chassons de temps en temps, mais ils reviennent tout simplement. "
       "Parfois, je jure que les rochers eux-mêmes doivent donner naissance à des trolls."))

(define (doug-wors knpc kpc)
  (say knpc "Le pire que j'ai jamais vu ? C'est l' Hypnotiseur. Il y avait une poignée d'esclaves, dont certains étaient des paladins. Des hommes que j'ai connus autrefois. [Il frissonne et se détourne]")
  (kern-conv-end)
  )

(define (doug-kurp knpc kpc)
  (say knpc "Kurpolis est un vivier de monstres. On ne peut pas les exterminer, mais on peut garder le contrôle."))

(define (doug-seco knpc kpc)
  (say knpc "Pour rejoindre la deuxième garnison, allez à l'est d'ici jusqu'au carrefour, puis au sud et descendez l'échelle."))

(define (doug-gaze knpc kpc)
  (say knpc "L' Hypnotiseur est une créature issue d'un cauchemar. Les anciens ont le pouvoir d'asservir d'autres êtres et de les forcer à se battre pour eux."))

(define doug-conv
  (ifc kurpolis-conv

       ;; basics
       (method 'default doug-default )
       (method 'bonj doug-hail )
	   (method 'hail doug-hail )
	   
       (method 'adie doug-bye )
       (method 'trav doug-job )
       (method 'nom doug-name )
       (method 'join doug-join )

       (method 'garn doug-garr )
       (method 'mons doug-mons )
       (method 'gobe doug-gobl )
       (method 'trol doug-trol )
       (method 'pire doug-wors )
       (method 'kurp doug-kurp )
       (method 'enfe doug-kurp )
       (method 'port doug-kurp )
       (method 'deux doug-seco )
       (method 'hypn doug-gaze )
       ))

(define (mk-douglas)
  (bind 
   (kern-mk-char 'ch_douglas        ; tag
                 "Douglas"           ; name
                 sp_human            ; species
                 oc_warrior          ; occ
                 s_companion_paladin ; sprite
                 faction-men         ; starting alignment
                 2 2 1               ; str/int/dex
                 0 0                 ; hp mod/mult
                 0 0                 ; mp mod/mult
                 max-health -1 max-health 0 4  ; hp/xp/mp/AP_per_turn/lvl
                 #f                  ; dead
                 'doug-conv         ; conv
                 sch_doug           ; sched
                 'townsman-ai                 ; special ai
                 nil                 ; container
                 (list t_armor_chain
                       t_chain_coif
                       t_sword
                       ))         ; readied
   (doug-mk)))
