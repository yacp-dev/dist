;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------
(define lux-lvl 7)
(define lux-species sp_ghast)
(define lux-occ oc_wizard)

;;----------------------------------------------------------------------------
;; Schedule
;;
;; No schedule (found in Green Tower Tombs)
;;----------------------------------------------------------------------------

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (lux-mk) nil)

;;----------------------------------------------------------------------------
;; Conv
;; 
;; Luximene is a lich (or later, a shade conjured up from his skull),
;; sitting in rulership over the small realm of his treasury in 
;; ruined Kurpolis.  In life, he was a great king who conquered and united 
;; the Shard, and was ultimately overthrown by a coalition of those who 
;; became known as the Wise.
;;----------------------------------------------------------------------------

;; Basics...
(define (lux-hail knpc kpc)
  (say knpc "[Vous rencontrez une ombre qui brûle de malice] Que voulez-vous, "
       "mortel ?"))

(define (lux-default knpc kpc)
  (say knpc "Ne me faites pas perdre mon temps."))

(define (lux-name knpc kpc)
  (say knpc "Je suis Luximène le Grand, Seigneur du Royaume du Milieu."))

(define (lux-rune knpc kpc)
  (say knpc "[Il a l'air soudainement perturbé] C'est une cle, une des huit, "
       "fabriquée par les Sages pour verrouiller la Porte des Demons."))

(define (lux-gate knpc kpc)
  (say knpc "Chaque cle était donnée à un Gardien, chaque Gardien n'avait pas le droit de rencontrer les autres, "
       "et de transmettre leur patrimoine à un héritier. Es-tu un Gardien ?")
  (if (yes? kpc)
      (begin
        (say knpc "Alors pourquoi me demandes-tu cela ? Ton maître n'a-t-il pas expliqué ?")
        (if (yes? kpc)
            (say knpc "[Il rit de façon malveillante] Tu me prends pour un idiot, "
                 "et tu es fou de penser ainsi. La Rune sera ta perte, "
                 "et la fin de ton Epoque !")
            (say knpc "Maudite est l'Epoque où les Hommes ont oublié leurs serments.")))
      (begin
        (say knpc "Es-tu un Voleur ?")
        (if (yes? kpc)
            (say knpc "Condamnée est l'Epoque où même les voleurs ne connaissent pas la valeur de ce qu'ils volent.")
            (say knpc "Alors tu as obtenu la Rune par hasard, "
                 "et la fin de ton Epoque est proche.")))))

(define (lux-age knpc kpc)
  (say knpc "Lorsque la Porte des Demons a été scellée, l'Epoque des Sorciers a pris fin. "
       "C'est moi qui ai conquis et uni le Tesson, et l'Epoque de Luximene a commencée. "
       "Après moi, chaque souverain était pire que le précédent, et mon empire est tombé en ruine, "
       "et l'ère actuelle, l'Epoque Perdue, a commencé. Vous souhaitez connaître un grand secret ?")
  (if (yes? kpc)
      (say knpc "Alors je vais vous le dire, car vous êtes le Dernier Gardien.")
      (say knpc "\n[La pièce se remplit de son terrible rire]\n"
	   "Mais c'est à toi de le savoir, \n"
           "Le dernier des Gardiens !"))
  (say knpc "L'Epoque perdue prendra fin lorsque la porte des demons sera ouverte."))

(define (lux-keep knpc kpc)
  (say knpc "Tu es le dernier Gardien. Tu as une Rune, et tu connais sa signification. "
       "Maintenant, toutes les Runes doivent être à toi pour les garder. Les as-tu en totalité ?")
  (if (yes? kpc)
      (say knpc "Sois-en sûr, Gardien. La Porte ne s'ouvrira pas sans elles.")
      (say knpc "Trouvez-les. Un homme honorable sauvera une epoque de la disgrâce, "
           "mais peut-être pas lui-même.")))

(define (lux-wise knpc kpc)
  (say knpc "Les Sages ?  [Il rit]\n"
       "Des rebelles contre le dirigeant d'une Epoque !\n"
       "\n"
       "Le guerrier Argus,\n"
       "  qui a vaincu mes armées\n"
       " et ont mené leur expédition\n"
       "Le magicien Xileph,\n"
       "  qui a conseillé la rébellion\n"
       "  et a contré mes sortilèges\n"
       "Le Malfrat Narthax,\n"
       "  dont les vols ont fait de courageux ennemis des mines\n"
       "  et a trouvé mes passages secrets\n"
       "Le Fabricant Weilend,\n"
       " qui a équipé la mission\n"
       "  contre ma forteresse\n"
       "\n"
       "Pourtant, dans ma défaite, a été forgé leur MALHEUR!"
       "\n")
  (say knpc "\n[Il vous regarde avec attention]\n"
       "Comment ?  Tu ne connait point ces noms ?")
  (if (yes? kpc)
      (say knpc "Alors, émerveille-toi devant ma légende !")
      (begin
	(say knpc
	     "\n[Ses yeux froids brillent de colère]\n"
	     "Ah, tu fait plutôt référence à ceux que l'on appelle les Sages de cette Epoque.\n"
	     "Je ne sais rien de ces questions insignifiantes.\n"
	     "Va-t'en, mortel !")
	(kern-conv-end)
	))
  )

(define (lux-accu knpc kpc)
  (say knpc "Les Maudits ?\n"
       "À chaque epoque, il y a ceux qui cherchent le pouvoir, "
       "qui ne seront pas détourné de cette recherche par des avertissements ou des scrupules.\n"
       "\n"
       "Certains seront détruits par cette recherche, "
       "tandis que d'autres atterrissent sous l'emprise de ces quelques personnes qui acquièrent le véritable pouvoir.\n"
       "\n"
       "Tels doivent être les vers dont tu parles.")
  )


(define lux-conv
  (ifc basic-conv

       ;; basics
       (method 'default lux-default )
       (method 'bonj lux-hail )
	   (method 'hail lux-hail )
	   
       (method 'nom lux-name )

       (method 'rune lux-rune )
       (method 'cle lux-rune ) ;; A synonym

       (method 'demo lux-gate ) ;; A synonym
       (method 'port lux-gate )

       (method 'sage lux-wise )
       (method 'maud lux-accu )

       (method 'epoq lux-age )
       (method 'gard lux-keep )

       ))

(define (mk-luximene)
  (bind 
   (kern-mk-char 
    'ch_lux           ; tag
    "Luximene"             ; name
    lux-species         ; species
    lux-occ              ; occ
    s_ghost     ; sprite
    faction-men      ; starting alignment
    0 0 0            ; str/int/dex
    0 0              ; hp mod/mult
    0 0              ; mp mod/mult
    max-health ; hp
    -1                   ; xp
    max-health ; mp
    0
    lux-lvl
    #f               ; dead
    'lux-conv         ; conv
    nil           ; sched
    nil              ; special ai
    nil              ; container
    nil              ; readied
    )
   (lux-mk)))

(define (mk-lich-king)
  (let ((kchar 
         (bind 
          (kern-char-force-drop
           (kern-mk-char 
            'ch_lich_king           ; tag
            "Roi Liche" ; name
            sp_lich         ; species
            oc_wizard              ; occ
            s_lich     ; sprite
            faction-monster      ; starting alignment
            10 10 10            ; str/int/dex
            10 1              ; hp mod/mult
            0  0              ; mp mod/mult
            max-health ; hp
            -1                   ; xp
            max-health ; mp
            0
            8
            #f               ; dead
            nil              ; conv
            nil             ; sched
            'lich-ai        ; special ai
            (mk-inventory
             (list (list 1 t_morning_star)
                   (list 1 t_armor_chain_4)
                   (list 1 t_chain_coif_4)
                   (list 100 t_gold_coins)
                   (list 3 t_mana_potion)
                   (list 3 t_heal_potion)
                   (list 1 t_lich_skull)
                   (list 1 t_lichs_blood)
                   ))
            nil              ; readied
            )
           #t)
          (lux-mk))))
    (map (lambda (eff) (kern-obj-add-effect kchar eff nil))
         undead-effects)
    kchar))

