;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------

;;----------------------------------------------------------------------------
;; Schedule
;; 
;; In Glasdrin.
;;----------------------------------------------------------------------------
(kern-mk-sched 'sch_jeff
               (list 0  0  gcj-bed      "dort")
               (list 7  0  gs-altar    "suis en pause")
               (list 8  0  ghg-s6      "mange")
               (list 9  0  gc-hall     "travaille")
               (list 12 0  ghg-s3      "mange")
               (list 13 0  gc-train    "travaille")
               (list 18 0  ghg-s3      "mange")
               (list 19 0  ghg-hall    "suis en pause")
               (list 21 0  gcj-bed      "dort")
               )

;; Make another schedule which will be assigned when Jeffreys resigns after the
;; trial.
(kern-mk-sched 'sch_jeff_resigned
               (list 0 0 kun-road "dort")
               (list 9 0 campfire-4 "suis en pause")
               (list 13 0 cantina-5 "suis en pause")
               (list 20 0 kun-road "suis en pause")
               )

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (jeff-mk) nil)
               
;;----------------------------------------------------------------------------
;; Conv
;; 
;; Jeffreys is the Commander of the Paladins of Glasdrin.
;; He lives in Glasdrin, and reports directly to the ruler there,
;; currently the Stewardess, Victoria.
;;----------------------------------------------------------------------------

;; Basics...
(define (jeff-hail knpc kpc)
  (cond	((player-stewardess-trial-done?)
         (say knpc "Je veux que vous sachiez, Vagabond, que je n'ai pas trahi la Warritrix. Je n'étais pas informé au sujet de l'embuscade. "
              "Mais je savais que quelque chose n'allait pas, j'aurais dû agir en fonction de mes soupçons. "
              "Le commandant de la Glasdrin ne doit jamais manquer de diligence. "
              "Pour cette raison, j'ai démissionné de mon poste.")
         (aside kpc 'ch_ini "Ne faites pas semblant d'être innocent, espèce de vieux crapaud corrompu. "
                "Si jamais nous nous rencontrons sur le terrain, ce sera la fin de l'un d'entre nous.")
         (kern-conv-end)
         )
        (else
         (say knpc "[Vous rencontrez un splendide paladin] Enchanté, monsieur.")
         )))

(define (jeff-default knpc kpc)
  (say knpc "Je ne peux pas vous aider à ce sujet."))

(define (jeff-name knpc kpc)
  (say knpc "Je suis le commandant Jeffreys."))

(define (jeff-join knpc kpc)
  (say knpc "J'ai déjà du travail."))

(define (jeff-job knpc kpc)
  (say knpc "Je commande les paladins de Glasdrin."))

(define (jeff-bye knpc kpc)
  (say knpc "Adieu à vous."))

;; Special
(define (jeff-comm knpc kpc)
  (say knpc "Je suis le plus haut fonctionnaire de Glasdrin, "
       "excepté la Regisseuse. La force militaire de Glasdrin m'a fait un rapport."))

(define (jeff-mili knpc kpc)
  (say knpc "Glasdrin est imprenable sur terre. Tous les citoyens de Glasdrin sont "
       "tenus de rendre service. Etant donné que tout le monde a reçu une formation de base "
       "ils peuvent être appelés à agir en cas de crise."))

(define (jeff-pala knpc kpc)
  (say knpc "Les paladins de Glasdrin sont les meilleurs guerriers que le Tesson n'aie "
       "jamais eu. Individuellement, leurs compétences varient, bien sûr, mais leur "
       "force vient du combat en restant unis."))

(define (jeff-skil knpc kpc)
  (say knpc "Oui, qu'il s'agisse d'une jeune recrue ou de la Warritrix elle-même, "
       "lorsqu'ils se battent avec d'autres en restant unis, les paladins de Glasdrin sont "
       "pratiquement imbattables."))

(define (jeff-warr knpc kpc)
  (cond ((player-found-warritrix?)
         (if (ask? knpc kpc "[Tousse] Oui. C'est très malheureux. Nous pleurons tous sa perte. "
                   "Mais pour perdre toute son équipe de cette façon, elle a dû faire une erreur de jugement. "
                   "Vous ne pensez pas ?")
             (say knpc "Oui, cela arrive aux meilleurs d'entre nous. Chaque chef militaire fait des erreurs, "
                  "et cela coûte des vies. Maintenant, j'ai peur d'être très occupé. Bonne journée, monsieur.")
             (if (ask? knpc kpc "Vous insinuez qu'elle a été conduite dans une sorte de piège ?")
                 (say knpc "C'est ridicule. Je n'ai rien à vous répondre. "
                      "Parlez à la Regisseuse si vous avez une plainte à formuler. "
                      "Et si vous essayez de faire du grabuge, les gardes vous expulseront de la ville.  "
                      "En fait, il serait peut-être préférable que vous filez d'ici maintenant.")
                 (say knpc "Très bien. Les erreurs se produisent en temps de guerre. Parfois, même des amis sont tués, "
                      "lorsqu'on les prend pour des ennemis. J'espère que vous prendrez soin de vous, mon ami. Bonne journée.")
                 ))
         (kern-conv-end)
         )
	 ((quest-data-assigned? 'questentry-wise)
         (say knpc "La Warritrix est un trésor vivant ; la plus rusée, la plus polyvalente "
              "des guerriers de l'époque. Je l'ai vue battre des hommes de deux fois sa taille et "
              "d'abattre des bêtes redoutables. Pour l'instant, elle a été appelée pour faire "
              "une course.")
              (quest-data-update 'questentry-warritrix 'assignment 1)
         )
	 (else
         (say knpc "La Warritrix est un trésor vivant ; la plus rusée, la plus polyvalente "
              "des guerriers de l'époque. Je l'ai vue battre des hommes de deux fois sa taille et "
              "d'abattre des bêtes redoutables.  En ce moment, elle est en patrouille.")
              (quest-data-update 'questentry-warritrix 'general-loc 1)
         )
	 ))

(define (jeff-warr-ready subfn)
	(if (quest-data-assigned? 'questentry-wise)
		(subfn)
		(jeff-default knpc kpc)
		))

(define (jeff-erra knpc kpc)
	(jeff-warr-ready (lambda ()
  (say knpc "[Il a l'air un peu mal à l'aise] Oui, elle a emmené une équipe dans les Salles Perdues. "
       "C'est étrange qu'elle n'ait pas encore fait son rapport... "
       "Normalement, je devrais envoyer une équipe de recherche, "
       "mais pour le moment, je n'ai pas de troupes disponible.")
      (quest-data-update-with 'questentry-rune-l 'located 1 (quest-notify nil)) 
      (quest-data-update 'questentry-warritrix 'lost-hall 1)
       )))

(define (jeff-sear knpc kpc)
	(jeff-warr-ready (lambda ()
	(say knpc "[Il s'exaspère] Je ne peux épargner à personne de chercher la "
       "Warritrix ! Maintenant, si ça ne vous dérange pas, je suis très occupé ...")
  (kern-conv-end)
  (if (is-player-party-member? ch_ini)
      (say ch_ini "Quelque chose sent la pourriture dans le Danemark. "
           "Nous devons la trouver !"))
  )))

;; Townspeople...
(define (jeff-glas knpc kpc)
  (say knpc "Ville puissante, Glasdrin n'est jamais tombée aux mains des envahisseurs."))

(define (jeff-ange knpc kpc)
  (say knpc "Angela est une femme très gracieuse et hospitalière."))

(define (jeff-patc knpc kpc)
  (say knpc "Docteur Patch est un médecin expérimenté et le chef de notre hôpital."))

(define (jeff-stew knpc kpc)
  (say knpc "La Regisseuse porte bien le poids du leadership."))

(define (jeff-ini knpc kpc)
  (say knpc "Le lieutenant Inago est un guerrier très naturel et un excellent officier."))

(define (jeff-jess knpc kpc)
  (say knpc "Jess est une jeune fille enjouée, et un spectacle bienvenu à la fin d'une "
       "dure journée quand elle rempli les verres."))

(define (jeff-ches knpc kpc)
  (say knpc "Son bras puissant nous manque au combat, mais ses armes et son armure "
       "nous servent également."))

(define (jeff-lost knpc kpc)
  (say knpc "Les Salles Perdues est un endroit très dangereux. Pas de place pour les amateurs. "
       "Je vous conseille de rester à l'écart ! Maintenant, bonne journée, monsieur !")
  (kern-conv-end)
  (if (is-player-party-member? ch_ini)
	(begin
      (say ch_ini "Ne vous inquiétez pas. Je sais où trouver les Salles Perdues. "
           "Nous devrons prendre un bateau et naviguer vers ["
           (loc-x lost-halls-loc) " "
           (loc-y lost-halls-loc) "].")
	   (quest-data-update-with 'questentry-rune-l 'know-hall 1 (quest-notify nil))
	   (quest-data-update 'questentry-warritrix 'lost-hall-loc 1)
	   )
	   )
  )

(define jeff-conv
  (ifc glasdrin-conv

       ;; basics
       (method 'default jeff-default )
       (method 'bonj jeff-hail )
	   (method 'hail jeff-hail )
	   
       (method 'adie jeff-bye )
       (method 'trav jeff-job )
       (method 'nom jeff-name )
       (method 'join jeff-join )

       (method 'comm jeff-comm )
       (method 'jani (lambda (knpc kpc) (say knpc "Mon assistante Janice est inestimable en tant que tacticienne.")))
       (method 'mili jeff-mili )
       (method 'pala jeff-pala )
       (method 'warr jeff-warr )
       (method 'cour jeff-erra )
       (method 'glas jeff-glas )
       (method 'ange jeff-ange )
       (method 'sall jeff-lost )
       (method 'patc jeff-patc )
       (method 'regi jeff-stew )
       (method 'vict jeff-stew )  ;; A synonym
       (method 'ini jeff-ini )
       (method 'inag jeff-ini )
       (method 'jess jeff-jess )
       (method 'ches jeff-ches )
       ))

(define (mk-jeffreys)
  (bind 
   (kern-mk-char 'ch_jeffreys       ; tag
                 "Jeffreys"          ; name
                 sp_human            ; species
                 oc_warrior          ; occ
                 s_companion_paladin ; sprite
                 faction-glasdrin         ; starting alignment
                 2 1 1               ; str/int/dex
                 0 0                 ; hp mod/mult
                 0 0                 ; mp mod/mult
                 max-health -1 max-health 0 5  ; hp/xp/mp/AP_per_turn/lvl
                 #f                  ; dead
                 'jeff-conv         ; conv
                 sch_jeff           ; sched
                 'townsman-ai                 ; special ai
                 nil                 ; container
                 (list t_armor_chain
                       t_chain_coif
                       t_sword
                       ))         ; readied
   (jeff-mk)))
