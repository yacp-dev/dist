;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------
(define silas-lvl 8)
(define silas-species sp_human)
(define silas-occ oc_wizard)
(define shrine-path-x 97)
(define shrine-path-y 5)

;;----------------------------------------------------------------------------
;; Schedule
;; 
;; In Old Absalot
;;----------------------------------------------------------------------------
(define silas-bed oa-bed1)
(define silas-mealplace oa-tbl3)
(define silas-workplace oa-temple)
(define silas-leisureplace oa-baths)
(kern-mk-sched 'sch_silas
               (list 0  0 silas-bed          "dort")
               (list 7  0 silas-mealplace    "mange")
               (list 8  0 silas-workplace    "travaille")
               (list 12 0 silas-mealplace    "mange")
               (list 13 0 silas-workplace    "travaille")
               (list 18 0 silas-mealplace    "mange")
               (list 19 0 silas-leisureplace "suis en pause")
               (list 22 0 silas-bed          "dort")
               )

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (silas-mk) 
  (list #f (mk-quest) #f))
(define (silas-set-will-help! gob) (set-car! gob #t))
(define (silas-will-help? gob) (car gob))
(define (silas-quest gob) (cadr gob))
(define (silas-met? gob) (caddr gob))
(define (silas-set-met! gob) (set-car! (cddr gob) #t))

;;----------------------------------------------------------------------------
;; Conv
;; 
;; Silas is the leader of the evil cult of the Accursed.
;; He is a wizard of considerable power.
;;----------------------------------------------------------------------------

;; Basics...
(define (silas-hail knpc kpc)
  (if (silas-met? (kobj-gob-data knpc))
      (say knpc "Bonjour à nouveau, Vagabond.")
      (begin
        (silas-set-met! (kobj-gob-data knpc))
        (say knpc "[Vous rencontrez un charmant homme âgé] Salut, voyageur. "
             "Si je ne me trompe pas, vous êtes bien celui que l'on nomme Vagabond. Ai-je raison ?")
        (if (yes? kpc)
            (say knpc "Ah, je le savais ! En fait, je vous attendais.")
            (say knpc "[Il est clair qu'il ne vous croit pas] "
                 "Vraiment, vous êtes trop modeste. "
                 "Je vous attends depuis un certain temps.")))))

(define (silas-default knpc kpc)
  (say knpc "Je crains de ne pouvoir vous aider à cet égard."))

(define (silas-name knpc kpc)
  (say knpc "Pardonnez-moi, je suis Silas. Et toi, mon ami, "
       "tu n'a pas besoin d'être présenté."))

(define (silas-ask-help knpc kpc)
  (cond ((yes? kpc)
         (say knpc "Je ne peux pas vous dire à quel point je suis heureux d'entendre cela. "
              "Avec vous à mes côtés, nous apporterons une nouvelle ère d'espoir et "
              "de paix dans le Tesson. Quand vous serez prêt à commencer, "
              "J'ai une quete pour vous.")
         (silas-set-will-help! (kobj-gob-data knpc))
         (make-allies knpc kpc)
         )
        (
		else
		 ( begin
           (say knpc "Bien que le succès soit très douteux aujourd'hui, "
              "Je devrai faire de mon mieux sans vous. "
              "C'est dommage. Vous savez, dans le passé, l'apparition d'un Vagabond ")
			  
			  (prompt-for-key)
			  
            (say knpc "s'est toujours produite à un moment charnière de l'histoire. "
              "Les actions - ou inactions - du Vagabond parfois "
              "ont décidé du destin du monde pendant les siècles qui ont suivi.")
		  )
        )))

(define (silas-join knpc kpc)
  (say knpc "[Rigole] En fait, j'espérais vous convaincre de vous joindre à MOI. "
       "J'ai une tâche très difficile devant moi, mais avec votre aide, je sais que "
       "cela peut être fait. Allez-vous m'aider ?")
  (silas-ask-help knpc kpc)
  )

(define (silas-job knpc kpc)
  (say knpc "Mon objectif est d'apporter un nouvel âge d'or au Tesson."
       "De multiples obstacles se dressent devant moi, "
       "et j'ai grandement besoin de quelqu'un avec vos talents. "
       "Veux-tu m'aider, Vagabond ? Je ne peux pas le faire sans toi.")
  (silas-ask-help knpc kpc)
  )

(define (silas-help knpc kpc)
  (say knpc "Voulez-vous m'aider dans ma tâche ?")
  (silas-ask-help knpc kpc)
  )

(define (silas-bye knpc kpc)
  (say knpc "Alors adieu, Vagabond, je te souhaite beaucoup de chance !"))

;; Tier 2
(define (silas-expe knpc kpc)
  (say knpc "Oui, j'ai entendu parler de votre venue. "
       "Je savais que tôt ou tard, vous apparaîtriez. "
       "J'ai beaucoup étudié l'histoire des Vagabonds."))
(define (silas-hist knpc kpc)
  (say knpc "Lorsque la bibliothèque ci-dessus a été brûlée, la plupart des archives ont été perdues. "
       "J'ai bien peur que le meilleur récit des Vagabonds se trouve maintenant dans ce maigre livre. "
       "[Il se tape la tête]"))
(define (silas-wand knpc kpc)
  (say knpc "Tous les Vagabonds arrivent par la porte du sanctuaire, comme vous l'avez fait. Mais saviez-vous qu'il y a une autre Porte ?")
  (if (yes? kpc)
      (say knpc "Vous êtes déjà bien informés ! Bien sûr, je parle de la Porte des Demons.")
      (say knpc "En effet, c'est le cas. Elle est connue sous le nom de Porte des Demons.")))

(define (silas-demo knpc kpc)
  (say knpc "Pendant longtemps, la Porte des Demons a connecté le Tesson vers d'autres mondes. "
       "Ce fut un âge d'or de progrès et d'illumination, "
       "quand les sorciers de ce monde et d'autres se côtoyaient librement, "
       "en partageant des connaissances et le commerce.")
  (prompt-for-key)
  (say knpc "Mais finalement, des problèmes ont commencé à surgir. "
       "Un des autres mondes a commencé à conquérir les autres, "
       "utilisant la porte pour déplacer ses armées. De peur que le Tesson ne soit également "
       "envahis, nos sorciers ont scellé la Porte des Demons avec huit serrures, et ont partagé  "
       "les cles entre eux pour les garder en sécurité."))

(define (silas-key knpc kpc)
  (if (any-in-inventory? kpc rune-types)
      (say knpc "Les cles sont des runes spéciales, comme celle que vous portez déjà.")
      (say knpc "Les cles sont des runes spéciales. Malheureusement, elles ont été perdues à travers les âges.")))

(define (silas-rune knpc kpc)
  (say knpc "J'ai fait de la récupération de toutes les runes perdues mon objectif principal. Même si "
       "nous choisissons de garder la Porte des Demons fermée pour toujours, nous devrions au moins savoir que "
       "les runes sont toutes répertoriées et bien gardées. N'êtes-vous pas d'accord ?")
  (if (yes? kpc)
      (say knpc "Bien sûr, il s'agit simplement d'une bonne politique.")
      (say knpc "Mais pensez à la possibilité que les runes tombent entre de mauvaises mains, "
           "ou si un jour nous devions évacuer le Tesson, "
           "ou si nous devions faire appel à l'aide des autres mondes ? "
           "Il est certainement bon d'avoir la possibilité d'ouvrir la Porte des Demons, "
           "même si nous n'avons jamais l'intention de nous en servir.")))

;; Accursed, Wise
(define (silas-accu knpc kpc)
  (say knpc "[Il ricane] Hé oui, je suis un Maudit. Malheureusement, ce nom est venu "
       "à être diabolisé par l'imagination populaire. Toutes sortes de contes sauvages abondent "
       "concernant nos activités présumées. Je vous assure qu'aucune d'entre elles n'est vraie. ")
       
	   (prompt-for-key)
	   
  (say knpc "Mais nous ne pouvons pas nous défendre en révélant ce que nous faisons réellement, car nous avons tous prêté serment "
       "au secret le plus total."))

(define (silas-secr knpc kpc)
  (say knpc "Les rites des Maudits sont gardés secrets pour les protéger "
       "des gens profanes, et pour protéger les gens stupides de leurs tentations! Ces rites saints sont  "
       "révérés et dangereux, et non destinés aux non-initiés. Mais je vous assure, "
       "ils n'impliquent rien de nuisible pour les innocents!"))

(define (silas-wise knpc kpc)
  (say knpc "Ah, oui. Les soi-disant Sages. Vous savez, ils font partie d'une "
       "tradition vénérable et utile. Au moins, c'était une tradition utile dans le passé "
       "[Soupir] Je crains qu'à présent les Sages représentent plus un obstacle pour le Tesson qu'ils ne "
       "sont une aide. Considérez toute cette affaire avec Absalot."))
 
(define (silas-absa knpc kpc)
  (say knpc "Vous connaissez sans doute déjà l'histoire. L'Enchanteur, "
       "dans une jalousie malavisée de nos secrets, est obsédé par l'élimination "
       "des Maudits. La Régisseuse de Glasdrin est avide de pouvoir et rêve d'un "
       "empire militaire.")
    
	(prompt-for-key)
	
   (say knpc    "Elle prévoit de conquérir ou de raser les villes du Tesson une par "
       "une, Absalot était simplement la première et la plus commode des cibles. Elle a facilement "
       "manipulé les preuves contre Absalot et a convaincu les autres villes et "
       "l'Enchanteur pour la détruire. Le reste n'est que de l'histoire.")
	   
)

;; Philosophy
(define (silas-evil knpc kpc)
  (say knpc "Qu'est-ce que le mal, vraiment ? Je ne dis pas que le mal "
       "n'existe pas. Je vous demande simplement de remettre en question vos notions conventionnelles de ce qui est "
       "mal. Si une personnalité autoritaire nous dit que quelque chose ne va pas, devons-nous "
       "le prendre au mot?")
	   
	   (prompt-for-key)
	   
  (say knpc "Les autorités ne sont-elles pas des gens comme nous, avec leur propre "
       "objectifs? Chacun agit selon ses propres motivations égoïstes, vous savez, "
       "qu'ils l'admettent ou non.")
  
  (prompt-for-key)
  
  (say knpc "Et en effet, Vagabond, c'est comme il se doit ! Tous devraient s'efforcer de défendre "
       "ses propres intérêts, car c'est la manière naturelle de faire les choses. Tous les hommes sont ")
       
	   (prompt-for-key)
	   
   (say knpc "des pièces dans un jeu qu'ils ne peuvent pas éviter de jouer. Nier le jeu, nier son propre "
       "rôle dans le jeu, accepter la croyance que ses propres intérêts ne soient pas aussi importants "
       "que ceux d'un autre, ce sont toutes des tromperies propagées par ses adversaires.")
)

(define (silas-good knpc kpc)
  (say knpc "Vous me demandez du bien, et je vous demande en retour, qu'est-ce que vous "
       "desirez le plus ? Une chose n'a de valeur que lorsqu'elle est desirée par les Hommes. Quelle ironie "
       "que l'on veuille apprendre aux Hommes à supprimer leurs desirs, à les assouvir par la tolérance, ")
       
	   (prompt-for-key)
	   
   (say knpc "comme s'ils étaient mauvais parce que ce sont des desirs, alors qu'en fait c'est le contraire qui est vrai ! "
       "Je vais vous dire un grand secret, c'est le desir de certains Hommes que tous les autres Hommes "
       "veulent assouvir leurs desirs !"))

(define (silas-desi knpc kpc)
  (say knpc "Oui, tout comme l'esprit anime la chair, ainsi le desir anime "
       "l'esprit. Sans lui, l'esprit est apathique et vide. C'est le premier pas "
       "des Maudits, pour reconnaître leurs propres desirs comme ce qu'ils sont : le bien ultime, "
       "digne de tout sacrifice et de tout effort."))

(define (silas-sacr knpc kpc)
  (say knpc "La doctrine du Maudit soutient que le sacrifice est une échelle "
       "pour le desir. Le sacrifice est le résultat inévitable d'un choix, car tout n'est pas possible !"
       "Pour rendre possible l'objet des desirs, il faut nier les autres possibilités.")
       
	   (prompt-for-key)
	   
   (say knpc "De même que la branche d'un arbre peut être coupée par des cisailles, de même chaque choix que l'on fait "
       "cisaille une branche entière de l'avenir. C'est ce que nous entendons par sacrifice : "
       "l'élagage de l'arbre des possibilités.")
)



;; People
(define (silas-ench knpc kpc)
  (say knpc "C'est dommage qu'il soit un tel ennemi des Maudits. Mais je crains "
       "qu'il ne soit trop vieux et inflexible, et une fois qu'il a décidé que quelque chose est mauvais, "
       "il ne peut plus changer d'avis. Malheureusement, ses notions du bien et du mal "
       "sont erronées et inapplicables."))

(define (silas-deni knpc kpc)
  (say knpc "Dennis est un jeune homme sérieux mais franchement sans imagination."))

(define (silas-sele knpc kpc)
  (say knpc "Selene est une jeune femme talentueuse. "
       "Malheureusement, ses pouvoirs seront toujours inhibés par son insatiable "
       "cruauté."))
 
;; Quest-related
(define (silas-ques knpc kpc)
  (let* ((gob (kobj-gob-data knpc))
        (quest (silas-quest gob)))

    (define (has-all-runes?)
      (all-in-inventory? kpc rune-types))

    (define (missing-only-s-rune?)
      (all-in-inventory? kpc
                         (filter (lambda (ktype)
                                   (not (eqv? ktype t_rune_s)))
                                 rune-types)))

    (define (give-last-rune)
      (say knpc "Je vois qu'il vous manque encore une rune pour avoir la totalité. Veuillez me pardonner pour "
           "cette petite déception, mais j'ai caché la dernière rune ici "
           "dans le Vieux Absalot. Considérez qu'il s'agit maintenant d'un dernier test pour vous permettre de la trouver.")
	(quest-data-update-with 'questentry-rune-s 'silasinfo 1 (quest-notify nil))
	(quest-data-assign-once 'questentry-rune-s)
	)

    (define (continue-quest) 
      (say knpc "Je vois qu'il vous manque encore des runes. N'abandonnez pas, "
           "Vagabond! Demandez parmi les Sages, plongez dans les profondeurs, cherchez au loin."))

    (define (end-quest)
      (quest-done! quest #t)
      (say knpc "Bravo, Vagabond! Vous avez rassemblé toutes les runes perdues, "
           "un exploit digne de la légende. Bravo, en effet !")
      (prompt-for-key)
      (say knpc "Maintenant que toutes les runes sont récupérées, il est impératif que "
           "qu'elles soient gardées en sécurité. Pardonnez-moi d'être trop soupçonneux, mais je ne fais pas confiance "
           "aux Sages, ni même à l'Enchanteur lui-même, pour les garder.")
      (prompt-for-key)
      (say knpc "Je sais ce que tu penses, mon ami, mais oublie cette idée ! "
           "Je ne pourrais pas les garder ici avec moi. Et je ne le veux pas non plus. "
           "Non, j'ai quelque chose de beaucoup plus audacieux en tête. ")
      (prompt-for-key)
      (say knpc "Vagabond, le temps est venu de prendre le taureau par les cornes. En effet, je "
           "sent que c'est ce qui vous a amené jusqu'au Tesson. Prenez les cles, trouvez la Porte, "
           "et déverrouillez-la. Faites face à ce qui se trouve à l'intérieur. Soyez audacieux, et vous entrerez dans une Nouvelle "
           "Ère. Le ferez-vous ?")
      (if (yes? kpc)
          (say knpc "Alors je vais vous dire un grand secret qui reste caché même aux "
               "Sages : les dieux vivent encore, tout comme leurs ennemis. Je ne sais pas à quoi vous allez devoir faire face. Mais "
               "je ne sais qu'une chose : leurs ennemis ont scellé la Porte. ")
		   
          (say knpc "[Ses épaules s'affaissent] Ce n'était pas votre fardeau à porter, "
               "Vagabond, car vous êtes un étranger à ce "
               "monde. Gardez les cles en sécurité, au moins, si vous ne changez pas d'avis.")))
           
    (define (offer-quest)
      (say knpc "Vagabond, j'ai une tâche très importante pour toi : trouver les huit "
           "cles runiques qui verrouillent la Porte des Demons. Voulez-vous le faire ?")
      (if (yes? kpc)
          (begin
            (quest-accepted! quest #t)
            (cond
            	((has-all-runes?)
            		(say knpc "Vous avez déjà les runes ?")
            		(prompt-for-key)
            		(end-quest)
            		)
            	((missing-only-s-rune?)
            		(give-last-rune))
            	(#t
            		(say knpc "Je sais que je peux compter sur vous. Il y a un homme très sage et intelligent, "
                 	"un Alchimiste, qui vit dans Oparine. Vous le connaissez peut-être déjà. Il serait "
                 	"une bonne base de départ."))
             ))
          (say knpc "Il est impératif que nous les trouvions. Je suis vraiement déçu, mon "
               "ami, mais vous avez sans doute vos propres raisons.")))

    (if (silas-will-help? gob)
        (if (quest-done? quest)
            (say knpc "Cherchez la Porte des Demons !")
            (if (quest-accepted? quest)
                (if (has-all-runes?)
                    (end-quest)
                    (if (missing-only-s-rune?)
                        (give-last-rune)
                        (continue-quest)))
                (offer-quest)))
        (say knpc "Rejoignez-moi, et il y aura des quetes et de la gloire en abondance. "
             "Vous deviendrez le plus célèbre des Vagabonds -- en effet, "
             "le plus grand héros du Tesson -- pour toujours."))
    ))

(define (pissed-off-silas knpc kpc)
  (map (lambda (tag)
         (if (defined? tag)
             (let ((kchar (eval tag)))
               (if (is-alive? kchar)
                   (begin
                     (kern-being-set-base-faction kchar faction-accursed)
                     (kern-char-set-schedule kchar nil)
                     )))))
       (list 'ch_silas 'ch_dennis 'ch_selene))
  (make-enemies knpc kpc)
  )

(define (silas-noss knpc kpc)
  (say knpc "[Son visage se fige] Comment avez-vous appris ce nom, mon ami ?")
  (kern-conv-get-reply kpc)
  (say knpc "Avez-vous fouiné dans la propriété d'autrui ?")
  (if (yes? kpc)
      (say knpc "Comme c'est malheureux. Je crains qu'il soit temps pour vous de partir.")
      (say knpc "Je pense que c'est le cas. Je pense que vous vous êtes mal conduit, "
           "et maintenant vous racontez des mensonges. Vous n'êtes pas le bienvenu ici. "
           "Partez sur-le-champ !!."))
  (pissed-off-silas knpc kpc)
  (kern-conv-end)
  )

(define silas-conv
  (ifc basic-conv

       ;; basics
       (method 'default silas-default )
       (method 'bonj silas-hail )
       (method 'adie silas-bye )
       (method 'trav silas-job )
       (method 'nom silas-name )
       (method 'join silas-join )

       (method 'absa silas-absa )
       (method 'maud silas-accu )
       (method 'demo silas-demo )
       (method 'deni silas-deni )
       (method 'denn silas-deni )
       (method 'desi silas-desi )
       (method 'ench silas-ench )
       (method 'mal silas-evil )
       (method 'atte silas-expe )
       (method 'port silas-demo )
       (method 'bien silas-good )
	   (method 'bonn silas-good )
	   (method 'bon  silas-good )
	   
       (method 'aide silas-help )
       (method 'hist silas-hist )
       (method 'cles silas-key )
       (method 'serr silas-key )
       (method 'noss silas-noss )
       (method 'quet silas-ques )
       (method 'rune silas-rune )
       (method 'sacr silas-sacr )
       (method 'secr silas-secr )
       (method 'sele silas-sele )
       (method 'occu silas-job )
       (method 'vaga silas-wand )
       (method 'sage silas-wise )
       ))

(define (mk-silas)
  (bind 
   (kern-mk-char 
    'ch_silas           ; tag
    "Silas"             ; name
    silas-species         ; species
    silas-occ              ; occ
    s_silas     ; sprite
    faction-men      ; starting alignment
    0 5 0            ; str/int/dex
    2 1              ; hp mod/mult
    2 1              ; mp mod/mult
    max-health ; hp
    -1                   ; xp
    max-health ; mp
	0
    silas-lvl
    #f               ; dead
    'silas-conv         ; conv
    sch_silas           ; sched
    'spell-sword-ai  ; special ai
    nil              ; container
    (list t_stun_wand) ; readied
    )
   (silas-mk)))
