;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------
(define jones-lvl 6)
(define jones-species sp_human)
(define jones-occ nil)

;;----------------------------------------------------------------------------
;; Schedule
;; 
;; In the Keep guarding Kurpolis.
;;----------------------------------------------------------------------------
(define jones-bed ph-bed1)
(define jones-mealplace ph-tbl1)
(define jones-workplace ph-arms)
(define jones-leisureplace ph-hall)
(kern-mk-sched 'sch_jones
               (list 0  0 jones-bed          "dort")
               (list 7  0 jones-mealplace    "mange")
               (list 8  0 jones-workplace    "travaille")
               (list 12 0 jones-mealplace    "mange")
               (list 13 0 jones-workplace    "travaille")
               (list 18 0 jones-mealplace    "mange")
               (list 19 0 jones-leisureplace "suis en pause")
               (list 22 0 jones-bed          "dort")
               )

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (jones-mk) nil)

;;----------------------------------------------------------------------------
;; Conv
;; 
;; Jones runs the supply depot for the Glasdrin militia.
;; He is stationed in the Keep guarding Kurpolis.
;;----------------------------------------------------------------------------

;; Basics...
(define (jones-name knpc kpc)
  (say knpc "Jonesy à votre service."))

(define (jones-job knpc kpc)
  (say knpc "Je dirige le dépôt de ravitaillement de la milice de Glasdrin. Vous souhaitez acheter des fournitures ?")
  (if (yes? kpc)
      (jones-trade knpc kpc)
      (say knpc "Si jamais vous avez besoin de quelque chose, je serai là.")))

;; Trade...
(define jones-merch-msgs
  (list "Passez au dépôt de ravitaillement  entre 9h00 et 18h00."
        "Je garde l'essentiel en stock."
        nil
        nil
        "Êtes-vous sûr d'en avoir assez ? Vous feriez mieux d'en obtenir davantage."
        "J'espère que vous en avez assez, pour votre bien."
   ))

(define jones-catalog
  (list
   (list t_arrow        1 "Ici, vous serez à la recherche de flèches de même que les Trolls recherchent les Grogs!")
   (list t_bolt         1 "Vous pouvez vous retrouver à court de carreaux en un clin d'oeil !")
   (list t_oil          6 "Oui, faites des réserves de cette huile brûlante. La situation s'aggrave en bas.")
   (list t_torch        6 "Vous ne voulez pas être à cours de torches en bas!")
   (list t_heal_potion 23 "Oui, elles sont chères, mais les potions de soin sont difficiles à obtenir et il est essentiel d'en avoir.")
   (list t_mana_potion 23 "Vous feriez mieux d'acheter des potions de mana en plus. Vos mages feront des heures supplémentaires.")
   (list t_food        10 "Il n'y a rien de pire que de manquer de nourriture quand on est perdu dans les niveaux inférieurs.")
   ))

(define (jones-trade knpc kpc) (conv-trade knpc kpc "buy" jones-merch-msgs jones-catalog))

;; Quest-related

(define jones-conv
  (ifc kurpolis-conv

       ;; basics
       (method 'trav jones-job )
       (method 'nom jones-name )
       
       ;; trade
       (method 'comm jones-trade )
       (method 'ache jones-trade )

       ))

(define (mk-jones)
  (bind 
   (kern-mk-char 
    'ch_jones        ; tag
    "Jones"             ; name
    jones-species         ; species
    jones-occ              ; occ
    s_townsman     ; sprite
    faction-men      ; starting alignment
    2 0 0            ; str/int/dex
    0 0              ; hp mod/mult
    0 0              ; mp mod/mult
    max-health ; hp
    -1                   ; xp
    max-health ; mp
    0
    jones-lvl
    #f               ; dead
    'jones-conv         ; conv
    sch_jones           ; sched
    'townsman-ai              ; special ai
    nil              ; container
    (list t_axe
    		t_armor_chain)              ; readied
    )
   (jones-mk)))
