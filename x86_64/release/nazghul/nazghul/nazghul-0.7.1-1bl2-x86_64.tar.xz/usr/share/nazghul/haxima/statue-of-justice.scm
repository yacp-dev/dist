;;----------------------------------------------------------------------------
;; This is the special statue that stands in the courtyard of Glasdrin. When
;; attacked, it speaks. This requires two objects: an object with a type in
;; order to support the 'attack interface, and a character type to have the
;; conversation. The illusion is that they are both the same object.
;;----------------------------------------------------------------------------

(define (soj-strike kobj kpc)
  (let ((kchar (mk-talking-statue)))
    (kern-obj-put-at kchar (kern-obj-get-location kobj))
    (kern-conv-begin kchar)
    (kern-obj-remove kchar)
    ))


(mk-obj-type 't_statue_of_justice "ancienne statue" s_headless_w_sword_statue layer-mechanism
             (ifc nil
                  (method 'xamine (lambda (knpc kpc)
                                    (kern-log-msg "Une gravure usée porte l'inscription GRÈVE POUR LA JUSTICE.")))
                  (method 'attack soj-strike )
                  ))

(define (soj-accuse knpc kpc)
  (say knpc "Qui accusez-vous ?")
  (let ((kchar (ui-target (kern-obj-get-location kpc) 19 obj-is-char?)))
    (cond ((null? kchar)
           (say knpc "Souhaitez-vous retirer votre accusation ?")
           (cond ((yes? kpc)
                  (say knpc "Maudit sois-tu : pour avoir joué avec les choses sérieuses, "
                       "une nuisance insignifiante hantera ton sommeil.")
                  (unrest-curse-apply-new kpc 'insect-party-l1)
                  (kern-conv-end))
                 (else
                  (soj-accuse knpc kpc))
                 ))
          (else
           (say knpc "Êtes-vous certain de vouloir accuser " (kern-obj-get-name kchar) "?")
           (cond ((no? kpc)
                  (soj-accuse knpc kpc))
                 (else
                  (say knpc (kern-obj-get-name kchar) ", vous êtes accusé par " (kern-obj-get-name kpc) ". ")
                  (soj-get-evidence knpc kpc kchar)
                  ))
           ))
    ))

(define (soj-get-evidence knpc kpc kchar)
  (say knpc (kern-obj-get-name kpc) ", vous pouvez également produire vos preuves.")
  (let ((ktype (kern-ui-select-item kpc)))
    (cond ((null? ktype)
           (say knpc "Avez-vous d'autres preuves ?")
           (cond ((no? kpc)
                  (shake-map 15)
                  (say knpc "Pour avoir accusé une autre personne avec des preuves insuffisantes, "
                       "vous êtes coupable d'avoir fait un faux témoignage. "
                       "Votre châtiment est l'exil.")
                  ;; todo: implement exile
                  (make-enemies knpc kpc)
                  (kern-obj-relocate kpc
                                     (kern-place-get-location (loc-place (kern-obj-get-location knpc)))
                                     nil)
                  (kern-conv-end)
                  )
                 (else (soj-get-evidence knpc kpc kchar))
                 ))
          ((or (not (equal? ktype t_stewardess_journal))
              (not (defined? 'ch_steward))
              (not (equal? kchar ch_steward)))
           (say knpc "La justice évaluera les preuves.")
           (log-dots 10 1000)
           (say knpc "Les preuves sont insuffisantes.")
           (prompt-for-key)
           (soj-get-evidence knpc kpc kchar)
           )
          (else
           (say knpc "La justice évaluera les preuves.")
           (log-dots 10 1000)
           (say knpc (kern-obj-get-name kchar) ", vous êtes coupable de trahison. Votre punition est la mort, "
                "et que votre nom soit à jamais une malédiction.")
           (aside kpc 'ch_ini "Enfin la justice !")
           (kern-being-set-current-faction kchar faction-monster)
           (quest-data-update-with 'questentry-warritrix 'avenged 1 (quest-notify (grant-party-xp-fn 200)))

           (if (defined? 'ch_jeffreys)
           		(begin
               		(kern-char-set-sched ch_jeffreys sch_jeff_resigned)
               		(kern-obj-set-sprite ch_jeffreys s_fallen_paladin)
               	)
               )

           (if (defined? 'ch_valus)
           		(begin
               		(kern-char-set-sched ch_valus sch_jeff)
               		(kern-obj-set-sprite ch_valus s_companion_paladin)
               	)
               )

           (kern-conv-end)
           ))
    ))
           
                  

(define (soj-hail knpc kpc)
  (say knpc "Cherchez-vous la justice ?")
  (cond ((no? kpc)
         (say knpc "Alors vous êtes maudit : un homme injuste vivrait parmi les bêtes, "
              "pour que les bêtes ne vous laissent pas de repos.")
         (unrest-curse-apply-new kpc 'wolf-party-l2)
         (kern-conv-end))
        (else
         (say knpc "Parlez franchement, ou soyez maudit. Accusez-vous une autre personne de vol, de faux témoignage, de rupture de serment ou de trahison ?")
         (cond ((no? kpc) 
                (say knpc "Alors allez en paix, et ne me frappez plus en vain.")
                (kern-conv-end))
               (else
                (say knpc "Soyez avertis ! Si vous accusez avec des preuves insuffisantes, vous serez coupable de faux témoignage et serez puni. "
                     "Êtes-vous certain de vouloir en accuser un autre en ce moment ?")
                (cond ((no? kpc)
                       (say knpc "Si vous accusez vraiment, alors allez en paix et rassemblez plus de preuves. Mais si vous accusez faussement, ne me frappez plus.")
                       (kern-conv-end))
                      (else
                       (say knpc "LA JUSTICE CONVOQUE L'ASSEMBLÉE !")
                       (shake-map 5)
                       (soj-assemble-everyone (kern-obj-get-location knpc))
                       (soj-accuse knpc kpc))
                      ))
               ))
        ))

(define (soj-assemble-everyone loc)
  (define (assemble townsfolk)
    (kern-map-repaint)
    (if (not (null? townsfolk))
        (assemble (filter notnull? 
                          (map (lambda (kchar)
                                 (cond ((in-range? loc 2 kchar) nil)
                                       (else
                                        (pathfind kchar loc)
                                        kchar)))
                               townsfolk)))))
  (assemble (filter (lambda (kchar)
                      (let ((gob (gob kchar)))
                        (and (not (null? gob))
                             (pair? gob)
                             (eq? 'townsman (car gob)))))
                    (kern-place-get-beings (loc-place loc))))
  )

(define soj-conv
  (ifc basic-conv
       (method 'bonj soj-hail )
	   (method 'hail soj-hail )
	   
       ))

(define (soj-ai knpc)
  #t)

(define (mk-talking-statue)
  (let ((kchar 
         (kern-mk-char 
          'ch_soj           ; tag
          "Statue de la justice"     ; name
          sp_statue         ; species
          nil              ; occ
          s_headless_w_sword_statue     ; sprite
          faction-glasdrin      ; starting alignment
          0 0 0            ; str/int/dex
          0 0              ; hp mod/mult
          0 0              ; mp mod/mult
          1000 ; hp
          0                   ; xp
          0 ; mp
          0
          9                ; lvl
          #f               ; dead
          'soj-conv         ; conv
          nil           ; sched
          'soj-ai              ; special ai
          nil              ; container
          nil              ; readied
          )))
    (kern-char-set-known kchar #t)
    kchar))
