;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------
(define angriss-lvl 20)

;;----------------------------------------------------------------------------
;; Schedule
;; 
;; No schedule.  (Angriss' Lair)
;;----------------------------------------------------------------------------

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (angriss-mk)
  (list #f (mk-quest)))

(define (angriss-quest angriss) (cadr angriss))
(define (angriss-spoke? angriss) (car angriss))
(define (angriss-spoke! angriss) (set-car! angriss #t))

;;----------------------------------------------------------------------------
;; Conv
;;
;; Angriss is Queen of the Spiders, dwelling in Angriss' Lair.
;; Suspicious, jealous, alien.
;;----------------------------------------------------------------------------

;; Basics...
(define (angriss-hail knpc kpc)
  (say knpc "Doux Hideux , qui\n"
       "n'est pas invité, soyez rapide\n"
       "dans l'honneur, ou vous mourrez."))

(define (angriss-default knpc kpc)
  (say knpc "[Toujours comme une statue dans sa toile, elle ne donne pas de réponse]"))

(define (angriss-name knpc kpc)
  (say knpc "Pour les Humains, Angriss ; Pour les\n"
       "Gobelins, Ruka; pour les\n"
       "Trolls, Hibliminos."))

(define (angriss-join knpc kpc)
  (say knpc "Les lèvres se joignent-elles à une tasse\n"
       "mais si ce n'est pour la vider de son contenu ? Mes semblables\n"
       "aux hommes s'y joignent."))

(define (angriss-job knpc kpc)
  (say knpc "La faim."))

(define (angriss-bye knpc kpc)
  (say knpc "L'empire de la lumière\n"
       "vous rappelle. Montez les escaliers\n"
       "si vous pouvez y accéder.\n"))


(define (angriss-soft knpc kpc)
  (say knpc "Pour boire le vin sombre\n"
       "Les hommes écrasent le raisin. Je bois le\n"
       "vin des Hommes écrasés."))

(define (angriss-hung knpc kpc)
  (say knpc "Un fleuve de sang\n"
       "coule vers ma tanière, une pile\n"
       "d'os grandit ici."))

(define (angriss-men knpc kpc)
  (say knpc "Si fiers en armure\n"
       "si doux dans l'aspect caché\n"
       "si doux dans la folie."))

(define (angriss-gobl knpc kpc)
  (say knpc "Une chasse furtive, une\n"
       "lutte terrible, à la\n"
       "fin le repos éternel."))

(define (angriss-trol knpc kpc)
  (say knpc "Lanceurs de pierres qui font bataille avec\n"
       "les rochers, votre redoutable mugissement\n"
       "deviendra un cri."))

(define (angriss-choose knpc kpc)
  (say knpc "Choisissez qui vous allez me donner.")
  (let ((kchar (kern-ui-select-party-member))
        (quest (angriss-quest (kobj-gob-data knpc))))
    (if (null? kchar)
        (begin
          (say knpc "Vous jouez avec un monstre, maintenant fuyez.")
          (harm-relations knpc kpc)
          (harm-relations knpc kpc)
          (kern-conv-end))
        (if (is-dead? kchar)
            (begin
              (say knpc "J'ai besoin de viande FRAÎCHE !\n"
                   "Poison ! Ignoble, c'est du sang mort !\n"
                   "Apportez-m'en un autre.")
              (kern-conv-end))
            (begin
              (say knpc "L'honneur est satisfait.\n")
              (if (not (quest-done? quest))
                  (quest-done! quest #t))
              (kern-char-leave-player kchar)
              (kern-being-set-base-faction kchar faction-none)
              (improve-relations knpc kpc)
              (kern-conv-end))))))


(define (angriss-rune knpc kpc)
  (let ((quest (angriss-quest (kobj-gob-data knpc))))
    (if (quest-done? quest)
        (begin
          (say knpc "L'ancien secret, \n"
               "La clé d'une serrure de l'enfer.\n"
               "Prends-la, elle est à toi.")
          (kern-obj-remove-from-inventory knpc t_rune_f 1)
          (kern-obj-add-to-inventory kpc t_rune_f 1)
          (rune-basic-quest 'questentry-rune-f s_runestone_f)
         )
        (say knpc "Je sais ce que vous cherchez.\n"
             "Mais je me demande, et vous ? D'abord,\n"
             "satisfaire l'honneur."))))

(define (angriss-sacr knpc kpc)

  (define (player-alone?)
    (< (num-player-party-members) 
       2))

  (let ((quest (angriss-quest (kobj-gob-data knpc))))

    (define (refused)
      (say knpc "Fuyez ma présence !\n"
           "Vous pouvez échapper à ma colère, mais\n"
           "Vous ne reviendrez pas.")
      (harm-relations knpc kpc)
      (harm-relations knpc kpc)
      (kern-conv-end))

    (define (offer-quest)
      (display "Quête offerte")(newline)
      (if (player-alone?)
          (begin
            (say knpc "Vous trouverez, si vous\n"
                 "cherchez, un idiot pour vous rejoindre. Apportez\n"
                 "cet idiot pour moi.\n"
                 "...D'accord ?")
            (if (kern-conv-get-yes-no? kpc)
                (begin
                  (quest-accepted! quest)
                  (improve-relations knpc kpc)
                  (improve-relations knpc kpc))
                (refused)))
          (begin
            (say knpc "Au sein de votre équipe\n"
                 "Choisissez en un pour le sacrifice\n"
                 "et vous serez libre.\n"
                 "...D'accord ?")
            (if (kern-conv-get-yes-no? kpc)
                (angriss-choose knpc kpc)
                (refused)))))
            
    (if (quest-done? quest)
        (say knpc "C'est chose faite.")
        (if (quest-accepted? quest)
            (if (player-alone?)
                (say knpc "Seul, tu reviens !\n"
                     "Où est le sacrifice qui\n"
                     "vous gardera de la comdamnation ?")
                (choose-victim))
            (offer-quest)))))


(define (angriss-hono knpc kpc)
  (say knpc "J'exige l'honneur\n"
       "et le sacrifice. Donnez-les à\n"
       "moi, ou fuiyez, ou mourrez."))

(define angriss-conv
  (ifc basic-conv

       ;; basics
       (method 'default angriss-default )
       (method 'bonj angriss-hail )
	   (method 'hail angriss-hail )
	   
       (method 'adie angriss-bye )
       (method 'trav angriss-job )
       (method 'nom angriss-name )
       (method 'join angriss-join )
       
       (method 'doux angriss-soft )
       (method 'faim angriss-hung )
       (method 'rune angriss-rune )
       (method 'homm angriss-men )
       (method 'gobe angriss-gobl )
       (method 'trol angriss-trol )
       (method 'sacr angriss-sacr )
       (method 'honn angriss-hono )
       ))

(define (angriss-ai kchar)
  (if (angriss-spoke? (kobj-gob-data kchar))
      (spider-ai kchar)
      (begin
        (angriss-spoke! (kobj-gob-data kchar))
        (kern-conv-begin kchar))))

(define (mk-angriss)
  (bind 
   (kern-char-force-drop
    (kern-mk-char 
     'ch_angriss         ; tag
     "Angriss"           ; name
     sp_queen_spider     ; species
     nil                 ; occ
     s_purple_spider     ; sprite
     faction-spider ; starting alignment
     20 0 20             ; str/int/dex
     10 5                ; hp mod/mult
     10 5                ; mp mod/mult
     max-health ;;..current hit points
     -1 ;;...........current experience points
     max-health ;;..current magic points
     0
     angriss-lvl
     #f                  ; dead
     'angriss-conv       ; conv
     nil                 ; sched
     'angriss-ai          ; special ai
     
     ;;..........container (and contents)
     (mk-inventory (list (list 1 t_rune_f)))
     nil                 ; readied
     )
    #t)
    (angriss-mk)))
