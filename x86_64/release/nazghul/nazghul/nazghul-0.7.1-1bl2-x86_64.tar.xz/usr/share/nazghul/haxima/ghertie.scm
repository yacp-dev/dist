;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------

;;----------------------------------------------------------------------------
;; Schedule
;; 
;; In Oparine
;;----------------------------------------------------------------------------
(kern-mk-sched 'sch_ghertie
               (list 0  0  cheerful-room-3      "suis en pause")
               )

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (ghertie-mk) 
  (list (mk-quest)))

(define (ghertie-quest gob) (car gob))



;;----------------------------------------------------------------------------
;; Conv
;; 
;; Ghertie is the vengeful ghost of a murdered female pirate captain.
;; She haunts an inn room in Oparine.
;;----------------------------------------------------------------------------

;; Quest...
(define (ghertie-give-instr knpc kpc)
  (say knpc "Chaque membre de mon equipage porte une "
       "bague maudite, avec un crâne pour signet. Elle ne peut être "
       "enlevée sans le doigt. Jorn, Gholet et Meaney sont toujours en "
       "vie. Apportez-moi leurs bagues pour remplir votre contrat "
       "et je remplirai ensuite le mien.")
	(quest-data-update-with 'questentry-ghertie 'questinfo 1 (quest-notify nil))
)

(define (ghertie-update-quest knpc kpc)
  (let ((nrem (- 3 (num-in-inventory kpc t_skull_ring))))
    (if (= nrem 0)
        (begin
          (say knpc "Enfin je suis vengée ! Maintenant je peux me reposer... "
		  "Mon navire, la Mort Miséricordieuse, "
               "repose à [" merciful-death-x ", " merciful-death-y
               "] en suivant le sextant. Mais comment vous allez la piller alors "
               "qu'elle gît au fond de la mer, ça c'est votre problème ! "
               "[Elle disparaît avec un rire cruel]")
			(quest-data-update-with 'questentry-rune-c 'shiploc 1 (quest-notify nil))
			(quest-data-assign-once 'questentry-ghertie)
			(quest-data-update-with 'questentry-ghertie 'done 1 (grant-party-xp-fn 20))
			 (kern-conv-end)
          (kern-obj-remove knpc)
          (kern-map-set-dirty))
        (begin
          (say knpc "Vous avez toujours " nrem " des bagues à retrouver. "
               "Avez-vous oublié mes instructions ?")
           (if (kern-conv-get-yes-no? kpc)
               (begin
                 (say knpc "Si vous étiez un membre de mon equipage, je vous aurais "
                      "fouetté pour votre négligence !")
                 (ghertie-give-instr knpc kpc))
               (say knpc "Alors pourquoi êtes-vous revenu les mains vides ? "
                    "Si vous manquez à votre serment, je fouetterai votre âme avec mes "
                    "propres main !"))))))

;; Basics...
(define (ghertie-hail knpc kpc)
  (let ((quest (ghertie-quest (kobj-gob-data knpc))))
		(quest-data-update 'questentry-ghertie 'ghertieloc 1)
		(quest-data-assign-once 'questentry-ghertie)
    (display "quest:")(display quest)(newline)
    (if (quest-accepted? quest)
        (ghertie-update-quest knpc kpc)        
        (say knpc "[Vous rencontrez le fantôme d'une femme à l'allure sauvage] "
             "Vous osez me déranger ? Méfiez-vous, je suis d'humeur noire."))))

(define (ghertie-default knpc kpc)
  (say knpc "Je ne me soucie pas de cette ligne de discours."))

(define (ghertie-name knpc kpc)
	(quest-data-update 'questentry-ghertie 'ghertieid 1)
  (say knpc "Je m'appelle Ghertrude."))

(define (ghertie-join knpc kpc)
  (say knpc "Hélas, je suis emprisonnée ici pour l'éternité."))

(define (ghertie-job knpc kpc)
  (say knpc "J'étais un pirate quand j'étais vivante. Maintenant, je hante cette pièce."))

(define (ghertie-bye knpc kpc)
  (if (quest-accepted? (ghertie-quest (kobj-gob-data knpc)))
      (say knpc "Vengez-moi sans tarder ! J'attends cette revanche ...")
      (say knpc "Ne faites pas confiance à votre equipage !")))

;; Pirate...
(define (ghertie-pira knpc kpc)
  (say knpc "J'ai pillé ce littoral pendant des années et j'ai amassé une fortune. "
       "Puis, à la veille de ma retraite, mon equipage m'a trahi. "
       "Ils étaient comme des fils pour moi, les misérables !"))

(define (ghertie-betr knpc kpc)
  (say knpc "Les lâches m'ont tué dans mon sommeil et ont volé mon navire."))

(define (ghertie-ship knpc kpc)
  (say knpc "La Mort Miséricordieuse était rapide et intrépide. "
       "Je ne pouvais pas souhaiter un navire plus raffiné. Mon trésor n'était rien, "
       "ma vie était condamnée, mais pour avoir volé mon navire, je ne "
       "pardonnerai jamais mon equipage !"))

(define (ghertie-haun knpc kpc)
  (say knpc "Je suis liée à cet endroit. Mon premier lieutenant savait que je ne me reposerais pas "
       "dans ma tombe, et avec une malediction il m'a fixé ici pour que je ne puisse pas "
       "les poursuivre dans ma vengeance ! Ha ! Il ne savait pas "
       "à propos de la malediction sur mon navire !"))

(define (ghertie-curs knpc kpc)
  (say knpc "J'ai fait mettre une malediction sur mon navire. Si jamais il était volé "
       "il se dirigerait tout seul vers un endroit particulier et coulerait ! Je suis la seule à savoir "
       "l'emplacement de sa tombe aquatique ..."))

(define (ghertie-grav knpc kpc)
  (say knpc "Pourquoi devrais-je vous le dire ?"))

(define (ghertie-reve knpc kpc)
  (let ((quest (ghertie-quest (kobj-gob-data knpc))))
    (if (quest-accepted? quest)
        (say knpc "Oui, vous avez juré de me venger, "
             "pourquoi jacassez-vous ?")
        (begin
          (say knpc "[Elle vous fixe avec un regard glacé] "
               "Vous prononcez le mot le plus cher à mon coeur mort. "
               "Proposez-vous de me venger ?")
	(quest-data-update 'questentry-ghertie 'revenge 1)
          (if (kern-conv-get-yes-no? kpc)
              (begin
                (say knpc "Tout mon equipage n'a pas coulé avec le navire. "
                     "J'ai cherché parmi les morts et j'ai trouvé des disparus. "
                     "Trouvez et punissez les survivants, "
                     "et je vous dirai où se trouve mon navire. "
                     "Avons-nous prêté serment ?")
                (if (kern-conv-get-yes-no? kpc)
                    (begin
                      (say knpc "Alors d'accord, mortel. ")
                      (quest-accepted! quest #t)
                      (ghertie-give-instr knpc kpc))
                    (say knpc "Il est sage que vous ne prêtez pas un tel serment "
                         "à la légère, car j'attends les personnes qui rompent leur serment de ce côté "
                         "du fossé.")))
              (begin
                (say knpc "Alors ne jouez pas avec moi, imbécile !")
                (kern-conv-end)))))))

(define (ghertie-fort knpc kpc)
  (say knpc "Or, pierres précieuses, objets magiques, armes, armures et runes.")
	(quest-data-assign-once 'questentry-rune-c)
	)

(define ghertie-conv
  (ifc basic-conv

       ;; basics
       (method 'default ghertie-default )
       (method 'bonj ghertie-hail )
	   (method 'hail ghertie-hail )
       (method 'adie ghertie-bye )
       (method 'trav ghertie-job )
       (method 'nom ghertie-name )
       (method 'join ghertie-join )
       
       ;; special
       (method 'pira ghertie-pira )
       (method 'trah ghertie-betr )
       (method 'equi ghertie-betr )
       (method 'navi ghertie-ship )
       (method 'hant ghertie-haun )
       (method 'male ghertie-curs )
       (method 'tomb ghertie-grav )
       (method 'fort ghertie-fort )
       (method 'reva ghertie-reve )
	   (method 'veng ghertie-reve )
	   

       ))

(define (mk-ghertie)
  (bind 
   (kern-mk-char 'ch_ghertie           ; tag
                 "Ghertie"             ; name
                 sp_ghast            ; species
                 oc_warrior                 ; occ
                 s_ghost               ; sprite
                 faction-men         ; starting alignment
                 0 0 0               ; str/int/dex
                 0 0                 ; hp mod/mult
                 0 0                 ; mp mod/mult
                 max-health -1 max-health 0 6  ; hp/xp/mp/AP_per_turn/lvl
                 #f                  ; dead
                 'ghertie-conv         ; conv
                 sch_ghertie           ; sched
                 nil                 ; special ai
                 nil                 ; container
                 nil                 ; readied
                 )
   (ghertie-mk)))
