;;----------------------------------------------------------------------------
;; Schedule
;;
;; The schedule below is for the place "Trigrave"
;;----------------------------------------------------------------------------
(kern-mk-sched 'sch_jim
               (list 0  0  trigrave-jims-bed        "dort")
               (list 6  0  trigrave-tavern-table-1a  "mange")
               (list 7  0  trigrave-forge            "travaille")
               (list 12 0  trigrave-tavern-table-1a  "mange")
               (list 13 0  trigrave-forge            "travaille")
               (list 18 0  trigrave-tavern-hall      "suis en pause")
               (list 22 0  trigrave-jims-bed         "dort")
               )

;;----------------------------------------------------------------------------
;; Gob
;;
;; Quest flags, etc, go here.
;;----------------------------------------------------------------------------
(define (jim-mk) nil)

;;----------------------------------------------------------------------------
;; Conv
;;
;; Jim is a merchant, and will trade with the player if he's at work. He's a
;; tall, wiry blacksmith with a very dry wit. If the town has a leader it would
;; be him because the other townsfolk respect him and look to him in times of
;; crises. He isn't interested in being a celebrity, however, and doesn't
;; exercise any real ambition. He's not interested in adventures and considers
;; (privately) that adventurers are fools. But he's happy to trade with
;; them. He drinks hard, and probably had a very wild youth.
;;----------------------------------------------------------------------------
(define jim-merch-msgs
  (list "Passez dans ma boutique quand je suis ouvert. C'est la ferronnerie dans le coin nord-est. Je suis ouvert de 7h à 18h."
        "Faites-moi savoir si vous voyez quelque chose qui vous intéresse."
        "Je rachèterai quelques articles pour la récupération."
        "Faites-moi savoir si vous voyez quelque chose qui vous intéresse."
        "Frappez fort, d'abord et pour le bien, mon ami."
        "Peut-être une autre fois."
        "Je peux en faire fondre ou en réutiliser des parties."
        "Bien."
        "Frappez fort, d'abord et pour le bien, mon ami."
        "Bien."
   ))

(define jim-catalog
  (list
   (list t_dagger          40 "C'est une bonne arme pour les classes non combattantes.")
   (list t_sword           80 "Ce n'est pas de la fantaisie, mais notez l'équilibre parfait sur cette épée.")
   (list t_axe             70 "Une hache est nécessaire si vous campez dans la nature, mais il peut être délicat de s'en emparer dans un combat.")
   (list t_mace            75 "La massue est une arme simple mais efficace contre les ennemis avec une armure légère.")
   
   (list t_2H_axe         240 "La hache de guerre est idéale pour fendre les armures et les boucliers.")
   (list t_2H_sword       350 "Si vous êtes assez fort pour la manier, une épée à deux mains est une excellente arme offensive.")
   
   (list t_chain_coif     110 "La coiffe en chaîne protégera votre cou contre les coups décapitants.")
   (list t_iron_helm      160 "Avec un casque de fer, vous pouvez survivre à un coup direct de massue.")
   (list t_armor_chain    300 "Les armures de chaînes repoussent la plupart des lames et des flèches.")
   (list t_armor_plate    600 "Bien que lourde, l'armure en plaques vous protégera de tous les coups, sauf des plus puissants ou des pointes perforantes.")
   
   (list t_shield          45 "Un bouclier est vital pour le combat rapproché.")
   
   (list t_spiked_helm    150 "Le casque à pointes est privilégié par ceux qui ont un style plus... direct.")
   (list t_spiked_shield  150 "Un bouclier à pointes augmente la poussée de base du fantassin avec des dégâts supplémentaires.")
   ))

(define (jim-trade knpc kpc) (conv-trade knpc kpc "trade" jim-merch-msgs jim-catalog))

(define jim-conv
  (ifc basic-conv
       ;; default if the only "keyword" which may (indeed must!) be longer than
       ;; 4 characters. The 4-char limit arises from the kernel's practice of
       ;; truncating all player queries to the first four characters. Default,
       ;; on the other hand, is a feature of the ifc mechanism (see ifc.scm).
       (method 'default (lambda (knpc kpc) (say knpc "Je ne sais pas.")))
       (method 'bonj (lambda (knpc kpc) (say knpc "Enchanté.")))
       (method 'hail (lambda (knpc kpc) (say knpc "Enchanté.")))
       
	   (method 'adie (lambda (knpc kpc) (say knpc "Bon voyage.")))
       (method 'trav (lambda (knpc kpc) 
                 (say knpc "Je suis le forgeron de Trigrave. Vous avez besoin de quelque chose ?")
                            (if (kern-conv-get-yes-no? kpc)
                                (jim-trade knpc kpc)
                                (say knpc "Regardez autour de vous tant que vous voulez."))))
       (method 'nom (lambda (knpc kpc) (say knpc "Les gens m'appellent Jim.")))
       (method 'ache (lambda (knpc kpc) (conv-trade knpc kpc "buy" jim-merch-msgs jim-catalog)))
       (method 'vend (lambda (knpc kpc) (conv-trade knpc kpc "sell" jim-merch-msgs jim-catalog)))
       (method 'comm jim-trade )
       (method 'join (lambda (knpc kpc) 
                       (say knpc "C'est ici que je reste, quoi qu'il arrive.")))


       (method 'chan (lambda (knpc kpc)
                       (say knpc "Chanteclair le troubadour fréquente la "
                            "taverne de Trigrave. Il connaît bien la région.")))
       (method 'char (lambda (knpc kpc)
                 (say knpc "Le charbonnier qui vit dans les bois "
                      "garde mes forges bien chaudes.")))
       (method 'earl (lambda (knpc kpc)
                 (say knpc "Earl est le commerçant du magasin général. "
                      "Il affirme qu'il était autrefois un mage de guerre.")))
       (method 'gwen (lambda (knpc kpc)
                 (say knpc "Gwen est notre aubergiste. C'est une femme magnifique "
                      "mais mystérieuse.")))
       (method 'fer (lambda (knpc kpc)
                       (say knpc "Les collines sont pleines de minerai, et tant "
                            "de batailles ont été livrées dans cette vallée qu'il n'est pas "
                            "nécessaire de leur rendre visite pour trouver de la ferraille.")))
       (method 'bouc (lambda (knpc kpc)
                 (say knpc "[il vous regarde froidement] Je me suis débarrassé d'un "
                      "bouclier qui portait l'emblème de Glasdrin. "
                      "Je vous remercie de ne plus en parler.")))
       (method 'vole (lambda (knpc kpc)
                 (say knpc "Je n'ai vu personne de bizarre. Mais demandez à Gwen, elle parle à de nombreux voyageurs.")))
       (method 'trig (lambda (knpc kpc) 
                 (say knpc "Trigrave n'a pas grand-chose à dire.")))
       (method 'bois (lambda (knpc kpc)
                 (say knpc "Les bois sont l'habitat des bêtes et des bandits. "
                      "Vous aurez besoin d'armes courtes et d'une armure légère, "
                      "car le bosquet est une entrave aux armes lourdes "
                      "et aux armes à distance.")))
       
       ))
