(mk-tower
 'p_tutorial_town "le Tutoriel 'Dans le village'"
 (list
      "xx xx xx xx xx xx xx xx xx ,, xx xx xx xx xx xx xx xx xx "
      "xx xx xx xx xx xx xx xx xx ,, xx xx xx xx xx xx xx xx xx "
      "xx xx xx xx xx xx xx xx xx ,, ,, ,, ,, ,, xx xx xx xx xx "
      "xx xx xx xx xx xx xx xx xx xx xx xx xx ,, xx xx xx xx xx "
      "xx xx xx xx xx xx xx xx xx xx xx xx xx ,, xx xx xx xx xx "
      "xx xx xx xx xx xx xx xx xx xx xx xx ,, ,, ,, xx xx xx xx "
      "xx xx xx xx xx ,, ,, ,, ,, ,, xx xx ,, ,, ,, xx xx xx xx "
      "xx xx xx xx xx xx ,, xx xx ,, xx xx ,, ,, ,, xx xx xx xx "
      "xx xx xx xx xx xx ,, xx xx ,, xx xx xx ,, xx xx xx xx xx "
      "xx xx xx xx xx xx ,, xx xx ,, xx xx ,, ,, ,, xx xx xx xx "
      "xx xx xx xx xx ,, ,, xx xx xx xx ,, ,, ,, ,, xx xx xx xx "
      "xx xx xx xx xx xx ,, xx xx xx xx xx ,, ,, ,, xx xx xx xx "
      "xx xx xx xx xx xx ,, xx xx xx xx xx xx ,, xx xx xx xx xx "
      "xx xx xx xx xx xx ,, ,, ,, ,, ,, ,, ,, ,, xx xx xx xx xx "
      "xx xx xx xx xx xx xx xx xx ,, xx xx xx xx xx xx xx xx xx "
      "xx xx xx xx xx xx xx xx xx xx xx xx xx xx xx xx xx xx xx "
      "xx xx xx xx xx xx xx xx xx xx xx xx xx xx xx xx xx xx xx "
      "xx xx xx xx xx xx xx xx xx xx xx xx xx xx xx xx xx xx xx "
      "xx xx xx xx xx xx xx xx xx xx xx xx xx xx xx xx xx xx xx "

  )
  (list ;entrances
  	(list north 9 0)
  )
 (put (mk-chest 
       nil 
       '( 
        ( 10 t_torch)
        ( 1 t_sword)
        ( 1 t_armor_leather)
        ( 1 t_shield)
        ( 1 t_halberd)
        ))
      5 6)
 (put (spawn-pt 'snake) 11 13)
 (put (kern-tag 'p1 (mk-portcullis)) 6 11)
 (put (mk-lever 'p1) 5 10)
 (put (kern-tag 'p2 (mk-portcullis)) 10 13)
 (put (mk-lever 'p2) 9 14)
 (put (mk-step-clue "A gauche, un coffre. Ouvrez-le en appuyant sur la touche 'O' suivi d'une touche fléchée. "
                    "Obtenez ensuite des objets en appuyant sur la touche G suivie d'une flèche.") 
      6 6)
 (put (mk-step-clue "Vous feriez mieux de préparer vos armes et votre armure en appuyant sur R."
                    "Appuyez sur la touche 'R'. Dans la fenêtre ci-dessus, vous pouvez sélectionner les armes et armures à porter ou "
                    "à enlever en appuyant sur la BARRE D'ESPACE. Testez un peu. "
                    "Lorsque vous avez fini de vous amuser, appuyez sur la touche ESC."
                    )
      6 8)
 (put (mk-step-clue "Pour vérifier l'état de votre équipement, appuyez sur la touche 'Z'. "
                    "Faites défiler les volets à l'aide des touches fléchées. "
                    "Lorsque vous avez terminé, appuyez sur la touche ESC."
                    )
      6 9)
 (put (mk-step-clue "Pour ouvrir la herse, vous devez manipuler le levier à gauche. "
                    "Appuyez sur 'H', déplacez le réticule sur le levier avec les touches fléchées, "
                    "et appuyez ensuite sur la touche Entrée.")
      6 10)
 (put (mk-step-clue "Si vous voulez identifier les objets qui vous entourent, utilisez la commande Examiner en appuyant sur 'x'. "
                    "Le curseur se trouve sur ce que vous voulez regarder. "
                    "Les personnages non joueurs (PNJ) comme le serpent seront mis en évidence par une case. "
                    "Rouge signifie hostile, jaune signifie neutre et vert signifie amical. "
                    "Les PNJ hostiles vous attaqueront à vue. "
                    "Lorsque vous avez terminé, appuyez sur la touche ESC.")
      6 13)
 (put (mk-step-clue "Une fois que vous aurez ouvert la herse, vous devrez combattre le serpent. "
                    "Pour attaquer, appuyez sur 'A' et placez le curseur sur la cible, puis appuyez sur ENTRÉE.")
      9 13)

 (put (mk-step-clue "Pour ouvrir une porte, il suffit d'essayer de la franchir.") 13 13)
 (put (mk-door) 13 12)

 (put (mk-step-clue "Fouillez les cadavres à l'aide de la touche 'S' suivie d'une touche fléchée. Vous pouvez également rechercher des objets invisibles avec cette commande.") 12 10)
 (put (mk-corpse2 (list (list 20 't_picklock) 
                        (list 10 'sulphorous_ash)
                        (list 10 'blood_moss)
                        )) 11 10)

 (put (mk-locked-door) 13 8)
 (put (mk-step-clue "Utilisez les crochets de serrures du cadavre pour déverrouiller cette porte. "
                    "Utilisez la touche 'U', sélectionnez l'élément, puis ciblez la porte. "
                    "Si votre crochet se casse, essayez à nouveau !"
                    ) 13 9)

 (put (kern-tag 'p3 (mk-portcullis)) 12 13)
 (put (mk-lever 'p3) 11 14)

 (put (mk-magic-locked-door) 13 4)
 (put (mk-thorald) 12 5)
 (put (mk-step-clue "Parlez aux PNJ en appuyant sur la touche 'T' et en les ciblant. "
                    "Ensuite, entrez des mots-clés pour leur poser des questions. La plupart des PNJ répondent à NOM et TRAVAIL. "
                    "Les PNJ vous donnent généralement des indices sur d'autres mots clés dans leurs réponses. "
                    "Pour mettre fin à une conversation, tapez 'adieu' ou appuyez simplement sur ENTRÉE. "
                    "Si vous pensez qu'un NPC serait un bon ajout à votre équipe, demandez-lui de se JOINdre à vous. Tapez JOIN."
                    "Maintenant, parlez à Thorald et interrogez-le sur la porte. ")
      13 7)


 (put (mk-step-clue "Vous êtes sur le point de quitter la ville et d'entrer dans la nature sauvage. "
                    "Dans la nature, tout votre groupe apparaîtra sous la forme d'une seule icône. ")
      9 0)
 )
