;; Thorald is a character in the Tutorial game.


(define (thorald-mixi knpc kpc)
  (say knpc "Pour Melanger la préparation des sorts, appuyez d'abord sur la touche M. "
       "Tapez ensuite la première lettre de chaque syllabe du sort, suivie de ENTRÉE. "
       "Par exemple, In Ex Por serait : i, e, p, ENTRÉE.")
  (prompt-for-key)
  (say knpc "Ensuite, sélectionnez les réactifs à l'aide de la barre d'espacement. ")
  (prompt-for-key)
  (say knpc "Ensuite, appuyez sur ENTRÉE et tapez le nombre de melanges à faire. "
       "Il suffit de melanger 1 pour l'instant. ")
  (prompt-for-key)
  (say knpc "Vous pouvez voir les sorts que vous avez melangés avec la touche Z."
       "Pourquoi ne pas essayer d'en melanger un maintenant ? Reparlez-moi quand vous aurez réussi.")
  (kern-conv-end)
  )

(define conv-thorald
  (ifc nil
       (method 'adie (lambda (knpc kpc)
                 (say knpc "Oh, je suis sûr que nous allons nous voir davantage.")))
       (method 'default (lambda (knpc kpc)
                 (say knpc "Je ne peux pas vous aider à ce sujet.")))
       (method 'bonj (lambda (knpc kpc)
                 (kern-log-msg "Vous rencontrez un vieil homme qui s'ennuie.")
                 (if (in-inventory? kpc in_ex_por)
                     (say knpc "Je vois que vous avez le sortilège 'In Ex Por'. "
                          "Si vous ne savez pas faire, demandez-moi comment lancer les sorts.")
                     (say knpc "Bienvenue au tutoriel. Pourquoi ne pas me poser des questions sur mon travail, "
                          "ou peut-être cette porte là-bas.")
                     )))
					 
       (method 'hail (lambda (knpc kpc)
                 (kern-log-msg "Vous rencontrez un vieil homme qui s'ennuie.")
                 (if (in-inventory? kpc in_ex_por)
                     (say knpc "Je vois que vous avez le sortilège 'In Ex Por'. "
                          "Si vous ne savez pas faire, demandez-moi comment lancer les sorts.")
                     (say knpc "Bienvenue au tutoriel. Pourquoi ne pas me poser des questions sur mon travail, "
                          "ou peut-être cette porte là-bas.")
                     )))
					 
					 
					 
       (method 'join (lambda (knpc kpc)
                 (say knpc "Oui, mettons ce spectacle en route. "
                      "Appuyez sur la touche F et je me joindrai à vous."
                      "Plus tard, si vous voulez que je me déplace à tour de rôle avec vous, appuyez à nouveau sur la touche F. "
                      "Et si vous voulez que j'explore pendant que vous attendez, appuyez sur 2. "
                      "Vous pouvez toujours appuyer à nouveau sur la touche F pour que je vous suive.")
                 (join-player knpc)
                 (kern-conv-end)
                 ))
       (method 'nom (lambda (knpc kpc)
                 (say knpc "Je m'appelle Thorald. Salut.")))
       (method 'trav (lambda (knpc kpc)
                 (say knpc "Je suis juste l'aide du jeu.")))
       (method 'port (lambda (knpc kpc)
                 (say knpc "Oui, je connais un sort qui peut ouvrir cette porte magiquement verrouillée. "
                      "Imaginez cela ! Pourquoi ne pas me poser la question ?")
                 ))
       (method 'sort (lambda (knpc kpc)
                 (say knpc "Le sort 'In Ex Por' déverrouille des portes verrouillées par magie. "
                      "Pour le melange, vous aurez besoin de cendres sulfureuses et de mousse de sang. "
                      "Interrogez-moi sur le melange si vous ne savez pas comment.")))
       (method 'mela thorald-mixi )
       (method 'mela thorald-mixi )
       (method 'lanc (lambda (knpc kpc)
                 (say knpc "Pour lancer un sort, appuyez sur C et entrez la première lettre de chaque mot magique. "
                      "Par exemple, pour lancer le sort 'In Ex Por', vous tapez i, e et p. "
                      "Utilisez la touche retour arrière si vous vous trompez. "
                      "Quand le sort est correct, appuyez sur ENTRER pour le lancer. "
                      "'In Ex Por' vous demande de cibler la porte.")))
       ))
       
(define (thorald-ai kchar) #t)

(define (mk-thorald)
  (kern-mk-char 
   'ch_thorald ; tag
   "Thorald Greybeard"   ; name
   sp_human              ; species
   oc_wrogue             ; occ
   s_companion_wizard    ; sprite
   faction-player        ; starting alignment
   0 10 2                ; str/int/dex
   0 1                   ; hp mod/mult
   10 5                  ; mp mod/mult
   240 -1 8 0 8             ; hp/xp/mp/AP_per_turn/lvl
   #f                    ; dead
   'conv-thorald         ; conv
   nil                   ; sched
   'thorald-ai           ; special ai
   nil                   ; container
   (list t_sling
         t_armor_leather
         )
   nil
   ))
