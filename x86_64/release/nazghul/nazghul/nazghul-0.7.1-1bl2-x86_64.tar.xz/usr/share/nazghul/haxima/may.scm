;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------
(define may-start-lvl  6)
(define inn-room-price 30)

;;----------------------------------------------------------------------------
;; Schedule
;; 
;; In Bole.
;;----------------------------------------------------------------------------
(kern-mk-sched 'sch_may
               (list 0  0  bole-bed-may "dort")
               (list 6  0  bole-dining-hall "travaille")
               )

;;----------------------------------------------------------------------------
;; Gob
;;
;; Quest flags, etc, go here.
;;----------------------------------------------------------------------------
(define (may-mk) nil)

;;----------------------------------------------------------------------------
;; Conv
;; 
;; May is a female innkeeper, who lives in Bole.
;; Melvin is her (seventh) husband.
;;----------------------------------------------------------------------------
(define (may-trade knpc kpc)
  (say knpc "Parlez à mon mari Melvin dans la cuisine."))

(define (may-hail knpc kpc)
  (say knpc "[Vous rencontrez une femme âgée et corpulente qui vous regarde attentivement] "
       "Je sais que vous avez des problèmes, mais je vous souhaite la bienvenue."))

(define (may-job knpc kpc)
  (say knpc "Je dirige la taverne avec mon mari ici à Bole"))

(define (may-husband knpc kpc)
  (say knpc "Mon mari Melvin est un ivrogne sans valeur et un lâche "
       "mais il est assez bon cuisinier. J'ai survécu à six autres maris.  "
       "Je l'ai épousé parce que j'avais besoin d'aide pour gérer l'auberge, c'est tout."))

(define (may-other-husbands knpc kpc)
  (say knpc "Mes autres maris étaient tous des imbéciles ! Quelques-uns, en effet, que j'aimais. "
       "Mais ils étaient fous et chacun a connu une mort insensée. "
       "Je vois que vous êtes aussi un idiot, et que vous allez rencontrer vous aussi votre propre "
       "mort incensée un jour."))

(define (may-tavern knpc kpc)
  (say knpc "Melvin est le cuisinier et je sers les invités. "
       "Peut-être voudriez-vous acheter une boisson, un dîner, "
       "ou une chambre pour vous reposer."))

(define (may-guests knpc kpc)
  (say knpc "[Elle vous donne un coup d'oeil de bon augure] Oui, même maintenant, nous avons une étrange "
       "femme et son... compagnon. Mais peut-être cherchiez-vous "
       "quelqu'un d'autre, hein ?")
  (if (kern-conv-get-yes-no? kpc)
      (begin
        (say knpc "Oui, c'est ce que je pensais. Et peut-être que cette autre personne avait "
             "quelque chose qui vous intéresse ?")
        (if (kern-conv-get-yes-no? kpc)
            (begin
              (say knpc "C'est curieux, car cet objet intéressait également "
                   "nos invités actuels. Non pas que cela me regarde, "
                   "mais on soupçonne que la femme et celui que vous cherchez "
                   "se sont arrangé pour se rencontrer ici. Peut-être pour faire un ... "
                   "échange."))
            (say knpc "Eh bien, il y a eu un autre homme venu ici brièvement. Mais il "
                 "est parti peu avant votre arrivée.")))
      (say knpc "Peut-être n'êtes-vous alors qu'en train d'admirer la campagne.")))

(define (may-woman knpc kpc)
  (say knpc "Oui, nous n'avons pas souvent de si belles personnes dans ces régions. "
       "Le pauvre Bill en est très épris. Et mon imbécile de mari la lorgne ici "
       "dès qu'il en a l'occasion. [Elle se penche de près et chuchote] Mais "
       "si elle n'est pas une sorcière, ou une en cours de  formation, alors je suis une vraie dinde !"))

(define (may-companion knpc kpc)
  (say knpc "Cette femme voyage avec une grande brute. Je soupçonne qu'il a "
       "du sang d'ogre dans ses veines. De toute évidence, il est son protecteur, mais je ne sais pas "
       "quel lien elle a avec lui."))

(define (may-bill knpc kpc)
  (say knpc "Oui, Bill est un garçon du coin. Pas très brillant, mais il mène "
       "une vie honnête en tant que bûcheron. Il mange ici, et parfois parle "
       "aux invités."))

(define (may-hackle knpc kpc)
  (say knpc "Hackle est une vieille sorcière, folle mais inoffensive, qui vit de l'autre côté "
       "du fleuve. Elle a un don pour les arts de la guérison mais n'a pas l'esprit "
       "pour bien d'autres choses."))

(define (may-room knpc kpc)
  (if (not (string=? "travaille" (kern-obj-get-activity knpc)))
      (say knpc "L'auberge est fermée. Revenez le matin à 6 heures.")
      (let ((door (eval 'bole-inn-room-door)))
        ;; is the room still open?
        (if (not (door-locked? (kobj-gob door)))
            ;; yes - remind player
            (say knpc "Votre chambre est toujours ouverte.")
            ;; no - ask if player needs a room
            (begin
              (say knpc "Vous voulez une chambre ?")
              (if (kern-conv-get-yes-no? kpc)
                  ;; yes - player wants a room
                  (begin
                    (say knpc 
                         "Ce sera " inn-room-price " pièces d'or, "
                         "et vous pouvez utiliser la chambre aussi "
                         "longtemps que vous restez en ville. D'accord ?")
                    (if (kern-conv-get-yes-no? kpc)
                        ;; yes - player agrees to the price
                        (let ((gold (kern-player-get-gold)))
                          ;; does player have enough gold?
                          (if (>= gold inn-room-price)
                              ;; yes - player has enough gold
                              (begin
                                (kern-player-set-gold 
                                 (- gold 
                                    inn-room-price))
                                (say knpc "Bien. Votre chambre est au bout du couloir "
                                     "sur la gauche.")
                                (send-signal knpc door 'unlock)
                                (kern-conv-end)
                                )
                              ;; no - player does not have enouvh gold)
                              (say knpc "Vous n'avez pas d'or !")))
                        ;; no - player does not agree to the price
                        (say knpc 
                             "Dormez donc par terre. Attention aux loups.")))
                  ;; no - player does not want a room
                  (say knpc "Même une personne telle que vous doit parfois se reposer !")))))))
  
(define (may-thief knpc kpc)
  (say knpc "Ah... vous jouez le rôle de l'attrape-voleur. Je me doutais bien qu'il y avait quelque chose "
       "de ce genre. Nous avons eu quelques invités étranges ici dernièrement."))

(define (may-trouble knpc kpc)
  (say knpc "Vous avez le visage dur et impitoyable, vous ressemblez aux hommes de l'Ancien Temps. "
       "Mais je sens que vous n'êtes pas injuste."))

(define may-conv
  (ifc nil
       (method 'default (lambda (knpc kpc) (say knpc "Je ne peux pas vous aider.")))
       (method 'bonj may-hail )
	   (method 'hail may-hail )
	   
       (method 'adie (lambda (knpc kpc) (say knpc "Partez alors pour le moment.")))
       (method 'trav may-job )
       (method 'nom (lambda (knpc kpc) (say knpc "Je m'appelle May.")))
       (method 'join (lambda (knpc kpc)
                       (say knpc "Ne me flattez pas avec vos bêtises.")))

       (method 'ache may-trade )
       (method 'nour may-trade )
       (method 'bois may-trade )
       (method 'rati may-trade )
       (method 'comm may-trade )

       (method 'bill may-bill )
       (method 'comp may-companion )
       (method 'invi may-guests )
       (method 'hack may-hackle )
       (method 'mari may-husband )
       (method 'aube may-tavern )
       (method 'melv may-husband )
       (method 'autr may-other-husbands )
       (method 'diri may-tavern )
       (method 'cham may-room )
       (method 'six may-other-husbands )
       (method 'tave may-tavern )
       (method 'vole may-thief )
       (method 'prob may-trouble )
       (method 'femm may-woman )

       ))

;;----------------------------------------------------------------------------
;; First-time constructor
;;----------------------------------------------------------------------------
(define (mk-may)
  (bind 
   (kern-char-arm-self
    (kern-mk-char 
     'ch_may ;;......tag
     "May" ;;.......name
     sp_human ;;.....species
     nil ;;..........occupation
     s_townswoman ;;...sprite
     faction-men ;;..faction
     0 ;;............custom strength modifier
     1 ;;............custom intelligence modifier
     0 ;;............custom dexterity modifier
     0 ;;............custom base hp modifier
     0 ;;............custom hp multiplier (per-level)
     0 ;;............custom base mp modifier
     0 ;;............custom mp multiplier (per-level)
     max-health ;;..current hit points
     -1  ;;...........current experience points
     max-health ;;..current magic points
     0
     may-start-lvl  ;;..current level
     #f ;;...........dead?
     'may-conv ;;...conversation (optional)
     sch_may ;;.....schedule (optional)
     'townsman-ai ;;..........custom ai (optional)
     nil ;;..........container (and contents)
     (list t_dagger) ;;.........readied arms (in addition to the container contents)
     nil ;;..........hooks in effect
     ))
   (may-mk)))
