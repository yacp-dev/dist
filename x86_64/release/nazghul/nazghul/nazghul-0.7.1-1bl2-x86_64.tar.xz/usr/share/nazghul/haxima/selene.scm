;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------
(define selene-lvl 5)
(define selene-species sp_human)
(define selene-occ nil)

;;----------------------------------------------------------------------------
;; Schedule
;; 
;; In Old Absalot.
;;----------------------------------------------------------------------------
(define selene-bed oa-bed3)
(define selene-mealplace oa-tbl2)
(define selene-workplace oa-baths)
(define selene-leisureplace oa-temple)
(kern-mk-sched 'sch_selene
               (list 0  0 selene-bed          "dort")
               (list 7  0 selene-mealplace    "mange")
               (list 8  0 selene-workplace    "travaille")
               (list 12 0 selene-mealplace    "mange")
               (list 13 0 selene-workplace    "travaille")
               (list 18 0 selene-mealplace    "mange")
               (list 19 0 selene-leisureplace "suis en pause")
               (list 22 0 selene-bed          "dort")
               )

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (selene-mk) nil)

;;----------------------------------------------------------------------------
;; Conv
;; 
;; Selene is a female cult member of the Accursed.
;; She is unstable, wicked, and depraved.
;;----------------------------------------------------------------------------

;; Basics...
(define (selene-hail knpc kpc)
  (say knpc "[Cette jeune femme aux yeux sauvages vous regarde avec insistance]"))

(define (selene-default knpc kpc)
  (say knpc "[Elle ricane. C'est un son maléfique]"))

(define (selene-name knpc kpc)
  (say knpc "Selene."))

(define (selene-join knpc kpc)
  (say knpc "[Elle secoue la tête avec insistance]"))

(define (selene-job knpc kpc)
  (say knpc "[Elle hausse les épaules] Je joue avec les choses."))

(define (selene-bye knpc kpc)
  (say knpc "[Elle crie dans votre dos] A bientôt, héros !"))

(define (selene-play knpc kpc)
  (say knpc "Les choses... les gens..."))

(define (selene-peop knpc kpc)
  (say knpc "J'aime leur faire faire ce que je veux."))

(define (selene-want knpc kpc)
  (say knpc "Tout ce que je veux. Je m'en moque. J'aime juste faire en sorte que les gens le fassent. "
       "S'ils ne le font pas... [elle hausse les épaules et glousse]"))

(define (selene-accu knpc kpc)
  (say knpc "Ce n'est pas si mal, héros. C'est plutôt amusant."))

(define (selene-fun knpc kpc)
  (say knpc "Être maudit ? Bien sûr que oui ! Ce que je préfère, ce sont les sacrifices."))

(define (selene-sacr knpc kpc)
  (say knpc "Tu vas le découvrir, idiot !"))

(define (selene-denn knpc kpc)
  (say knpc "Il est facile de lui faire faire ce que je veux. Il a peur de moi. "
       "Et c'est moi qu'il désire."))

(define (selene-sila knpc kpc)
  (say knpc "[Elle a soudain l'air effrayée, et devient vicieuse] "
       "Pourquoi me dérangez-vous ? Partez !")
  (kern-conv-end))

(define selene-conv
  (ifc basic-conv

       ;; basics
       (method 'default selene-default )
       (method 'bonj selene-hail )
	   (method 'hail selene-hail )
	   
       (method 'adie selene-bye )
       (method 'trav selene-job )
       (method 'nom selene-name )
       (method 'join selene-join )

       (method 'joue selene-play )
       (method 'gens selene-peop )
       (method 'veux selene-want )
       (method 'maud selene-accu )
       (method 'amus selene-fun )
       (method 'sacr selene-sacr )
       (method 'denn selene-denn )
       (method 'sila selene-sila )
       ))

(define (mk-selene)
  (bind 
   (kern-mk-char 
    'ch_selene           ; tag
    "Selene"             ; name
    selene-species         ; species
    selene-occ              ; occ
    s_townswoman     ; sprite
    faction-men      ; starting alignment
    0 2 1            ; str/int/dex
    0 0              ; hp mod/mult
    0 0              ; mp mod/mult
    max-health ; hp
    -1                   ; xp
    max-health ; mp
    0
    selene-lvl
    #f               ; dead
    'selene-conv         ; conv
    sch_selene           ; sched
    'townsman-ai              ; special ai
    nil              ; container
    (list t_dagger)              ; readied
    )
   (selene-mk)))
