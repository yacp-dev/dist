(define (gsstatue-unknown knpc kpc)
  (say knpc "[La statue reste silencieuse]"))

(define (gsstatue-hail knpc kpc)
  (say knpc "[Une statue vous parle]")
  (gamestart-statue-clean knpc "statspeak")
  )
    
(define gsstatue-conv
  (ifc '()
       ;; fundamentals
       (method 'defaut gsstatue-unknown )
       (method 'salut gsstatue-hail )
       )
       )

(define (gsstatue-dostat knpc kpc iname iset iget dname dset dget initial)
	(define (gs-check-upper value)
		(if (> value 11)
			(begin
				(say knpc "Je ne peux pas augmenter votre " iname " davantage")
				#t
				)
			#f))
	(define (gs-check-lower value)
		(if (< value 1)
			(begin
				(say knpc "Vous ne devez pas abuser de votre " dname " davantage")
				#t
				)
			#f))
	(define (gs-initialcheck)
		(say knpc "Souhaitez-vous convertir " dname " en " iname "?")
		(if (kern-conv-get-yes-no? kpc)
			#f #t)
		)
	(define (gs-repeatcheck)
		(say knpc "Continuer ?")
		(if (kern-conv-get-yes-no? kpc)
			#f #t)
		)
	(let ((ival (iget kpc))
			(dval (dget kpc))
			)
		(cond ((gs-check-upper ival))
			((gs-check-lower dval))
			((and initial (gs-initialcheck)) (say knpc "Comme vous le souhaitez"))
			((and (not initial) (gs-repeatcheck)) (say knpc "Comme vous le souhaitez"))
			(#t
				(iset kpc (+ ival 1))
				(dset kpc (- dval 1))
				(say knpc "[Votre " iname " a augmenté]")
				(say knpc "[Votre " dname
					(cond ((< dval 3) " se fane!]")
						((< dval 9) " diminue]")
						(#t " s'atténue]")
					)
				)
				(gamestart-reset-lamps kpc)
				(gsstatue-dostat knpc kpc iname iset iget dname dset dget #f)
			)
		)	
	))
		       
;; Statue of intelligence

(define (gs-int-hail knpc kpc)
  (say knpc "Bienvenue, Aventurier. Je donne la sagesse à ceux qui la demandent.")
  (gamestart-statue-clean knpc "statspeak")
  )
  
(define (gs-int-job knpc kpc)
	(say knpc "Je représente la force de la raison, et je peux vous aider dans vos efforts de magie ou d'esprit.")
	)
  
(define (gs-int-assi knpc kpc)
	(say knpc "Je peux élever votre intellect, mais cela vous coûtera une partie de votre force ou de votre dextérité")
	)

(define (gs-int-rais knpc kpc)
	(say knpc "Vous devrez dire pour quelle compétence vous voulez subir la sanction")
	)
		
;; expand on this as other abilities become available
(define (gs-int-inte knpc kpc)
  (say knpc "Les sages tissent des sorts de pouvoir et résistent aux magies malveillantes, mais les imbéciles sont pris au piège et facilement trompés. "
  "Prenez garde, Aventurier ! Des êtres maléfiques d'une grande intelligence vous guettent sur votre chemin. "
  "Vous aurez besoin de sagesse pour les vaincre. Est-ce là votre souhait ?")
  (if (yes? kpc)
      (say knpc "Pour devenir sage, il faut renoncer à la force ou à la dextérité. ")
      (say knpc "Celui qui se détourne de la sagesse devient le délice des démons.")
      )
  )
	
(define (gs-int-stre knpc kpc)
  (say knpc "Faites attention, Aventurier ! La force physique ne vous servira pas contre la plus forte des puissances obscures.")
  (gsstatue-dostat knpc kpc "intelligence" kern-char-set-intelligence kern-char-get-base-intelligence 
                   "force" kern-char-set-strength kern-char-get-base-strength #t)
  )
      
	
(define (gs-int-dext knpc kpc)
  (say knpc "Réfléchissez bien, Aventurier ! La flèche la plus droite manquera le sorcier impur, et les portes des profondeurs sont fermées par des sorts qui ne peuvent être choisis.")
  (gsstatue-dostat knpc kpc "intelligence" kern-char-set-intelligence kern-char-get-base-intelligence 
                   "dextérité" kern-char-set-dexterity kern-char-get-base-dexterity #t)
  )

(define (gs-int-bye knpc kpc)
  (say knpc "Allez-y maintenant, Aventurier. Puissent vos proches vous protéger, vos invocations vous aider, et votre colère faire pleuvoir le feu et la foudre sur les impies !")
  )

(define gs-int-conv
  (ifc '()
       ;; fundamentals
       (method 'defaut gsstatue-unknown )
       (method 'adie gs-int-bye )
       (method 'bonj gs-int-hail )
	   (method 'hail gs-int-hail )
       (method 'trav gs-int-inte )
       (method 'inte gs-int-inte )
       (method 'int  gs-int-inte )
       (method 'sag  gs-int-inte )
       (method 'sage gs-int-inte )
       (method 'forc gs-int-stre )
       (method 'for gs-int-stre )
       (method 'dext gs-int-dext )
       (method 'dex gs-int-dext )
       )
  )
       
;; Statue of might

(define (gs-str-hail knpc kpc)
  (say knpc "Je vous salue, Aventurier. Je donne de la force à ceux qui voudraient être puissants.")
  (gamestart-statue-clean knpc "statspeak")
  )
  
;; expand on this as other abilities become available
(define (gs-str-stre knpc kpc)
	(say knpc "Gagnez en force, et vous fendrez les casques, écraserez les os et réduirez les boucliers de vos ennemis en éclats. "
	"Vous pouvez porter les armures les plus lourdes sans tituber, et les coups de vos ennemis ne vous porteront aucune atteinte. "
	"La force n'est pas la chose la plus importante pour un guerrier, c'est la seule ! Voulez-vous être fort ?")
        (if (yes? kpc)
            (say knpc "Qu'allez-vous sacrifier pour la force : l' intelligence ou la dextérité ?")
            (say knpc "Seuls les plus forts survivront là où vous devez aller.")
            ))
	
(define (gs-str-inte knpc kpc)
  (say knpc "Un guerrier a besoin de ruse, mais la puissance est primordiale !")
  (gsstatue-dostat knpc kpc "force" kern-char-set-strength kern-char-get-base-strength 
                   "intelligence" kern-char-set-intelligence kern-char-get-base-intelligence #t)
  )
	
(define (gs-str-dext knpc kpc)
  (say knpc "Vos amis seront peut-être impressionnés par les prouesses de dextérité, mais vos ennemis seront persuadés par la force des armes !")
  (gsstatue-dostat knpc kpc "force" kern-char-set-strength kern-char-get-base-strength 
                   "dextérité" kern-char-set-dexterity kern-char-get-base-dexterity #t)
  )

(define (gs-str-bye knpc kpc)
  (say knpc "Partez maintenant et frappez les méchants."))

(define gs-str-conv
  (ifc '()
       ;; fundamentals
       (method 'defaut gsstatue-unknown )
       (method 'adie gs-str-bye )
       (method 'bonj gs-str-hail )
	   (method 'hail gs-str-hail )
	   
       (method 'trav gs-str-stre )
       (method 'forc gs-str-stre )
       (method 'inte gs-str-inte )
       (method 'int gs-str-inte )
       (method 'dext gs-str-dext )
       (method 'dex gs-str-dext )
       )
  )
       
;; Statue of agility

(define (gs-dex-hail knpc kpc)
  (say knpc "Bienvenue, Aventurier. Hélas, je ne peux pas faire de vous une brute puissante ni un mage distrait comme mes cohortes voisines, mais permettez-moi de faire preuve de dextérité.")
  (gamestart-statue-clean knpc "statspeak")
  )
  
(define (gs-dex-dext knpc kpc)
  (say knpc "La dextérité est l'attribut de l'aventurier subtil. Pourquoi défoncer une porte quand on peut crocheter la serrure ? "
            "Pourquoi se ruiner la vue sur des grimoires moisis quand le trésor est facilement trouvé par la ruse et l'artisanat ? "
            "Pourquoi risquer de gâcher ses accessoires choisis avec goût dans une mêlée quand les ennemis peuvent être abattus de loin avec aplomb ?")
  (say knpc "En effet, si une erreur de jugement momentanée laisse une personne acculée, "
            "la vitesse et la réflexion rapide sauveront la journée.\n"
            "Êtes-vous d'accord ?")
  (if (yes? kpc)
      (say knpc "En effet. La dextérité vaut bien le sacrifice d'une force grossière ou d'une intelligence grossière.\n"
            "Ah. Eh bien. Attention à ton portefeuille, mon ami. Les voleurs aiment s'attaquer aux maladroits.")
      )
  )
	
(define (gs-dex-inte knpc kpc)
  (say knpc "Si vous me demandez, le renseignement est largement surévalué. Je veux dire, qui se soucie de ressusciter les morts quand on peut piller leurs cadavres ?")
       (gsstatue-dostat knpc kpc "dextérité" kern-char-set-dexterity kern-char-get-base-dexterity 
                        "intelligence" kern-char-set-intelligence kern-char-get-base-intelligence #t)
       )
	
(define (gs-dex-stre knpc kpc)
  (say knpc "La force est impressionnante pour ceux qui sont impressionnables, mais transporter toutes ces armures et ces armes ressemble à un travail inutile.")
  (gsstatue-dostat knpc kpc "dextérité" kern-char-set-dexterity kern-char-get-base-dexterity 
                   "force" kern-char-set-strength kern-char-get-base-strength #t)
  )

(define (gs-dex-bye knpc kpc)
  (say knpc "Adieu, gardez toujours votre esprit vif, ne laissez jamais passer une occasion de siroter une bouteille ou d'embrasser une jolie servante, et à tout prix, Aventurier, souvenez-vous de bien mourir !")
  )

(define gs-dex-conv
  (ifc '()
       ;; fundamentals
       (method 'defaut gsstatue-unknown )
       (method 'adie gs-dex-bye )
       (method 'bonj gs-dex-hail )
	   (method 'hail gs-dex-hail )
	   
       (method 'trav gs-dex-dext )
       (method 'dex gs-dex-dext )
       (method 'dext gs-dex-dext )
       (method 'forc gs-dex-stre )
       (method 'for gs-dex-stre )
       (method 'inte gs-dex-inte )
       (method 'int gs-dex-inte )
       )
  )
