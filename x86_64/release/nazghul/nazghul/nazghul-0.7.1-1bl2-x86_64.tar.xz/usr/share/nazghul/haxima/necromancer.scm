;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------
(define necr-lvl 8)
(define necr-species sp_human)
(define necr-occ oc_wizard)

;;----------------------------------------------------------------------------
;; Schedule
;;----------------------------------------------------------------------------
(define necr-bed nl-bed)
(define necr-mealplace nl-tbl)
(define necr-workplace nl-lab)
(define necr-leisureplace nl-lib)
(kern-mk-sched 'sch_necr
               (list 0  0 necr-bed          "dort")
               (list 7  0 necr-mealplace    "mange")
               (list 8  0 necr-workplace    "travaille")
               (list 12 0 necr-mealplace    "mange")
               (list 13 0 necr-workplace    "travaille")
               (list 18 0 necr-mealplace    "mange")
               (list 19 0 necr-leisureplace "suis en pause")
               (list 22 0 necr-bed          "dort")
               )

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (necr-mk) 
  (mk-quest))
(define (necr-quest gob) gob)

;;----------------------------------------------------------------------------
;; Conv
;;----------------------------------------------------------------------------

;; Basics...
(define (necr-hail knpc kpc)
  (let ((quest (necr-quest (kobj-gob-data knpc))))
    (if (and (quest-offered? quest)
             (not (quest-done? quest))
             (in-inventory? kpc t_lich_skull)
             )
        (necr-meet-lich knpc kpc)
        (say knpc "[Vous rencontrez un magicien mince et pâle, tout de noir vêtu] "
             "[ tousse ] Bonjour, Vagabond."))))

(define (necr-default knpc kpc)
  (say knpc "[Il est saisi par une crise de toux]"))

(define (necr-heal knpc kpc)
  (begin
    (say knpc "\n[Il est saisi par une crise de toux]\n"
	 "Je vais bien [TOUX] [SOUPIRE]")
    (prompt-for-key)

    (say knpc "Vraiment.\n")
    (prompt-for-key)

    (say knpc "\nJe vais assez bien... [ tousse ]")
    (prompt-for-key)

    (say knpc "\n  [SOUPIRE]...")
    (prompt-for-key)

    (say knpc "[CHOC]")
    (kern-sleep 100)
    (say knpc "[la légère silhouette s'effondre]")
    (kern-sleep 100)
    (say knpc "[GASP!]")
    (kern-sleep 3000)
    (say knpc " ...")
    (prompt-for-key)

    (say knpc "\n[Tout est silencieux]")
    (prompt-for-key)

    (if (in-player-party? 'ch_mesmeme)
	(begin	
	  (say knpc "\n[Le silence s'étend sur...]")
	  (kern-sleep 3000)
	  (aside kpc 'ch_mesmeme "[Regardant la silhouette affaissée]\nA manger  maintenant ?")
	  (aside kpc 'ch_amy "Heerrrkkk !  Mauvais Hypnotiseur !")
	  (prompt-for-key)
	  )
	)

    (if (in-player-party? 'ch_nate)
	(begin
	  (say knpc "\n[Le son mort de la crypte se fait entendre]")
	  (kern-sleep 3000)
	  (aside kpc 'ch_nate "Euh...")
	  (kern-sleep 100)
	  (aside kpc 'ch_nate "  On devrait peut-être...")
	  (kern-sleep 1000)
	  (aside kpc 'ch_nate "  prendre ses affaires ?")
	  (kern-sleep 500)
	  (aside kpc 'ch_roland "Non ! Ce serait un déshonneur !")
	  (prompt-for-key)
	  )
	)
    
    (if (in-player-party? 'ch_amy)
	(begin
	  (aside kpc 'ch_amy "Je pourrais peut-être... creuser un trou, à un certain endroit ?")
	  (prompt-for-key)
	  )
	)

    (kern-sleep 3000)
    (say knpc
	 "\n[Sa forme immobile se contracte]\n"
	 "[Son bras tâtonne pour atteindre sa poitrine]\n"
	 "  ^c+bIN VAS MANI CORP XEN^c-\n"
	 "")
    ;; (vas-mani knpc)  ;; SAM: Alas, this invoked UI, and emitted extra messages
    (say knpc
	 "\n[Il se redresse, et respire profondément]\n"
	 "Comme je le disais, je vais assez bien, merci.")
    ))

(define (necr-name knpc kpc)
  (say knpc "Je suis le Necromancien."))

(define (necr-join knpc kpc)
  (say knpc "Je ne suis pas un aventurier."))

(define (necr-job knpc kpc)
  (say knpc "J'enquête sur les secrets de la mort."))

(define (necr-bye knpc kpc)
  (say knpc "[Il vous fait signe de quitter les lieux en toussant]"))

;; L2
(define (necr-dead knpc kpc)
  (say knpc "Mort ? Non, pas encore. Vous ?")
  (if (yes? knpc)
      (say knpc "Vous avez l'air un peu ferme pour un esprit.")
      (say knpc "Je ne le pensais pas, mais je parle à tellement d'esprits que je ne peux pas "
           "vraiment en dire plus.")))

(define (necr-coug knpc kpc)
  (say knpc "J'ai fumé la pipe pendant des années. Je le fais encore, parfois."))

(define (necr-spir knpc kpc)
  (say knpc "Certains esprits sont si vieux qu'ils se souviennent "
       "d'histoires antérieures. [ tousse ] Si vous voulez savoir quelque chose, il y a un esprit "
       "situé on ne sait où et qui le sait."))

;; Quest-related
(define (necr-meet-lich knpc kpc)
  (if (quest-done? (necr-quest (kobj-gob-data knpc)))
      (begin
        (say knpc "Demandez à l'esprit du roi Luximene ! Vous ne le voyez pas ?")
        (if (no? kpc)
            (begin
              (say knpc "Oh, désolé. Laissez-moi arranger ça :\n"
		   "[Il entonne des mots magiques]"
		   "  ^c+bWIS QUAS^c-!")
              (wis-quas knpc))
            (say knpc "Eh bien...")))
      (begin
        (say knpc "Ah ! Vous avez le crâne du roi Luximène ! "
             "Il y a sans doute une bonne histoire pour accompagner cela, "
             "mais nous en reparlerons plus tard. Pour l'instant...")
        (kern-obj-remove-from-inventory kpc t_lich_skull 1)
        (say knpc "\n[Il entonne des mots magiques]\n"
	     "  ^c+bKAL AN XEN CORP^c-!\n"
	     "Luximene, venez !")
        (kern-obj-put-at (mk-luximene)
                         (loc-offset (kern-obj-get-location knpc)
                                     south))
        (quest-done! (necr-quest (kobj-gob-data knpc)) #t)
        (say knpc "Voilà ! Vous le voyez ?")
        (if (no? kpc)
            (begin
              (say knpc "Bien sûr, son esprit est invisible pour les non-initiés.\n"
                   "Laissez-moi arranger ça :\n"
		   "[Il entonne des mots magiques]"
		   "  ^c+bWIS QUAS^c-!")
              (wis-quas knpc))
            (say knpc "Demandez-lui la rune maintenant.")))))

(define (necr-rune knpc kpc)
  (let ((quest (necr-quest (kobj-gob-data knpc))))
    (if (quest-offered? quest)
        (if (in-inventory? kpc t_lich_skull)
            (necr-meet-lich knpc kpc)
            (if (quest-done? quest)
                (begin
                  (say knpc "Demandez à l'esprit du roi Luximene ! Vous ne le voyez pas ?")
                  (if (no? kpc)
                      (begin
                        (say knpc "Essayez un sort de révélation...\n"
			     "[Il entonne des mots magiques]\n"
			     "  ^c+bWIS QUAS^c-\n"
			     "Parlez à son ombre, demandez la RUNE.")
			(wis-quas knpc)
			(kern-conv-end)
			)
                      (begin
			(say knpc "Alors, demandez à son ombre.")
			(kern-conv-end)
		      )
		  ))
                (say knpc "Apportez-moi le crâne du roi Luximène la Liche "
                     "et nous pouvons en apprendre davantage.")))
        (if (not (any-in-inventory? kpc rune-types))
            (say knpc "J'ai rencontré beaucoup de runes. [ tousse ] Apportez-moi un "
                 "exemplaire et je pourrai peut-être vous en parler.")
            (begin
              (say knpc "Hm. Oui. Cette rune me rappelle des écrits que j'ai vus un jour dans "
                   "le tombeau du roi Luximène. [ tousse ] Si je pouvais parler à son "
                   "esprit peut-être plus cela nous en dira un peu plus. Es-tu courageux, Vagabond ?")
              (if (no? kpc)
                  (say knpc "Moi non plus. C'est dommage, car je suis très curieux "
                       "maintenant à propos de cette rune. [ tousse ]")
                  (begin
                    (say knpc "C'est ce que je pensais. Le roi Luximene est une liche de nos jours. "
                         "Très indiscipliné ! Sa tombe se trouve dans une crypte sous la Tour verte. "
                         "Si vous me rapportez son crâne, je pourrai apprivoiser son esprit et parler "
                         "avec lui. [ tousse ] Vous devrez d'abord le vaincre, "
                         "bien sûr, ainsi que son armée de morts-vivants. "
                         "Savez-vous comment repousser les morts-vivants ?")
                    (quest-offered! quest #t)
                    (if (yes? kpc)
                        (say knpc "Un sort très utile quand on a affaire à des morts en colère.")
                        (say knpc "Apprenez-en davantage [An Xen Corp].\n"
			     "Un sort des plus utiles.\n"
			     "Mélanger l'^c+gail^c- et les ^c+gcendres sulphureuses^c-\n"
			     "pour le faire.\n"
                             "[ tousse ]\n"
			     "Je dois probablement en "
                             "avoir ici.\n"
			     "Vous pouvez l'emprunter."))
		    )))))))

(define (necr-absa knpc kpc)
  (say knpc "Ah, Absalot, ancienne cité de la Sagesse, aujourd'hui détruite."
       "Vous y êtes allé ?")
  (if (yes? kpc)
      (say knpc "Ce n'est plus qu'une ruine honteuse.")
      (begin
        (say knpc "Êtes-vous un allié de Glasdrin ?")
        (if (yes? kpc)
            (say knpc "[Il tousse et marmonne] Eh bien, "
                 "il n'y a plus rien à y voir maintenant.")
            (say knpc "Il y a un passage secret. Demandez à l'Alchimiste, il le connait.")))))

;; the wise
(define (necr-ench knpc kpc)
  (say knpc "Le vieux fou croit que je suis un des Maudits ! "
       "Il ne comprend pas que ses façons de faire ne sont pas les seules.")
       )

(define (necr-man knpc kpc)
  (say knpc "Le MEC vient parfois me voir quand il a besoin d'informations... "
       "et en retour, il acquiert parfois... des choses pour moi.")
  (quest-data-update 'questentry-the-man 'common 1)
  )

(define (necr-alch knpc kpc)
  (say knpc "Un homme intelligent. Un homme profond, bon à sa manière.")
  (quest-data-update 'questentry-alchemist 'common 1)
  )

(define (necr-engi knpc kpc)
  (say knpc "Un homme intelligent et très curieux, "
       "mais il faut toujours qu'il fasse quelque chose. "
       "Et dès qu'il a fini, il en commence une autre ! "
       "[ tousse ] Jamais le temps de réfléchir à quelque chose de valable.")
       (quest-data-update 'questentry-engineer 'common 1)
       )

(define (necr-warr knpc kpc)
	(if (quest-data-assigned? 'questentry-wise)
		(begin
		  (say knpc "Hélas, elle est tuée. J'ai rencontré son esprit dans le vide. "
		       "Elle a été trahie par les dirigeants de Glasdrin. "
		       "Si seulement les dieux ne nous avaient pas abandonnés, "
		       "et Vale, seigneur de la vengeance, traquait toujours le Tesson !")
		       (quest-data-update 'questentry-warritrix 'slain 1)
		 )
		 (say knpc "Il n'y a pas eu un autre chevalier aussi noble et aussi fort "
		 "depuis très, très longtemps.")
       ))

(define (necr-vale knpc kpc)
  (say knpc "Un ancien dieu, connu seulement des morts maintenant."))

(define (necr-wise knpc kpc)
  (say knpc "C'est une tradition ancienne et digne que ceux  "
       "qui ont maîtrisé les voies du Guerrier, du Sorcier, du Fabricant "
       "et du Malfrat devraient influencer les affaires du Tesson."
       "La chaîne de cette tradition est longue, "
       "retour des esprits les plus anciens dans le vide."))

(define (necr-accu knpc kpc)
  (say knpc "Ils sont une misérable abomination ! [ tousse ] Leur ordre "
       "a commencé il y a environ 500 ans, ou du moins ce sont les plus anciens "
       "esprits qui parlent d'eux. Mais je ne connais pas leurs secrets "
       "parce que leurs esprits ne retournent pas dans le vide !")
  (prompt-for-key)
  (say knpc "[Il a l'air troublé] "
       "Je n'en trouve aucun parmi les morts qui ont été Maudits de leur vivant. "
       "C'est une énigme des plus troublantes."))

(define (necr-gate knpc kpc)
  (say knpc "Ah, la légendaire Porte des Demons. Je croyais que ce n'était qu'une légende. "
       "Demandez à l'Enchanteur, il en sait sûrement plus que moi. "
       "En attendant, je vais m'entretenir avec les morts pour voir ce que je peux découvrir."))

(define (necr-necr knpc kpc)
  (say knpc "[ tousse ] Je suis spécialisé dans la magie liée aux morts."))

(define necr-conv
  (ifc basic-conv

       ;; basics
       (method 'default necr-default )
       (method 'bonj necr-hail )
	   (method 'hail necr-hail )
	   
       (method 'adie necr-bye )
       (method 'trav necr-job )
       (method 'nom necr-name )
       (method 'join necr-join )
       (method 'sant necr-heal )
       
       (method 'mort necr-dead )
       (method 'tous necr-coug )
       (method 'espr necr-spir )
       (method 'rune necr-rune )
       (method 'absa necr-absa )
       (method 'ench necr-ench )
       (method 'mec  necr-man )
       (method 'alch necr-alch )
       (method 'inge necr-engi )
       (method 'warr necr-warr )
       (method 'vale necr-vale )
       (method 'sage necr-wise )
       (method 'maud necr-accu )
       (method 'port necr-gate )
       (method 'demo necr-gate )
       (method 'necr necr-necr )
       ))

(define (mk-necromancer)
  (bind 
   (kern-mk-char 
    'ch_necr           ; tag
    "Necromancien"    ; name
    necr-species         ; species
    necr-occ              ; occ
    s_necromancer     ; sprite
    faction-men      ; starting alignment
    1 6 0            ; str/int/dex
    0 0              ; hp mod/mult
    0 0              ; mp mod/mult
    max-health ; hp
    -1                   ; xp
    max-health ; mp
    0
    necr-lvl
    #f               ; dead
    'necr-conv         ; conv
    sch_necr         ; sched
    'townsman-ai              ; special ai
    nil              ; container
    (list t_staff)              ; readied
    )
   (necr-mk)))
