;;----------------------------------------------------------------------------
;; gregor.scm - read-only data for Gregor the Charcoal Burner
;;----------------------------------------------------------------------------
;;----------------------------------------------------------------------------
;; Schedule
;; 
;; At the shrine gate (moongate-clearing.scm)
;; His home is Gregor's Hut (gregors-hut.scm).
;;----------------------------------------------------------------------------
(kern-mk-sched 'sch_gregor
               (list 0  0  gh-gregors-bed   "dort")
               (list 6  0  gh-graveyard     "suis en pause")
               (list 7  0  mgc-roadbend     "suis en pause")
               (list 13 0  gh-table-2       "mange")
               (list 14 0  gh-pasture       "travaille")
               (list 17 0  gh-table-2       "mange")
               (list 18 0  gh-living-room   "suis en pause")
               (list 20 0  gh-gregors-bed   "dort")
               )

;;----------------------------------------------------------------------------
;; Gob
(define (gregor-mk) (list (mk-quest)))
(define (gregor-quest gob) (car gob))


;;----------------------------------------------------------------------------
;; Conv
;; 
;; Gregor is an elderly charcoal burner, living near the Shrine Gate.
;; He tends the grounds of the shrine, and takes care of his grandaughter Ilya.
;; 
;; Gregor is the first NPC which the player is likely to encounter,
;; and has a variety of helpful responses for the starting character
;; and the first-time player.
;;----------------------------------------------------------------------------

(define (gregor-kill-nate knpc kpc)
  (say knpc "[Il pointe un doigt tremblant vers Nate] J'ai quelque chose pour toi.")
  (aside kpc 'ch_nate "[Marmonant] Que veut ce vieux fou ?")
  (prompt-for-key)
  (say knpc "[Il sort un parchemin] Ça m'a coûté beaucoup d'or. Je ne peux pas le lire, mais elle m'a dit ce qu'il disait quand je l'ai acheté.")
  (aside kpc 'ch_nate "Attends... c'est un... ?")
  (prompt-for-key)
  (say knpc "XEN CORP!")
  (cast-missile-proc knpc ch_nate t_deathball)
  (aside kpc 'ch_nate "Gasp!")
  (prompt-for-key)
  (if (equal? kpc ch_nate)
      (kern-conv-end)
      (say knpc "[Il se tourne vers vous] Vous ne devriez pas voyager avec des personnes comme ça. Les villageois pourraient se faire une fausse idée de vous."))
  )
  

(define (gregor-hail knpc kpc)
  (if (in-player-party? 'ch_nate)
      (gregor-kill-nate knpc kpc)
      (if (in-inventory? kpc t_letter_from_enchanter)
           (say knpc "Je vois que tu as reçu tes affaires, et cette lettre de l'Enchanteur. "
                "N'oublie pas de preparer tes armes avant de partir. "
                "C'est dangereux la bas!")
           (say knpc "[Vous rencontrez un vieux paysan grisonnant] "
                "Bonjour, Vagabond. Je t'ai cherché. "
                "Il y a des choses qui t'appartiennent, dans cette grotte. "
                "Va à l'endroit où se trouve le coffre, ouvre-le et prend les choses à l'intérieur. "
                "Tout est pour toi."))
      ))

;; Some prompting with initial commands:
;; 
;; Hmmm...perhaps it would be desirable to have game-UI promts
;; spoken out-of-character, so that the NPCs don't break the game fiction...
(define (gregor-open knpc kpc)
  (say knpc "Utilise la touche o pour ^c+bouvrir^c- les coffres."))

(define (gregor-get knpc kpc)
  (say knpc "Utilise la touche g pour ^c+bprendre^c- ce qui se trouve au sol."))

(define (gregor-read knpc kpc)
  (say knpc "Utilise la touche r pour  ^c+bpreparer^c- les armes ou les armures. "
       "On ne peut pas utiliser une arme au combat tant qu'elle n'est pas prête."))

(define (gregor-camp knpc kpc)
  (say knpc "Utilise la touche k pour ^c+b kamper^c-, heu...camper, dans la nature et se soigner."))


(define (gregor-dang knpc kpc)
  (say knpc "Très dangereux ! Si tu as besoin de soins, une auberge de ville est l'endroit le plus sûr. "
       "Tu peux camper dans la nature, mais c'est dangereux quand tu es seul et que tu n'as personne pour monter la garde. "
       "Bien sûr, il existe aussi des sorts et des potions de guérison."))

(define (gregor-dead knpc kpc)
  (say knpc "Oui, c'est dommage. Ma fille et son mari tous les deux - "
       "tués par des trolls."))

(define (gregor-charcoal knpc kpc)
  (say knpc "J'apporte du charbon de bois en ville et je le vends, "
       "des gens viennent dans ma demeure pour l'acheter."))

(define (gregor-hut knpc kpc)
  (say knpc "Ma hutte est dans la foret au sud et à l'est. "
       "Il n'y a plus que moi et ma petite-fille qui y vivons maintenant."))

(define (gregor-ench knpc kpc)
  (quest-data-assign-once 'questentry-calltoarms)
  (say knpc "L'Enchanteur est l'un des Sages. "
       "Il m'a dit de trouver un Vagabond comme toi. "
       "Si j'en voyais un, je devrais l'envoyer sur son chemin. Veux-tu des indications ? ")
  (quest-wise-subinit 'questentry-enchanter)
  (quest-data-update 'questentry-enchanter 'common 1)
  (cond ((yes? kpc)
         (quest-data-update 'questentry-calltoarms 'directions 1)
         (quest-data-update 'questentry-enchanter 'general-loc 1)
         (say knpc "Il vit dans une tour située dans un marécage, à l'ouest, au-dessus des montagnes. "
	      "Prend la route au sud, puis suis la à l'ouest et demande aux gardes du donjon.")
         (else 
          (say knpc "C'est comme tu veux. Si tu veux des indications plus tard, demande-moi à propos de l'Enchanteur.")
          ))
        ))

(define (gregor-cave knpc kpc)
  (say knpc "Là, ce petit sentier qui mène hors du chemin principal vers le Sud et l'Ouest. "
       "Continue à l'intérieur. Ouvre le coffre. Prend les affaires. "
       "Reviens et nous reparlerons, si tu as d'autres questions."))

(define (gregor-ches knpc kpc)
  (say knpc "Vas-y, ouvre-le et prend les affaires à l'intérieur."))

(define (gregor-stuf knpc kpc)
  (say knpc "Les gens ordinaires faisaient des offrandes de ces choses, pensant qu'un jour un Vagabond pourrait revenir."))

(define (gregor-leav knpc kpc)
  (say knpc "Si tu veux partir, il suffit de suivre la piste vers le sud et de sortir."))

(define (gregor-band knpc kpc)
  (let ((quest (gregor-quest (kobj-gob-data knpc))))
    (cond ((quest-accepted? quest)
           (say knpc "As-tu trouvé les bandits ?")
           (cond ((yes? kpc)
                  (say knpc "Que les anciens dieux soient loués !")
                  (quest-done! quest #t)
                  )
                 (else 
                  (say knpc "Va à la Tour verte et renseigne-toi sur les bandits.")
                  )))
          (else
           (say knpc "Les bandits sont dans les bois. "
                "Ils m'ont volé dans ma propre hutte. "
                "J'ai essayé de les combattre, "
                "et maintenant je marche en boitant et avec une canne.")
           (prompt-for-key)
           (say knpc "J'ai une petite-fille qui vit avec moi maintenant. "
                "C'est juste une fillette, mais parfois les mauvais hommes ne s'en soucient pas. "
                "J'ai peur de ce qu'ils feront la prochaine fois.")
           (prompt-for-key)
           (say knpc "Je déteste demander, mais on dit que les Vagabond avaient l'habitude d'aider les gens. Veux-tu m'aider maintenant ?")
           (cond ((yes? kpc)
                  (say knpc "Je te remercie. "
                       "Lorsque tu auras tes affaires, vas à la Tour Verte. "
                       "Demande ce qu'il en est des bandits. "
                       "Quelqu'un sait peut-être où les trouver.")
                  (quest-data-assign-once 'questentry-bandits)
                  (quest-accepted! quest #t)
                  )
                 (else
                  (say knpc "[Il se détourne tristement]")
                  (kern-conv-end)
                  ))))))

(define (gregor-bye knpc kpc)
  (let ((quest (gregor-quest (kobj-gob-data knpc))))
    (cond ((quest-accepted? quest)
           (say knpc "Adieu, et fait attention."))
          (else
           (say knpc "Attend ! Avant que tu partes, j'ai une faveur à te demander.")
           (prompt-for-key)
           (gregor-band knpc kpc)
           ))))

(define gregor-conv
  (ifc basic-conv
       ;; default if the only "keyword" which may (indeed must!) be longer than
       ;; 4 characters. The 4-char limit arises from the kernel's practice of
       ;; truncating all player queries to the first four characters. Default,
       ;; on the other hand, is a feature of the ifc mechanism (see ifc.scm).
       (method 'default (lambda (knpc kpc) (say knpc "Je ne peux pas t'aider dans ce domaine.")))
       (method 'bonj gregor-hail )
	   (method 'hail gregor-hail )
       (method 'sant (lambda (knpc kpc) (say knpc "[tousse] Assez bien. Ma petite-fille m'aide à prendre soin de moi.")))
       (method 'adie gregor-bye )
       (method 'trav (lambda (knpc kpc) (say knpc "Je suis un bruleur de charbon. Je m'occupe aussi de ce sanctuaire.")))
       (method 'join (lambda (knpc kpc) (say knpc "Désolé. J'ai déjà trouvé un travail.")))
       (method 'nom (lambda (knpc kpc) (say knpc "Je m'appelle Gregor.")))

       (method 'ouvr gregor-open )
       (method 'pren gregor-get )

       (method 'grot gregor-cave )
       (method 'coff gregor-ches )

       (method 'affa gregor-stuf )
       (method 'equi gregor-stuf )  ;; A synonym
       (method 'chos gregor-stuf )  ;; A synonym

       (method 'prep gregor-read )
       (method 'dang gregor-dang )

       (method 'camp gregor-camp )
       (method 'kamp gregor-camp ) ;; A synonym

       (method 'band gregor-band )
       (method 'part gregor-leav )

;; SAM -- This response seems to be shadowed by the gregor-band declaration above?
       (method 'band (lambda (knpc kpc) (say knpc "Une bande de voyous fait des raids sur le sanctuaire "
                                             "quand je ne suis pas là. Ils ne m'ont pas attaqué, "
                                             "donc ce ne sont probablement que des voyous, "
                                             "effrayés par le gourdin d'un vieil homme.")))

       (method 'char gregor-charcoal )
       (method 'brul gregor-charcoal )  ;; A synonym

       (method 'fill (lambda (knpc kpc) (say knpc "Oui, c'était une quasi-sorcière comme sa mère. "
                                             "Elle avait le don, mais pas assez pour être parmi les Sages.")))
       (method 'mort gregor-dead )
       (method 'ench gregor-ench )
       (method 'pers (lambda (knpc kpc) (say knpc "Il y a des fermes éparpillées dans "
                                             "les bois et les contreforts.")))
       (method 'fore (lambda (knpc kpc) (say knpc "Reste hors de la foret profonde. "
                                               "Des bandits, des araignées et pire encore y vivent")))
       (method 'port (lambda (knpc kpc) (say knpc "Personne ne peut prédire quand elle s'ouvrira, "
                                             "ni si quelque chose en sortira si cela se produit. "
                                             "J'ai entendu parler d'autres portes dans d'autres régions du pays, "
                                             "et des histoires racontent d'autres portes oubliées depuis longtemps.")))
       (method 'peti (lambda (knpc kpc) (say knpc "J'ai une petite-fille qui s'appelle Ilya.")))
       (method 'aide (lambda (knpc kpc) (say knpc "Il y a toujours des gens qui ont besoin d'aide. "
                                             "Ce sont des temps difficiles dans un pays difficile.")))
       (method 'coll (lambda (knpc kpc) (say knpc "Les trolls sont toujours une menace dans les contreforts, "
                                             "mais plus encore ces derniers temps.")))
       (method 'mari (lambda (knpc kpc) (say knpc "Mon beau-fils était un simple fermier. "
                                             "Je ne sais pas pourquoi les trolls l'ont attaqué. "
                                             "Peut-être qu'ils ont été chassés des collines "
                                             "par autre chose.")))
       (method 'hutt gregor-hut )
       (method 'ilya (lambda (knpc kpc) (say knpc "Oui. Elle vit chez moi maintenant "
                                             "que ses parents sont morts.")))

;; SAM: I dont' see any reference to this lake anywhere, commenting this one out for now...
;;       (method (knpc kpc) (say knpc "Exit this shrine and ye'll find yourself in a "
;;                                             "hidden valley. Head south and you'll see the Gray Lake "
;;                                             "to the west.")))

       (method 'offr (lambda (knpc kpc) (say knpc "Dans la grotte, tu trouveras un coffre. "
                                      "Prend ce qu'il y a à l'intérieur. Les Vagabonds entrent dans ce monde avec peu de choses, "
                                             "et dans le passé, certains ont fait beaucoup de bien, "
                                             "alors les gens laissent des choses en bon état pour le prochain.")
                                             (quest-data-update 'questentry-whereami 'wanderer 2)
       										))
       (method 'pare gregor-dead )
       (method 'deme gregor-hut )

       (method 'tess (lambda (knpc kpc) (say knpc "Le Tesson ?  C'est comme ça qu'on appelle cette terre, Vagabond.")
       				(quest-data-update 'questentry-whereami 'shard 1)
       			))

       (method 'sanc (lambda (knpc kpc) (say knpc "Ce sanctuaire est destiné à ceux qui viennent par la porte. "
                                             "Les Vagabonds comme toi. "
                                             "Les gens y laissent des offrandes simples pour les aider "
                                             "dans leur voyage.")
                                             (quest-data-update 'questentry-whereami 'wanderer 1)
       											))

       (method 'arai (lambda (knpc kpc) (say knpc "Certaines des araignées dans les profondeurs "
					     "de la foret sont monstrueuses - "
					     "grosses comme des boeufs! "
					     "C'est ce qu'on appelle les Enfants d'Angriss.")))
       (method 'angr (lambda (knpc kpc) (say knpc "Juste une légende. "
					     "La mère de toutes les araignées des bois. "
                                             "Elle effraie les enfants, les empêche d'aller dans les bois "
                                             "où ils peuvent se perdre.")))

       (method 'vill (lambda (knpc kpc) (say knpc "Trigrave est la ville la plus proche. "
					     "Suis la route vers le sud et tu ne pourras pas la manquer.")))

       (method 'trol (lambda (knpc kpc) (say knpc "Les trolls mangent les gens. "
					     "Ils peuvent même briser les os et sucer la moelle. "
					     "Il ne reste rien à enterrer.")))

       (method 'vaga (lambda (knpc kpc) (say knpc "Nous appelons les Vagabonds ceux qui viennent par la porte. "
                                             "Personne ne sait d'où ils viennent ni où ils vont. "
                                             "Tu es le premier à passer depuis très, très longtemps.")
                                             (quest-data-update 'questentry-whereami 'wanderer 1)
       										))

       (method 'sage (lambda (knpc kpc) (say knpc "Les Sages sont à la fois forts et - surtout - bons. "
                                             "Ils aident le pays comme ils le peuvent,  "
					     "et tiennent les Maudits à distance.")))
       (method 'maud (lambda (knpc kpc) 
                       (say knpc "Les Maudits ? La rumeur dit qu'ils ont vendu leurs âmes contre la puissance. "
                            "Si ce n'était pas pour les Sages, ils envahiraient le Tesson.")))     

       (method 'sorc (lambda (knpc kpc) (say knpc "Il n'y a plus de sorcières dans cette région.")))
       ))

;;----------------------------------------------------------------------------
;; Ctor
(define (mk-gregor)
  (bind 
   (kern-mk-char 'ch_gregor ; tag
                 "Gregor"              ; name
                 sp_human            ; species
                 nil                 ; occ
                 s_old_townsman          ; sprite
                 faction-men         ; starting alignment
                 0 10 5              ; str/int/dex
                 0 0                 ; hp mod/mult
                 0 0                 ; mp mod/mult
                 max-health -1 max-health 0 2  ; hp/xp/mp/AP_per_turn/lvl
                 #f                  ; dead
                 'gregor-conv        ; conv
                 sch_gregor          ; sched
                 'townsman-ai                 ; special ai
                 nil                 ; container
					   (list t_axe
					         t_armor_leather
					         )              ; readied
                 )
   (gregor-mk)
   ))
