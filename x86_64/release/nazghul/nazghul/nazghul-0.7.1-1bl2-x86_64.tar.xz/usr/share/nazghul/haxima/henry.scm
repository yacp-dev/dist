;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------

;;----------------------------------------------------------------------------
;; Schedule
;; 
;; In Oparine.
;;----------------------------------------------------------------------------
(kern-mk-sched 'sch_henry
               (list 0  0  bilge-water-bed     "dort")
               (list 8  0  bilge-water-counter "travaille")
               (list 23 0  bilge-water-bed     "dort")
               )

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (henry-mk) nil)

;;----------------------------------------------------------------------------
;; Conv
;; 
;; Henry is a one-handed tavern-keeper, doing trade in Oparine.
;; He was once a mighty mariner.
;;----------------------------------------------------------------------------

;; Basics...
(define (henry-hail knpc kpc)
  (say knpc "[Vous rencontrez un homme joyeux avec un crochet à la place de la main] "
       "Bienvenue, mon pote !"))

(define (henry-default knpc kpc)
  (say knpc "Vous demandez le mauvais sel à ce sujet!"))

(define (henry-name knpc kpc)
  (say knpc "Je suis Henry ! Henry le barman."))

(define (henry-join knpc kpc)
  (say knpc "Je vous rejoindrais bien volontiers, mon garçon, mais qui va remplir "
       "les choppes ici si je m'en vais ? Ça ne devrait pas être possible !"))

(define (henry-job knpc kpc)
  (say knpc "Ais-je l'air d'un ministre? Je remplis les choppes avec les seuls sacrements !"))

(define (henry-bye knpc kpc)
  (say knpc "Adieu, et gardez un oeil sur la météo !"))

(define henry-catalog
  (list
   (list t_food 5 "Ma célèbre soupe épaisse de palourdes vous réchauffera jusqu'aux orteils.")
   (list t_beer 5 "Oui, buvez et soyez joyeux, demain matin vous souhaiterez être mort !")
   (list t_wine 7 "Je garde un peu de ces trucs de fantaisie pour les gentleman occasionnels.")
   ))

(define henry-merch-msgs
  (list "Je vous servirai quand ma gueule de bois aura disparue."
        "Laissez le bon temps rouler!"
        "Je n'ai aucun intérêt pour les aliments ou les boissons d'occasion."
        "Là, on parle !"
        "Ne buvez pas et ne naviguez pas !"
        "Si vous cherchez juste un endroit pour traîner, il y a un quai dehors."
        "Je suppose que je peux en faire un ragoût."
        "Très bien. Excellent."
        "Revenez quand vous aurez besoin d'une recharge !"
        "Si vous cherchez juste un endroit pour traîner, il y a un quai dehors."
        ))

;; Trade...
(define (henry-buy knpc kpc) (conv-trade knpc kpc "buy" henry-merch-msgs henry-catalog))
(define (henry-sell knpc kpc) (say knpc "Je ne fait pas commerce avec les gens du porte-à-porte."))

;; Hook...
(define (henry-hook knpc kpc)
  (say knpc "Oui, j'ai perdu mon bras, je l'ai fait, en combattant des monstres redoutables "
       "des profondeurs."))

(define (henry-mons knpc kpc)
  (say knpc "Le kraken m'a pris le bras, l'a cassé tout de suite avec son méchant bec! "
       "Le kraken ne tire pas de loin de la même manière que le ferait ce lâche de "
       "serpent de mer. Non, il aime grignoter à travers les quais et attraper sa proie "
       "en toute tranquillité !"))

(define (henry-serp knpc kpc)
  (say knpc "Le serpent de mer peut broyer un navire quand il s'enroule, "
       "mais c'est une bête lâche, et elle préfère cracher des boules de feu de loin."))

;; Townspeople...
(define (henry-opar knpc kpc)
  (say knpc "C'est un endroit plutot juste."))

(define (henry-gher knpc kpc)
  (say knpc "Vous avez donc entendu la légende de l'horrible Ghertie ! "
       "Si vous n'avez pas d'objection à recevoir un petit conseil non sollicité d'un vieil oiseau de mer, "
       "éloignez-vous des fantômes ! Ils ont faim !")
	(quest-data-assign-once 'questentry-ghertie))

(define (henry-ghos knpc kpc)
  (say knpc "La mer est pleine de morts, et Ghertie a fait son devoir "
       "pour les y mettre.  J'ai vu des nuits de pleine lune où ils se lèvent "
       "et rôdent sur les vagues de la même manière que les chats ! Ce qui est terrible, c'est la mort, "
       "et Henry n'a pas l'intention de les rejoindre !")
	(quest-data-assign-once 'questentry-ghertie))

(define (henry-alch knpc kpc)
  (say knpc "Oui, il est bizarre."))

(define (henry-bart knpc kpc)
  (say knpc "[voix grave] Bart est le meilleur charpentier naval de la Péninsule ! "
       "[se penchant plus près et plus doucement] Et le seul charpentier naval, aussi !"))

(define (henry-seaw knpc kpc)
  (say knpc "Une belle jeune fille, mais étrange tel un poisson sur la terre ferme !"))

(define (henry-osca knpc kpc)
  (say knpc "Une âme pathétique et mal placée, mais il en boit bien sa dose."))

(define henry-conv
  (ifc basic-conv

       ;; basics
       (method 'default henry-default )
       (method 'bonj henry-hail )
	   (method 'hail henry-hail )
	   
       (method 'adie henry-bye )
       (method 'trav henry-job )
       (method 'nom henry-name )
       (method 'join henry-join )
       
       ;; trade
       (method 'comm henry-buy )
       (method 'ache henry-buy )
       (method 'vend henry-sell )
       (method 'sacr henry-buy )

       ;; hand
       (method 'croc henry-hook )
       (method 'main henry-hook )
       (method 'mons henry-mons )
       (method 'prof henry-mons )
       (method 'mer henry-serp )
       (method 'serp henry-serp )

       ;; town & people
       (method 'opar henry-opar )
       (method 'alch henry-alch )
       (method 'gher henry-gher )
       (method 'horr henry-gher )
       (method 'bart henry-bart )
       (method 'sorc henry-seaw )
       (method 'osca henry-osca )

       ))

(define (mk-henry)
  (bind 
   (kern-mk-char 'ch_henry           ; tag
                 "Henry"             ; name
                 sp_human            ; species
                 nil                 ; occ
                 s_townsman          ; sprite
                 faction-men         ; starting alignment
                 1 0 0               ; str/int/dex
                 0 0                 ; hp mod/mult
                 0 0                 ; mp mod/mult
                 max-health -1 max-health 0 6  ; hp/xp/mp/AP_per_turn/lvl
                 #f                  ; dead
                 'henry-conv         ; conv
                 sch_henry           ; sched
                 'townsman-ai                 ; special ai
                 (mk-inventory (list (list 1 t_dagger)))     ; container
                 nil                 ; readied
                 )
   (henry-mk)))
