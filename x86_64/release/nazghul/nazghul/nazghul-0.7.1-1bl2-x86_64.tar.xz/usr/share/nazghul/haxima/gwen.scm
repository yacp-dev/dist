;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------

;;----------------------------------------------------------------------------
;; Schedule
;;
;; The schedule below is for the place "Trigrave"
;;----------------------------------------------------------------------------
(kern-mk-sched 'sch_gwen
               (list 0  0  trigrave-gwens-bed        "dort")
               (list 8  0  trigrave-tavern-table-1a  "mange")
               (list 9  0  trigrave-inn-counter      "travaille")
               (list 13 0  trigrave-tavern-table-1d  "mange")
               (list 14 0  trigrave-inn-counter      "travaille")
               (list 20 0  trigrave-tavern-table-1a  "mange")
               (list 21 0  trigrave-inn-counter      "travaille")
               )

;;----------------------------------------------------------------------------
;; Gob
;;
;; Quest flags, etc, go here.
;;----------------------------------------------------------------------------
(define (gwen-mk) nil)

;;----------------------------------------------------------------------------
;; Conv
;;
;; Gwen is the innkeeper for Trigrave. She is a gracious, mysterious woman.
;;----------------------------------------------------------------------------
(define (gwen-trade knpc kpc)
  (if (not (string=? "travaille" (kern-obj-get-activity knpc)))
      (say knpc "Passez dans ma boutique quand je suis ouvert. "
           "C'est l'auberge de la Colombe Grise, dans le coin nord-ouest de la ville. "
           "J'ouvre le matin à 9 heures et je ferme le comptoir à minuit.")
      (let ((door (eval 'trigrave-inn-room-1-door)))
        ;; is the room still open?
        (if (not (door-locked? (kobj-gob door)))
            ;; yes - remind player
            (say knpc "Votre chambre est toujours ouverte !")
            ;; no - ask if player needs a room
            (begin
              (say knpc "Vous avez besoin d'une chambre ?")
              (if (kern-conv-get-yes-no? kpc)
                  ;; yes - player wants a room
                  (begin
                    (say knpc 
                         "Cela fera " trigrave-inn-room-price " pièces d'or, "
                         "et vous pouvez utiliser la chambre aussi "
                         "longtemps que vous restez en ville. D'accord ?")
                    (if (kern-conv-get-yes-no? kpc)
                        ;; yes - player agrees to the price
                        (let ((gold (kern-player-get-gold)))
                          ;; does player have enough gold?
                          (if (>= gold trigrave-inn-room-price)
                              ;; yes - player has enough gold
                              (begin
                                (kern-player-set-gold 
                                 (- gold 
                                    trigrave-inn-room-price))
                                (say knpc "Vous êtes dans la chambre 1. Profitez de votre séjour !")
                                (send-signal knpc door 'unlock)
                                (kern-conv-end)
                                )
                              ;; no - player does not have enouvh gold)
                              (say knpc "Désolé, mais vous avez besoin de plus d'or !")))
                        ;; no - player does not agree to the price
                        (say knpc 
                             "Vous ne trouverez pas de meilleure offre dans la Péninsule !")))
                  ;; no - player does not want a room
                  (say knpc "Peut-être une autre fois.")))))))

(define (gwen-thie knpc kpc)
  (say knpc "Des voyageurs récents de la Tour Verte ont rencontré un homme très pressé qui se dirigeait vers l'est par le col. Vous pouvez essayer de vous renseigner à la Tour Verte.")
  (quest-data-update-with 'questentry-thiefrune 'tower 1 (quest-notify (grant-party-xp-fn 10)))
  )

(define gwen-conv
  (ifc basic-conv
       ;; default if the only "keyword" which may (indeed must!) be longer than
       ;; 4 characters. The 4-char limit arises from the kernel's practice of
       ;; truncating all player queries to the first four characters. Default,
       ;; on the other hand, is a feature of the ifc mechanism (see ifc.scm).
       (method 'default (lambda (knpc kpc) 
                          (say knpc "Je ne peux pas vous aider à ce sujet")))
       (method 'bonj (lambda (knpc kpc)
                 (kern-print "[Vous voyez une charmante femme habillée en "
                             "gris. Une longue et fine epee est attachée "
                             "à sa taille]")
                 (say knpc "Bienvenue, voyageur.")))
							 
		(method 'hail (lambda (knpc kpc)
                 (kern-print "[Vous voyez une charmante femme habillée en "
                             "gris. Une longue et fine epee est attachée "
                             "à sa taille]")
							 
							 
                 (say knpc "Bienvenue, voyageur.")))
       (method 'adie (lambda (knpc kpc) (say knpc "Au revoir.")))
       (method 'trav (lambda (knpc kpc) 
                 (say knpc "Je suis l'aubergiste de Trigrave.")
                 (gwen-trade knpc kpc)))
       (method 'nom (lambda (knpc kpc) (say knpc "Je m'appelle Gwen.")))
       (method 'comm gwen-trade )
       (method 'join (lambda (knpc kpc) 
                 (say knpc "Mes voyages sont terminés, "
                      "mais merci pour cette offre.")))
       (method 'chan (lambda (knpc kpc)
                 (say knpc "Ce guignol se trouve généralement à la taverne. "
                      "il revient toujours en titubant dans sa chambre ici, tard dans la nuit, ivre autant qu'un marin.")))
       (method 'civi (lambda (knpc kpc) 
                 (say knpc "Il n'y a pas beaucoup de gens dont on peut parler ici.")))
       (method 'earl (lambda (knpc kpc)
                 (say knpc "Un vieil homme doux mais aigri. Il tient la boutique "
                      "au sud de mon auberge.")))
       (method 'enne (lambda (knpc kpc) (say knpc "Cela ne vous concerne pas.")))
       (method 'echa (lambda (knpc kpc)
                 (say knpc "Si l'on souhaite se cacher d'un ennemi ou d'un "
                      "acte honteux, il n'y a pas de meilleur endroit que ce  "
                      "coin perdu du Tesson.")))
       (method 'aube (lambda (knpc kpc)
                 (say knpc "J'aime diriger l'auberge parce que j'ai l'occasion d'entendre "
                            "les nouvelles des voyageurs.")))
       (method 'jim (lambda (knpc kpc)
                 (say knpc "Beau, mais plutôt sinistre. Il possède une "
                      "forge à l'extrémité est de la ville.")))
       (method 'nouv (lambda (knpc kpc)
                       (say knpc "J'ai entendu dire qu'il manquait quelque chose de précieux à l'Enchanteur.")))
       (method 'cham gwen-trade )
       (method 'hont (lambda (knpc kpc) (say knpc "Cela ne vous concerne pas.")))
       (method 'epee (lambda (knpc kpc) 
                 (say knpc "C'est le cadeau d'un ami.")))
       (method 'tave (lambda (knpc kpc)
                 (say knpc "Le Pichet Vigoureux se trouve dans le coin sud de la ville.")))
       (method 'vole gwen-thie )
       (method 'trig (lambda (knpc kpc) 
                 (say knpc "C'est une petite ville, loin de la civilisation. "
                      "Beaucoup viennent ici pour s'echapper.")))

       ))
