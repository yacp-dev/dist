;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------

;;----------------------------------------------------------------------------
;; Schedule
;;
;; In Oparine
;;----------------------------------------------------------------------------
(kern-mk-sched 'sch_oscar
               (list 0  0  oparine-innkeepers-bed "dort")
               (list 8  0  bilge-water-seat-3     "mange")
               (list 9  0  cheerful-counter       "travaille")
               (list 12 0  bilge-water-seat-3     "mange")
               (list 13 0  cheerful-counter       "travaille")
               (list 21 0  bilge-water-seat-3     "mange")
               (list 22 0  bilge-water-hall       "suis en pause")
               (list 23 0  oparine-innkeepers-bed "dort")
               )

;;----------------------------------------------------------------------------
;; Gob
;;
;; Quest flags, etc, go here.
;;----------------------------------------------------------------------------
(define (oscar-mk) nil)

;;----------------------------------------------------------------------------
;; Conv
;;
;; Oscar is the innkeeper in Oparine.  He is a glum fellow, with a wooden leg.
;;----------------------------------------------------------------------------

;; Basics...
(define (oscar-hail knpc kpc)
  (say knpc "[Vous rencontrez un homme lugubre avec une jambe de bois] Bonjour."))

(define (oscar-default knpc kpc)
  (say knpc "Je ne sais pas."))

(define (oscar-name knpc kpc)
  (say knpc "Je suis Oscar l'aubergiste."))

(define (oscar-join knpc kpc)
  (say knpc "Je risque de me mettre dans le mauvais sens sur le chemin."))

(define (oscar-job knpc kpc)
  (say knpc "Je suis l'aubergiste. "
       "Je doute que vous vouliez louer une chambre, "
       "mais si vous le faites, faites-le moi savoir."))

(define (oscar-bye knpc kpc)
  (say knpc "Au revoir"))

;; Trade...
(define (oscar-trade knpc kpc)
  (if (not (string=? "travaille" (kern-obj-get-activity knpc)))
      (say knpc "L'auberge est ouverte de 9 heures à 9 heures, et je dois parfois manger, "
           "alors essayez plus tard.")
      (let ((door (eval 'oparine-inn-room-1-door)))
        ;; is the room still open?
        (if (not (door-locked? (kobj-gob door)))
            ;; yes - remind player
            (say knpc "Votre chambre est toujours ouverte.")
            ;; no - ask if player needs a room
            (begin
              (say knpc "Vous avez besoin d'une chambre ?")
              (if (kern-conv-get-yes-no? kpc)
                  ;; yes - player wants a room
                  (begin
                    (say knpc 
                         "Ce sera " oparine-inn-room-price " pièces d'or. "
                         "Vous pouvez avoir la chambre tant que vous êtes en ville. "
                         "La voulez-vous toujours ?")
                    (if (kern-conv-get-yes-no? kpc)
                        ;; yes - player agrees to the price
                        (let ((gold (kern-player-get-gold)))
                          ;; does player have enough gold?
                          (if (>= gold oparine-inn-room-price)
                              ;; yes - player has enough gold
                              (begin
                                (say knpc "Ok, vous êtes dans la chambre 1, "
                                     "mais vous n'aimerez pas."
                                     "Ne vous plaignez pas à moi parce que je vous ai dit "
                                     "ainsi.")
                                (kern-player-set-gold 
                                 (- gold 
                                    oparine-inn-room-price))
                                (send-signal knpc door 'unlock)
                                (kern-conv-end)
                                )
                              ;; no - player does not have enouvh gold)
                              (say knpc "Désolé, mais vous n'avez pas d'or. "
                                   "Ce n'est pas une maison de pauvres, vous savez." )))
                        ;; no - player does not agree to the price
                        (say knpc 
                             "Je savais que vous ne le feriez pas.")))
                  ;; no - player does not want a room
                  (say knpc "Je ne le pensais pas. "
                       "Je voulais juste être poli.")))))))

;; Inn...
(define (oscar-inn knpc kpc)
  (say knpc "L'ancien propriétaire lui a donné ce nom. "
       "Je n'avais pas envie de le changer. En plus, ça porterait malheur."))

(define (oscar-luck knpc kpc)
  (say knpc "Le fantôme de la chambre 3 aime ce nom. Je ne veux pas du fantôme d'un méchant pirate en "
       "colère contre moi.")
	(quest-data-assign-once 'questentry-ghertie)
	(quest-data-update 'questentry-ghertie 'ghertieloc 1))

(define (oscar-ghost knpc kpc)
  (say knpc "L'horrible Ghertie a été assassinée par son équipage dans la chambre 3. "
       "Elle la hante encore, donc je ne la loue pas. "
       "J'aimerais qu'elle paie sa facture.")
	(quest-data-update 'questentry-ghertie 'ghertieid 1)
	(quest-data-update 'questentry-ghertie 'ghertieloc 1)
	(quest-data-assign-once 'questentry-ghertie))

;; Leg...
(define (oscar-leg knpc kpc)
  (say knpc "J'ai essayé d'être un marin mais personne ne voulait me prendre. "
       "J'ai donc coupé ma jambe pour me faire passer pour un marin. "
       "Ils ne voulaient toujours pas me prendre. Cette jambe me manque."))

;; Townspeople...
(define (oscar-opar knpc kpc)
  (say knpc "C'est une ville portuaire. La plupart de mes clients sont des voyageurs qui "
       "débarquent ici avant de se diriger vers le nord."))

(define (oscar-gher knpc kpc)
  (say knpc "Ghertie était un méchant pirate avant mon époque. "
       "Son propre équipage l'a assassinée puis s'est enfui avec son bateau et son trésor.")
	(quest-data-assign-once 'questentry-ghertie))

(define (oscar-alch knpc kpc)
  (say knpc "Sa boutique est à côté de la taverne. Il est toujours à la recherche de bizarreries "
       "à utiliser dans ses expériences."))

(define (oscar-bart knpc kpc)
  (say knpc "Bart le charpentier naval a une boutique juste en face. "
       "Il est généralement assez saoul le soir. Je n'arrive pas à le suivre."))

(define (oscar-seaw knpc kpc)
  (say knpc "La sorcière des mers est très belle mais reste seule. "
       "Elle m'ignore, bien sûr."))

(define (oscar-henr knpc kpc)
  (say knpc "Il y a un vrai marin. Je ne serai jamais semblable à lui."))

(define oscar-conv
  (ifc basic-conv

       ;; basics
       (method 'default oscar-default )
       (method 'bonj oscar-hail )
	   (method 'hail oscar-hail )
	   
       (method 'adie oscar-bye )
       (method 'trav oscar-job )
       (method 'nom oscar-name )
       (method 'join oscar-join )
       
       ;; trade
       (method 'comm oscar-trade )
       (method 'cham oscar-trade )
       (method 'ache oscar-trade )
       (method 'vend oscar-trade )

       ;; inn
       (method 'aube oscar-inn )
       (method 'malh oscar-luck )
       (method 'fant oscar-ghost )
       (method 'pira oscar-ghost )
       (method 'jamb oscar-leg )

       ;; town & people
       (method 'opar oscar-opar )
       (method 'alch oscar-alch )
       (method 'gher oscar-gher )
       (method 'horr oscar-gher )
       (method 'henr oscar-henr )
       (method 'bart oscar-bart )
       (method 'mer oscar-seaw )
       (method 'sorc oscar-seaw )

       ))

(define (mk-oscar)
  (bind 
   (kern-mk-char 'ch_oscar           ; tag
                 "Oscar"             ; name
                 sp_human            ; species
                 nil                 ; occ
                 s_townsman          ; sprite
                 faction-men         ; starting alignment
                 1 1 0               ; str/int/dex
                 0 0                 ; hp mod/mult
                 0 0                 ; mp mod/mult
                 max-health -1 max-health 0 1  ; hp/xp/mp/AP_per_turn/lvl
                 #f                  ; dead
                 'oscar-conv         ; conv
                 sch_oscar           ; sched
                 'townsman-ai        ; special ai
                 nil                 ; container
                 (list t_dagger)     ; readied
                 )
   (oscar-mk)))
