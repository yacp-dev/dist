;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------
(define enchanter-start-lvl 8)

;;----------------------------------------------------------------------------
;; Schedule
;;
;; The schedule below is for the place "Enchanter's Tower Ground Floor"
;; 
;; (The fact that he never visits the second floor of his own tower
;; should serve as an incentive for us to eventually get multi-place
;; schedules working  :-)
;;----------------------------------------------------------------------------
(kern-mk-sched 'sch_enchanter
               (list 0  0  enchtwr-ench-bed        "dort")
               (list 8  0  enchtwr-dining-room-2   "mange")
               (list 9  0  enchtwr-hall            "suis en pause")
               (list 12 0  enchtwr-dining-room-2   "mange")
               (list 13 0  enchtwr-hall            "suis en pause")
               (list 19 0  enchtwr-dining-room-2   "mange")
               (list 20 0  enchtwr-bedroom-1       "suis en pause")
               )

;;----------------------------------------------------------------------------
;; Gob
;;
;; Quest flags, etc, go here.
;;----------------------------------------------------------------------------
(define (enchanter-mk)
  (list #f 
        (mk-quest) ;; get stolen rune
        (mk-quest) ;; learn the purpose of the runes
        (mk-quest) ;; get all runes
        (mk-quest) ;; open demon gate
        ))
(define (ench-met? gob) (car gob))
(define (ench-first-quest gob) (cadr gob))
(define (ench-second-quest gob) (caddr gob))
(define (ench-quest gob n) (list-ref gob n))
(define (ench-met! gob val) (set-car! gob val))

;;----------------------------------------------------------------------------
;; Conv
;;
;; The Enchanter is a powerful Mage, and one of the Wise.
;; He lives in the Enchanter's Tower.
;; He plays an important role in multiple stages of the main quest.
;;----------------------------------------------------------------------------
(define (ench-hail knpc kpc)
  (let ((ench (gob knpc)))

    ;; Fourth Quest -- open the demon gate
    (define (check-fourth-quest)
      (say knpc "Avez-vous trouvé l'emplacement de la Porte des Demons ?")
      (if (yes? kpc)
          (begin
            (say knpc "Et avez-vous trouvé les serrures que les clés Runiques vont ouvrir ?")
            (if (yes? kpc)
                (say knpc "Donc, vous vous amusez, vous perdez du temps!. Je vois.")
                (say knpc "Je m'attendrais à ce qu'ils apparaissent comme des autels dans un sanctuaire. "
                     "Le sanctuaire peut être caché, et être révélé peut-être avec un "
                     "mot de passe. Trouvez et recherchez les Maudits, "
                     "ils devraient avoir un indice.")))
          (say knpc "Cherchez dans la bibliothèque d'Absalot.")))

    ;; Third Quest -- find all the Runes
    (define (finish-third-quest)
      (say knpc "Vous avez trouvé toutes les Runes ! "
           "Alors!, ça n'a pas dû être si difficile. ")
      (prompt-for-key)
      (say knpc "J'ai une dernière tâche pour vous. "
           "Vous devez trouver la Porte des Demons et la rouvrir. "
           "Savez-vous où la trouver ?")
      (if (yes? kpc)
          (say knpc
               "Je ne sais pas ce que vous allez affronter, "
               "donc préparez-vous! , "
               "et prennez quiconque est assez fou pour se joindre à vous. "
               )
          (say knpc "Les Maudits doivent avoir une idée, "
               "et la bibliothèque d'Absalot peut encore détenir quelques indices. "
               "Cherchez par tous les moyens.")
          )
      (quest-done! (ench-quest ench 3) #t)
      (kern-char-add-experience kpc 100)
      (quest-accepted! (ench-quest ench 4) #t)      
      )

    (define (check-third-quest)
	(define (missing-only-s-rune?)
		(all-in-inventory? kpc
                         (filter (lambda (ktype)
                                   (not (eqv? ktype t_rune_s)))
                                 rune-types)))
	(cond			 
		((missing-only-s-rune?)
			(say knpc "Vous semblez avoir trouvé la plupart des runes maintenant.")
		(prompt-for-key)
		(say knpc "Hmmm.")
		(prompt-for-key)
		(say knpc "J'ai hésité à soulever ce point avant, mais il est peut-être dans vos capacités après tout.")
		(prompt-for-key)
		(say knpc "Nous savons que les Maudits cherchent aussi les runes. Nous devons nous estimer heureux si une seule est tombée dans leurs griffes.")
		(prompt-for-key)
		(say knpc "Vous devrez la chercher dans l'antre même de nos ennemis : les ruines d'Absalot.")
		(quest-data-assign-once 'questentry-rune-s)
		)
		
		((has-all-runes? kpc)
          (finish-third-quest)
          (say knpc "Revenez quand vous aurez trouvé toutes les runes. "
               "Consultez les autres Sages, ils peuvent avoir des indices sur l'endroit où se trouvent les runes.")
	       ))
	       )

    ;; Second Quest -- find out what the Runes are for
    (define (second-quest-spurned)
      (say knpc "Il est du devoir de tous les hommes de bien de s'opposer au mal. "
           "Je n'ai pas de temps pour les paresseux ou les cyniques. Maintenant, donnez-moi ma rune, "
           "prenez votre récompense et sortez !")
      (kern-obj-remove-from-inventory kpc t_rune_k 1)
      (kern-obj-add-to-inventory knpc t_rune_k 1)
      (quest-accepted! (ench-second-quest ench) #f)
      (kern-conv-end))

    (define (start-second-quest)
      (quest-accepted! (ench-second-quest ench) #t)
      (say knpc "Parfait ! D'abord, gardez ma rune, et gardez-la précieusement. ")
      (quest-data-update 'questentry-rune-k 'entrusted-with-rune 1)
      (prompt-for-key)
      (say knpc "Ensuite, trouvez les autres Sages et demandez leur à propos des RUNES. "
           "Vous pourriez commencer par l'alchimiste près d'Oparine. "
           "En étant obscènement avide, "
           "il a consacré sa vie à l'acquisition de secrets.")
      (quest-data-assign-once 'questentry-runeinfo)
      (quest-wise-subinit 'questentry-alchemist)
      (quest-wise-init)
      (kern-conv-end)
      )

    (define (offer-second-quest-again)
      (say knpc "Vous êtes de retour. Vous avez peut-être eu une crise de conscience. "
           "Cela arrive aux pires d'entre nous. "
           "Maintenant, êtes-vous prêt à m'aider à contrecarrer les Maudits ?")
      (if (kern-conv-get-yes-no? kpc)
          (begin
            (kern-obj-remove-from-inventory knpc t_rune_k 1)
            (kern-obj-add-to-inventory kpc t_rune_k 1)
            (start-second-quest))
          (begin
            (say knpc "Comme un cochon à l'abreuvoir, "
                 "un fou retourne à sa propre folie. "
                 "Retournez vous remplir la panse !")
            (kern-conv-end)))
      )
    
    (define (finish-second-quest)
      (say knpc "[Il semble très grave] "
           "Ma Rune est donc l'une des huit clés de la Porte des Demons. "
           "Parfait, vous devez trouver le reste. "
           "Les Maudits ont une longueur d'avance sur nous. "
           "Il ne fait aucun doute qu'ils possèdent déjà certaines des runes. "
           "Quand vous aurez trouvé toutes les runes, revenez me voir.")
      (quest-done! (ench-second-quest ench) #t)
      (quest-data-update 'questentry-runeinfo 'abe 1)
      (quest-data-update 'questentry-runeinfo 'keys 1)
      (quest-data-update 'questentry-runeinfo 'gate 1)
      (quest-data-update 'questentry-rune-k 'entrusted-with-rune 1)
      (quest-data-update-with 'questentry-runeinfo 'done 1 (grant-party-xp-fn 30))
      (quest-data-complete 'questentry-runeinfo)
      ;; temporary setup- will require information gathering first when done
      (prompt-for-key)
      (quest-data-assign-once 'questentry-allrunes)
      (quest-data-convert-subquest 'questentry-rune-k 'questentry-allrunes)
      (quest-data-assign-once 'questentry-rune-k)
      (quest-data-convert-subquest 'questentry-rune-c 'questentry-allrunes)
      (quest-data-convert-subquest 'questentry-rune-d 'questentry-allrunes)
      (quest-data-convert-subquest 'questentry-rune-l 'questentry-allrunes)
      (quest-data-convert-subquest 'questentry-rune-p 'questentry-allrunes)
      (quest-data-convert-subquest 'questentry-rune-s 'questentry-allrunes)
      (quest-data-convert-subquest 'questentry-rune-w 'questentry-allrunes)
      (quest-data-convert-subquest 'questentry-rune-f 'questentry-allrunes)
      (quest-accepted! (ench-quest ench 3) #t)
      )

    (define (check-second-quest)
      (say knpc "Avez-vous appris à quoi sert la Rune ?")
      (if (yes? kpc)
          (begin
            (say knpc "Eh alors, quoi ?")
            (let ((reply (kern-conv-get-reply kpc)))
              (if (or (equal? reply 'demo) (equal? reply 'gate) (equal? reply 'key))
                  (finish-second-quest)
                  (begin
                    (say knpc "Je ne pense pas. Avez-vous demandé à tous les Sages ce qu'ils pensaient des ^c+mrunes^c- ?")
                    (if (yes? kpc)
                        (say knpc "L'un d'entre eux a sûrement dû vous donner un indice !")
                        (say knpc "Cherchez-les tous."))))))
          (say knpc "Demandez à tous les Sages à propos des ^c+mrunes^c-.")))

    ;; First Quest -- find the stolen Rune
    (define (finish-first-quest)
      (say knpc "Ah, je vois que vous avez enfin trouvé ma Rune !")
      (kern-obj-add-gold kpc 200)
		(quest-data-update-with 'questentry-thiefrune 'done 1 (grant-party-xp-fn 20))
		(quest-data-complete 'questentry-thiefrune)
      (say knpc "Peut-être que vous n'êtes pas complètement inutile. "
           "Avez-vous rencontré une quelconque... résistance ?")      
      (kern-conv-get-yes-no? kpc)
      (say knpc "Les Maudits sont à l'origine de ce vol. "
           "Nous devons découvrir à quoi sert la Rune. "
           "Allez-vous nous aider ?")
      (quest-offered! (ench-second-quest ench) #t)
      (if (kern-conv-get-yes-no? kpc)
          (start-second-quest)
          (second-quest-spurned)))

    (define (check-first-quest)
      (if (in-inventory? kpc t_rune_k)
          (finish-first-quest)
          (say knpc "Hmph. Je vois que vous n'avez toujours pas trouvé mon objet !"
               " [ Il marmonne quelque chose à propos des Vagabonds et des Voyous ]")
            ))
    
    ;; Main
    (if (ench-met? ench)
        (if (quest-done? (ench-quest ench 4))
            (say knpc "Salutation, ami des Sages")
            (if (quest-accepted? (ench-quest ench 4))
                (check-fourth-quest)
                (if (quest-accepted? (ench-quest ench 3))
                    (check-third-quest)
                    (if (quest-offered? (ench-second-quest ench))
                        (if (quest-accepted? (ench-second-quest ench))
                            (check-second-quest)
                            (offer-second-quest-again))
                        (if (quest-accepted? (ench-first-quest ench))
                            (check-first-quest)
                            (say knpc "Oui, qu'est-ce que c'est cette fois-ci ?"))))))
        (begin
          (quest-data-update-with 'questentry-calltoarms 'talked 1 (quest-notify (grant-xp-fn 10)))
          (kern-log-msg "Ce mage sans âge ne semble pas surpris de vous voir.")
          (say knpc "Je me demandais quand vous arriveriez ici. "
               "Il vous a fallu du temps !")
          (ench-met! ench #t)))))

(define (ench-name knpc kpc)
  (say knpc "On m'appelle l'Enchanteur."))

(define (ench-job knpc kpc)
  (say knpc "J'aide comme je peux dans la lutte contre le mal."))

(define (ench-default knpc kpc)
  (say knpc "Je ne peux pas vous aider à ce sujet"))

(define (ench-bye knpc kpc)
  (say knpc "Méfiez-vous des Maudits !"))

(define (ench-join knpc kpc)
  (say knpc "Non, ma place est ici. Cherchez la Warritrix si vous désirez un puissant "
       "compagnon."))


(define (ench-warr knpc kpc)
  (say knpc "La Warritrix est sage et féroce, "
       "et comme vous, enclin à l'errance. "
       "En fait, pour l'instant, je ne sais pas où elle se trouve. "
       "Essayez à Glasdrine.")
       (quest-wise-subinit 'questentry-warritrix)
       (quest-data-update 'questentry-warritrix 'general-loc 1)
       )

(define (ench-wand knpc kpc)
  (say knpc "Oui, j'ai déjà rencontré des types comme vous. Imprévisible. "
       "Et quant à savoir si vous êtes bon ou mauvais, cela dépend de vous."))

(define (ench-offer-first-quest knpc kpc)
  (say knpc "Je n'ergoterai pas sur les définitions du bien et du mal. "
       "Ils sont facilement reconnaissables lorsqu'on les rencontre. "
       "Avez-vous l'intention de faire le bien pendant que vous êtes ici ?")
  (if (kern-conv-get-yes-no? kpc)
      ;; yes - player intends to do good
      (begin
        (say knpc "Vous me trouverez alors comme votre allié. "
             "Mais attention ! Beaucoup de ceux qui prétendent être bons ne le sont pas, "
             "ou échouent lorsqu'ils sont mis à l'épreuve. Êtes-vous prêt à être mis à l'épreuve ?")
        (if (kern-conv-get-yes-no? kpc)
            ;; yes - player is ready to be tested
            (begin
              (say knpc "Parfait. Un objet m'a été volé récemment. "
                   "J'ai besoin de quelqu'un pour trouver le voleur, "
                   "récupérer l'objet et me le rendre. Êtes-vous prêt ?")
              (if (kern-conv-get-yes-no? kpc)
                  ;; yes -- player is willing
                  (begin
                    (say knpc "Parfait ! Les Rangers ont traqué le voleur jusqu'à "
                         "Trigrave. Allez là-bas et renseignez-vous sur un ^c+mvoleur^c-.")
							(quest-data-assign-once 'questentry-thiefrune)
              		(quest-data-complete 'questentry-calltoarms)
                  	;; if you dont read the letter, you might not get the quest till now!
              		(quest-data-assign-once 'questentry-calltoarms)
                  	(quest-data-update-with 'questentry-calltoarms 'done 1 (grant-xp-fn 10))
                    (quest-accepted! (ench-first-quest (gob knpc)) #t)
                    )
                  ;; no -- player is not willing
                  (say knpc "Peut-être vous ai-je mal jugé.")))
            ;; no -- player is not ready
            (say knpc "Il ne suffit pas de parler de faire le bien, on ne peut "
                 "pas ETRE bon sans FAIRE le bien.")))
      ;; no -- player does not intend to do good
      (say knpc "Nous verrons cela. Les hommes mauvais peuvent faire le bien sans le vouloir, "
           "et les hommes qui seraient insensibles découvrent qu'ils ne peuvent pas ignorer leur "
           "conscience.")))

(define (ench-good knpc kpc)
  (if (quest-accepted? (ench-first-quest (gob knpc)))
      (say knpc "Les méchants s'enfuient quand personne ne les poursuit, mais les justes sont "
           "audacieux comme des dragons.")
      (ench-offer-first-quest knpc kpc)))

(define (ench-gate knpc kpc)
  (say knpc "Il existe une multitude de portes dans le pays qui sont reliées "
       "les unes les autres et apparaissent selon les phases des lunes. "
       "Mais la Porte du Sanctuaire est la seule que je connaisse avec certitude qui soit reliée à "
       "d'autres mondes."))

(define (ench-wise knpc kpc)
  (say knpc "Les Sages sont les plus puissants des Guerriers, des Sorciers, des Artisans et des "
       "Voyous dans le pays. Bien qu'ils aient pour fonction de protéger le Tesson, "
       "ils ne sont pas tous bons."))

(define (ench-accu knpc kpc)
  (say knpc "Les Maudits sont une société secrète maléfique, responsable de plusieurs  "
       "crimes et atrocités. Avec la destruction d'Absalot, je pensais "
       "qu'ils étaient finis. J'avais tort. Je crains maintenant leur multitude et "
       "leur force est plus grande que jamais."))

(define (ench-moon knpc kpc)
  (say knpc "Demandez à Kalcifax, la voyageuse des portes lunaires. "
       "Elle est une experte en la matière."))

(define (ench-shri knpc kpc)
  (say knpc "La Porte du Sanctuaire s'ouvre de façon imprévisible, et seulement pour une courte durée. "
       "Ceux qui entrent ne reviennent jamais, "
       "et ceux qui en sortent sont des étrangers et des Vagabonds comme vous."))

(define (ench-rune knpc kpc)
  (say knpc "La rune m'a été transmise par mon maître il y a longtemps. "
       "Il ne savait pas à quoi cela servait, et en dépit de toutes mes recherches, je n'ai jamais "
       "trouvé son utilité, lui aussi. J'ai décidé qu'il s'agissait d'une vieille relique sans importance. "
       "Sinon, pourquoi ne serait-elle pas mentionnée dans l'un des tomes obscurs ou "
       "dans les histoires ?"))

(define (ench-wiza knpc kpc)
  (say knpc "Les Guerriers, les Artisans et les Voyous tirent tous un certain pouvoir de leur "
       "connaissance du monde physique. Mais le pouvoir d'un sorcier vient de sa "
       "connaissance du monde magique."))

(define (ench-know knpc kpc)
  (say knpc "Tout comme un aveugle ne peut pas percevoir les couleurs, ceux qui n'ont pas la "
       "L'Oeil intérieur ne peuvent pas percevoir les forces de la magie. Mais ceux qui ont "
       "ouvert l'Oeil perçoivent des causes et des effets invisibles pour les autres."))

(define (ench-wrog knpc kpc)
  (say knpc "Le plus sage des Voyous est le MEC, qui va et vient comme "
       "le vent. Si le MEC a une maison, elle est parfaitement cachée. Demandez autour de vous, "
       "peut-être que vos demandes susciteront une rencontre.")
       (quest-wise-subinit 'questentry-the-man)
       (quest-data-update 'questentry-the-man 'common 1)
       )

(define (ench-wrig knpc kpc)
  (say knpc "Le plus sage des Artisans préfère travailler de manière isolée. Vous le trouverez peut-être "
       "si vous êtes tenace, mais pas dans n'importe quelle ville. "
       "Cherchez le mage Kalcifax, je pense qu'elle connaît  l'Ingenieur.")
       (quest-wise-subinit 'questentry-engineer)
       (quest-data-update 'questentry-engineer 'kalcifax 1)
       )

(define (ench-necr knpc kpc)
  (say knpc "C'est le plus dépravé et le plus méchant de tous les Sages, "
       "mon némésis le Necromancien réside dans un endroit situé dans le monde souterrain. "
       "Il est puissant, trompeur et corrompu au-delà de toute rédemption.")
       (quest-wise-subinit 'questentry-necromancer)
       (quest-data-update 'questentry-necromancer 'general-loc 1)
      )

(define (ench-alch knpc kpc)
  (say knpc "L'alchimiste tient un laboratoire près d'Oparine. "
       "Il est avide et très rusé, alors méfiez-vous de lui.")
       (quest-wise-subinit 'questentry-alchemist)
       (quest-data-update 'questentry-alchemist 'oparine 1)
       )

(define (ench-thie knpc kpc)
	;;in case quest generated once in progress
	(quest-data-assign-once 'questentry-thiefrune)
  (if (quest-done? (ench-first-quest (gob knpc)))
      (say knpc "Plutot gênant, il n'était qu'un intermédiaire. "
           "J'espère que vous ne l'avez pas traité trop durement.")
      (say knpc "Le voleur qui a volé mon objet doit être très malin. Les rangers "
           "ont perdu sa trace à Trigrave. Demandez à tous ceux qui s'y trouvent s'ils "
           "ont vu le ^c+mvoleur^c-.")))

(define (ench-kalc knpc kpc)
  (say knpc "Kalcifax ? Elle est assez difficile à suivre, j'en ai peur."))

(define (ench-demo knpc kpc)
  (say knpc "La Porte des Demons est une porte légendaire que les sorciers d'autrefois avaient l'habitude de franchir pour se rendre dans d'autres mondes. "
       "Puis, pour des raisons qui varient selon les récits, elle a été perdue ou scellée, oubliée ou détruite. "
       "J'ai toujours pensé que c'était une fiction."))

(define (ench-ench knpc kpc)
  (say knpc "Oui?"))

(define enchanter-conv
  (ifc basic-conv
       (method 'default ench-default )
       (method 'bonj ench-hail )
	   (method 'hail ench-hail )
	   
       (method 'nom ench-name )
       (method 'adie ench-bye )
       (method 'trav ench-job )
       (method 'join ench-join )
       
       (method 'ench ench-ench )
       (method 'maud ench-accu )
       (method 'alch ench-alch )
       (method 'mal ench-good )
       (method 'port ench-gate )
       (method 'bien ench-good )
       (method 'conn ench-know )
       (method 'lune ench-moon )
       (method 'necr ench-necr )
       (method 'rune ench-rune )
       (method 'sanc ench-shri )
       (method 'vole ench-thie )
       (method 'erra ench-wand )
       (method 'warr ench-warr )
       (method 'sage ench-wise )
       (method 'sorc ench-wiza )
       (method 'voyo ench-wrog )
       (method 'arti ench-wrig )
       (method 'inge ench-wrig )
       (method 'kalc ench-kalc )
       (method 'demo ench-demo )
       ))

;;----------------------------------------------------------------------------
;; First-time constructor
;;----------------------------------------------------------------------------
(define (mk-enchanter-first-time tag)
  (bind 
   (kern-char-arm-self
    (kern-mk-char 
     tag ;;..........tag
     "L'Enchanteur" ;;.......name
     sp_human ;;.....species
     oc_wizard ;;.. .occupation
     s_old_mage ;;..sprite
     ;;(mk-composite-sprite (list s_hum_body s_hum_belt s_hum_beard))
     faction-men ;;..faction
     0 ;;...........custom strength modifier
     7 ;;...........custom intelligence modifier
     0 ;;...........custom dexterity modifier
     10 ;;............custom base hp modifier
     2 ;;............custom hp multiplier (per-level)
     20 ;;............custom base mp modifier
     5 ;;............custom mp multiplier (per-level)
     max-health ;;..current hit points
     -1  ;;...........current experience points
     max-health ;;..current magic points
     0
     enchanter-start-lvl  ;;..current level
     #f ;;...........dead?
     'enchanter-conv ;;...conversation (optional)
     sch_enchanter ;;.....schedule (optional)
     'townsman-ai ;;..........custom ai (optional)
     ;;..............container (and contents)
     (mk-inventory
      (list
       (list 10  t_food)
       (list 100 t_arrow)
       (list 1   t_bow)
       (list 1   t_dagger)
       (list 1   t_sword)
       (list 1   t_leather_helm)
       (list 1   t_armor_leather)
       (list 5   t_torch)
       (list 5   t_cure_potion)
       (list 5   t_heal_potion)
       ))
     nil ;;.........readied arms (in addition to the container contents)
     nil ;;..........hooks in effect
     ))
   (enchanter-mk)))
