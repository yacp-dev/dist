(kern-add-save-game "test.scm")
