;;----------------------------------------------------------------------------
;; Schedule
;;
;; In Bole.
;;----------------------------------------------------------------------------
(kern-mk-sched 'sch_melvin
               (list 0  0  bole-bed-melvin      "dort")
               (list 7  0  bole-kitchen "travaille")
               (list 21 0  bole-bedroom-may      "suis en pause")
               (list 22 0  bole-bed-melvin "dort")
               )

;;----------------------------------------------------------------------------
;; Gob
;;
;; Quest flags, etc, go here.
;;----------------------------------------------------------------------------
(define (melvin-mk) nil)

;;----------------------------------------------------------------------------
;; Conv
;;
;; Melvin is the cook at the Inn in Bole.
;; He is the (seventh) husband to May.
;;----------------------------------------------------------------------------
(define melv-merch-msgs
  (list "Passez à la taverne quand je suis ouvert. J'ouvre à 7h et je ferme à minuit."
        "Essayez le plat du jour." ;; buy
        nil ;; sell
        nil ;; trade
        "Pas mal, hein ?" ;; sold-something
        "Maintenant, ne soyez pas timide." ;; sold-nothing
        nil ;; bought-something
        nil ;; bought-nothing
        nil ;; traded-something
        nil ;; traded-nothing
   ))

(define melv-catalog
  (list
   (list t_beer  4 "La bière, c'est ce qu'il y a au petit déjeuner !")
   (list t_food  3 "Les gens disent que je fais la meilleure quiche au piment dans le Tesson !")
   ))

(define (melvin-buy knpc kpc) (conv-trade knpc kpc "buy" melv-merch-msgs melv-catalog))

;; basics...
(define (melvin-default knpc kpc)
  (say knpc "Demandez à May à ce sujet, je ne sais pas."))

(define (melvin-hail knpc kpc)
  (say knpc "[Vous rencontrez un chef qui a la gueule de bois] Bonjour, amis."))

(define (melvin-name knpc kpc)
  (say knpc "Je suis Melvin, le cuisinier."))

(define (melvin-job knpc kpc)
  (say knpc "Je dirige l'Auberge et Taverne de Bole avec ma femme, May. Moi je fais la cuisine et "
       "elle sert."))

(define (melvin-join knpc kpc)
  (say knpc "Je ne serais pas très bon avec vous, amis. Mieux vaut me laisser ici "
       "dans ma cuisine où je peux au moins vous préparer de la bouffe."))

(define (melvin-bye knpc kpc)
  (say knpc "Adieu, amis. Reviens quand tu auras faim."))

;; other characters & town...
(define (melvin-may knpc kpc)
  (say knpc "Ma femme, May, est une femme récalcitrante, mais elle est très vive."))

(define (melvin-kath knpc kpc)
  (say knpc "Cette dame rouge est d'une méchante beauté ! Mais je ne suis ni ivre ni "
       "assez bête pour se mêler des affaires des sorciers. Suivez mon conseil, restez "
       "loin d'elle et de cette chose avec laquelle elle voyage !"))

(define (melvin-bill knpc kpc)
  (say knpc "Il lui manque une ou deux vis, mais c'est un bon garçon."))

(define (melvin-thud knpc kpc)
  (say knpc "Ce n'est pas un homme qui voyage avec la dame rouge, mais je n'ai jamais vu "
       "de troll qui pouvait si bien parler. Je ne suis pas sûr de ce que c'est, mais la magie a "
       "joué un petit coup de main dans sa réalisation."))

(define (melvin-bole knpc kpc)
  (say knpc "C'est un endroit assez agréable."))

(define (melvin-hack knpc kpc)
  (say knpc "Hackle vit dans le coin nord-ouest de la ville, de l'autre côté du pont. "
       "C'est une vieille sorcière un peu folle mais inoffensive."))


;; thief quest...
(define (melvin-thie knpc kpc)
  (say knpc "Il y a peu de temps, un étrange voyou est venu ici, "
       "On dirait qu'il avait des démons à ses trousses. Il s'en est allé peu après "
       "que la dame rouge soit arrivée. J'ai parlé avec Hackle avant son départ, je crois. "
       "Très bizarre."))

;; misc...
(define (melvin-wiza knpc kpc)
  (say knpc "Il y a des affaires louches qui se préparent ! Il se passe quelque chose entre "
       "cette sorcière rouge et ce mystérieux voyou, je le sais."))

(define (melvin-inn knpc kpc)
  (say knpc "Si vous avez besoin d'une chambre pour la nuit ou de quelque chose pour vous rincer "
       "le gosier, demandez à May. Mais si vous avez faim, dites-le "
       "et je vous arrange ça tout de suite !"))

(define (melvin-hung knpc kpc)
  (say knpc "Avez-vous faim ?")
  (if (kern-conv-get-yes-no? kpc)
      (melvin-buy knpc kpc)
      (say knpc "Si vous avez faim, dites-le !")))

(define melvin-conv
  (ifc basic-conv
       ;; default if the only "keyword" which may (indeed must!) be longer than
       ;; 4 characters. The 4-char limit arises from the kernel's practice of
       ;; truncating all player queries to the first four characters. Default,
       ;; on the other hand, is a feature of the ifc mechanism (see ifc.scm).
       (method 'default melvin-default )
       (method 'bonj melvin-hail )
	   (method 'hail melvin-hail )
	   
       (method 'adie melvin-bye )
       (method 'trav melvin-job )
       (method 'nom melvin-name )
       (method 'join melvin-join )

       (method 'ache melvin-buy )
       (method 'nour melvin-buy )
       (method 'boir melvin-buy )
       (method 'supp melvin-buy )
       (method 'comm melvin-buy )

       (method 'bill melvin-bill )
       (method 'cuis melvin-inn )
       (method 'aube melvin-inn )
       (method 'kath melvin-kath )
       (method 'roug melvin-kath )
       (method 'femm melvin-kath )
       (method 'sorc melvin-kath )
       (method 'may melvin-may )
       (method 'hack melvin-hack )
       (method 'faim melvin-hung )
       (method 'tave melvin-inn )
       (method 'thud melvin-thud )
       (method 'minc melvin-thud )
       (method 'anim melvin-thud )

       (method 'vole melvin-thie )
       (method 'voyo melvin-thie )
       (method 'vole melvin-thie )
       ))

;;----------------------------------------------------------------------------
;; First-time constructor
;;----------------------------------------------------------------------------
(define (mk-melvin)
  (bind 
   (kern-mk-char 'ch_melvin          ; tag
                 "Melvin"            ; name
                 sp_human            ; species
                 nil                 ; occ
                 s_townsman          ; sprite
                 faction-men         ; starting alignment
                 2 0 1             ; str/int/dex
                 0 0                 ; hp mod/mult
                 0 0                 ; mp mod/mult
                 max-health -1 max-health 0 3  ; hp/xp/mp/AP_per_turn/lvl
                 #f                  ; dead
                 'melvin-conv        ; conv
                 sch_melvin          ; sched
                 'townsman-ai         ; special ai
                 nil     				; container
                 (list t_dagger)   ; readied
                 )
   (melvin-mk)))
