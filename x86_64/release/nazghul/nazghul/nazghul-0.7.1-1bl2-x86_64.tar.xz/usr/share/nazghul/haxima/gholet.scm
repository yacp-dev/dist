;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------
(define gholet-lvl 4)
(define gholet-species sp_human)
(define gholet-occ nil)

;;----------------------------------------------------------------------------
;; Schedule
;; 
;; In the Prison level under Glasdrin
;;----------------------------------------------------------------------------

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (gholet-mk) nil)

;;----------------------------------------------------------------------------
;; Conv
;; 
;; Gholet is a former pirate, now imprisoned in the Prison below Glasdrin.
;; He is one of the surviving crew of the Merciful Death, 
;; and is sought for vengeance by the ghost Ghertie.
;;----------------------------------------------------------------------------

;; Basics...
(define (gholet-hail knpc kpc)
  (say knpc "Salut, chef!"))

(define (gholet-default knpc kpc)
  (say knpc "C'est vrai, chef, c'est ce que j'aime chez vous !"))

(define (gholet-name knpc kpc)
  (say knpc "Gholet est mon nom, mais ne fait pas un cas avec moi, chef")
  (quest-data-update 'questentry-ghertie 'gholet-dungeon 1))

(define (gholet-join knpc kpc)
  (say knpc "Et laisser derrière soi une vie de luxe ? Bah !"))

(define (gholet-job knpc kpc)
  (say knpc "Je suis cuisinier. Ou en tout cas, je l'étais avant de m'engager dans la nouvelle "
       "vocation que vous me voyez ici."))

(define (gholet-bye knpc kpc)
  (say knpc "C'était sympa de discuter avec toi, chef"))

;; Tier 2 replies
(define (gholet-cook knpc kpc)
  (say knpc "J'étais cuisinier sur un célèbre paquebot de luxe ! La Mort Misericordieuse, "
       "jamais entendu parler d'elle ?")
  (if (yes? kpc)
      (say knpc "Oh. Eh bien, je vous avais dit qu'elle était célèbre !")
      (say knpc "Oh, elle était plutôt bien connue à son époque. "
           "Je ne sais pas ce qu'elle est devenue.")))

(define (gholet-merc knpc kpc)
  (say knpc "Oh, oui, elle était commandée par une femme merveilleuse. "
       "Son nom était Ghertie."))

(define (gholet-gher knpc kpc)
  (say knpc "Une vraie pêche. On ne peut pas demander un patron plus gentil."))

(define (gholet-voca knpc kpc)
  (say knpc "Oui, c'est le travail le plus facile que j'ai jamais eu."))

(define (gholet-mean knpc kpc)
  (say knpc "Je n'ai pas vu le vieux Meaney depuis des lustres. "
       "La dernière fois que j'ai entendu parler de lui, il dirigeait un refuge pour les pauvres."))

(define (gholet-jorn knpc kpc)
  (say knpc "Oh, voilà un homme bien dangereux, maintenant chef. "
       "Il vaut mieux laisser les chiens dormir, comme j'aime à le dire. "))

(define (gholet-dog knpc kpc)
  (say knpc "D'après ce que j'ai entendu, ce chien se trouve au Cerf Blanc.")
  (quest-data-update 'questentry-ghertie 'jorn-loc 1))

;; Quest-related
(define (gholet-ring knpc kpc)

  (if (not (in-inventory? knpc t_skull_ring_g))
      (say knpc "Une bague ? Quelle bague ?")
      (begin

        (define (take-picklocks)
          (if (< (num-in-inventory kpc t_picklock) 12)
		(begin
		(quest-data-update-with 'questentry-ghertie 'gholet-price 1 (quest-notify nil))
              (say knpc "Mmm. Un petit problème, chef, "
                   "vous n'avez pas assez de crochets de serrures. "
                   "Mais je vais garder la bague ici en réserve jusqu'à ce que vous le fassiez.")
		   )
              (begin
                (say knpc "C'est vrai, vous allez la bas , et je vais aussi la bas,  "
                     "droit comme la pluie, droit comme la pluie ! Profitez de votre nouvelle bague, "
                     "chef!")
                (kern-obj-remove-from-inventory kpc t_picklock 12)
                (kern-obj-add-to-inventory knpc t_picklock 12)
                (kern-obj-remove-from-inventory knpc t_skull_ring_g 1)
		(skullring-g-get nil kpc)
		)))

        (say knpc "Oh, ce vieux truc ? Ça me démangeait, "
             "Je dois être allergique. "
             "Alors je l'ai enlevé. J'ai enlevé tout le doigt, en fait, "
             "ca fait un peu désordre. Vous voulez la voir ?")
        (if (yes? kpc)
            (begin
              (say knpc "Ne te blâme pas. Pas du tout. "
                   "C'est un objet très curieux ! "
                   "Mais une bonne action en mérite une autre, "
                   "vous n'êtes pas d'accord, chef ?")
              (if (yes? kpc)
                  (begin
                    (say knpc "Bien sûr que si ! Vous êtes un homme juste, chef ! "
                         "Vous savez comme on dit, se gratter le dos les uns les autres ! "
                         "Une douzaine de crochets de serrure. Une douzaine de crochets et vous pouvez avoir la bague. "
                         "Vous êtes d'accord ?")
                    (if (yes? kpc)
                        (take-picklocks)
                        (begin
			(quest-data-update-with 'questentry-ghertie 'gholet-price 1 (quest-notify nil))
                          (say knpc "C'est mon prix. "
                               "Revenez quand vous serez prêt à payer.")
                          (kern-conv-end))))
                  (begin
                    (say knpc "Alors, dégagez !")
                    (kern-conv-end))))
            (say knpc "Ne vous moquez pas de moi. "
                 "Je sais que vous êtes là pour la bague, sinon vous ne l'auriez pas "
                 "demandé.")))))
      
(define gholet-conv
  (ifc basic-conv

       ;; basics
       (method 'default gholet-default )
       (method 'bonj gholet-hail )
	   (method 'hail gholet-hail )
	   
       (method 'adie gholet-bye )
       (method 'trav gholet-job )
       (method 'nom gholet-name )
       (method 'join gholet-join )
       
       ;; other responses
       (method 'cuis gholet-cook )
       (method 'mise gholet-merc )
       (method 'gher gholet-gher )
       (method 'voca gholet-voca )
       (method 'bagu gholet-ring )

       (method 'mean gholet-mean )
       (method 'jom gholet-jorn )
       (method 'chie gholet-dog )
       ))

(define (mk-gholet)
  (bind 
   (kern-char-force-drop
   (kern-mk-char 
    'ch_my           ; tag
    "Gholet"             ; name
    gholet-species         ; species
    gholet-occ              ; occ
    s_brigand     ; sprite
    faction-men      ; starting alignment
    1 0 3            ; str/int/dex
    0 0              ; hp mod/mult
    0 0              ; mp mod/mult
    max-health; hp
    -1                   ; xp
    max-health ; mp
    0
    gholet-lvl
    #f               ; dead
    'gholet-conv         ; conv
    nil              ; sched
    nil              ; special ai
    ;;..........container (and contents)
    (mk-inventory
              (list
               (list 1 t_skull_ring_g)
               ))
    nil              ; readied
    )
   #t)
  (gholet-mk)))
