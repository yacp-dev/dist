;; shroom.scm - an old hag with an interesting history who lives in the
;; northeast corner of green tower.

;;----------------------------------------------------------------------------
;; Schedule
;; 
;; In Green Tower.
;;----------------------------------------------------------------------------
(define (mk-zone x y w h) (list 'p_green_tower x y w h))
(kern-mk-sched 'sch_shroom
               (list 0  0  (mk-zone 51 9  1  1)  "dort")
               (list 5  0  (mk-zone 40 11 3  3)  "suis en pause")
               (list 6  0  (mk-zone 49 6  7  1)  "travaille")
               (list 12 0  (mk-zone 50 9  1  1)  "mange")
               (list 13 0  (mk-zone 49 6  7  1)  "travaille")
               (list 18 0  (mk-zone 56 54 1  1)  "mange")
               (list 19 0  (mk-zone 53 50 4  7)  "suis en pause")
               (list 21 0  (mk-zone 51 9  1  1)  "dort"))

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (shroom-mk gave-quest? finished-quest?) (list gave-quest? 
                                                      finished-quest?))
(define (shroom-gave-quest? shroom) (car shroom))
(define (shroom-quest-done? shroom) (cadr shroom))
(define (shroom-give-quest shroom) (set-car! shroom #t))
(define (shroom-set-quest-done! shroom) (set-car! (cdr shroom) #t))

;;----------------------------------------------------------------------------
;; Conv
;; 
;; Shroom is a female hedge-witch, who sells reagents and potions 
;; in Green Tower.  She was once a battle-maiden fighting for 
;; the forces of King Clovis in the Goblin Wars.
;;----------------------------------------------------------------------------

(define shroom-merch-msgs
  (list "Oui, je fais le commerce des champignons et autres. Passez à ma boutique dans le coin nord-est quand je suis ouvert."
        "Je sais où trouver les meilleurs dans la forêt."
        "Si vous avez quelque chose d'intéressant, cela m'intéressera peut-être."
        "J'ai des champignons et d'autres reactifs à échanger. Souhaitez-vous acheter ou vendre ?"
        "Faites attention avec ça."
        "N'essayez pas de cueillir les votres. Les mauvais vous tueront !"
        "Revenez quand vous aurez plus à vendre."
        "Faites autant que bon vous semble."
        "C'était une petite affaire agréable."
        "Je vois. Vous préférez peut-être bavarder avec une vieille femme."
   ))

(define shroom-catalog
  (list
   (list sulphorous_ash (*  2 reagent-price-mult) "Je dois me rendre loin dans les collines pour trouver ces mottes nauséabondes.")
   (list garlic         (*  3 reagent-price-mult) "Cela vient de mon propre jardin. Le cuisinier de Bole adore mon ail.")
   (list ginseng        (*  3 reagent-price-mult) "Les gens de la forêt m'ont montré où cueillir le ginseng sauvage.")
   (list blood_moss     (*  4 reagent-price-mult) "La mousse sanguine rare pousse sur le bois mort dans la forêt profonde.")
   (list spider_silk    (*  5 reagent-price-mult) "La soie d'araignée est assez répandue, mais il est dangereux de la recueillir.")
   (list nightshade     (* 10 reagent-price-mult) "Je dois chercher près des rivières du sud pour trouver la mortelle Ombre Nocturne.")
   (list mandrake       (*  8 reagent-price-mult) "La racine de mandragore pousse à l'état sauvage dans ces bois, mais peu savent où la trouver !")
   
   (list t_heal_potion  20 "Le plus dangereux, ce sont les bois. Prenez-en quelques uns au cas où vous auriez un accident.")
   (list t_mana_potion  20 "Quelques unes me suffiront pour que je jete un sort de lumière sur le chemin du retour après une longue journée de cueillette.")
   (list t_cure_potion  20 "Si vous êtes assez négligent pour être empoisonné, ceci vous guerira.")
   (list t_poison_immunity_potion 20 "J'en bois toujours un avant de chercher des reactifs dans les marais empoisonnés.")
   (list t_slime_vial   20 "Les aventuriers paresseux aiment ça, alors je les transporte. A croire qu'il n'y a pas assez d'ectoplasmes dans le monde.")
   ))

;; Shroom's merchant procedure
(define (shroom-trade knpc kpc) (conv-trade knpc kpc "trade" shroom-merch-msgs shroom-catalog))

;; Shroom's mushroom quest
(define (shroom-wards knpc kpc)
  (let ((shroom (kobj-gob-data knpc)))
    (if (shroom-gave-quest? shroom)
        ;; gave quest
        (if (shroom-quest-done? shroom)
            ;; quest already done
            (say knpc "J'ai oublié tous les autres.")
            ;; quest NOT yet done
            (begin
              (say knpc "Apportez-moi les champignons et je vous apprendrai le sortilège de "
                   "protection du feu."
                   "Vous souvenez-vous de l'endroit où ils se trouvent ?")
              (if (kern-conv-get-yes-no? kpc)
                  (say knpc "Eh bien...")
                  (say knpc "[Soupir] Peut-être devriez-vous écrire ceci. "
                       "Quittez la ville et allez vers le sud, dans les montagnes, au bord de la mer. "
                       "Vous y trouverez l'entrée de la grotte."))))
        (begin
          (say knpc "À mon époque, j'ai connu beaucoup de sortilèges de protection. "
               "Vous voulez que je vous l'apprenne, n'est-ce pas ?")
          (if (kern-conv-get-yes-no? kpc)
              (begin
                (say knpc "Je connais un sortilège de protection qui rendra le feu inoffensif. "
                     "Mais peut-être pouvez-vous d'abord me rendre un petit service, oui ?")
                (if (kern-conv-get-yes-no? kpc)
                    (begin
                      (say knpc "Dans une grotte au sud pousse "
                           "un champignon violet. Apporte-m'en un. D'accord ?")
                      (if (kern-conv-get-yes-no? kpc)
                          (begin
                            (say knpc "Bien. Une colonie d'ectoplasmes infeste cette "
                                 "grotte, alors prenez beaucoup d'huile brûlante !")
                            (shroom-give-quest shroom))
                          (say knpc "Oui, vous avez peut-être peur.")))
                    (say knpc "On n'a rien sans rien, jeunot !")))
              (say knpc "Bien sûr, un guerrier habile tel que vous n'a "
                   "rien à apprendre d'une vieille sorcière telle que moi."))))))
                               
(define (shroom-hail knpc kpc)
  (let ((shroom (kobj-gob-data knpc)))
    (display "shroom: ")
    (display shroom)(newline)
    (if (shroom-gave-quest? shroom)
        ;; gave quest
        (if (shroom-quest-done? shroom)
            ;; quest done
            (say knpc "Bonjour à nouveau, Vagabond. Viens me rendre visite, moi je suis  "
               "Champignon.")
            ;; quest not done yet
            (if (in-inventory? kpc t_royal_cape)
                (begin
                  ;; player has shrooms
                  (say knpc "Ah, vous avez le champignon, c'est bien ce que j'ai demandé !")
                  (kern-obj-remove-from-inventory kpc t_royal_cape 1)
                  (shroom-set-quest-done! shroom)
                  (say knpc "Et maintenant, votre récompense. La technique de protection du feu s'appelle "
                       "In Flam Sanct, du premier cercle de Magie. Mélangez le champignon à cape royale, "
                       "la cendre sulfureuse et l'ail. Jetez-le sort sur vous-même ou sur un compagnon "
                       "et le feu ne fera pas de mal !"))
                ;; player does NOT have shrooms yet
                (say knpc "Toujours pas de champignon violet, je vois. Pas de précipitation, mon cher. "
                      "Mais j'en voudrais avant de mourir.")))
        ;; has NOT given quest yet
        (say knpc "Bonjour et bienvenue."))))

(define (shroom-thie knpc kpc)
  (say knpc "Je n'ai vu aucune personne etrange par ici."))

(define (shroom-roya knpc kpc)
  (say knpc "Savez-vous à quoi sert le champignon à cape royale ?")
  (if (yes? kpc)
      (say knpc "Il est très rare, mais on le trouve souvent avec des ectoplasmes jaunes.")
      (say knpc "Il est utilisé dans les sortilèges pour absorber les effets !")))

(define (shroom-band knpc kpc)
  (say knpc "Des bandits ? Oui, une vieille femme doit être prudente dans les bois."))

(define shroom-conv
  (ifc basic-conv
       ;; default if the only "keyword" which may (indeed must!) be longer than
       ;; 4 characters. The 4-char limit arises from the kernel's practice of
       ;; truncating all player queries to the first four characters. Default,
       ;; on the other hand, is a feature of the ifc mechanism (see ifc.scm).
       (method 'default (lambda (knpc kpc) (say knpc "Il y a longtemps, j'aurais pu "
                                                "connaître ce sujet.")))
       (method 'bonj shroom-hail )
	   (method 'hail shroom-hail )
	   
       (method 'adie (lambda (knpc kpc) (say knpc "À bientôt !")))
       (method 'trav (lambda (knpc kpc) (say knpc "Je vends des potions, des reactifs "
                                            "et autres.")))
       (method 'nom (lambda (knpc kpc) (say knpc "On m'appelle Champignon. A "
                                                "votre service.")))
       (method 'cape shroom-roya )
       (method 'roya shroom-roya )
       (method 'cham (lambda (knpc kpc) (say knpc "Les champignons sont ma "
                                                "spécialité. C'est pourquoi tous "
                                                "m'appellent Champignon.")))
       (method 'fill (lambda (knpc) (say knpc "[elle sourit avec des "
                                           "dents tordues] Il est difficile de croire que "
                                           "j'était autrefois une jeune fille de guerre loyale ? [elle "
                                           "ricane de façon obscène]")))
       
       (method 'ache (lambda (knpc kpc) (conv-trade knpc kpc "buy" shroom-merch-msgs shroom-catalog)))
       (method 'comm shroom-trade )
       (method 'vend (lambda (knpc kpc) (conv-trade knpc kpc "sell" shroom-merch-msgs shroom-catalog)))
       (method 'reac shroom-trade )
       (method 'poti shroom-trade )
       (method 'join (lambda (knpc) (say knpc "Hélas, vous êtes trop jeune pour moi, "
                                         "mon Cher!")))
       (method 'gen (lambda (knpc) (say knpc "Oui, un beau jeune homme qu'il "
                                        "était autrefois. Il pouvait rester éveillé toute la nuit"
                                        " au lit ! Mais il est devenu un peu etrange, il "
                                        "s'est lié d'amitié avec les gobelins et tout "
                                        "le reste.")))
       (method 'etra (lambda (knpc) (say knpc "Il les a rencontré dans la forêt "
                                            "et court avec ses chasseurs. "
                                            "Il est presque à moitié gobelin ; "
                                            "il a appris leurs manières. Mais "
                                            "vous ne pourrez jamais lui dire ce qu'il faut faire "
                                            "à cet homme stupide.")))
       (method 'gobe (lambda (knpc) (say knpc "Je fais du commerce avec eux de temps en "
                                            "temps. Leurs sorciers connaissent bien "
                                            "les plantes de ces bois. "
                                            "Je leur parle même un peu. Je connait un peu "
                                            "de leur magie. Mais je ne leur fait "
                                            "jamais confiance.")))
       (method 'vole shroom-thie )
       (method 'conf (lambda (knpc) (say knpc "Les gobelins se retournent contre nous "
                                          "quand l'occasion se présente. "
                                          "Je ferais de même à leur "
                                          "place!")))
       (method 'guer (lambda (knpc) (say knpc "Ha ! Oui, j'ai combattu les gobelins. "
                                         "C'était il y a longtemps. Les gens ont oublié.")))
       (method 'prot shroom-wards )
       (method 'band shroom-band )
       ))

;;----------------------------------------------------------------------------
;; First-time constructor
;;----------------------------------------------------------------------------
(define (mk-shroom tag)
  (bind 
   (kern-mk-char tag                 ; tag
                 "Champignon"            ; name
                 sp_human            ; species
                 nil                 ; occ
                 s_companion_druid   ; sprite
                 faction-men         ; starting alignment
                 1 6 1               ; str/int/dex
                 0 0                 ; hp mod/mult
                 0 0                 ; mp mod/mult
                 max-health -1 max-health 0 3  ; hp/xp/mp/AP_per_turn/lvl
                 #f                  ; dead
                 'shroom-conv        ; conv
                 sch_shroom          ; sched
                 'townsman-ai                 ; special ai
                 (mk-inventory (list (list 1 t_sword)))                 ; container
                 (list t_armor_leather)                 ; readied
                 )
   (shroom-mk #f #f)))
