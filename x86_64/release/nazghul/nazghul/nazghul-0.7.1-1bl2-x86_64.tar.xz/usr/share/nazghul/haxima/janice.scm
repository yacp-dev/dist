;;----------------------------------------------------------------------------
;; Janice
;;
;; Initially Commander Jeffries's assistant, she will be elected to replace
;; him after the trial.
;;----------------------------------------------------------------------------

;;----------------------------------------------------------------------------
;; Schedule
;;----------------------------------------------------------------------------
(kern-mk-sched 'sch_jan
               (list 0  0  gjan-bed    "dort")
               (list 6  0  gc-hall     "travaille")
               (list 7  0  ghg-s6      "mange")
               (list 8  0  gc-hall     "travaille")
               (list 11 0  ghg-s3      "mange")
               (list 12 0  gc-hall     "travaille")
               (list 17 0  ghg-s3      "mange")
               (list 18 0  g-fountain  "suis en pause")
               (list 20 0  gjan-bed    "dort")
               )

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (jan-mk) (list 'townsman))

;;----------------------------------------------------------------------------
;; Conv
;;----------------------------------------------------------------------------

;; Basics...
(define (jan-hail knpc kpc)
  (say knpc "Salut, Vagabond.")
  )

(define (jan-name knpc kpc)
  (if (player-stewardess-trial-done?)
      (say knpc "Je suis le Commandant Janice.")
      (say knpc "Je m'appelle Janice.")
      ))

(define (jan-job knpc kpc)
  (if (player-stewardess-trial-done?)
      (say knpc "Je commande la milice de Glasdrin.")
      (say knpc "Je suis conseillère stratégique auprès du Commandant Jeffries.")
      ))

;; Special
(define (jan-comm knpc kpc)
  (if (player-stewardess-trial-done?)
      (say knpc "J'ai été élue pour remplacer Jeffries, l'ancien Commandant.")
      (say knpc "Le commandant Jeffries est un dirigeant compétent.")
      ))

(define (jan-repl knpc kpc)
  (if (player-stewardess-trial-done?)
      (say knpc "Il est dommage que sa longue histoire de bons et loyaux services à Glasdrin se termine dans un tel déshonneur.")
      (say knpc "Pourquoi, quoi que vous vouliez dire ?")
      ))

(define (jan-mili knpc kpc)
  (say knpc "La milice de Glasdrin est actuellement engagée dans Kurpolis et les patrouilles frontalières. "
       "Nous ne menons pas activement de guerre."))

(define (jan-bord knpc kpc)
  (say knpc "Bien que nous soyons actuellement en paix avec Trigrave et la Tour Verte, nous ne devons jamais relâcher notre vigilance.")
  )

;; Townspeople...

(define jan-conv
  (ifc glasdrin-conv

       ;; basics
       (method 'bonj jan-hail )
	   (method 'hail jan-hail )
	   
       (method 'trav jan-job )
       (method 'nom jan-name )

       (method 'comm jan-comm )
       (method 'jeff jan-comm )
       (method 'mili jan-mili )
       (method 'remp jan-repl )
       (method 'fron jan-bord )
       ))

(define (mk-janice)
  (bind 
   (kern-mk-char 'ch_janice       ; tag
                 "Janice"          ; name
                 sp_human            ; species
                 oc_warrior          ; occ
                 s_cloaked_female ; sprite
                 faction-glasdrin         ; starting alignment
                 2 1 1               ; str/int/dex
                 0 0                 ; hp mod/mult
                 0 0                 ; mp mod/mult
                 max-health -1 max-health 0 5  ; hp/xp/mp/AP_per_turn/lvl
                 #f                  ; dead
                 'jan-conv         ; conv
                 sch_jan           ; sched
                 'townsman-ai                 ; special ai
                 nil                 ; container
                 (list t_armor_chain
                       t_chain_coif
                       t_sword
                       ))         ; readied
   (jan-mk)))
