;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------
(define tooth-lvl 2)
(define tooth-species sp_rat)
(define tooth-occ oc_wrogue)

;;----------------------------------------------------------------------------
;; Schedule
;; 
;; In the monster village of Kun.
;;----------------------------------------------------------------------------
(kern-mk-sched 'sch_tooth
               (list 0 0 campfire-4 "dort")
               (list 6 0 black-market-counter "travaille")
               (list 19 0 cantina-12 "suis en pause")
               )

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (tooth-mk) nil)

;;----------------------------------------------------------------------------
;; Conv
;; 
;; Tooth is a nervous ratling, running a black market and pawn shop 
;; in the monster village of Kun.  It appears that he is suffering from 
;; the surplus (or lack) of some stimulant.
;;----------------------------------------------------------------------------

;; Basics...
(define (tooth-hail knpc kpc)
  (kern-log-msg "Vous rencontrez un vieux rat sournois avec une énorme incisive. Il tremble et frissonne nerveusement. "
                "Trop de caféine ? Elimination du lotus noir ? Vous n'êtes pas certain.")
  (say knpc "Psst. Vous cherchez un bon plan ? J'ai plein de bons plans. Toutes sortes de bons plans ! Des bons ! Des mauvais plans ! "
       "Vous le dites, vous le faites, c'est à vous de décider ! Pas de questions. Pas de réponses.")
  )

(define (tooth-default knpc kpc)
  (say knpc "Je ne sais pas. Je ne sais pas. Des informations ? Ce n'est pas mon jeu.")
  )

(define (tooth-name knpc kpc)
  (say knpc "Moi c'est Dent. Je suis connu ! Très respecté. Mes clients m'aiment. "
       "Ils reviennent toujours. Parler de moi à leurs amis ? Pas question ! "
       "Les affaires sont trop bonnes. Ils le gardent pour eux. Je suis un secret bien gardé ! Un secret bien connu !")
  )

(define (tooth-join knpc kpc)
  (say knpc "Je peux pas, mon pote. J'ai mon magasin à faire tourner. Des factures à payer. Gardes à esquiver. Trop occupé ! Il faut de l'action !")
  )

(define (tooth-job knpc kpc)
  (say knpc "Des marchés ! Marché conclu ! Marché ! Marché ! Marché ! Faisons en un. Tout de suite. "
       "Ici même. Allons-y. Prêts ? C'est parti.")
  (tooth-trade knpc kpc)
  )

(define (tooth-bye knpc kpc)
  (say knpc "Quoi ?? Vous partez déjà ? J'ai d'autres affaires ! Beaucoup d'autres choses ! "
       "De bonnes choses ! Mais ça ne restera pas ! Non ! Ça s'envole des étagères ! Partez à vos risques et périls... !"
       "[Il continue de cette façon alors que vous vous éloignez]")
  )

(define tooth-merch-msgs
  (list nil ;; closed
        "Regardez ici, regardez cette merveilleuse chose ! Toute la qualité ! Rare, précieux, difficile à trouver !" ;; buy
        "Vous avez des trucs ? Je les prends. Où l'as-tu trouvé ? Je ne veux pas le savoir." ;; sell
        "Tout à un prix raisonnable ! De quelle manière j'arrive à continuer mes affaires ? Je ne sais pas ! Voyez par vous-même !" ;; trade
        "Quoi ?? C'est tout ? J'en ai d'autres !" ;; sold-something
        "Hé attendez ! Où allez-vous ? Revenez, regardez encore ! Vous avez vu ma collection de parchemins ?" ;; sold-nothing
        "Revenez quand vous en aurez plus ! Je suis toujours en train de chercher !" ;; bought-something
        "J'ai besoin de bonnes choses ! Des trucs magiques, des pierres précieuses, des artefacts !" ;; bought-nothing
        "N'oubliez pas l'essentiel ! Huile, pierres précieuses, pioches !" ;; traded-something
        "Attendez ! Où allez-vous ? Revenez, regardez encore ! Vous avez vu ma collection de parchemins ?" ;; traded-nothing
        ))

(define tooth-catalog
  (list
   (list t_picklock            5 "Déverrouiller les portes ! Il faut un peu d'habileté !")
   (list t_gem                20 "Trouver des salles et des passages cachés ! Les voleurs les adorent !")
   (list t_grease             25 "Vous êtes coincé ?? La graisse est le mot qui sauve !")

   (list t_oil                 5 "Parfait pour combattre les ectoplasmes !")
   (list t_slime_vial         30 "C'est 'Kal Xen Nox' dans une bouteille ! Idéal pour échapper aux gardes !")
   (list t_arrow               3 "Il faut avoir beaucoup de flèches !")
   (list t_bolt                3 "On ne peut pas avoir trop de carreaux!")
   (list t_smoke_bomb          4 "Ca permet de faire une évasion propre en restant sous couvert!")

   (list t_spiked_helm       300 "Utilisez votre tête dans un combat !")
   (list t_spiked_shield     300 "Un objet rare ! Pour les combattants agressifs !")

   (list t_dagger_4           (* 4 65) "Très bien ! Petit, facile à dissimuler, mais avec un tranchant féroce !")
   (list t_sword_2            (* 2 85) "Mieux que l'épée moyenne ! Regardez ce tranchant !")
   (list t_sword_4            (* 4 85) "La meilleure ! La meilleure ! Une arme pour le véritable artiste de la mort !")
   (list t_morning_star_2     (* 2 105) "Une arme vraiment géniale ! Semez le bordel à des équipes de combat entières !")

   (list t_leather_helm_2     (* 2 100) "Pour le malfrat qui a besoin de cette petite protection supplémentaire !")
   (list t_chain_coif_4       (* 4 100) "Vous voyez ce tissage serré ? Le renfort à bandes ? il fait dévier n'importe quelle lame et adoucit le coup !")
   (list t_iron_helm_4        (* 4 150) "Très rare ! Les coups sur la tête ressembleront à des coups d'oreillers !")

   (list t_armor_leather_2    (* 2 150) "Voler des armes aux Géants?, des bijoux aux trolls? Il vous faut quelque chose de léger et efficace telle que cette armure de cuir!")
   (list t_armor_leather_4    (* 4 150) "Cela a appartenu à un vieux schnock ! Il est mort de vieillesse sur un lit de pièces d'or ! Maintenant, si vous la voulez aussi !")
   (list t_armor_chain_4      (* 4 330) "C'est parfait pour le bagarreur qui aime être dans le feu de l'action sans être ralenti !")
   (list t_armor_plate_4      (* 4 660) "Élimine les coups des Géants et des trolls dans cette incroyable armure en plaques! Il n'y a rien de comparable ailleurs!")

   (list t_xen_corp_scroll    (* 7 base-scroll-cost) "Le favori de l'assassin ! Tue instantanément !")
   (list t_sanct_lor_scroll   (* 7 base-scroll-cost) "Le favori du voyou ! Parfait pour entrer et sortir en douce !")
   (list t_an_xen_ex_scroll   (* 6 base-scroll-cost) "Si vous ne pouvez pas les battre, faites-les se joindre à vous avec ce sort de charme !")
   (list t_in_ex_por_scroll   (* 4 base-scroll-cost) "Les portes magiques ne vous arrêteront pas si vous en transportez beaucoup !")
   (list t_wis_quas_scroll    (* 4 base-scroll-cost) "Parfait pour trouver des portes cachées (et des ennemis invisibles) !")
   (list t_in_quas_xen_scroll (* 7 base-scroll-cost) "Vous avez toujours souhaité être deux ? Avec ce parchemin, c'est possible !")
   (list t_an_tym_scroll      (* 8 base-scroll-cost) "Car lorsque vous aurez vraiment des ennuis, ce parchemin arrêtera le temps et vous permettra de vous en sortir !")
   ))

(define (tooth-trade knpc kpc) (conv-trade knpc kpc "trade" tooth-merch-msgs tooth-catalog))
(define (tooth-buy   knpc kpc) (conv-trade knpc kpc "buy"   tooth-merch-msgs tooth-catalog))
(define (tooth-sell  knpc kpc) (conv-trade knpc kpc "sell"  tooth-merch-msgs tooth-catalog))

(define tooth-conv
  (ifc nil

       ;; basics
       (method 'default tooth-default )
       (method 'bonj tooth-hail )
	   (method 'hail tooth-hail )
	   
       (method 'adie tooth-bye )
       (method 'trav tooth-job )
       (method 'nom tooth-name )
       (method 'join tooth-join )

       (method 'comm tooth-trade )
       (method 'ache tooth-buy )
       (method 'vend tooth-sell )
       (method 'plan tooth-trade )
       ))

(define (mk-tooth)
  (bind 
   (kern-mk-char 
    'ch_tooth           ; tag
    "Dent"             ; name
    tooth-species         ; species
    tooth-occ              ; occ
    s_rat     ; sprite
    faction-men      ; starting alignment
    0 4 1            ; str/int/dex
    0  ; hp bonus
    0 ; hp per-level bonus
    0 ; mp off
    1 ; mp gain
    max-health ; hp
    -1                  ; xp
    max-health ; mp
    0
    tooth-lvl
    #f               ; dead
    'tooth-conv         ; conv
    sch_tooth           ; sched
    'townsman-ai              ; special ai
    nil
    nil              ; readied
    )
   (tooth-mk)))
