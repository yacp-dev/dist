;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------
(define amy-lvl 1)
(define amy-species sp_human)
(define amy-occ oc_wright)

;;----------------------------------------------------------------------------
;; Schedule
;; 
;; In the Poor House (at least until such time as she joins the Wanderer).
;;----------------------------------------------------------------------------
(define amy-bed poorh-bed2)
(define amy-mealplace poorh-sup2)
(define amy-workplace poorh-pasture)
(define amy-leisureplace poorh-dining)
(kern-mk-sched 'sch_amy
               (list 0  0 amy-bed          "dort")
               (list 7  0 amy-mealplace    "mange")
               (list 8  0 amy-workplace    "travaille")
               (list 12 0 amy-mealplace    "mange")
               (list 13 0 amy-workplace    "travaille")
               (list 18 0 amy-mealplace    "mange")
               (list 19 0 amy-leisureplace "suis en pause")
               (list 22 0 amy-bed          "dort")
               )

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (amy-mk) nil)

;;----------------------------------------------------------------------------
;; Conv
;; 
;; Amy is a female tinker, fallen upon hard times.
;; She currently dwells in the Poor House.
;; Amy is a potential party member.
;;----------------------------------------------------------------------------

;; Basics...
(define (amy-hail knpc kpc)
  (meet "Vous rencontrez une femme artisan qui a l'air pratique.")
  (say knpc "Salut.")
  )

(define (amy-name knpc kpc)
  (say knpc "Tu peux m'appeler Amy.")
  )

(define (amy-join knpc kpc)
  (if (is-player-party-member? knpc)
      (say knpc "Je t'ai déjà rejoint !")
      (begin
        (say knpc "Je pensais que tu ne le demanderai jamais !")
        (join-player knpc)
        (kern-conv-end)
        )))

(define (amy-job knpc kpc)
  (say knpc "Eh bien, je suis artisan de métier, "
       "mais je n'ai pas eu beaucoup de chance de trouver du travail ces derniers temps.")
  )

(define (amy-bye knpc kpc)
  (say knpc "Adieu.")
  )

(define (amy-mean knpc kpc)
  (say knpc "Il est génial. "
       "Je ne sais pas où j'irais si ce n'était pas pour le foyer des pauvres. "
       "Il ne regarde même pas beaucoup mes nichons.")
  )

(define (amy-tink knpc kpc)
  (say knpc "Un artisan est un travailleur errant. "
       "Nous voyageons de ville en ville, pour réparer les objets des gens.")
  )

(define (amy-luck knpc kpc)
  (say knpc "Les gens sont maintenant nerveux face aux étrangers, "
       "avec les Maudits et tout le reste.")
  )
  
(define (amy-accu knpc kpc)
  (say knpc "Les Maudits sont une secte secrète qui "
       "suivent des voies mauvaises.")
  )

;; Quest-related

(define amy-conv
  (ifc basic-conv

       ;; basics
       (method 'bonj amy-hail )
	   (method 'hail amy-hail )
	   
       (method 'adie amy-bye )
       (method 'trav amy-job )
       (method 'nom amy-name )
       (method 'join amy-join )
       

       (method 'mean amy-mean )
       (method 'arti amy-tink )
       (method 'chan amy-luck )
       (method 'maud amy-accu )
       ))

(define (mk-amy)
  (bind 
   (kern-mk-char 
    'ch_amy           ; tag
    "Amy"             ; name
    amy-species         ; species
    amy-occ              ; occ
    s_companion_tinker ; sprite
    faction-men      ; starting alignment
    2 4 4            ; str/int/dex
    pc-hp-off  ; hp bonus
    pc-hp-gain ; hp per-level bonus
    1 ; mp off
    1 ; mp gain
    max-health ; hp
    -1                   ; xp
    max-health ; mp
    0
    amy-lvl
    #f               ; dead
    'amy-conv         ; conv
    sch_amy           ; sched
    'townsman-ai              ; special ai
    nil              ; container
    (list
     t_armor_leather
     t_leather_helm
     t_sling
     t_sword
    ))
   (amy-mk)))
