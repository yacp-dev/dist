;;----------------------------------------------------------------------------
;; Sched
;; 
;; In Green Tower.
;;----------------------------------------------------------------------------
(define (mk-zone x y w h) (list 'p_green_tower x y w h))
(kern-mk-sched 'sch_deric
               (list 0  0 (mk-zone 17  4  1   1)  "dort")
               (list 6  0 (mk-zone 30 30  5   5)  "travaille")
               (list 12  0 (mk-zone 52 54  1   1)  "mange")
               (list 13  0 (mk-zone 30 30  5   5)  "travaille")
               (list 18  0 (mk-zone 52 54  1   1)  "mange")
               (list 19  0 (mk-zone 30 30  5   5)  "travaille")
               (list 21  0 (mk-zone 13  2  4   4)  "suis en pause")
               (list 22  0 (mk-zone 17  4  1   1)  "dort")
               )

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (deric-mk tell-secret?) (list tell-secret? (mk-quest)))
(define (deric-tell-secret? deric) (car deric))
(define (deric-set-tell-secret! deric) (set-car! deric #t))
(define (deric-bandit-quest deric) (cadr deric))

;;----------------------------------------------------------------------------
;; Conv
;; 
;; Deric is a Captain of the Rangers in Green Tower.
;;----------------------------------------------------------------------------

(define (deric-name knpc kpc)
  (say knpc "Je suis le capitaine Deric, commandant des Rangers, à votre service."))

(define (deric-job knpc kpc)
  (say knpc "Je commande les Rangers, bien que j'aspire à de plus grandes choses. "
       "Je pense que j'ai fait mes preuves en tant que leader, mais ici "
       "vous devez attendre la mort de quelqu'un avant d'avoir une promotion !"))

(define (deric-health knpc kpc)
  (say knpc "Je suis la définition même de la bonne santé !"))

(define (deric-rangers knpc kpc)
  (say knpc "Alors voilà. Les Rangers sont chargés de maintenir la paix dans "
       "la Grande Forêt. Nous appliquons la loi, nous surveillons les gobelins, "
       " Nous sommes également chargés de l'entretien de la forêt et  "
       "garder les routes d'entrée et de sortie dégagées. Si je puis dire, nous avons fait "
       "un travail incroyable sous ma direction. Grâce au travail acharné de mes "
       "hommes, bien sûr. Hummm..."))

(define (deric-two knpc kpc)
  (say knpc "Le niveau supérieur de la tour est principalement constitué de fortifications. Le niveau inférieur "
       "est l'endroit où se trouvent la salle du conseil, la caserne, la cuisine et les autres "
       "installations. Nous avons également une prison là-bas. Certains pensent que le "
       "le niveau inférieur est hanté."))

(define (deric-haunted knpc kpc)
  (say knpc "Ils disent que le niveau inférieur est hanté, et pour ma part, j'ai entendu "
       "des bruits étranges. On dirait qu'ils viennent des profondeurs des murs "
       " - des chants, ou des cris. Mais je n'ai jamais vu de fantômes. "
       "Et bien sûr, je n'ai pas peur de ces choses-là !"))

(define (deric-gen knpc kpc)
  (say knpc "Un vieux type splendide, bien qu'un peu idiot. C'est une légende parmi les "
       "Rangers pour ses efforts pendant la guerre des Gobelins, et l'un des derniers "
       "survivants vétérans. Il semble toujours être en bonne forme physique, mais "
       "il est devenu un peu indigène, si vous voyez ce que je veux dire."))

(define (deric-native knpc kpc)
  (say knpc "Oui, il a adopté certaines des habitudes des habitants des Bois - la "
       "forêts des gobelins. Mais je ne le soupçonne pas de conspirer contre nous - "
       "si je le faisais, je le dénoncerais et j'obtiendrais peut-être une promotion ! Mais hélas, "
       "Ce n'est pas le cas."))

(define (deric-shroom knpc kpc)
  (say knpc "Ah! Champignon, une bonne vieille chouette. Un peu sorcière, mais pas de problème. Elle tient "
       "un magasin de réactifs dans le coin nord-est de la ville."))

(define (deric-abe knpc kpc)
  (say knpc "Un jeune homme bizarre. Aussi bizarre qu'étrange, tu sais, "
       "pas cet autre ... enfin, peut-être ... c'est difficile à dire. Quoi qu'il en soit, il étudie les "
       "des ruines dans le coin sud-ouest. Il Travaille pour la Bibliothèque royale ou pour "
       "d'autres."))


(define (deric-tower knpc kpc)
  (say knpc "Oui, la Tour elle-même qui donne son nom à la Tour verte est "
       "située au centre de la ville. Il s'agit de mon poste de commandement et de mon quartier général "
       "pour les Rangers. Un bâtiment fascinant ! Saviez-vous qu'il est construit sur "
       "les ruines d'une ancienne tour ?")
  (if (kern-conv-get-yes-no? kpc)
      (say knpc "Intéressant, non ? Non pas que je sois un expert en la matière. "
           "Il faudrait parler avec le vieux Abe, ou peut-être Champignon, pour en  "
           "apprendre un peu plus.")
      (say knpc "C'est vrai ! Ce qui est aujourd'hui la Tour n'était autrefois que "
           "la flèche centrale d'une très grande structure qui atteignait beaucoup plus haut ! Et "
           "beaucoup plus basse également, si l'on en croit le jeune Abe. Actuellement "
           "il n'y a que deux histoires.")))

(define (deric-ambition knpc kpc)
  (say knpc "Oui, je suis assez ambitieux et je n'ai pas peur de l'admettre ! Inutile "
       "de se faufiler quand on est ambitieux, cela ne fait que rendre les personnes nerveuses. "
       "Je ne ferais rien d'immoral pour faire avancer ma position, bien sûr, "
       "Je crois trop fermement aux principes de notre grande société. "
       " Est-ce que vous avez des ambitions ?")
  (if (kern-conv-get-yes-no? kpc)
      (begin
        (say knpc "Eh bien, assez parlé de vous ! J'espère être un jour un Seigneur. "
             "Pensez-vous que j'ai une chance ?")
        (if (kern-conv-get-yes-no? kpc)
            (begin
              (say knpc "Je le savais ! Vous savez, je n'étais pas sûr de pouvoir vous faire confiance, "
                   "mais vous êtes manifestement une personne perspicace, alors je vais "
                   "vous faire part d'un secret.")
              (deric-set-tell-secret! (kobj-gob-data knpc)))
            (say knpc "[Rigole] Je suis désolé si je ne suis pas d'accord ! Les personnes "
                 "du destin ne sont jamais appréciées par leurs semblables.")))
      (say knpc "[Soupirs] Tant de personnes mènent des vies inutiles et gâchées. Je suis heureux "
           "de ne pas être l'un d'entre eux !")))

(define (deric-secret knpc kpc)
  (if (deric-tell-secret? (kobj-gob-data knpc))
      (say knpc "Dans le niveau inférieur de la Tour, il y a un passage caché. "
           "Descendez l'échelle et entrez dans la salle de ravitaillement sud-est. "
           "Sur le mur à l'est se trouve une porte secrète ! "
           "Je n'ai aucune idée de ce à quoi elle servait.")
      (say knpc "Rien que je ne veuille dire à un étranger tel que vous !")))

(define (deric-afraid knpc kpc)
  (say knpc "Bien sûr que non ! La peur est le hobgobelin des petits esprits. "
       "Ou est-ce que les hobgobelins sont la peur des petits esprits? "
       "Bon sang!, je ne me souviendrai jamais de cette phrase idiote."))

(define (deric-prison knpc kpc)
  (say knpc "Oui. Très sécurisées. Nous n'avons actuellement qu'un seul prisonnier, "
       "un gobelin des forêts que nous avons attrapé en train de roder par ici. "
       "Une brute à l'air assez vicieux, je dois dire. "
       "Non pas que j'aie peur de lui. Hummm..."))

(define (deric-gobl knpc kpc)
  (say knpc "Les sournois ! L'autre jour, j'en ai attrapé un ici en ville et je l'ai fait jeter en prison."))

(define (deric-brute knpc kpc)
  (say knpc "Très suspect. Il n'est évidemment pas venu pour faire du commerce, "
       "car il ne transportait aucune marchandise. Et il ne parle pas un mot du langage habituel. "
       "En fait, il refuse de dire quoi que ce soit ! Eh bien, quelque temps passé "
       "sous terre devrait délier sa langue. Je découvrirai "
       "ce qu'il complote."))

(define (deric-default knpc kpc)
  (say knpc "Vous devriez demander aux autres sur cela !"))

;; Scan the player party looking for mercs
                         

(define (deric-hail knpc kpc)

  (define (get-ranger-merc)
    (let ((mercs (filter (lambda (kchar)
                           (kbeing-is-npc-type? kchar 'ranger))
                         (kern-party-get-members (kern-get-player)))))
      (cond ((null? mercs) nil)
            (else
           (car mercs)))))

  (define (rm-ranger-merc)
    (let ((kmerc (get-ranger-merc)))
      (if (not (null? kmerc))
          (begin
            (prompt-for-key)
            (say knpc "Je vais devoir réassigner ce ranger à une patrouille.")
            (kern-char-leave-player kmerc)
            ))))

  (cond ((in-player-party? 'ch_nate)
         (say knpc "Je vois que vous avez appréhendé le chef des bandits ! "
              "Livrez le en bas au geôlier et je vous donnerai "
              "la récompense.")
         (rm-ranger-merc)
         (quest-data-update-with 'questentry-bandits 'captured-nate-and-talked-to-deric 1 (quest-notify nil))
         )        
        ((has? kpc t_prisoner_receipt 1)
         (say knpc "Mettre ce bandit derrière les barreaux fera très bonne impression sur "
              "mes dossiers ! Voici votre récompense.")
         (give-player-gold 100)
         (kern-char-add-experience kpc 64)
         (take kpc t_prisoner_receipt 1)
         (quest-done! (deric-bandit-quest (kobj-gob-data knpc)) #t)
         (rm-ranger-merc)
         (quest-data-update-with 'questentry-bandits 'done 1 (grant-party-xp-fn 30))
         (quest-data-complete 'questentry-bandits)
         )
        (else
         (say knpc "Enchanté, en effet !")
         )))

(define (deric-bye knpc kpc)
  (say knpc "Jusqu'à la prochaine fois"))

(define (deric-thie knpc kpc)
  (say knpc "Hmmm. La brute gobelin que nous avons enfermée en bas est peut-être un voleur. Mais "
       "il est dans notre prison depuis un certain temps. Nos rangers ont signalé "
       "un homme seul voyageant vers le nord et qui passe par la forêt, mais nous ne savons pas  "
       "d'où il vient. La seule chose au nord est Bole.")
       (quest-data-update 'questentry-thiefrune 'tower 1)
       (quest-data-update-with 'questentry-thiefrune 'bole 1 (quest-notify (grant-party-xp-fn 10)))
       )

(define (deric-accu knpc kpc)
  (say knpc "Je vous assure, mon brave homme, qu'il n'y a pas de Maudits par ici."))


(define (deric-band knpc kpc)
  (let ((quest (deric-bandit-quest (kobj-gob-data knpc))))
    (cond ((quest-done? quest) 
           (say knpc "Je ne m'attends pas à plus d'ennuis de la part des bandits "
                "depuis que j'ai fait appréhender leur chef. "
                "Par vous, bien sûr. "
                "Mais je l'ai fait faire. "
                "Hummm.."))
          ((quest-accepted? quest)
           (say knpc "Les bandits ont une cachette dans un endroit situé dans ces "
                "bois.  Continuez à chercher ! Et amenez-moi leur chef "
                "de retour en vie.")
           )
          (else
           (say knpc "Vous avez donc entendu parler de notre problème de bandits. "
                "Oui, ils ont une cachette secrète dans un endroit situé dans ces bois. "
                "Je les aurais débusqués il y a longtemps, "
                "mais je n'ai pas d'hommes en réserve. Vous comprenez. ")
           (prompt-for-key)
           (say knpc
                "Dites, vous avez l'air courageux. "
                "Si vous capturez le chef des bandits et que vous l'amenez ici, "
                "je vous récompenserai volontiers pour vos efforts. Qu'en dites-vous ?")
           (if (yes? kpc)
               (begin
                 (quest-accepted! quest #t)
                 (say knpc "Bien ! Vous aurez peut-être besoin d'aide. "
                      "[Il vous donne un parchemin]."
                      "Ces ordres affecteront temporairement un de mes Rangers "
                      "à vous. Il suffit de demander à l'un d'entre eux de se joindre à votre équipe.")
                 (give kpc t_ranger_orders 1)
                 (quest-data-update-with 'questentry-bandits 'talked-to-deric 1 (quest-notify nil))
                 )
               (say knpc "Vous ne gagnerez jamais une réputation de cette façon !")))
          )))
                       

(define deric-conv
  (ifc green-tower-conv
       (method 'abe deric-abe )
       (method 'peur deric-afraid )
       (method 'ambi deric-ambition )
       (method 'aspi deric-ambition )
       (method 'band deric-band )
       (method 'brut deric-brute )
       (method 'adie deric-bye )
       (method 'comm deric-rangers )
       (method 'default deric-default )
       (method 'mort deric-ambition )
       (method 'gen deric-gen )
       (method 'bonj deric-hail )
	   (method 'hail deric-hail )
	   
       (method 'hant deric-haunted )
       (method 'sant deric-health )
       (method 'trav deric-job )
       (method 'nom deric-name )
       (method 'indi deric-native )
       (method 'pris deric-prison )
       (method 'prom deric-ambition )
       (method 'rang deric-rangers )
       (method 'secr deric-secret )
       (method 'cham deric-shroom )
       (method 'rode deric-brute )
       (method 'hist deric-two )
       (method 'vole deric-thie )
       (method 'tour deric-tower )
       (method 'deux deric-two )
       (method 'gobe deric-gobl )
))                

(define (mk-deric tag)
  (bind 
   (kern-mk-char tag                 ; tag
                 "Deric"            ; name
                 sp_human            ; species
                 nil                 ; occ
                 s_ranger_captain   ; sprite
                 faction-men         ; starting alignment
                 1 3 2               ; str/int/dex
                 0 0                 ; hp mod/mult
                 0 0                 ; mp mod/mult
                 max-health -1 max-health 0 4  ; hp/xp/mp/AP_per_turn/lvl
                 #f                  ; dead
                 'deric-conv        ; conv
                 sch_deric          ; sched
                 'townsman-ai        ;; special ai
                 nil                 ; container
                 (list  t_sword_2
					         t_armor_leather_2
					         t_leather_helm_2
					         )                  ; readied
                 )
   (deric-mk #f)))
