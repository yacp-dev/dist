;; ----------------------------------------------------------------------------
;; Level 1 of the Thief's Ladder
;; ----------------------------------------------------------------------------
(mk-dungeon-room
 'p_traps_1 "les Énigmes dans l'obscurité"
 (list
  "rr rr rr rr rr rr rr xx xx xx xx xx xx xx xx xx xx rr rr "
  "rr rr rr xx xx xx xx xx ,, ,, ,, xx xx ,, ,, ,, xx rr rr "
  "rr rr rr xx ,, ,, ,, ,, ,, ,, ,, ,, x! ,, ,, ,, x! rr rr "
  "rr rr rr xx ,, ,, ,, ,, ,, ,, ,, ,, xx ,, ,, ,, xx rr rr "
  "rr rr xx xx ,, xx xx xx xx ,, xx xx xx xx ,, xx xx rr rr "
  "rr rr xx ,, ,, ,, xx xx ,, ,, ,, xx xx ,, ,, ,, xx rr rr "
  "rr rr xx ,, ,, ,, xx xx ,, ,, ,, xx xx ,, ,, ,, xx rr rr "
  "rr rr xx ,, ,, ,, xx xx ,, ,, ,, xx xx ,, ,, ,, xx rr rr "
  "rr rr xx ,, ,, ,, xx xx ,, ,, ,, xx xx ,, ,, ,, xx rr rr "
  "rr rr xx ,, ,, ,, xx xx ,, ,, ,, xx xx ,, ,, ,, xx rr rr "
  "rr rr xx ,, ,, ,, xx xx ,, ,, ,, xx xx ,, ,, ,, xx rr rr "
  "rr rr xx ,, ,, ,, xx xx ,, ,, ,, xx xx ,, ,, ,, xx rr rr "
  "rr rr xx ,, ,, ,, xx xx ,, ,, ,, xx xx ,, ,, ,, xx rr rr "
  "rr rr xx ,, ,, ,, xx xx ,, ,, ,, xx xx ,, ,, ,, xx rr rr "
  "rr rr xx xx ,, xx xx xx xx ,, xx xx xx xx ,, xx xx rr rr "
  "rr rr xx ,, ,, ,, xx ,, ,, ,, ,, ,, ,, ,, ,, xx rr rr rr "
  "rr rr x! ,, ,, ,, x! ,, ,, ,, ,, ,, ,, ,, ,, xx rr rr rr "
  "rr rr xx ,, ,, ,, xx xx ,, ,, ,, xx xx xx xx xx rr rr rr "
  "rr rr xx xx xx xx xx xx xx xx xx xx rr rr rr rr rr rr rr "
  )
 (put (mk-riddle 'egg 't_lava 3 5 3 9 #f
                 "Tous ceux qui veulent passer doivent répondre à l'énigme :\n\n"
                 "  Dans une salle de marbre blanc comme du lait\n"
                 " Doublée d'une peau douce comme de la soie\n"
                 "  Dans une fontaine limpide\n"
                 " Une pomme dorée apparaît\n"
                 "  Il n'y a pas de portes qui mènent à cette forteresse\n"
                 "  Pourtant, des voleurs s'introduisent pour voler son or.\n"
                 ) 4 14)
 (put (mk-riddle 'few 't_lava 8 5 3 9 #f
                 "Tous ceux qui veulent passer doivent répondre à l'énigme :\n\n"
                 "  Je connais un mot de trois lettres.\n"
                 "  Ajoutez deux, et il y en aura moins."
                 ) 9 4)
 (put (mk-riddle 'eye 't_lava 13 5 3 9 #f
                 "Tous ceux qui veulent passer doivent répondre à l'énigme :\n\n"
                 "  Prononcé comme une seule lettre,\n"
                 "  mais écrit avec trois.\n"
                 " Deux lettres sont présentes\n"
                 " et deux uniquement dans moi-même.\n"
                 "  Je suis deux, et tout seul\n"
                 "  et noir, bleu et gris.\n"
                 "  Quand on le lit par les deux bouts\n"
                 "  Je reste le même dans les deux cas."
                 ) 14 14)
 (put (mk-ladder-down 'p_traps_2 9 15) 14 2)
 (put (mk-ladder-up 'p_bole 43 6) 4 16)
 )

(mk-place-music p_traps_1 'ml-dungeon-town)

(kern-place-add-on-entry-hook p_traps_1 'quest-thiefrune-den1)
