;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------
(define tim-start-lvl 4)

;;----------------------------------------------------------------------------
;; Schedule
;; 
;; In the Tower of Brundegart (p_brundegardt_tower_4), locked outside.
;;----------------------------------------------------------------------------

;;----------------------------------------------------------------------------
;; Gob
;;
;; Quest flags, etc, go here.
;;----------------------------------------------------------------------------
(define (tim-mk) (list #f #f))
(define (tim-caught? gob) (car gob))
(define (tim-caught! gob) (set-car! gob #t))
(define (tim-met? gob) (cadr gob))
(define (tim-met! gob) (set-car! (cdr gob) #t))

;;----------------------------------------------------------------------------
;; Conv
;;
;; Tim is a maimed, drooling madman, currently trapped outside 
;; the Tower of Brundegart.
;; 
;; Once a seeker of knowledge (and power), 
;; his body was ravaged by griffins (and their hungry chicks), 
;; and his mind broken by contact with the EYE of Brundegart.
;; (One rather assumes the maiming did not help his mental state, 
;; for that matter...)
;;----------------------------------------------------------------------------
(define (tim-hail knpc kpc)
  (meet "Vous rencontrez un fou qui bave avec un seul bras.")
  (say knpc "J'ai vu l' oeil !"))

(define (tim-eye knpc kpc)
  (say knpc "Je suis si sage maintenant, à cause de l' oeil. Seriez-vous sage ?")
  (cond ((yes? knpc)
         (say knpc "Hélas, mon ami, j'ai perdu la cle !"))
        (else
         (say knpc "Idiot !")
         (kern-conv-end))))

(define (tim-key knpc kpc)
  (say knpc "C'était ma cle ! Je l'ai trouvée sur le mort. "
       "D'abord, ils ont pris mon bras, puis les oiseaux-lions ont pris ma cle !"))

(define (tim-arm knpc kpc)
  (say knpc "Ils m'ont choisi alors que je marchais parmi les collines, "
       "et m'a amené ici pour nourrir leurs petits."))

(define (tim-name knpc kpc)
  (say knpc "Ne faites pas semblant de ne pas me connaître ! "
       "Celui qui est sage est forcément célèbre ! C'est logique !"))

(define (tim-job knpc kpc)
  (say knpc "Je vais apporter la lumière au monde !"))

(define (tim-enli knpc kpc)
  (say knpc "Oui ! L' oeil ! L' oeil... [Il se recroqueville en boule comme un nouveau né et sanglote]")
  (kern-conv-end))

(define (tim-lion knpc kpc)
  (say knpc "[Il crie et se lâche] Vous les voyez ? ! "
       "Sont-ils venus pour mon autre bras ?  Les poussins ont tellement faim ! C'est si cruel !"))

(define tim-conv
  (ifc nil
       (method 'bonj tim-hail )
	   (method 'hail tim-hail )
	   
       (method 'oeil tim-eye )
       (method 'cle tim-key )
       (method 'bras tim-arm )
       (method 'nom tim-name )
       (method 'trav tim-job )
       (method 'lumi tim-enli )
       (method 'oise tim-lion )
       ))


;;----------------------------------------------------------------------------
;; First-time constructor
;;----------------------------------------------------------------------------
(define (mk-tim)
  (bind 
   (kern-char-arm-self
    (kern-mk-char 
     'ch_tim ;;..........tag
     "Tim" ;;.......name
     sp_human ;;.....species
     oc_wizard ;;.. .occupation
     s_wizard ;;..sprite
     faction-men ;;..faction
     +1 ;;...........custom strength modifier
     0 ;;...........custom intelligence modifier
     +1 ;;...........custom dexterity modifier
     +1 ;;............custom base hp modifier
     +1 ;;............custom hp multiplier (per-level)
     0 ;;............custom base mp modifier
     0 ;;............custom mp multiplier (per-level)
     max-health ;;..current hit points
     -1  ;;...........current experience points
     max-health ;;..current magic points
     0
     tim-start-lvl  ;;..current level
     #f ;;...........dead?
     'tim-conv ;;...conversation (optional)
     nil ;;sch_tim ;;.....schedule (optional)
     nil ;;..........custom ai (optional)
     nil ;;..............container (and contents)
     nil ;;.........readied arms (in addition to the container contents)
     nil ;;..........hooks in effect
     ))
   (tim-mk)))
