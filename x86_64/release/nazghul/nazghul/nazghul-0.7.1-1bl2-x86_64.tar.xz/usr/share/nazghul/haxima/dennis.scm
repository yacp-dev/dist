;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------
(define dennis-lvl 3)
(define dennis-species sp_human)
(define dennis-occ oc_wright)

;;----------------------------------------------------------------------------
;; Schedule
;; 
;; In Old Absalot.
;;----------------------------------------------------------------------------
(define dennis-bed oa-bed2)
(define dennis-mealplace oa-tbl1)
(define dennis-workplace oa-slaves)
(define dennis-leisureplace oa-dining-hall)
(kern-mk-sched 'sch_dennis
               (list 0  0 dennis-bed          "dort")
               (list 7  0 dennis-mealplace    "mange")
               (list 8  0 dennis-workplace    "travaille")
               (list 12 0 dennis-mealplace    "mange")
               (list 13 0 dennis-workplace    "travaille")
               (list 18 0 dennis-mealplace    "mange")
               (list 19 0 dennis-leisureplace "suis en pause")
               (list 22 0 dennis-bed          "dort")
               )

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (dennis-mk) nil)

;;----------------------------------------------------------------------------
;; Conv
;; 
;; Dennis is an acolyte of the Accursed, who lives in Old Absalot.
;; He is somewhat naive, but not yet wholly corrupt.
;;----------------------------------------------------------------------------

;; Basics...
(define (dennis-hail knpc kpc)
  (say knpc "Bonjour."))

(define (dennis-default knpc kpc)
  (say knpc "Je ne sais rien de ce genre."))

(define (dennis-name knpc kpc)
  (say knpc "Je m'appelle Dennis."))

(define (dennis-join knpc kpc)
  (say knpc "[Il se moque] Je ne pense pas, voyageur."))

(define (dennis-job knpc kpc)
  (say knpc "Je suis un eleve de Maître Silas."))

(define (dennis-bye knpc kpc)
  (say knpc "Au revoir."))

;; Tier 2
(define (dennis-stud knpc kpc)
  (say knpc "Maître Silas enseigne qu'en concentrant ma volonté, et en sacrifiant les choses qui m'empêchent de progresser, je peux réaliser tout ce que je désire. Ou, du moins, je le pourrai une fois que j'aurai maîtrisé les voies du Maudit."))

(define (dennis-accu knpc kpc)
  (say knpc "Les maudits sont incompris. Il n'est pas mal de poursuivre ses désirs, c'est bien ! Pourquoi nos ennemis ne peuvent-ils pas voir cela ?"))

(define (dennis-enem knpc kpc)
  (say knpc "Les bouchers de Glasdrin et ce vieux fou de l'Enchanteur ont plus de sang sur les mains que quiconque !"))

(define (dennis-ways knpc kpc)
  (say knpc "Les Voies des Maudits sont révélées aux étudiants par étapes. À chaque phase, un acolyte gagne en puissance. Pour passer à la phase suivante, l'eleve doit maîtriser les rites et effectuer un sacrifice approprié."))

(define (dennis-sacr knpc kpc)
  (say knpc "Les rites sacrificiels sont secrets. Je ne peux pas en parler avec un non-initié comme vous."))

(define (dennis-powe knpc kpc)
  (say knpc "Un pouvoir inimaginable attend ceux qui ont la volonté de le saisir."))

(define (dennis-sila knpc kpc)
  (say knpc "Maître Silas est un puissant sorcier et un sage professeur."))

(define (dennis-absa knpc kpc)
  (say knpc "Ces idiots ont détruit Absalot, pensant que nous étions là ! Mais ils ne connaissaient pas le vieux Absalot, une ville sous la ville."))

(define (dennis-old knpc kpc)
  (say knpc "Je ne peux pas m'empêcher d'être impressionné lorsque je marche parmi ces ruines. Mais elles sont un peu effrayantes. Les anciens avaient des croyances étranges !"))

(define (dennis-sele knpc kpc)
  (say knpc "[Il rougit] Si tu sais ce qui est bon pour toi, tu resteras loin d'elle !")
  (kern-conv-end)
  )

(define dennis-conv
  (ifc basic-conv

       ;; basics
       (method 'default dennis-default )
       (method 'bonj dennis-hail )
	   (method 'hail dennis-hail )
	   
       (method 'adie dennis-bye )
       (method 'trav dennis-job )
       (method 'nom dennis-name )
       (method 'join dennis-join )
       
       (method 'sele dennis-sele )
       (method 'elev dennis-stud )
       (method 'ense dennis-stud )
       (method 'maud dennis-accu )
       (method 'enne dennis-enem )
       (method 'voie dennis-ways )
       (method 'sacr dennis-sacr )
       (method 'pouv dennis-powe )
	   (method 'puis dennis-powe )
       (method 'sila dennis-sila )
       (method 'absa dennis-absa )
       (method 'vieu dennis-old )
       ))

(define (mk-dennis)
  (bind 
   (kern-mk-char 
    'ch_dennis           ; tag
    "Dennis"             ; name
    dennis-species         ; species
    dennis-occ              ; occ
    s_townsman     ; sprite
    faction-men      ; starting alignment
    0 1 0            ; str/int/dex
    0 0              ; hp mod/mult
    0 0              ; mp mod/mult
    max-health ; hp
    -1                   ; xp
    max-health ; mp
    0
    dennis-lvl
    #f               ; dead
    'dennis-conv         ; conv
    sch_dennis           ; sched
    'spell-sword-ai              ; special ai
    nil              ; container
    (list t_staff)              ; readied
    )
   (dennis-mk)))
