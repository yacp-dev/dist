;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------
(define engineer-start-lvl 8)

(define voidship-parts
  (list 
  	(list t_power_core 1)
	(list sulphorous_ash 20)
	(list t_gem 10)
  ))

(define voidship-loc (mk-loc 'p_shard 50 3))

;;----------------------------------------------------------------------------
;; Schedule
;;
;; The schedule below is for the place "Engineer's Tower Ground Floor"
;;----------------------------------------------------------------------------
(kern-mk-sched 'sch_engineer
               (list 0  0  eng-workshop   "travaille")
               (list 1  0  eng-bed        "dort")
               (list 10 0  eng-workshop   "travaille")
               )

;;----------------------------------------------------------------------------
;; Gob
;;
;; Quest flags, etc, go here.
;;----------------------------------------------------------------------------
(define (engineer-mk)
  (list #f 
        (mk-quest)))
(define (eng-met? gob) (car gob))
(define (eng-quest gob) (cadr gob))
(define (eng-met! gob val) (set-car! gob val))

;; ----------------------------------------------------------------------------
;; Voidship plans
;; ----------------------------------------------------------------------------
(mk-reusable-item 
 't_voidship_plans "Plans des Vaisseaux du Néant" s_lexicon norm
 (lambda (klexicon kuser)
   (kern-ui-page-text
   "Plans des Vaisseaux du Néant"
   "Liste des composants :"
   " - Cendre sulfureuse  (20)"
   " - Pierres précieuses (10)"
   " - Noyau de pouvoir   ( 1)"
   )))

;;----------------------------------------------------------------------------
;; Conv
;;
;; The Engineer is a Wright of great knowledge, and one of the Wise.
;; He dwells in an isolated workshop on a nearly inaccessible
;; void-mesa (or void-island) off the edge of the Shard.
;;----------------------------------------------------------------------------
(define (eng-hail knpc kpc)
  (say knpc "[Vous rencontrez un homme mince avec des cheveux blancs et sauvages. "
       "Il ne semble pas vous remarquer au début] Oh, bonjour."))

(define (eng-name knpc kpc)
  (say knpc "Je suis Rudolph. Je suis plus connu sous le nom d'Ingénieur."))

(define (eng-job knpc kpc)
  (say knpc "Oh, ceci et cela. J'aime faire des choses."))

(define (eng-default knpc kpc)
  (say knpc "Je ne sais pas. Demandez à l'Enchanteur."))

(define (eng-bye knpc kpc)
  (say knpc "[Il semble vous avoir déjà oublié]"))

(define (eng-join knpc kpc)
  (say knpc "Trop occupé. Essayez la Warritrix, elle aime les aventures."))

(define (eng-warr knpc kpc)
  (say knpc "Je crois savoir qu'elle est l'une des meilleures guerrières qui aient jamais vécu, "
       "mais je sais pertinemment qu'elle est l'une des plus nobles. Quand elle n'est pas "
       "en train de faire quelque chose d'incroyablement courageux et stupide, vous pouvez la trouver "
       "à Glasdrin.")
    (quest-wise-subinit 'questentry-warritrix)
  	(quest-data-update 'questentry-warritrix 'general-loc 1)
       )

(define (eng-make knpc kpc)
  (say knpc "Je travaille sur toutes sortes de choses différentes. Dernièrement, je me suis "
       "intéressé à des dispositifs de déplacement : portes, vaisseau du neant, etc. "
       "Inventer est une de mes obsessions."))

(define (eng-wand knpc kpc)
  (say knpc "Vous êtes un Vagabond ? J'ai toujours voulu en rencontrer un. "
       "Avez-vous construit votre propre porte ?")
  (kern-conv-get-reply kpc)
  (say knpc "Je me suis toujours demandé de quelle manière cela pouvait être fait. "
       "J'ai quelques théories, et j'ai conçu un vaisseau du neant "
       "pour en tester certaines, mais il n'est pas encore terminé."))

(define (eng-void knpc kpc)
  (let* ((eng (kobj-gob-data knpc))
         (quest (eng-quest eng)))

    (define (remove-stuff)
      (map (lambda (ktype) 
             (kern-obj-remove-from-inventory kpc (car ktype) (cadr ktype)))
           voidship-parts))

	;;FIXME: the grammer here needs work
	
    (define (really-has-parts?)
      (display "really-has-parts?")(newline)
      (let ((missing (filter 
				(lambda (ktype)
					(let ((nrem (- (cadr ktype) (num-in-inventory kpc (car ktype)))))
						(cond 
							((> nrem 1)
								(begin
									(say knpc "Nous avons encore besoin " nrem " " (kern-type-get-name (car ktype)) "s")
									#t))
							((> nrem 0)
								(begin
									(say knpc "Nous avons toujours besoin de " (kern-type-get-name (car ktype)))
									#t))
							(else #f))))
					voidship-parts)))
		
        (if (null? missing)
			#t
            #f)))

    (define (build-ship)
      (say knpc "Oui, on dirait que vous avez tout. "
           "Eh bien, mettons-nous au travail...")
      (remove-stuff)
      (kern-log-msg "[Après beaucoup d'efforts, de jurons, d'essais, d'échecs...]")
      (prompt-for-key)
      (kern-log-msg "[réessayer, échouer, faire les cent pas, s'arracher "
           "des poignées de cheveux...]")
      (prompt-for-key)
      (kern-log-msg "[plus de jurons, de disputes, de recommencements, d'échecs...]")
      (prompt-for-key)
      (kern-log-msg "[recommencement, échecs, pleurs, grincement de dents...]")
      (prompt-for-key)
      (kern-log-msg "[...et ainsi de suite...]")
      (prompt-for-key)
      (kern-log-msg "[...Enfin...]")
      (prompt-for-key)
      (kern-log-msg "[...oh, bon sang, et maintenant ?...]")
      (prompt-for-key)
      (kern-log-msg "[...mais alors...]")
      (kern-obj-relocate (mk-voidship) (eval-loc voidship-loc) nil)
      (kern-log-msg "[Vous vous effondrez tous les deux d'épuisement] ")
      (say knpc
           "Eh bien. Ce n'était pas si mal. Elle est à vous maintenant, "
           "elle vous attend dehors au bout du quai. Bonne chance ! ")
      (kern-log-msg "[Il commence à ronfler]")
      (kern-obj-add-effect knpc ef_sleep nil)
      (quest-done! quest #t)
      (kern-conv-end))

    (define (missing-power-core?)
      (not (in-inventory? kpc t_power_core)))

    (define (has-plans)
      (say knpc "Ah, vous avez trouvé les plans de mon vaisseau du neant ! "
           "Avez-vous toutes les pièces dont nous avons besoin ?")
      (if (kern-conv-get-yes-no? kpc)
          (if (really-has-parts?)
              (build-ship))
          (if (missing-power-core?)
              (say knpc "A un endroit de l'autre côté du gouffre, au sud, se trouve un vaisseau du neant qui est échoué. "
                   "Si vous pouvez trouver un moyen de franchir le gouffre, il pourrait y avoir un noyau de pouvoir "
                   "que vous pouvez récupérer.")
              (say knpc "Eh bien, qu'attendez-vous ? Allez les chercher.")
              )))
      
    (define (no-plans)
      (say knpc "Un grand neant vide entoure le Tesson. J'ai conçu un vaisseau "
           "qui devrait pouvoir franchir le neant, mais ce n'est pas "
           "encore terminé. J'ai les plans dans un endroit par ici. "
           "Si vous les trouvez, faites-le moi savoir.")
           (quest-data-update 'questentry-whereami 'shard 2)
           )

    (if (quest-done? quest)
        (say knpc "Tout est terminé.")
        (if (in-inventory? kpc t_voidship_plans)
            (has-plans)
            (no-plans)))))

(define (eng-gate knpc kpc)
  (say knpc "Les portes lunaires et la Porte du Sanctuaire sont un mystère. J'aimerais bien tout comprendre "
       "d'eux. Vous savez à propos de la Porte des Démons, n'est-ce pas ?")
  (if (kern-conv-get-yes-no? kpc)
      (say knpc "J'aimerais savoir si elle existe vraiment ou non.")
      (say knpc "C'est une légende. La Porte des Démons s'est ouverte de ce monde pour "
           "d'autres. Puis quelqu'un est devenu paranoïaque, l'a fermé à cle et "
           "a jeté la cle. Dommage si c'est vrai.")))
  
(define (eng-key knpc kpc)
  (say knpc "La cle est supposée être un ensemble de runes qui ont été par la suite "
       "perdues ou dispersées. Une absurdité typique des contes de fées. Mais il peut y avoir "
       "un noyau de vérité."))

(define (eng-wise knpc kpc)
  (say knpc "Toute personne ayant l'arrogance de se dire Sage est probablement "
       "un âne. Prenez la Regisseuse de Glasdrin, par exemple."))

(define (eng-stew knpc kpc)
  (say knpc "Elle aspire à être comptée parmi les Sages, et ne se soucie pas de savoir comment "
       "combien de sang elle doit faire couler pour y parvenir. Vous avez entendu parler d'Absalot, je "
       "suppose?")
  (if (kern-conv-get-yes-no? kpc)
      (say knpc "Un exemple parfait de pouvoir abusif. C'est triste.")
      (say knpc "La Regisseuse a escroqué les autres villes et l'enchanteur "
           "pour massacrer les citoyens d'Absalot. "
           "Absalot aurait été un foyer d'insurrection des Maudits. S'il y avait "
           "des preuves de la présence des Maudits la bas, ils l'ont incendié "
           "avec le reste de la ville.")))

(define (eng-accu knpc kpc)
  (say knpc "On suppose qu'il s'agit d'une sorte de secte qui se livre à des "
       "pratiques du mal. Les personnes qui veulent s'en mêler sont très "
       "mécontentes à leur sujet. Personnellement, je n'en ai rien à faire."))

(define (eng-shri knpc kpc)
  (say knpc "J'ai étudié les dossiers concernant la Porte du Sanctuaire et j'ai fait des recherches "
       "sur site, bien sûr. Mais rien n'indique comment elle fonctionne ou "
       "comment la contrôler. Je pense que la dernière fois qu'elle a été ouverte, c'était il y a plus d'un "
       "siècle."))

(define (eng-rune knpc kpc)
  (say knpc "La légende de la Porte des Démons insiste sur le fait qu'elle était fermée par un ensemble "
       "de Runes. Certaines versions disent que les Runes ont été dispersées pour "
       "ne pas être réassemblées afin d'ouvrir la porte, d'autres disent qu'elles étaient perdues  "
       "par simple incompétence et malchance. Bien sûr, il n'y a rien "
       "qui dit si les Runes ou même la Porte ont jamais existé !"))

(define (eng-wiza knpc kpc)
  (say knpc "En règle générale, les sorciers ont tendance à être obsédés par le pouvoir."))

(define (eng-wrog knpc kpc)
  (say knpc "La plupart des Voyous sont tout simplement des nuisibles. Il sont dans tout."))

(define (eng-wrig knpc kpc)
  (say knpc "Les Artisans sont mon genre de personnes. Ils aiment faire des choses, "
       "pour comprendre comment les elles fonctionnent, et veulent juste avoir la liberté de suivre "
       "leurs propres intérêts."))

(define (eng-necr knpc kpc)
  (say knpc "Pas mal du tout. J'ai discuté avec lui une fois ou deux.")
  (quest-data-update 'questentry-necromancer 'nonevil 1)
  )

(define (eng-alch knpc kpc)
  (say knpc "Un bâtard rusé, mais je dois le respecter."))

(define (eng-man knpc kpc)
  (say knpc "Un Voyou, mais un Voyou utile. Nous nous entendons bien."))

(define (eng-ench knpc kpc)
  (say knpc "Un peu fanatique, si vous voulez mon avis. Mais il en faut de toutes sortes."))

(define eng-merch-msgs
  (list "Pas pour l'instant."
        "Laissez-moi vous montrer quelques-unes de mes inventions..."
        nil
        nil
        "Toujours heureux d'aider un collègue bricoleur."
        "Pas de problème."
   ))

(define eng-catalog
  (list
   ;; Various tools and devices
   (list t_picklock       10 "Il se trouve que j'ai quelques crochets de serrure de rechange. Ils sont pratiques pour toutes sortes de choses.")  ;; high prices, not his specialty
   (list t_shovel        100 "Je déteste me séparer de ma pelle, on ne sait jamais quand elle peut être utile.")  ;; high prices, not his specialty
   (list t_pick          100 "En fait, j'ai utilisé cette pioche. Une fois. Je pense que je peux m'en séparer.")  ;; high prices, not his specialty
   (list t_sextant       200 "C'est l'une de mes inventions les plus réussies. Avec ce sextant, vous n'avez pas besoin du sortilège 'In Wis' pour trouver votre position à la surface.")
   (list t_chrono        200 "C'est une petite HORLOGE PORTABLE ! N'est-ce pas incroyable ? [Il rit avec joie]")
   
   ;; A bit of oil and grease, for a grease-monkey:
   (list t_grease         20 "J'ai beaucoup de graisse. Je l'utilise pour tout.")
   (list t_oil            10 "Si je pouvais trouver comment exploiter la puissance explosive de cette huile, je suis sûr que je pourrais fabriquer un moteur utile.")  ;; high prices, not his specialty

   ;; Crossbows and bolts, as he likes intricate devices
   (list t_lt_crossbow    50 "Cette petite arbalète n'est-elle pas mignonne ? Les petits leviers sont assez astucieux.")
   (list t_crossbow      100 "Je suis un très mauvais tireur, mais je voulais étudier les arbalètes pour voir si je pouvais trouver comment me tirer une balle en toute sécurité dans le vide.")
   (list t_hvy_crossbow  300 "Je n'ai pas pu m'empêcher d'apporter quelques améliorations à l'arbalète standard. Celle-ci fonctionne mieux si vous la montez d'abord sur quelque chose.")
   (list t_trpl_crossbow 500 "Et si une arbalète pouvait tirer plus d'un carreaux à la fois ? Il fallait que je l'essaie, alors j'ai fait ça.") ;; a mechanism of his devising
   (list t_bolt            2 "Je suis passé par beaucoup de carreaux en testant des modifications d'arbalètes, et il me reste quelques caisses.")
   ))

(define (eng-trade knpc kpc) (conv-trade knpc kpc "buy" eng-merch-msgs eng-catalog))

(define engineer-conv
  (ifc nil
       (method 'default eng-default )
       (method 'bonj eng-hail )
	   (method 'hail eng-hail )
       (method 'nom eng-name )
       (method 'adie eng-bye )
       (method 'trav eng-job )
       (method 'join eng-join )

       (method 'comm eng-trade )
       (method 'ache eng-trade )
       (method 'inve eng-trade )

       (method 'fair eng-make )
       (method 'chos eng-make )
       (method 'vaga eng-wand )
       (method 'nean eng-void )
       (method 'port eng-gate )
       (method 'cle eng-key )
       (method 'sage eng-wise )
       (method 'regi eng-stew )
       (method 'maud eng-accu )
       (method 'sanc eng-shri )
       (method 'rune eng-rune )
       (method 'sorc eng-wiza )
       (method 'voyo eng-wrog )
       (method 'arti eng-wrig )
       (method 'necr eng-necr )
       (method 'alch eng-alch )
       (method 'homm eng-man )
       (method 'ench eng-ench )
       ))

(define (mk-engineer)
  (bind 
   (kern-char-arm-self
    (kern-mk-char 
     'ch_engineer ;;..........tag
     "L'Ingénieur" ;;.......name
     sp_human ;;.....species
     oc_wright ;;.. .occupation
     s_companion_tinker ;;..sprite
     faction-men ;;..faction
     2 ;;...........custom strength modifier
     10 ;;...........custom intelligence modifier
     2 ;;...........custom dexterity modifier
     10 ;;............custom base hp modifier
     2 ;;............custom hp multiplier (per-level)
     20 ;;............custom base mp modifier
     5 ;;............custom mp multiplier (per-level)
     max-health ;;..current hit points
     -1  ;;...........current experience points
     max-health ;;..current magic points
     0
     engineer-start-lvl  ;;..current level
     #f ;;...........dead?
     'engineer-conv ;;...conversation (optional)
     sch_engineer ;;.....schedule (optional)
     'townsman-ai ;;..........custom ai (optional)
     ;;..............container (and contents)
     (mk-inventory
      (list
       (list 1   t_dagger)
       (list 1   t_doom_staff)
       (list 1   t_trpl_crossbow)
       (list 100 t_bolt)
       (list 5   t_cure_potion)
       (list 5   t_heal_potion)
       ))
     nil ;;.........readied arms (in addition to the container contents)
     nil ;;..........hooks in effect
     ))
   (engineer-mk)))
