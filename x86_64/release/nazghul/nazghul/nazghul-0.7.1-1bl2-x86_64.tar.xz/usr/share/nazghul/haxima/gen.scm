;;----------------------------------------------------------------------------
;; Schedule
;; 
;; In Green Tower.
;;----------------------------------------------------------------------------
(define (mk-zone x y w h) (list 'p_green_tower x y w h))
(kern-mk-sched 'sch_gen
               (list 0  0  (mk-zone 2  13 1  1)  "dort")
               (list 4  0  (mk-zone 3  12 3  3)  "mange")
               (list 5  0  gt-woods  "suis en pause")
               (list 10 0  (mk-zone 26 27 2  12) "suis en pause")
               (list 12 0  (mk-zone 49 54 1  1)  "mange")
               (list 13 0  (mk-zone 49 3  7  2)  "suis en pause")
               (list 14 0  (mk-zone 7  20 5  5)  "suis en pause")
               (list 18 0  (mk-zone 49 54 1  1)  "mange")
               (list 19 0  (mk-zone 3  12 3  3)  "suis en pause")
               (list 0  0  (mk-zone 2  13 1  1)  "dort")
               )

;; ----------------------------------------------------------------------------
;; Gen's Goblin Lexicon
;; ----------------------------------------------------------------------------
(mk-reusable-item 
 't_goblin_lexicon "Lexique de la langue des Gobelins" s_lexicon norm
 (lambda (klexicon kuser)
   (kern-ui-page-text
   "Lexique de la langue des Gobelins"
   "J'ai compilé ces notes pour aider "
   "d'autres personnes à apprendre la "
   "langue des gobelins. "
   "J'espère qu'elles te seront utiles."
   "--Gen"
   ""
   "Bo....Mon, Moi-même"
   "Cho...Humain"
   "Da....La demeure, le monde"
   "Eh....'Quoi ?'"
   "Gu....Esprit, Ancêtre"
   "Ha....Bon, oui, habile"
   "Hi....Magie"
   "Iki...Allez, à"
   "Jo....Se joindre à"
   "Ka....Tuer, Détruire, Fin"
   "Ki....Santé, force de vie, pouvoir"
   "Lu....Changement, Transformation"
   "Ma....Forêt, chemins cachés"
   "Me....Devoir, travail, destin"
   "Na....La vôtre, vous-même"
   "Nu....Donner naissance, créer, commencer"
   "No....Nom"
   "Nin...Furtif"
   "Ru....Ancien, Primordial, Profond, Grotte"
   "To....Individuel"
   "Tu....Non, mauvais"
   "Zu....Regarder, Chercher"
   )))

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (gen-mk will-join? gave-notes?) (list will-join? gave-notes?))
(define (gen-will-join? gen) (car gen))
(define (gen-gave-notes? gen) (cadr gen))
(define (gen-set-will-join! gen val) (set-car! gen val))
(define (gen-set-gave-notes! gen val) (set-car! (cdr gen) val))

;;----------------------------------------------------------------------------
;; Conv
;; 
;; Gen is a Ranger who dwells in Green Tower.
;; He has much knowledge of Goblin kind, and is a friend of Kama.
;; Gen is a potential party member.
;;----------------------------------------------------------------------------
(define (gen-hail     gen player) (say gen "Salut, Vagabond"))
(define (gen-bye      gen player) (say gen "Adieu"))
(define (gen-default  gen player) (say gen "Je ne peux pas vous aider à ce sujet"))
(define (gen-name     gen player) (say gen "Je suis Gen." ))
(define (gen-woodsman gen player) (say gen "Oui, certains m'appellent l'Homme des bois." ))
(define (gen-job      gen player) (say gen "J'étais autrefois un Ranger, mais mon devoir est maintenant accompli. Je me promène dans les bois pour mes propres raisons." ))
(define (gen-reasons  gen player) (say gen "Mes raisons sont les miennes." ))

(define (gen-captain gen player) 
  (say gen "Le capitaine Deric commande les Rangers de la Tour verte. L'avez-vous rencontré ?")
  (if (kern-conv-get-yes-no? player)
      (say gen "Un homme décent, bien qu'un peu ambitieux.")
      (say gen "Vous pouvez le rencontrer dans la Tour. Son bureau est au deuxième étage.")))

(define (gen-ambitious   gen player) (say gen "Dans la paix, il n'y a rien de tel pour un homme que l'immobilité et l'humilité modeste." ))
(define (gen-culture     gen player) 
  (say gen "Bien qu'ils aient une culture qui leur est propre, ils ont vraiment une culture (contrairement aux trolls et aux sans-tête)."
       "Les vérités de la culture peuvent être vues dans Shakespeare, des vérités qui tiennent à_travers les gouffres entre les différents peuples."))
(define (gen-shakespeare gen player)
  (say gen "Vous le connaissez ! Très bien ! Enfin une conversation intéressante.")
  (if (in-player-party? 'ch_kama)
      (say gen player "[Il désigne Kama] Un autre qui connaît le Troubadour ! Vous devriez l'entendre parler de Hamlet !")
      ))

(define (gen-ranger gen player) (say gen "Les Rangers ont combattu dans ces bois pendant les Guerres des Gobelins. Maintenant, ils maintiennent une présence symbolique."))
(define (gen-wars   gen player) (say gen "Oui, j'ai combattu en tant que Ranger dans les guerres de gobelins. C'était il y a une génération, et les gens oublient. "
				     "Ils voient les gobelins comme des êtres inférieurs, vaincus et dignes d'une lente extinction."))
(define (gen-goblin gen player) (say gen "Une espèce intéressante. Bien qu'ils aient leur propre langue, ils n'ont pas d'écriture. Ils ont une certaine culture."
				     "Ils ressemblent beaucoup aux hommes, mais sont plus sauvages, plus primitifs. "
				     "Leurs guerriers sont des beserkers (foux furieux), leurs chamans sont des mystiques extatiques."))
(define (gen-primal gen player) (say gen "Vous pouvez dire que je les admire ? Mais dans les guerres que j'ai menées, je ne comprenais pas ce qu'ils étaient. "
				     "J'ai des amis parmi les gobelins sauvages de la foret, maintenant. Mais les gobelins des cavernes, c'est une autre histoire..." ))
(define (gen-cave   gen player) (say gen "Les gobelins des cavernes, qui sont plus grands et plus forts que leurs cousins des forets, préfèrent vivre dans les profondeurs du monde. "
				     "Leur dieu des ténèbres exige des sacrifices vivants. Méfiez-vous d'eux si vous explorez les grottes, ils brûlent de haine pour l'humanité." ))

(define (gen-language kgen player)
  (let ((gen (kobj-gob-data kgen)))
    (say kgen "Oui, je peux dire quelques mots de gobelin. Voulez-vous apprendre ?")
    (if (kern-conv-get-yes-no? player)
        (if (gen-gave-notes? gen)
            (say kgen "Étudiez les notes que je vous ai données, puis entraînez-vous avec moi.")
            (begin
              (say kgen "Voici quelques notes que j'ai prises sur leur langue. Vous pouvez les conserver. N'hésitez pas à vous entraîner avec moi.")
              (kern-obj-add-to-inventory player t_goblin_lexicon 1)
              (gen-set-gave-notes! gen #t)))
        (say kgen "Peut-être une autre fois."))))


(define (gen-practice gen player) (say gen "Si vous voulez vous entraîner à parler gobelin, demandez-moi quelque chose en gobelin !" ))

(define (gen-join gen player)
  (if (gen-will-join? (kobj-gob-data gen))
      (begin
        (say gen "Oui, je me joindrai à vous. "
             "J'aurai besoin de mon équipement qui est dans mon coffre, "
             "alors allons dans ma cabane dans la partie ouest de la ville. "
             "Une fois de plus à la brèche, chers amis !")
             (join-player gen))
      (say gen "Non, car les bois appellent mon nom.")))

;; SAM: Added a few words from the Lexicon which were not defined as responses.
;;      These were (Iki, Lu, Nin)
;;      Also enhanced a few responses such as for (Eh).
;; Added responses having to do with the concepts of Wanderer, Warrior, Wizard, Rogue, Wright.
;; A bit of organization/tidying may still be wanted, to make sure there are no loose ends .

(define (gen-da  gen player) (say gen "Ha! Da-Ma-To signifie gobelin des forets." ))
(define (gen-gu  gen player) (say gen "Ha! Da-Gu signifie le monde." ))
(define (gen-ru  gen player) (say gen "Ha! Da-Ru-To signifie gobelin des cavernes." ))
(define (gen-no  gen player) (say gen "Bo-No-Gen. Mais les gobelins m'appellent Ma-Zu-To." ))
(define (gen-ki  gen player) (say gen "Bo-Ha-Ki! Je suis en bonne santé." ))
(define (gen-jo  gen player) (say gen "Très bien ! Si vous vous liez d'amitié avec un gobelin, il peut se joindre à vos aventures."))
(define (gen-cho gen player) (say gen "Ha! Cho-To signifie 'un homme'." ))
(define (gen-nu  gen player) (say gen "Ha ! Nu-Ki est le mot gobelin pour 'nourriture'." ))
(define (gen-ha  gen player) (say gen "Oui, 'Ha' est un terme général affirmatif." ))
(define (gen-tu  gen player) (say gen "Oui, 'Tu' est un terme général négatif." ))
(define (gen-bo  gen player) (say gen "Oui, Bo-Gu signifie votre moi spirituel, qui est votre alter ego dans le monde des esprits." ))
(define (gen-na  gen player) (say gen "Oui, Bo-Na signifie 'nous' ou 'tribu'. Bo-Na-Ma fait référence aux gobelins des forets en général." ))
(define (gen-to  gen player) (say gen "Exact, 'To' est un suffixe général signifiant personne." ))
(define (gen-ma  gen player) (say gen "Oui, et Ka-Ma-To est leur terme pour bûcheron." ))
(define (gen-eh  gen player) (say gen "Hein ?  Ah oui, Eh-Na-Me signifie quel est votre travail, ou votre devoir." ))
(define (gen-iki gen player) (say gen "Ha ! Bo-Iki-Da signifie Je rentre chez moi."))

(define (gen-me  gen player) (say gen "Bo-Ma-Zu. Je regarde la foret, ou je cherche les chemins cachés.  Me-Lu-Ki, c'est grandir, changer, apprendre, explorer.  Tel est le chemin du Vagabond !"))
(define (gen-ka  gen player) (say gen "Ha ! Ka-Ha-To signifie guerrier.  Et Me-Ka-Ha est le chemin du guerrier !"))
(define (gen-hi  gen player) (say gen "Ha ! Hi-Ma-To est le mot pour shaman.  Et Me-Ha-Zu-Ru est le chemin du Sorcier !"))
(define (gen-nin gen player) (say gen "Ha ! Nin-Ma-To est un traqueur de foret.  Et Me-Ha-Nin-Zu est le chemin des voyous !"))
(define (gen-lu  gen player) (say gen "Ha ! Lu-Da-To est celui qui crée.  Et Me-Ha-Lu-Da est le chemin des Fabricants !"))

(define (gen-zu       gen player) (say gen "Bien ! Et Zu-To signifie Chercheur, ou Vagabond.  [Il vous regarde avec perspicacité.] Iki Meluki ?"))
(define (gen-meluki   gen player) (say gen "Vous êtes donc un véritable chercheur.  Je me joindrais à vous, si vous pouvez maîtriser Gunodama"))
(define (gen-gunodama gen player) (say gen "Les noms donnés par les esprits des ancêtres, à ceux qui habitent dans la foret.  En d'autres termes, la langue des gobelins de la foret."))

(define (gen-nuki knpc kpc)
  (say knpc "C'est le mot gobelinois pour 'nourriture'."))

(define (gen-bonaha gen player) 
  (say gen "Excellent ! C'est le mot gobelin pour ami. Vous avez fait beaucoup de progrès dans la maîtrise de leur langue.")
  (gen-set-will-join! (kobj-gob-data gen) #t))

(define (gen-shroom gen player) (say gen "C'est une vieille amie. Pouvez-vous croire qu'elle était une jeune fille de guerre dans la bataille avec les Gobelins ?"))
(define (gen-maiden gen player) (say gen "C'est vrai ! Je me souviens encore de sa hache brillant au clair de lune "
                                   "alors qu'elle se frayait un chemin dans les groupes de guerre des gobelins, scandant un chant de bataille "
                                   "avec une haleine rauque ! Elle était un spectacle à voir."))

(define (gen-thie knpc kpc)
  (say knpc "Je n'ai vu personne de bizarre par ici, mais les gobelins qui vivent dans "
       "le bois du nord ont récemment vu un homme seul voyageant vers le nord-est en direction de "
       "Bole.")
       (quest-data-update 'questentry-thiefrune 'tower 1)
       (quest-data-update-with 'questentry-thiefrune 'bole 1 (quest-notify (grant-party-xp-fn 10)))
       )

(define (gen-kama knpc kpc)
  (if (is-player-party-member? ch_kama)
      (begin
        (say knpc "Je vois que Kama vous a rejoint. Bonaha Kama !")
        (say ch_kama "Unh. Bonaha Mazuto."))
      (begin
        (say knpc "Kama est un chasseur de gobelins de foret. Il était censé me retrouver à la périphérie de la ville il y a quelques nuits, mais il ne s'est jamais montré. Vous l'avez vu ?")
        (if (yes? kpc)
            (begin
              (say knpc "Est-il en difficulté ?")
              (if (yes? kpc)
                  (say knpc "Nous devons l'aider si nous le pouvons !")
                  (say knpc "C'est un vrai soulagement !")))
            (say knpc "Si vous le faites, faites-le moi savoir. Je suis un peu inquiet.")))))
            
(define (gen-ruka knpc kpc)
  (say knpc "Ruka est le nom gobelin pour Angriss, leur dieu de la mort. "
       "Les prêtres d'Angriss étaient des agitateurs pendant les guerres de gobelins. "
       "Sa dévotion s'est pratiquement éteint depuis leur défaite. ")
  (prompt-for-key)
  (say knpc "Aujourd'hui, elle n'est plus qu'un mythe pour empêcher les enfants de s'égarer dans les bois, "
       "où des pratiques dangereuses existent encore."))

(define (gen-clov knpc kpc)
  (say knpc "Le roi Clovis a dirigé les paladins pendant la guerre des Gobelins. "
       "Si jamais mon ami Kama se présentait, nous pourrions lui demander "
       "si les gobelins auraient retrouvé son corps.")
       (quest-data-update-with 'questentry-rune-f 'kama 1 (quest-notify nil))
       )

(define (gen-band knpc kpc)
  (say knpc "Les gobelins signalent un camp de bandits vers le sud et à l'ouest. "
       "Peut-être que Deric en sait plus."))

(define gen-conv
  (ifc basic-conv
       ;;;; Goblin root words:
       (method 'bo gen-bo )  ; My, Myself
       (method 'cho gen-cho ) ; Mankind
       (method 'da gen-da )  ; Abode, World
       (method 'eh gen-eh )  ; What?
       (method 'gu gen-gu )  ; Spirit, Ancestor
       (method 'ha gen-ha )  ; Good, yes, skillful
       (method 'hi gen-hi )  ; Magic
       (method 'iki gen-iki ) ; Go
       (method 'jo gen-jo )  ; Join
       (method 'ka gen-ka )  ; Kill
       (method 'ki gen-ki )  ; Health
       (method 'lu gen-lu )  ; Change
       (method 'me gen-me )  ; Forest
       (method 'ma gen-ma )  ; Duty, Job, Destiny
       (method 'na gen-na )  ; Your, yourself
       (method 'nin gen-nin ) ; Stealth
       (method 'no gen-no )  ; Name
       (method 'nu gen-nu )  ; Give birth, Create, Begin
       (method 'run gen-ru )  ; Ancient, Primordial, Deep, Cave
       (method 'to gen-to )  ; Individual
       (method 'tu gen-tu )  ; No, Bad
       (method 'zu gen-zu )  ; Watch, Seek

       ;;;; Goblin composite words / phrases:
       (method 'bona gen-bonaha )   ; Friend
       (method 'kama gen-kama )     ; Kama, the goblin friend of Gen
       (method 'nuki gen-nuki )     ; Food
       (method 'ruka gen-ruka )     ; Angriss, the Spider Queen
       (method 'melu gen-meluki )   ; Seeker, Wanderer
       (method 'guno gen-gunodama ) ; the language of the Forest Goblins

       ;;;; Responses in human speech:
       ;; Standard responses:
       (method 'default gen-default )
       (method 'bonj gen-hail )
	   (method 'hail gen-hail )
	   
       (method 'nom gen-name )
       (method 'trav gen-job )
       (method 'join gen-join )
       (method 'adie gen-bye )

       ;; Having to do with the goblin language:
       (method 'gobe gen-goblin )
       (method 'lang gen-language )
       (method 'entr gen-practice )

       ;; Other responses:
       (method 'admi gen-primal )
       (method 'ambi gen-ambitious )
       (method 'band gen-band )
       (method 'capi gen-captain )
       (method 'cave gen-cave )
       (method 'fore gen-job )
       (method 'fill gen-maiden )
       (method 'prim gen-primal )
       (method 'rang gen-ranger )
       (method 'rais gen-reasons )
       (method 'sauv gen-primal )

       (method 'cult gen-culture )
       (method 'shak gen-shakespeare )
       (method 'trou gen-shakespeare )  ;; synonyn
       (method 'haml gen-shakespeare )  ;; synonyn

       (method 'cham gen-shroom )
       (method 'vole gen-thie )
       (method 'guer gen-wars )
       (method 'bois gen-woodsman )
       (method 'clov gen-clov )
       ))

;;----------------------------------------------------------------------------
;; First-time constructor
;;----------------------------------------------------------------------------
(define (mk-gen tag)
  (bind 
   (kern-mk-char tag                 ; tag
                 "Gen"               ; name
                 sp_human            ; species
                 oc_ranger           ; occ
                 s_old_ranger  ; sprite
                 faction-men         ; starting alignment
                 4 2 4           	 ; str/int/dex
                 pc-hp-off  ; hp bonus
                 pc-hp-gain ; hp per-level bonus
                 0 0                 ; mp mod/mult
                 max-health -1 max-health 0 3  ; hp/xp/mp/AP_per_turn/lvl
                 #f                  ; dead
                 'gen-conv           ; conv
                 sch_gen             ; sched
                 'townsman-ai        ; special ai
                 (mk-inventory (list (list 1 t_dagger) 
				     (list 1 t_playbook_hamlet)
				     ))  ; container
                 (list t_armor_leather)                ; readied
                 )
   (gen-mk #f #f)))
