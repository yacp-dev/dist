;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------

;;----------------------------------------------------------------------------
;; Schedule
;;
;; In Glasdrin.
;;----------------------------------------------------------------------------
(kern-mk-sched 'sch_ange
               (list 0  0  ga-bed "dort")
               (list 6  0  ghg-s2     "mange")
               (list 7  0  gpi-counter       "travaille")
               (list 11 0  ghg-s2     "mange")
               (list 12 0  gpi-counter       "travaille")
               (list 17 0  ghg-s2     "mange")
               (list 18 0  gpi-counter "travaille")
               (list 23 0  ga-bed "dort")
               )

;;----------------------------------------------------------------------------
;; Gob
;;
;; Quest flags, etc, go here.
;;----------------------------------------------------------------------------
(define (ange-mk) (list 'townsman))

;;----------------------------------------------------------------------------
;; Conv
;;
;; Angela is a female innkeeper, who runs the Palisades Inn in Glasdrin.
;; She is a gracious, mysterious woman.
;;----------------------------------------------------------------------------

;; Basics...
(define (ange-hail knpc kpc)
  (say knpc "[Vous rencontrez une charmante dame] Bienvenue, voyageur."))

(define (ange-default knpc kpc)
  (say knpc "J'ai bien peur de ne pas savoir."))

(define (ange-name knpc kpc)
  (say knpc "Je m'appelle Angela. Et vous êtes ?")
  (let ((name (kern-conv-get-string kpc)))
    (say knpc "Je suis très heureux de vous rencontrer, " name 
         ". J'espère que vous apprécierez votre séjour à Glasdrin.")))

(define (ange-join knpc kpc)
  (say knpc "Vous me flattez ! Cela fait des années que je n'ai pas vécu une bonne aventure, "
       "mais je dois refuser."))

(define (ange-job knpc kpc)
  (say knpc "Je suis l'aubergiste de Glasdrin. "
       "Si vous souhaitez une chambre, il suffit de demander !"))

(define (ange-bye knpc kpc)
  (say knpc "Adieu, voyageur, j'espère que tu reviendras bientôt !"))

;; Trade...
(define (ange-trade knpc kpc)
  (if (not (string=? "travaille" (kern-obj-get-activity knpc)))
      (say knpc "Oh, passez me voir quand je suis à mon comptoir ! "
           "Les Palissades sont ouvertes de 7h00 à 23h00. "
           "J'espère vous voir alors !")
      (let ((door (eval 'glasdrin-inn-room-1-door)))
        ;; is the room still open?
        (if (not (door-locked? (kobj-gob door)))
            ;; yes - remind player
            (say knpc "La chambre 1 est à vous jusqu'à ce que vous quittiez la ville !")
            ;; no - ask if player needs a room
            (begin
              (say knpc "Vous avez besoin d'une chambre ?")
              (if (kern-conv-get-yes-no? kpc)
                  ;; yes - player wants a room
                  (begin
                    (say knpc 
                         "Cela fera " glasdrin-inn-room-price " pièces d'or."
                         "La chambre est à vous jusqu'à ce que vous quittiez la ville. "
                         "Cela vous convient-il ?")
                    (if (kern-conv-get-yes-no? kpc)
                        ;; yes - player agrees to the price
                        (let ((gold (kern-player-get-gold)))
                          ;; does player have enough gold?
                          (if (>= gold glasdrin-inn-room-price)
                              ;; yes - player has enough gold
                              (begin
                                (say knpc "Merveilleux ! Vous êtes dans la chambre 1, "
                                     "c'est notre meilleure ! Profitez de votre séjour.")
                                (kern-player-set-gold 
                                 (- gold 
                                    glasdrin-inn-room-price))
                                (send-signal knpc door 'unlock)
                                (kern-conv-end)
                                )
                              ;; no - player does not have enouvh gold)
                              (say knpc "Oh, j'ai bien peur que vous n'ayez pas "
                                   "assez d'or ! J'espère que lorsque vous ferez "
                                   "fortune, vous reviendrez et resterez." )))
                        ;; no - player does not agree to the price
                        (say knpc "Je souhaite que vous restiez, "
                             "Je reçois rarement des invités aussi intrigants !")))
                  ;; no - player does not want a room
                  (say knpc "Je suis tellement déçue, "
                       "vous semblez être un invité très intéressant ! "
                       "Peut-être une autre fois.")))))))

;; Inn...
(define (ange-inn knpc kpc)
  (say knpc "'Les Palissades' est une très belle auberge, si j'ose dire."))

(define (ange-adve knpc kpc)
  (say knpc "Comme vous le savez peut-être, tous les citoyens de Glasdrin doivent effectuer une période de "
       "service. J'étais quartier-maître, et une fois, j'ai même accompagné les paladins "
       "en patrouille."))

(define (ange-patr knpc kpc)
  (say knpc "C'était une belle promenade, et le campement sous les étoiles était grandiose. "
       "Mais ensuite, les Geants ont attaqué et ont ruiné toute l'ambiance."))

(define (ange-gint knpc kpc)
  (say knpc "Les Geants sont comme des hommes trapus mais énormes et bicéphales (deux têtes). "
       "Ils étaient autrefois communs dans les montagnes, mais la vigilance de Glasdrin "
       "les a conduits dans des grottes. Ce sont des brutes des plus redoutables. "
       "Je les ai vus lancer des hommes adultes avec des lourdes armures comme des pierres sur leur "
       "propres camarades !"))

;; Townspeople...
(define (ange-glas knpc kpc)
  (say knpc "Glasdrin est une ville honnête, vous ne trouvez pas ?")
  (if (kern-conv-get-yes-no? kpc)
      (say knpc "En effet.")
      (say knpc "Vous avez sans doute vu des villes magnifiques au cours de vos voyages. "
           "Je suppose que je l'aime parce que c'est chez moi.")))

(define (ange-patc knpc kpc)
  (say knpc "Patch est le meilleur guérisseur qui soit. "
       "Il peut même faire revenir à la vie les personnes récemment décédées, "
       "si leurs blessures ne sont pas trop graves."))

(define ange-conv
  (ifc glasdrin-conv

       ;; basics
       (method 'default ange-default )
       (method 'bonj ange-hail )
	   (method 'hail ange-hail )
       (method 'adie ange-bye )
       (method 'trav ange-job )
       (method 'nom ange-name )
       (method 'join ange-join )
       
       ;; trade
       (method 'echa ange-trade )
       (method 'cham ange-trade )
       (method 'ache ange-trade )
       (method 'vend ange-trade )

       ;; inn
       (method 'aube ange-inn )
       (method 'aven ange-adve )
       (method 'gean ange-gint )
       (method 'patr ange-patr )

       ;; town & people
       (method 'glas ange-glas )
       (method 'patc ange-patc )

       ))

(define (mk-angela)
  (bind 
   (kern-mk-char 'ch_angela          ; tag
                 "Angela"            ; name
                 sp_human            ; species
                 nil                 ; occ
                 s_townswoman        ; sprite
                 faction-glasdrin         ; starting alignment
                 0 1 0               ; str/int/dex
                 0 0                 ; hp mod/mult
                 0 0                 ; mp mod/mult
                 max-health -1 max-health 0 3  ; hp/xp/mp/AP_per_turn/lvl
                 #f                  ; dead
                 'ange-conv          ; conv
                 sch_ange            ; sched
                 'townsman-ai                 ; special ai
                 (mk-inventory (list (list 1 t_dagger)))                 ; container
                 (list t_dagger
					         )                  ; readied
                 )
   (ange-mk)))
