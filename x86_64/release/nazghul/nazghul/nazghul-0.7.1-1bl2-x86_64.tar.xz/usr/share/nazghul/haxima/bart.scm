;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------

;;----------------------------------------------------------------------------
;; Schedule
;; 
;; In Oparine.
;;----------------------------------------------------------------------------
(kern-mk-sched 'sch_bart
               (list 0  0  black-barts-bed      "dort")
               (list 11 0  black-barts-ship     "travaille")
               (list 18 0  bilge-water-hall     "suis en pause")
               (list 23 0  black-barts-bed      "dort")
               )

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (bart-mk) nil)

;;----------------------------------------------------------------------------
;; Conv
;; 
;; Bart is a hard-drinking goblin shipwright who dwells in Oparine.
;;----------------------------------------------------------------------------

;; Basics...
(define (bart-hail knpc kpc)
  (say knpc "[Vous rencontrez un gobelin taciturne qui sent le whisky] "
       "Heu..."))

(define (bart-default knpc kpc)
  (say knpc "Hein?"))

(define (bart-name knpc kpc)
  (say knpc "Bart."))

(define (bart-join knpc kpc)
  (say knpc "[Il vous regarde bizarrement et secoue la tête]"))

(define (bart-job knpc kpc)
  (say knpc "Bart fait des bateaux. Bon bateau."))

(define (bart-bye knpc kpc)
  (say knpc "Ja."))

;; Trade...
(define (bart-trade knpc kpc)

  (define (buy-ship)
    (let* ((town (loc-place (kern-obj-get-location knpc)))
           (town-loc (kern-place-get-location town))
           (ship-loc (loc-offset town-loc east)))
      (if (ship-at? ship-loc)
          (say knpc "Hummm.. Pas de place à quai. Quelqu'un doit d'abord déplacer le bateau.")
          (begin
            (kern-obj-relocate (mk-ship) ship-loc nil)
            (take-player-gold oparine-ship-price)
            (say knpc "Le bateau est prêt en dehors de la ville.")
            ))))

  (define (sell-ship)
    (let* ((town (loc-place (kern-obj-get-location knpc)))
           (town-loc (kern-place-get-location town))
           (ship-loc (loc-offset town-loc east))
           (kship (kern-place-get-vehicle ship-loc)))
      (if (null? kship)
          (say knpc "Bart ne voit pas le bateau. Vous devez vous arrimer au quai, puis revenez.")
          (begin
            (say knpc "Vous voulez vendre cette épave ? Bart donne " 
                 oparine-ship-tradein-price
                 ". C'est d'accord?")
            (if (kern-conv-get-yes-no? kpc)
                (begin
                  (say knpc "Bart trop généreux, toi chanceux.")
                  (kern-obj-remove kship)
                  (give-player-gold oparine-ship-tradein-price))
                (say knpc "Humm... Ce bateau va bientôt couler."))))))

  (if (not (string=? "travaille" (kern-obj-get-activity knpc)))
      (say knpc "Pas travailler maintenant. Maintenant, boire !")
      (begin
        (say knpc "Vous voulez acheter un bateau ?")
        (if (yes? kpc)
            (begin
              (say knpc "bateau " oparine-ship-price " pièces d'or. Vous voulez un bateau ?")
              (if (kern-conv-get-yes-no? kpc)
                  (if (player-has-gold? oparine-ship-price)
                      (buy-ship)
                      (begin
                        (say knpc "Tu n'as pas d'or ! Tu as essayé de tromper Bart ? "
                             "[Il crache par terre]")
                        (kern-conv-end)))
                  (say knpc "Bien. Va nager.")))
            (begin
              (say knpc "Vous voulez vendre un bateau ?")
              (if (yes? kpc)
                  (sell-ship)
                  (begin
                    (say knpc "Alors pourquoi tu embêtes Bart ?")
                    (kern-conv-end))))))))

;; Drink...
(define (bart-drink knpc kpc)
  (if (not (string=? "travaille" (kern-obj-get-activity knpc)))
      (say knpc "Allons boire !")
      (say knpc "Travail maintenant. Boire plus tard.")))


;; Townspeople...
(define (bart-opar knpc kpc)
  (say knpc "Sentir le poisson."))

(define (bart-gher knpc kpc)
  (say knpc "Tu-gu. Méchant fantôme. [Il fait un signe étrange dans l'air]"))

(define (bart-alch knpc kpc)
  (say knpc "Hi-lu-to. Il prend la route du bas de la ville qui brûle. "
       "Cousins des gobelins se souvenir."))

(define (bart-seaw knpc kpc)
  (say knpc "Elle sent comme le poisson."))

(define (bart-osca knpc kpc)
  (say knpc "Tu-to. Bart ne connaît pas les mots d'homme."))

(define (bart-henr knpc kpc)
  (say knpc "Un ami de Bart. Faire bonne boisson ! Bart aime la boisson."))

(define bart-conv
  (ifc basic-conv

       ;; basics
       (method 'default bart-default )
       (method 'bonj bart-hail )
	   (method 'hail bart-hail )
	   
       (method 'adie bart-bye )
       (method 'trav bart-job )
       (method 'nom bart-name )
       (method 'join bart-join )
       
       ;; drink
       (method 'boir bart-drink )

       ;; trade
       (method 'echa bart-trade )
       (method 'bate bart-trade )
       (method 'ache bart-trade )
       (method 'vend bart-trade )

       ;; town & people
       (method 'opar bart-opar )
       (method 'alch bart-alch )
       (method 'gher bart-gher )
       (method 'sorc bart-seaw )
       (method 'osca bart-osca )
       (method 'henr bart-henr )
       (method 'ja bart-bye )

       ))

(define (mk-bart)
  (bind 
   (kern-mk-char 'ch_bart           ; tag
                 "Bart"             ; name
                 sp_forest_goblin    ; species
                 nil                 ; occ
                 s_fgob_civilian     ; sprite
                 faction-men         ; starting alignment
                 0 0 0               ; str/int/dex
                 0 0                 ; hp mod/mult
                 0 0                 ; mp mod/mult
                 max-health -1 max-health 0 1  ; hp/xp/mp/AP_per_turn/lvl
                 #f                  ; dead
                 'bart-conv         ; conv
                 sch_bart           ; sched
                 'townsman-ai                 ; special ai
                 (mk-inventory (list (list 1 t_axe)))                 ; container
                 nil                 ; readied
                 )
   (bart-mk)))
