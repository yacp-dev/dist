;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------

;;----------------------------------------------------------------------------
;; Schedule
;;
;; The schedule below is for the place "Trigrave"
;;----------------------------------------------------------------------------
(kern-mk-sched 'sch_chant
               (list 0  0  trigrave-east-west-road   "suis ivre")
               (list 2  0  trigrave-chants-bed       "dort")
               (list 12 0  trigrave-tavern-hall      "travaille")
               (list 23 0  trigrave-east-west-road   "suis ivre")               
               )

;;----------------------------------------------------------------------------
;; Gob
;;
;; Quest flags, etc, go here.
;;----------------------------------------------------------------------------
(define (chant-mk) (list 0))
(define (chant-get-gold knpc) (car (kobj-gob-data knpc)))
(define (chant-has-gold? knpc) (> (chant-get-gold knpc) 0))
(define (chant-set-gold! knpc amount) 
  (if (>= amount 0)
      (set-car! (kobj-gob-data knpc) 
                amount)))
(define (chant-dec-gold! knpc) (chant-set-gold! knpc 
                                                (- (chant-get-gold knpc)
                                                   1)))

;; ----------------------------------------------------------------------------
;; Chanticleer
;;
;; Chanticleer is a roaming bard who spends most of his time in Trigrave. He's
;; a confident, easy-going fellow who is also an unstoppable showman. He
;; possesses a great deal of knowledge about the region, loves rumours and
;; gossip, has friends in low and high places (uncluding the reclusive
;; Enchanter) and is probably a spy for *somebody* but it isn't clear who.
;;
;; ----------------------------------------------------------------------------
(define (chant-song knpc kpc)
  (if (isdrunk? knpc)
      (say knpc "Tous ensemble maintenant ! Ramez, ramez, ramez votre bateau ! [Hée hée hée !]")
      (begin
        (say knpc "Mille melodies attendent en cage derrière les barreaux de ma gorge "
             "sèche! Peut-être une petite pièce de monnaie pour stimuler les tuyaux ? [Il vous regarde "
             "avec insistance. Lui donnez-vous de l'or ?]")
        (if (kern-conv-get-yes-no? kpc)
            ;; yes - give chant some gold
            (let ((amount (kern-conv-get-amount)))
              (display "montant=")(display amount)(newline)
              (cond ((= 0 amount) 
                     (say knpc "Ah bon ??, Une melodie imaginaire alors, pour votre or imaginaire !!"
                          " [Il fait semblant de jouer du luth]"))
                    ((< amount 2)
                     (say knpc "Oui... Je vois. Et voilà :\n"
                          "Il y avait un Vagabond oh tellement pauvre \n"
                          "Il voulait garder tout son or\n"
                          "Et quand il s'est moqué du pauvre Chanteclair\n"
                          "Le bruit de la discorde lui a rempli l'oreille !\n"
                          " [Il frappe fort, impétueux, et s'incline]"))
                    (else
                     (say knpc "Cela remplira ma choppe préférée ! "
                          "Maintenant, de quoi aimeriez-vous entendre ? Des Marais, de la foret "
                          "ou des Lieux oubliés ?")
                     (chant-set-gold! knpc amount))))
            ;; no -- don't give him some gold
            (say knpc "Un troubadour sobre ne fait de bien à personne !")))))

(define (chant-fen knpc kpc)
  (if (isdrunk? knpc)
      (say knpc "Sale endroit ! [HIPS !! Hic !!]")
      (if (not (chant-has-gold? knpc))
          (chant-song knpc kpc)
          (begin
            (chant-dec-gold! knpc)
            (say knpc 
                 "LES MARAIS\n"
                 "\n"
                 "Si vous aimez ...\n"
                 " les mouches qui piquent, \n"
				 " et les marécages qui pètent, \n"
                 " des ciels lugubres, \n"
				 " des grenouilles de taille humaine,\n"
                 " des autels maléfiques, \n"
				 " des bottes pleines de boue, \n"
                 " des rangers égarés \n"
				 " (méfiants envers les étrangers),\n"
                 " des étendues désertes sans chemin,\n"
                 " des Liches, des Spectres,\n"
                 " et des guerriers squelettes, aussi...\n"
                 " alors, mon ami,\n"
                 " au nord des Marais!\n"
                 " Car c'est l'endroit idéal pour toi.\n")))))

(define (chant-forest knpc kpc)
  (if (isdrunk? knpc)
      (say knpc "Cours, Foret, cours ! [Hée-hée]")
      (if (not (chant-has-gold? knpc))
          (chant-song knpc kpc)
          (begin
            (chant-dec-gold! knpc)
            (say knpc 
                 "LES BOIS DE L'EST\n"
                 "\n"
                 "Les bois sont beaux, sombres et profonds\n"
                 "et toujours affamé aussi !\n"
                 "Ils ont mangé beaucoup de voyageurs\n"
                 "et englouti un roi ou deux.\n"
                 "\n"
                 "Là-bas, les gobelins rôdent et les bandits se cachent\n"
                 "et les araignées géantes bavent,\n"
                 "Donc, si vous y allez, n'oubliez pas\n"
                 "d'amener un imbécile plus lent !\n"
                 )))))

(define (chant-forgotten knpc kpc)
  (if (isdrunk? knpc)
      (say knpc "Je ne m'en souviens pas ! [il pleure de rire]")
      (if (not (chant-has-gold? knpc))
          (chant-song knpc kpc)
          (begin
            (chant-dec-gold! knpc)
            (say knpc 
                 "LES SALLES PERDUES\n"
                 "\n"
                 "S'enfoncer toujours plus profondément, \n"
                 "Ils ont réveillé l'ancien dormeur,\n"
                 "Vous connaissez l'histoire\n"
                 "(La morale est dépassée)\n"
                 "Je ne vais donc pas vous ennuyer avec des détails !\n"
                 "\n"
                 "[arrête de jouer] Si vous DEVEZ simplement aller enquêter, "
                 "cherchez sur la côte sud.")
		 (if (null? (quest-data-getvalue 'questentry-rune-l 'know-hall))
			(quest-data-update-with 'questentry-rune-l 'approx-hall 1 (quest-notify nil))
		)
		 ))))

(define (chant-thie knpc kpc)
  (if (isdrunk? knpc)
      (say knpc 
           "Hé, devinette qui est chouette,\n"
           "Te voilà dans les oubliettes!\n"
           "Quand Kalcifax a sauté à travers la lune\n"
           "Le Nécromage a ri de voir un tel sport\n"
           "Et le voleur s'est enfui avec la Rune !")
      (say knpc "Alors Enchy, vous cherchez aussi ? Le voleur a dû éviter la "
           "ville, mais des voyageurs ont pu croiser son chemin. Demandez à Gwen.")))

(define (chant-man knpc kpc)
  (if (isdrunk? knpc)
      (begin
        (say knpc "Héé ! Pouvez-vous garder un zecret ?")
        (if (yes? knpc)
            (begin
              (say knpc "Le MEC a une grotte zecrète. Tu sais où c'est ?")
              (if (yes? kpc)
                  (say knpc "Moi aussi ! [Héé-héé !]")
                  (say knpc "La montagne à [ " 
                       (loc-x the-mans-hideout-loc) " " 
                       (loc-y the-mans-hideout-loc) 
                       "] n'est pas vraiment une montagne ! Allez le surprendre !")))
            (say knpc "Moi non plus ! [Il renifle]")))
      (say knpc "Le MEC ? Je ne sais rien sur le MEC. Pourquoi me demandez-vous cela ?")))

(define chant-conv
  (ifc basic-conv
       ;; default if the only "keyword" which may (indeed must!) be longer than
       ;; 4 characters. The 4-char limit arises from the kernel's practice of
       ;; truncating all player queries to the first four characters. Default,
       ;; on the other hand, is a feature of the ifc mechanism (see ifc.scm).
       (method 'default (lambda (knpc kpc) 
                 (if (isdrunk? knpc)
                     (say knpc "Je suis ivre... [hic]")
                     (say knpc "Je suis dans le doute...."))))
       (method 'bonj (lambda (knpc kpc)
                 (if (isdrunk? knpc)
                     (say knpc "[Saluant ivre] Hiippss! Sa...Salut au fromage!")
                     (say knpc "Ravi de faire ta connaissance, mon cher ami !"))))
		
		(method 'hail (lambda (knpc kpc)
                 (if (isdrunk? knpc)
                     (say knpc "[Saluant ivre] Hiippss! Sa...Salut au fromage!")
                     (say knpc "Ravi de faire ta connaissance, mon cher ami !"))))
				
					 
       (method 'adie (lambda (knpc kpc) 
                 (if (isdrunk? knpc)
                 (say knpc "Bouuhh-Adieu [ricanement]")
                 (say knpc "Que la route vous embrasse les pieds !"))))
       (method 'trav (lambda (knpc kpc) 
                 (if (isdrunk? knpc)
                     (say knpc "[De façon surdramatique, il montre du doigt ses yeux, "
                          "puis ses oreilles, puis fait un mouvement de fermeture éclair sa "
                          "bouche, hoche la tête de manière sagace et fait un clin d'oeil].")
                     (say knpc "Je suis un véritable vaisseau d' intelligence et de melodies!"))))
       (method 'nom (lambda (knpc kpc)
                 (if (isdrunk? knpc)
                     (say knpc "Hiipps! Chantitroubadour ! Heuu... [Il essaie de s'incliner mais tombe]")
                     (say knpc "Chanteclaire le Troubadour, à votre service "
                          "[Il s'incline et fait une révérence]"))))
       (method 'join (lambda (knpc kpc) 
                 (if (isdrunk? knpc)
                     (say knpc "Vous voulez prendre un verre ? "
                          "Je pensais que vous ne demanderiez jamais ! (Hiiippss!! HIC! )")
                     (say knpc "Certains troubadours s'aventurent, d'autres sont plus sages. "
                          "Je suis parmi ces derniers."))))

       (method 'chan (lambda (knpc kpc)
                 (if (isdrunk? knpc)
                     (say knpc "[HIC!!] Qui est cet imbécile larmoyant et ivre, [HIPSS !!]\n"
                          "Qui plaît à la melodie comme la bête a fait l'homme...")
                     (say knpc "\n"
                          "\n"
                          " Qui est ce sage troubadour enchanteur, \n"
                          " Qui joue du luth comme une melodie faite de chair \n"
                          " Et raconte des histoires que le destin lui-même raconterait\n"
                          " Si seulement le destin pouvait aussi bien mentir ?"))))
       (method 'earl (lambda (knpc kpc)
                 (if (isdrunk? knpc)
                     (say knpc "Earl? Ah oui, ce marchand, il a tout oublié et je ne le saurai jamais !")
                     (say knpc 
                          "Notre distingué commerçant...\n"
                          "\n"
                          " Il était une fois un maître de la flamme\n"
                          " En tant que Mage de guerre, il a acquis une grande renommée\n"
                          " Mais comme vous pouvez le constater\n"
                          "Il a tenté un mauvais sortilège\n"
                          "Et maintenant, il ne se souvient plus de son nom !\n"
                          ))))

       (method 'ench (lambda (knpc kpc)
                 (if (isdrunk? knpc)
                     (say knpc "Enchy ! Installé dans sa confortable tour, il donne "
                          "des ordres, tandis que Chant doit faire les rondes !")
                     (say knpc 
                          "Mes voyages m'amènent parfois à la "
                          "Tour de l'Enchanteur."))))
       (method 'gwen (lambda (knpc kpc)
                 (if (isdrunk? knpc)
                     (say knpc "[Il se penche de près et chuchote bruyamment] "
                          "Avez-vous déjà vu une sorcière porter une épée ?")
                     (say knpc
                          "Ah, notre mystérieuse aubergiste ...\n"
                          "\n"
                          " Quand la colombe grise pleure\n"
                          "Et que le monde entier dort \n"
                          " Quand les fantômes s'élèvent comme la brume de la mer\n"
                          " La chouette au clair de lune \n"
                          "se renseigne sur la nuit immobile\n"
                          " La question que nous lui posons tous !\n"))))
       (method 'mara chant-fen )
       (method 'fore chant-forest )
       (method 'oubl chant-forgotten )
       (method 'jim (lambda (knpc kpc)
                 (if (isdrunk? knpc)
                     (say knpc "Jim?? Un chevalier à l'envers ! [Hips! Beurp!!! !]")
                     (say knpc
                          "Ha ! Voici un peu de potins !\n"
                          "\n"
                          "Plein feu et sinistre !\n"
                          "le respectable Jim, \n"
                          " Son armure s'est déchirée dans le sang, \n"
                          " Il a mené son maître sur le champ de bataille\n"
                          " A rayé l'emblème de son bouclier\n"
                          " Et a fui cette côte maudite."
                          ))))
       (method 'rond (lambda (knpc kpc)
                 (if (isdrunk? knpc)
                     (say knpc "D'accord ! Je surveille les routes, "
                          "en les surveillant...")
                     (say knpc "Quelle étrange chose à demander !"))))
       (method 'melo chant-song )
       (method 'les (lambda (knpc kpc)
                 (if (isdrunk? knpc)
                     (say knpc "[Sifflant] oui Eux !!! Les ennemis des sages ! Chut Hiippss !")
                     (say knpc "[En vous regardant avec un faux soupçon] "
                          "Quoi?? Etes-vous sûr de ne pas être paranoïaque ?"))))
       (method 'vole chant-thie )
       
       (method 'tour (lambda (knpc kpc)
                 (if (isdrunk? knpc)
                     (say knpc "Un lieu déprimant !")
                     (say knpc
                          "Elle surveille les Marécages au nord, "
                          "mais si vous pensez à y aller, "
                          "sachez que l'Enchanteur n'aime pas les visiteurs !"))))

       (method 'inte (lambda (knpc kpc)
                 (say knpc "Des ragots, en fait. Donnez-moi un nom, je vous donnerai "
                      "la saleté.")))
       (method 'perd (lambda (knpc kpc)
                 (say knpc "Eh bien, je ne serais pas un troubadour si je ne connaissais pas une melodie sur les légendaires Salles Perdues !")))
       (method 'mec chant-man )
       (method 'malf chant-man )
       ))
