;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------
(define abe-lvl 3)
(define abe-species sp_human)
(define abe-occ nil)

;;----------------------------------------------------------------------------
;; Schedule
;; 
;; In Green Tower
;;----------------------------------------------------------------------------
(define abe-bed gt-abe-bed)
(define abe-mealplace gt-ws-tbl2)
(define abe-workplace gt-ruins)
(define abe-leisureplace gt-ws-hall)
(kern-mk-sched 'sch_abe
               (list 0  0 abe-bed          "dort")
               (list 7  0 abe-mealplace    "mange")
               (list 8  0 abe-workplace    "travaille")
               (list 12 0 abe-mealplace    "mange")
               (list 13 0 abe-workplace    "travaille")
               (list 18 0 abe-mealplace    "mange")
               (list 19 0 abe-leisureplace "suis en pause")
               (list 22 0 abe-bed          "dort")
               )

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (abe-mk) (list #f))
(define (abe-met? gob) (car gob))
(define (abe-met! gob) (set-car! gob #t))

;;----------------------------------------------------------------------------
;; Conv
;; 
;; Abe is a scholar who knows much of the runes.
;; He fled from Absalot with the Alchemist, and now lives in Green Tower.
;;----------------------------------------------------------------------------

;; Basics...
(define (abe-hail knpc kpc)
  (kern-print "Vous rencontrez un jeune homme à l'allure littéraire.\n")
  (if (abe-met? (gob knpc))
      (say knpc "Re-bonjour.")
      (begin
        (abe-met! (gob knpc))
        (say knpc "Bonjour. Dites, vous ne seriez pas un aventurier ?")
        (if (yes? kpc)
            (say knpc "Je suis très honoré ! Je ne peux pas croire à ma bonne fortune. "
			"J'ai tant de questions à vous poser. Quand vous aurez le temps. Si vous le voulez bien.")
            (say knpc "Oh, bien sûr que non. Désolé. Je pensais juste... peu importe.")))))

(define (abe-default knpc kpc)
  (say knpc "Je chercherai cela dans les archives quand j'en aurai l'occasion."))

(define (abe-name knpc kpc)
  (say knpc "Oh. Oui. Je m'appelle Abe."))

(define (abe-join knpc kpc)
  (say knpc "Oh, non, je ne pourrais pas... Je ne suis pas vraiment ce genre de personne."))

(define (abe-job knpc kpc)
  (say knpc "Je suis un érudit. J'étudie les ruines ici, dans la Tour verte. Les avez-vous examinées ?")
  (if (no? kpc)
      (say knpc "Ils sont dans le coin sud-ouest de la ville. Fascinant.")
      (begin
        (say knpc "Saviez-vous qu'il y en a d'autres sous la surface ?")
        (yes? kpc)
        (say knpc "Oui, tout comme Absalot !"))))

(define (abe-absa knpc kpc)
  (say knpc "Peu de gens savent que sous Absalot se trouve une ville plus ancienne. "
  "Les ruines sous Absalot sont très similaires à celles de la Tour Verte. "
  "Je suis certain qu'elles ont été construites par la même civilisation !"))

(define (abe-rune knpc kpc)
  (if (any-in-inventory? kpc rune-types)
      (begin
	 (say knpc "\n[Il siffle doucement]\n Vous avez quelques-unes des huit cles de la Porte des Demons ?\n Je vais les examiner pour vous !")
		(quest-data-update 'questentry-runeinfo 'abe 1)
	 (quest-data-update-with 'questentry-runeinfo 'keys 1 (quest-notify (grant-party-xp-fn 20)))
	(if (any-in-inventory? kpc (list t_rune_k))
	    (say knpc "[Il examine une rune] C'est la Rune de la connaissance !")
	    )
	(if (any-in-inventory? kpc (list t_rune_p))
	    (say knpc "[Il examine une rune] C'est la Rune du pouvoir !")
	    )
	(if (any-in-inventory? kpc (list t_rune_s))
	    (say knpc "[Il examine une rune] C'est la Rune de la compétence !")
	    )
	(if (any-in-inventory? kpc (list t_rune_c))
	    (say knpc "[Il examine une rune] C'est la Rune de la curiosité !")
	    )
	(if (any-in-inventory? kpc (list t_rune_f))
	    (say knpc "[Il examine une rune] C'est la Rune de la liberté !")
	    )
	(if (any-in-inventory? kpc (list t_rune_w))
	    (say knpc "[Il examine une rune] C'est la Rune de la Sagesse !")
	    )
	(if (any-in-inventory? kpc (list t_rune_d))
	    (say knpc "[Il examine une rune] C'est la Rune de la discrétion !")
	    )
	(if (any-in-inventory? kpc (list t_rune_l))
	    (say knpc "[Il examine une rune] C'est la Rune du leadership !")
	    )
	(if (has-all-runes? kpc) 
	    (say knpc "C'est incroyable !\n Vous avez toutes les huit cles de la Porte des Demons ! !! Que comptez-vous en faire ?")
	    )
	)
      (say knpc "Il y a beaucoup de runes. Peut-être que si vous m'apportiez un exemple...")))

(define (abe-demo knpc kpc)
  (say knpc "La Porte des Demons a été fermée par les Sages il y a longtemps. "
  "Son emplacement a été effacé de toutes les archives, "
  "mais la légende la situe à un endroit au nord. ")
		(quest-data-update 'questentry-runeinfo 'abe 1)
	     (quest-data-update 'questentry-runeinfo 'keys 1)
  		(quest-data-update-with 'questentry-runeinfo 'gate 1 (quest-notify (grant-party-xp-fn 30)))
       )

(define (abe-keys knpc kpc)
  (say knpc "Oui, la Porte des Demons était verrouillée avec huit serrures et les cles étaient séparées. "
  "Chacune prend la forme d'une rune puissante. Elles ont été perdues ou cachées depuis lors."))
       
(define (abe-eigh knpc kpc)
	(say knpc "La légende dit qu'il y a huit runes en tout, cherchez-vous les autres ?")
	(if (yes? kpc)
		(say knpc "Les vieilles histoires parlent de certains, comme le charme du roi Clovis, ou le temple du vide.")
		(say knpc "Simple curiosité oisive ? Croyez-moi, je comprends.")))

(define (abe-clov knpc kpc)
     (say knpc "Une légende veut que le roi Clovis en a porté une comme un talisman enchanté."
	 "Il fut tué au combat pendant les guerres des gobelins, mais on ne l'a jamais retrouvé sur son corps."
	 "Peut-être que quelqu'un (un ^c+mgobelin^c- ?) a pillé son cadavre et l'a pris.")
           (quest-data-assign-once 'questentry-rune-f)
           )
           
(define (abe-temp knpc kpc)
	(say knpc "Au nord-ouest d'Oparine, il y a un temple qui flotte dans le vide. "
	"Personne ne peut l'atteindre, mais la légende dit qu'une rune y a été scellée par les anciens.")
			(quest-data-assign-once 'questentry-rune-d)
			)
      
(define (abe-void knpc kpc)
  (say knpc "Le Tesson, les lunes et les étoiles habitent un grand vide. "
  "Les anciens pouvaient naviguer à travers le vide dans des bateaux, comme nous naviguons à travers une mer !")
       (quest-data-update 'questentry-whereami 'shard 2)
       )

(define (abe-ship knpc kpc)
  (say knpc "Je connais les navires du vide, mais pas leur fonctionnement. "
  "Même les Maîtres Constructeurs ont perdu la technique pour les fabriquer.")
       (quest-data-update 'questentry-whereami 'shard 2)
       )

(define (abe-wrig knpc kpc)
  (say knpc "Les Constructeurs sont spécialisés dans la fabrication de choses. L'ingénieur est le plus grand Constructeur vivant."))

(define (abe-quee knpc kpc)
  (say knpc "Je ne suis pas sûr de ce que vous insinuez."))

(define (abe-civi knpc kpc)
  (say knpc "Je ne sais pas grand-chose de la civilisation qui a construit les ruines, "
  "mais des indices indiquent qu'elle était assez méchante selon nos normes ! "
  "Vous savez ce que je veux dire ?")
  (if (yes? kpc)
      (say knpc "Alors je n'en parlerai pas !")
      (say knpc "Sacrifices humains, cannibalisme, culte des demons. Pratiques maudites !")))

(define (abe-accu knpc kpc)
  (say knpc "Oui, les maudits ont une longue histoire. "
  "Ils sont peut-être un croque-mitaine politique commode, "
  "mais il y a suffisamment de preuves pour suggérer qu'ils existent, ou qu'ils ont existé."))

(define (abe-bye knpc kpc)
  (say knpc "Faites-moi savoir si vous trouvez d'autres ruines !"))

(define (abe-alch knpc kpc)
  (say knpc "Ah, comment va le vieux coquin secret ? Je ne l'ai pas vu depuis que nous étions voisins."))

(define (abe-neig knpc kpc)
  (say knpc "A Absalot. Avant que nous ne devions fuir."))

(define (abe-flee knpc kpc)
  (say knpc "[Il soupire]C'est une longue histoire. Demandez autour de vous. Ça n'a plus d'importance."))

(define (abe-gobl knpc kpc)
  (say knpc "Demandez à Deric ou Gen à propos des gobelins, ils ont beaucoup d'expérience avec eux."))

(define abe-conv
  (ifc green-tower-conv

       ;; basics
       (method 'default abe-default )
       (method 'bonj abe-hail )
	   (method 'hail abe-hail )   
       (method 'adie abe-bye )
       (method 'trav abe-job )
       (method 'nom abe-name )
       (method 'join abe-join )
       

       (method 'absa abe-absa )
       (method 'rune abe-rune )
       (method 'demo abe-demo )
       (method 'port abe-demo )
       (method 'cle abe-keys )
       (method 'huit abe-eigh )
       (method 'rein abe-quee )
       (method 'roi abe-clov )
       (method 'clov abe-clov )
       (method 'char abe-clov )
	   (method 'tali abe-clov )
	   (method 'ench abe-clov )
       (method 'temp abe-temp )
       (method 'civi abe-civi )
       (method 'maud abe-accu )
       (method 'ruin abe-job )
       (method 'vide abe-void )
	   (method 'nean abe-void )
       (method 'navi abe-ship )
       (method 'vogu abe-ship )
       (method 'cons abe-wrig )
       (method 'alch abe-alch )
       (method 'vois abe-neig )
       (method 'fuir abe-flee )
       (method 'gobe abe-gobl )
       ))

(define (mk-abe)
  (bind 
   (kern-mk-char 
    'ch_abe           ; tag
    "Abe"             ; name
    abe-species         ; species
    abe-occ              ; occ
    s_companion_wizard ; sprite
    faction-men      ; starting alignment
    2 1 1            ; str/int/dex
    0 0              ; hp mod/mult
    0 0              ; mp mod/mult
    max-health ; hp
    -1                   ; xp
    max-health ; mp
    0
    abe-lvl
    #f               ; dead
    'abe-conv         ; conv
    sch_abe           ; sched
    'townsman-ai              ; special ai
    nil              ; container
    (list t_staff
					         t_armor_leather
					         )              ; readied
    )
   (abe-mk)))
