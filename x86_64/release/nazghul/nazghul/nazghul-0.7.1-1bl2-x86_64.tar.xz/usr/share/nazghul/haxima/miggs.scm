;;----------------------------------------------------------------------------
;; Schedule
;;
;; The schedule below is for the place "Trigrave"
;;----------------------------------------------------------------------------
(kern-mk-sched 'sch_miggs
               (list 0  0  trigrave-miggs-bed      "dort")
               (list 7  0  trigrave-tavern-kitchen "travaille")
               (list 23 0  trigrave-miggs-bed      "dort")
               )

;;----------------------------------------------------------------------------
;; Gob
;;
;; Quest flags, etc, go here.
;;----------------------------------------------------------------------------
(define (miggs-mk) nil)

;;----------------------------------------------------------------------------
;; Conv
;;
;; Miggs is the tavern-keeper.
;;----------------------------------------------------------------------------
(define miggs-merch-msgs
  (list "Passez à la taverne quand je suis ouvert. J'ouvre à 7h et je ferme à minuit."
        "[Elle indique silencieusement un menu]"
        nil
        nil
        "Je vous remercie."
        "D'accord."
        ))

(define miggs-catalog
  (list
   (list t_food 5 "[Elle sert un ragoût à l'odeur délicieuse]")
   (list t_beer 3 "[Elle désigne un tonneau étiqueté 'La meilleure bière de Fenmire']")
  ))

(define (miggs-trade knpc kpc) (conv-trade knpc kpc "buy" miggs-merch-msgs miggs-catalog))

(define (miggs-hail knpc kpc)
  (kern-print "[Vous rencontrez une grande femme avec un joli visage. Elle évite timidement "
              "votre regard]\n"))

(define (miggs-job knpc kpc)
  (say knpc "Je dirige cette taverne, Le Pichet Vigoureux."))

(define (miggs-lust knpc kpc)
  (say knpc "C'est une taverne. Tu veux quelque chose ?")
  (if (kern-conv-get-yes-no? kpc)
      (miggs-trade knpc kpc)
      (say knpc "D'accord")))

(define miggs-conv
  (ifc basic-conv
       ;; default if the only "keyword" which may (indeed must!) be longer than
       ;; 4 characters. The 4-char limit arises from the kernel's practice of
       ;; truncating all player queries to the first four characters. Default,
       ;; on the other hand, is a feature of the ifc mechanism (see ifc.scm).
       (method 'default (lambda (knpc kpc) (say knpc "[Elle hausse les épaules]")))
       (method 'bonj miggs-hail )
	   (method 'hail miggs-hail )
	   
       (method 'adie (lambda (knpc kpc) (say knpc "[Elle sourit légèrement]")))
       (method 'trav miggs-job )       
       (method 'nom (lambda (knpc kpc) (say knpc "Miggs")))

       (method 'comm miggs-trade )
       (method 'ache miggs-trade )
       (method 'nour miggs-trade )
       (method 'vigo miggs-lust )
       (method 'pich miggs-lust )
       ))

;;----------------------------------------------------------------------------
;; First-time constructor
;;----------------------------------------------------------------------------
(define (mk-miggs tag)
  (bind 
   (kern-mk-char tag                 ; tag
                 "Miggs"            ; name
                 sp_human            ; species
                 nil                 ; occ
                 s_fat_townswoman    ; sprite
                 faction-men         ; starting alignment
                 2 0 0             ; str/int/dex
                 0 0                 ; hp mod/mult
                 0 0                 ; mp mod/mult
                 max-health -1 max-health 0 3  ; hp/xp/mp/AP_per_turn/lvl
                 #f                  ; dead
                 'miggs-conv        ; conv
                 sch_miggs          ; sched
                 'townsman-ai                 ; special ai
                  nil                ; container
                 (list t_dagger)                 ; readied
                 )
   (miggs-mk)))
