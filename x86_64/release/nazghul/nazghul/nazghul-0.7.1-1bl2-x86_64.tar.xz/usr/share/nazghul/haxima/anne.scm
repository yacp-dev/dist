;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------
(define anne-lvl 4)
(define anne-species sp_human)
(define anne-occ oc_wizard)

;;----------------------------------------------------------------------------
;; Schedule
;; 
;; In Paladin's Hold, in the Keep guarding Kurpolis.
;;----------------------------------------------------------------------------
(define anne-bed ph-bed2)
(define anne-mealplace ph-tbl2)
(define anne-workplace ph-medik)
(define anne-leisureplace ph-dine)
(kern-mk-sched 'sch_anne
               (list 0  0 anne-bed          "dort")
               (list 7  0 anne-mealplace    "mange")
               (list 8  0 anne-workplace    "travaille")
               (list 12 0 anne-mealplace    "mange")
               (list 13 0 anne-workplace    "travaille")
               (list 18 0 anne-mealplace    "mange")
               (list 19 0 anne-leisureplace "suis en pause")
               (list 22 0 anne-bed          "dort")
               )

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (anne-mk) nil)

;;----------------------------------------------------------------------------
;; Conv
;; 
;; Anne is a female White Magick mage serving as a medik 
;; in the service of Glasdrin.  
;; She currently serves in the Paladin's Hold of the Keep guarding Kurpolis.
;;----------------------------------------------------------------------------

;; Basics...
(define (anne-name knpc kpc)
  (say knpc "Je m'appelle Anne."))

(define (anne-job knpc kpc)
  (say knpc "Je suis un medecin au service de Glasdrin. Avez-vous besoin d'une guerison ?")
  (if (yes? kpc)
      (anne-trade knpc kpc)))

(define (anne-trade knpc kpc)
  (if (trade-services knpc kpc
                      (list
                       (svc-mk "guerir" 30 heal-service)
                       (svc-mk "soigner" 30 cure-service)
                       (svc-mk "Ressusciter" 100 resurrect-service)))
      (begin
        (say knpc "Que puis-je faire d'autre pour vous ?")
        (anne-trade knpc kpc))
      (begin
        (say knpc "Y aura-t-il autre chose ?")
        (if (kern-conv-get-yes-no? kpc)
            (anne-trade knpc kpc)
            (say knpc "Très bien.")))))

(define (anne-medik knpc kpc)
  (say knpc "Je soigne les paladins qui sont blessés au combat. Je guerirai aussi d'autres personnes, moyennant un certain prix."))

(define (anne-kurp knpc kpc)
  (say knpc "C'est un endroit sauvage, pas pour les inexpérimentés. Plus on s'enfonce, plus la situation empire."))

(define anne-conv
  (ifc kurpolis-conv

       ;; basics
       (method 'trav anne-job )
       (method 'nom anne-name )
       
       ;; trade
       (method 'echa anne-trade )
       (method 'guer anne-trade )
	   (method 'soin anne-trade )
	   (method 'soig anne-trade )
       (method 'prix anne-trade )

       (method 'mede anne-medik )
       (method 'kurp anne-kurp )
       ))

(define (mk-anne)
  (bind 
   (kern-mk-char 
    'ch_anne           ; tag
    "Anne"             ; name
    anne-species         ; species
    anne-occ              ; occ
    s_companion_wizard     ; sprite
    faction-men      ; starting alignment
    1 3 2            ; str/int/dex
    0 0              ; hp mod/mult
    0 0              ; mp mod/mult
    max-health ; hp
    -1                   ; xp
    max-health ; mp
    0
    anne-lvl
    #f               ; dead
    'anne-conv         ; conv
    sch_anne           ; sched
    'townsman-ai              ; special ai
    nil              ; container
    (list t_sword
					         t_armor_leather
					         )               ; readied
    )
   (anne-mk)))
