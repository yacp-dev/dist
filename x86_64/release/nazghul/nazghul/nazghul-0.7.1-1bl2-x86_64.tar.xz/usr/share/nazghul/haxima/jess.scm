;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------

;;----------------------------------------------------------------------------
;; Schedule
;; 
;; In Glasdrin.
;;----------------------------------------------------------------------------
(kern-mk-sched 'sch_jess
               (list 0  0  gj-bed      "dort")
               (list 7  0  ghg-counter "travaille")
               (list 9  0  g-fountain  "suis en pause")
               (list 10 0  ghg-counter "travaille")
               (list 13 0  gc-hall     "suis en pause")
               (list 14 0  ghg-counter "travaille")
               )

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (jess-mk) (list 'townsman))

;;----------------------------------------------------------------------------
;; Conv
;; 
;; Jess is the female proprietress of the Holy Grail tavern in Glasdrin.
;; Her face is scarred, the result of an encounter with goblins 
;; when serving as a crossbowman in the Glasdrin militia.
;;----------------------------------------------------------------------------

;; Basics...
(define (jess-hail knpc kpc)
  (if (string=? "travaille" (kern-obj-get-activity knpc))
      (say knpc "[Vous rencontrez une jeune femme par ailleurs séduisante avec une  "
           "cicatrice hideuse sur un côté de son visage]. Détendez-vous, messieurs, vous avez enfin "
           "trouvé le Saint Graal !")
      (say knpc "[Vous rencontrez une jeune femme par ailleurs séduisante avec une "
           "cicatrice hideuse sur un côté de son visage]. Belle journée, n'est-ce pas ?")))

(define (jess-default knpc kpc)
  (say knpc "Hm... Je ne sais pas."))

(define (jess-name knpc kpc)
  (if (working? knpc)
      (say knpc "Je suis Jess, propriétaire de cette oasis.")
      (say knpc "Je m'appelle Jess, propriétaire du Saint Graal. "
           "Venez à un moment où vous avez soif.")))

(define (jess-join knpc kpc)
  (say knpc "Non merci, j'ai assez d'action en jetant dehors les ivrognes et "
       "en mettant fin aux disputes."))

(define (jess-job knpc kpc)
  (say knpc "Je tente les faibles d'esprit avec mes marchandises. Vous voulez les voir ?")
  (if (kern-conv-get-yes-no? kpc)
      (begin
        (say knpc "[Elle fait un clin d'oeil] Je pensais que vous le feriez!")
        (jess-trade knpc kpc))
      (say knpc "Dommage.")))

(define (jess-bye knpc kpc)
  (say knpc "A bientôt, revenez nous voir !"))

(define jess-catalog
  (list
   (list t_food 7  "Les paladins aiment mon rôti de boeuf.")
   (list t_beer 12 "Prenez un Graal !")
   ))

(define jess-merch-msgs
  (list "Passez par le Saint Graal quand je travaille. Le petit déjeuner est servi entre 7h et 9h, le déjeuner entre 10h et 13h et je rouvre à 14h jusqu'à minuit."
        "Voici le menu !"
        nil ;; sell
        nil ;; trade
        "Régalez-vous !" ;; sold-something
        "Eh bien, c'est mieux que les coups durs !" ;; sold-nothing
        nil ;; the rest are nil
        ))

;; Trade...
(define (jess-buy knpc kpc) (conv-trade knpc kpc "buy" jess-merch-msgs jess-catalog))

;; Holy Grail
(define (jess-grai knpc kpc)
  (say knpc "Selon la légende, un Vagabond aurait suggéré le nom. "
       "Ce nom était basé sur une histoire populaire de son monde natal."))

;; Scar
(define (jess-scar knpc kpc)
  (say knpc "J'ai eu la courtoisie de quelques gobelins des cavernes et d'un gardien qui "
       "ne pouvait pas rester éveillé. Ils nous ont tendu une embuscade pendant que nous dormions, "
       "J'ai reçu la lame d'une hache sur la joue, mais mon casque a pris "
       "le plus gros des dégats. Aimez-vous les histoires de batailles ?")
  (if (kern-conv-get-yes-no? kpc)
      (say knpc "Tout le monde en ville en a au moins une. Nous avons tous servi.")
      (say knpc "Dommage, parce que c'est l'endroit pour les entendre.")))

(define (jess-serv knpc kpc)
  (say knpc "Tous les citoyens de Glasdrin doivent effectuer une période de service."
       "J'étais arbalétrier, mon travail consistait à soutenir l'armure lourde par "
       "derrière. Ma tenue a servi sur les marches de l'est de la Grande Foret."))

(define (jess-wood knpc kpc)
  (say knpc "Les rangers gardent les choses bien en main, mais cette année-là "
       "les gobelins des cavernes et les trolls ont sortis en force."))

;; Townspeople...
(define (jess-glas knpc kpc)
  (say knpc "C'est un endroit assez agréable, vu que c'est un camp armé."))

(define (jess-ange knpc kpc)
  (say knpc "Une gentille dame. Pas vraiment une battante, mais elle fait de son mieux."))

(define (jess-patc knpc kpc)
  (say knpc "Un sale vieux ! Non, c'est juste pour taquiner."))

(define jess-conv
  (ifc glasdrin-conv

       ;; basics
       (method 'default jess-default )
       (method 'bonj jess-hail )
	   (method 'hail jess-hail )
	   
       (method 'adie jess-bye )
       (method 'trav jess-job )
       (method 'nom jess-name )
       (method 'join jess-join )
       
       ;; trade
       (method 'graa jess-grai )
       (method 'sain jess-grai )
       (method 'comm jess-buy )
       (method 'cham jess-buy )
       (method 'ache jess-buy )
       

       ;; scar
       (method 'cica jess-scar )
       (method 'serv jess-serv )
       (method 'fore jess-wood )

       ;; town & people
       (method 'glas jess-glas )
       (method 'ange jess-ange )
       (method 'patc jess-patc )

       ))

(define (mk-jess)
  (bind 
   (kern-mk-char 'ch_jess           ; tag
                 "Jess"             ; name
                 sp_human            ; species
                 nil                 ; occ
                 s_townswoman        ; sprite
                 faction-glasdrin         ; starting alignment
                 0 0 1               ; str/int/dex
                 0 0                 ; hp mod/mult
                 0 0                 ; mp mod/mult
                 max-health -1 max-health 0 3  ; hp/xp/mp/AP_per_turn/lvl
                 #f                  ; dead
                 'jess-conv         ; conv
                 sch_jess           ; sched
                 'townsman-ai                 ; special ai
                 (mk-inventory (list (list 1 t_dagger)))                 ; container
                 nil                 ; readied
                 )
   (jess-mk)))
