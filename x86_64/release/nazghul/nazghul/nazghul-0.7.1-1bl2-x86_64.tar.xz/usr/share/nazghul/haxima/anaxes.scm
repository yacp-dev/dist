;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------
(define anaxes-lvl 6)
(define anaxes-species sp_lich)
(define anaxes-occ oc_wizard)

;;----------------------------------------------------------------------------
;; Schedule
;; 
;; No schedule (Cave Shrine within Brundegart).
;;----------------------------------------------------------------------------

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (anaxes-mk) nil)

;;----------------------------------------------------------------------------
;; Conv
;; 
;; Anaxes is the lich/shade of a long-dead wizard, who once served 
;; Luximène and later rebelled against him.
;; Anaxes abides in the Cave Shrine within the lost realm of Brundegart.
;;----------------------------------------------------------------------------

;; Basics...
(define (anaxes-hail knpc kpc)
  (meet "[Vous rencontrez l'ombre fière d'un magicien mort depuis longtemps]")
  (say knpc "Es-tu l'agent de Luximène ?")
  (if (yes? kpc)
      (say knpc "Mais qui d'autre ? [Il rit sinistrement] "
           "Tu as brisé les defenses, "
           "mais ton maître infâme ne me trouvera pas édenté !")
      (say knpc "Ne le niez pas, je sais qu'il cherche à me tuer pour ma rébellion !"))
  (aside kpc 'ch_nate 
         "[Murmures] Monseigneur, Luximène est mort depuis des lustres !")
  )


(define (anaxes-default knpc kpc)
  (say knpc "[Il vous regarde en silence]"))

(define (anaxes-name knpc kpc)
  (say knpc "Je suis Anaxes, anciennement des Douzes."))

(define (anaxes-luxi knpc kpc)
  (say knpc "Luximène n'est pas un homme, mais un démon avec un masque ! "
       "Il a semé la dissidence et conquis dans son sillage, "
       "et cherche maintenant à détrôner les dieux.")
  (prompt-for-key)
  (say knpc "Il a ordonné que sa propre image soit érigée dans les sanctuaires. "
       "C'en est trop ! Maintenant, sa perfidie est évidente ! ")
  (prompt-for-key)
  (say knpc "Tant que je respirerai, le sanctuaire de Brune ne sera pas souillé !")
  (aside kpc 'ch_nate "Ah ! Le nom du dieu enfin ! Je craignais qu'il ne soit oublié à jamais !")
  (cond ((has? kpc t_lich_skull 1)
         (say knpc "Attendez ! Qu'est-ce que vous avez là ? [Il montre le crâne de Luximène] Qu'est-ce que cela signifie ? Luximène est-il donc mort ?")
         (yes? kpc)
         (say knpc "[Il vous ignore. La lumière dans ses yeux commence à s'éteindre et sa voix s'affaiblit] C'est fini...")
         (prompt-for-key kpc)
         (say knpc "[Il s'effondre en un tas] ... ")
         (aside kpc 'ch_nate "Droit dans ses bottes.")
         (kern-conv-end)
         (kern-char-kill knpc))))

(define (anaxes-gods knpc kpc)
  (say knpc "Les dieux se vengeront terriblement sur le Tesson pour son "
       "infidélité ! Luximène et ses disciples seront consumés par le feu et "
       "noyés dans le sang lors de la dernière bataille ! "
       "Vigilance pour les fidèles !"))

(define (anaxes-brun knpc kpc)
  (say knpc "C'est le sanctuaire de Brune, dieu de la vigilance. "
       "Je me suis rebellé contre l'ordre de Luximène pour le déshonorer avec son image. "
       "J'ai ordonné que l'entrée de la garde de Brune soit scellée, et j'ai attendu le siège. ")
  )

(define (anaxes-vigi knpc kpc)
  (say knpc "Nous avons failli à notre devoir de vigilance ! "
       "Luximène nous a tous trompés, et maintenant nous devons payer le prix de l'échec."))

(define (anaxes-fail knpc kpc)
  (say knpc "Nous avons failli aux dieux, il n'est pas étonnant qu'ils nous aient abandonnés !"))

(define (anaxes-twel knpc kpc)
  (say knpc "J'étais parmi les douze conseillers de Luximène. "
       "A ma grande honte, je l'ai aidé à réaliser son empire. "
       "Je pensais qu'un chef fort apporterait de l'ordre au Tesson, "
       "et freiner l'hérésie des Maudits. "
       "Hélas ! Nous avons tous été trompés !"))

(define (anaxes-accu knpc kpc)
  (say knpc "Dans les années qui ont suivi la Scission, "
       "le sacerdoce est devenu corrompu. "
       "Toutes sortes d'hommes misérables prétendaient parler au nom des dieux, "
       "polluant le culte des dieux par leurs pratiques infâmes. ")
  (prompt-for-key)
  (say knpc "Sous Luximène, nous avons fait la guerre aux hérétiques. "
       "Nous avons brûlé les faux prêtres sur le bûcher et mis leur "
       "vermine d'adeptes à l'épée. "))

(define (anaxes-bye knpc kpc)
  (say knpc "Sur tes gardes, profanateur du Saint ! Je te résisterai ; "
       "et si je dois tomber au combat, je frapperai d'au-delà de la tombe !")
  (aside kpc 'ch_nate "[Marmonnant] Je pense qu'il est en avance sur son temps.")
  (kern-being-set-base-faction knpc faction-monster)
  )

(define (anaxes-job knpc kpc)
  (say knpc "J'étais l'un des Douze de Luximène, à qui l'on a confié le commandement de "
       "cette forteresse et sa tour de guet. "
       "Mais Luximène a ordonné la profanation des sanctuaires, "
       "et je me suis révolté !")
  (aside kpc 'ch_nate 
         "[Chuchotement] Cette liche se prend pour un sorcier vivant au temps de Luximène. Se peut-il qu'il l'ait été autrefois ?")
  )

(define (anaxes-fort knpc kpc)
  (say knpc "Cette forteresse est la garde de Brune, ainsi nommée pour ce Sanctuaire de Brune, "
       "et pour la vigilance de la tour. Il est pratiquement imprenable de l'assiéger."))

(define (anaxes-towe knpc kpc)
  (say knpc "La tour de guet de la garde de Brune regarde au loin, au-dessus de la mer, de la forêt, "
       "des montagnes, et dans les profondeurs du ciel. Du temps au-delà de la mémoire,  "
       "avant la Scission, les vigilants ont veillé ici pour "
       "le danger d'en bas ou des signes d'en haut."))

(define (anaxes-sund knpc kpc)
  (say knpc "Le Scission est le cataclysme qui a failli détruire ce monde. "
       "Tu le sais certainement ! "
       "A moins que tu ne sois un démon venu d'au-delà du néant ..."))

(define anaxes-conv
  (ifc nil

       ;; basics
       (method 'maud anaxes-accu )
       (method 'assa anaxes-luxi )
       (method 'adie anaxes-bye )
       (method 'brun anaxes-brun )
       (method 'default anaxes-default )
       (method 'defe anaxes-fort )
       (method 'fail anaxes-fail )
       (method 'fide anaxes-vigi )
       (method 'fort anaxes-fort )
       (method 'dieu anaxes-gods )
       (method 'dieu anaxes-gods )
       (method 'bonj anaxes-hail )
	   (method 'hail anaxes-hail )
       (method 'trav anaxes-job )
       (method 'luxi anaxes-luxi )
       (method 'mast anaxes-luxi )
       (method 'nom anaxes-name )
       (method 'rebe anaxes-luxi )
       (method 'sanc anaxes-vigi )
       (method 'scis anaxes-sund )
       (method 'tour anaxes-towe )
       (method 'douz anaxes-twel )
       (method 'vigi anaxes-vigi )
       ))

(define (mk-anaxes)
  (let ((kchar
         (bind 
          (kern-char-force-drop
           (kern-mk-char 
            'ch_lux          ; tag
            "Anaxes"         ; name
            anaxes-species   ; species
            anaxes-occ       ; occ
            s_lich           ; sprite
            faction-men      ; starting alignment
            0 0 0            ; str/int/dex
            0 0              ; hp mod/mult
            0 0              ; mp mod/mult
            max-health       ; hp
            -1               ; xp
            max-health       ; mp
            0
            anaxes-lvl       ; level
            #f               ; dead
            'anaxes-conv     ; conv
            nil              ; sched
            'lich-ai         ; special ai
            (mk-inventory
             ;; hack: as the kernel is currently written, he won't drop his
             ;; readied arms on death, and he won't ready arms from inventory
             ;; (its all messed up), but he will drop his inventory. So put
             ;; some decent arms in as loot.
             (list (list 1 t_armor_chain)
                   (list 1 t_chain_coif)
                   (list 1 t_morning_star)
                   (list 1 t_shield)
                   (list 3 mandrake)
                   (list 3 nightshade)
                   (list 8 sulphorous_ash)
                   (list 5 blood_moss)
                   (list 5 black_pearl)
                   (list 50 t_gold_coins)
                   (list 1 t_anaxes_letter)
                   (list 1 t_lichs_blood)
                   ))
            ;; readied
            (list
             t_armor_chain_4
             t_chain_coif_4
             t_morning_star_2
             t_shield_4
             )
            ) ; kern-mk-char
           #t) ; kern-char-force-drop
          (anaxes-mk)) ; bind
         ))
    (map (lambda (eff) (kern-obj-add-effect kchar eff nil))
         undead-effects)
    kchar))
