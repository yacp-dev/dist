;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;
;; Quest Data Table
;;
;; The basic quest data mechanism is based on a tbl of quest information. This allows quests
;; to be created once, then tracked and updated from a central repository.
;; While not suitable for quests generated on the fly, this is a lot more convenient for
;; complex plot based quests. On the fly quests can still interface directly with the
;; quest-sys module.
;;
;; The questadd function here handles creation of quests (it also makes sure the quest is
;; created iff it is needed, so savegames have some chance of updating right)
;;
;; It is inside a let definition, and hence wont work elsewhere. The quest to be added is
;; a quest using qst-mk from the quest-sys module
;;
;; (questadd (qst-mk
;;    "Name of Quest"
;;    'tag-to-refer-to-quest
;;    "Text description of quest, probably using kern-ui-paginate-text"
;;    'function-called-on-quest-assignment  ;; probably 'quest-assign-notify, or nil
;;    'function-called-before-quest-is-displayed  ;; probably nil
;;    'sprite-for-quest
;;    quest-payload
;;	)
;;
;; The various quest-data-* methods assume that quest-payload is a tbl, containing various
;; info possibly including:
;;
;; 		'on-update  a method name that )will be called in response to a quest-data-update call
;;		'bonus-xp   a storage space for experience rewards that are accrued before the player
;;					knows about the quest (the xp will increase the rewards given once the
;;					the player knows why they are being given xp)
;;
;;
;; Using quests basically boils down to:
;;      defining the quest here
;;      adding a (quest-data-assign-once 'tag-to-refer-to-quest) at the relevent place in the game code
;;      adding a (quest-data-complete 'tag-to-refer-to-quest)
;;                                   at the relevent place in the game code
;;		
;;		for nicely updating quest information, add the on-update method as described )above, and sprinkle
;;      the plot with
;;          (quest-data-update 'tag-to-refer-to-quest 'name-of-quest-flag value-to-set-tag-to)
;;             and
;;          (quest-data-update-with 'tag-to-refer-to-quest 'name-of-quest-flag value-to-set-tag-to
;;                  function-to-perform-if-the-tag-wasnt-already-set-that-way)
;;      a common example of the latter would be giving the party an xp reward:
;;          (quest-data-update-with 'tag-to-refer-to-quest 'name-of-quest-flag value-to-set-tag-to
;;                  (grant-party-xp-fn amount-of-xp-to-share-out))
;;
;;

(let*
	(
		(newtbl (tbl-mk))
		(oldtbl (tbl-get (gob (kern-get-player)) 'questdata))
		(questdata (if (null? oldtbl)
						(begin 
							(tbl-set! (gob (kern-get-player)) 'questdata newtbl)
							newtbl
						)
						oldtbl))
		(questadd (lambda (quest)
			(if (null? (tbl-get questdata (qst-tag quest)))
				(tbl-set! questdata (qst-tag quest) quest)
			)))
	)
	
(questadd (qst-mk 
	"Création de personnage"
	'questentry-charcreate
	(kern-ui-paginate-text
		"Déplacez-vous vers la porte de la lune, au nord de la salle, "		"pour commencer le jeu, et en cours de route, vous devrez indiquer le nom de votre personnage. "		"Vous pouvez également personnaliser vos attributs en parlant aux statues de la salle."
	)
	'quest-assign-notify
	'quest-status-inprogress
	's_quest_start
	0
))

(questadd (qst-mk "Où suis-je ?"
	'questentry-whereami
	(kern-ui-paginate-text
		"Vous vous êtes retrouvé dans un monde que vous ne connaissez pas, "		"avec des impressions très sommaires de ce qui aurait pu se passer avant. "		"Où êtes-vous ? Comment et pourquoi êtes-vous ici ? Et qu'allez-vous faire maintenant ?"
	)
	'quest-assign-notify
	'quest-status-inprogress
	's_quest_start
	(tbl-build
		'on-update 'quest-whereami-update
		)
	;; 'shard- pc knows about shard(1), cosmology(2)
	;; 'wanderer- pc knows about wanderers(1), potential(2)
	;; 'nossifer- pc knows about N's summoning(3)
))

(questadd (qst-mk "L'appel aux armes"
	'questentry-calltoarms
	(kern-ui-paginate-text
		"Vous avez reçu un message urgent vous invitant à contacter dès que possible "		"une personne appelée l'Enchanteur et à demander votre chemin au gardien de la clairière "		"dans laquelle vous êtes arrivé."
	)
	'quest-assign-notify
	'quest-status-inprogress
	's_enchanter
	(tbl-build
		'on-update 'quest-calltoarms-update
		'bonus-xp 0
		)
	;; 'directions- pc has directions to tower
	;; 'tower- pc has reached tower
	;; 'talked- pc has talked to the enchanter
	;; 'done- pc has been enlisted
))
	
(questadd (qst-mk "Attraper un voleur"
	'questentry-thiefrune
	(kern-ui-paginate-text
		"L'Enchanteur vous a demandé d'enquêter sur un vol commis dans sa tour. "		"Le ^c+mvoleur^c- a été suivi jusqu'à Trigrave. "		"Les habitants de la ville pourront peut-être vous donner de plus amples informations."
	)
	'quest-assign-notify
	'quest-status-inprogress
	's_brigand
	(tbl-build
		'on-update 'quest-thiefrune-update
		'bonus-xp 0
		)
	;; '
	;; 'tower- pc has reached tower
	;; 'talked- pc has talked to the enchanter
	;; 'done- pc has been enlisted
))

(questadd (qst-mk "Le secret des Runes"
	'questentry-runeinfo
	(kern-ui-paginate-text
		"La rune volée que vous avez récupérée doit avoir une grande importance pour qu'elle soit volée. "		"L'Enchanteur vous a chargé de rechercher cette raison et vous suggère de commencer avec l'^c+Alchimiste^c-, "		"que vous trouverez peut-être à Oparine."
	)
	'quest-assign-notify
	'quest-status-inprogress
	's_runestone_k
	(tbl-build
		'on-update 'quest-runeinfo-update
		'bonus-xp 0
		)
))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; runes questgroup

(questadd (qst-mk "La recherche des Runes"
	'questentry-allrunes
	(kern-ui-paginate-text
		"L'enchanteur croit que les Maudits cherchent les runes à des fins néfastes. C'est à vous de les collecter en premier."
	)
	'quest-assign-notify
	'quest-status-inprogress
	's_runestone_group
	(tbl-build
		;;'on-update 'quest-allrunes-update
		'bonus-xp 0
		)
))

;; TODO- alternate path in which the rune is lost?
(questadd (qst-mk "Une Rune en main"
	'questentry-rune-k
	(kern-ui-paginate-text
		"La Rune de la Connaissance appartient à l'Enchanteur. Vous pourrez peut-être le convaincre de vous la remettre."
	)
	'quest-assign-notify
	'quest-status-inprogress
	's_runestone_k
	(tbl-build
		'on-update 'quest-rune-k-update
		'entrusted-with-rune 0
		'player-got-rune 0
		'ench-should-have-rune 0
		'bonus-xp 0
		)
))

(questadd (qst-mk "Une rune dans les profondeurs"
	'questentry-rune-p
	(kern-ui-paginate-text
		"L'alchimiste vous a fourni des informations sur une rune enterrée dans les profondeurs de Kurpolis."
	)
	'quest-assign-notify
	'quest-status-inprogress
	's_runestone_r
	(tbl-build
		'on-update 'quest-rune-p-update
		'bonus-xp 0
		)
))

(questadd (qst-mk "La rune d'un soldat"
	'questentry-rune-l
	(kern-ui-paginate-text
		"L'une des runes est portée par la Warritrix."
	)
	'quest-assign-notify
	'quest-status-inprogress
	's_runestone_r
	(tbl-build
		'on-update 'quest-rune-l-update
		'bonus-xp 0
		'located 0
		'know-hall 0
		'approx-hall 0
		)
))

(questadd (qst-mk "Une rune perdue"
	'questentry-rune-f
	(kern-ui-paginate-text
		"Le roi Clovis possédait autrefois une rune, mais il fut tué pendant les guerres des gobelins."
	)
	'quest-assign-notify
	'quest-status-inprogress
	's_runestone_r
	(tbl-build
		'on-update 'quest-rune-f-update
		'bonus-xp 0
		)
))

(questadd (qst-mk "Une rune dans le Néant"
	'questentry-rune-d
	(kern-ui-paginate-text
		"Les légendes parlent d'un temple dans le Néant, qui abritait une rune."
	)
	'quest-assign-notify
	'quest-status-inprogress
	's_runestone_r
	(tbl-build
		'on-update 'quest-rune-d-update
		'bonus-xp 0
		)
))

(questadd (qst-mk "Une rune dans le feu"
	'questentry-rune-w
	(kern-ui-paginate-text
		"Une rune a été trouvée parmi le trésor d'un dragon caché dans la Mer de Feu."
	)
	'quest-assign-notify
	'quest-status-inprogress
	's_runestone_r
	(tbl-build
		'bonus-xp 0
		)
))

(questadd (qst-mk "Une rune dans les ruines"
	'questentry-rune-s
	(kern-ui-paginate-text
		"Une rune se trouve dans la Vieille Absalot, sous les ruines."
	)
	'quest-assign-notify
	'quest-status-inprogress
	's_runestone_r
	(tbl-build
		;;'on-update 'quest-allrunes-update
		'bonus-xp 0
		)
))

(questadd (qst-mk "Une rune dans la mer"
	'questentry-rune-c
	(kern-ui-paginate-text
		"Une rune appartenait autrefois au pirate Ghertie."
	)
	'quest-assign-notify
	'quest-status-inprogress
	's_runestone_r
	(tbl-build
		'on-update 'quest-rune-c-update
		'bonus-xp 0
		)
))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; wise questgroup

(questadd (qst-mk "Les Sages"
	'questentry-wise
	(kern-ui-paginate-text
		"Les Sages ont une grande influence sur les affaires du Tesson. Les trouver peut être essentiel à votre succès."
	)
	'quest-assign-notify
	'quest-status-inprogress
	's_quest_wise
	(tbl-build
		;;'on-update 'quest-wise-update
		)
))

(questadd (qst-mk "L'Enchanteur"
	'questentry-enchanter
	(kern-ui-paginate-text
		"L'Enchanteur est un grand sorcier, un des Sages de l'époque actuelle."
	)
	'quest-assign-subquest
	'quest-status-inprogress
	's_enchanter
	(tbl-build
		;;'on-update 'quest-enchanter-update
		'qparent 'questentry-wise
		)
))

(questadd (qst-mk "L'Alchimiste"
	'questentry-alchemist
	(kern-ui-paginate-text
		"L'Alchimiste est l'un des Sages."
	)
	'quest-assign-subquest
	'quest-status-inprogress
	's_companion_tinker
	(tbl-build
		;;'on-update 'quest-alchemist-update
		'qparent 'questentry-wise
		)
))

(questadd (qst-mk "Le MEC"
	'questentry-the-man
	(kern-ui-paginate-text
		"Le MEC est l'un des Sages."
	)
	'quest-assign-subquest
	'quest-status-inprogress
	's_companion_bard
	(tbl-build
		;;'on-update 'quest-the-man-update
		'qparent 'questentry-wise
		)
))

(questadd (qst-mk "L'Ingénieur"
	'questentry-engineer
	(kern-ui-paginate-text
		"L'Ingénieur est l'un des Sages."
	)
	'quest-assign-subquest
	'quest-status-inprogress
	's_companion_tinker
	(tbl-build
		;;'on-update 'quest-engineer-update
		'qparent 'questentry-wise
		)
))

(questadd (qst-mk "Le Nécromancien"
	'questentry-necromancer
	(kern-ui-paginate-text
		"Le Nécromancien est l'un des Sages."
	)
	'quest-assign-subquest
	'quest-status-inprogress
	's_black_mage
	(tbl-build
		;;'on-update 'quest-necromancer-update
		'qparent 'questentry-wise
		)
))

(questadd (qst-mk "La Warritrix"
	'questentry-warritrix
	(kern-ui-paginate-text
		"La Warritrix est l'un des Sages."
	)
	'quest-assign-subquest
	'quest-status-inprogress
	's_avatar
	(tbl-build
		'on-update 'quest-warritrix-update
		'qparent 'questentry-wise
		)
		;;'name - knows existance, but no info
		;;'common - basic info
		;;'general-loc - common knowledge info
		;;'assignment - failed to find her
		;;'lost-hall - where she has been sent
		;;'lost-hall-loc - additionally, knows location of hall
		;;'slain - indirect evidence of her fall
		;;'reached - reached location of corpse - used by losthalls mechs
		;;'found - located corpse
		;;'avenged - completed justice quest TODO- pull from that quest info instead
))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(questadd (qst-mk "Une auberge hantée"
	'questentry-ghertie
	(kern-ui-paginate-text
		"Un fantôme hante l'auberge d'Oparine. Pourquoi s'y attarde-t-il dans la non-mort ?"
	)
	'quest-assign-notify
	'quest-status-inprogress
	's_ghost
	(tbl-build
		'on-update 'quest-ghertie-update
		;; ghertieloc  - gherties loc
		;; ghertieid - ghertie info
		;; revenge	- gherties trigger
		;; questinfo - quest info revealed
		;; meaney-loc - location of meaney
		;; ring-meaney - got ring from meaney
		;; jorn-forest - rough info on jorn
		;; jorn-loc - jorn found
		;; ring-jorn - got ring from jorn
		;; gholet-prison - rough info on gholet
		;; gholet-glasdrin - found gholet
		;; gholet-price - gholets offer for ring
		;; ring-gholet - got ring from gholet
		)
))

(questadd (qst-mk "Le prix du sang : le Dragon"
	'questentry-dragon
	(kern-ui-paginate-text
		"L'alchimiste a proposé de vous échanger des informations sur le lieu où se trouve une rune, en échange du sang d'un dragon."
	)
	'quest-assign-notify
	'quest-dragon-update
	's_dragon_party
	(tbl-build
		)
))

(questadd (qst-mk "Une justice de soldat"
	'questentry-warrjustice
	(kern-ui-paginate-text
		"La Warritrix a été tuée par trahison. Ce crime restera-t-il impuni ?"
	)
	'quest-assign-subquest
	'quest-status-inprogress
	's_ghost
	(tbl-build
		'on-update 'quest-warrjustice-update
		)
		;;'statue - info about statue
		;;'book - info about journal
		;;'havejournal - found journal
		;;'avenged - completed justice quest
))

(questadd (qst-mk "problèmes de bandits"
	'questentry-bandits
	(kern-ui-paginate-text
		"Gregor, un vieux brûleur de charbon, a demandé votre aide pour lutter contre les bandits qui sévissent dans la grande forêt. "		"Il suggère que les Rangers de la Tour Verte soient en mesure de vous aider dans cette tâche."
	)
	'quest-assign-notify
	'quest-status-inprogress
	's_brigand
	(tbl-build
         'on-update 'quest-bandits-update
         )
))

)

