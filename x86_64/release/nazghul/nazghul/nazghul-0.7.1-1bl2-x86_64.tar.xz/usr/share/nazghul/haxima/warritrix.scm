;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------
(define warr-lvl 8)
(define warr-species sp_ghast)
(define warr-occ oc_warrior)

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (warr-mk) (list 3))
(define (warr-must-go? gob) (= 0 (car gob)))
(define (warr-end-conv gob) (set-car! gob (- (car gob) 1)))

;;----------------------------------------------------------------------------
;; Conv
;; 
;; Clarissa (known as the Warritrix) was in life a powerful female Warrior
;; of superlative might and warcraft.  Now slain, she may be encountered
;; as a shade, summoned by the use of the Rune of Leadership,
;; found among her effects where her corpse lies (in the Broken Sanctuary
;; in the Lost Halls).
;;----------------------------------------------------------------------------

;; Basics...
(define (warr-hail knpc kpc)
  (meet "Le spectre d'une femme calme et majestueuse vous confronte.")
  (say knpc "Je vous salue, Vagabond.")
  (quest-data-update 'questentry-warritrix 'found 1)
  (quest-data-icon! 'questentry-warritrix 's_ghost)
  (quest-data-complete 'questentry-warritrix)
  )

(define (warr-name knpc kpc)
  (say knpc "J'étais Clarissa, connue par beaucoup sous le nom de Warritrix.")
  )

(define (warr-join knpc kpc)
  (say knpc "Si seulement nous nous étions rencontrés dans cette vie !")
  )

(define (warr-job knpc kpc)
  (say knpc "Pour servir la justice. Faites-vous de même ?")
  (if (yes? kpc)
      (begin
        (say knpc "Pour servir la justice, il faut savoir ce qui est juste. "
             "On m'a ordonné d'explorer complètement ces grottes, "
             "et quand mon équipe était faible pour combattre les monstres, "
             "nous avons été pris en embuscade par des assassins Maudits, et tous tués. "
             "Dites-moi, est-ce juste pour venger ma mort sur mes traîtres ?")
        (yes? kpc)
        (say knpc "La justice ne s'empresse pas de punir, mais plutôt de récompenser. "
             "Les traîtres seront récompensés par la ruine, "
             "Les comploteurs et les conspirateurs vont provoquer leur propre chute, "
             "ceux qui cherchent le pouvoir seront impuissants dans leur heure de besoin. "
             "Ne me vengez pas, mais cherchez plutôt la verité.")
        )
      (say knpc "L'injustice est bien servie par l'inaction."))
  )

(define (warr-trut knpc kpc)
  (say knpc "Pour trouver la verité, vous devez trouver des preuves."))

(define (warr-warr knpc kpc)
  (say knpc "C'était un titre que je portais pour gratifier les autres. "
       "En verité, je n'étais qu'un autre paladin."))

(define (warr-evid knpc kpc)
  (say knpc "Les Malfrats sont passés maîtres dans l'art de trouver ce que les autres essaient de cacher, "
       "et le MEC est maître de tous les malfrats.")
       (quest-wise-subinit 'questentry-the-man)
       (quest-data-update 'questentry-the-man 'common 1)
       )

(define (warr-wise knpc kpc)
  (say knpc "Les Sages sont trompés et divisés dans leurs opinions. "
       "Les Maudits ont bien fait leur travail."))

(define (warr-bye knpc kpc)
  (if (warr-must-go? (gob knpc))
      (begin
        (say knpc "Nous ne nous reverrons plus, Vagabond.")
        (kern-log-msg "Le spectre disparaît.")
        (kern-obj-remove knpc))
      (begin
        (say knpc "Vous m'avez demandé tout ce que vous vouliez savoir ?")
        (if (yes? kpc)
            (say knpc "Sachez que je dois partir bientôt, le grand Vide me rappelle.")
            (say knpc "Alors j'essaierai de rester un peu plus longtemps.")
            )
        (warr-end-conv (gob knpc)))))

;; Quest-related
(define (warr-rune knpc kpc)
  (say knpc "Gardez la Rune. Je ne connais pas son utilité. Je l'ai portée "
       "toutes ces années en mémoire au roi Clovis, mon parrain, "
       "qui me l'a donnée."))

(define (warr-clov knpc kpc)
  (say knpc "Le roi Clovis portait une rune de son vivant. Il est tombé au combat pendant "
       "les Guerres des Gobelins et la rune a été perdue. Vous souhaitez la retrouver ?")
  (if (yes? kpc)
  		(begin
      (say knpc "Si quelqu'un sait où il se trouve, ce sont bien les Gobelins. "
           "Allez à la Tour Verte et cherchez Gen. Demandez-lui à propos de ^c+mClovis^c-.")
       	(quest-data-update 'questentry-rune-f 'gen 1)
        (quest-data-assign-once 'questentry-rune-f)
           )
      (say knpc "Si vous le faites, demandez-moi maintenant, car comme tous ceux qui sont morts, je suis rappelée "
           "par le Grand Vide, et ne peut résister longtemps."
           ))
  )

(define (warr-just knpc kpc)
  (say knpc "La justice est le seul idéal qui n'a pas besoin de théorie "
       "ou de la philosophie ou de divinité pour la soutenir. "
       "C'est l'idéal indéniable, irrésistible."))

(define (warr-absa knpc kpc)
  (say knpc "La Regisseuse a ordonné la destruction d'Absalot "
       "sous prétexte qu'il répandait des pratiques des Maudits. "
       "Mais la soif de pouvoir n'est-elle pas le vrai signe d'un Maudit ?")
  (yes? kpc)
  (say knpc "En effet, c'est le cas.")
  )

(define (warr-void knpc kpc)
  (say knpc "Tous les esprits sont des Vagabonds dans le Vide."))

(define (warr-assa knpc kpc)
  (say knpc "Ils nous attendaient, même si personne ne savait que nous étions ici "
       "sauf la Regisseuse de Glasdrin et le commandant Jeffries."))

(define (warr-jeff knpc kpc)
  (say knpc "Les hauts exploits argentés de la noble jeunesse sont ternis par la culpabilité de "
       "l'époque. Mieux vaut quelqu'un qui lutte, meurt, qu'un héros ruiné "
       "par le succès et la réussite."))

(define (warr-powe knpc kpc)
  (say knpc 
       "Ceux qui voient un ennemi sur tous les visages n'ont jamais assez de pouvoir, "
       "mais les intrépides le méprisent."))

(define warr-conv
  (ifc basic-conv

       ;; basics
       (method 'bonj warr-hail )
	   (method 'hail warr-hail )
	   
       (method 'adie warr-bye )
       (method 'trav warr-job )
       (method 'nom warr-name )
       (method 'join warr-join )
       
       (method 'rune warr-rune )
       (method 'clov warr-clov )
       (method 'just warr-just )
       (method 'absa warr-absa )
       (method 'regi warr-absa )
       (method 'warr warr-warr )
       (method 'preu warr-evid )
       (method 'sage warr-wise )
       (method 'vide warr-void )
       (method 'veri warr-trut )
       (method 'assa warr-assa )
       (method 'jeff warr-jeff )
       (method 'pouv warr-powe )
       ))

(define (mk-warritrix)
  (bind 
   (kern-mk-char 
    'ch_warr           ; tag
    "Warritrix"        ; name
    warr-species         ; species
    warr-occ              ; occ
    s_ghost     ; sprite
    faction-men      ; starting alignment
    10 0 10            ; str/int/dex
    5 2              ; hp mod/mult
    5 2              ; mp mod/mult
    max-health ; hp
    -1                   ; xp
    max-health ; mp
    0  ;; AP_per_turn
    warr-lvl
    #f               ; dead
    'warr-conv         ; conv
    nil              ; schedule
    nil              ; special ai
    nil              ; container
    nil              ; readied
    )
   (warr-mk)))
