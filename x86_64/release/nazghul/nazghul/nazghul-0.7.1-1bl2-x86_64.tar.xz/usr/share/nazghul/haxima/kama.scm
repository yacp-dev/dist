;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------
(define kama-lvl 4)
(define kama-species sp_forest_goblin)
(define kama-occ oc_wrogue)
(define kama-exit-x 6)
(define kama-exit-y 2)

;;----------------------------------------------------------------------------
;; Schedule
;; 
;; In a prison cell in the dungeons below Green Tower.
;;----------------------------------------------------------------------------
(define kama-cell gtl-cell1)
(kern-mk-sched 'sch_kama
               (list 0  0 kama-cell        "dort")
               (list 7  0 kama-cell        "suis en pause")
               )

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (kama-mk jail-door-tag) (list #f #f jail-door-tag))
(define (kama-gave-food? gob) (car gob))
(define (kama-gave-food! gob) (set-car! gob #t))
(define (kama-joined-once? gob) (cadr gob))
(define (kama-joined-once! gob) (set-car! (cdr gob) #t))
(define (kama-get-jail-door-tag gob) (caddr gob))

;;----------------------------------------------------------------------------
;; Conv
;; 
;; Kama is a male Forest Goblin ranger, currently imprisoned below Green Tower.
;; A friend of Gen, Kama was enroute to a meeting, and detained due to 
;; some misadventure.
;; Kama is a potential party member, 
;; if the player can learn a bit of the Goblin language.
;;----------------------------------------------------------------------------

;; Basics...
(define (kama-default knpc kpc)
  (say knpc "[pas de réponse]"))

(define (kama-hail knpc kpc)
  (meet "Vous rencontrez un gobelin calme qui vous regarde avec un regard intrépide et calculateur.")
  (if (kama-gave-food? (gob knpc))
      (say knpc "Bonaha.")
      (say knpc "Nuki?")
      ))

(define (kama-bye knpc kpc)
  (say knpc "[son expression ne change pas]"))

;; No == Name
(define (kama-no knpc kpc)
  (if (kama-gave-food? (gob knpc))
      (say knpc "[Il se désigne lui-même] Kama.")
      (kama-default knpc kpc)))

;; Me == Job
(define (kama-me knpc kpc)
  (if (not (kama-gave-food? (gob knpc)))
      (kama-default knpc kpc)
      (begin
        (say knpc "Ninto. [Il vous désigne] Zuto ?")
        (if (yes? kpc)
            (say knpc "[Il hoche la tête]")
            (say knpc "[Il ricane comme s'il ne vous croyait pas]")))))

;; Jo == Join
(define (kama-jo knpc kpc)
  (define (exit-point)
    (mk-loc (kobj-place knpc)
            kama-exit-x
            kama-exit-y))
  (define (door-still-locked?)
    (let ((kdoor (eval (kama-get-jail-door-tag (gob knpc)))))
      (cond ((null? kdoor) (error "L'étiquette de la porte de Kama est indéfinie !") #t)
            (else
             (let ((gob (kobj-gob kdoor)))
               (or (door-locked? gob)
                   (door-magic-locked? gob)))))))
  (define (rejoin)
    (say knpc "Ha! Iki!")
    (join-player knpc)
    (kern-conv-end)
    )
  (define (join-first-time)    
    (say knpc "Hajo! Bona ka ruka!")
	  (say knpc "[Sur le sol, il gratte ce qui semble être une carte de la région de la Grande Forêt. Là où la lisière sud de la forêt rencontre les montagnes de l'est, il marque un X plusieurs fois pour mettre l'accent].")
	  (quest-data-update-with 'questentry-rune-f 'angriss 1 (quest-notify nil))
    (kama-joined-once! (gob knpc))
    (join-player knpc)
    ;; Improve the player's relations with forest goblins
    (kern-dtable-inc faction-player faction-forest-goblin)
    (kern-dtable-inc faction-player faction-forest-goblin)
    (kern-conv-end)
    )
  (if (is-player-party-member? knpc)
      (say knpc "[Il semble confus] Ha...")
      (if (kama-joined-once? (gob knpc))
          (rejoin)
          (if (not (kama-gave-food? (gob knpc)))
              (kama-default knpc kpc)
              (if (door-still-locked?)
                  (say knpc "[Il montre la porte de la cellule et hausse les épaules, peut-être que si vous l'ouvriez...]")
                  (join-first-time)
                  )))))

(define (kama-food knpc kpc)
  (kern-log-msg "[Lui donnez-vous de la nourriture ?]")
  (define (no-food)
    (say knpc "[Il grogne et se détourne]")
    (kern-conv-end))
  (define (yes-food)
    (kama-gave-food! (gob knpc))
    (say knpc "[Il l'engloutit avidement et claque les lèvres] "
         "Ha nuki ! [Il vous montre du doigt] Bonaha."))
  (if (yes? kpc)
      (if (> (get-food-donation knpc kpc) 0)
          (yes-food)
          (no-food))
      (no-food)))
          
(define (kama-rune knpc kpc)
  (if (not (kama-gave-food? (gob knpc)))
      (kama-default knpc kpc)
      (if (any-in-inventory? kpc rune-types)
          (say knpc "[Vous lui montrez une rune. Il hoche la tête avec difficulté] Ruka.")
          (say knpc "[Il a l'air confus pendant que vous essayez de décrire une rune]"))))

;; Ruka == Rune
;; Having a goblin spout out *sextant coordinates* is just daft. Changing to something descriptive
;; Maybe for the repeat, give a pointed direction based on the parties location on the worldmap? "He points south" or whatever direction is appropriate
(define (kama-ruka knpc kpc)
  (if (kama-joined-once? (gob knpc))
  		(begin
	      (say knpc "Iki ruka.")
    	  (say knpc "[Sur le sol, il gratte ce qui semble être une carte de la région de la Grande Forêt. Là où la lisière sud de la forêt rencontre les montagnes de l'est, il marque un X plusieurs fois pour mettre l'accent].")
    	  (quest-data-update-with 'questentry-rune-f 'angriss 1 (quest-notify nil))
      	)
      (begin
        (say knpc "[Dans la poussière du sol de la cellule, il dessine un cercle avec des jambes articulées. Une araignée. Il vous montre ensuite du doigt, lui-même puis il efface l'araignée].")
        (prompt-for-key)
        (say knpc "[Vous avez l'impression qu'il vous propose une alliance avec vous contre l'araignée, ou quoi que ce soit d'autre]."))))

;; King Clovis (leader of the human forces in the war against the Goblins, one generation ago.
(define (kama-clov knpc kpc)
  (if (not (kama-gave-food? (gob knpc)))
      (kama-default knpc kpc)  
      (say knpc "[Il a l'air perplexe au début, mais il hoche ensuite la tête] Ruka ka choto.")))

(define (kama-leav knpc kpc)
  (if (is-player-party-member? knpc)
      (begin
        (say knpc "Kama tujo?")
        (if (yes? kpc)
            (begin
              (if (kern-char-leave-player knpc)
                  (begin
                    (say knpc "Kama iki")
                    (kern-conv-end))
                  (say knpc "Kama tu iki")))
            (kern-log-msg "[Il semble soulagé]")))
      (kern-log-msg "[Il semble confus]")))

;; Shakespeare
(define (kama-zukakiguru knpc kpc)
  (begin
    (say knpc "Ha!  Zukakiguru!")
    (aside kpc 'ch_gen "Nous partageons un intérêt commun, voyez-vous.")
    (say knpc "[Il regarde votre expression perplexe, et essaie à nouveau, en parlant lentement.] Zu-Ka Ki-Gi-Ru, Choguha Zuluma: Nu Hameluto!")
    (aside kpc 'ch_gen "Imaginez mon étonnement, lorsque j'ai appris l'existence du véritable auteur !")
    ))

;; Hameluto == Good/yes/skillful, Destiny change individual (Prince Hamlet)
(define (kama-hameluto knpc kpc)
  (begin
  (say knpc "Hameluto?  Ha!  [Kama change d'expression, puis s'adresse à nouveau à vous, avec un aspect sérieux.]")
  (aside kpc 'ch_gen "Vous allez vous régaler d'entendre l'original ! [Gen observe avec un intérêt dévoué.]")

  (say knpc "Nuboda? Tuboda? Ehgulu!")
  (aside kpc 'ch_gen "Être ou ne pas être.  Telle est la question !")

  (say knpc "Bogu Hahime, Natuda, Kamana, Rulumada?")
  (aside kpc 'ch_gen "Est-il plus noble, dans l'esprit, de subir les frondes et les flèches d'une fortune outrageante ?")

  (say knpc "Eh, Bomeka Darutu, Ikikacho, Katucho!")
  (aside kpc 'ch_gen "Ou de prendre les armes contre une mer de malheurs, et en s'opposant d'y mettre fin ?")

  (say knpc "[Il semble prêt à continuer un peu plus longtemps, voulez-vous écouter le récital en entier ?]")
  (if (yes? kpc)
      (say knpc "[Vous écoutez avec étonnement, pendant un certain temps.]")
      (say knpc "Bona iki?  Ha!  [Il cesse, apparemment content d'attendre un moment plus opportun].")
      )
  (aside kpc 'ch_gen "La quintessence de la pièce ressort plus clairement dans l'original, vous ne pensez pas ?")
  ))

(define kama-conv
  (ifc nil
       (method 'default kama-default )
       (method 'bonj kama-hail )
	   (method 'hail kama-hail )
	   
       (method 'adie kama-bye )
       (method 'part kama-leav )

       (method 'non kama-no )
       (method 'moi kama-me )
       (method 'jo kama-jo )
       (method 'nour kama-food )
       (method 'rune kama-rune )
       (method 'ruka kama-ruka )
       (method 'clov kama-clov )

       (method 'shak kama-zukakiguru ) ;; synonym
       (method 'trou kama-zukakiguru ) ;; synonym
       (method 'zuka kama-zukakiguru )

       (method 'haml kama-hameluto ) ;; synonym
       (method 'hame kama-hameluto )
    ))

(define (mk-kama jail-door-tag)
  (bind 
    (kern-mk-char 
     'ch_kama           ; tag
     "Kama"             ; name
     kama-species         ; species
     kama-occ              ; occ
     s_fgob_civilian  ; sprite
     faction-men      ; starting alignment
     2 0 10            ; str/int/dex
     pc-hp-off  ; hp bonus
     pc-hp-gain ; hp per-level bonus
     0 ; mp off
     0 ; mp gain
     max-health ; hp
     -1                   ; xp
     max-health ; mp
     0
     kama-lvl
     #f               ; dead
     'kama-conv         ; conv
     sch_kama           ; sched
     nil              ; special ai
     nil              ; container
     nil              ; readied
     )
   (kama-mk jail-door-tag)))
