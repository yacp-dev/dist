;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------
(define kalc-lvl 6)
(define kalc-species sp_human)
(define kalc-occ oc_wizard)

;;----------------------------------------------------------------------------
;; Schedule
;; 
;; Kalcifax travels (notionally by the moon gates) 
;; to many places, carrying messages and such.
;;----------------------------------------------------------------------------
(define kalc-bed cheerful-bed-2)
(define kalc-mealplace )
(define kalc-workplace )
(define kalc-leisureplace )
(kern-mk-sched 'sch_kalc
               (list 0  0 kalc-bed          "dort")
               (list 7  0 bilge-water-seat-5 "mange")
               (list 8  0 enchtwr-hall       "suis en pause")
               (list 11 0 g-fountain         "suis en pause")
               (list 12 0 ghg-s6             "mange")
               (list 13 0 eng-workshop       "suis en pause")
               (list 16 0 trigrave-tavern-hall "suis en pause")
               (list 17 0 trigrave-tavern-table-3b "mange")
               (list 19 0 gt-ws-hall           "suis en pause")
               (list 23 0 kalc-bed          "dort")
               )

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (kalc-mk) nil)

;;----------------------------------------------------------------------------
;; Conv
;; 
;; Kalcifax is a female wizard with considerable knowledge of the moon gates.
;; She travels to many places (notionally by use of the gates),
;; carrying messages and such.
;; Kalcifax is a potential party member.
;;----------------------------------------------------------------------------

;; Basics...
(define (kalc-hail knpc kpc)
  (meet "Vous rencontrez un mignon magicien.")
  (say knpc "Ravis de vous rencontrer, compagnon voyageur.")
  )

(define (kalc-name knpc kpc)
  (say knpc "Je m'appelle Kalcifax. Et toi, tu es... ?")
  (kern-conv-get-reply kpc)
  (say knpc "C'est un plaisir de vous rencontrer.")
  )

(define (kalc-join knpc kpc)
  (if (is-player-party-member? knpc)
      (say knpc "Je vous ai déjà rejoint !")
      (begin
        (say knpc "Ok, ça va être marrant !")
        (join-player knpc)
        (kern-conv-end)
        )
  ))

(define (kalc-job knpc kpc)
  (say knpc "Je voyage de portes en portes, je fais des courses pour les gens.")
  )

(define (kalc-bye knpc kpc)
  (say knpc "Je suis sûr que nous nous reverrons !")
  )

(define (kalc-gate knpc kpc)
  (say knpc "Les Portes Lunaires ! Savez-vous comment elles fonctionnent ?")
  (if (yes? kpc)
      (say knpc "Je ne sais pas pourquoi plus de gens ne le font pas.")
      (say knpc "C'est la phase de Lumis qui décide d'où vous pouvez entrer, "
           "la phase de Ord décide d'où vous émergez !")))

(define (kalc-lumi knpc kpc)
  (say knpc "Lumis est la lune jaune qui se déplace lentement."))

(define (kalc-ord knpc kpc)
  (say knpc "Ord est la lune bleue qui se déplace rapidement."))

(define (kalc-engi knpc kpc)
  (say knpc "Je suis l'une des seules personnes à avoir rendu visite à l'Ingenieur! "
       "Il faut utiliser une porte lunaire pour se rendre chez lui. "
       "Entrez quand Ord est presque pleine."))

(define (kalc-peop knpc kpc)
  (say knpc "Je délivre des messages et des colis pour l'Ingenieur, l'Enchanteur et les fonctionnaires de la ville. "
       "Tous ceux qui ont besoin d'une livraison rapide et sûre, et qui sont prêts à payer !"))

(define (kalc-pay knpc kpc)
  (say knpc "Je me débrouille plutôt bien."))

(define kalc-conv
  (ifc basic-conv

       ;; basics
       (method 'bonj kalc-hail )
	   (method 'hail kalc-hail )
	   
       (method 'adie kalc-bye )
       (method 'trav kalc-job )
       (method 'nom kalc-name )
       (method 'join kalc-join )
       
       (method 'port kalc-gate )
       (method 'lumi kalc-lumi )
       (method 'ord kalc-ord )
       (method 'engi kalc-engi )
	   (method 'inge kalc-engi )
       (method 'gens kalc-peop )
       (method 'cour kalc-peop )
       (method 'paye kalc-pay )
       ))

(define (mk-kalcifax)
  (bind 
   (kern-mk-char 
    'ch_kalc           ; tag
    "Kalcifax"             ; name
    kalc-species         ; species
    kalc-occ              ; occ
    s_blue_wizard
    faction-men      ; starting alignment
    0 7 0            ; str/int/dex
    (/ pc-hp-off 2)  ; hp bonus
    (/ pc-hp-gain 2) ; hp per-level bonus
    pc-mp-off        ; mp bonus
    pc-mp-gain       ; mp per-level bonus
    max-health ; hp
    -1  ; xp
    max-health ; mp
    0
    kalc-lvl
    #f               ; dead
    'kalc-conv         ; conv
    sch_kalc           ; sched
    'townsman-ai              ; special ai
    nil              ; container
    (list            ;; readied
     t_staff
     )
    )
   (kalc-mk)))
