;;----------------------------------------------------------------------------
;; Schedule
;;
;; In Bole.
;;----------------------------------------------------------------------------
(kern-mk-sched 'sch_hackle
               (list 0  0  bole-hackles-hut "suis en pause")
               (list 2  0  bole-bed-hackle "dort")
               (list 10 0  bole-hackles-hut "suis en pause")
               (list 20 0  bole-hackles-yard "suis en pause")
               )

;;----------------------------------------------------------------------------
;; Gob
;;
;; Quest flags, etc, go here.
;;----------------------------------------------------------------------------
(define (hackle-mk) nil)

;;----------------------------------------------------------------------------
;; Conv
;;
;; Hackle is a female hedge-witch dwelling in Bole.
;; Her mind was shattered by some misadventure with Gazer(s),
;; though she is still capable of serving as a healer.
;;----------------------------------------------------------------------------
(define (hackle-trade knpc kpc)
  (say knpc "Elle peut le guerir, ou l'un de ses amis. Elle a besoin d'une pièce "
       "d'or pour chaque personne en vie ! Est-il d'accord ?")
  (define (hackle-heal)
    (say knpc "Qui doit-elle guerir ?")
    (let ((kchar (kern-ui-select-party-member)))
      (if (null? kchar)
          (say knpc "Sinon de quelle manière peut-elle aider autrement ?")
          (let* ((gold (kern-player-get-gold))
                 (pts (- (kern-char-get-max-hp kchar)
                         (kern-char-get-hp kchar))))
            (if (= 0 gold)
                (say knpc "Pas d'or, pas de vie ! C'est la loi du pays !")
                (begin
                  (if (= 0 pts)
                      (say knpc "C'est bien ! Elle ne peut rien y faire !")
                      (let ((n (min gold pts)))
                        (say knpc "Elle la guerit !")
                        (kern-obj-heal kchar n)
                        (kern-player-set-gold (- gold n))))
                  (say knpc "Est-ce qu'il faut guerir un autre ?")
                  (if (kern-conv-get-yes-no? kpc)
                      (hackle-heal)
                      (say knpc "Il y a quelque chose d'autre qu'il veut.")
                      )))))))
  (if (kern-conv-get-yes-no? kpc)
      (hackle-heal)
      (say knpc "Qu'il en soit ainsi !")))
                   
              
        

;; basics...
(define (hackle-default knpc kpc)
  (say knpc "Elle ne peut pas aider à ce sujet."))

(define (hackle-hail knpc kpc)
  (if (in-player-party? 'ch_mesmeme)
      (begin
        (say knpc "[Elle recule d'horreur à la vue de Mesmeme] AHHH ! Elle a peur !")
        (aside kpc 'ch_mesmeme "Pas de peur.")
        )
      (say knpc "[Vous rencontrez une femme d'âge moyen, débraillée] Il vient à elle ! "
           "Il veut quelque chose !")
  ))

(define (hackle-name knpc kpc)
  (say knpc "Elle s'appelle Hackle."))

(define (hackle-job knpc kpc)
  (say knpc "Elle est un peu folle ! Mais elle peut guerir !"))

(define (hackle-join knpc kpc)
  (say knpc "Elle ne peut pas se joindre ! Elle doit s'occuper de ses moutons !"))

(define (hackle-bye knpc kpc)
  (say knpc "Elle lui fait ses adieux, mais sait qu'il reviendra !"))


;; other characters & town...
(define (hackle-may knpc kpc)
  (say knpc "C'est une femme dure, dure mais gentille avec Hackle !"))

(define (hackle-kath knpc kpc)
  (say knpc "Une femme vêtue de rouge ! Un monstre vêtu en femme !"))

(define (hackle-bill knpc kpc)
  (say knpc "Il est négligent. Oui, les dieux du bois l'auront pour souper "
       "un jour."))

(define (hackle-thud knpc kpc)
  (say knpc "[Elle rit d'un son doré et surprenant] Ce n'est pas un jouet ! "
       "ils ont appelé un serviteur, mais ont invoqué un démon !"))

(define (hackle-melv knpc kpc)
  (say knpc "C'est une bonne âme."))

(define (hackle-bole knpc kpc)
  (say knpc "Ah non, Pas Bole ! un trou ! Le trou de serrure des profondeurs ! Elle le sait !"))

;; misc...
(define (hackle-mesm knpc kpc)
  (say knpc "Ce n'est qu'un enfant. Il est muet et n'entend rien, à sa manière. "
       "Mais l'animal fera de son maître un animal de compagnie.")
  (aside kpc 'ch_mesmeme "Pas d'animaux de compagnie")
  )

(define (hackle-shee knpc kpc)
  (say knpc "Le mouton se cache dans des vêtements de loup ! Entend-le hurler quand "
       "il bêle !"))

(define (hackle-wood knpc kpc)
  (say knpc "Elle les a vus dormir dans les vieux chênes. Elle ne les reveille "
       "pas ! Ils ne nous aiment pas, ils n'aiment personne ! Les gobelins "
       "les apaisent, mais elle ne connaît pas les mots."))

(define (hackle-mad knpc kpc)
  (say knpc "Les Hypnotiseurs l'ont attrapée quand elle était petite ! Elle s'est échappée, mais pas son "
       "esprit!"))

(define (hackle-gaze knpc kpc)
  (say knpc "Si elle en rencontre un, elle devrait en tuer un sans poser de question ! Ils savent "
       "la réponse à toute question, et dans la réponse se cache l'esclavage !")
  (aside kpc 'ch_mesmeme "[Elle cligne nerveusement]")
)

;; thief quest...
(define (hackle-thie knpc kpc)
  (say knpc "C'est en effet un puissant Malfrat qui derobe un puissant sorcier !"))

(define (hackle-robs knpc kpc)
  (say knpc "Il vole et court, dans son petit trou de souris !"))

(define (hackle-hole knpc kpc)
  (say knpc "Est-ce qu'il aime les énigmes ?\n"
       " Un 'o' a un trou !\n"
       " Et le trou a un 'o' !\n"
       " Et la souris a les deux !\n"
       " Au milieu de la nuit\n"
       " Ça va tomber !\n"
       " Sait-il ce qu'il ^c+mrevele^c- ?")
  (if (kern-conv-get-yes-no? kpc)
      (say knpc "Alors, qu'il ^c+mrevele^c- et comprenne mon énigme !")
      (begin
        (say knpc "Wis Quas ! La Salope rouge a un parchemin, mais n'a pas "
             "la sagesse.")))
  )

(define (hackle-reve knpc kpc)
  (say knpc "L'enfant  Bill sait où la souris a disparu ! "
       "Qu'il se ^c+mrevele^c- là !"))

(define (hackle-midd knpc kpc)
  (say knpc "Oui ! Au milieu de la nuit !"))

(define hackle-conv
  (ifc basic-conv
       ;; default if the only "keyword" which may (indeed must!) be longer than
       ;; 4 characters. The 4-char limit arises from the kernel's practice of
       ;; truncating all player queries to the first four characters. Default,
       ;; on the other hand, is a feature of the ifc mechanism (see ifc.scm).
       (method 'default hackle-default )
       (method 'bonj hackle-hail )
	   (method 'hail hackle-hail )
	   
       (method 'adie hackle-bye )
       (method 'trav hackle-job )       
       (method 'nom hackle-name )
       (method 'join hackle-join )

       (method 'comm hackle-trade )
       (method 'ache hackle-trade )
       (method 'vend hackle-trade )
       (method 'guer hackle-trade )

       (method 'bill hackle-bill )
       (method 'kath hackle-kath )
       (method 'roug hackle-kath )
       (method 'salo hackle-kath )
       (method 'may hackle-may )
       (method 'melv hackle-melv )
       (method 'thud hackle-thud )
       
       (method 'bole hackle-bole )
       (method 'hypn hackle-gaze )
       (method 'dieu hackle-wood )
       (method 'dieu hackle-wood )
       (method 'trou hackle-hole )
       (method 'foll hackle-mad )
       (method 'mesm hackle-mesm )
       (method 'puis hackle-robs )
       (method 'sour hackle-hole )
       (method 'reve hackle-reve )
       (method 'dero hackle-robs )
       (method 'dero hackle-robs )
       (method 'malf hackle-robs )
       (method 'sorc hackle-robs )
       (method 'mout hackle-shee )
       (method 'vole hackle-thie )
       (method 'bois hackle-wood )
       (method 'mili hackle-midd )
       (method 'nuit hackle-midd )
       ))

;;----------------------------------------------------------------------------
;; First-time constructor
;;----------------------------------------------------------------------------
(define (mk-hackle)
  (bind 
   (kern-mk-char 'ch_hackle          ; tag
                 "Hackle"            ; name
                 sp_human            ; species
                 nil                 ; occ
                 s_beggar             ; sprite
                 faction-men         ; starting alignment
                 0 0 1            ; str/int/dex
                 0 0                 ; hp mod/mult
                 0 0                 ; mp mod/mult
                 max-health -1 max-health 0 6  ; hp/xp/mp/AP_per_turn/lvl
                 #f                  ; dead
                 'hackle-conv        ; conv
                 sch_hackle          ; sched
                 'townsman-ai                 ; special ai
                 nil                 ; container
                 nil                 ; readied
                 )
   (hackle-mk)))
