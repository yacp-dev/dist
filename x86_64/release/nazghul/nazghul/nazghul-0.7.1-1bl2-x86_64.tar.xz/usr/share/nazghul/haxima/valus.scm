;;----------------------------------------------------------------------------
;; Valus
;;
;; Initially a prisoner of Glasdrin, he becomes the new Steward after the
;; trial.
;;----------------------------------------------------------------------------

;;----------------------------------------------------------------------------
;; Schedule
;; 
;; Initially, in a prison cell in the dungeons below Glasdrin.
;; After the trial of the Stewardess, Valus is assigned Jeffries schedule.
;;----------------------------------------------------------------------------

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (valus-mk) (list 'townsman))

;;----------------------------------------------------------------------------
;; Conv
;; 
;; Valus is an imprisoned nobleman, once in the service of the late 
;; Steward of Glasdrin, now languishing in the dungeons below Glasdrin.
;; 
;;----------------------------------------------------------------------------

;; Basics...
(define (valus-hail knpc kpc)
  (say knpc "Bienvenue, étranger.")
  )

(define (valus-name knpc kpc)
  (if (player-stewardess-trial-done?)
      (say knpc "Je suis Valus, Regisseur de Glasdrin.")
      (say knpc "Je suis Valus, le seigneur de tout ce que je surveille [il fait des gestes autour de la cellule].")
  ))

(define (valus-job knpc kpc)
  (cond ((player-stewardess-trial-done?)
         (say knpc "Les gens de Glasdrin m'ont libéré de prison, grâce aux preuves contenues dans le journal que vous avez trouvé. "
              "Il semble que je vous sois redevable.")
         (prompt-for-key)
         (say knpc "Après ma libération, ils m'ont élu leur nouveau Regisseur.")
         )
        (else
         (say knpc "Je profite de ma retraite.")
         )))

(define (valus-join kpc kpc)
  (cond ((player-stewardess-trial-done?) (say knpc "Mes devoirs me maintiennent ici."))
        (else (say knpc "Au contraire, pourquoi ne pas ouvrir la porte et me rejoindre ?"))
        ))

;; Special
(define (valus-comm knpc kpc)
  (if (player-stewardess-trial-done?)
         (say knpc "Janice fera un excellent commandant. Je me souviens quand elle n'était qu'un chef d'équipe.")
         (say knpc "Jeffries est le nouveau commandant. Il fait un bon animal de compagnie pour la Regisseuse. Je n'étais pas un si bon chien, moi-même.")
         ))

(define (valus-pet knpc kpc)
  (say knpc "Après Absalot, elle m'a reproché la mort de civils, "
       "et m'a accusé d' ivresse et d'actes contre nature avec les trolls.")
  (aside 'ch_ini "Je pensais que l'histoire sur les trolls était vraie.")
  )

(define (valus-trol knpc kpc)
  (say knpc "Que puis-je dire ? Ces trolls savent faire la fête. [Il sourit sèchement]")
  (prompt-for-key)
  (say knpc "Mais sérieusement, elle m'a fait emprisonner pour avoir posé trop de questions. "
       "L'ancien Regisseur est devenu fou dans des circonstances mystérieuses. "
       "Pour une raison quelconque, elle n'aimait pas que j'intervienne dans cette affaire.")
  )

(define (valus-absa knpc kpc)
  (say knpc "La guerre, c'est l'enfer, mon ami. Toutes ces absurdités sur les Maudits, "
       "les mages d'Absalot devenaient trop puissants. "
       "Chaque commandant connaît la légende d' isin.")
  )

(define (valus-isin knpc kpc)
  (say knpc "Selon la légende, la sorcière Isin a presque vaincu à elle seule deux armées. "
       "L'armée des Tulemanes a été si totalement vaincue que leur ville a été oubliée. ")
  (prompt-for-key)
  (say knpc "L'armée de Glasdrin l'a finalement vaincue, mais avec de si lourdes pertes qu'elle a dû abandonner son objectif. "
       "Nous n'avons jamais oublié la lecon.")
  )

(define (valus-less knpc kpc)
  (say knpc "La lecon de la bataille d' Isin est de ne jamais laisser les sorciers devenir trop puissants. "
       "Et s'ils le font, n'essayez pas de les affronter en combat ouvert. "
       "Vous savez, je me suis toujours demandé pourquoi cette bataille a eu lieu.")
  )

;; new....
(define (valus-stew knpc kpc)
  (if (player-stewardess-trial-done?)
      (say knpc "Maintenant que je suis Regisseur, il y aura quelques changements ici.")
      (say knpc "La politique de cette folle sera la ruine de Glasdrin.")
      ))

(define (valus-poli knpc kpc)
  (say knpc "Le but de la Regisseuse est d'augmenter son propre pouvoir au détriment de tout le reste. ")
  )

(define (valus-chan knpc kpc)
  (say knpc "Ma première préoccupation est la securité, la stabilité et la domination de Glasdrin.")
  )

(define (valus-domi knpc kpc)
  (if (ask? knpc kpc "La seule façon pour une ville ou un État d'assurer sa propre securité est de dominer les autres, n'est-ce pas ?")
      (say knpc "Oui, tous les hommes d'État sages le savent et s'efforcent de faire de leur propre État le plus fort.")
      (say knpc "Si nous permettons à d'autres États de nous dépasser en force, alors ils nous domineront. "
           "En tant que Regisseur, je suis chargé de prendre des mesures pour empêcher cela.")
      ))

(define valus-conv
  (ifc glasdrin-conv

       ;; basics
       (method 'bonj valus-hail )
	   (method 'hail valus-hail )
	   
       (method 'trav valus-job )
       (method 'nom valus-name )
       (method 'join valus-join )

       (method 'absa valus-absa )
       (method 'chan valus-chan )
       (method 'civi valus-absa )
       (method 'comm valus-comm )
       (method 'chie valus-pet )
       (method 'domi valus-domi )
       (method 'ivre valus-trol )
       (method 'isin valus-isin )
       (method 'jeff valus-comm )
       (method 'leco valus-less )
       (method 'anim valus-pet )
       (method 'poli valus-poli )
       (method 'retr (lambda (knpc kpc) (say knpc "Auparavant, j'étais le commandant de Glasdrin.")))
       (method 'ruin valus-poli )
       (method 'secu valus-domi )
       (method 'stab valus-domi )
       (method 'regi valus-stew )
       (method 'trol valus-trol )
       (method 'natu valus-trol )
       ))

(define (mk-valus)
  (bind 
   (kern-mk-char 'ch_valus       ; tag
                 "Valus"          ; name
                 sp_human            ; species
                 oc_warrior          ; occ
                 s_fallen_paladin ; sprite
                 faction-glasdrin         ; starting alignment
                 2 1 1               ; str/int/dex
                 0 0                 ; hp mod/mult
                 0 0                 ; mp mod/mult
                 max-health -1 max-health 0 5  ; hp/xp/mp/AP_per_turn/lvl
                 #f                  ; dead
                 'valus-conv         ; conv
                 nil           ; sched
                 'townsman-ai                 ; special ai
                 nil                 ; container
                 (list t_armor_chain
                       t_chain_coif
                       t_sword
                       ))         ; readied
   (valus-mk)))
