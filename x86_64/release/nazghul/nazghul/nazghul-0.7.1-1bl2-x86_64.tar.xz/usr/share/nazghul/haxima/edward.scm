;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------
(define edward-start-lvl 4)

;;----------------------------------------------------------------------------
;; Schedule
;;
;; In the dungeons below Green Tower.
;;----------------------------------------------------------------------------
(kern-mk-sched 'sch_edward
               (list 0  0  gtl-jailor-bed "dort")
               (list 7  0  gtl-jail       "travaille" )
               (list 21 0  gtl-jailor-bed "dort")
               )

;;----------------------------------------------------------------------------
;; Gob
;;
;; Quest flags, etc, go here.
;;----------------------------------------------------------------------------
(define (edward-mk) (list #f #f))
(define (edward-met? gob) (car gob))
(define (edward-meet! gob) (set-car! gob #t))
(define (edward-has-nate? gob) (cadr gob))
(define (edward-has-nate! gob) (set-car! (cdr gob) #t))

;;----------------------------------------------------------------------------
;; Conv
;;
;; Edward is a old blind man, serving as the jailor 
;; in the dungeons below Green Tower.
;;----------------------------------------------------------------------------
(define (edward-hail knpc kpc)
  (meet "Vous rencontrez un vieil homme pâle dont les yeux sont d'un blanc laiteux, ce qui fait penser qu'il est aveugle.")
  (let ((edward (kobj-gob-data knpc)))
    (cond ((not (edward-met? edward))
           (say knpc "Qui va là ?")
           (reply? kpc)
           (edward-meet! edward)
           (say knpc "Je ne vous connais pas. Avez vous l'intention de faire une évasion de prison ?")
           (if (yes? kpc)
               (say knpc "Eh bien, allez-y ! Je suis trop vieux pour t'arrêter.")
               (say knpc "C'est un soulagement. Je n'aurais personne à qui parler.")
               )
           )
          (else
           (say knpc "Bienvenue à nouveau. Je me souviens de vos pas.")
           ))))

(define (edward-give-nate knpc kpc)
  (say knpc "Vous délivrez un prisonnier ?")
  (cond ((yes? kpc)
         (cond ((is-only-living-party-member? ch_nate)
                (say knpc "Rendez-vous si vous voulez,"
                     "mais débarrassez-vous d'abord de ce cadavre ! "
                     "Ce n'est pas une morgue ici!")
                )
               (else
                (say knpc "Oh, bien. Plus de compagnie. [Il met en arrêt Nate et "
                     "l'enferme dans une cellule]")
                (kern-char-leave-player ch_nate)
                (kern-obj-relocate ch_nate (mk-loc p_green_tower_lower 9 10) nil)
                (prompt-for-key)
                (say knpc "Voici votre reçu, au cas où le capitaine le voudrait.")
                (give (kern-get-player) t_prisoner_receipt 1)
                (edward-has-nate! (kobj-gob-data knpc))
                (quest-data-update-with 'questentry-bandits 'nate-given-to-jailor 1 (quest-notify nil))                
                )))
        (else
         (say knpc "Ouais d'accord. [Il regarde Nate, puis hausse les épaules]")
         )))

(define (edward-pris knpc kpc)
  (cond ((in-player-party? 'ch_nate) (edward-give-nate knpc kpc))
        (else
         (let ((edward (kobj-gob-data knpc)))
           (if (edward-has-nate? edward)
               (say knpc "J'ai un gobelin des forêts et le type que vous avez amené.")
               (say knpc "Je viens d'avoir un gobelin des forêts en ce moment. "
                    "Lui et moi ne pouvons pas nous comprendre, "
                    "mais cela ne nous empêche pas d'échanger nos histoires."))))
        ))

(define (edward-gobl knpc kpc)
  (say knpc "Je n'ai pas peur d'eux. Ils ne m'ont jamais fait de mal."))

(define (edward-stor knpc kpc)
  (say knpc "Avez-vous entendu celle sur les Feux-follets ?")
  (cond ((no? kpc)
         (say knpc "Le Feux-follet était un esprit qui hantait ces bois, "
              "dans l'ancien temps où les portes fonctionnaient et où les dieux étaient honorés. ")
         (prompt-for-key kpc)
         (say knpc "Si une jolie jeune fille s'aventurait seule dans les bois, "
              "il apparaîtrait comme un beau bûcheron ou un ranger, "
              "et l'incitera à retourner dans son bosquet sacré. "
              "Là, il la transforme en arbre.")
         (prompt-for-key kpc)
         (say knpc "C'est ainsi que la Grande Forêt a vu le jour, dans son bosquet. "
              "Et c'est pourquoi on trouve encore aujourd'hui tant d'arbres hantés dans les bois.")
         )
        (else
         (say knpc "Personne ne sait ce qu'il adviendra du Feux-follet. "
              "Il est passé dans la légende comme les autres dieux, je suppose.")
         )))

(define (edward-gate knpc kpc)
  (say knpc "Je ne sais rien sur elles. Elles ont fonctionné, c'est tout ce que je sais."))

(define (edward-gods knpc kpc)
  (say knpc "Ce n'est pas une bonne idée de parler des anciens dieux. "
       "Les gens pourraient penser que nous sommes des Maudits s'ils nous entendaient."))

(define (edward-accu knpc kpc)
  (say knpc "Les Maudits cherchent le pouvoir auprès des anciens dieux... et d'autres choses. "
       "J'en ai eu quelques-uns dans ma prison."))

(define (edward-talk knpc kpc)
  (say knpc "Les prisonniers sont les seuls avec qui je peux parler ici."))

(define (edward-blin knpc kpc)
  (say knpc "L'obscurité ne me dérange pas. La lumière non plus, d'ailleurs. "
       "Pour moi, tout est la même chose."))

(define (edward-guar knpc kpc)
  (say knpc "A vrai dire, je ne suis pas un grand gardien."))

(define (edward-jail knpc kpc)
  (cond ((in-player-party? 'ch_nate) (edward-give-nate knpc kpc))
        (else
         (say knpc "Je nourris les prisonniers et j'échange des histoires avec eux. "
              "Je suis censé les garder aussi. Empêcher les evasions.")
         )))

(define edward-conv
  (ifc ranger-conv
       ;; default if the only "keyword" which may (indeed must!) be longer than
       ;; 4 characters. The 4-char limit arises from the kernel's practice of
       ;; truncating all player queries to the first four characters. Default,
       ;; on the other hand, is a feature of the ifc mechanism (see ifc.scm).
       (method 'default 
               (lambda (knpc kpc) 
                 (say knpc "[Il hausse les épaules]")))
       (method 'bonj edward-hail )
	   (method 'hail edward-hail )
	   
       (method 'adie 
               (lambda (knpc kpc) 
                 (say knpc "Faites attention à la marche dans le noir !")))
       (method 'trav 
               (lambda (knpc kpc) 
                 (say knpc "Je suis geolier, gardien de prison.")))
       (method 'nom 
               (lambda (knpc kpc) 
                 (say knpc "Je suis Edward. Et vous m'avez déjà dit votre nom.")))
       (method 'join 
               (lambda (knpc kpc) 
                 (say knpc "J'aurais voulu. [Mais il ne le fait pas]")))
       (method 'maud edward-accu )
       (method 'aveu edward-blin )
       (method 'evas edward-guar )
       (method 'port edward-gate )
       (method 'gobe edward-gobl )
       (method 'dieu edward-gods )
       (method 'dieu edward-gods )
       (method 'gard edward-guar )
       (method 'geol edward-jail )
       (method 'anci edward-gods )
       (method 'pris edward-pris )
       (method 'hist edward-stor )
       (method 'parl edward-talk )
       ))

;;----------------------------------------------------------------------------
;; First-time constructor
;;----------------------------------------------------------------------------
(define (mk-edward)
  (bind 
   (kern-char-arm-self
    (kern-mk-char 
     'ch_edward ;;..........tag
     "Edward" ;;.......name
     sp_human ;;.....species
     oc_ranger ;;.. .occupation
     s_old_townsman ;;..sprite
     faction-men ;;..faction
     0 ;;...........custom strength modifier
     0 ;;...........custom intelligence modifier
     0 ;;...........custom dexterity modifier
     0 ;;............custom base hp modifier
     0 ;;............custom hp multiplier (per-level)
     0 ;;............custom base mp modifier
     0 ;;............custom mp multiplier (per-level)
     max-health ;;..current hit points
     -1  ;;...........current experience points
     max-health ;;..current magic points
     0
     edward-start-lvl  ;;..current level
     #f ;;...........dead?
     'edward-conv ;;...conversation (optional)
     sch_edward ;;.....schedule (optional)
     'townsman-ai ;;..........custom ai (optional)

     ;;..............container (and contents)
     (mk-inventory
      (list
       (list 1 t_torch)
       (list 1 t_dagger)
       ))
     (list t_armor_leather)                ; readied ;;.........readied arms (in addition to the container contents)
     nil ;;..........hooks in effect
     ))
   (edward-mk)))
