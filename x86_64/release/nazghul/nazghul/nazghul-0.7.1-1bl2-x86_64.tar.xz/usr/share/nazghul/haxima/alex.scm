;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------
(define alex-lvl 8)
(define alex-species sp_human)
(define alex-occ oc_wizard)

;;----------------------------------------------------------------------------
;; Schedule
;; 
;; In Paladin's Hold, in the Keep guarding Kurpolis.
;;----------------------------------------------------------------------------
(define alex-bed ph-bed3)
(define alex-mealplace ph-tbl3)
(define alex-workplace ph-hall)
(define alex-leisureplace ph-dine)
(kern-mk-sched 'sch_alex
               (list 0  0 alex-bed          "dort")
               (list 7  0 alex-mealplace    "mange")
               (list 8  0 alex-workplace    "travaille")
               (list 12 0 alex-mealplace    "mange")
               (list 13 0 alex-workplace    "travaille")
               (list 18 0 alex-mealplace    "mange")
               (list 19 0 alex-leisureplace "suis en pause")
               (list 22 0 alex-bed          "dort")
               )

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (alex-mk) nil)

;;----------------------------------------------------------------------------
;; Conv
;; 
;; Alex is a Captain in the Glasdrin Militia, 
;; serving in the second garrison which guards 
;; the undead-filled prison level of Kurpolis.
;;----------------------------------------------------------------------------

;; Basics...
(define (alex-hail knpc kpc)
  (say knpc "Bienvenue, aventurier, vous trouverez ici la sécurité derrière nos murs."))

(define (alex-name knpc kpc)
  (say knpc "Je suis le capitaine Alex de la milice de Glasdrin."))

(define (alex-job knpc kpc)
  (say knpc "Je suis mage de guerre et commandant de cette garnison. Vous voulez passer nos portes ?")
  (if (yes? kpc)
      (alex-pass knpc kpc)
      (say knpc "Si vous changez d'avis et avez besoin du mot de passe, venez me le demander.")))

(define (alex-bye knpc kpc)
  (say knpc "Surveillez vos arrières."))

(define (alex-warm knpc kpc)
  (say knpc "Un mage de guerre est spécialisé dans les sorts de combat. Vous savez quel est mon plus gros problème ?")
  (yes? kpc)
  (say knpc "Trouver des réactifs. Faites des provisions avant de vous aventurer plus loin !"))

(define (alex-garr knpc kpc)
  (say knpc "C'est l'une des trois garnisons que la milice maintient à Kurpolis. "
       "La première garnison garde l'entrée de Kurpolis pour empêcher les monstres de remonter à la surface. ")
  (prompt-for-key)
  (say knpc "Celle-ci, la deuxième garnison, gère la prison en contrebas et tient les morts-vivants à distance.")
  (prompt-for-key)
  (say knpc "La troisième garnison garde le chemin vers... enfin, vers un endroit où personne n'a rien à faire. ")
  )

(define (alex-unde knpc kpc)
  (say knpc "Ce niveau de Kurpolis est un ancien donjon, principalement contrôlé par les morts-vivants. Vous voulez savoir ce que j'en pense ?")
  (if (yes? kpc)
      (say knpc "Je pense que les morts-vivants sont au service d'une liche.")
      (say knpc "Alors je ne vous ennuierai pas avec mon opinion !")))

(define (alex-lich knpc kpc)
  (say knpc "Qu'est-ce qu'une liche ? C'est un magicien mort-vivant. Une liche peut controler les morts et jeter toutes sortes de sortilèges. Un ennemi très gênant."))

(define (alex-pass knpc kpc)
  (say knpc "Le mot de passe est deep."))

(define (alex-thir knpc kpc)
  (say knpc "Nous avons perdu le contact avec la troisième garnison. "
       "Un des soldats de ce régiment se trouve dans notre prison, en bas. "
       "J'ai bien peur qu'il soit assez fou. Les endroits profonds peuvent faire cela à un homme."))

(define (alex-pris knpc kpc)
  (say knpc "Si vous voulez visiter la prison, descendez l'échelle."))

(define (alex-firs knpc kpc)
  (say knpc "Si vous voulez visiter la première garnison, montez l'échelle, puis dirigez-vous vers le nord et ensuite vers l'ouest."))

(define alex-conv
  (ifc kurpolis-conv

       ;; basics
       (method 'bonj alex-hail )
	   (method 'hail alex-hail )
	   
       (method 'adie alex-bye )
       (method 'trav alex-job )
       (method 'nom alex-name )

       (method 'mage alex-warm )
       (method 'garn alex-garr )
       (method 'comm alex-garr )
       (method 'lich alex-lich )
       (method 'mot alex-pass )

       (method 'troi alex-thir )
       (method 'pris alex-pris )
       (method 'prem alex-firs )
       ))

(define (mk-alex)
  (bind 
   (kern-mk-char 
    'ch_alex           ; tag
    "Alex"             ; name
    alex-species         ; species
    alex-occ              ; occ
    s_companion_wizard     ; sprite
    faction-men      ; starting alignment
    2 5 1            ; str/int/dex
    0 0              ; hp mod/mult
    0 0              ; mp mod/mult
    max-health ; hp
    -1                   ; xp
    max-health ; mp
    0
    alex-lvl
    #f               ; dead
    'alex-conv         ; conv
    sch_alex           ; sched
    'townsman-ai              ; special ai
    nil              ; container
    (list t_sword
    		t_shield
    		t_leather_helm
					         t_armor_leather_2
					         )               ; readied
    )
   (alex-mk)))
