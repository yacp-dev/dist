;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------
(define meaney-lvl 6)
(define meaney-species sp_human)
(define meaney-occ nil)

;;----------------------------------------------------------------------------
;; Schedule
;; 
;; In the Poorhouse, near Oparine.
;;----------------------------------------------------------------------------
(define meaney-bed poorh-bed1)
(define meaney-mealplace poorh-sup1)
(define meaney-workplace poorh-hall)
(define meaney-leisureplace poorh-dining)
(kern-mk-sched 'sch_meaney
               (list 0  0 meaney-bed          "dort")
               (list 5  0 meaney-mealplace    "mange")
               (list 6  0 meaney-workplace    "travaille")
               (list 12 0 meaney-mealplace    "mange")
               (list 13 0 meaney-workplace    "travaille")
               (list 18 0 meaney-mealplace    "mange")
               (list 19 0 meaney-leisureplace "suis en pause")
               (list 21 0 meaney-bed          "dort")
               )

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (meaney-mk) (list 0 #t))
(define (meaney-get-donated meaney) (car meaney))
(define (meaney-donated? meaney) (> (meaney-get-donated meaney) 
                                    0))
(define (meaney-donate! meaney q) (set-car! meaney (+ (car meaney) q)))
(define (meaney-has-ring meaney) (cadr meaney))
(define (meaney-remove-ring meaney) (set-car! (cdr meaney) #f))

(define (meaney-on-death knpc)
	(if  (meaney-has-ring (kobj-gob-data knpc))
		(kern-obj-put-at (kern-mk-obj t_skull_ring_m 1) (kern-obj-get-location knpc))
	))

;;----------------------------------------------------------------------------
;; Conv
;; 
;; Meaney is a monk of the Order of the Crossroad, 
;; living in the Poorhouse near Oparine.
;; He was once a pirate, in the crew of the Merciful Death,
;; and is sought for vengeance by the ghost captain Ghertie.
;;----------------------------------------------------------------------------

;; Basics...
(define (meaney-hail knpc kpc)
  (say knpc "Je te salue, voyageur."))

(define (meaney-default knpc kpc)
  (say knpc "Je ne peux pas t'aider dans ce domaine."))

(define (meaney-name knpc kpc)
  (say knpc "Je suis le frere Meaney.")
  (quest-data-update 'questentry-ghertie 'meaney-loc 1))

(define (meaney-join knpc kpc)
  (say knpc "Mon devoir est envers les pauvres et les affligés."))

(define (meaney-job knpc kpc)
  (say knpc "Je gère le foyer des pauvres,"
       "où nous prenons soin des malades et des indigents."))

(define (meaney-bye knpc kpc)
  (say knpc "Adieu."))

;; Second-tier responses
(define (meaney-get-donation knpc kpc)
  (define (rejected)
    (cond ((> (kern-player-get-gold) 0)
           (say knpc "Je vois. Peut-être une autre fois. [Il se détourne tristement]")
           (kern-conv-end))
          (else
           (say knpc "Peut-être êtes-vous vous aussi dans le besoin."))))
  (let ((meaney (kobj-gob-data knpc)))
    (if (not (meaney-donated? meaney))
        (begin
          (say knpc "Veux-tu donner de l'or pour aider les pauvres ?")
          (if (kern-conv-get-yes-no? kpc)
              (let ((q (get-gold-donation knpc kpc)))
                (if (> q 0)
                    (begin
                      (say knpc "Soyez béni, étranger ! "
                           "On se souviendra de votre gentillesse.")
                      (meaney-donate! meaney q))
                    (rejected)))
              (rejected))))))

(define (meaney-poor knpc kpc)
  (say knpc "Dans le Foyer des pauvres, nous aidons surtout les veuves et les orphelins. "
       "Etes-vous dans un grand besoin ?")
  (if (kern-conv-get-yes-no? kpc)
      (say knpc "Ensuite, nous distribuons volontiers le peu de nourriture que nous avons avec vous.")
      (meaney-get-donation knpc kpc)))

(define (meaney-sick knpc kpc)
  (say knpc "Nous guerissons tous ceux qui viennent ici dans le besoin. Avez-vous besoin de guerison ?")
  (if (kern-conv-get-yes-no? kpc)
      (meaney-trade knpc kpc)
      (meaney-get-donation knpc kpc)))

(define (meaney-brot knpc kpc)
  (say knpc "Je suis un moine de l'Ordre de la Croisée des Chemins. "
       "Mon ordre a été fondé par le Vagabond Davis il y a plus de sept siècles "
       "pour servir les pauvres."))

;; Trade...
(define (meaney-trade knpc kpc)
  (if (trade-services knpc kpc
                      (list
                       (svc-mk "Soigner les blessure" 0 heal-service)
                       (svc-mk "Remède et anti-poison" 0 cure-service)
                       ))
      (begin
        (say knpc "Que puis-je faire d'autre pour vous aider ?")
        (meaney-trade knpc kpc))
      (begin
        (say knpc "Y a-t-il autre chose ?")
        (if (kern-conv-get-yes-no? kpc)
            (meaney-trade knpc kpc)
            (meaney-get-donation knpc kpc)))))

;; Town & Townspeople

;; Quest-related
(define (meaney-pira knpc kpc)
	(quest-data-update 'questentry-ghertie 'meaney-loc 1)
	(say knpc "Oui, j'étais un pirate autrefois, il y a longtemps. "
		"J'ai navigué avec Ghertie à bord de la Mort Miséricordieuse. "
		"Maintenant, je passe ma vie à faire penitence aux pauvres."))

(define (meaney-gher knpc kpc)
  (say knpc "Ghertie a bien traité notre équipage."
       "Nous étions considérés autant que sa propre famille à ses yeux. " 
       "A vrai dire, c'était un brigand impitoyable et complètement méchante. "
       "Certes, elle méritait sans aucun doute de mourir, "
       "hélas, pas dans les mains de ses propres brutes."))

(define (meaney-pena knpc kpc)
  (say knpc "Je suis coupable de pleins de crimes odieux, "
       "et toute cette effusion de sang n'a servi à rien. "
       "J'ai trahi mon capitaine, et j'ai été trahi à mon tour."))

(define (meaney-betr knpc kpc)
  (say knpc "Tout l'équipage a conspiré pour assassiner notre capitaine et se répartir le butin. "
       "Nous étions certains qu'elle allait tous nous assassiner en premier si nous ne le faisions pas. "
       "Le premier lieutenant, la cuisinière et moi avons décidé de passer à l'acte pendant qu'elle gisait ivre, "
       "Quand nous sommes revenus sur le quai, le bateau avait navigué sans nous."))

(define (meaney-firs knpc kpc)
  (say knpc "Le premier lieutenant était un misérable maléfique qui s'appelle Jorn. "
       "J'ai entendu dire que c'est un bandit maintenant, il se trouverait à un endroit dans la grande forêt à l'est. "
       "Vous pouvez vous renseigner à la Tour Verte.")
       (quest-data-update 'questentry-ghertie 'jorn-forest 1))

(define (meaney-cook knpc kpc)
  (say knpc "Gholet est sans doute soit mort, soit en train de pourrir dans une prison oubliée au loin. "
       "La dernière fois que je l'ai vu, il s'est arrêté ici pour la nuit. "
       "Quand je me suis réveillé le lendemain matin, j'ai trouvé le verrou de notre boîte de dons cassé. "
       "La boîte était encore plus vide que d'habitude.")
       (quest-data-update 'questentry-ghertie 'gholet-prison 1)
       )

(define (meaney-ring knpc kpc)
  (if (not (meaney-has-ring (kobj-gob-data knpc)))
      (say knpc "J'espère ne plus jamais revoir cette chose maudite.")
      (begin
        (say knpc "Oui, je porte la bague des Brutes de Ghertie, "
             "l'équipage de la Mort Miséricordieuse. Oui, je suis un pirate meurtrier. ")
        (prompt-for-key)
        (say knpc "La légende dit que Luto le Vagabond a parcouru la campagne, "
              "rendant la justice à la pointe de son épée. Êtes-vous venu "
              "me tuer pour mes crimes ?")
        (if (yes? kpc)
            (begin
              (say knpc "Alors, finissons-en, je suis prêt. [Il se tient la tête baissée].")
              (kern-conv-end))
            (begin
              (say knpc "Vous êtes miséricordieux. "
                    "Il est temps que je me sépare de cette bague, "
                    "ce qui signifie que je dois me séparer de ce doigt. "
                    "Je n'ai pas le courage de le couper, "
                    "le ferez-vous ?")
              (if (yes? kpc)
                  (begin
                    (say knpc "[D'un geste rapide, vous saisissez sa main et coupez le "
                          "doigt] Ah ! voilà, c'en est fini, et je suis libéré de sa malédiction. "
                          "Je vous remercie, Vagabond. Sachez que si jamais vous avez besoin d'aide "
                          "ou de guerison, je ferai ce que je peux pour vous.")
			(skullring-m-get nil kpc)
			(meaney-remove-ring (kobj-gob-data knpc))
                    )
                  (say knpc "J'aimerais pouvoir me débarrasser de cette misérable chose !")))))))

(define meaney-conv
  (ifc basic-conv

       ;; basics
       (method 'default meaney-default )
       (method 'bonj meaney-hail )
	   (method 'hail meaney-hail )
	   
       (method 'adie meaney-bye )
       (method 'trav meaney-job )
       (method 'nom meaney-name )
       (method 'join meaney-join )
       
       ;; trade
       (method 'comm meaney-trade )
       (method 'ache meaney-trade )
       (method 'vend meaney-trade )

       ;; town & people

       ;; other responses
       (method 'pauv meaney-poor )
       (method 'indi meaney-poor )
       (method 'soin meaney-sick )
       (method 'guer meaney-sick )
       (method 'affl meaney-sick )
       (method 'frer meaney-brot )
       (method 'foye meaney-job )

       ;; pirate quest replies
       (method 'pira meaney-pira )
       (method 'gher meaney-gher )
       (method 'capi meaney-gher )
       (method 'peni meaney-pena )
       (method 'trah meaney-betr )
       (method 'prem meaney-firs )
       (method 'cuis meaney-cook )
       (method 'bagu meaney-ring )
       (method 'cran meaney-ring )
       (method 'ghol meaney-cook )
       (method 'jorn meaney-firs )
       ))

(define (mk-meaney)
	(let ((knpc
    (kern-mk-char 
     'ch_meaney           ; tag
     "Meaney"             ; name
     meaney-species         ; species
     meaney-occ              ; occ
     s_companion_shepherd  ; sprite
     faction-men      ; starting alignment
     1 2 1            ; str/int/dex
     0 0              ; hp mod/mult
     0 0              ; mp mod/mult
     max-health ; hp
     -1                   ; xp
     max-health ; mp
     0
     meaney-lvl
     #f               ; dead
     'meaney-conv         ; conv
     sch_meaney           ; sched
     'townsman-ai              ; special ai

     ;;..........container (and contents)
     (mk-inventory
      (list
       (list 1 t_dagger)
       ))
     nil              ; readied
     )))
 (kern-char-force-drop knpc #t)
  (bind knpc (meaney-mk))
  (kern-obj-add-effect knpc 
           ef_generic_death
           'meaney-on-death)
	  knpc) )
  