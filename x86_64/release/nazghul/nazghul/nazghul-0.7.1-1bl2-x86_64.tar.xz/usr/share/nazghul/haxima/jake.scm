;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------
(define jake-lvl 2)
(define jake-species sp_gint)
(define jake-occ nil)

;;----------------------------------------------------------------------------
;; Schedule
;; 
;; In Kun.
;;----------------------------------------------------------------------------
(define jake-bed )
(kern-mk-sched 'sch_jake
               (list 0  0 cantina-counter-zzz "dort")
               (list 9  0 cantina-counter "travaille")
               )

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (jake-mk) (list #t))
(define (jake-left? gob) (car gob))
(define (jake-left! gob val) (set-car! gob val))

;;----------------------------------------------------------------------------
;; Conv
;; 
;; Jake / Percy is a gint (two-headed giant) 
;; who lives in the monster village of Kun.
;; 
;; Jake is the brutish left head,
;; who acts as the bouncer for the tavern there.
;; 
;; Percy is the refined right head,
;; who is the barkeep and proprietor of the tavern there.
;;----------------------------------------------------------------------------

(define (left-head? knpc)
  (jake-left? (gob knpc)))
(define (left-head! knpc)
  (jake-left! (gob knpc) #t)
  (say knpc "JUSTE ICI !"))
(define (right-head! knpc)
  (jake-left! (gob knpc) #f)
  (say knpc "Que puis-je faire pour vous aider ?"))

;; Basics...
(define (jake-hail knpc kpc)
  (kern-log-msg "Vous rencontrez un personnage énorme à deux têtes. L'une a un aspect bourrue et l'autre quelque peu ... "
                "disons, guindée n'est probablement pas un mot trop fort.")
  (if (left-head? knpc)
      (say knpc "SALUT, TOI T'ES QUI ???")
      (say knpc "Bienheureux de vous rencontrer, cher Monsieur.")
      ))

(define (jake-default knpc kpc)
  (if (left-head? knpc)
      (say knpc "BON SANG! JE SAIS PAS !!! DEMANDE A PERCY , OUAIS!!!")
      (say knpc "Hmmm, une énigme, c'est certain.")
      ))

(define (jake-name knpc kpc)
  (if (left-head? knpc)
      (say knpc "OUAIS MOI CH'UIS JAKE ! ET CET AUTRE LA BAS C'EST PERCY ! [La tête gauche se secoue pour indiquer la droite]")
      (say knpc "Je suis Perceval. Et mon compagnon de tous les jours aime qu'on l'appelle Jake.  [La tête gauche hoche vers la tête droite]")
      ))

(define (jake-join knpc kpc)
  (if (left-head? knpc)
      (say knpc "JOINDRE ??? OUAAA HARR HAARR HAARRRR!!! QUEL IDIOT !!!!")
      (say knpc "Oh, j'ai bien peur que non. Certes c'est une offre des plus gracieuses, cependant...")
      ))

(define (jake-job knpc kpc)
  (if (left-head? knpc)
      (say knpc "OUAICHHH !!! J'SUIS LE VIDEUR, BIEN SÛR !! MAINTENANT, BOIS UN TRUC OU TU DEGAGE !")
      (begin
        (say knpc "Humm, un peu de tenue voyons. Je suis le propriétaire et le barman. Voulez-vous boire un verre ?")
        (if (yes? kpc)
            (jake-trade knpc kpc)
            (say knpc "Veuillez reconsidérer votre choix, je vous offre le meilleur.")
            ))))

(define (jake-bye knpc kpc)
  (if (left-head? knpc)
      (say knpc "OUAIS, ADIEU ET A JAMAIS !!!")
      (say knpc "Adieu, revenez nous voir. Ce fut un plaisir ...")
      ))

(define (jake-jake knpc kpc)
  (if (left-head? knpc)
      (say knpc "OUAIIISS !!! QU'EST CE QUE TU ME VEUX ????")
      (begin
        (say knpc "Voulez-vous vraiment parler à Jake ?")
        (if (yes? kpc)
            (left-head! knpc)))
      ))

(define (jake-perc knpc kpc)
  (if (left-head? knpc)
      (begin
        (say knpc "QUOI ? TU VEUX PARLER À PERCY MAINTENANT ?")
        (if (yes? kpc)
            (right-head! knpc)
            ))
      (say knpc "Heu, Oui, Perceval c'est moi. Puis-je vous aider ?")
      ))

(define (jake-drin knpc kpc)
  (if (left-head? knpc)
      (say knpc "QUOI ??? DEMANDE A PERCY !!!")
      (jake-trade knpc kpc)))


;; Trade...
(define jake-merch-msgs
  (list nil ;; closed
        "Laissez-moi vous montrer le menu." ;; buy
        nil ;; sell
        nil ;; trade
        "Je suis ravi d'avoir pu vous aider." ;; bought-something
        "[Sniff!] Eh bien, tant pis, je ne serai pas offensé." ;; bought-nothing
        nil
        nil
        nil
        nil
   ))

(define jake-catalog
  (list
   (list t_food 7 "Mon agneau rôti est divin, à vous mettre à genoux devant ! J'ai bien peur qu'il ne soit gâché par la racaille habituelle.")
   (list t_beer 4 "J'importe des fûts de bière des célèbres brasseurs du Longeron des Géants.")
   (list t_wine 6 "Nous obtenons du très bon vin d'un voyou spécialisé dans le vol de caves à vin. J'espère que vous ne reconnaitrez aucune de ces bouteilles ...  Ahem...")
   ))

(define (jake-trade knpc kpc) (conv-trade knpc kpc "buy" jake-merch-msgs jake-catalog))

;; Town & Townspeople

;; Quest-related

(define jake-conv
  (ifc basic-conv

       ;; basics
       (method 'default jake-default )
       (method 'bonj jake-hail )
	   (method 'hail jake-hail )
	   
       (method 'adie jake-bye )
       (method 'trav jake-job )
       (method 'nom jake-name )
       (method 'join jake-join )
       
       ;; trade
       (method 'bois jake-drin )
       (method 'comm jake-trade )
       (method 'ache jake-trade )

       ;; town & people
       (method 'jake jake-jake )
       (method 'perc jake-perc )
       ))

(define (mk-jake)
  (bind 
   (kern-mk-char 
    'ch_jake           ; tag
    "Jake&Perceval"             ; name
    jake-species         ; species
    jake-occ              ; occ
    s_gint     ; sprite
    faction-men      ; starting alignment
    0 0 0            ; str/int/dex
    0 0              ; hp mod/mult
    0 0              ; mp mod/mult
    max-health ; hp
    -1                   ; xp
    max-health ; mp
    0
    jake-lvl
    #f               ; dead
    'jake-conv         ; conv
    sch_jake           ; sched
    'townsman-ai              ; special ai
    nil              ; container
    nil              ; readied
    )
   (jake-mk)))
