;;----------------------------------------------------------------------------
;; Constants
;;----------------------------------------------------------------------------
(define slywan-lvl 2)
(define slywan-species sp_human)
(define slywan-occ oc_wrogue)

;;----------------------------------------------------------------------------
;; Schedule
;; 
;; In the monster town of Kun.
;;----------------------------------------------------------------------------
(kern-mk-sched 'sch_slywan
               (list 0 0 kun-road "travaille")
               (list 2 0 campfire-2 "dort")
               (list 9 0 cantina-9 "suis en pause")
               (list 14 0 black-market "suis en pause")
               (list 17 0 cantina-9 "suis en pause")
               (list 23 0 kun-road "travaille")
               )

;;----------------------------------------------------------------------------
;; Gob
;;----------------------------------------------------------------------------
(define (slywan-mk) nil)

;;----------------------------------------------------------------------------
;; Conv
;; 
;; Slywan is a thief (an accomplished pickpocket) 
;; living in the monster village of Kun.
;;----------------------------------------------------------------------------

;; Basics...
(define (slywan-hail knpc kpc)
  (kern-log-msg "Vous rencontrez un homme agile.")
  (say knpc "Bonjour, tu veux connaître mon petit secret ?")
  )

(define (slywan-default knpc kpc)
  (say knpc "[Il hausse les épaules et sourit faiblement]")
  )

(define (slywan-name knpc kpc)
  (say knpc "Slywan, à votre service")
  )

(define (slywan-join knpc kpc)
  (say knpc "Désolé, mon vieux")
  )

(define (slywan-job knpc kpc)
  (say knpc "Ceci et cela. Vous savez.")
  )

(define (slywan-bye knpc kpc)
  (let ((q (min (kern-player-get-gold)
                (kern-dice-roll "1d20"))))
    (take-player-gold q)
    (kern-obj-add-to-inventory knpc t_gold_coins q)
    (say knpc "A bientôt")
    ))

(define (slywan-this knpc kpc)
  (say knpc "Et cela"))

(define (slywan-that knpc kpc)
  (say knpc "Et ceci"))

(define (slywan-bust knpc kpc)
  (say knpc "Oups ! Il faut que j'y aille! A notre prochaine rencontre! ...")
  (kern-obj-add-effect knpc ef_invisibility nil)
  (kern-char-set-fleeing knpc #t)
  (kern-being-set-current-faction knpc faction-outlaw)
  (kern-conv-end)
  )

(define (slywan-thie knpc kpc)
  (say knpc "Quoi ? Quelqu'un vous a-t-il vole de l'or ?")
  (if (yes? kpc)
      (begin
        (say knpc "Vous ne m'accusez certainement pas ?")
        (if (yes? kpc)
            (slywan-bust knpc kpc)
            (say knpc "Oh... heh. Bien sûr que non. Désolé, je n'ai rien vu.")))
      (say knpc "Vous avez de la chance, c'est une ville difficile. Ne faites confiance à personne !")))

(define slywan-conv
  (ifc nil

       ;; basics
       (method 'default slywan-default )
       (method 'bonj slywan-hail )
	   (method 'hail slywan-hail )
	   
       (method 'adie slywan-bye )
       (method 'trav slywan-job )
       (method 'nom slywan-name )
       (method 'join slywan-join )

       (method 'ceci slywan-this )
       (method 'cela slywan-that )
       (method 'secr slywan-bust )
       (method 'vole slywan-thie )
       (method 'or slywan-thie )
       (method 'vole slywan-thie )
       ))

(define (mk-slywan)
  (bind 
   (kern-char-force-drop
   (kern-mk-char 
    'ch_slywan           ; tag
    "Slywan"             ; name
    slywan-species         ; species
    slywan-occ              ; occ
    s_brigand     ; sprite
    faction-men      ; starting alignment
    1 0 4            ; str/int/dex
    0  ; hp bonus
    0 ; hp per-level bonus
    0 ; mp off
    1 ; mp gain
    max-health ; hp
    -1                   ; xp
    max-health ; mp
    0
    slywan-lvl
    #f               ; dead
    'slywan-conv         ; conv
    sch_slywan           ; sched
    'townsman-ai              ; special ai
    (mk-inventory nil) ;; container
    (list t_sword
					         t_armor_leather
					         )               ; readied
    )
   #t)
   (slywan-mk)))
