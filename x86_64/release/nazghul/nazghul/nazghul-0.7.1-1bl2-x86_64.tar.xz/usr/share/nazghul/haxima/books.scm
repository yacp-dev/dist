;; ----------------------------------------------------------------------------
;; books.scm -- reading material
;; ----------------------------------------------------------------------------

(kern-mk-sprite-set 'ss_books 32 32 2 2 0 0 "books.png")

(kern-mk-sprite 's_lexicon ss_books 1 0 #f 0)
(kern-mk-sprite 's_manual  ss_books 1 1 #f 0)
(kern-mk-sprite 's_scroll  ss_books 1 2 #f 0)

;; Fixme: see if something like this will work for books:
(define (mk-book tag name . text)
  (mk-reusable-item 
   tag name s_manual norm
   (lambda ()
     (kern-ui-page-text text))))

;;----------------------------------------------------------------------------
;; player manual
(define (basic-survival-manual-commands)
  (kern-ui-page-text
   "Sommaire des commandes"
   "Utilisez les touches fléchées pour indiquer"
   "la direction."
   "Utilisez la touche ESC pour annuler les"
   "commandes."
   "Utilisez la première lettre pour commencer"
   "une commande."
   "Pour des informations détaillées, voir le"
   "guide de l'utilisateur."
   ""
   "A: Attaquer quelque chose"
   "B: Monter à bord d'un navire ou d'un autre"
   "   véhicule"
   "C: Jeter un sortilège"
   "E: Entrer dans une ville ou un donjon"
   "F: Tirer avec un canon de navire ou d'autres"
   "   munitions"
   "G: Prendre quelquechose sur le sol"
   "H: Manipuler un levier ou un autre mécanisme"
   "L: Flâner quelques heures"
   "N: Nouvel ordre (réarrangement de l'ordre"
   "   de l'équipe)"
   "O: Ouvrir un coffre, une porte ou tout autre"
   "   objet fermé"
   "Q: Quitter et peut sauver la partie"
   "R: Préparer une arme"
   "S: Rechercher des objets cachés"
   "T: Parler à quelqu'un"
   "U: Utiliser un article dans l'inventaire"
   "Z: Afficher les stats de l'équipe"
   "X: Examiner les alentours"
   "@: informations sur le lieu et l'heure"
   "<espace> Passer un tour"
   "CTRL-S: Enregistrer la partie"
   "CTRL-R: Recharger un jeux sauvegardé"
   "SHIFT+TOUCHE CURSEUR: Faire défiler la"
   "     fenêtre d'affichage."
   )
  result-ok)

(mk-reusable-item 't_manual "Manuel de survie de base" s_manual (/ norm 3)
                  basic-survival-manual-commands)

;;----------------------------------------------------------------------------
;; letter from enchanter
(mk-reusable-item 
 't_letter_from_enchanter "Lettre importante" s_lexicon norm
 (lambda (klexicon kuser)
   (kern-ui-page-text
   "A l'attention du Vagabond -- IMPORTANT"
   " "
   "Il est très ^c+rimportant^c- "
   "que vous ME TROUVIEZ. "
   "Le paysan qui s'occupe de ce sanctuaire peut "
   "indiquer le chemin. Prenez garde."
   ""
   "-- Signé L'Enchanteur\n"
   )
   (quest-data-assign-once 'questentry-calltoarms)
   result-ok))

;;----------------------------------------------------------------------------
;; book of the demon gate
(mk-reusable-item 
 't_demon_gate_book "Texte rayé" s_scroll v-hard
 (lambda (kbook kuser)
   (kern-ui-page-text
   "LA PORTE DES DÉMONS"
   " "
   "...le Sage d'autrefois a verrouillé la Porte"
   "des Démons et a dispersé les clés... "
   "le sanctuaire de la Porte des Démons ne "
   "devait pas être révélé à nouveau tant que le"
   "monde ne s'est pas RENOUVELÉ... "
   "ils ont dissimulé la route vers le sanctuaire"
   "avec une illusion... "
   "là où il y a un chemin, les imprudents ne"
   "voient qu'une montagne...  "
   " "
   "... le fleuve des étoiles, et le suivre"
   "jusqu'à sa source... "
   " "
   "... à celui qui ouvre la Porte, "
   "... une puissance inimaginable ... "
   ""
   "...Nossifer attend."
   ""
   "-- Signé Fildex l'impur\n"
   )
   result-ok))

;;----------------------------------------------------------------------------
;; Kathryn's Letter
(mk-reusable-item 
 't_kathryns_letter "Lettre" s_scroll norm
 (lambda (kletter kuser)
   (kern-ui-page-text
   "Lettre"
   " "
   "Cher K.,"
   "L'Enchanteur possède une des runes."
   "L'acquérir par tous les moyens nécessaires, "
   "et ne laissez personne raconter l'histoire. "
   "Même pas à un fantôme."
   " "
   "-- Signé S.")
   result-ok))


;;----------------------------------------------------------------------------
;; The soliloquy from Hamlet:
(mk-reusable-item 
 't_playbook_hamlet "Livre de jeux" s_scroll norm
 (lambda (kletter kuser)
   (kern-ui-page-text
   "Un livre de jeu partiel"
   " "
   "Être ou ne pas être : telle est la question :"
   "Est-il plus noble de souffrir dans l'esprit"
   "Les frondes et les flèches de la chance"
   "outrageante,"
   "Ou pour prendre les armes contre un océan "
   "de problèmes,"
   "Et en s'opposant à eux, ils y mettent fin ?"
   "Mourir : dormir ;"
   "Pas plus ; et par un sommeil pour dire que "
   "nous arrêtons"
   "Le mal du coeur et les mille chocs naturels"
   "Cette chair est l'héritière, c'est "
   "accomplissement"
   "Sincèrement à souhaiter. Mourir, dormir;"
   "Dormir : peut-être rêver : oui, c'est là que "
   "le bât blesse ;"
   ""
   "Car dans ce sommeil de mort, quels rêves "
   "peuvent venir"
   "Une fois que nous aurons arrêté cette spirale"
   "mortelle,"
   "Doit nous faire réfléchir : il y a le respect"
   "Cela fait une calamité de si longue vie ;"
   ""
   "Car qui supporterait les fouets et les mépris"
   "du temps,"
   "L'oppresseur a tort, l'homme fier est"
   "contumément,"
   "Les douleurs de l'amour méprisé, le retard "
   "de la loi,"
   "L'insolence du devoir et les rejets"
   "Ce mérite patient des indignes prend,"
   "Quand lui-même pourrait faire son silence"
   "Avec un corps nu? qui porterait les fardeaux,"
   "Pour grogner et transpirer sous une "
   "vie épuisante,"
   "Mais que la crainte de quelque chose "
   "après la mort,"
   "Le pays inconnu dont"
   "aucun voyageur ne revient, ce qui laisse"
   "perplexe la volonté"
   "Et nous fait plutôt supporter les maux que"
   "nous avons"
   "Que de voler vers d'autres que nous ne"
   "connaissons pas ?"
   ""
   "Ainsi, la conscience fait de nous tous"
   "des lâches ;"
   "Et donc la teinte originelle "
   "de la détermination"
   "est malade à cause de la pâleur "
   "de ses pensées,"
   "Et des projets de grande envergure "
   "À cet égard, leurs courants tournent mal,"
   "Et perd le nom de l'action."
   "La belle Ophelia ! Nymphe, dans tes oraisons"
   "Que tous mes péchés reviennent à ma mémoire"
   )))

;;----------------------------------------------------------------------------
;; Spell books
(mk-reusable-item 
 't_ylem_an_ex_book "Livre de sorts : YAE" s_manual hard
 (lambda (kletter kuser)
   (kern-ui-page-text
   "Sortilège 'Toile d'araignée'- Ylem An Ex"
   ""
   "Un sort utile pour les lanceurs de sorts"
   "débutants."
   "La toile d'araignée permet à un adversaire"
   "distant d'être empêtré et rendu impuissant"
   "pour une courte période de temps."
   ""
   "Si elle est utilisée correctement, elle peut"
   "également bloquer un endroit temporairement,"
   "bien que ce soit difficile à réaliser pour "
   "les novices."
   ""
   "Le sort nécessite de la soie d'araignée, "
   "bien sûr, et aussi de la perle noire, pour "
   "projeter la toile sur la cible désirée."
   ""
   "Avec le mélange approprié, entonnez "
   "Ylem An Ex (permet d'entraver le liberté) et "
   "lancez le filet de toile vers vos ennemis."
   ) 
   result-ok))

(mk-reusable-item 
 't_bet_flam_hur_book "Livre de sorts : BFH" s_manual hard
 (lambda (kletter kuser)
   (kern-ui-page-text
   "Jet de feu- Bet Flam Hur"
   ""
   "Si l'efficacité du sort Vent de Flamme est "
   "reconnue, il est difficile à lancer"
   "et est épuisant."
   "Il est bien au-delà des moyens de tous sauf"
   "des plus grands mages."
   ""
   "Le sort Vent de Feu est une adaptation du"
   "sort Vent de Flamme aux besoins modestes."
   "Bien qu'il ne puisse pas être lancé par un "
   "débutant absolu, il requiert une capacité "
   "minimale. L'efficacité du sort augmente,"
   "bien sûr, avec l'habileté du lanceur."
   ""
   "Le sort Jet de Feu a une portée limitée - "
   "pas beaucoup plus grande qu'une arme "
   "contondante - et n'a pas une puissance"
   "suffisante pour quitter les champs brûlants"
   "associés au sort Vent de Flamme."
   ""
   "Le sort nécessite des cendres sulfureuses "
   "pour alimenter la flamme. Le lancement "
   "initial du sort est assuré par la perle"
   "noire, et la mousse de sang insuffle le"
   "mouvement du cône de feu qui se propage."
   ""
   "Avec ce mélange, entonnez 'Bet Flam Hur' "
   "(Petit vent de feu) et dirigez le cône pour "
   "engloutir vos ennemis."
   )
   result-ok))

(mk-reusable-item
 't_ranger_orders "Ordres des Rangers" s_scroll norm
 (lambda (kletter kuser)
   (kern-ui-page-text
    "Ordres des Rangers"
    ""
    "Le porteur de cette lettre peut enrôler "
    "un (1) ranger en service temporaire "
    "limité.")
   result-ok))

(mk-reusable-item
 't_prisoner_receipt "Reçu pour les prisonniers" s_scroll norm
 (lambda (kletter kuser)
   (kern-ui-page-text
    "Reçu pour les prisonniers"
    ""
    "Le porteur de cette lettre a remis "
    "un (1) prisonnier au geôlier.")
   result-ok))


;;;;;;;;;;;;;;;;;;;; White Magick ;;;;;;;;;;;;;;;;;;;;

(mk-reusable-item
 't_spell_book_white_magick_1 "livre 'La Magie Blanche' (Livre I)" s_manual (/ norm 3)
 (lambda (kbook kuser)
   (kern-ui-page-text
    "La Magie Blanche : Livre I"
    "Les sorts de guérison, du Premier Cercle"
    "+-------------------------------------------+"
    "| M)élangez vos réactifs pour créer un      |"
    "| sort, puis le jeter (C) au moment voulu.  |"
    "| Par la tradition du BLANC, vous serez     |"
    "| guéris, alors que vous vous rétablissez   |"
    "| soyez encore SAGE !                       |"
    "+-------------------------------------------+"
    "Guérir le poison <AN NOX>"
    "- Mélanger le ginseng et l'ail"
    ""
    "Réveiller <AN ZU>"
    "- Mélanger le ginseng et l'ail"
    ""
    "Guérison mineure <MANI>"
    "- Mélange de ginseng et de soie d'araignée"
    )
   result-ok))

(mk-reusable-item
 't_spell_book_white_magick_2 "livre 'La Magie blanche' (Livre II)"  s_manual (/ norm 3)
 (lambda (kbook kuser)
   (kern-ui-page-text
    "Magie blanche: Livre II"
    "Sorts de guérison et de protection"
    "+-------------------------------------------+"
    "|  Le savoir traditionnel que vous détenez  |" 
	"|  pour mélanger et jeter un sort.          |"
    "|  Soyez bien servis par ces chants.        |"
    "|  Mais n'oubliez pas, ô Sage, du devoir,   |"
    "|  de guérir tout ceux qui viennent à toi.  |"
    "+-------------------------------------------+"
    "Protection contre le Poison <SANCT NOX>"
    "- Mélangez l'Ail, l'Ombre Nocturne et le "
	"  champignon à Cape Royale"
    ""
    "Protection contre le feu <IN FLAM SANCT>"
    "- Mélanger la cendre sulfureuse, l'ail, "
    "- et ne l'oubliez pas : [LES PAROLES]"
    ""
    "Dissiper la magie <An Ort Xen>"
    "- Mélangee la cendre sulfureuse, l'ail et"
	"  la mandragore"
    ""
    "Protection <IN SANCT>"
    "- Mélanger la cendre sulfureuse, l'ail et "
	"  le ginseng"
    ""
    "Guérison de masse du poison <VAS AN NOX>"
    "- Mélangez l'ail, le ginseng et "
	"  la mandragore"
    ""
    "Grande guérison <VAS MANI>"
    "- Mélange de ginseng, soie d'araignée,"
	"  et la mandragore"
    )
   result-ok))

(mk-reusable-item
 't_spell_book_white_magick_3 "livre 'La Magie blanche' (Livre III)"  s_manual (/ norm 3)
 (lambda (kbook kuser)
   (kern-ui-page-text
    "Magie blanche: Livre III"
    "Sorts de guérison, de haute magie"
    "+-------------------------------------------+"
    "| Mélangez, et Maître Couronné, lancez!     |"
    "| Mais attention,le pouvoir vers toi se hâte|"
    "| Si vous êtes Sage, alors agissez ainsi:   |"
    "|  KAL WIS - IN MANI - AN CORP - ZU QUAS    |"
    "+-------------------------------------------+"
    "Guérison de masse du poison<VAS AN NOX>"
    "- Mélange de ginseng, d'ail, de mandragore"
    ""
    "Protection de masse contre le poison"
	"  <VAS SANCT NOX>"
    "- Mélangez l'ail, l'Ombre Nocturne, la "
	"  mandragore et la Cape Royale"
    ""
    "Grande guérison <VAS MANI>"
    "- Mélange de ginseng, soie d'araignée, "
	"  et de Mandragore"
    ""
    ""
    "--------------- HAUTE MAGIE -----------"
    ""
    "Résurrection <IN MANI CORP>"
    "- Mélange de ginseng, d'ail et de soie "
	"  d'araignée, "
    "- de Cendre sulfureuse, mousse de sang,"
	"  mandragore"
    ""
    "-- Ne tuez pas ce qui doit vivre !   -- "
    "-- Ne réveillez pas pas ce qui doit  --"
	"-- se reposer!                       --"

    )
   result-ok))


;;;;;;;;;;;;;;;;;;;; Force Magick ;;;;;;;;;;;;;;;;;;;;

(mk-reusable-item
 't_spell_book_force_magick_12 "livre 'Magie de la force' (Livre I)" s_manual (/ norm 3)
 (lambda (kbook kuser)
   (kern-ui-page-text
    "Magie de la force: Livre I"
    "Sorts de pouvoir, des cercles I, II      "
    "+-------------------------------------------+"
    "| Mélangez vos réactifs pour créer un sort, |"
    "| puis jetez-le au moment venu. Par la FORCE|"
    "| tes ennemis connaîtront la PEUR,          |"
    "|  mais les imbéciles qui lancent ainsi,    |"
	"|  connaitront le MALHEUR!                  |"
    "+-------------------------------------------+"
    "Les sorts du Cercle I :"
    "-----------------------"
    "Projectile magique <GRAV POR>"
    "- Mélange de cendre sulfureuse et de "
	"  perle noire"
    ""
    "Lumière <IN LOR>"
    "- Mélange de cendres sulfureuses"
    ""
    "------------------------"
    "Les sorts du Cercle II :"
    "------------------------"
    "Changer le vent <REL HUR>"
    "- Mélange de cendres sulfureuses et de "
	"  mousse de sang"
    ""
    "Jet de Feu <BET FLAM HUR>"
    "- Mélange de cendres sulfureuses et de "
	"  mousse de sang, "
    "-    et de Perle noire"
    ""
    "Flèche empoisonnée <IN NOX POR>"
    "- Mélange d'Ombre Nocturne, mousse de sang,"
    "-     et de Perle noire"
    )
   result-ok))

(mk-reusable-item
 't_spell_book_force_magick_battle "livre 'Magie de la force' (De la bataille)"  s_manual (/ norm 3)
 (lambda (kbook kuser)
   (kern-ui-page-text
    "Magie de la force : De la bataille"
    "+-----------------------------------------+"
    "| Bataille à proximité :                  |"
	"| Chanter les runes et mélanger           |"
    "| La bataille continue :                  |"
	"| Lancez et jetez avec violence           |"
    "| Tes ennemis connaitront la douleur,     |"
	"| et même la mort                         |"
    "| Mais maniez-vous que la puissance,      |"
	"| ou êtes vous sage ?                     |"
    "+-----------------------------------------+"
    "Les sorts du Cercle I :"
    "-----------------------"
    "Projectile magique <GRAV POR>"
    "- Mélange de cendre sulfureuse "
	"  et de perle noire"
    ""
    "Eclair <ORT GRAV>"
    "- Mélange de cendre sulfureuse, de perle "
	"  noire et de mandragore"
    ""
    "-------------------------"
    "Les sorts du Cercle III :"
    "-------------------------"
    "Boule de feu <VAS FLAM>"
    "- Mélange de cendre sulfureuse "
	"  et de perle noire"
    ""
    "Protection contre le Feu <IN FLAM SANCT>"
    "- Mélange de cendres sulfureuses, "
    "- et n'oublie pas :Royal [TRAINEE DE CENDRES]"
    ""
    "------------------------"
    "Les sorts du Cercle VI :"
    "------------------------"
    "Tremblement de terre <IN VAS POR YLEM>"
    "- Mélange de cendres sulfureuses, "
	"  mousse de sang, mandragore"
    )
   result-ok))


(mk-reusable-item
't_spell_book_force_magick_winds "livre 'Magie de la force' (Vents mortels)"  s_manual (/ norm 3)
 (lambda (kbook kuser)
   (kern-ui-page-text
    "Magie de la force : Vents mortels"
    "+-------------------------------------------+"
    "|  Pour le vent, vous mélangerez,           |"
	"|Pour le vent, vous lancerez !              |"
    "|Ton ennemi, endormi, ne connaîtra rien,    |"
    "|Ton ennemi, frappé, brûlera ou s'envenimera|"
    "|Pourtant, pouvez-vous changer le vent ?    |"
    "|Pour ce que le vent ne change pas,         |"
    "|ne souffle pas. L'auriez-vous donc changé ?|"
    "+-------------------------------------------+"
    "Les sorts du cercle I et II :"
    "------------------------------"
    "Dissiper la Fumée <Bet Ylem Hur>"
    "- Mélange de cendres sulfureuses"
    ""
    "Changer le vent <REL HUR>"
    "- Mélange de cendres sulfureuses "
	"  et de mousse de sang"
    ""
    "Jet de Feu <BET FLAM HUR>"
    "- Mélange de cendres sulfureuses "
	"  et de mousse de sang, "
    "-    et de Perle noire"
    ""
    "-------------------------"
    "Les sorts du Cercle VII :"
    "-------------------------"
    "Vent de sommeil <IN ZU HUR>"
    "- Mélange de ginseng, mousse "
	"  de sang, mandragore"
    ""
    "Vent empoisonné <IN NOX HUR>"
    "- Mélange de cendres sulfureuses "
	"  et de mousse de sang, "
    "-     et d'Ombre Nocturne"
    ""
    "--------------------------"
    "Les sorts du Cercle VIII :"
    "--------------------------"
    "Vent de Flamme <IN FLAM HUR>"
    "- Mélange de cendres sulfureuses "
	"  et de mousse de sang, "
    "-     et de Mandragore"
    )
   result-ok))
(mk-reusable-item
't_spell_book_force_magick_matter "livre 'Magie de la force' (Sur la matière)"  s_manual (/ norm 3)
 (lambda (kbook kuser)
   (kern-ui-page-text
    "Magie de la force : Sur la matière"
    "+-------------------------------------------+"
    "|Mélangez et lancez, par la force controlez |"
    "|la matière. Les pouvoirs subtils et        |"
    "|grandioses s'exercent tous les deux.       |"
    "|Si vous êtes sages, alors répondez à cette |"
	"|énigme :                                   |"
	"|Quel secret, l'acier ? (La chair est douce)|"
    "|Quel son, une main ? (Papillon)            |"
    "+-------------------------------------------+"
    "Les sorts des cercles I et II :"
    "-------------------------------"
    "Détruire les pièges <AN SANCT YLEM>"
    "- Mélange de mousse de sang"
    ""
    "Déverrouiller <AN SANCT>"
    "- Mélange de cendres sulfureuses et de sang"
    ""
    "Verrouiller <SANCT>"
    "- Mélange de cendres sulfureuses, soie "
	"  d'araignée"
    ""
    "Changer le vent <REL HUR>"
    "- Mélange de cendres sulfureuses et de mousse"
	"  de sang"
    ""
    "------------------------"
    "Les sorts du Cercle VI :"
    "------------------------"
    "Tremblement de terre <IN VAS POR YLEM>"
    "- Mélange de cendres sulfureuses, mousse de"
	"  sang, mandragore"
    ""
    "Télékinésie <IN REL POR>"
    "- Mélange de soie d'araignée, mousse de "
	"  sang, perle noire"
    ""
    "----------------"
    "[Notes gribouillées]"
    "----------------"
    "Élever la matière au-dessus de l'eau"
	"<VAS UUS YLEM>"
    "- Essai 1 : Mélange de cendres, de perles et"
	"  de mandragore ???"
    "- Essai 2 : Mélange [TEXT BRULÉ], Oeil de "
	"  triton ?"
    "- Oeil d'Hypnotiseur ? spleen du Dragon  ?"
	"  Crachat d'ogre ?"
    )
   result-ok))

(mk-reusable-item
't_spell_book_force_magick_mechanismus "livre 'Magie de la force' (Mécanique)"  s_manual (/ norm 3)
 (lambda (kbook kuser)
   (kern-ui-page-text
    "Magie de la force : Mécanique"
    "+-------------------------------------------+"
    "| Savoir,  Mélanger, et avec art, Lancer!   |"
    "| Vous avez peur des bagages ?              |"
	"| Les dangers des coffres, c'est du passé!  |"
    "| Les clés sont perdues ?                   |"
	"| Porteur de clés malgré soit-tu  !         |"
    "| La Porte lumineuse n'est pas aussi        |"
	"| puissante !                               |"
    "| Garder le rythme, rester en vogue         |"
    "| Garder le temps (ou son Seigneur)         |"
    "| Avec de telles runes, ne laisse aucune    |"
    "| dispute arracher la clôture [MOT MANQUANT]|"
    "+-------------------------------------------+"
    "Les sorts des cercles I et II :"
    "-------------------------------"
    "Détruire les pièges <An Sanct Ylem>"
    "- Mélange de mousse de sang"
    ""
    "Déverrouiller <An Sanct>"
    "- Mélange de cendres sulfureuses, de mousse"
    "  de sang"
    ""
    "Verrouillage <Sanct>"
    "- Mélange de cendres sulfureuses, soie "
	"  d'araignée"
    ""
    "-----------------------"
    "Les sorts du Cercle V :"
    "-----------------------"
    "Déverrouiller la magie <In Ex Por>"
    "- Mélange de cendres sulfureuses et de"
	"  mousse de sang"
    ""
    "Verrouillage magique <An Ex Por>"
    "- Mélange de cendres sulfureuses, "
	"  d'ail et de mousse de sang"
    )
   result-ok))

(mk-reusable-item
't_spell_book_force_magick_fields "livre 'Magie de la force' (Sur les champs)"  s_manual (/ norm 3)
 (lambda (kbook kuser)
   (kern-ui-page-text
    "Magie de la force : Sur les champs"
    "+-------------------------------------------+"
    "| Mélangez et lancez, la puissance forme les|"
    "| champs.                                   |"
	"| Conjurez le sommeil, le poison, le feu    |"
	"| ou la force,                              |"
    "| ou si cela vous empêche de le faire,      |"
	"| alors dissipez-le.                        |"
    "| IN GRAV - AN POR - AN GRAV - EX POR       |"
    "+-------------------------------------------+"
    "Les sorts du Cercle III :"
    "-------------------------"
    "Champ de sommeil <In Zu Grav>"
    "- Mélange de ginseng, soie d'araignée, "
	"  perle noire"
    ""
    "Champ de poison <In Nox Grav>"
    "- Mélangez la soie d'araignée, la perle noire"
	"  l'Ombre Nocturne"
    ""
    "Champ de feu <In Flam Grav>"
    "- Mélange de cendre sulfureuse, de soie "
	"  d'araignée et de  Perle noire."
    ""
    "------------------------"
    "Les sorts du Cercle IV :"
    "------------------------"
    "Champ de force <In Sanct Grav>"
    "- Mélange de soie d'araignée, de perle "
	"  noire et de mandragore"
    ""
    "Champ de Dissipation <An Grav>"
    "- Mélange de cendre sulfureuse et de "
	"  perle noire"
    )
   result-ok))

(mk-reusable-item
't_spell_book_force_magick_high_magick "livre 'Magie de la force' (Haute Magie)"  s_manual (/ norm 3)
 (lambda (kbook kuser)
   (kern-ui-page-text
    "Magie de la force : Haute Magie"
    "+-------------------------------------------+"
    "|  ATTENTION, ne soyez pas puissants        |"
	"|  en action!                               |"
    "|  ATTENTION, ne soyez pas sages !          |"
    "|  Voici les runes de la HAUTE MAGIE        |"
    "|  Si vous êtes un FOU, vous connaîtrez     |"
	"|  la MORT                                  |"
    "|  Pourtant, si vous le voulez bien,        |"
	"|  voici le POUVOIR gravé                   |"
    "+-------------------------------------------+"
    "Cercle VI - Annuler la magie <In An>"
    "- Mélange de cendre sulfureuse, d'ail et de"
	"  mandragore"
    ""
    "Cercle VII - Coup mortel <Xen Corp>"
    "- Mélange de perle noire, Mandragore"
    ""
    "Cercle VIII - Vent de la mort "
	"<In Vas Grav Corp>"
    "- Mélange de cendres sulfureuses, Ombre "
	"  Nocturne, mandragore"
    ""
    "Cercle VIII - Arrêt du temps <An Tym>"
    "- Mélange d'ail, mousse de sang, mandragore"
    )
   result-ok))


;;;;;;;;;;;;;;;;;;;; Necromancy ;;;;;;;;;;;;;;;;;;;;

(mk-reusable-item
 't_spell_book_necromancy "livre 'Mystères de la mort et de l'immortalité'" s_manual (/ norm 3)
 (lambda (kbook kuser)
   (kern-ui-page-text
    "Mystères de la MORT et de l'immortalité     "
    "+-----------------------------------------+"
    "| Sanctus Corporem ex Nihilo, Rel Oculume |"
    "| De Vermiis Mysteriis, Astralis Sangrem  |"
    "+-----------------------------------------+"
    "II - Devenir un mort-vivant <An Xen Corp>"
    "- Mélange de cendre sulfureuse et d'ail"
    ""
    "VIII - Invoquer les morts-vivants "
	" <Kal Xen Corp>"
    "- Mélangez la soie d'araignée, l'Ombre"
	"  Nocturne, la mandragore"
    ""
    "II - Flèche empoisonnée <In Nox Por>"
    "- Mélange de mousse de sang, de perle noire,"
    "  d'Ombre Nocturne"
    " "
    "VII - Vent empoisonné <In Nox Hur>"
    "- Mélange de cendres sulfureuses, de mousse"
	"  de sang, d'Ombre Nocturne"
    ""
    "VII - Coup mortel <Xen Corp>"
    "- Mélange de perle noire, Ombre Nocturne"
    ""
    "VII - Clone <In Quas Xen>"
    "- Mélange de cendre sulfureuse, de ginseng,"
	"  de soie d'araignée, Mousse de sang, "
	"  Ombre Nocturne, Mandragore"
    ""
    "VIII - Résurrection <In Mani Corp>"
    "- Mélanger la cendre sulfureuse, le "
	" ginseng, l'ail, Soie d'araignée, "
	" mousse de sang, mandragore."
    )
   result-ok))


;;;;;;;;;;;;;;;;;;;; Summoning ;;;;;;;;;;;;;;;;;;;;

(mk-reusable-item
 't_spell_book_summoning "livre 'Invocation Bêtes et entités'" s_manual (/ norm 3)
 (lambda (kbook kuser)
   (kern-ui-page-text
    "Invocation : Bêtes et entités"
    "+------------------------------------------+"
    "| KAL     À l'invocateur - ATTENTION   KAL |"
    "| CORP        N'appelez pas,           XEN |"
    "| BET   Ce que vous ne pouvez renvoyer ORT |"
    "| SANCT  [ABRAD] - [ACAD] - [ABRA]    YLEM |"
    "+------------------------------------------+"
    "II - Invoquer la vermine <In Bet Xen>"
    "- Mélange de cendres sulfureuses,de mousse"
	"  de sang, Soie d'araignée"
    ""
    "V - Invoquer la Bête <Kal Xen>"
    "- Mélange de soie d'araignée, mandragore"
    ""
    "VIII - Invoquer l'Ectoplasme <Kal Xen Nox>"
    "- Mélangez la soie d'araignée, l'Ombre "
	"  Nocturne, la mandragore"
    ""
    "VIII - Invoquer les morts-vivants"
	"  <Kal Xen Corp>"
    "- Mélangez la soie d'araignée, l'Ombre"
	"  Nocturne, la mandragore"
    )
   result-ok))


;;;;;;;;;;;;;;;;;;;; Dimensions and Gate Magick ;;;;;;;;;;;;;;;;;;;;

(mk-reusable-item
 't_spell_book_gate_magick "livre 'Dans les dimensions' (Portes)" s_manual (/ norm 3)
 (lambda (kbook kuser)
   (kern-ui-page-text
    "Dans les dimensions : Portes"
    "+-------------------------------------------+"
    "| En yoyage, la liberté est en effet,       |"
	"| ô Chercheur                               |"
    "|       IN POR - IN WIS - EX POR WIS        |"
    "|                                           |"
    "| L'histoire des lunes,Contrôlez les portes!|"
    "|    SOLEIL - FYER  Radiant 24  (12,12)     |"
    "|    LUNE   - LUMIS Jaune   60, (5)x8       |"
    "|    LUNE   - ORD   Bleu    36, (9)x8       |"
    "|                                           |"
    "| Si vous êtes sages, observez la cire      |"
	"| et le déclin                              |"
    "+-------------------------------------------+"
    "Localiser <In Wis>"
    "- Mélangez l'Ombre Nocturne"
    ""
    "Vision <In Quas Wis>"
    "- Mélangez l'Ombre Nocturne, la Mandragore"
    ""
    "Vascillement <Bet Por>"
    "- Mélangez la Mousse de sang, la perle noire"
    ""
    "Ascension <Uus Por>"
    "- Ne le mélangez pas, ne le lancez pas ! "
	"  Des larmes de l'espace !"
    ""
    "Descente <Des Por>"
    "- Attention à la distorsion! Ne cherchez pas"
	"  ce genre de connaissance !"
    ""
    "Rapidité <Rel Tym>"
    "- Mélangez la cendres sulfureuses, la mousse"
	"  de sang, la mandragore"
    ""
    "Téléporter l'équipe <Vas Por>"
    "- Mélangez la mousse de sang, la perle noire"
	"  la mandragore"
    ""
    "Porte <Vas Rel Por>"
    "- Mélangez la cendre sulfureuse, la perle "
	"  noire et la mandragore"
    )
   result-ok))


;;;;;;;;;;;;;;;;;;;; Enchantment ;;;;;;;;;;;;;;;;;;;;

(mk-reusable-item
 't_spell_book_enchantment_wards "livre 'Enchantements' (Protections)" s_manual (/ norm 3)
 (lambda (kbook kuser)
   (kern-ui-page-text
    "Enchantement : Protections"
    "+-------------------------------------------+"
    "| SANCT -   Protégez-vous!    - SANCT       |"
    "| Mélangez! Jetez des sorts de protection ! |"
    "| S'entourer de champs de force             |"
    "| Chercheur,Vous êtes en danger,Prenez garde|"
    "+-------------------------------------------+"
    "Protection contre le poison <Sanct Nox>"
    "- Mélanger Ail, Ombre Nocturne, Cape Royale"
    ""
    "Protection contre le Feu <In Flam Sanct>"
    "- Mélanger [BRULÉ], [BARBOUILLÉ],"
    "      et la Cape du prince Côtier"
    ""
    "Protection de masse contre le poison "
	"<Vas Sanct Nox>"
    " "
	"- Mélanger Ail, Ombre Nocturne, "
	"  Mandragore, Cape Royale"
    ""
    "Protection <In Sanct>"
    "- Mélanger cendre sulfureuse, ginseng, ail"
    ""
    "Dissiper la magie <An Ort Xen>"
    "- Mélanger cendre sulfureuse, ail, mandragore"
    ""
    "Négation de la magie <In An>"
    "- Mélanger cendre sulfureuse, ail, mandragore"
    ""
    "Champ de force <In Sanct Grav>"
    "- Mélange de soie d'araignée, de perle noire "
	"  et de mandragore."
    )
   result-ok))

(mk-reusable-item
 't_spell_book_enchantment_curses "livre 'Enchantements : Malédiction'" s_manual (/ norm 3)
 (lambda (kbook kuser)
   (kern-ui-page-text
    "Enchantement : Malédiction"
    "+-------------------------------------------+"
    "|    Pour le lecteur Soyez maudits,         |"
    "|  je vous frappe à l'aveuglette !          |"
    "|  -------------------------------          |"
    "|  Gentil lecteur - Soyez sage, Mélangez    |"
    "|  et lancez ces runes quand nécessaire     |"
    "+-------------------------------------------+"
    "Toile d'araignée <Ylem An Ex>"
    "- Mélange de soie d'araignée, de perle noire."
    ""
    "Calmer les araignées <An Xen Bet>"
    "- Mélange Ail, Soie d'araignée."
    ""
    "Dormir <Xen Zu>"
    "- Mélange de ginseng, soie d'araignée"
    ""
    "Charmer les Monstres <An Xen Ex>"
    "- Mélangez la soie d'araignée, la perle noire"
	"  et l'Ombre Nocturne."
    ""
    "Confusion <Quas An Wis>"
    "- mélanger Ombre Nocturne, mandragore."
    ""
    "Peur <In Quas Corp>"
    "- Mélange Ail, Ombre Nocturne, Mandragore."
    )
   result-ok))

(mk-reusable-item
 't_spell_book_enchantment_miscellanea "livre 'Enchantement : divers'" s_manual (/ norm 3)
 (lambda (kbook kuser)
   (kern-ui-page-text
    "Enchantement : divers"
    "+-----------------------------------------+"
    "| [TEXTE TACHÉ] les Secrets!   [FLOU]     |"
    "| Cachez la [TACHÉ] de [MOT BROUILLÉ]     |"
    "| AN EX WIS -                  - KAL QUAS |"
    "+-----------------------------------------+"
    "Rapidité <Rel Tym>"
    "- Mélange de cendres sulfureuses, mousse "
	"  de sang, et de mandragore."
    ""
    "Vue Rayon-X <Wis An Ylem>"
    "- Mélange de cendres sulfureuses, "
	"  et de mandragore."
    ""
    "Invisibilité <Sanct Lor>"
    "- Mélange de mousse de sang, d'Ombre "
	"Nocturne et de mandragore."
    ""
    "Télékinésie <In Rel Por>"
    "- Mélange de soie d'araignée, mousse de sang,"
	"  et de perle noire."
    ""
    "Vent empoisonné <In Nox Hur>"
    "- Mélange de cendres sulfureuses, de mousse"
	"  de sang et d'Ombre Nocturne."
    ""
    "Vent de sommeil <In Zu Hur>"
    "- Mélange de ginseng, mousse de sang,"
	"  et de mandragore."
    ""
    "Arrêt du temps <An Tym>"
    "- Mélange d'ail, mousse de sang, mandragore"
    )
   result-ok))


;;;;;;;;;;;;;;;;;;;; Illusions, Misdirections, and Schemes ;;;;;;;;;;;;;;;;;;;;

(mk-reusable-item
 't_spell_book_illusion_1 "livre 'Illusions : Les petits secrets'" s_manual (/ norm 3)
 (lambda (kbook kuser)
   (kern-ui-page-text
    "Illusions : Les petits secrets"
    "+-------------------------------------------+"
    "| Êtes-vous un Voyou, ou un Mage ?          |"
    "| Par l'artifice,par la ruse, vous Survivrez|"
    "| Utilisez bien ces runes, mélangez-les     |"
	"| et lancez-les.                            |" 
    "+-------------------------------------------+"
    "Dissiper la Fumée <Bet Ylem Hur>"
    "- Mélange de cendres sulfureuses"
    ""
    "Détecter les pièges <Wis Sanct>"
    "- Mélange de cendres sulfureuses"
    ""
    "Sommeil <Xen Zu>"
    "- Mélange de ginseng, soie d'araignée"
    ""
    "Calmer les araignées <An Xen Bet>"
    "- Mélange d'ail, soie d'araignée"
    )
   result-ok))

(mk-reusable-item
't_spell_book_illusion_2 "livre 'Illusions : De plus grands secrets'" s_manual (/ norm 3)
 (lambda (kbook kuser)
   (kern-ui-page-text
    "Illusions : De plus grands secrets"
    "+-------------------------------------------+"
    "| Êtes-vous maître voleur, ou mage masqué ? |"
    "| Artifice Superlatif                       |"
    "|     Une ruse extraordinaire               |"
    "|         Survie Quotidienne                |"
    "|     Mélangez et lancez les runes          |"
    "|  AVERTISSEMENT AU LECTEUR                 |"
    "| NON CARBORUNDUM ILLEGITEMI                |"
    "+-------------------------------------------+"
    "Confusion <Quas An Wis>"
    "- Mélange d'Ombre Nocturne, mandragore"
    ""
    "Charmer les Monstres <An Xen Ex>"
    "- Mélangez la soie d'araignée,la perle noire"
    " et l'Ombre Nocturne."
    " "
    "Peur <In Quas Corp>"
    "- Mélanger Ail, Ombre Nocturne, Mandragore"
    ""
    "Invisibilité <Sanct Lor>"
    "- Mélange de mousse de sang,d'Ombre Nocturne"
	"  et de mandragore"
    )
   result-ok))


;;;;;;;;;;;;;;;;;;;; Divination Magick ;;;;;;;;;;;;;;;;;;;;

(mk-reusable-item
't_spell_book_divination "livre 'Les mystères de la divination'" s_manual (/ norm 3)
 (lambda (kbook kuser)
   (kern-ui-page-text
    "Les mystères de la divination"
    "+-------------------------------------------+"
    "|     IN WIS - AN QUAS - VAS KAL EX WIS     |"
    "| Oh Chercheur, êtes-vous sage?             |"
	"| Devinette, alors                          |"
    "| Je cherche le Chercheur, je tue le Tueur  |"
    "| Je détruit le Voyou,                      |"
	"| Je construit le Constructeur              |"
    "|             Que suis-je donc ?            |"
    "+-------------------------------------------+"
    "Détection des pièges <Wis Sanct>"
    "- Mélanger cendres sulfureuses"
    ""
    "Désactiver les pièges<An Sanct Ylem>"
    "- Mélange de mousse de sang"
    ""
    "Localiser <In Wis>"
    "- Mélangez l'Ombre Nocturne"
    ""
    "Vision <In Quas Wis>"
    "- Mélange d'Ombre Nocturne, mandragore"
    ""
    "Révéler <Wis Quas>"
    "- Mélange de cendre sulfureuse et "
	"d'ombre nocturne"
    ""
    "Vision Rayon-X <Wis An Ylem>"
    "- Mélange de cendres sulfureuses, mandragore"
    )
   result-ok))


;;;;;;;;;;;;;;;;;;;; Master Spellbook ;;;;;;;;;;;;;;;;;;;;

(mk-reusable-item
 't_basic_spell_book "Livre de sorts" s_manual (/ norm 3)
 (lambda (kbook kuser)
   (kern-ui-page-text
    "Livre de sorts"
    ""
    "+-------------------------------------------+"
    "| M)élangez vos réactifs pour créer un sort |"
    "| Puis (C) lancez-le au moment voulu        |"
    "| Ce tome te sera toujours utile            |"
    "| mais ô combien tu dois lire avec attention|"
    "+-------------------------------------------+"
    "                                           "
    "................... Réactifs ................"
    "GI Ginseng                 SS Soie d'araignée"
    "GA Ail                     BP Perle noire"
    "SA Cendre sulfureuse       BM Mousse de sang"
    "NI Ombre Nocturne          MA Mandragore"
    "...................... Sorts ................"
    "-------------- Premier cercle ---------------"
    "An Nox           Guérir le poison     GI, GA"
    "An Zu            Réveiller            GI, GA"
    "Grav Por         Projectile magique   SA, BP"
    "In Lor           Lumière              SA    "
    "Mani             Guérison             GI, SS"
    "Wis Sanct        Détecter les pièges  SA    "
    "An Sanct Ylem   Désactiver les pièges BM    "
    "-------------- Deuxième cercle --------------"
    "An Sanct         Déverrouiller         SA, BM"
    "An Xen Corp Repousser les morts-vivants GA,SA"
    "In Wis           Localiser                 NI"
    "Rel Hur          Changer le Vent        SA,BM"
    "In Nox Por       Missile Empoisonné NI, BM,BP"
    "In Bet Xen      Invoquer la vermine SS, BM,SA"
    "-------------- Troisième cercle -------------"
    "In Flam Grav     Champ de feu     SA, BP, SS"
    "In Zu Grav       Champ de sommeil GI, BP, SS"
    "In Nox Grav      Champ de poison  NI, BP, SS"
    "Vas Flam         Boule de feu     BP, SA    "
    "Vas Lor          Grande Lumière   SA, MA    "
    "-------------- Quatrième cercle -------------"
    "An Grav          Champ de Dissipation   BP,SA"
    "In Sanct Grav    Champ d'énergie     MA,BP,SS"
    "In Sanct         Protection          SA,GI,GA"
    "Wis Quas       Révéler ce qui est caché NI,SA"
    "Bet Por          Sautillement          BP, BM"
    "-------------- Cinquième cercle -------------"
    "In Ex Por        Déverrouiller la magie SA,BM"
    "An Ex Por        Serrure magique SA, BM, GA"
    "In Zu            Sommeil         GI, NI, SS"
    "Vas Mani         Grande guérison GI, SS, MA"
    "Rel Tym          Rapidité        SA, BM, MA"
    "Kal Xen          Invoquer la bête    SS, MA"
    "-------------- Sixième cercle  --------------"
    "An Xen Ex        Charmer            BP, NI,SS"
    "In An       Négation de la magie   GA, MA, SA"
    "In Vas Por Ylem Tremblement de terre BM,MA,SA"
    "Quas An Wis      Confusion             MA, NI"
    "Wis An Ylen      Vision Rayon-X        MA, SA"
    "In Rel Por       Télékinésie       BP, BM, SS"
    "Vas Por        Téléporter l'équipe MA, BP, BM"
    "------------- Septième cercle ---------------"
    "In Nox Hur       Vent empoisonné    NI, SA,BM"
    "In Quas Corp     Peur               NI, MA,GA"
    "In Quas Wis      Scruter            NI, MA   "
    "In Quas Xen      Cloner             NI, MA,SA"
    "...              ...                SS, BM,GI"
    "Sanct Lor        Invisibilité       NI, MA,BM"
    "Xen Corp        Tuer                NI, BP   "
    "-------------- Huitième cercle --------------"
    "An Tym           Arrêt du temps     MA, GA,BM"
    "In Flam Hur      Vent de flamme     MA, SA,BM"
    "In Vas Grav Corp Vent d'Énergie     MA, SA,NI"
    "In Mani Corp     Ressusciter        GA, GI,SS"
    "...              ...                SA, BM,MA"
    "Kal Xen Corp Invoquer morts-vivants SS, MA,NI"
    "Vas Rel Por Voyage par les Portes   SA, MA,BP"
    )
   result-ok))
   
;;----------------------------------------------------------------------------
;; Anaxes letters
(mk-reusable-item
 't_anaxes_letter "Lettre à Anaxes" s_scroll v-hard
 (lambda (kletter kuser)
   (kern-ui-page-text
    "Lettre"
    ""
    "Anaxes,                                      "
    "                                             "
    "Mon amour le plus cher. Les Douzes t'ont     "
	"chassé (Luximène les a complètement          "
	"effarouchés).Il a publié un édit selon lequel"
    "l'ancienne religion est illégale,et tous ceux"
	"qui font preuve de piété envers un dieu      "
	"sera maudit.                                 "
    "                                             "
    "Au moment où j'écris ces lignes, les légions "
	"de Glasdrin et la Marche de Tulemane sur     "
	"Brundegarde.Je vais les détruire avant qu'ils"
	"ne vous atteignent. Scellez les entrées de   "
	"peur que mon sacrifice ne soit vain.         "
    "                                             "
    "Sache, mon amour,que je ne t'ai jamais trahi."
	"Puisse nos esprits se rencontrer dans le Vide"
	"et Vale exigeait son prix de nos ennemis.    "
    "                                             "
    "Amitié,                                      "
    "  Isin                                       "
    "                                             "
    "P.S. Les Titans sont en sécurité. J'ai vu que"
    "ceux qui les connaissaient ont été tués.     "
    )
   result-ok))

;;----------------------------------------------------------------------------
;; Stewardess's Journal
;;
;; TODO: update last entry time to match when warritrix quest becomes available
;; Journal should not be updated if stolen by wanderer (This would also destroy its applicability as evidence)
;;
(mk-reusable-item 
 't_stewardess_journal "Journal de Victoria" s_lexicon norm
 (lambda (klexicon kuser)
   (kern-ui-page-text
    "Journal de Victoria"
    ""
    "1.3.1610"
    "Je crains que si la Warritrix devienne       "
	"davantage populaire, alors la prochaine      "
	"fois qu'elle me défie elle conduira à        "
	"une révolte ouverte. Des mesures extrêmes    "
    "doivent être prises, je le crains. Je dois   "
	"être le plus prudent.Peut-être que 'nos amis'"
	"peuvent nous aider.  "
    "Ils nous doivent une grande dette. Non pas"
    "qu'on peut leur faire confiance. "
    ""
    "..."
    ""
    "11.13.1610"
    "J'ai finalement réussi à mettre ce parasite "
	"de Valus hors du chemin. Une petite preuve "
	"dans le bon endroit,quelques vilaines rumeurs"
	"et les gens sont prêts à accepter qu'il est "
	"devenu un ivrogne déviant.Je crois que le fou"
    "désespéré aurait eu la témérité de frapper  "
    "la statue si je ne l'avait pas détenu dans  "
    "une cellule. Les pouvoirs de la statue sont "
	"probablement un mythe, mais je ne vois pas "
	"l'intérêt de prendre des risques.  "
    ""
    "..."
    ""
    "4.1.1611"
    "S. m'a averti que les rumeurs d'un Vagabond"
    "sont en cours. "
	"S. est un outil tellement utile."
    "Je ne me demande pas d'où il obtient ses "
	"informations. "
    "Je ne sais pas pourquoi il s'énerve à propos"
	"d'un Vagabond, de toute façon. Je suis sûr "
	"que les légendes à leur sujet sont "
	"grandement exagérées. La dernière fois "
	"qu'un Vagabond est apparu, les anciens dieux"
	"marchaient encore dans le Tesson, "
	"si les mythes sont vrais.                "
    ""
    "..."
    ""
    "6.12.1611"
    "J'ai reçu un message de S. Tout est prêt."
    "Je vais suggérer à Jeffries que les rumeurs"
    "des esprits sauvages qui occupent les Salles"
	"Perdues doivent faire l’objet d’une enquête"
	"et insistera sur la Warritrix à la tête de"
	"l'expédition. Ils s'attendront à de la "
	"vulgaire racaille, pas à de la sorcellerie,"
	"et S. s'assurera que la voie est fermée "
	"derrière eux.     "
    "Il n'y aura pas d'échappatoire, et s'il y en"
	"a une, Je ne serais pas coupable. "
	"Au contraire, cet idiot de Jeffries sera "
	"condamné pour incompétence.      "
    ""
    "La seule chose qui pourrait me condamner"
	"est ce journal. Mais personne ne le "
	"trouvera jamais, "
    "et quand je serais la reine de tout le"
	"Tesson, les scribes en auront besoin"
	"pour leur histoire.            "
    ""
    "..."
   )
   result-ok))
