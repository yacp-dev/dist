# ChangeLog

## 1.21.1

### Fixed
- Validate inputs before interpolating them into a KMS HTTP request.

## 1.21.0

### Changed
- Bump downloaded libbson version from 2.3.3 to 2.5.6.

### Removed
- Discontinue builds for EOL Debian releases (version 11, 10, and 9) and remove corresponding CI tasks.
- Remove support for the `prefixPreview`, `suffixPreview`, and `substringPreview` query types. Setting them with `mongocrypt_ctx_setopt_query_type` or using them in encryptedFields is now an error.

## 1.20.5

### Fixed
- Fix possible abort parsing endpoints.
- Reject more payloads that cannot be decrypted in explicit decryption.
- Fix more degenerate cases of masterKey parsing.

## 1.20.4

### Fixed
- Reject undersized decryption payloads.

## 1.20.3

### Fixed
- Validate database and collection name arguments against "." and NUL bytes.

## 1.20.2

### Changed
- Add checks when creating GCP requests.

## 1.20.1

### Changed
- Bump downloaded libbson version from 2.3.0 to 2.3.3 to address configuration error with CMake 4.4.0.

## 1.20.0

### Added
- Stable support for substring queries.

### Removed
- RHEL 6.2 builds. Use the `linux-x86_64-glibc_2_7-nocrypto` build instead as it has an equivalent glibc requirement.

## 1.19.2

### Added
- Add static library files to GitHub releases.

## 1.19.1

### Added
- Restore support for the experimental `prefixPreview` and `suffixPreview` query types.


## 1.19.0

### Added
- Stable support for prefix and suffix queries:
    - The `prefixPreview` query type is replaced with `prefix`.
    - The `suffixPreview` query type is replaced with `suffix`.
    - Use the `string` algorithm (formerly `textPreview`) for `prefix`, `suffix`, and `substringPreview` query types.

### Removed
- Support for the experimental `prefixPreview` and `suffixPreview` query types.


## 1.18.2

### Fixed
- Add musl arm64 release to GitHub release. This was an omission in 1.18.0.
- Reject large KMS replies.

## 1.18.1

### Fixed
- Fix QE text explicit encryption handling of `caseSensitive` and `diacriticSensitive` options.
    - This is a backwards breaking bug fix, but only applies to the experimental QE text algorithm "TextPreview".
- Fix handling of malformed KMS replies.

## 1.18.0

### Added
- Signed binaries for macOS and Linux are now available on the GitHub release.
    - Linux binaries including `nocrypto` in the name have no dependency on OpenSSL. Drivers using the `nocrypto` variant are expected to set crypto callbacks (e.g. call `mongocrypt_setopt_crypto_hooks`) to do operations requiring crypto to avoid an error.
    - Drivers that package libmongocrypt binaries are encouraged to migrate release scripts to use these binaries.
        - No reduction in platform support is expected. glibc dependencies were checked against existing builds on RHEL 6.2 and Ubuntu 16.04.
- Support referencing keys by `keyAltName` in `encryptedFieldsMap`.

### Changed

- Final release packages in the PPA are now available by specifying `release` in the repository configuration in place of the major/minor version (e.g., `1.17`). Details in `README.md`.
- Bump downloaded libbson version from 2.1.0 to 2.3.0.

### Deprecated
- RHEL 6.2 builds are deprecated and may be removed in the future. The `linux-x86_64-glibc_2_7-nocrypto` release build may be used instead and has equivalent glibc requirements.

### Removed

- The configure-time CMake parameter `ENABLE_WINDOWS_STATIC_RUNTIME` has been
  removed. Users that need the static MSVCRT library should instead set the
  [`CMAKE_MSVC_RUNTIME_LIBRARY`][msvcrt] built-in CMake parameter when
  configuring libmongocrypt.
- Packages for Debian 9 and Debian 10.

[msvcrt]: https://cmake.org/cmake/help/latest/variable/CMAKE_MSVC_RUNTIME_LIBRARY.html

## 1.17.3

### Fixed

- Fix check in KMIP parser.

## 1.17.2

### Fixed

- Fix build warning with GCC 16

## 1.17.1

Add package for Debian Trixie.

## 1.17.0

### New features

- Support mixing QE and unencrypted JSON schemas.

### Fixed

- Comply with CMake policy CMP0148 (use `FindPython` instead of `FindPythonInterp` and `FindPythonLibs`).
- Fix possible resource leak in Queryable Encryption.

## 1.16.0

### Changed

- Set CMake minimum required version to `3.15...4.0` (with maximum policy version set to `4.0`).
- `FetchContent_MakeAvailable()` is used to populate dependencies instead of `FetchContent_Populate()`.
  - This applies to MongoDB C Driver when `MONGOCRYPT_MONGOC_DIR` is not set to `USE-SYSTEM`.
  - This applies to IntelDFP when `MONGOCRYPT_DFP_DIR` is not set to `USE-SYSTEM`.
  - Note: `FetchContent_Populate()` is still used for CMake versions prior to 3.18 to avoid `add_subdirectory()` behavior.
- Bump downloaded libbson version from 1.30.3 to 2.1.0.

### New features
- Support in-place retry on KMS requests.

### Fixed
- Do not propagate `-fPIC` in CMake targets.

## 1.15.2

### Fixed
- Rename internal headers to avoid conflicts building libmongocrypt and C driver together.

## 1.15.1

### Fixed
- Fix possible error when text options include multiple query types and are used for a find payload: `Text search query specification cannot contain multiple query type specifications`.
- Require setting contention for text options.
- Improve error message if text options are unset when using text algorithm.


## 1.15.0

### New features
- Support experimental Queryable Encryption text indexes with `cleanupStructuredEncryptionData` and `compactStructuredEncryptionData`.
- Support experimental explicit encryption for algorithm type: `textPreview` and query types: `prefixPreview`, `suffixPreview` and `substringPreview`
    - Add `mongocrypt_setopt_algorithm_text` to apply options for explicit encryption.

### Fixed
- Bypass command `buildinfo` (previously only `buildInfo` was bypassed).
- Bypass command `serverStatus`.

### Removed
- Support for building with Visual Studio 2015. Use Visual Studio 2017 or newer.

## 1.14.1
### Fixed
- Fix possible missing error state on `mongocrypt_ctx_finalize`.
### Improvements
- Add Ubuntu 24.04 package.

## 1.14.0
### Fixed
- Fix building against libbson with extra alignment enabled (`ENABLE_EXTRA_ALIGNMENT=ON`).
- Retry KMS encrypt request for context created by `mongocrypt_ctx_rewrap_many_datakey_init`.
### Improvements
- Improve performance of OpenSSL crypto operations.
- Improve error for incorrect path to crypt_shared library.
### New features
- Support experimental Queryable Encryption text indexes for automatic encryption.

## 1.13.2
### Notes
- Bump downloaded libbson version from 1.28.1 to 1.30.3. Fixes a CMake configure error on macOS with CMake 4.
## 1.13.1
### Fixed
- Fix possible double free on parse error of malformed payload.
- Fix build failure when configuring with `ENABLE_TRACE=ON`.
- Fix possible redefinition of `_GNU_SOURCE`.

## 1.13.0
### New features
- Support automatic encryption for `$lookup` stages in `aggregate` pipelines on MongoDB server 8.1+.
### Fixed
- Restore default behavior to disable extra alignment when importing libbson. This was the default behavior in 1.11. This can be overridden by setting the CMake option `ENABLE_EXTRA_ALIGNMENT=ON`.
### Removed
- Support for macOS versions older than 11. libmongocrypt is supported and tested with macOS 11+.

## 1.12.0
### New features
- Add option to configure Data Encryption Key cache lifetime (`mongocrypt_setopt_key_expiration`)
- Add opt-in retry behavior for KMS operations (`mongocrypt_setopt_retry_kms`)
### Removed
- libmongocrypt is no longer published in the MongoDB package repository for RHEL 6. libmongocrypt may instead be built from source on RHEL 6, but support for RHEL 6 will be dropped in a future release.
### Notes
- This release unintentionally changes the default behavior of extra alignment with importing libbson. See 1.13.0 release notes.

## 1.11.0
### New features
- Support `range` algorithm as stable.
### Deprecated
- The Windows download URLs for [stable](https://s3.amazonaws.com/mciuploads/libmongocrypt/windows/latest_release/libmongocrypt.tar.gz) and [unstable](https://s3.amazonaws.com/mciuploads/libmongocrypt/windows/latest_release/libmongocrypt_unstable.tar.gz) are now deprecated. See the GitHub Release page for Windows downloads.
## 1.10.1
## Fixed
- Document `range` algorithm as unstable.
## 1.10.0
### New features
- Support KMIP `delegated` option.
- Support processing `bulkWrite` command.
- Support `range` algorithm.
## 1.9.1
### New features
- Add Debian 12 packages
## 1.9.0
### New features
- Support named KMS providers.
- Add `arm64` Debian packages
## Fixed
- Fix `arm64` Alpine build.
## 1.8.4
### Fixed
- Fix `aarch64` packages for RHEL 8, RHEL 9, Amazon 2023, and Amazon 2
## 1.8.3
### Improvements
- Include packages for RHEL 8, RHEL 9, and Amazon 2023
## 1.8.2
### Fixed
- Fix possible leaks in Queryable Encryption in errors on malformed data.
## 1.8.1
- Bypass search index management commands in automatic encryption
## 1.8.0
This release adds stable support of the Queryable Encryption (QE) feature for the "Indexed" and "Unindexed" algorithms.
## 1.8.0-alpha1
This release makes backwards breaking changes to Queryable Encryption (QE) behavior added in the 1.8.0-alpha0 release:
- Do not apply default to min/max values for int/long/date.
- Enable the QEv2 protocol by default. Remove function to enable QEv2.
## 1.8.0-alpha0
### Improvements
- Support Queryable Encryption v2 protocol.
## 1.7.2
### Improvements
- Add toggle for Decimal128 Range Support.
### Fixed
- Fix i686 (32-bit) build.
- Fix 32-bit ARM build.
## 1.7.1
### Improvements
- Vendor Intel DFP library and allow using system DFP.
### Fixed
- Fix possible abort on base64 decode error of KMS messages.
- Fix ILP32-target builds.
- Fix LTO build.
- Fix IntelDFP to not require Git.
## 1.7.0
### New Features
- Add encryptExpression helper
- Support for range index. NOTE: The Range algorithm is experimental only. It is not intended for public use.
## 1.7.0-alpha2
### New Features
- Support range index for decimal128. NOTE: The Range algorithm is experimental only. It is not intended for public use.
## 1.7.0-alpha1
### New Features
- Add encryptExpression helper
## 1.7.0-alpha0
### New Features
- Support range index for int32, int64, double, and date. NOTE: The Range algorithm is experimental only. It is not intended for public use.

## 1.6.2
## Fixed
- Fix build on FreeBSD.
- Set context error state during KMS provider validation.
## 1.6.1
## Fixed
- Fix libbson dependency in pkg-config for MongoDB repository package.
## 1.6.0
## New Features
- Support accessToken to authenticate with Azure.
## Fixed
- Use correct schema when `collMod` command includes `validator.$jsonSchema`.
## 1.6.0-alpha0
### New Features
- Support accessToken to authenticate with GCP.
### Improvements
- Use CRLF, not LF, for HTTP request newlines.
- Include full body of HTTP errors in `mongocrypt_status_t`.
## 1.5.2
### Fixed
- Fix datakey decryption requiring multiple rounds of KMS requests.
## 1.5.1
## Warnings
- This release has a severe bug in the context returned by `mongocrypt_ctx_rewrap_many_datakey_init` that may result in data corruption. Please upgrade to 1.5.2 before using `mongocrypt_ctx_rewrap_many_datakey_init`.
### New Features
- Update Java bindings to support remaining 1.5.0 API.

## 1.5.0
## Warnings
- This release has a severe bug in the context returned by `mongocrypt_ctx_rewrap_many_datakey_init` that may result in data corruption. Please upgrade to 1.5.2 before using `mongocrypt_ctx_rewrap_many_datakey_init`.
## Fixed
- Update to use new payload for FLE 2.0 find.
- Require contention factor.
## 1.5.0-rc2
### Fixed
- Fix handling of create command with $jsonSchema.
- Fix leak on encrypt or decrypt error.
## Improved
- Accept string values for QueryType and IndexType.

## 1.4.1
### Fixed
- Add missing MONGOCRYPT_EXPORT to mongocrypt_ctx_provide_kms_providers
## 1.5.0-rc1
## Fixed
- Revert new payload for FLE 2.0 find.
- Do not send "create" and "createIndexes" to mongocryptd when bypassing query analysis.

## 1.5.0-rc0
## Fixed
- Account for shared library rename.
- Update to use new payload for FLE 2.0 find.

## 1.5.0-alpha2
## New Features
- Fix explain when using csfle shared library.
- Do not bypass "create" or "createIndexes" commands. Support "collMod".
- Bypass "hello", "buildInfo", "getCmdLineOpts", and "getLog" commands.
## Fixed
- Preserve $db in output command.
- Add missing MONGOCRYPT_EXPORT to mongocrypt_ctx_provide_kms_providers
## 1.5.0-alpha1
### Fixed
- Pick a random contention factor on FLE 2.0 insert.

## 1.5.0-alpha0
### New Features
- Support FLE 2.0.
- Support FLE 1.0 Shared Library.
- Support Key Management API.

## 1.4.0
### New Features
- Support on-demand credentials with `MONGOCRYPT_CTX_NEED_KMS_CREDENTIALS` state and `mongocrypt_ctx_provide_kms_providers`.

## 1.4.0-alpha0
### New Features
- Support on-demand AWS credentials with `MONGOCRYPT_CTX_NEED_KMS_CREDENTIALS` state and `mongocrypt_ctx_provide_kms_providers`.
### Fixed
- Resolve 32 bit Windows compile errors.

## 1.3.1

### New Features
- Support custom key material through `mongocrypt_ctx_setopt_key_material`.
### Fixed
- Fix deprecation warnings with OpenSSL 3.0.
- Resolve possible symbol conflicts with OpenSSL.

## 1.3.0
- Support "kmip" KMS provider.
- Add mongocrypt_kms_ctx_get_kms_provider.
- Apply default port to endpoints returned in mongocrypt_kms_ctx_endpoint
## 1.2.2
- Fix pkg-config and PPA build dependency on libbson.
- Fix JSON schema caching behavior when server reports no JSON schema.

## 1.2.1
### Fixed
- Fix possible crash when oauth credentials expire.

## 1.2.0
### Added
- Support AWS temporary credentials via session token.

### Fixed
- Add "=" padding to base64url encoding.
## 1.1.0
### Added
- Add ENABLE_PIC cmake option, set to ON by default, so static libraries build with -fPIC by default on relevant systems.

### Fixed
- Errors produced in all crypto callbacks are propagated to user.

## 1.1.0-beta1
### Deprecated
- mongocrypt_setopt_kms_provider_aws and mongocrypt_setopt_kms_provider_local are deprecated in favor of the more flexible mongocrypt_setopt_kms_providers, which supports configuration of all KMS providers.
- mongocrypt_ctx_setopt_masterkey_aws, mongocrypt_ctx_setopt_masterkey_aws_endpoint, and mongocrypt_ctx_setopt_masterkey_local are deprecated in favor of the more flexible mongocrypt_ctx_setopt_key_encryption_key, which supports configuration for all KMS providers.
### Added
- Introduces a new crypto hook for signing the JSON Web Token (JWT) for Google Cloud Platform (GCP) requests:
    - mongocrypt_setopt_crypto_hook_sign_rsaes_pkcs1_v1_5
- Introduces a CLI utility `csfle` to test the context state machine against live KMS, mongocryptd, and mongod. See ./test/util/README.md.
- Introduces two new functions to the libmongocrypt API.
    - mongocrypt_setopt_kms_providers
        To set the KMS providers.
    - mongocrypt_ctx_setopt_key_encryption_key
        To set the key encryption key.
- Adds support for Azure and GCP KMS providers.
