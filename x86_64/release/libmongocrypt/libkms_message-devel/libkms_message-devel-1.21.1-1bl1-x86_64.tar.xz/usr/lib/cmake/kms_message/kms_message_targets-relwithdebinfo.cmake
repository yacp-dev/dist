#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "mongo::kms_message" for configuration "RelWithDebInfo"
set_property(TARGET mongo::kms_message APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(mongo::kms_message PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libkms_message.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygkms_message-0.dll"
  )

list(APPEND _cmake_import_check_targets mongo::kms_message )
list(APPEND _cmake_import_check_files_for_mongo::kms_message "${_IMPORT_PREFIX}/lib/libkms_message.dll.a" "${_IMPORT_PREFIX}/bin/cygkms_message-0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
