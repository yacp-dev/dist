set(CMAKE_IMPORT_FILE_VERSION 1)

set(
  SDFTD3_INCLUDEDIRS
  "/usr/include"
  "/usr/include/s-dftd3/modules"
)
find_library(
  SDFTD3_LIBRARIES
  "s-dftd3"
  PATHS "/usr/lib"
  NO_DEFAULT_PATH
)
set(
  SDFTD3_DEPENDENCIES
  "$<$<BOOL:${SDFTD3_USE_MCTCLIB}>:mctc-lib::mctc-lib>"
  "$<$<BOOL:${SDFTD3_WITH_OpenMP}>:OpenMP::OpenMP_Fortran>"
)

add_library(s-dftd3::s-dftd3-lib INTERFACE IMPORTED)
add_library(s-dftd3::s-dftd3 ALIAS s-dftd3::s-dftd3-lib)
target_link_libraries(s-dftd3::s-dftd3-lib INTERFACE ${SDFTD3_LIBRARIES} ${SDFTD3_DEPENDENCIES})
target_include_directories(s-dftd3::s-dftd3-lib INTERFACE ${SDFTD3_INCLUDEDIRS})
