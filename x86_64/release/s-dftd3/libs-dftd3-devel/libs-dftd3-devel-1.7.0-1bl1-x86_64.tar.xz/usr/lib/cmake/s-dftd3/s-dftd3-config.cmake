

set("SDFTD3_WITH_API" ON)
set("SDFTD3_WITH_OpenMP" ON)
set("SDFTD3_WITH_MPI" OFF)
set("SDFTD3_USE_MCTCLIB" ON)

if(NOT TARGET "s-dftd3::s-dftd3")
  include(CMakeFindDependencyMacro)
  list(APPEND CMAKE_MODULE_PATH "${CMAKE_CURRENT_LIST_DIR}")

  if(NOT TARGET "OpenMP::OpenMP_Fortran" AND SDFTD3_WITH_OpenMP)
    find_dependency("OpenMP")
  endif()

  if(NOT TARGET "MPI::MPI_Fortran" AND SDFTD3_WITH_MPI)
    find_dependency("MPI" COMPONENTS "Fortran")
  endif()

  if(NOT TARGET "mctc-lib::mctc-lib" AND SDFTD3_USE_MCTCLIB)
    find_dependency("mctc-lib")
  endif()

  list(REMOVE_AT CMAKE_MODULE_PATH -1)
  include("${CMAKE_CURRENT_LIST_DIR}/s-dftd3-targets.cmake")
endif()
