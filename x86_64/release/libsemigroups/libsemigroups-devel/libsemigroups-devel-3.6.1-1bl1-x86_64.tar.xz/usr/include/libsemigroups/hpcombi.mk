HPCOMBI_CXXFLAGS = -mavx -Wno-unused-command-line-argument -flax-vector-conversions
LIBSEMIGROUPS_HPCOMBI_ENABLED = 1
