//
// libsemigroups - C++ library for semigroups and monoids
// Copyright (C) 2020-2026 James D. Mitchell
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
//

// TODO(v4): delete this file it's no longer necessary

#ifndef LIBSEMIGROUPS_DEPRECATED_HPP_
#define LIBSEMIGROUPS_DEPRECATED_HPP_

#if __has_attribute(deprecated)
#define LIBSEMIGROUPS_DEPRECATED __attribute__((deprecated))
#else
#define LIBSEMIGROUPS_DEPRECATED
#endif

#endif  // LIBSEMIGROUPS_DEPRECATED_HPP_
