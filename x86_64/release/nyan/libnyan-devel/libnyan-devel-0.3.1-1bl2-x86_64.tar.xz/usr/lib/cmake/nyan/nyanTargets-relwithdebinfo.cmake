#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "nyan::nyan" for configuration "RelWithDebInfo"
set_property(TARGET nyan::nyan APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(nyan::nyan PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libnyan.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygnyan-1.dll"
  )

list(APPEND _cmake_import_check_targets nyan::nyan )
list(APPEND _cmake_import_check_files_for_nyan::nyan "${_IMPORT_PREFIX}/lib/libnyan.dll.a" "${_IMPORT_PREFIX}/bin/cygnyan-1.dll" )

# Import target "nyan::nyancat" for configuration "RelWithDebInfo"
set_property(TARGET nyan::nyancat APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(nyan::nyancat PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/nyancat.exe"
  )

list(APPEND _cmake_import_check_targets nyan::nyancat )
list(APPEND _cmake_import_check_files_for_nyan::nyancat "${_IMPORT_PREFIX}/bin/nyancat.exe" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
