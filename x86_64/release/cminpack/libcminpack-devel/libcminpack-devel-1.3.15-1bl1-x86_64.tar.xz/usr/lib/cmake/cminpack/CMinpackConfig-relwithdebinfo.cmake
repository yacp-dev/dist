#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "cminpack::cminpacks" for configuration "RelWithDebInfo"
set_property(TARGET cminpack::cminpacks APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(cminpack::cminpacks PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libcminpacks.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygcminpacks-1.dll"
  )

list(APPEND _cmake_import_check_targets cminpack::cminpacks )
list(APPEND _cmake_import_check_files_for_cminpack::cminpacks "${_IMPORT_PREFIX}/lib/libcminpacks.dll.a" "${_IMPORT_PREFIX}/bin/cygcminpacks-1.dll" )

# Import target "cminpack::cminpack" for configuration "RelWithDebInfo"
set_property(TARGET cminpack::cminpack APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(cminpack::cminpack PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libcminpack.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygcminpack-1.dll"
  )

list(APPEND _cmake_import_check_targets cminpack::cminpack )
list(APPEND _cmake_import_check_files_for_cminpack::cminpack "${_IMPORT_PREFIX}/lib/libcminpack.dll.a" "${_IMPORT_PREFIX}/bin/cygcminpack-1.dll" )

# Import target "cminpack::cminpackld" for configuration "RelWithDebInfo"
set_property(TARGET cminpack::cminpackld APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(cminpack::cminpackld PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libcminpackld.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygcminpackld-1.dll"
  )

list(APPEND _cmake_import_check_targets cminpack::cminpackld )
list(APPEND _cmake_import_check_files_for_cminpack::cminpackld "${_IMPORT_PREFIX}/lib/libcminpackld.dll.a" "${_IMPORT_PREFIX}/bin/cygcminpackld-1.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
