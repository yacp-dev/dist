#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Forge::forge" for configuration "RelWithDebInfo"
set_property(TARGET Forge::forge APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(Forge::forge PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libforge.dll.a"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELWITHDEBINFO "glfw"
  IMPORTED_LOCATION_RELWITHDEBINFO "/usr/bin/cygforge-1.dll"
  )

list(APPEND _cmake_import_check_targets Forge::forge )
list(APPEND _cmake_import_check_files_for_Forge::forge "${_IMPORT_PREFIX}/lib/libforge.dll.a" "/usr/bin/cygforge-1.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
