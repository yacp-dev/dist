#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "cmark-gfm" for configuration "RelWithDebInfo"
set_property(TARGET cmark-gfm APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(cmark-gfm PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cmark-gfm.exe"
  )

list(APPEND _cmake_import_check_targets cmark-gfm )
list(APPEND _cmake_import_check_files_for_cmark-gfm "${_IMPORT_PREFIX}/bin/cmark-gfm.exe" )

# Import target "libcmark-gfm" for configuration "RelWithDebInfo"
set_property(TARGET libcmark-gfm APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(libcmark-gfm PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libcmark-gfm.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygcmark-gfm-0.29.0.gfm.13.dll"
  )

list(APPEND _cmake_import_check_targets libcmark-gfm )
list(APPEND _cmake_import_check_files_for_libcmark-gfm "${_IMPORT_PREFIX}/lib/libcmark-gfm.dll.a" "${_IMPORT_PREFIX}/bin/cygcmark-gfm-0.29.0.gfm.13.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
