#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "libcmark-gfm-extensions" for configuration "RelWithDebInfo"
set_property(TARGET libcmark-gfm-extensions APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(libcmark-gfm-extensions PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libcmark-gfm-extensions.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygcmark-gfm-extensions-0.29.0.gfm.13.dll"
  )

list(APPEND _cmake_import_check_targets libcmark-gfm-extensions )
list(APPEND _cmake_import_check_files_for_libcmark-gfm-extensions "${_IMPORT_PREFIX}/lib/libcmark-gfm-extensions.dll.a" "${_IMPORT_PREFIX}/bin/cygcmark-gfm-extensions-0.29.0.gfm.13.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
