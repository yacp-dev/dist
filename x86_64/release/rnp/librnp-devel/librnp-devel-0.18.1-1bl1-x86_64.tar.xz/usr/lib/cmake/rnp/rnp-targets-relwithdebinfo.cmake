#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "rnp::librnp" for configuration "RelWithDebInfo"
set_property(TARGET rnp::librnp APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(rnp::librnp PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/librnp.dll.a"
  )

list(APPEND _cmake_import_check_targets rnp::librnp )
list(APPEND _cmake_import_check_files_for_rnp::librnp "${_IMPORT_PREFIX}/lib/librnp.dll.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
