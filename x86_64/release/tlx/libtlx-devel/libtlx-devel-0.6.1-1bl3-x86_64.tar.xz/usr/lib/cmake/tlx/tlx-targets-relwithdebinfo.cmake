#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "tlx" for configuration "RelWithDebInfo"
set_property(TARGET tlx APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(tlx PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libtlx.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygtlx-0.6.dll"
  )

list(APPEND _cmake_import_check_targets tlx )
list(APPEND _cmake_import_check_files_for_tlx "${_IMPORT_PREFIX}/lib/libtlx.dll.a" "${_IMPORT_PREFIX}/bin/cygtlx-0.6.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
