#pragma once
#include "guest_cpp_string.hpp"
#include <algorithm>
#include <array>
#include <tuple>
#include <vector>

namespace riscv {

// View into libstdc++ and LLVM libc++ std::vector (same layout)
template <int W, typename T>
struct alignas(guest_word_align<W>) GuestStdVector {
	using gaddr_t = riscv::address_type<W>;
	using machine_t = riscv::Machine<W>;

	gaddr_t ptr_begin;
	gaddr_t ptr_end;
	gaddr_t ptr_capacity;

	constexpr GuestStdVector() noexcept : ptr_begin(0), ptr_end(0), ptr_capacity(0) {}

	GuestStdVector(machine_t& machine, std::size_t elements)
		: ptr_begin(0), ptr_end(0), ptr_capacity(0)
	{
		auto [array, self] = this->alloc(machine, elements);
		(void)self;
		for (std::size_t i = 0; i < elements; i++) {
			new (&array[i]) T();
			this->relocate_element(machine, array, i);
		}
		// Set new end only after all elements are constructed
		this->ptr_end = this->ptr_begin + elements * sizeof(T);
	}

	GuestStdVector(machine_t& machine, const std::vector<std::string>& vec)
		: ptr_begin(0), ptr_end(0), ptr_capacity(0)
	{
		static_assert(std::is_same_v<T, GuestStdString<W>>, "GuestStdVector<T> must be a vector of GuestStdString<W>");
		if (vec.empty())
			return;

		// Specialization for std::vector<std::string>
		auto [array, self] = this->alloc(machine, vec.size());
		(void)self;
		for (std::size_t i = 0; i < vec.size(); i++) {
			T* str = new (&array[i]) T(machine, vec[i]);
			str->move(this->ptr_begin + i * sizeof(T));
		}
		// Set new end only after all elements are constructed
		this->ptr_end = this->ptr_begin + vec.size() * sizeof(T);
	}
	GuestStdVector(machine_t& machine, const std::vector<T>& vec = {})
		: ptr_begin(0), ptr_end(0), ptr_capacity(0)
	{
		if (!vec.empty())
			this->assign(machine, vec);
	}
	template <typename... Args>
	GuestStdVector(machine_t& machine, const std::array<T, sizeof...(Args)>& arr)
		: GuestStdVector(machine, std::vector<T> {arr.begin(), arr.end()})
	{
	}

	GuestStdVector(GuestStdVector&& other) noexcept
		: ptr_begin(other.ptr_begin), ptr_end(other.ptr_end), ptr_capacity(other.ptr_capacity)
	{
		other.ptr_begin = 0;
		other.ptr_end = 0;
		other.ptr_capacity = 0;
	}

	// Copying is intentionally shallow/fast, in order to avoid copying/duplication
	// Use the std::move if you need proper semantics
	GuestStdVector(const GuestStdVector& other) = default;
	GuestStdVector& operator=(const GuestStdVector& other) = default;

	gaddr_t data() const noexcept { return ptr_begin; }

	std::size_t size() const noexcept {
		return size_bytes() / sizeof(T);
	}
	bool empty() const noexcept {
		return size() == 0;
	}

	std::size_t capacity() const noexcept {
		return capacity_bytes() / sizeof(T);
	}

	T& at(machine_t& machine, std::size_t index, std::size_t max_bytes = 16UL << 20) {
		if (index >= size())
			throw std::out_of_range("Guest std::vector index out of range");
		return as_array(machine, max_bytes)[index];
	}
	const T& at(machine_t& machine, std::size_t index, std::size_t max_bytes = 16UL << 20) const {
		if (index >= size())
			throw std::out_of_range("Guest std::vector index out of range");
		return as_array(machine, max_bytes)[index];
	}

	void push_back(machine_t& machine, T&& value) {
		if (size_bytes() >= capacity_bytes())
			this->increase_capacity(machine);
		T* array = machine.memory.template memarray<T>(this->data(), size() + 1);
		new (&array[size()]) T(std::move(value));
		this->relocate_element(machine, array, size());
		this->ptr_end += sizeof(T);
	}
	void push_back(machine_t& machine, const T& value) {
		if (size_bytes() >= capacity_bytes())
			this->increase_capacity(machine);
		T* array = machine.memory.template memarray<T>(this->data(), size() + 1);
		new (&array[size()]) T(value);
		this->relocate_element(machine, array, size());
		this->ptr_end += sizeof(T);
	}

	// Specialization for std::string and std::string_view
	void push_back(machine_t& machine, std::string_view value) {
		static_assert(std::is_same_v<T, GuestStdString<W>>, "GuestStdVector: T must be a GuestStdString<W>");
		if (size_bytes() >= capacity_bytes())
			this->increase_capacity(machine);
		T* array = machine.memory.template memarray<T>(this->data(), size() + 1);
		const gaddr_t address = this->ptr_begin + size() * sizeof(T);
		new (&array[size()]) T(machine, address, value);
		this->ptr_end += sizeof(T);
	}
	// Specialization for std::vector<U>
	template <typename U>
	void push_back(machine_t& machine, const std::vector<U>& value) {
		static_assert(is_guest_stdvector<W, T>::value, "GuestStdVector: T must be a GuestStdVector itself");
		this->push_back(machine, GuestStdVector<W, U>(machine, value));
	}

	void pop_back(machine_t& machine) {
		if (size() == 0)
			throw std::out_of_range("Guest std::vector is empty");
		this->free_element(machine, size() - 1);
		this->ptr_end -= sizeof(T);
	}

	void append(machine_t& machine, const T* values, std::size_t count) {
		if (size_bytes() + count * sizeof(T) > capacity_bytes())
			this->reserve(machine, size() + count);
		T* array = machine.memory.template memarray<T>(this->data(), size() + count);
		for (std::size_t i = 0; i < count; i++) {
			new (&array[size() + i]) T(values[i]);
			this->relocate_element(machine, array, size() + i);
		}
		this->ptr_end += count * sizeof(T);
	}

	void clear(machine_t& machine) {
		for (std::size_t i = 0; i < size(); i++)
			this->free_element(machine, i);
		this->ptr_end = this->ptr_begin;
	}

	gaddr_t address_at(std::size_t index) const {
		if (index >= size())
			throw std::out_of_range("Guest std::vector index out of range");
		return ptr_begin + index * sizeof(T);
	}

	T *as_array(const machine_t& machine, std::size_t max_bytes = 16UL << 20) {
		if (size_bytes() > max_bytes)
			throw std::runtime_error("Guest std::vector has size > max_bytes");
		return machine.memory.template memarray<T>(data(), size());
	}
	const T *as_array(const machine_t& machine, std::size_t max_bytes = 16UL << 20) const {
		if (size_bytes() > max_bytes)
			throw std::runtime_error("Guest std::vector has size > max_bytes");
		return machine.memory.template memarray<T>(data(), size());
	}

#if RISCV_SPAN_AVAILABLE
	std::span<T> to_span(const machine_t& machine) {
		return std::span<T>(as_array(machine), size());
	}
	std::span<const T> to_span(const machine_t& machine) const {
		return std::span<const T>(as_array(machine), size());
	}
#endif

	// Iterators
	auto begin(machine_t& machine) { return as_array(machine); }
	auto end(machine_t& machine) { return as_array(machine) + size(); }

	std::vector<T> to_vector(const machine_t& machine) const {
		if (size_bytes() > capacity_bytes())
			throw std::runtime_error("Guest std::vector has size > capacity");
		// Copy the vector from guest memory
		const size_t elements = size();
		const T *array = machine.memory.template memarray<T>(data(), elements);
		return std::vector<T>(&array[0], &array[elements]);
	}

	/// @brief Specialization for std::string
	/// @param machine The RISC-V machine
	/// @return A vector of strings
	std::vector<std::string> to_string_vector(const machine_t& machine) const {
		if constexpr (std::is_same_v<T, GuestStdString<W>>) {
			std::vector<std::string> vec;
			const size_t elements = size();
			const T *array = machine.memory.template memarray<T>(data(), elements);
			vec.reserve(elements);
			for (std::size_t i = 0; i < elements; i++)
				vec.push_back(array[i].to_string(machine));
			return vec;
		} else {
			throw std::runtime_error("GuestStdVector: T must be a GuestStdString<W>");
		}
	}

	void assign(machine_t& machine, const std::vector<std::string>& vec)
	{
		static_assert(std::is_same_v<T, GuestStdString<W>>, "GuestStdVector<T> must be a vector of GuestStdString<W>");
		this->free(machine);
		if (vec.empty())
			return;

		// Specialization for std::vector<std::string>
		auto [array, self] = this->alloc(machine, vec.size());
		(void)self;
		for (std::size_t i = 0; i < vec.size(); i++) {
			T* str = new (&array[i]) T(machine, vec[i]);
			str->move(this->ptr_begin + i * sizeof(T));
		}
		// Set new end only after all elements are constructed
		this->ptr_end = this->ptr_begin + vec.size() * sizeof(T);
	}

	void assign(machine_t& machine, const std::vector<T>& vec)
	{
		auto [array, self] = alloc(machine, vec.size());
		(void)self;
		std::copy(vec.begin(), vec.end(), array);
		for (std::size_t i = 0; i < vec.size(); i++)
			this->relocate_element(machine, array, i);
		this->ptr_end = this->ptr_begin + vec.size() * sizeof(T);
	}

	void assign(machine_t& machine, const T* values, std::size_t count)
	{
		auto [array, self] = alloc(machine, count);
		(void)self;
		std::copy(values, values + count, array);
		for (std::size_t i = 0; i < count; i++)
			this->relocate_element(machine, array, i);
		this->ptr_end = this->ptr_begin + count * sizeof(T);
	}

	/// @brief Replace the contents of the vector with the given array,
	/// by assuming ownership of the array memory (which must have been
	/// allocated with guest_alloc and *must* be properly initialized
	/// with the given values).
	void assume_ownership(machine_t& machine, gaddr_t array, std::size_t count)
	{
		this->free(machine);
		this->ptr_begin = array;
		this->ptr_end = array + count * sizeof(T);
		this->ptr_capacity = this->ptr_end;
	}

	void resize(machine_t& machine, std::size_t new_size)
	{
		if (new_size < size()) {
			for (std::size_t i = new_size; i < size(); i++)
				this->free_element(machine, i);
			this->ptr_end = this->ptr_begin + new_size * sizeof(T);
		} else if (new_size > size()) {
			if (new_size > capacity())
				this->reserve(machine, new_size);
			T* array = machine.memory.template memarray<T>(this->data(), new_size);
			for (std::size_t i = size(); i < new_size; i++) {
				new (&array[i]) T();
				this->relocate_element(machine, array, i);
			}
			this->ptr_end = this->ptr_begin + new_size * sizeof(T);
		}
	}

	void reserve(machine_t& machine, std::size_t elements)
	{
		if (elements <= capacity())
			return;

		GuestStdVector<W, T> old_vec(std::move(*this));
		// Allocate new memory
		auto [array, self] = this->alloc(machine, elements);
		(void)self;
		if (!old_vec.empty()) {
			std::copy(old_vec.as_array(machine), old_vec.as_array(machine) + old_vec.size(), array);
			// Free the old vector manually (as we don't want to call the destructor(s))
			machine.arena().free(old_vec.ptr_begin);
		}
		this->ptr_end = this->ptr_begin + old_vec.size() * sizeof(T);
		// Adjust the elements that point back into themselves (std::string
		// small-string optimization, std::unordered_map bucket pointers)
		if constexpr (element_is_self_referencing) {
			T* array = machine.memory.template memarray<T>(this->data(), size());
			for (std::size_t i = 0; i < size(); i++)
				this->relocate_element(machine, array, i);
		}
	}

	void free(machine_t& machine) {
		if (this->ptr_begin != 0) {
			for (std::size_t i = 0; i < size(); i++)
				this->free_element(machine, i);
			machine.arena().free(this->data());
			this->ptr_begin = 0;
			this->ptr_end = 0;
			this->ptr_capacity = 0;
		}
	}

	std::size_t size_bytes() const noexcept { return ptr_end - ptr_begin; }
	std::size_t capacity_bytes() const noexcept { return ptr_capacity - ptr_begin; }

private:
	void increase_capacity(machine_t& machine) {
		this->reserve(machine, capacity() * 2 + 4);
	}

	std::tuple<T *, gaddr_t> alloc(machine_t& machine, std::size_t elements) {
		this->free(machine);

		this->ptr_begin = machine.arena().malloc(elements * sizeof(T));
		this->ptr_end = this->ptr_begin;
		this->ptr_capacity = this->ptr_begin + elements * sizeof(T);
		return { machine.memory.template memarray<T>(this->data(), elements), this->data() };
	}

	/// @brief True when the elements contain pointers back into themselves,
	/// and must be told when they are moved to another address.
	static constexpr bool element_is_self_referencing =
		is_self_referencing_guest_object<W, T>::value;

	/// @brief Tell an element that it now lives at its current address
	void relocate_element(machine_t& machine, T* array, std::size_t index) {
		relocate_guest_object<W>(machine, array[index],
			this->ptr_begin + index * sizeof(T));
	}

	void free_element(machine_t& machine, std::size_t index) {
		free_guest_object<W>(machine, this->at(machine, index));
	}
};

/// @brief A guest std::vector that lives in the arena, and which frees
/// itself (and its elements) at the end of the scope.
template <int W, typename T>
using ScopedGuestStdVector = ScopedArenaObject<W, GuestStdVector<W, T>>;

template <int W, typename T>
struct is_scoped_guest_stdvector : std::false_type {};

template <int W, typename T>
struct is_scoped_guest_stdvector<W, ScopedArenaObject<W, GuestStdVector<W, T>>> : std::true_type {};

} // riscv
