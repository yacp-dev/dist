#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "RecastNavigation::DebugUtils" for configuration "RelWithDebInfo"
set_property(TARGET RecastNavigation::DebugUtils APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(RecastNavigation::DebugUtils PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libDebugUtils.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygDebugUtils-1.dll"
  )

list(APPEND _cmake_import_check_targets RecastNavigation::DebugUtils )
list(APPEND _cmake_import_check_files_for_RecastNavigation::DebugUtils "${_IMPORT_PREFIX}/lib/libDebugUtils.dll.a" "${_IMPORT_PREFIX}/bin/cygDebugUtils-1.dll" )

# Import target "RecastNavigation::Detour" for configuration "RelWithDebInfo"
set_property(TARGET RecastNavigation::Detour APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(RecastNavigation::Detour PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libDetour.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygDetour-1.dll"
  )

list(APPEND _cmake_import_check_targets RecastNavigation::Detour )
list(APPEND _cmake_import_check_files_for_RecastNavigation::Detour "${_IMPORT_PREFIX}/lib/libDetour.dll.a" "${_IMPORT_PREFIX}/bin/cygDetour-1.dll" )

# Import target "RecastNavigation::DetourCrowd" for configuration "RelWithDebInfo"
set_property(TARGET RecastNavigation::DetourCrowd APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(RecastNavigation::DetourCrowd PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libDetourCrowd.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygDetourCrowd-1.dll"
  )

list(APPEND _cmake_import_check_targets RecastNavigation::DetourCrowd )
list(APPEND _cmake_import_check_files_for_RecastNavigation::DetourCrowd "${_IMPORT_PREFIX}/lib/libDetourCrowd.dll.a" "${_IMPORT_PREFIX}/bin/cygDetourCrowd-1.dll" )

# Import target "RecastNavigation::DetourTileCache" for configuration "RelWithDebInfo"
set_property(TARGET RecastNavigation::DetourTileCache APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(RecastNavigation::DetourTileCache PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libDetourTileCache.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygDetourTileCache-1.dll"
  )

list(APPEND _cmake_import_check_targets RecastNavigation::DetourTileCache )
list(APPEND _cmake_import_check_files_for_RecastNavigation::DetourTileCache "${_IMPORT_PREFIX}/lib/libDetourTileCache.dll.a" "${_IMPORT_PREFIX}/bin/cygDetourTileCache-1.dll" )

# Import target "RecastNavigation::Recast" for configuration "RelWithDebInfo"
set_property(TARGET RecastNavigation::Recast APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(RecastNavigation::Recast PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libRecast.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygRecast-1.dll"
  )

list(APPEND _cmake_import_check_targets RecastNavigation::Recast )
list(APPEND _cmake_import_check_files_for_RecastNavigation::Recast "${_IMPORT_PREFIX}/lib/libRecast.dll.a" "${_IMPORT_PREFIX}/bin/cygRecast-1.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
