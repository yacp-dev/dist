#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "HYPRE::HYPRE" for configuration "RelWithDebInfo"
set_property(TARGET HYPRE::HYPRE APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(HYPRE::HYPRE PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libHYPRE.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygHYPRE-302.dll"
  )

list(APPEND _cmake_import_check_targets HYPRE::HYPRE )
list(APPEND _cmake_import_check_files_for_HYPRE::HYPRE "${_IMPORT_PREFIX}/lib/libHYPRE.dll.a" "${_IMPORT_PREFIX}/bin/cygHYPRE-302.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
