/*
 * Definitions for libfsxfs
 *
 * Copyright (C) 2020-2026, Joachim Metz <joachim.metz@gmail.com>
 *
 * Refer to AUTHORS for acknowledgements.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#if !defined( _LIBFSXFS_DEFINITIONS_H )
#define _LIBFSXFS_DEFINITIONS_H

#include <libfsxfs/types.h>

#define LIBFSXFS_VERSION			20260901

/* The version string
 */
#define LIBFSXFS_VERSION_STRING			"20260901"

/* The file access
 * bit 1        set to 1 for read access
 * bit 2        set to 1 for write access
 * bit 3-8      not used
 */
enum LIBFSXFS_ACCESS_FLAGS
{
	LIBFSXFS_ACCESS_FLAG_READ		= 0x01,
/* Reserved: not supported yet */
	LIBFSXFS_ACCESS_FLAG_WRITE		= 0x02
};

/* The file access macros
 */
#define LIBFSXFS_OPEN_READ			( LIBFSXFS_ACCESS_FLAG_READ )
/* Reserved: not supported yet */
#define LIBFSXFS_OPEN_WRITE			( LIBFSXFS_ACCESS_FLAG_WRITE )
/* Reserved: not supported yet */
#define LIBFSXFS_OPEN_READ_WRITE		( LIBFSXFS_ACCESS_FLAG_READ | LIBFSXFS_ACCESS_FLAG_WRITE )

/* The path segment separator
 */
#define LIBFSXFS_SEPARATOR			'/'

/* The file types
 */
enum LIBFSXFS_FILE_TYPES
{
	LIBFSXFS_FILE_TYPE_FIFO			= 0x1000,
	LIBFSXFS_FILE_TYPE_CHARACTER_DEVICE	= 0x2000,
	LIBFSXFS_FILE_TYPE_DIRECTORY		= 0x4000,
	LIBFSXFS_FILE_TYPE_BLOCK_DEVICE		= 0x6000,
	LIBFSXFS_FILE_TYPE_REGULAR_FILE		= 0x8000,
	LIBFSXFS_FILE_TYPE_SYMBOLIC_LINK	= 0xa000,
	LIBFSXFS_FILE_TYPE_SOCKET		= 0xc000,
};

/* The extent flag definitions
 */
enum LIBFSXFS_EXTENT_FLAGS
{
	/* The extent is sparse
	 */
	LIBFSXFS_EXTENT_FLAG_IS_SPARSE		= 0x00000001UL
};

#endif /* !defined( _LIBFSXFS_DEFINITIONS_H ) */

