#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "LibUVC::UVCShared" for configuration "RelWithDebInfo"
set_property(TARGET LibUVC::UVCShared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(LibUVC::UVCShared PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libuvc.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cyguvc-0.dll"
  )

list(APPEND _cmake_import_check_targets LibUVC::UVCShared )
list(APPEND _cmake_import_check_files_for_LibUVC::UVCShared "${_IMPORT_PREFIX}/lib/libuvc.dll.a" "${_IMPORT_PREFIX}/bin/cyguvc-0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
