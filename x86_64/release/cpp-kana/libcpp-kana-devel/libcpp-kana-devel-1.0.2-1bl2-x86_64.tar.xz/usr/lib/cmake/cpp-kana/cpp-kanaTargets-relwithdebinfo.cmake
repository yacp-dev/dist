#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "cpp-kana::cpp-kana" for configuration "RelWithDebInfo"
set_property(TARGET cpp-kana::cpp-kana APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(cpp-kana::cpp-kana PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libcpp-kana.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygcpp-kana-1.dll"
  )

list(APPEND _cmake_import_check_targets cpp-kana::cpp-kana )
list(APPEND _cmake_import_check_files_for_cpp-kana::cpp-kana "${_IMPORT_PREFIX}/lib/libcpp-kana.dll.a" "${_IMPORT_PREFIX}/bin/cygcpp-kana-1.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
