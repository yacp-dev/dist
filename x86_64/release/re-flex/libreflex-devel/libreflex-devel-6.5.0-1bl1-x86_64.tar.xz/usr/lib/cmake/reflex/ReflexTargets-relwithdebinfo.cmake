#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Reflex::Reflex" for configuration "RelWithDebInfo"
set_property(TARGET Reflex::Reflex APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(Reflex::Reflex PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/reflex.exe"
  )

list(APPEND _cmake_import_check_targets Reflex::Reflex )
list(APPEND _cmake_import_check_files_for_Reflex::Reflex "${_IMPORT_PREFIX}/bin/reflex.exe" )

# Import target "Reflex::ReflexLib" for configuration "RelWithDebInfo"
set_property(TARGET Reflex::ReflexLib APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(Reflex::ReflexLib PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libreflex.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygreflex-6.dll"
  )

list(APPEND _cmake_import_check_targets Reflex::ReflexLib )
list(APPEND _cmake_import_check_files_for_Reflex::ReflexLib "${_IMPORT_PREFIX}/lib/libreflex.dll.a" "${_IMPORT_PREFIX}/bin/cygreflex-6.dll" )

# Import target "Reflex::ReflexMinLib" for configuration "RelWithDebInfo"
set_property(TARGET Reflex::ReflexMinLib APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(Reflex::ReflexMinLib PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libreflexmin.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygreflexmin-6.dll"
  )

list(APPEND _cmake_import_check_targets Reflex::ReflexMinLib )
list(APPEND _cmake_import_check_files_for_Reflex::ReflexMinLib "${_IMPORT_PREFIX}/lib/libreflexmin.dll.a" "${_IMPORT_PREFIX}/bin/cygreflexmin-6.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
