#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "SOCI::MySQL" for configuration "RelWithDebInfo"
set_property(TARGET SOCI::MySQL APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(SOCI::MySQL PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libsoci_mysql.dll.a"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELWITHDEBINFO "fmt::fmt"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygsoci_mysql-4.dll"
  )

list(APPEND _cmake_import_check_targets SOCI::MySQL )
list(APPEND _cmake_import_check_files_for_SOCI::MySQL "${_IMPORT_PREFIX}/lib/libsoci_mysql.dll.a" "${_IMPORT_PREFIX}/bin/cygsoci_mysql-4.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
