#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "ECPINT::ecpint" for configuration "RelWithDebInfo"
set_property(TARGET ECPINT::ecpint APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(ECPINT::ecpint PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libecpint.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygecpint-1.dll"
  )

list(APPEND _cmake_import_check_targets ECPINT::ecpint )
list(APPEND _cmake_import_check_files_for_ECPINT::ecpint "${_IMPORT_PREFIX}/lib/libecpint.dll.a" "${_IMPORT_PREFIX}/bin/cygecpint-1.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
