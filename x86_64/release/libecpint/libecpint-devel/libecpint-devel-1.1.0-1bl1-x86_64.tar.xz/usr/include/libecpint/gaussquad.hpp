/*
 *      Copyright (c) 2020 Robert Shaw
 *		This file is a part of Libecpint.
 *
 *      Permission is hereby granted, free of charge, to any person obtaining
 *      a copy of this software and associated documentation files (the
 *      "Software"), to deal in the Software without restriction, including
 *      without limitation the rights to use, copy, modify, merge, publish,
 *      distribute, sublicense, and/or sell copies of the Software, and to
 *      permit persons to whom the Software is furnished to do so, subject to
 *      the following conditions:
 *
 *      The above copyright notice and this permission notice shall be
 *      included in all copies or substantial portions of the Software.
 *
 *      THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 *      EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 *      MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 *      NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 *      LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 *      OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 *      WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

#ifndef GC_QUAD_HEAD
#define GC_QUAD_HEAD

#include <cmath>
#include <functional>
#include <vector>

#include "mathutil.hpp"

namespace libecpint {

/// Different choices of integration algorithm, see references
enum GCTYPE {
  ONEPOINT,  ///< Described in Perez92
  TWOPOINT   ///< Described in Perez93
};

/**
 * \class GCQuadrature
 * \brief Performs adaptive Gauss-Chebyshev quadrature of the second kind for any given function.
 *
 * Stores the weights and abscissae for the quadrature, and provides two different methods to
 * integrate on [-1, 1] Also contains means to transform the region of integration to [0, infinity)
 * and [rmin, rmax]
 *
 * REFERENCES:
 * (Perez92) J.M. Perez-Jorda et al., Comput. Phys. Comm. 70 (1992), 271-284
 * (Perez93) J.M. Perez-Jorda et al., Comput. Phys. Comm. 77 (1993), 46-56
 * (Krack98) M. Krack, A.M. Koster, J. Chem. Phys. 108 (1998), 3226 - 3234
 * (Flores06) R. Flores-Moreno et al., J. Comput. Chem. 27 (2006), 1009-1019
 */
class GCQuadrature {
 private:
  int maxN;  ///< Maximum number of points to use in quadrature
  int M;     ///< Index of midpoint

  std::vector<double> x;  ///< Abscissae
  std::vector<double> w;  ///< Weights

  double I;  ///< Integral value

  GCTYPE t;  ///< Algorithm type to be used

  /// Worker function for integration routines, should not be called directly.
  /// p holds the pretabulated integrand values at the abscissae.
  double sumTerms(const double* p, int limit, int start, int end, int shift, int skip) const;

 public:
  /// Default constructor, creates empty object
  GCQuadrature();

  /// Copy constructor, carbon copies all members
  GCQuadrature(const GCQuadrature& other);

  /// Copy-assignment, carbon copies all members (reusing existing buffers where possible)
  GCQuadrature& operator=(const GCQuadrature& other);

  /**
   * Intialises the integration grid to the given number of points, and integration type.
   * ONEPOINT will choose N = 2^n - 1 closest to the given number of points, whilst
   * TWOPOINT will choose N= 3*2^n - 1 in the same way.
   *
   * @param points - maximum number of quadrature points to be used
   * @param t - the algorithm to be used (ONEPOINT / TWOPOINT)
   */
  void initGrid(int points, GCTYPE t);

  /**
   * Integrates a pretabulated integrand (over [-1, 1] by default) to within the given tolerance.
   * The integrand must already be evaluated at each abscissa and stored in params, indexed by grid
   * point.
   * @param params - the pretabulated integrand values, one per quadrature abscissa
   * @param tolerance - change below which convergenced is considered to be achieved
   * @param start - the index of the first point used in the integration
   * @param end - the index of the last point used in the integration
   * @returns the integral (first) and true if integration converged, false otherwise (second)
   */
  std::pair<double, bool> integrate(const double* params, double tolerance, int start,
                                    int end) const;

  /**
   * Transforms the region of integration to [0, inf) using the logarithmic transformation of
   * Krack98
   */
  void transformZeroInf();

  /**
   * Transforms region of integration to [rmin, rmax] using the linear transformation from Flores06,
   * assuming a Gaussian envelope. rmin/rmax are the distances from the centre of the envelope such
   * that the integrand is effectively zero.
   * @param z - the exponent of the Gaussian envelope
   * @param p - the centre of the Gaussian envelope
   */
  void transformRMinMax(double z,
                        double p);  // Transfromation from [-1, 1] to [rmin, rmax] from Flores06
  void untransformRMinMax(double z, double p);

  /**
   * Linearly transforms the region of integration from [-1, 1] to [rmin, rmax]
   * @param rmin - lower limit of the integration region
   * @param rmax - upper limit of the integration region
   */
  void transformInterval(double rmin, double rmax);

  /// @return the maximum number of quadrature points
  int getN() const { return maxN; }

  /// @return a reference to the abscissae
  std::vector<double>& getX() { return x; }
  const std::vector<double>& getX() const { return x; }
};

/**
 * \struct GaussLegendre
 * \brief N-point Gauss-Legendre rule on [-1, 1], nodes x and weights w.
 *
 * The radial integrals use fixed rules rather than adaptive ones: their integrands are Gaussians
 * of at most ~20 widths times factors varying on the scale of r, so the rule converges
 * exponentially (against adaptive quadrature on real shell pairs: 24 points 1e-6, 32 points 3e-11,
 * 48 points 2e-14 relative). Fixed nodes also make the result a smooth function of the geometry,
 * which an adaptive stopping rule is not. The rule integrates polynomials of degree <= 2N - 1
 * exactly.
 */
template <int N>
struct GaussLegendre {
  double x[N], w[N];
  GaussLegendre() {
    for (int i = 0; i < N; i++) {
      double z = std::cos(M_PI * (i + 0.75) / (N + 0.5)), z1, dp;
      do {
        double p1 = 1.0, p2 = 0.0;
        for (int j = 1; j <= N; j++) {
          const double p3 = p2;
          p2 = p1;
          p1 = ((2.0 * j - 1.0) * z * p2 - (j - 1.0) * p3) / j;
        }
        dp = N * (z * p1 - p2) / (z * z - 1.0);
        z1 = z;
        z = z1 - p1 / dp;
      } while (std::abs(z - z1) > 1e-15);
      x[i] = z;
      w[i] = 2.0 / ((1.0 - z * z) * dp * dp);
    }
  }
};

/// @return the N-point Gauss-Legendre rule, built once (thread-safe static initialisation)
template <int N>
const GaussLegendre<N>& gauss_legendre() {
  static const GaussLegendre<N> gl;
  return gl;
}
}  // namespace libecpint

#endif
