/* Copyright (C) 2022-2025 Davide Faconti, Eurecat -  All Rights Reserved
*
*   Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
*   to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
*   and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
*   The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
*
*   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
*   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
*   WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

#pragma once

#include "simple_string.hpp"

#include <cmath>
#include <type_traits>

#undef max
#undef min

namespace SafeAny
{

namespace details
{

template <typename BoolCondition>
using EnableIf = typename std::enable_if<BoolCondition::value, void>::type;

template <typename T>
constexpr bool is_integer()
{
  return std::is_same<T, bool>::value || std::is_same<T, char>::value ||
         std::is_integral<T>::value;
}

template <typename T>
constexpr bool is_convertible_type()
{
  return is_integer<T>() || std::is_floating_point<T>::value ||
         std::is_same<T, std::string>::value || std::is_same<T, SimpleString>::value ||
         std::is_enum<T>::value;
}

template <typename T>
constexpr bool is_convertible_to_bool()
{
  return is_integer<T>() || std::is_floating_point<T>::value || std::is_enum<T>::value;
}

template <typename T>
constexpr bool is_signed()
{
  return std::is_signed<T>::value;
}

template <typename T1, typename T2>
constexpr bool is_same()
{
  return std::is_same<T1, T2>::value;
}

template <typename From, typename To>
inline void checkUpperLimit(const From& from)
{
  if(from > static_cast<From>(std::numeric_limits<To>::max()))
  {
    throw std::runtime_error("Value outside the max numerical limit.");
  }
}

template <typename From, typename To>
inline void checkLowerLimit(const From& from)
{
  if constexpr(std::is_same<To, bool>::value)
  {
    if(from != 0 && from != 1)
    {
      throw std::runtime_error("Implicit casting to bool is not allowed");
    }
  }
  else if(from < std::numeric_limits<To>::min())
  {
    throw std::runtime_error("Value outside the lovest numerical limit.");
  }
}

// Rounding to a narrower floating point type is accepted, but a finite value
// beyond the range of To has no representation there: the conversion is
// undefined and in practice produces an infinity.
template <typename From, typename To>
inline void checkFloatingPointRange(const From& from)
{
  if constexpr(std::numeric_limits<To>::max_exponent <
               std::numeric_limits<From>::max_exponent)
  {
    // Values below max + half an ulp still round to max (e.g. 3.4028235e38,
    // the usual printout of FLT_MAX); from there on they round to infinity.
    constexpr int half_ulp_exp =
        std::numeric_limits<To>::max_exponent - std::numeric_limits<To>::digits - 1;
    const From limit = static_cast<From>(std::numeric_limits<To>::max()) +
                       std::ldexp(From(1), half_ulp_exp);
    if(std::isfinite(from) && std::fabs(from) >= limit)
    {
      throw std::runtime_error("Value outside the numeric limits of the floating point "
                               "type");
    }
  }
}

template <typename From, typename To>
inline void checkTruncation(const From& from)
{
  // Handle integer to floating point
  if constexpr(std::is_integral_v<From> && std::is_floating_point_v<To>)
  {
    // Check if value can be represented exactly in the target type
    constexpr uint64_t max_exact = (1LL << std::numeric_limits<double>::digits) - 1;
    bool doesnt_fit = false;
    if constexpr(!std::is_signed_v<From>)
    {
      doesnt_fit = static_cast<uint64_t>(from) > max_exact;
    }
    else
    {
      // Negate in unsigned arithmetic: std::abs(INT64_MIN) overflows.
      const auto value = static_cast<int64_t>(from);
      const uint64_t magnitude =
          value < 0 ? 0 - static_cast<uint64_t>(value) : static_cast<uint64_t>(value);
      doesnt_fit = magnitude > max_exact;
    }
    if(doesnt_fit)
    {
      throw std::runtime_error("Loss of precision when converting a large integer number "
                               "to floating point:" +
                               std::to_string(from));
    }
  }
  // Handle floating point to integer
  else if constexpr(std::is_floating_point_v<From> && std::is_integral_v<To>)
  {
    // static_cast<From>(To::max) rounds up to an out-of-range value when To has
    // more significant bits than From's mantissa (e.g. double -> int64_t). In
    // that case a plain `>` lets the rounded boundary through and the cast to To
    // below overflows, so use a half-open upper bound to reject it first.
    constexpr bool max_rounds_up =
        std::numeric_limits<To>::digits > std::numeric_limits<From>::digits;
    const From max_limit = static_cast<From>(std::numeric_limits<To>::max());
    const bool over = max_rounds_up ? (from >= max_limit) : (from > max_limit);
    if(over || from < static_cast<From>(std::numeric_limits<To>::lowest()) ||
       from != std::nearbyint(from))
    {
      throw std::runtime_error("Invalid floating point to integer conversion");
    }
  }
  // Handle floating point to floating point (e.g. double to float)
  else if constexpr(std::is_floating_point_v<From> && std::is_floating_point_v<To>)
  {
    checkFloatingPointRange<From, To>(from);
  }
  // Handle other conversions
  else
  {
    if(from > static_cast<From>(std::numeric_limits<To>::max()) ||
       from < static_cast<From>(std::numeric_limits<To>::lowest()))
    {
      throw std::runtime_error("Value outside numeric limits");
    }
    To as_target = static_cast<To>(from);
    From back_to_source = static_cast<From>(as_target);
    if(from != back_to_source)
    {
      throw std::runtime_error("Value truncated in conversion");
    }
  }
}

//----------------------- Implementation ----------------------------------------------

template <typename SRC, typename DST>
void convertNumber(const SRC& source, DST& target)
{
  static_assert(is_convertible_type<SRC>() && is_convertible_type<DST>(), "Not "
                                                                          "convertible");

  constexpr bool both_integers = is_integer<SRC>() && is_integer<DST>();

  if constexpr(is_signed<SRC>() && !is_signed<DST>())
  {
    if(source < 0)
    {
      throw std::runtime_error("Value is negative and can't be converted to unsigned");
    }
  }
  // these conversions are always safe (no check needed):
  // - same type
  // - float -> double
  // - floating point to bool (C-style: any non-zero is true)
  if constexpr(is_same<SRC, DST>() || (is_same<SRC, float>() && is_same<DST, double>()) ||
               (std::is_floating_point<SRC>::value && is_same<DST, bool>()))
  {
    target = static_cast<DST>(source);
  }
  // integer to bool: only 0 and 1 are valid
  else if constexpr(is_integer<SRC>() && is_same<DST, bool>())
  {
    checkLowerLimit<SRC, DST>(source);
    target = static_cast<DST>(source);
  }
  else if constexpr(both_integers)
  {
    if constexpr(sizeof(SRC) == sizeof(DST) && !is_signed<SRC>() && is_signed<DST>())
    {
      checkUpperLimit<SRC, DST>(source);
    }
    // casting to a smaller number need to be check
    else if constexpr(sizeof(SRC) > sizeof(DST))
    {
      if constexpr(is_signed<SRC>())
      {
        checkLowerLimit<SRC, DST>(source);
      }
      checkUpperLimit<SRC, DST>(source);
    }
    target = static_cast<DST>(source);
  }
  // casting to/from floating points might cause truncation.
  else if constexpr(std::is_floating_point<SRC>::value ||
                    std::is_floating_point<DST>::value)
  {
    checkTruncation<SRC, DST>(source);
    target = static_cast<DST>(source);
  }
}

}  //end namespace details
}  //end namespace SafeAny
