^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package behaviortree_cpp
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

4.11.0 (2026-11-08)
-------------------
* Feature: advanced xml validation (`#1146 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1146>`_)
* add Finally control node for guaranteed cleanup (`#1229 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1229>`_)
  * Behavior change: "Finally" is now a built-in node ID, so an application that
    registers its own node with that ID gets a duplicate-registration error.
* Add _onlyIf and _onStart preconditions (`#820 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/820>`_, `#895 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/895>`_) (`#1261 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1261>`_)
  * Behavior change: the attribute names `_onlyIf` and `_onStart` are now reserved.
    Before, they were stored silently as non-port attributes and did nothing.
* test: don't assume a tick rate in Reactive.TestLogging (`#1285 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1285>`_)
* null-check the entry in ImportBlackboardFromJSON after createEntry (`#1284 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1284>`_)
* Restore 4.10.0 ABI of Sleep/Delay/Timeout nodes; ignore stale timer handlers (`#1283 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1283>`_)
* add unit test for subtree with default values and autoremap enabled (`#1272 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1272>`_)
  * Behavior change: for a modelled input port with a literal default that is not
    explicitly remapped, the default is now set in the SubTree blackboard if no entry with
    that name exists in the parent blackboard when the tree is created (creation-time
    rule, documented in PORT_CONNECTION_RULES.md). A parent key created only at runtime
    (e.g. by a Script) is shadowed by the default.
* bound the AST height of flat script expressions (`#1259 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1259>`_)
  * Behavior change: a single script expression with more than ~255 chained operators is
    now rejected when the tree is created.
* reset a child's status when its halt() throws in ControlNode::haltChild (`#1273 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1273>`_)
* OSS-Fuzz: Add new fuzzer/corpus/dict targets tree exec (`#1277 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1277>`_)
* fix: bad_expected_access::what() returns the error message (`#1269 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1269>`_)
* Propagate skipped conditions in IfThenElse and WhileDoElse (`#1276 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1276>`_)
* Reset Precondition state between activations (`#1275 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1275>`_)
* forget a rejected XML document in XMLParser (`#1266 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1266>`_)
* ignore aborted timer handler in SleepNode (`#1267 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1267>`_)
* fix stack overflow on nested JSON in JsonToInteger and fromJson (`#1274 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1274>`_)
* make wildcards_match iterative to avoid stack overflow (`#1270 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1270>`_)
* use the locked entry in script assignment string conversion (`#1265 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1265>`_)
* Sort ports in the TreeNodesModel XML (`#851 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/851>`_) (`#1260 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1260>`_)
* fix: keep the name of SubTree nodes in WriteTreeToXML (`#1262 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1262>`_) (`#1268 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1268>`_)
* Bump prefix-dev/setup-pixi from 0.11.2 to 0.11.3 (`#1280 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1280>`_)
* feat: write the library version as BTCPP_version in the <root> of generated XML (`#1264 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1264>`_)
* test: a reactive node must not restart its RUNNING child (`#1258 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1258>`_)
* Add input port update subscriptions (`#1247 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1247>`_)
* store SubTree literals as strings again; coerce numeric strings in script arithmetic (`#1246 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1246>`_) (`#1254 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1254>`_)
  * Behavior change compared to 4.9.1 - 4.10.0, back to pre-4.9.1 behavior: two literal
    operands are strings ("1" + "2" is "12", "10" < "2" compares text), and compound
    assignment, unary minus, bitwise and logic operators on such a literal require an
    explicit number again.
* Allow a custom "__type" name in the JsonExporter lambda converters (`#1255 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1255>`_)
* Document the MSVC timer resolution caveat of Tree::sleep (`#1257 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1257>`_)
* Include emscripten/fiber.h at global scope before minicoro.h (`#1256 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1256>`_)
* clang-format: never split string literals (`#1253 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1253>`_)
* Warn when a BehaviorTree ID replaces one registered from another source (`#1133 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1133>`_)
  * Behavior change: a new "Warning: BehaviorTree ID [...] replaces ..." line on stdout in
    the cases above; no other change.
* Fix Reactive Sequence async control node validation (`#1183 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1183>`_)
  * Behavior change: a ReactiveSequence with two or more direct children among
    AsyncSequence / AsyncFallback, at least one of them an AsyncFallback, now fails to
    load, like two AsyncSequence already did.
* pixi: bound the parallel build on Linux (`#1252 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1252>`_)
* reject non-integer JSON numbers where an integer is expected (`#1240 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1240>`_)
  * Behavior change: int-vector elements, async_delay and Groot2 hook fields that are
    fractional, NaN, boolean or out of range now throw instead of being silently truncated
    or wrapped.
* reject out-of-range values in the double to float conversions (`#1249 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1249>`_)
  * Behavior change: reading a finite double with |x| >= FLT_MAX + half an ulp as float
    now throws instead of returning an infinity.
* throw instead of wrapping the 16-bit UID counter in Tree::getUID (`#1244 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1244>`_)
  * Behavior change: creating a tree with more than 65535 nodes now throws instead of
    succeeding with duplicate UIDs.
* fix overflow in the integer to floating point safe-cast checks (`#1238 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1238>`_)
* range-check uint16_t in the Any string to number fallback (`#1242 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1242>`_)
* fix null _p access in the TestNode async_delay timer handler (`#1243 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1243>`_)
* fix TimeoutNode halting the child concurrently with its timer thread (`#1241 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1241>`_)
* Bump prefix-dev/setup-pixi from 0.10.1 to 0.11.2 (`#1245 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1245>`_)
* Groot2Publisher: add a constructor that takes the bind address (`#1251 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1251>`_)
* XMLParser: detect cyclic <include> instead of overflowing the stack (`#1250 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1250>`_)
* TreeObserver: don't throw when two nodes have the same path (`#1234 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1234>`_)
* fix data race in SetBlackboardNode copying a blackboard entry (`#1236 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1236>`_)
* fix data race in SqliteLogger::callback (`#1237 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1237>`_)
* fix undefined double to int64 cast in the script complement operator (`#1239 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1239>`_)
* Add USE_VENDORED_JSON option to use the system nlohmann_json (fixes `#959 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/959>`_) (`#1235 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1235>`_)
* Validate model names in explicit XML node syntax (fixes `#1220 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1220>`_) (`#1231 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1231>`_)
  * Behavior change: the ID of explicit <Action>, <Condition>, <Decorator> and <Control>
    elements is now checked with the same model-name rules as the compact form, so an ID
    with a forbidden character (e.g. ID="My.Action") or the reserved name Root, which
    loaded before, now throws.
* fuzzing: don't return 1 from bb_fuzzer on unexpected exceptions (fixes `#1224 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1224>`_) (`#1233 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1233>`_)
* apply type checks in Blackboard::set when the key is remapped (`#1232 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1232>`_)
  * Behavior change: writes through a SubTree remapping now follow the same type rules as
    local writes. An unconvertible string written into a strongly typed parent entry
    throws instead of being stored as a std::string, and a remapped write locks the type
    of a weakly typed (AnyTypeAllowed) parent entry, as a local write already did.
* Report a declared port whose name cannot be bound (fixes `#1215 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1215>`_) (`#1216 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1216>`_)
* match subtrees by name in ImportTreeFromJSON (`#1227 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1227>`_)
* fix SimpleString equality for content with embedded NUL bytes (`#1230 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1230>`_)
* check from_chars result for integer literals in script parser (`#1214 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1214>`_)
* clamp snprintf result before using it as fwrite length (`#1185 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1185>`_)
* fix locale-dependent std::stod fallback in Any and SwitchNode (`#1218 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1218>`_)
* Say that duplicate SubTree names are checked across the whole tree (fixes `#1219 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1219>`_) (`#1222 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1222>`_)
* Name the forbidden character in the port name error (fixes `#1221 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1221>`_) (`#1223 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1223>`_)
* Bump actions/setup-python from 6 to 7 (`#1179 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1179>`_)
* DecoratorNode: don't discard the result of an asynchronous child (`#1206 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1206>`_)
* CI: run the Windows tests through ctest with --repeat until-pass (`#1205 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1205>`_)
* docs: clarify that Precondition is evaluated once per activation, not every tick (`#1204 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1204>`_)
* add Blackboard::getKeyNames() and deprecate getKeys() (`#1203 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1203>`_)
* fix use-after-free of a blackboard entry held by getAnyLocked (alternative to `#1181 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1181>`_) (`#1202 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1202>`_)
* Bump prefix-dev/setup-pixi from 0.10.0 to 0.10.1 (`#1190 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1190>`_)
* haltTree() from another thread now stops tickWhileRunning() (fixes `#686 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/686>`_) (`#1201 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1201>`_)
* fix FileLogger2: drain the transition queue in the destructor after joining the writer thread (`#1198 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1198>`_)
* fix TimerQueue shutdown race that left cancelled items in the queue (`#1200 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1200>`_)
* validate substituted node type in instantiateTreeNode (`#1193 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1193>`_)
* fix: typo Slop->Slot and mark Signal::subscribe() [[nodiscard]] (`#1199 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1199>`_)
* Fix logical not for string-backed booleans (`#1191 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1191>`_)
* preserve integer width in JsonExporter::fromJson (`#1186 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1186>`_)
* fix use-after-free of the timer node mutex on destruction (`#1180 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1180>`_)
* fix unbounded recursion in the script expression parser (`#1174 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1174>`_)
* Fix library version in CMake subprojects (`#1188 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1188>`_)
* fix @ root remapping in Blackboard::createEntryImpl (`#1192 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1192>`_)
* validate backup size in BlackboardRestore (`#1182 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1182>`_)
* Contributors: Arthur Chan, Aysha Afrah Ziya, Azer Ben Ali, DV (David Vadovszki), Davide Faconti, Golitsin Vyacheslav, Igor Stadnyk, Jonas Otto, KImanalieva, Lim Jooyoung, Nikola Kachmaryk, Varun Kumar, Victor Voronin, dependabot[bot], ktyang, simobenziane

4.10.0 (2026-07-24)
-------------------
* reject trailing characters in SwitchNode numeric comparison (`#1178 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1178>`_)
* Pin ament install destinations to lib/include/bin (fixes `#1175 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1175>`_) (`#1176 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1176>`_)
  The ROS build farm (bloom/debhelper) configures with
  -DCMAKE_INSTALL_LIBDIR=lib/<multiarch-triplet>. Since `#1152 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1152>`_ made the
  BTCPP\_*_DESTINATION variables honor GNUInstallDirs, farm binaries
  installed libbehaviortree_cpp.so to /opt/ros/<distro>/lib/x86_64-linux-gnu,
  which breaks ament_export_libraries lookup in downstream packages and is
  not on the LD_LIBRARY_PATH set by the ament environment hooks.
  Shadow the cache variables with plain set() in the ament build path, so
  ROS builds always install to $prefix/lib regardless of
  CMAKE_INSTALL_LIBDIR, while standalone builds keep the GNUInstallDirs
  override behavior introduced for `#1120 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1120>`_.
  Also add a ros2-lyrical CI job that emulates the build farm flags and
  asserts the library lands in $prefix/lib.
  Co-authored-by: Claude Fable 5 <noreply@anthropic.com>
* fix out-of-bounds read in Groot2 hook insert handler (`#1170 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1170>`_)
  * fix out-of-bounds read in Groot2 hook insert handler
  * exclude Parallel.FailingParallel from macOS CI test run
* Add scripted return status support for TestNode mocks (`#1169 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1169>`_)
  Introduce `return_status_script` on TestNodeConfig, allowing a mock's
  completion status to be computed at runtime from blackboard state instead
  of being fixed. When set, it takes precedence over `return_status`; it may
  reference the NodeStatus names (SUCCESS/FAILURE/...) and is rejected if it
  resolves to IDLE.
  The NodeStatus enum names are injected only into the return_status_script
  environment. The pre-existing success_script/failure_script/post_script
  continue to evaluate against the node's own enums, so a blackboard entry
  named like a status (e.g. "SUCCESS") is not shadowed.
  To pay the ABI break only once, TestNode's state is moved behind a PImpl,
  so future changes to it no longer alter the layout consumers link against
  (mirroring StatusChangeLogger). The new return_status_script field is
  appended at the end of TestNodeConfig, preserving the byte offsets of the
  existing fields.
  Also add JSON validation rejecting a TestNodeConfig with neither a
  return_status nor a return_status_script, and a tutorial example
  (t15_nodes_mocking_strict_failure) demonstrating the strict-failure flow.
  Addresses `#995 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/995>`_.
  Co-authored-by: Pepe <pepe@ross-robotics.co.uk>
  Co-authored-by: Claude Opus 4.8 <noreply@anthropic.com>
* Fix ROOT blackboard export in Groot2 publisher (`#1132 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1132>`_) (`#1168 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1168>`_)
  When a subtree's blackboard is backed by a separate root blackboard
  (e.g. created via `Blackboard::create(external_root)` to expose `@`
  globals), the Groot2 publisher never exported those root entries, so
  they were invisible in Groot2. Export the root blackboard under the
  reserved name `ROOT` whenever a requested subtree resolves to a
  distinct root blackboard.
  - Deduplicate the `ROOT` payload when several subtrees share the same
  root blackboard.
  - Return the dump as `Expected<>` and send an error reply for
  ambiguous requests: a subtree literally named `ROOT`, or a request
  spanning multiple distinct root blackboards.
  - Add functional coverage to gtest_groot2_publisher_integration.cpp
  using the shared Groot2Test helpers (makePublisher/Client).
  - Enable `/utf-8` for behaviortree_cpp_test on MSVC so the Unicode
  name-validation tests build on Windows.
  Closes `#1130 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1130>`_
  Co-authored-by: magic-alt <zaqwerss@outlook.com>
  Co-authored-by: Claude Opus 4.8 <noreply@anthropic.com>
* Add macOS CI and fix Apple libc++ build (`#1167 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1167>`_)
  * Add macOS build to CI
  Add a Conan + CMake workflow running on macos-latest (Apple Silicon,
  AppleClang + libc++). This exercises the Apple standard-library toolchain
  that other CI jobs (Ubuntu/GCC, Windows/MSVC, conda/Clang) do not, catching
  Apple-specific breakage such as the missing floating-point std::from_chars.
  The job mirrors the existing cmake_ubuntu.yml Conan flow (conan install ->
  cmake --preset conan-release -> ctest), pinning compiler.cppstd=17 as the
  Windows job does.
  Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>
  * Fix Apple libc++ build: guard floating-point std::from_chars
  Apple's libc++ deletes the floating-point std::from_chars overload (and
  undefines __cpp_lib_to_chars), so the unguarded double parse in
  recursivelyCreateSubtree fails to compile on macOS. This is the same code
  path the new cmake_macos.yml CI job exercises, so guard it here to keep that
  job green.
  Introduce parseDoubleStrict(), which uses std::from_chars where available and,
  where it is not (Apple libc++), falls back to strtod_l with a "C" locale
  created once. Unlike setlocale(), this does not mutate process-global state,
  so it is thread-safe. A small guard rejects the inputs strtod would accept but
  std::from_chars(general) rejects -- leading whitespace, a leading '+', and hex
  floats -- so the parsed blackboard-entry type is identical on every platform.
  Verified byte-for-byte against std::from_chars over a battery of inputs
  (including "+1.5", " 1.5", "0x1p4", "1.", ".5", inf/nan, overflow/underflow).
  The integer std::from_chars just above is available on Apple libc++ and is
  left unchanged.
  Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>
  * CI: install Conan via Homebrew on macOS
  turtlebrowser/get-conan runs `pip3 install`, which fails on macOS runners with
  PEP 668 (externally-managed-environment). Use `brew install conan` instead,
  which provides Conan 2.x without touching the system Python.
  Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>
  * Fix convertFromString<double/float> error type on Apple libc++
  On platforms without floating-point std::from_chars (Apple libc++), the
  fallback used std::stod but let its std::invalid_argument/out_of_range escape,
  whereas the from_chars path throws BT::RuntimeError. This made
  BasicTypes.ConvertFromString_Double fail on macOS (it expects RuntimeError for
  "not_a_number"). The throw also skipped the setlocale restore, leaking the "C"
  locale process-wide. Wrap stod in try/catch: restore the locale and rethrow as
  RuntimeError on both success and failure paths.
  Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>
  * CI: macOS diagnostics for remaining test failures (temporary)
  Add --output-on-failure and an lldb backtrace step (on failure) to capture
  assertion messages and stack traces for the macOS-only segfaults/timeouts.
  To be removed once those are fixed.
  Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>
  * Fix macOS segfault: don't touch child in DelayNode destructor
  ~DelayNode called halt(), which via DecoratorNode::halt() -> resetChild()
  dereferences the child node (child_node\_->status()). During Tree destruction
  nodes are owned by a flat std::vector<TreeNode::Ptr> whose element-destruction
  order is unspecified: libstdc++ tears down front-to-back (child outlives the
  decorator) but libc++ back-to-front (child destroyed first). On libc++ (macOS)
  the child is already gone, so status() locks a mutex through a null PImpl and
  segfaults. This crashed every tree containing a <Delay> node on macOS
  (Decorator.DelayWithXML and the Substitution Issue930 tests).
  Only cancel the timer in the destructor, mirroring TimeoutNode's destructor,
  which already does exactly this. The halt() method is unchanged for normal
  (non-destruction) halting.
  Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>
  * CI: retry timing-flaky tests on macOS (--repeat until-pass:3)
  The shared macOS runners cannot reliably meet several tests' tight wall-clock
  tolerances (e.g. elapsed 222 vs 200 ms), and the failing set varies run to run.
  Retry to absorb the flakiness without loosening assertions on other platforms.
  Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>
  * tests: widen timing tolerances on macOS (platform-gated)
  The shared macOS CI runners are much slower/noisier than Linux/Windows, so a
  few tests with tight wall-clock tolerances fail there (not library bugs). Gate
  the tolerances behind __APPLE_\_ so other platforms keep the strict values:
  - gtest_coroutines: scale the sub-50ms action/timeout durations by 5x on macOS
  (only relative ordering matters), so the timeout reliably fires between the
  short and long actions instead of racing scheduling jitter.
  - gtest_parallel PauseWithRetry: widen margin_msec 80 -> 250 on macOS
  (observed overshoot was 130-150ms).
  Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>
  * CI: bump macOS test retries to until-pass:5
  A couple of timing tests (Parallel.Issue819, SwitchTest.CaseSwitchToDefault)
  are flaky under runner load rather than consistently over a single tolerance,
  so retry a bit more to absorb that.
  Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>
  * CI: exclude timing-flaky tests on macOS; drop lldb diagnostic
  The shared macOS runners are too slow/noisy to reliably meet the tight
  wall-clock tolerances in ~11 tests (a rotating subset fails each run). They are
  not macOS-specific logic and keep running on Linux and Windows, so exclude them
  on macOS with ctest -E to make the job deterministic. --repeat until-pass:3
  absorbs residual flakiness in the rest. The __APPLE_\_-gated tolerances added
  earlier (gtest_coroutines, gtest_parallel) remain so these can be re-enabled
  here later.
  Also remove the temporary lldb backtrace step now that the DelayNode
  destruction segfault is fixed.
  Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>
  * Revert macOS timing-margin edits; rely on exclusion only
  Since the timing-sensitive tests are excluded on macOS (ctest -E), there is no
  reason to also widen their wall-clock tolerances. Restore gtest_coroutines.cpp
  and gtest_parallel.cpp to their original values so the shared tests stay
  pristine for every platform, and drop the stale workflow comment that mentioned
  the __APPLE_\_-gated tolerances.
  Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>
  * Simplify: dedup convertFromString double/float Apple fallback
  /simplify cleanup. The macOS (no floating-point std::from_chars) fallback was
  duplicated between convertFromString<double> and <float>, each restoring the
  locale twice (catch + fall-through). Extract a single guarded file-local helper
  stodClassicLocale() with an RAII locale-restore, so the fallback lives in one
  place and the restore happens on every path without the duplicated try/catch.
  Behavior is unchanged (still stod under a temporary "C" locale, still throws
  RuntimeError on bad input).
  Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>
  * Unify double parsing into a single BT::parseDouble primitive
  Previously the "parse a double locale-independently" logic existed in two
  divergent forms: xml_parsing.cpp's parseDoubleStrict (from_chars, or strtod_l +
  "C" locale on Apple libc++ -- thread-safe, strict) and basic_types.cpp's
  convertFromString<double>/<float> Apple fallback (stod + global setlocale --
  thread-unsafe, lenient). They also disagreed on Apple: convertFromString
  accepted leading '+'/whitespace/hex that std::from_chars (and thus the other
  platforms) reject.
  Extract one shared BT::parseDouble(str, out, require_full_consumption) that both
  build on:
  - xml_parsing passes require_full_consumption=true (strict full-string check,
  so compound values like "2.2;2.4" stay strings).
  - convertFromString<double>/<float> pass false (lenient, matching the previous
  from_chars behavior of accepting trailing characters).
  The single implementation uses std::from_chars where available and the
  thread-safe strtod_l + static "C" locale fallback otherwise, reproducing
  from_chars(general) semantics exactly (verified against std::from_chars over a
  battery of inputs, both modes). This removes the duplicated fallback and the
  thread-unsafe setlocale path from basic_types.cpp. On Apple, convertFromString
  now rejects '+'/whitespace/hex, matching Linux/Windows.
  convertFromString<float> keeps std::from_chars<float> on platforms that have it
  (preserving float-range semantics) and uses parseDouble only on the fallback.
  Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>
  ---------
  Co-authored-by: Claude Opus 4.8 <noreply@anthropic.com>
* test(test_node): cover script enum resolution (`#1166 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1166>`_)
* Fix Groot2 publisher thread safety and hook handling (`#1165 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1165>`_)
  * Fix Groot2 publisher thread safety
  * Simplify Groot2 publisher thread-safety machinery
  Apply code-review cleanups to the thread-safety fix:
  - Extract the duplicated callback drain-gate (CallbackState/CallbackGuard
  and HookCallbackState/HookCallbackGuard were byte-identical) into a
  single shared BT::details::CallbackGate in utils/callback_gate.h.
  notify_all() now fires only when a drain is actually waiting.
  - Replace the 69-line injected hook lambda and its immediately-invoked
  inner lambda with PImpl::runHook(). The BREAKPOINT_REACHED message is
  now built and sent without holding hook->mutex, and only the ZMQ send
  holds publisher_mutex.
  - Drop the Hook::removed tombstone from the public protocol header:
  with the single lock order established (hooks_map_mutex before
  hook->mutex), enableAllHooks() and HOOKS_DUMP traverse the maps under
  hooks_map_mutex, so no stale snapshot can resurrect an erased hook and
  'enabled = false' suffices for stale callback copies.
  - GET_TRANSITIONS: swap the transitions buffer out under status_mutex
  and serialize outside the lock the status callback contends on.
  - Call unsubscribeFromTreeChanges() in the destructors of the five other
  StatusChangeLogger subclasses; the base-class destructor call runs too
  late to protect derived state, so each dtor must drain callbacks first.
  - Deduplicate the hook-JSON literals in the Groot2 tests into
  Groot2Test::makeHook(); use make_unique for PImpl; rely on CTAD for
  lock guards in touched code.
  Verified: 495/495 tests (Release), 499/499 under TSan with the CI
  suppressions file, zero ThreadSanitizer warnings.
  Co-Authored-By: Claude Fable 5 <noreply@anthropic.com>
  * Extend TSan suppressions to statically linked ZeroMQ
  CI builds zmq from source with Conan and links it statically, so the
  module-based rule 'race:libzmq.so' does not match and zmq-internal
  false positives (encoder_base_t::encode, msg_t::close) fail the
  Groot2 hook tests. Match the zmq namespace instead, which works
  regardless of how the library is linked.
  Co-Authored-By: Claude Fable 5 <noreply@anthropic.com>
  * Move StatusChangeLogger state behind a PImpl
  StatusChangeLogger is the base class of a public extension point: every
  logger, including user-defined ones, embeds its layout. The thread-safety
  fix already changes that layout (and, being header-only, the old inlined
  implementation survives in consumer binaries even after a library
  upgrade), so take the opportunity to pay the ABI break only once:
  - all data members move into a PImpl defined in the new
  src/loggers/abstract_logger.cpp
  - the member functions are no longer inline, so future behavior fixes in
  this class can ship as an ABI-compatible library update
  Adding or changing state in StatusChangeLogger no longer affects the
  layout derived classes compile against. Note that changing its virtual
  interface would still break ABI.
  Co-Authored-By: Claude Fable 5 <noreply@anthropic.com>
  ---------
  Co-authored-by: Claude Fable 5 <noreply@anthropic.com>
* fix undefined float-to-integer cast at the numeric limit boundary (`#1162 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1162>`_)
* fix out-of-bounds read in isBlackboardPointer whitespace trim (`#1161 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1161>`_)
  Co-authored-by: Davide Faconti <davide.faconti@gmail.com>
* Fix package share path API for newer ament_index_cpp (`#1163 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1163>`_)
  * Fix package share path API for newer ament_index_cpp
  * Style: format package share path update
  ---------
  Co-authored-by: Davide Faconti <davide.faconti@gmail.com>
* Fix WakeUp test flakiness by using steady_clock (`#1164 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1164>`_)
  The `WakeUp.BasicTest` previously used `system_clock`, which is not monotonic and can be affected by system time adjustments (NTP, DST). This made the test susceptible to flaky failures.
  This change switches to `steady_clock` for robust, monotonic time measurement. Additionally, the assertion threshold is increased from `25ms` to `100ms` to provide adequate headroom for scheduler jitter, especially on loaded CI environments.
* Contributors: Aysha Afrah Ziya, Davide Faconti, Maurice Alexander Purnawan, pepeRossRobotics

4.9.1 (2026-07-06)
------------------
* Merge pull request `#1139 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1139>`_ from mini-1235/patch-3
  Fix -Wfree-nonheap-object and -Wunused-result
* Fix -Wfree-nonheap-object and -Wnull-dereference
* Merge pull request `#1128 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1128>`_ from XinyuKhan/patch-1
  Rename header guard for shared_library.h
* Rename header guard for shared_library.h
* Merge pull request `#1126 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1126>`_ from BehaviorTree/dependabot/github_actions/prefix-dev/setup-pixi-0.9.5
  Bump prefix-dev/setup-pixi from 0.9.4 to 0.9.5
* Merge pull request `#1127 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1127>`_ from botsandus/add-sleep-override
  Add `Tree::wakeUpSignal()` getter
* Merge pull request `#1121 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1121>`_ from PickNikRobotics/fix-subtree-literal-numeric-types
  Preserve numeric types for literal subtree port values
* version 2
* lint
* Add support for custom sleep override function in Tree class
* Bump prefix-dev/setup-pixi from 0.9.4 to 0.9.5
  Bumps [prefix-dev/setup-pixi](https://github.com/prefix-dev/setup-pixi) from 0.9.4 to 0.9.5.
  - [Release notes](https://github.com/prefix-dev/setup-pixi/releases)
  - [Commits](https://github.com/prefix-dev/setup-pixi/compare/v0.9.4...v0.9.5)
  ---
  updated-dependencies:
  - dependency-name: prefix-dev/setup-pixi
  dependency-version: 0.9.5
  dependency-type: direct:production
  update-type: version-update:semver-patch
  ...
* Preserve numeric types for literal subtree port values
  When literal values are passed to SubTree ports (not blackboard remapping),
  detect numeric types (int64_t, double) before storing them in the child
  blackboard. Previously all literals were stored as std::string, which caused
  type-mismatch errors in Script expressions that tried to do arithmetic.
  Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>
* Contributors: Davide Faconti, Ladislav Skvarka, Tony Najjar, Xinyu Han, dependabot[bot], mini-1235

4.9.0 (2026-02-11)
------------------
* Fix Blackboard thread-safety: 6 data races fixed, use shared_mutex for storage
* Fix XML parser null pointer dereference in loadSubtreeModel on missing SubTree ID
* Add TryCatch control node for try/catch recovery patterns
* Fix `#1111 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1111>`_: EntryUpdatedDecorator::halt() not halting its child (`#1112 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1112>`_)
* Add polymorphic shared_ptr port support (`#943 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/943>`_) (`#1107 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1107>`_)
* Fix `std::from_chars` compilation on older g++ versions (`#1110 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1110>`_)
* Fix clang-tidy warnings across tests, examples, and samples (`#1109 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1109>`_)
* Add exception tracking with node backtrace (`#990 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/990>`_) (`#1106 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1106>`_)
* Fix `#861 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/861>`_
* Fix `#917 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/917>`_: add comments about preconditions
* Fix missing read_parameter_from_ports initialization in DelayNode (`#1103 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1103>`_)
* Fix `#880 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/880>`_: createTreeFromText now finds previously registered subtrees (`#1105 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1105>`_)
* Remove lexy dependency, replace with hand-written tokenizer and Pratt parser (`#1099 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1099>`_)
* Fix `#953 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/953>`_: getInput() now uses stored converter for plugin custom types (`#1104 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1104>`_)
* Improve test suite quality and coverage (`#1102 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1102>`_)
* Fix Groot2Publisher destructor infinite loop (`#1057 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1057>`_) (`#1100 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1100>`_)
* Fix misleading static_assert when extra args have wrong type (`#837 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/837>`_) (`#1098 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1098>`_)
* Fix DelayNode ignoring delay_msec when created from XML (`#1097 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1097>`_)
* Fix Windows build issues (`#762 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/762>`_, `#869 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/869>`_, `#836 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/836>`_) (`#1089 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1089>`_)
* Fix `#989 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/989>`_: JsonExporter use-after-move in vector converter registration (`#1090 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1090>`_)
* Fix `#672 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/672>`_: reject deeply-nested/recursive XML to prevent stack overflow (`#1091 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1091>`_)
* Fix `#930 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/930>`_: mock substitution hangs when TestNodeConfigs is absent (`#1086 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1086>`_)
* Detect recursive subtree cycles at parse time (`#979 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/979>`_) (`#1085 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1085>`_)
* Fix `#1046 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1046>`_: use-after-free when factory destroyed before tree (`#1081 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1081>`_)
* Fix `#934 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/934>`_: segfault when substituting a SubTree node (`#1083 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1083>`_)
* Fix `#937 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/937>`_: enable returning BehaviorTreeFactory by value (`#1082 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1082>`_)
* Add vcpkg installation instructions (`#421 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/421>`_)
* Fix `#942 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/942>`_: getLockedPortContent creates entry for default-remapped ports (`#1078 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1078>`_)
* Add code coverage CI with Codecov, Coveralls, Codacy, and SonarCloud (`#1068 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1068>`_)
* Fix Groot2Publisher destructor infinite loop (`#1058 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1058>`_)
* Remove deprecated `std::aligned_storage` (`#1061 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1061>`_)
* Add regression test for `#1065 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1065>`_: subtree string literal to LoopDouble (`#1072 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1072>`_)
* Add regression test for `#858 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/858>`_: getInput with default port value (`#1076 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1076>`_)
* Add regression test for `#832 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/832>`_: script compare with negative number (`#1071 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1071>`_)
* Add regression test for `#923 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/923>`_: ValidateScript OOB read with large scripts (`#1070 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1070>`_)
* Fix `#948 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/948>`_: parseString supports enums with convertFromString specializations (`#1075 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1075>`_)
* Fix `#982 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/982>`_: handle json: prefix in vector convertFromString specializations (`#1073 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1073>`_)
* Fix `#408 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/408>`_: debugMessage shows type info for remapped subtree entries (`#1079 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1079>`_)
* Fix `#969 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/969>`_: LoopNode accepts std::vector<T> in addition to SharedQueue<T> (`#1074 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1074>`_)
* Fix `#1029 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1029>`_: correct left-associativity for arithmetic operators in script parser (`#1069 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1069>`_)
* Generate .clangd in PROJECT_SOURCE_DIR for submodule/FetchContent support (`#1059 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1059>`_)
* Contributors: Christoph Hertzberg, Copilot, Davide Faconti, Frank, Vincent PALANCHER, alvintps, dependabot[bot]

4.8.4 (2026-01-09)
------------------
* extend the Groot example to reproduce issues with arrays
* add tool to generate XML models
* add documentation to classes
* sort includes with clang format
* add new name validation rules
* add claude file
* detect duplicated instance names
* cleanup doc
* add contributors guide
* move and cleanup tests
* Contributors: Davide Faconti

4.8.3 (2025-12-29)
------------------
* minor change
* remove nolint
* Entry should be non copyable
* miscellaneus
* fix
* run clang tidy in CI
* fix remaining warnings
* apply the rulke of 5
* fix compilation in c++17
* add clang tidy and fix warnings
* update copyright year
* add unit test
* fix multiple issues with SimpleString
* Merge pull request `#1043 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1043>`_ from uilianries/fix/cppzmq-visibility
  [fix] Make cppzmq as public dependency to avoid linkage errors for tools
* Turn cppzmq dependency public
* Restore Star History and add Contributors section
  Reintroduced the Star History section and added Contributors section to the README.
* Update copyright year in README.md
* Contributors: Davide Faconti, Uilian Ries

4.8.2 (2025-10-30)
------------------
* Merge pull request `#996 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/996>`_ from EnjoyRobotics/make-sequence-node-inheritable
* Merge branch 'master' of github.com:BehaviorTree/BehaviorTree.CPP
* fix issue `#1034 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1034>`_
* Merge pull request `#1030 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1030>`_ from pleemann/tree_wake_up
  Event-based tree ticking
* force tinyxml2_vendor in ROS2. See `#1033 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1033>`_ and `#1028 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1028>`_
* added Tree::emitWakeUpSignal
* Lint
* Propagate node config to parent
* Make tick method protected
* Contributors: Davide Faconti, pleemann, redvinaa

4.8.1 (2025-10-23)
------------------

4.8.0 (2025-10-14)
------------------
* fix issue in destruction order
* fix memory leak
* fix thread safety issues
* Improve error message
* Leave a note for posterity
* Fix windows builds
* Do not fail fast. We want results of both sanitizer runs
* Combine sanitizer actions into a single file
* use gtest_discover_tests to regiester the unit tests
  this modern approach registers many individual tests instead of a single monolitic test
  so if one fails the rest continue running which allows the developer to flag multiple
  failing tests on a single run
  It also speeds up testing since tests run in parallel
* Add support for sanitizers including some GHAs
* Remove unused conan.cmake (`#1016 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1016>`_)
* Improve handling of dependencies (`#1012 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1012>`_)
* update tinyxml to version 11.0
* fix potential compilation errors
* compile for c++ 17 (`#1013 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1013>`_)
* Contributors: Davide Faconti, Eric Riff

4.7.3 (2025-10-01)
------------------
* remove cpp-sqlite
* update cppzmq to 4.11.0
* remove wildcards from 3rd party
* Clean up VerifyXML logic (`#1000 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1000>`_)
  * Refactor VerifyXML to clarify logic
  - Reduces duplication in VerifyXML by handling the ID check for built-in
  node types up front so they can then be definitively looked up in the
  registered nodes.
  - Enhances error messaging in VerifyXML by using *either* the node name
  *or* the ID, depending on which is appropriate, instead of leaving
  users guessing "which Decorator is wrong"
  - Fixes custom Action and Condition nodes using shorthand syntax not
  being properly verified
  - Fixes `<Control ID="ReactiveSequence"/>` not being verified with the
  same logic as `<ReactiveSequence/>`
  - Fixes `<Action ID="MyAction"/>` not triggering a behavior lookup when
  `<MyAction/>` would.
  * fix tests that were failing due to bad assumptions
* Append SQLite3_INCLUDE_DIRS to BTCPP_EXTRA_INCLUDE_DIRS, otherwise sqlite3.h won't be found (`#1002 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1002>`_)
  Co-authored-by: alejandro.suarez@omron.com <alejandro.suarez@omron.com>
* fix: use dynamically growing error buffer in ParseScript (`#1007 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1007>`_)
  * fix: use dynamically growing error buffer in ParseScript
  * style: format code
  * fix: use dynamically growing error buffer in ValidateScript
  ---------
  Co-authored-by: ahuo <ahuo2865189826@gmail.com>
* fix: validate __type field before accessing in fromJson (`#1009 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1009>`_)
  Co-authored-by: ahuo <ahuo2865189826@gmail.com>
* fix: check path attribute before using (`#1005 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/1005>`_)
  Co-authored-by: ahuo <ahuo2865189826@gmail.com>
* Set current_child_idx of SequenceNode protected (`#991 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/991>`_)
* Add convertFromString<vector<bool>> (`#992 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/992>`_)
* Update README.md fix `#985 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/985>`_
  Duuuude
* fix: exclude 3rd party libraries from sonar issue tracking (`#984 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/984>`_)
* change CI file
* Contributors: Alejandro Suárez, Davide Faconti, Ezra Brooks, Marcus Ebner von Eschenbach, Shaur(ya) Kumar, Vince Reda, Yiyi Wang

4.7.2 (2025-05-29)
------------------
* Fix issue `#978 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/978>`_ : skipped was not working properly
* Added codespell as a pre-commit hook. (`#977 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/977>`_)
* fix: Make impossible to accidentally copy JsonExporter singleton (`#975 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/975>`_)
* Contributors: Davide Faconti, Leander Stephen D'Souza, tony-p

4.7.1 (2025-05-13)
------------------
* fix ROS CI
* Add action to publish Doxygen documentation as GH Page (`#972 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/972>`_)
* Update Doxyfile
* Make BT::Any::copyInto const (`#970 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/970>`_)
* more changes related to TestNode
* Contributors: David Sobek, Davide Faconti, Marcus Ebner von Eschenbach

4.7.0 (2025-04-24)
------------------
* change TestNodeConfig preferred constructor
* Fix dangling‐capture in TestNodeConfig
* Fix Precondition to only check condition once (`#904 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/904>`_)
* fix issue 945
* extend JSON conversion to include vectors (`#965 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/965>`_)
* Fix CI, add BUILD_TESTS and remove catkin support
* Fix testing CMake issue to resolve Rolling regression (`#961 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/961>`_)
* Bug fix/set blackboard (`#955 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/955>`_)
* feat: add fuzzing harnesses (`#925 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/925>`_)
* fix warnings
* Add const to applyVisitor (`#935 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/935>`_)
* try fix (`#941 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/941>`_)
* add workflow for sonarcube (`#936 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/936>`_)
* Fix issue `#909 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/909>`_: static queue in Loop
* apply changes suggested in `#893 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/893>`_
* apply fix mentioned in `#916 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/916>`_
* apply fixes suggested in `#919 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/919>`_
* fix issue `#918 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/918>`_ (introduced in `#885 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/885>`_)
* add fix suggested in `#920 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/920>`_
* add unit test related to `#931 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/931>`_
* Fix compilation error when targeting C++23 (`#926 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/926>`_)                   ^~~~~~~~~~~~~
* Fixes issue # `#929 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/929>`_ and `#921 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/921>`_
* apply check suggested in `#924 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/924>`_
* Fix ROS 2 build when ZeroMQ or SQlite3 include are not in the default include path (`#911 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/911>`_)
  * Fix ROS 2 build when ZeroMQ or SQlite3 include are not in the default include path
  * Update ament_build.cmake
* Fix/use correct compiler pixi/conda (`#914 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/914>`_)
  * fix: Use the cxx-compiler package which will set the correct compiler for the platform, and setup the required environment for it to work as expected
  * misc: update pixi versions in pipeline
* Add "other ports" to NodeConfig (`#910 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/910>`_)
* [retry_node] Refresh max_attempts\_ in case it changed (`#905 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/905>`_)
  Co-authored-by: Guillaume Doisy <guillaume@dexory.com>
* use relative path in .Doxyfile (`#882 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/882>`_)
* Additional XML verification for ReactiveSequence nodes (`#885 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/885>`_)
  Co-authored-by: AndyZe <andyzelenak@apptronik.com>
* fix script parse error while 'A==-1' (`#896 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/896>`_)
  Co-authored-by: wangzheng <wangz@oasisrobotics.tech>
* Expose return value of wait_for (`#887 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/887>`_)
* fix(examples): update t11_groot_howto log filename (`#886 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/886>`_)
* put minitrace in the build_interface link library (`#874 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/874>`_)
  fixes the cmake export set when building behavior tree on standard cmake: CMake Error: install(EXPORT "behaviortree_cppTargets" ...) includes target "behaviortree_cpp" which requires target "minitrace" that is not in any export set.
* Improved XML parsing error message to say where in the XML the offending port is found. (`#876 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/876>`_)
  Example output:
  a port with name [ball_pose] is found in the XML (<GrabBall>, line 7) but not in the providedPorts() of its registered node type.
* Refactored the TreeNode::executeTick() function to use a scoped timer for performance monitoring. (`#861 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/861>`_) (`#863 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/863>`_)
  Update src/tree_node.cpp
  Co-authored-by: wangzheng <wangz@oasisrobotics.tech>
  Co-authored-by: Davide Faconti <davide.faconti@gmail.com>
* fix issue `#852 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/852>`_: thread safety in Loggers
* Lexy updated
* tinyXML updated to version 10.0
* cppzmq updated to version 4.10
* fix the "all_skipped" logic
* fixed: support utf-8 path xml-file (`#845 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/845>`_)
  * fixed: 1. added compile version check to support Chinese path xml-file parsing 2. cmake add msvc /utf-8 options
  * change cmake /utf-8 option add mode
* Export plugins to share directory & register CrossDoor plugin (`#804 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/804>`_)
* Contributors: Aglargil, AndyZe, Antoine Hoarau, David Sobek, Davide Faconti, Guillaume Doisy, Isar Meijer, Jake Keller, Marq Rasmussen, Michele Tartari, Silvio Traversaro, Tony Najjar, b-adkins, ckrah, devis12, kinly, tony-p, vincent-hui

4.6.2 (2024-06-26)
------------------
* Initialize template variable `T out` (`#839 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/839>`_)
* Building with a recent compiler fails due incompatible expected library (`#833 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/833>`_)
  * nonstd::expected updated to 0.8
* fix issue `#829 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/829>`_: support again custom JSON converters
* fix issue `#834 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/834>`_: enable minitrace
* allow multiple instances of the loggers
* fix issue `#827 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/827>`_ : verify <BehaviorTree> name
* add TickMonitorCallback
* Fix typo in FallbackNode constructor parameter name (`#830 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/830>`_)
* fix segfault and throw instead when manifest is nullptr
* Add in call to ament_export_targets. (`#826 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/826>`_)
* Contributors: Davide Faconti, S. Messerschmidt, Sharmin Ramli, avikus-seonghyeon.kwon

4.6.1 (2024-05-20)
------------------
* remove flatbuffers from public API and old file_logger
* fix issue `#824 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/824>`_: use global in Blackboard::set
* Add test for setting a global blackboard entry using a node's output port `#823 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/823>`_
* examples renamed
* Contributors: Davide Faconti, Robin Müller

4.6.0 (2024-04-28)
------------------
* add tutorial 19 about the global blackboard
* renamed examples to match website
* Update TestNode and the corresponding tutorial
* bug fixes related to sequence_id and unit tests added
* Add string concatenation operator to scripting (`#802 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/802>`_)
* Add library alias for BT::behaviortree_cpp (`#808 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/808>`_)
* add Time Stamped blackboard (`#805 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/805>`_)
* add additional information and functionality to SQLiteLogger
* add syntax for entries in the root blackboard ("@" prefix)
* Fix/pixi build (`#791 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/791>`_)
* fix unit tests in Windows
* fix windows compilation
* Update cmake_windows.yml
* Deprecate Balckboard::clear(). Issue `#794 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/794>`_
* Support string vector conversion for ports (`#790 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/790>`_)
* add more convertToString for integers
* warn about overwritten enums
* fix ambiguous to_json
* Extend unit test for blackboard backup to run the second tree (`#789 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/789>`_)
* json conversion changed and
* issue `#755 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/755>`_ : add backchaining test and change reactive nodes checks (`#770 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/770>`_)
* Update switch_node.h
* test moved and port remapping fixed
* Create pull_request_template.md

* adding pre-commit
* handle enums conversions is assignment
* Contributors: Davide Faconti, Sean Geles, Sebastian Castro, Victor Massagué Respall, avikus-seonghyeon.kwon, tony-p

4.5.2 (2024-03-07)
------------------
* bugfix: string to enum/integer/boolean in scripts
* bug fix in scripting comparison
* added more pretty-prints to demangler
* fixes and checks in default values, based on PR `#773 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/773>`_
* Initialize std::atomic_bool (`#772 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/772>`_)
* Fix issue `#767 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/767>`_ and `#768 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/768>`_
* updated default port syntax: "{=}"
* new default port capability: blackbard entries
* fix issue `#757 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/757>`_ : skipped nodes should not call post-condition ALWAYS
* Merge pull request `#756 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/756>`_ from imere/imere-patch-1
* fix(test): Typo in gtest_blackboard.cpp
* Contributors: Davide Faconti, Lu Z, Marq Rasmussen

4.5.1 (2024-01-23)
------------------
* Support enums and real numbers in Node Switch
* improve Any::castPtr and add example
* fix issue `#748 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/748>`_ : static error messages
* Merge pull request `#746 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/746>`_ from galou/snprintf
  Use snprintf instead of sprintf
* Use snprintf instead of sprintf
  - Augment the buffer size on doc error.
  - Let sprintf in switch_node.h since the max. string length is known.
* Contributors: Davide Faconti, Gaël Écorchard

4.5.0 (2024-01-10)
------------------
* fix typo in unit test `#733 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/733>`_
* allow Input/Output ports with type Any
* Merge pull request `#703 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/703>`_ from galou/export_xsd
  Implement writeTreeXSD() to generate an XSD
* Any::isType() will return the original type. Cherry picking from `#708 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/708>`_
* fix `#734 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/734>`_
* remove unneeded includes
* add Any::castPtr
* add alias KeyValueVector
* Merge pull request `#730 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/730>`_ from adlarkin/add_metadata
  Add optional metadata to TreeNodeManifest
* Contributors: Ashton Larkin, Davide Faconti, Gaël Écorchard

4.4.3 (2023-12-19)
------------------
* Merge pull request #709 from galou/unset_blackboard
* fix issue `#725 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/725>`_ : SetBlackboard can copy entries
* add more unit tests
* fix typos `#721 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/721>`_
* fix: guard macro declaration to prevent redefinition warning
* fix: Rename scoped lock so it doesn't hide the outer lock triggering a compiler warning
* add private ports to exclude from autoremapping `#706 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/706>`_
* fix issue `#713 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/713>`_:  getNodesByPath should be const
* Contributors: Davide Faconti, Nestor Gonzalez, Tony Paulussen

4.4.2 (2023-11-28)
------------------
* fix issue `#702 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/702>`_ : output ports require {}
* Merge pull request `#691 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/691>`_ from galou/small_refactor_and_doc
  Small code refactor, log- and doc changes
* Merge pull request `#701 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/701>`_ from tony-p/fix/file-loggers-protected
  fix: ensure public get config overload is used
* ci: use pixi github action
* fix: ensure public get config overload is used
* Small code refactor, log- and doc changes
* Contributors: Davide Faconti, Gaël Écorchard, Tony Paulussen

4.4.1 (2023-11-12)
------------------
* erase server_port+1
* add reset by default in base classes (fix `#694 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/694>`_)
* fix issue `#696 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/696>`_ (wrong autoremapping)
* Remove traces of SequenceStar
* fix `#685 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/685>`_ (timeout in ZMP publisher)
* clang: fix warning
  fix warning: lambda capture 'this' is not used
* Use feature test macro to check availability of `std::from_chars`
* fix warning in older compilers
* Contributors: Christoph Hertzberg, Davide Faconti, Gaël Écorchard, Shen Xingjian, Sid

4.4.0 (2023-10-16)
------------------
* Update ex05_subtree_model.cpp
* added any::stringToNumber
* added SubTree model example
* unit test for issue 660
* adding SubTree model
* minor changes
* change blackboard entry
* Update simple_string.hpp
* SimpleString: fix warning by checking upper size limit (`#666 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/666>`_)
* Contributors: Adam Boseley, Davide Faconti

4.3.8 (2023-10-09)
------------------
* ReactiveSequence and ReactiveFallback will behave more similarly to 3.8
* bug fix in wakeUpSignal
* ignore newlines in script
* stop ordering ports in TreeNodesModel
* add a specific tutorial for plugins
* Contributors: Davide Faconti

4.3.7 (2023-09-12)
------------------
* Test and fix issue `#653 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/653>`_: AnyTypeAllowed by default
* more time margin for Windows tests
* Add support for successful conda builds (`#650 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/650>`_)
* fix: Update how unit tests are executed in the github workflow so they are actually run on windows (`#647 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/647>`_)
* Add unit test related to SequenceWithMemory `#636 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/636>`_
* Contributors: Davide Faconti, tony-p

4.3.6 (2023-08-31)
------------------
* Simplify the visualization of custom type in Groot2 and improved tutorial 12
* fix compilation warnings
* Apply changes in ReactiveSequence to ReactiveFallback too
* test that logging works correctly with ReactiveSequence `#643 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/643>`_
* reduce the number of times preconditions scripts are executed
* PauseWithRetry test added
* Contributors: Davide Faconti

4.3.5 (2023-08-14)
------------------
* fix issue `#621 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/621>`_: ConsumeQueue
* feat: add template specialization for convertFromString deque (`#628 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/628>`_)
* unit test added
* Update groot2_publisher.h (`#630 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/630>`_)
* unit test issue `#629 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/629>`_
* WhileDoElseNode can have 2 or 3 children (`#625 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/625>`_)
* fix issue `#624 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/624>`_ : add TimeoutNode::halt()
* fix recording_fist_time issue on windows (`#618 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/618>`_)
* Contributors: Aglargil, Davide Faconti, Michael Terzer, benyamin saedi, muritane

4.3.4 (2023-07-25)
------------------
* Fix error #617 in TestNode
* minitrace updated
* fix issue #615 : don't execute preconditions if state is RUNNING
* README.md
* fix issue `#605 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/605>`_: strip whitespaces and better error message
* Export cxx-standard with target. (`#604 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/604>`_)
* feature `#603 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/603>`_: add static method [std::string description()] to manifest
* fix issue with move semantic
* Contributors: Davide Faconti, Sebastian Kasperski

4.3.3 (2023-07-05)
------------------
* bug fix `#601 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/601>`_: onHalted not called correctly in Control Nodes
* Groot recording (`#598 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/598>`_)
  * add recording to groot publisher
  * fixed
  * protocols compatibility
  * reply with first timestamp
  * remove prints
* Fix error when building static library (`#599 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/599>`_)
* fix warnings
* 4.3.2
* prepare release
* fix `#595 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/595>`_ : improvement in blackboard/scripting types (`#597 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/597>`_)
* Merge branch 'master' of github.com:BehaviorTree/BehaviorTree.CPP
* Merge branch 'parallel_all'
* Fix Issue 593 (`#594 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/594>`_): support skipping in Parallel node
* fix ParallelAll
* adding ParallelAll, WIP
* Contributors: Davide Faconti, Oleksandr Perepadia

4.3.2 (2023-06-27)
------------------
* fix `#595 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/595>`_ : improvement in blackboard/scripting types (`#597 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/597>`_)
* Fix Issue 593 (`#594 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/594>`_): support skipping in Parallel node
* adding ParallelAll
* Contributors: Davide Faconti

4.3.1 (2023-06-21)
------------------
* fix issue `#592 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/592>`_
* use lambda in tutorial
* add script condition
* "fix" issue `#587 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/587>`_: ReactiveSequence should set conditions to IDLE
* better error message
* Fix issue `#585 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/585>`_
* Contributors: Davide Faconti

4.3.0 (2023-06-13)
------------------
* use PImpl in multiple classes
* updated FileLogger2
* better error messages
* blackboard refactoring to fix buggy _autoremap
* improved support for default values
* fix error and add nodiscard
* Fix `#580 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/580>`_ : more informative error when not specializing BT::toStr
* add builtin models to WriteTreeToXML
* add simple example to generate logs
* add Sleep Node
* Fix `#271 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/271>`_: better error message
* remove EOL ros2 from CI
* Contributors: Davide Faconti

4.2.1 (2023-06-07)
------------------
* Fix `#570 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/570>`_: string_view set in blackboard
* Fix missing attribute in generated XML (writeTreeNodesModelXML)
* Allow registration of TestNode
* Contributors: Davide Faconti, Oleksandr Perepadia

4.2.0 (2023-05-23)
------------------
* add more informative IDLE status
* more informative error message when trying to register virtual classes
* fixes and simpler getAnyLocked
* add Tree::getNodesByPath
* add FileLogger2
* change getPortAny name and fic loop_node
* Lexy updated to release 2022.12.1
* do not skip pre-post condition in substituted tick
* added Loop node
* deprecating getAny
* revert new behavior of Sequence and Fallback
* add resetChild to all the decorators that missed it
* Add test related to issue `#539 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/539>`_
* related to `#555 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/555>`_
* Critical bug fix in XML exporting
* Fix writeTreeNodesModelXML
* fix ament not registering executables as tests
* fix std::system_error in TimeoutNode
* minor changes, mostly comments
* add version string
* old ZMQ publisher removed
* Add RunOnce, based on `#472 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/472>`_
* Contributors: Alberto Soragna, Davide Faconti, Gaël Écorchard, Mithun Kinarullathil, Sergei Molchanov

4.1.1 (2023-03-29)
------------------
* adding sqlite logger
* fix warning
* better cmake
* ManualSelector removed
* magic_enum updated
* fix issue `#530 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/530>`_: use convertFromString in scripting assignments
* added unit test
* files moved
* fix groot2 publisher
* minor fixes in blackboard
* fix XML: Subtree should remember the remapped ports
* add the ability to load substitution rules from JSON
* Update README.md
* Contributors: Davide Faconti

4.1.0 (2023-03-18)
------------------
* temporary disable codeql
* Groot2 interface (`#528 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/528>`_)
  * refactored groot2 interface
  * protocol updated
* merging groot2 publisher
* add observer
* prepare 4.1
* Update README.md
* fix issue `#525 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/525>`_ when ReactiveSequence contains skipped children
* fix reactive sequence (issue `#526 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/526>`_ and `#525 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/525>`_)
* better test
* add cast to ENUMS in ports
* changes ported from 4.1
* fix samples
* better include paths
* Control node and Decorators RUNNING before first child
* blackboard: update getKeys and add mutex to scripting
* add [[nodiscard]] and some other minor changes
* add screenshot
* change the behavior of tickOnce to actually loop is wake up signal is… (`#522 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/522>`_)
  * change the behavior of tickOnce to actually loop is wake up signal is received
  * fix warning
* Cmake conan (`#521 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/521>`_)
  * boost coroutine substituted with minicoro. 3rd party updates
  * cmake refactoring + conan
  * fix cmake
  * fix build with conan and change CI
* fix CI in ROS1 (`#519 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/519>`_)
* fix alloc-dealloc-mismatch for _storage.str.data (`#518 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/518>`_)
* Fix issue `#515 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/515>`_: reactive sequence not skipped correctly
* Fix issue `#517 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/517>`_
* Merge branch 'master' of github.com:BehaviorTree/BehaviorTree.CPP
* fix issue `#492 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/492>`_ (Threads::Threads)
* Fix boost dependency in package.xml (`#512 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/512>`_)
  `libboost-coroutine-dev` has been merged into rosdistro on February 21st
  2023. Link to merge request: https://github.com/ros/rosdistro/pull/35789/.
* fix compilation
* revert breaking change
* Merge branch 'master' of github.com:BehaviorTree/BehaviorTree.CPP
* make default value of port optional, to allow empty strings
* Contributors: Alberto Soragna, Bart Keulen, Davide Faconti

4.0.2 (2023-02-17)
------------------
* fix issue `#501 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/501>`_
* fix issue `#505 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/505>`_
* solve issue `#506 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/506>`_
* prevent useless exception catcking
* fix issue `#507 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/507>`_
* adding the uid to the log to uniquely identify the nodes (`#502 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/502>`_)
* fix in SharedLibrary and cosmetic changes to the code
* using tinyxml ErrorStr() instead of ErrorName() to get more info about missing file (`#497 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/497>`_)
* Fixed use of ros_pkg for ROS1 applications (`#483 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/483>`_)
* Fix error message StdCoutLogger -> MinitraceLogger (`#495 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/495>`_)
* Fix boost dependency in package.xml (`#493 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/493>`_)
  Co-authored-by: Bart Keulen <b.keulen@avular.com>
* support Enums in string conversion
* fix issue 489
* updated example. Demonstrate pass by reference
* lexy updated
* rename haltChildren to resetChildren
* revert `#329 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/329>`_
* Merge branch 'master' of github.com:BehaviorTree/BehaviorTree.CPP
* Small improvements (`#479 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/479>`_)
  * Make message for allowed port names more explicit
  Also throw an exception for unknown port direction rather than using
  `PortDirection::INOUT`.
  * Small code improvements
  * Remove code without effect
* Fix some renaming for V4 (`#480 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/480>`_)
* Define NodeConfiguration for BT3 compatibility (`#477 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/477>`_)
* Implement `#404 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/404>`_ to solve `#435 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/435>`_ (gtest not found)
* fix issue `#474 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/474>`_ Make libraries dependencies private
* fix issue `#413 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/413>`_ (Delay logic)
* change suggested in `#444 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/444>`_
* add XML converter
* Add CodeQL workflow (`#471 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/471>`_)
* Update README.md
* Contributors: Ana, Bart Keulen, Christian Henkel, Davide Faconti, Gaël Écorchard, Jorge, Mahmoud Farshbafdoustar, Norawit Nangsue

4.0.1 (2022-11-19)
------------------
* version 4.X
* Contributors: Adam Aposhian, Adam Sasine, Alberto Soragna, Ali Aydın KÜÇÜKÇÖLLÜ, AndyZe, Davide Faconti, Dennis, Gaël Écorchard, Jafar, Joseph Schornak, Luca Bonamini, Paul Bovbel, SubaruArai, Tim Clephas, Will

3.7.0 (2022-05-23)
-----------
* add netlify stuff
* Event based trigger introduced
  Added a new mechanism to emit "state changed" events that can "wake up" a tree.
  In short, it just provide an interruptible "sleep" function.
* Fixed bug where including relative paths would fail to find the correct file (`#358 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/358>`_)
  * Added unit tests to verify current behavior
  * Fixed bug where including relative paths would fail to find the correct file
  * Added gtest environment to access executable path
  This path lets tests access files relative to the executable for better transportability
  * Changed file commandto add_custom_target
  The file command only copies during the cmake configure step. If source files change, file is not ran again
* Added pure CMake action to PR checks (`#378 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/378>`_)
  * Added CMake CI to PR checks
  * Renamed action to follow pattern
* updated documentation
* add the ability to register multiple BTs (`#373 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/373>`_)
* Update ros1.yaml
* fix `#338 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/338>`_
* fix issue `#330 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/330>`_
* fix issue `#360 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/360>`_
* Merge branch 'master' of github.com:BehaviorTree/BehaviorTree.CPP
* Update Tutorial 2 Docuemtation (`#372 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/372>`_)
* Update tutorial_09_coroutines.md (`#359 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/359>`_)
  Minor fix, renamed Timepoint to TimePoint.
* Export dependency on ament_index_cpp (`#362 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/362>`_)
  To make dependent packages try to link ament_index_cpp, export the
  dependency explicitly.
* Change order of lock to prevent deadlock. (`#368 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/368>`_)
  Resolves `#367 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/367>`_.
* Fix `#320 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/320>`_ : forbid references in Any
* Update action_node.h
* Contributors: Adam Sasine, Davide Faconti, Fabian Schurig, Griswald Brooks, Hyeongsik Min, Robodrome, imgbot[bot], panwauu

3.6.1 (2022-03-06)
------------------
* remove windows tests
* fix thread safety
* fix CI
* Don't restart SequenceStar on halt (`#329 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/329>`_)
  * Add more SequenceStar tests
  * Fix typo in test name
  * Don't reset SequenceStar on halt
* [docs] add missing node `SmashDoor` (`#342 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/342>`_)
* ROS2 include ros_pkg attribute support (`#351 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/351>`_)
  * ROS2 include pkg support
  * ros2 build fixed
  Co-authored-by: Benjamin Linne <benjamin.linne.civ@army.mil>
* [ImgBot] Optimize images (`#334 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/334>`_)
  *Total -- 90.34kb -> 61.77kb (31.63%)
  /docs/images/Tutorial1.svg -- 10.08kb -> 6.33kb (37.19%)
  /docs/images/FetchBeerFails.svg -- 9.00kb -> 5.93kb (34.13%)
  /docs/images/FetchBeer2.svg -- 21.19kb -> 14.41kb (32%)
  /docs/images/Tutorial2.svg -- 34.19kb -> 23.75kb (30.54%)
  /docs/images/DecoratorEnterRoom.svg -- 15.88kb -> 11.35kb (28.54%)
  Co-authored-by: ImgBotApp <ImgBotHelp@gmail.com>
* [Docs] BT_basics fix typo (`#343 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/343>`_)
* [docs] Clarify sentence (`#344 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/344>`_)
  `... will sleep up to 8 hours or less, if he/she is fully rested.` was not clear. It can also be understood as `If he/she is fully rested, the character will sleep ...`
* [docs] match text to graphics (`#340 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/340>`_)
* Docs: BT_basics fix typo (`#337 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/337>`_)
* Merge branch 'master' of github.com:BehaviorTree/BehaviorTree.CPP
* fix svg
* Fix CMake ENABLE_COROUTINES flag with Boost < 1.59 (`#335 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/335>`_)
  Co-authored-by: Cam Fulton <cfulton@symbotic.com>
* Add ENABLE_COROUTINES CMake option (`#316 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/316>`_)
  * Add DISABLE_COROUTINES CMake option
  * Change convention of CMake coroutine flag to ENABLE
  Co-authored-by: Cam Fulton <cfulton@symbotic.com>
* [ImgBot] Optimize images (`#333 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/333>`_)
  *Total -- 152.97kb -> 114.57kb (25.1%)
  /docs/images/ReactiveSequence.svg -- 7.58kb -> 4.59kb (39.47%)
  /docs/images/SequenceNode.svg -- 11.28kb -> 7.12kb (36.87%)
  /docs/images/SequenceStar.svg -- 11.22kb -> 7.09kb (36.8%)
  /docs/images/DecoratorEnterRoom.svg -- 20.71kb -> 13.30kb (35.77%)
  /docs/images/FallbackBasic.svg -- 19.09kb -> 12.64kb (33.79%)
  /docs/images/FetchBeer.svg -- 24.30kb -> 16.36kb (32.66%)
  /docs/images/SequenceBasic.svg -- 6.32kb -> 5.49kb (13.04%)
  /docs/images/Tutorial1.svg -- 6.67kb -> 5.94kb (10.98%)
  /docs/images/FetchBeerFails.svg -- 6.46kb -> 5.83kb (9.76%)
  /docs/images/FetchBeer2.svg -- 14.99kb -> 13.76kb (8.18%)
  /docs/images/Tutorial2.svg -- 24.35kb -> 22.44kb (7.85%)
  Co-authored-by: ImgBotApp <ImgBotHelp@gmail.com>
* doc fix
* Merge branch 'new_doc'
* remove deprecated code
* updated documentation
* [Fix] Fix cmake version warning and -Wformat warning (`#319 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/319>`_)
  Co-authored-by: Homalozoa <xuhaiwang@xiaomi.com>
* Update README.md
* Fix Windows shared lib build (`#323 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/323>`_)
* fix shadowed variable in string_view.hpp (`#327 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/327>`_)
* Build Sample Nodes By Default to Fix Github Action (`#332 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/332>`_)
  * Fix github action
  * Change working directory in github action step
  * Build samples by default
* Added BlackboardCheckBool decorator node (`#326 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/326>`_)
  * Added tests for BlackboardCheck decorator node
  * Added BlackboardCheckBool decorator node
* Fixed typo "Exeption" -> "Exception" (`#331 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/331>`_)
* WIP
* fix `#325 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/325>`_
* Contributors: Adam Sasine, Affonso, Guilherme, Alberto Soragna, Davide Faconti, Homalozoa X, Jake Keller, Philippe Couvignou, Tobias Fischer, benjinne, fultoncjb, goekce, imgbot[bot]

3.6.0 (2021-11-10)
------------------
* Build samples independently of examples (`#315 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/315>`_)
* Fix dependency in package.xml (`#313 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/313>`_)
* Fix doc statement (`#309 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/309>`_)
  Fix sentence
* Fix references to RetryUntilSuccesful (`#308 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/308>`_)
  * Fix github action
  * Fix references to RetryUntilSuccesful
* added subclass RetryNodeTypo (`#295 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/295>`_)
  Co-authored-by: Subaru Arai <SubaruArai@local>
* Fix github action (`#302 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/302>`_)
* Minor spelling correction (`#305 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/305>`_)
  Corrected `the_aswer` to `the_answer`
* Update FallbackNode.md (`#306 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/306>`_)
  typo correction.
* Add signal handler for Windows (`#307 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/307>`_)
* fix
* file renamed and documentation fixed
* Update documentation for reactive sequence (`#286 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/286>`_)
* Update FallbackNode.md (`#287 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/287>`_)
  Fix the pseudocode in the documentation of 'Reactive Fallback' according to its source code.
* Update fallback documentation to V3 (`#288 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/288>`_)
  * Update FallbackNode.md description to V3
  * Fix typo
* Use pedantic for non MSVC builds (`#289 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/289>`_)
* Merge branch 'master' of https://github.com/BehaviorTree/BehaviorTree.CPP
* updated to latest flatbuffers
* Update README.md
* Fix issue `#273 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/273>`_
* remove potential crash when an unfinished tree throws an exception
* remove appveyor
* Merge branch 'git_actions'
* Fixes for compilation on windows. (`#248 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/248>`_)
  * Fix for detecting ZeroMQ on windows
  Naming convention is a bit different for ZeroMQ, specifically on Windows with vcpkg. While ZMQ and ZeroMQ are valid on linux, the ZMQ naming convention only works on linux.
  * Compilation on windows not working with /WX
  * Macro collision on Windows
  On windows, the macros defined in the abstract logger collides with other in windows.h. Made them lowercase to avoid collision
* Remove native support for Conan (`#280 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/280>`_)
* add github workflow
* Registered missing dummy nodes for examples (`#275 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/275>`_)
  * Added CheckTemperature dummy node
  * Added SayHello dummy node
* add zmq.hpp in 3rdparty dirfectory
* add test
* fix some warnings
* Fix bug on halt of delay node (`#272 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/272>`_)
  - When DelayNode is halted and ticked again, it always returned FAILURE since the state of DelayNode was not properly reset.
  - This commit fixes unexpected behavior of DelayNode when it is halted.
  Co-authored-by: Jinwoo Choi <jinwoos.choi@samsung.com>
* Clear all of blackboard's content (`#269 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/269>`_)
* Added printTreeRecursively overload with ostream parameter (`#264 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/264>`_)
  * Added overload to printTreeRecursively
  * Changed include to iosfwd
  * Added test to verify function writes to stream
  * Added call to overload without stream parameter
  * Fixed conversion error
  * Removed overload in favor of default argument
* Fix typo (`#260 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/260>`_)
  Co-authored-by: Francesco Vigni <francesco.vigni@sttech.de>
* Update README.md
* abstract_logger.h: fixed a typo (`#257 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/257>`_)
* Contributors: Adam Sasine, Affonso, Guilherme, Akash, Billy, Cong Liu, Daisuke Nishimatsu, Davide Faconti, Francesco Vigni, Heben, Jake Keller, Per-Arne Andersen, Ross Weir, Steve Macenski, SubaruArai, Taehyeon, Uilian Ries, Yadu, Yuwei Liang, matthews-jca, swarajpeppermint

3.5.6 (2021-02-03)
------------------
* fix issue `#227 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/227>`_
* fix issue `#256 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/256>`_
* Merge branch 'master' of https://github.com/BehaviorTree/BehaviorTree.CPP
* fix issue `#250 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/250>`_
* Fixed typos on SequenceNode.md (`#254 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/254>`_)
* Contributors: Davide Faconti, LucasNolasco

3.5.5 (2021-01-27)
------------------
* fix issue `#251 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/251>`_
* Contributors: Davide Faconti

3.5.4 (2020-12-10)
------------------
* Update bt_factory.cpp (`#245 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/245>`_)
* Use the latest version of zmq.hpp
* Improved switching BTs with active Groot monitoring (ZMQ logger destruction) (`#244 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/244>`_)
  * Skip 100ms (max) wait for detached thread
  * add {} to single line if statements
* Update retry_node.cpp
* fix
* fix issue `#230 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/230>`_
* Contributors: Davide Faconti, Florian Gramß, amangiat88

3.5.3 (2020-09-10)
------------------
* fix issue `#228 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/228>`_ . Retry and Repeat node need to halt the child
* better tutorial
* Contributors: Davide Faconti

3.5.2 (2020-09-02)
------------------
* fix warning and follow coding standard
* docs: Small changes to tutorial 02 (`#225 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/225>`_)
  Co-authored-by: Valerio Magnago <valerio.magnago@fraunhofer.it>
* Merge branch 'master' of https://github.com/BehaviorTree/BehaviorTree.CPP
* tutorial 1 fixed
* decreasing warning level to fix issue `#220 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/220>`_
* fix compilation
* Allow BT factory to define clock source for TimerQueue/TimerNode (`#215 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/215>`_)
  * Allow BT factory to define clock source for TimerQueue/TimerNode
  * Fix unit tests
  Co-authored-by: Cam Fulton <cfulton@symbotic.com>
  Co-authored-by: Davide Faconti <davide.faconti@gmail.com>
* Added delay node and wait for enter keypress node (`#182 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/182>`_)
  * Added delay node and wait for enter press node
  * Fixed unsigned int to int conversion bug
  * Added a new timer to keep a track of delay timeout and return RUNNING in the meanwhile
  * Removed wait for keypress node
  * Review changes suggested by gramss
  Co-authored-by: Indraneel Patil <indraneel.p@greyorange.com>
* Update SequenceNode.md (`#211 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/211>`_)
* add failure threshold to parallel node with tests (`#216 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/216>`_)
* Update tutorial_05_subtrees.md
  I believe that the API has been updated. Reflecting the same in this tutorial.
* Contributors: Aayush Naik, Davide Faconti, Indraneel Patil, Renan Salles, Valerio Magnago, Wuqiqi123, fultoncjb

3.5.1 (2020-06-11)
------------------
* trying to fix compilation in eloquent  Minor fix on line 19
* Update README.md
* more badges
* readme updated
* fix ros2 compilation?
* move to github actions
* replace dot by zero in boost version (`#197 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/197>`_)
* Always use std::string_view for binary compatibility (fix issue `#200 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/200>`_)
* Adding ForceRunningNode Decorator (`#192 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/192>`_)
* updated doc
* Add XML parsing support for custom Control Nodes (`#194 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/194>`_)
* Fix typo
* [Windows] Compare `std::type_info` objects to check type. (`#181 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/181>`_)
* Fix pseudocode for ReactiveFallback. (`#191 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/191>`_)
* Contributors: Aayush Naik, Darío Hereñú, Davide Faconti, Francisco Martín Rico, G.Doisy, Sarathkrishnan Ramesh, Sean Yen, Ting Chang

3.5.0 (2020-05-14)
------------------
* added IfThenElse and  WhileDoElse
* issue `#190 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/190>`_
* unit test added
* reverting to a better solution
* RemappedSubTree added
* Fix issue `#188 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/188>`_
* added function const std::string& key (issue `#183 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/183>`_)
* Contributors: Davide Faconti, daf@blue-ocean-robotics.com

* added IfThenElse and  WhileDoElse
* issue `#190 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/190>`_
* unit test added
* reverting to a better solution
* RemappedSubTree added
* Fix issue `#188 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/188>`_
* added function const std::string& key (issue `#183 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/183>`_)
* Contributors: Davide Faconti, daf@blue-ocean-robotics.com

3.1.1 (2019-11-10)
------------------
* fix samples compilation (hopefully)
* Contributors: Davide Faconti

3.1.0 (2019-10-30)
------------------
* Error message corrected
* fix windows and mingw compilation (?)
* Merge pull request `#70 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/70>`_ from Masadow/patch-3
  Added 32bits compilation configuration for msvc
* make Tree non copyable
* fix `#114 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/114>`_
* Merge branch 'master' of https://github.com/BehaviorTree/BehaviorTree.CPP
* critical bug fix affecting AsyncActionNode
  When a Tree is copied, all the thread related to AsyncActionNode where
  invoked.
  As a consequence, they are never executed, despite the fact that the
  value RUNNING is returned.
* Fix issue `#109 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/109>`_
* fix `#111 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/111>`_
* Merge pull request `#108 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/108>`_ from daniel-serrano/add-RobMoSys-acknowledgement
  Add robmosys acknowledgement
* Add robomosys acknowledgement as requested
* Add robomosys acknowledgement as requested
* added more comments (issue `#102 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/102>`_)
* Update README.md
* Add files via upload
* Merge pull request `#96 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/96>`_ from LoyVanBeek/patch-1
  Fix typo
* Update tutorial_04_sequence_star.md
* fix compilation
* removing backward_cpp
  Motivation: backward_cpp is SUPER useful, but it is a library to use at
  the application level. It makes no sense to add it at the library level.
* Merge pull request `#95 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/95>`_ from LoyVanBeek/patch-1
  Remove 0 in front of http://... URL to publication
* Remove 0 in front of http://... URL to publication
  Hopefully, this makes the link correctly click-able when rendered to HTML
* fix issue `#84 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/84>`_ (Directories)
* add infinite loop to Repeat and Retry (issue `#80 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/80>`_)
* fix unit test
* issue `#82 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/82>`_
* fix issue `#82 <https://github.com/BehaviorTree/BehaviorTree.CPP/issues/82>`_
* Added 32bits compilation configuration for msvc
* Contributors: Daniel Serrano, Davide Facont, Davide Faconti, Jimmy Delas, Loy

3.0.7 (2019-04-02)
------------------
* this should fix issue with tinyXML2 once and for all (maybe...)
* improvement #79
* doc fix
* Deprecating <remap> tag in SubTree
* fix windows compilation
* Update README.md
* back to c++11
* Contributors: Davide Faconti, Ferran Roure

3.0.4 (2019-03-19)
------------------
* fix issue #72 with sibling subtrees
* Update .travis.yml
* Contributors: Davide Faconti

3.0.3 (2019-03-12)
------------------
* moving to C++14... deal with it
* updated tinyXML2. Should fix several issues too
* add "d" to debug library on Windows
* fixed compilation error on Windows x64 (issue #63)
* Improved MSVC compilation
  Added _CRT_SECURE_NO_WARNINGS flag for msvc compilation
* adding TreeNode::modifyPortsRemapping that might be useful in the future
* Merge pull request #64 from luminize/patch-1
  docs/xml_format.md
* Merge pull request #65 from luminize/patch-2
  docs/tutorial_01_first_tree.md: fix typo
* docs/tutorial_01_first_tree.md: fix typo
* fix compilation in Windows/Release
* remove a warning in Windows
* Update README.md
* Merge branch 'windows_compilation'
* fix issue #63 : compile on windows
* Update .travis.yml
* Create .appveyor.yml
* fix compilation on windows
* fix potential issue
* bug fix
* Update README.md
* Contributors: Bas de Bruijn,  Davide Faconti, Jimmy Delas, hlzl

3.0.2 (2019-03-04)
------------------
* make flatbuffers visible to other project (such as Groot)
* docs fix
* Contributors: Davide Faconti

3.0.0 (2019-02-27)
------------------
* Merge branch 'ver_3'. Too many changes to count...
* Contributors: Davide Facont, Davide Faconti, ImgBotApp, Victor Lopez

2.5.1 (2019-01-14)
------------------
* fix installation directory
* #39 Fix Conan version (#42)
  Signed-off-by: Uilian Ries <uilianries@gmail.com>
* Update .travis.yml
* Conan package distribution (#39)
* Non-functional refactoring of xml_parsing to clean up the code
* cosmetic changes in the code of BehaviorTreeFactory
* XML schema. Related to enhancement #40
* call setRegistrationName() for built-in Nodes
  The method is called by BehaviorTreefactory, therefore it
  registrationName is empty if trees are created programmatically.
* Reset reference count when destroying logger (issue #38)
* Contributors: Davide Facont, Davide Faconti, Uilian Ries

2.5.0 (2018-12-12)
------------------
* Introducing SyncActionNode that is more self explaining and less ambiguous
* fix potential problem related to ControlNode::haltChildren()
* Adding example/test of navigation and recovery behavior. Related to issue #36
* Contributors: Davide Faconti

2.4.4 (2018-12-12)
------------------
* adding virtual TreeNode::onInit() [issue #33]
* fix issue #34 : if you don't implement convertFromString, it will compile but it may throw
* Pretty demangled names and obsolete comments removed
* bug fixes
* more comments
* [enhancement #32]: add CoroActionNode and rename ActionNode as "AsynActionNode"
  The name ActionNode was confusing and it has been deprecated.
* Update README.md
* removed old file
* Fix issue #31 : convertFromString mandatory for TreeNode::getParam, not Blackboard::get
* Cherry piking changes from PR #19 which solve issue #2 CONAN support
* Contributors: Davide Faconti

2.4.3 (2018-12-07)
------------------
* Merge branch 'master' into ros2
* removed old file
* Fix issue #31 : convertFromString mandatory for TreeNode::getParam, not Blackboard::get
* 2.4.3
* version bump
* Merge pull request #30 from nuclearsandwich/patch-1
  Fix typo in package name.
* Remove extra find_package(ament_cmake_gtest).
  This package should only be needed if BUILD_TESTING is on and is
  find_package'd below if ament_cmake is found and BUILD_TESTING is on.
* Fix typo in package name.
* added video to readme
* Cherry piking changes from PR #19 which solve issue #2 CONAN support
* Merge pull request #29 from nuclearsandwich/ament-gtest-dep
  Add test dependency on ament_cmake_gtest.
* Add test dependency on ament_cmake_gtest.
* fix travis removing CI
* Contributors: Davide Faconti, Steven! Ragnarök

2.4.2 (2018-12-05)
------------------
* support ament
* change to ament
* Contributors: Davide Faconti

2.4.1 (2018-12-05)
------------------
* fix warnings and dependencies in ROS, mainly related to ZMQ
* Contributors: Davide Faconti

2.4.0 (2018-12-05)
------------------
* Merge pull request #27 from mjeronimo/bt-12-4-2018
  Add support for ament/colcon build
* updated documentation
* Merge pull request #25 from BehaviorTree/include_xml
  Add the ability to include an XML from another one
* <include> supports ROS package getPath (issue #17)
* Trying to fix writeXML (issue #24)
* New feature: include XMl from other XMLs (issue #17)
* more verbose error message
* adding unit tests for Repeat and Retry nodes #23
* Bug fix in Retry and Repeat Decorators (needs unit test)
* Throw if the parameter in blackboard can't be read
* Try to prevent error #22 in user code
* changed the protocol of the XML
* fixing issue #22
* Contributors: Davide Faconti, Michael Jeronimo

2.3.0 (2018-11-28)
------------------
* Fix: registerBuilder did not register the manifest. It was "broken" as public API method
* Use the Pimpl idiom to hide zmq from the header file
* move header of minitrace in the cpp file
* Fixed a crash occurring when you didn't initialized a Tree object (#20)
* Fix issue #16
* add ParallelNode to pre-registered entries in factory (issue #13)
* removed M_PI
* Update the documentation
* Contributors: Davide Faconti, Jimmy Delas

2.2.0 (2018-11-20)
------------------
* fix typo
* method contains() added to BlackBoard
* back compatible API change to improve the wrapping of legacy code (issue #15)
  Eventually, SimpleAction, SimpleDecorators and SimpleCondition can use
  blackboard and NodeParameters too.
* reduce potential memory allocations using string_view
* fix important issue with SubtreeNode
* Read at every tick the parameter if Blackboard is used
* Adding NodeParameters to ParallelNode
* travis update
* merge pull request #14 related to #10 (with some minor changes)
* Fix issue #8 and warning reported in #4
  Fixed problem of visibility with TinyXML2
* Contributors: Davide Faconti, Uilian Ries

2.1.0 (2018-11-16)
------------------
* version 2.1. New directory structure
* Contributors: Davide Faconti
