![License MIT](https://img.shields.io/github/license/BehaviorTree/BehaviorTree.CPP?color=blue)
[![conan Ubuntu](https://github.com/BehaviorTree/BehaviorTree.CPP/actions/workflows/cmake_ubuntu.yml/badge.svg)](https://github.com/BehaviorTree/BehaviorTree.CPP/actions/workflows/cmake_ubuntu.yml)
[![conan Windows](https://github.com/BehaviorTree/BehaviorTree.CPP/actions/workflows/cmake_windows.yml/badge.svg)](https://github.com/BehaviorTree/BehaviorTree.CPP/actions/workflows/cmake_windows.yml)
[![ros2](https://github.com/BehaviorTree/BehaviorTree.CPP/actions/workflows/ros2.yaml/badge.svg)](https://github.com/BehaviorTree/BehaviorTree.CPP/actions/workflows/ros2.yaml)
[![pixi (Conda)](https://github.com/BehaviorTree/BehaviorTree.CPP/actions/workflows/pixi.yaml/badge.svg)](https://github.com/BehaviorTree/BehaviorTree.CPP/actions/workflows/pixi.yaml)
[![Coverage Status](https://coveralls.io/repos/github/BehaviorTree/BehaviorTree.CPP/badge.svg?branch=master)](https://coveralls.io/github/BehaviorTree/BehaviorTree.CPP?branch=master)

# BehaviorTree.CPP 4.9

<p align="center"><img width=350 src="animated.svg"></p>

This  __C++ 17__ library provides a framework to create BehaviorTrees.
It was designed to be flexible, easy to use, reactive and fast.

Even if our main use-case is __robotics__, you can use this library to build
__AI for games__, or to replace Finite State Machines.

There are a few features that make __BehaviorTree.CPP__ unique, when compared to other implementations:

- It makes __asynchronous Actions__, i.e. non-blocking, a first-class citizen.

- You can build __reactive__ behaviors that execute multiple Actions concurrently (orthogonality).

- Trees are defined using a Domain Specific __scripting language__ (based on XML), and can be loaded at run-time; in other words, even if written in C++, the morphology of the Trees is _not_ hard-coded.

- You can statically link your custom TreeNodes or convert them into __plugins__
and load them at run-time.

- It provides a type-safe and flexible mechanism to do __Dataflow__ between
  Nodes of the Tree.

- It includes a __logging/profiling__ infrastructure that allows the user
to visualize, record, replay, and analyze state transitions.

## Documentation

- **Tutorials and general documentation**: https://www.behaviortree.dev/
- **Auto-generated Doxygen**: https://behaviortree.github.io/BehaviorTree.CPP/
- **Community support and forum**: https://github.com/BehaviorTree/BehaviorTree.CPP/discussions

# GUI Editor

Editing a BehaviorTree is as simple as editing an XML file in your favorite text editor.

If you are looking for a fancier graphical user interface (and I know you do) check
[Groot2](https://www.behaviortree.dev/groot) out.

![Groot screenshot](docs/groot-screenshot.png)

# How to compile

**BT.CPP** requires a compiler that supports C++17.

Three build systems are supported:

- **colcon (ament)**, if you use ROS2
- **conan** otherwise (Linux/Windows).
- **straight cmake** if you want to be personally responsible for dependencies :)

Compiling with [conan](https://conan.io/):

> [!NOTE]
> Conan builds require CMake 3.23 or newer.

Assuming that you are in the **root** directory of `BehaviorTree.CPP`:

```
conan install . -s build_type=Release --build=missing
cmake --preset conan-release
cmake --build --preset conan-release
```

If you have dependencies such as ZeroMQ and SQlite already installed and you don't want to
use conan, simply type:

```
mkdir build_release
cmake -S . -B build_release
cmake --build build_release --parallel
```

If you want to build in a [pixi](https://pixi.sh/) project (conda virtual environment).
```
pixi run build
```

If you want to use BT.CPP in your application, please refer to the
example here: https://github.com/BehaviorTree/btcpp_sample .

## Installing BehaviorTree.CPP (vcpkg)

Alternatively, you can build and install behaviortree-cpp using [vcpkg](https://github.com/Microsoft/vcpkg/) dependency manager:

    git clone https://github.com/Microsoft/vcpkg.git
    cd vcpkg
    ./bootstrap-vcpkg.sh
    ./vcpkg integrate install
    ./vcpkg install behaviortree-cpp

The behaviortree-cpp port in vcpkg is kept up to date by Microsoft team members and community contributors. If the version is out of date, please [create an issue or pull request](https://github.com/Microsoft/vcpkg) on the vcpkg repository.

#  Commercial support

Are you using BT.CPP in your commercial product, and do you need technical support / consulting?
You can contact the primary author, **dfaconti@aurynrobotics.com**, to discuss your use case and needs.

## Previous version

Version 3.8 of the software can be found in the branch
[v3.8](https://github.com/BehaviorTree/BehaviorTree.CPP/tree/v3.8).

That branch might receive bug fixes, but the new features will be implemented
only in the master branch.

# Star History

[![Star History Chart](https://api.star-history.com/svg?repos=BehaviorTree/BehaviorTree.CPP&type=Date)](https://star-history.com/#BehaviorTree/BehaviorTree.CPP&Date)

# Contributors

<a href="https://github.com/BehaviorTree/BehaviorTree.CPP/graphs/contributors">
  <img src="https://contrib.rocks/image?repo=BehaviorTree/BehaviorTree.CPP" />
</a>

# License

The MIT License (MIT)

Copyright (c) 2019-2026 Davide Faconti

Copyright (c) 2018-2019 Davide Faconti, Eurecat

Copyright (c) 2014-2018 Michele Colledanchise

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
