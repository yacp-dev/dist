#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "jsonfortran-gnu::jsonfortran" for configuration "RelWithDebInfo"
set_property(TARGET jsonfortran-gnu::jsonfortran APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(jsonfortran-gnu::jsonfortran PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libjsonfortran.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygjsonfortran-9.3.dll"
  )

list(APPEND _cmake_import_check_targets jsonfortran-gnu::jsonfortran )
list(APPEND _cmake_import_check_files_for_jsonfortran-gnu::jsonfortran "${_IMPORT_PREFIX}/lib/libjsonfortran.dll.a" "${_IMPORT_PREFIX}/bin/cygjsonfortran-9.3.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
