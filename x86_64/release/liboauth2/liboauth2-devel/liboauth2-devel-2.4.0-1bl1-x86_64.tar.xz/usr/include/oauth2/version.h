#ifndef _OAUTH2_VERSION_H_
#define _OAUTH2_VERSION_H_

/* include/oauth2/version.h  Generated from version.h.in by autoheader.  */

/***************************************************************************
 *
 * Copyright (C) 2018-2026 - ZmartZone Holding BV
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * @Author: Hans Zandbelt - hans.zandbelt@openidc.com
 *
 **************************************************************************/

/**
 * @file version.h
 * @brief Library name and version.
 *
 * Generated from version.h.in at configure time from the version in
 * configure.ac; the functions return the same values as the macros,
 * but for the library that is actually loaded rather than the headers
 * that a consumer was compiled against.
 */

/** @brief The package name, "liboauth2". */
#define OAUTH2_PACKAGE_NAME          "liboauth2"
/** @brief The package version, e.g. "2.1.0". */
#define OAUTH2_PACKAGE_VERSION       "2.4.0"

/** @brief The version of the library, as OAUTH2_PACKAGE_VERSION. */
const char *oauth2_version();

/**
 * @brief The library name and version joined with a dash, e.g.
 *        "liboauth2-2.1.0".
 */
const char *oauth2_package_string();

#endif  // _OAUTH2_VERSION_H_
