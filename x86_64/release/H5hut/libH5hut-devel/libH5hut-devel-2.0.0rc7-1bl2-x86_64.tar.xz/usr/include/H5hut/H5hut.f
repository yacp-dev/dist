         INTEGER*8, PARAMETER :: H5_O_RDWR =              Z'00000001'
         INTEGER*8, PARAMETER :: H5_O_RDONLY =            Z'00000002'
         INTEGER*8, PARAMETER :: H5_O_WRONLY =            Z'00000004'
         INTEGER*8, PARAMETER :: H5_O_APPEND =            Z'00000008'
         INTEGER*8, PARAMETER :: H5_VFD_MPIPOSIX =        Z'00000010'
         INTEGER*8, PARAMETER :: H5_VFD_MPIIO_IND =       Z'00000020'
         INTEGER*8, PARAMETER :: H5_VFD_MPIIO_COL =       Z'00000040'
         INTEGER*8, PARAMETER :: H5_VFD_CORE_IO =         Z'00000080'
         INTEGER*8, PARAMETER :: H5_PROP_DEFAULT =        0
         INTEGER*8, PARAMETER :: H5_STRING_T =            1
         INTEGER*8, PARAMETER :: H5_INT16_T =             2
         INTEGER*8, PARAMETER :: H5_INT32_T =             3
         INTEGER*8, PARAMETER :: H5_INT64_T =             4
         INTEGER*8, PARAMETER :: H5_FLOAT32_T =           5
         INTEGER*8, PARAMETER :: H5_FLOAT64_T =           6
         INTEGER*8, PARAMETER :: H5_MAX_NAME_LEN =        64
         INTEGER*8, PARAMETER :: H5_SUCCESS =             0
         INTEGER*8, PARAMETER :: H5_OK =                  H5_SUCCESS
         INTEGER*8, PARAMETER :: H5_NOK =                 -1
         INTEGER*8, PARAMETER :: H5_FAILURE =             -2
         INTEGER*8, PARAMETER :: H5_FAILED =              H5_FAILURE
         INTEGER*8, PARAMETER :: H5_ERR_BADF =            -9
         INTEGER*8, PARAMETER :: H5_ERR_NOMEM =           -12
         INTEGER*8, PARAMETER :: H5_ERR_INVAL =           -22
         INTEGER*8, PARAMETER :: H5_ERR_BADFD =           -77
         INTEGER*8, PARAMETER :: H5_ERR_LAYOUT =          -100
         INTEGER*8, PARAMETER :: H5_ERR_NOENTRY =         -101
         INTEGER*8, PARAMETER :: H5_ERR_MPI =             -201
         INTEGER*8, PARAMETER :: H5_ERR_HDF5 =            -202
         INTEGER*8, PARAMETER :: H5_ERR_H5 =              -203
         INTEGER*8, PARAMETER :: H5_ERR_H5PART =          -204
         INTEGER*8, PARAMETER :: H5_ERR_H5BLOCK =         -205
         INTEGER*8, PARAMETER :: H5_ERR_H5FED =           -206
         INTEGER*8, PARAMETER :: H5_ERR_INTERNAL =        -253
         INTEGER*8, PARAMETER :: H5_ERR_NOT_IMPLEMENTED = -254
         INTEGER*8, PARAMETER :: H5_VERBOSE_NONE =        0
         INTEGER*8, PARAMETER :: H5_VERBOSE_ERROR =       1
         INTEGER*8, PARAMETER :: H5_VERBOSE_WARN =        2
         INTEGER*8, PARAMETER :: H5_VERBOSE_INFO =        3
         INTEGER*8, PARAMETER :: H5_VERBOSE_DEFAULT =     H5_VERBOSE_ERROR
         INTEGER*8, PARAMETER :: H5_DEBUG_USER =          4
         INTEGER*8, PARAMETER :: H5_DEBUG_API =           8
         INTEGER*8, PARAMETER :: H5_DEBUG_CORE_API =      16
         INTEGER*8, PARAMETER :: H5_DEBUG_PRIV_API =      32
         INTEGER*8, PARAMETER :: H5_DEBUG_PRIV_FUNC =     64
         INTEGER*8, PARAMETER :: H5_DEBUG_HDF5 =          128
         INTEGER*8, PARAMETER :: H5_DEBUG_MPI =           256
         INTEGER*8, PARAMETER :: H5_DEBUG_MALLOC =        512
         INTEGER*8, PARAMETER :: H5_DEBUG_CLIB =          1024
         INTEGER*8, PARAMETER :: H5_DEBUG_ALL =           2048-4
       INTEGER*8 h5_createprop_file
       INTEGER*8 h5_setprop_file_mpio
       INTEGER*8 h5_setprop_file_mpio_collective
       INTEGER*8 h5_setprop_file_mpio_independent
       INTEGER*8 h5_setprop_file_mpio_posix
       INTEGER*8 h5_setprop_file_corevfd
       INTEGER*8 h5_setprop_file_align
       INTEGER*8 h5_setprop_file_throttle
       INTEGER*8 h5_closeprop
       INTEGER*8 h5_openfile
       INTEGER*8 h5_closefile
       INTEGER*8 h5_checkfile
       INTEGER*8 h5_flushfile
       INTEGER*8 h5_flushstep
       INTEGER*8 h5_finalize
       INTEGER*8 h5_setstep
       INTEGER*8 h5_getstep
       INTEGER*8 h5_getnsteps
       INTEGER*8 h5_getnfileattribs
       INTEGER*8 h5_getfileattribinfo
       INTEGER*8 h5_getfileattribinfo_by_name
       INTEGER*8 h5_writefileattrib_string
       INTEGER*8 h5_readfileattrib_string
       INTEGER*8 h5_writefileattrib_r8
       INTEGER*8 h5_readfileattrib_r8
       INTEGER*8 h5_writefileattrib_r4
       INTEGER*8 h5_readfileattrib_r4
       INTEGER*8 h5_writefileattrib_i8
       INTEGER*8 h5_readfileattrib_i8
       INTEGER*8 h5_writefileattrib_i4
       INTEGER*8 h5_readfileattrib_i4
       INTEGER*8 h5_getnstepattribs
       INTEGER*8 h5_getstepattribinfo
       INTEGER*8 h5_getstepattribinfo_by_name
       INTEGER*8 h5_writestepattrib_string
       INTEGER*8 h5_readstepattrib_string
       INTEGER*8 h5_writestepattrib_r8
       INTEGER*8 h5_readstepattrib_r8
       INTEGER*8 h5_writestepattrib_r4
       INTEGER*8 h5_readstepattrib_r4
       INTEGER*8 h5_writestepattrib_i8
       INTEGER*8 h5_readstepattrib_i8
       INTEGER*8 h5_writestepattrib_i4
       INTEGER*8 h5_readstepattrib_i4
       INTEGER*8 h5_get_error_number
       INTEGER*8 h5_get_verbosity_level
       INTEGER*8 h5_get_debug_mask
       INTEGER*8 h5pt_setnpoints
       INTEGER*8 h5pt_setnpoints_strided
       INTEGER*8 h5pt_setview
       INTEGER*8 h5pt_setview_indices
       INTEGER*8 h5pt_setcanonicalview
       INTEGER*8 h5pt_resetview
       INTEGER*8 h5pt_hasview
       INTEGER*8 h5pt_getview
       INTEGER*8 h5pt_getndatasets
       INTEGER*8 h5pt_getdatasetname
       INTEGER*8 h5pt_getdatasetinfo
       INTEGER*8 h5pt_getnpoints
       INTEGER*8 h5pt_writedata_r8
       INTEGER*8 h5pt_writedata_r4
       INTEGER*8 h5pt_writedata_i8
       INTEGER*8 h5pt_writedata_i4
       INTEGER*8 h5pt_readdata_r8
       INTEGER*8 h5pt_readdata_r4
       INTEGER*8 h5pt_readdata_i8
       INTEGER*8 h5pt_readdata_i4
       INTEGER*8 h5bl_3d_setview
       INTEGER*8 h5bl_3d_getview
       INTEGER*8 h5bl_3d_getreducedview
       INTEGER*8 h5bl_3d_hasview
       INTEGER*8 h5bl_3d_setchunk
       INTEGER*8 h5bl_getnumfields
       INTEGER*8 h5bl_getfieldinfo
       INTEGER*8 h5bl_getnfieldattribs
       INTEGER*8 h5bl_getfieldattribinfo
       INTEGER*8 h5bl_writefieldattrib_string
       INTEGER*8 h5bl_readfieldattrib_string
       INTEGER*8 h5bl_writefieldattrib_r8
       INTEGER*8 h5bl_readfieldattrib_r8
       INTEGER*8 h5bl_writefieldattrib_r4
       INTEGER*8 h5bl_readfieldattrib_r4
       INTEGER*8 h5bl_writefieldattrib_i8
       INTEGER*8 h5bl_readfieldattrib_i8
       INTEGER*8 h5bl_writefieldattrib_i4
       INTEGER*8 h5bl_readfieldattrib_i4
       INTEGER*8 h5bl_3d_get_field_origin
       INTEGER*8 h5bl_3d_set_field_origin
       INTEGER*8 h5bl_3d_get_field_spacing
       INTEGER*8 h5bl_3d_set_field_spacing
       INTEGER*8 h5bl_set_fieldxcoords
       INTEGER*8 h5bl_get_fieldxcoords
       INTEGER*8 h5bl_set_fieldycoords
       INTEGER*8 h5bl_get_fieldycoords
       INTEGER*8 h5bl_set_fieldzcoords
       INTEGER*8 h5bl_get_fieldzcoords
       INTEGER*8 h5bl_3d_write_scalar_field_r8
       INTEGER*8 h5bl_3d_read_scalar_field_r8
       INTEGER*8 h5bl_3d_write_vector3d_field_r8
       INTEGER*8 h5bl_3d_read_vector3d_field_r8
       INTEGER*8 h5bl_3d_write_scalar_field_r4
       INTEGER*8 h5bl_3d_read_scalar_field_r4
       INTEGER*8 h5bl_3d_write_vector3d_field_r4
       INTEGER*8 h5bl_3d_read_vector3d_field_r4
       INTEGER*8 h5bl_3d_write_scalar_field_i8
       INTEGER*8 h5bl_3d_read_scalar_field_i8
       INTEGER*8 h5bl_3d_write_vector3d_field_i8
       INTEGER*8 h5bl_3d_read_vector3d_field_i8
       INTEGER*8 h5bl_3d_write_scalar_field_i4
       INTEGER*8 h5bl_3d_read_scalar_field_i4
       INTEGER*8 h5bl_3d_write_vector3d_field_i4
       INTEGER*8 h5bl_3d_read_vector3d_field_i4
