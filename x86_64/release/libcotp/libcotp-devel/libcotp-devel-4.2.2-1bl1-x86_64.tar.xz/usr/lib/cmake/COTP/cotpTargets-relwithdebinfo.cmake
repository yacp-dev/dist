#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "COTP::cotp" for configuration "RelWithDebInfo"
set_property(TARGET COTP::cotp APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(COTP::cotp PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libcotp.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygcotp-4.dll"
  )

list(APPEND _cmake_import_check_targets COTP::cotp )
list(APPEND _cmake_import_check_files_for_COTP::cotp "${_IMPORT_PREFIX}/lib/libcotp.dll.a" "${_IMPORT_PREFIX}/bin/cygcotp-4.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
