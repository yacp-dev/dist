#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "sobjectizer::SharedLib" for configuration "RelWithDebInfo"
set_property(TARGET sobjectizer::SharedLib APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(sobjectizer::SharedLib PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libso.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygso-5.dll"
  )

list(APPEND _cmake_import_check_targets sobjectizer::SharedLib )
list(APPEND _cmake_import_check_files_for_sobjectizer::SharedLib "${_IMPORT_PREFIX}/lib/libso.dll.a" "${_IMPORT_PREFIX}/bin/cygso-5.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
