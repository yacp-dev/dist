/*
  CLAW - a C++ Library Absolutely Wonderful

  CLAW is a free library without any particular aim but being useful to 
  anyone.

  Copyright (C) 2005-2010 Julien Jorge

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

  contact: julien_jorge@yahoo.fr
*/
/**
 * \file version.hpp
 * \brief The version of the library.
 * \author Julien Jorge
 */
#ifndef __CLAW_VERSION_HPP__
#define __CLAW_VERSION_HPP__

#define CLAW_MAJOR_VERSION 1
#define CLAW_MINOR_VERSION 7
#define CLAW_RELEASE_NUMBER 4
#define CLAW_REVISION_NUMBER 0

#endif // __CLAW_VERSION_HPP__
