#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "libmemcached::libhashkit" for configuration "RelWithDebInfo"
set_property(TARGET libmemcached::libhashkit APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(libmemcached::libhashkit PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libhashkit.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cyghashkit-2.dll"
  )

list(APPEND _cmake_import_check_targets libmemcached::libhashkit )
list(APPEND _cmake_import_check_files_for_libmemcached::libhashkit "${_IMPORT_PREFIX}/lib/libhashkit.dll.a" "${_IMPORT_PREFIX}/bin/cyghashkit-2.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
