#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "libmemcached::libmemcached" for configuration "RelWithDebInfo"
set_property(TARGET libmemcached::libmemcached APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(libmemcached::libmemcached PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libmemcached.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygmemcached-11.dll"
  )

list(APPEND _cmake_import_check_targets libmemcached::libmemcached )
list(APPEND _cmake_import_check_files_for_libmemcached::libmemcached "${_IMPORT_PREFIX}/lib/libmemcached.dll.a" "${_IMPORT_PREFIX}/bin/cygmemcached-11.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
