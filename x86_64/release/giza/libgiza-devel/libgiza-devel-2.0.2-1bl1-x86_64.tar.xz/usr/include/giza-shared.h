/* giza - a scientific plotting library built on cairo
 *
 * Copyright (c) 2010      James Wetter and Daniel Price
 * Copyright (c) 2010-2022 Daniel Price
 *
 * This library is free software; and you are welcome to redistribute
 * it under the terms of the GNU Lesser General Public License
 * (LGPL, see COPYING.LESSER file for details) and the provision that
 * this notice remains intact. If you modify this file, please
 * note section 2 of the LGPLv3 states that:
 *
 *  a) The work must carry prominent notices stating that you modified
 *  it, and giving a relevant date.
 *
 * This software is distributed "AS IS", with ABSOLUTELY NO WARRANTY.
 * See the LGPL for specific language governing rights and limitations.
 */

#include "giza-version.h"

#define GIZA_LEFT_CLICK 'A'
#define GIZA_MIDDLE_CLICK 'D'
#define GIZA_RIGHT_CLICK 'X'
#define GIZA_SHIFT_CLICK 15
#define GIZA_SCROLL_UP 21
#define GIZA_SCROLL_DOWN 4
#define GIZA_SCROLL_LEFT 12
#define GIZA_SCROLL_RIGHT 18
#define GIZA_OTHER_CLICK 'X'

#define GIZA_LS_SOLID      1
#define GIZA_LS_SHORT_DASH 2
#define GIZA_LS_DASHED     2
#define GIZA_LS_LONG_DASH  3
#define GIZA_LS_DOT        4
#define GIZA_LS_DOTTED     4
#define GIZA_LS_DASH_DOT   5
#define GIZA_LS_DASH_DOT_DOT_DOT 6

#define GIZA_NUMBER_FORMAT_AUTO 0
#define GIZA_NUMBER_FORMAT_DEC  1
#define GIZA_NUMBER_FORMAT_EXP  2

#define GIZA_UNITS_NORMALIZED 0
#define GIZA_UNITS_NORMALISED 0
#define GIZA_UNITS_INCHES 1
#define GIZA_UNITS_MM 2
#define GIZA_UNITS_PIXELS 3
#define GIZA_UNITS_WORLD 4
#define GIZA_UNITS_DEVICE 5

#define GIZA_BAND_NONE 0
#define GIZA_BAND_LINE 1
#define GIZA_BAND_RECTANGLE 2
#define GIZA_BAND_HORZLINES 3
#define GIZA_BAND_VERTLINES 4
#define GIZA_BAND_HORZLINE 5
#define GIZA_BAND_VERTLINE 6
#define GIZA_BAND_CROSSHAIR 7
#define GIZA_BAND_CIRCLE 8

#define GIZA_BACKGROUND_COLOUR 0
#define GIZA_BACKGROUND_COLOR 0
#define GIZA_BACKGROUND 0
#define GIZA_FOREGROUND_COLOUR 1
#define GIZA_FOREGROUND_COLOR 1
#define GIZA_FOREGROUND 1

#define GIZA_COLOUR_INDEX_MIN 0
#define GIZA_COLOUR_INDEX_MAX 271

#define GIZA_COLOUR_PALETTE_DEFAULT 0
#define GIZA_COLOR_PALETTE_DEFAULT 0
#define GIZA_COLOUR_PALETTE_PGPLOT 1
#define GIZA_COLOR_PALETTE_PGPLOT 1

#define GIZA_FILL_SOLID  1
#define GIZA_FILL_HOLLOW 2
#define GIZA_FILL_HATCH 3
#define GIZA_FILL_CROSSHATCH 4

#define GIZA_MAX_FILL_STYLES 4

#define GIZA_EXTEND_NONE 0
#define GIZA_EXTEND_REPEAT 1
#define GIZA_EXTEND_REFLECT 2
#define GIZA_EXTEND_PAD 3

#define GIZA_FILTER_DEFAULT 0
#define GIZA_FILTER_FAST 1
#define GIZA_FILTER_GOOD 2
#define GIZA_FILTER_BEST 3
#define GIZA_FILTER_NEAREST 4
#define GIZA_FILTER_BILINEAR 5
#define GIZA_FILTER_GAUSSIAN 6