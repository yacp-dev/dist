!-----------------------------------------------------------------------
!  giza - a scientific plotting library built on cairo
!
!  Copyright (c) 2010      James Wetter and Daniel Price
!  Copyright (c) 2010-2022 Daniel Price
!
!  This library is free software; and you are welcome to redistribute
!  it under the terms of the GNU Lesser General Public License
!  (LGPL, see COPYING.LESSER file for details) and the provision that
!  this notice remains intact. If you modify this file, please
!  note section 2 of the LGPLv3 states that:
!
!   a) The work must carry prominent notices stating that you modified
!   it, and giving a relevant date.
!
!  This software is distributed "AS IS", with ABSOLUTELY NO WARRANTY.
!  See the LGPL for specific language governing rights and limitations.
!
!  The Original code is the giza plotting library.
!
!  Contributor(s):
!       James Wetter <wetter.j@gmail.com>
!       Daniel Price <daniel.price@monash.edu> (main contact)
!
!-----------------------------------------------------------------------
!---------------------------------------------------------
!  This file contains the Fortran interface to giza
!  (using the Fortran 2003 iso_c_binding module)
!---------------------------------------------------------

module giza
 use, intrinsic :: iso_c_binding, only:c_double,c_float,c_char,c_int
 implicit none
 public  :: &
      giza_plot, &
      giza_arrow, &
      giza_set_arrow_style, &
      giza_get_arrow_style, &
      giza_annotate, &
      giza_axis, &
      giza_band, &
      giza_box, &
      giza_box_time, &
      giza_begin_buffer, &
      giza_end_buffer, &
      giza_flush_buffer, &
      giza_circle, &
      giza_set_character_height, &
      giza_get_character_height, &
      giza_get_character_size, &
      giza_set_clipping, &
      giza_get_clipping, &
      giza_colour_bar, &
      giza_set_colour_index, &
      giza_get_colour_index, &
      giza_set_colour_index_range, &
      giza_get_colour_index_range, &
      giza_set_colour_palette, &
      giza_set_colour_representation, &
      giza_get_colour_representation, &
      giza_set_colour_representation_hls, &
      giza_set_colour_table, &
      giza_contour, &
      giza_contour_blanked, &
      giza_contour_fill, &
      giza_contour_labelled, &
      giza_get_current_point, &
      giza_rgb_from_table, &
      giza_print_device_list, &
      giza_open, &
      giza_open_device, &
      giza_open_device_size, &
      giza_get_device_id, &
      giza_select_device, &
      giza_flush_device, &
      giza_change_page, &
      giza_close_device, &
      giza_close, &
      giza_get_key_press, &
      giza_set_motion_callback, &
      giza_end_motion_callback, &
      giza_device_has_cursor, &
      giza_draw, &
      giza_draw_background, &
      giza_set_environment, &
      giza_error_bars, &
      giza_error_bars_x, &
      giza_error_bars_y, &
      giza_set_fill, &
      giza_get_fill, &
      giza_function_x, &
      giza_function_y, &
      giza_function_t, &
      giza_get_surface_size, &
      giza_set_hatching_style, &
      giza_get_hatching_style, &
      giza_histogram, &
      giza_histogram_binned, &
      giza_label, &
      giza_line, &
      giza_set_line_width, &
      giza_get_line_width, &
      giza_set_line_cap, &
      giza_get_line_cap, &
      giza_set_line_style, &
      giza_get_line_style, &
      giza_mark_line, &
      giza_mark_line_ordered, &
      giza_mark_points, &
      giza_mark_points_ordered, &
      giza_move, &
      giza_set_paper_size, &
      giza_get_paper_size, &
      giza_points, &
      giza_single_point, &
      giza_polygon, &
      giza_print_id, &
      giza_start_prompting, &
      giza_stop_prompting, &
      giza_set_text_background, &
      giza_get_text_background, &
      giza_text, &
      giza_ptext, &
      giza_qtext, &
      giza_qtextlen, &
      giza_rectangle, &
      giza_render, &
      giza_render_gray, &
      giza_render_gray_shade, &
      giza_render_transparent, &
      giza_draw_pixels, &
      giza_restore, &
      giza_round, &
      giza_save, &
      giza_set_font, &
      giza_set_font_bold, &
      giza_set_font_italic, &
      giza_set_font_bold_italic, &
      giza_subpanel, &
      giza_set_panel, &
      giza_get_panel, &
      giza_tick, &
      giza_vector, &
      giza_streamplot, &
      giza_set_viewport_default, &
      giza_set_viewport, &
      giza_get_viewport, &
      giza_set_viewport_inches, &
      giza_version, &
      giza_start_warnings, &
      giza_stop_warnings, &
      giza_set_window, &
      giza_set_window_equal_scale, &
      giza_get_window, &
      giza_format_number, &
      giza_set_image_transfer_function, &
      giza_get_image_transfer_function, &
      giza_query_device

#include "giza-shared.h"
  character(len=1),parameter, public :: giza_left_click_f = GIZA_LEFT_CLICK
  character(len=1),parameter, public :: giza_right_click_f = GIZA_RIGHT_CLICK
  character(len=1),parameter, public :: giza_middle_click_f = GIZA_MIDDLE_CLICK
  character(len=1),parameter, public :: giza_shift_click_f = achar(GIZA_SHIFT_CLICK)
  character(len=1),parameter, public :: giza_scroll_up_f = achar(GIZA_SCROLL_UP)
  character(len=1),parameter, public :: giza_scroll_down_f = achar(GIZA_SCROLL_DOWN)
  character(len=1),parameter, public :: giza_scroll_left_f = achar(GIZA_SCROLL_LEFT)
  character(len=1),parameter, public :: giza_scroll_right_f = achar(GIZA_SCROLL_RIGHT)
  character(len=*),parameter, public :: giza_version_string = GIZA_VERSION_STRING
  integer, parameter, public :: giza_version_major = GIZA_VERSION_MAJOR
  integer, parameter, public :: giza_version_minor = GIZA_VERSION_MINOR
  integer, parameter, public :: giza_version_micro = GIZA_VERSION_MICRO
!
!--the following can be generated automatically using the get-fortran-params.pl script
!
  integer, parameter, public :: giza_ls_solid = GIZA_LS_SOLID
  integer, parameter, public :: giza_ls_short_dash = GIZA_LS_SHORT_DASH
  integer, parameter, public :: giza_ls_long_dash = GIZA_LS_LONG_DASH
  integer, parameter, public :: giza_ls_dot = GIZA_LS_DOT
  integer, parameter, public :: giza_ls_dash_dot = GIZA_LS_DASH_DOT
  integer, parameter, public :: giza_ls_dash_dot_dot_dot = GIZA_LS_DASH_DOT_DOT_DOT
  integer, parameter, public :: giza_number_format_auto = GIZA_NUMBER_FORMAT_AUTO
  integer, parameter, public :: giza_number_format_dec = GIZA_NUMBER_FORMAT_DEC
  integer, parameter, public :: giza_number_format_exp = GIZA_NUMBER_FORMAT_EXP
  integer, parameter, public :: giza_units_normalized = GIZA_UNITS_NORMALIZED
  integer, parameter, public :: giza_units_inches = GIZA_UNITS_INCHES
  integer, parameter, public :: giza_units_mm = GIZA_UNITS_MM
  integer, parameter, public :: giza_units_pixels = GIZA_UNITS_PIXELS
  integer, parameter, public :: giza_units_world = GIZA_UNITS_WORLD
  integer, parameter, public :: giza_units_device = GIZA_UNITS_DEVICE
  integer, parameter, public :: giza_band_none = GIZA_BAND_NONE
  integer, parameter, public :: giza_band_line = GIZA_BAND_LINE
  integer, parameter, public :: giza_band_rectangle = GIZA_BAND_RECTANGLE
  integer, parameter, public :: giza_band_horzlines = GIZA_BAND_HORZLINES
  integer, parameter, public :: giza_band_vertlines = GIZA_BAND_VERTLINES
  integer, parameter, public :: giza_band_horzline = GIZA_BAND_HORZLINE
  integer, parameter, public :: giza_band_vertline = GIZA_BAND_VERTLINE
  integer, parameter, public :: giza_band_crosshair = GIZA_BAND_CROSSHAIR
  integer, parameter, public :: giza_band_circle = GIZA_BAND_CIRCLE
  integer, parameter, public :: giza_background_colour = GIZA_BACKGROUND_COLOUR
  integer, parameter, public :: giza_background_color = GIZA_BACKGROUND_COLOR
  integer, parameter, public :: giza_foreground_colour = GIZA_FOREGROUND_COLOUR
  integer, parameter, public :: giza_foreground_color = GIZA_FOREGROUND_COLOR
  integer, parameter, public :: giza_colour_index_min = GIZA_COLOUR_INDEX_MIN
  integer, parameter, public :: giza_colour_index_max = GIZA_COLOUR_INDEX_MAX
  integer, parameter, public :: giza_colour_palette_default = GIZA_COLOUR_PALETTE_DEFAULT
  integer, parameter, public :: giza_color_palette_default = GIZA_COLOR_PALETTE_DEFAULT
  integer, parameter, public :: giza_colour_palette_pgplot = GIZA_COLOUR_PALETTE_PGPLOT
  integer, parameter, public :: giza_color_palette_pgplot = GIZA_COLOR_PALETTE_PGPLOT
  integer, parameter, public :: giza_fill_solid = GIZA_FILL_SOLID
  integer, parameter, public :: giza_fill_hollow = GIZA_FILL_HOLLOW
  integer, parameter, public :: giza_fill_hatch = GIZA_FILL_HATCH
  integer, parameter, public :: giza_fill_crosshatch = GIZA_FILL_CROSSHATCH
  integer, parameter, public :: giza_max_fill_styles = GIZA_MAX_FILL_STYLES
  integer, parameter, public :: giza_extend_none = GIZA_EXTEND_NONE
  integer, parameter, public :: giza_extend_repeat = GIZA_EXTEND_REPEAT
  integer, parameter, public :: giza_extend_reflect = GIZA_EXTEND_REFLECT
  integer, parameter, public :: giza_extend_pad = GIZA_EXTEND_PAD
  integer, parameter, public :: giza_filter_default = GIZA_FILTER_DEFAULT
  integer, parameter, public :: giza_filter_fast = GIZA_FILTER_FAST
  integer, parameter, public :: giza_filter_good = GIZA_FILTER_GOOD
  integer, parameter, public :: giza_filter_best = GIZA_FILTER_BEST
  integer, parameter, public :: giza_filter_nearest = GIZA_FILTER_NEAREST
  integer, parameter, public :: giza_filter_bilinear = GIZA_FILTER_BILINEAR
  integer, parameter, public :: giza_filter_gaussian = GIZA_FILTER_GAUSSIAN

private

!---------------------------------------------------------
!  The following are pure interfaces to C
!  We make generic interfaces so that the Fortran can
!  be called with either single or double precision
!---------------------------------------------------------

 interface giza_arrow
    subroutine giza_arrow_double(x1,y1,x2,y2) bind(C, name="giza_arrow")
      import
      real(kind=c_double),intent(in),value :: x1,y1,x2,y2
    end subroutine giza_arrow_double

    subroutine giza_arrow_float(x1,y1,x2,y2) bind(C)
      import
      real(kind=c_float),intent(in),value :: x1,y1,x2,y2
    end subroutine giza_arrow_float
 end interface

 interface giza_set_arrow_style
    subroutine giza_set_arrow_style_double(fillStyle,angle,cutback) bind(C, name="giza_set_arrow_style")
      import
      integer(kind=c_int),intent(in),value :: fillStyle
      real(kind=c_double),intent(in),value :: angle,cutback
    end subroutine giza_set_arrow_style_double

    subroutine giza_set_arrow_style_float(fillStyle,angle,cutback) bind(C)
      import
      integer(kind=c_int),intent(in),value :: fillStyle
      real(kind=c_float) ,intent(in),value :: angle,cutback
    end subroutine giza_set_arrow_style_float
 end interface

 interface giza_get_arrow_style
    subroutine giza_get_arrow_style_double(fillStyle,angle,cutback) bind(C, name="giza_get_arrow_style")
      import
      integer(kind=c_int),intent(out) :: fillStyle
      real(kind=c_double),intent(out) :: angle,cutback
    end subroutine giza_get_arrow_style_double

    subroutine giza_get_arrow_style_float(fillStyle,angle,cutback) bind(C)
      import
      integer(kind=c_int),intent(out) :: fillStyle
      real(kind=c_float) ,intent(out) :: angle,cutback
    end subroutine giza_get_arrow_style_float
 end interface

 interface giza_axis
    module procedure giza_intern_axis_f2c
 end interface

 interface giza_axis_c
    subroutine giza_axis_float_c(opt,x1,y1,x2,y2,v1,v2,&
               tick,nsub,dmajl,dmajr,fmin,disp,angle) bind(C,name="giza_axis_float")
      import
      character(kind=c_char),dimension(*), intent(in) :: opt
      real(kind=c_float), value, intent(in)  :: x1,y1,x2,y2,v1,v2
      real(kind=c_float), value, intent(in)  :: tick,dmajl,dmajr,fmin,disp,angle
      integer(kind=c_int), value, intent(in) :: nsub
    end subroutine giza_axis_float_c

    subroutine giza_axis_double_c(opt,x1,y1,x2,y2,v1,v2,&
               tick,nsub,dmajl,dmajr,fmin,disp,angle) bind(C,name="giza_axis")
      import
      character(kind=c_char),dimension(*), intent(in) :: opt
      real(kind=c_double), value, intent(in)   :: x1,y1,x2,y2,v1,v2
      real(kind=c_double), value, intent(in)   :: tick,dmajl,dmajr,fmin,disp,angle
      integer(kind=c_int), value, intent(in)   :: nsub
    end subroutine giza_axis_double_c
 end interface

 interface giza_tick
    module procedure giza_intern_tick_f2c
 end interface

 interface giza_tick_c
   subroutine giza_tick_float_c(x1,y1,x2,y2,v,&
              tickl,tickr,disp,angle,label) bind(C,name="giza_tick_float")
     import
     real(kind=c_float), value, intent(in)  :: x1,y1,x2,y2,v
     real(kind=c_float), value, intent(in)  :: tickl,tickr,disp,angle
     character(kind=c_char),dimension(*), intent(in) :: label
   end subroutine giza_tick_float_c

   subroutine giza_tick_double_c(x1,y1,x2,y2,v,&
              tickl,tickr,disp,angle,label) bind(C,name="giza_tick")
     import
     real(kind=c_double), value, intent(in)   :: x1,y1,x2,y2,v
     real(kind=c_double), value, intent(in)   :: tickl,tickr,disp,angle
     character(kind=c_char),dimension(*), intent(in) :: label
   end subroutine giza_tick_double_c
 end interface

 interface giza_band
    function giza_band_double(mode,moveCurs,xanc,yanc,x,y,ch) bind(C, name="giza_band")
      import
      integer(kind=c_int)                  :: giza_band_double
      integer(kind=c_int),intent(in),value :: mode,moveCurs
      real(kind=c_double),intent(in),value :: xanc,yanc
      real(kind=c_double),intent(inout)    :: x,y
      character(kind=c_char),intent(out)   :: ch
    end function giza_band_double

    function giza_band_float(mode,moveCurs,xanc,yanc,x,y,ch) bind(C)
      import
      integer(kind=c_int)                  :: giza_band_float
      integer(kind=c_int),intent(in),value :: mode,moveCurs
      real(kind=c_float),intent(in),value  :: xanc,yanc
      real(kind=c_float),intent(inout)     :: x,y
      character(kind=c_char),intent(out)   :: ch
    end function giza_band_float
 end interface

 interface giza_annotate
    module procedure giza_intern_annotate_f2c
 end interface

 interface giza_annotate_c
    subroutine giza_annotate_double_c(side,displacement,coord,justification,text) bind(C,name="giza_annotate")
      import
      character(kind=c_char),dimension(*),intent(in) :: side,text
      real(kind=c_double),intent(in),value :: displacement,coord,justification
    end subroutine giza_annotate_double_c

    subroutine giza_annotate_float_c(side,displacement,coord,justification,text) bind(C,name="giza_annotate_float")
      import
      character(kind=c_char),dimension(*),intent(in) :: side,text
      real(kind=c_float),intent(in),value :: displacement,coord,justification
    end subroutine giza_annotate_float_c
 end interface

 interface giza_box
    module procedure giza_intern_box_f2c
 end interface

 interface giza_box_time
    module procedure giza_intern_box_time_f2c
 end interface

 interface giza_box_c
    subroutine giza_box_float_c(xopt,xtick,nxsub,yopt,ytick,nysub) bind(C,name="giza_box_float")
      import
      character(kind=c_char),dimension(*), intent(in) :: xopt,yopt
      real(kind=c_float), value, intent(in)    :: xtick,ytick
      integer(kind=c_int), value, intent(in)   :: nxsub,nysub
    end subroutine giza_box_float_c

    subroutine giza_box_double_c(xopt,xtick,nxsub,yopt,ytick,nysub) bind(C,name="giza_box")
      import
      character(kind=c_char),dimension(*), intent(in) :: xopt,yopt
      real(kind=c_double), value, intent(in)   :: xtick,ytick
      integer(kind=c_int), value, intent(in)   :: nxsub,nysub
    end subroutine giza_box_double_c
 end interface

 interface giza_box_time_c
    subroutine giza_box_time_float_c(xopt,xtick,nxsub,yopt,ytick,nysub) bind(C,name="giza_box_time_float")
      import
      character(kind=c_char),dimension(*), intent(in) :: xopt,yopt
      real(kind=c_float), value, intent(in)    :: xtick,ytick
      integer(kind=c_int), value, intent(in)   :: nxsub,nysub
    end subroutine giza_box_time_float_c

    subroutine giza_box_time_double_c(xopt,xtick,nxsub,yopt,ytick,nysub) bind(C,name="giza_box_time")
      import
      character(kind=c_char),dimension(*), intent(in) :: xopt,yopt
      real(kind=c_double), value, intent(in)   :: xtick,ytick
      integer(kind=c_int), value, intent(in)   :: nxsub,nysub
    end subroutine giza_box_time_double_c
 end interface

 interface giza_begin_buffer
    subroutine giza_begin_buffer_c() bind(C, name="giza_begin_buffer")
    end subroutine giza_begin_buffer_c
 end interface

 interface giza_end_buffer
    subroutine giza_end_buffer_c() bind(C, name="giza_end_buffer")
    end subroutine giza_end_buffer_c
 end interface

 interface giza_flush_buffer
    subroutine giza_flush_buffer_c() bind(C, name="giza_flush_buffer")
    end subroutine giza_flush_buffer_c
 end interface

 interface giza_circle
    subroutine giza_circle_double(x,y,r) bind(C, name="giza_circle")
      import
      real(kind=c_double),intent(in),value :: x,y,r
    end subroutine giza_circle_double

    subroutine giza_circle_float(x,y,r) bind(C)
      import
      real(kind=c_float),intent(in),value :: x,y,r
    end subroutine giza_circle_float
 end interface

 interface giza_set_character_height
    subroutine giza_set_character_height_double(ch) bind(C, name="giza_set_character_height")
      import
      real(kind=c_double),intent(in),value :: ch
    end subroutine giza_set_character_height_double

    subroutine giza_set_character_height_float(ch) bind(C)
      import
      real(kind=c_float),intent(in),value :: ch
    end subroutine giza_set_character_height_float
 end interface

 interface giza_get_character_height
    subroutine giza_get_character_height_double(ch) bind(C, name="giza_get_character_height")
      import
      real(kind=c_double),intent(out) :: ch
    end subroutine giza_get_character_height_double

    subroutine giza_get_character_height_float(ch) bind(C)
      import
      real(kind=c_float),intent(out) :: ch
    end subroutine giza_get_character_height_float
 end interface

 interface giza_get_character_size
    subroutine giza_get_character_size_double(units,xch,ych) bind(C, name="giza_get_character_size")
      import
      integer(kind=c_int),intent(in),value :: units
      real(kind=c_double),intent(out)      :: xch,ych
    end subroutine giza_get_character_size_double

    subroutine giza_get_character_size_float(units,xch,ych) bind(C)
      import
      integer(kind=c_int),intent(in),value :: units
      real(kind=c_float),intent(out)       :: xch,ych
    end subroutine giza_get_character_size_float
 end interface

 interface giza_set_clipping
    subroutine giza_set_clipping_c(clip) bind(C, name="giza_set_clipping")
      import
      integer(kind=c_int), value, intent(in) :: clip
    end subroutine giza_set_clipping_c
 end interface

 interface giza_get_clipping
    subroutine giza_get_clipping_c(clip) bind(C, name="giza_get_clipping")
      import
      integer(kind=c_int),intent(out) :: clip
    end subroutine giza_get_clipping_c
 end interface

 interface giza_colour_bar
    module procedure giza_intern_colour_bar_f2c
 end interface

 interface giza_colour_bar_c
    subroutine giza_colour_bar_double(side,disp,width,valmin,valmax,label) bind(C,name="giza_colour_bar")
      import
      character(kind=c_char), dimension(*), intent(in) :: side, label
      real(kind=c_double), value, intent(in) :: disp,width,valmin,valmax
    end subroutine giza_colour_bar_double

    subroutine giza_colour_bar_float_c(side,disp,width,valmin,valmax,label) bind(C,name="giza_colour_bar_float")
      import
      character(kind=c_char), dimension(*), intent(in) :: side, label
      real(kind=c_float), value, intent(in) :: disp,width,valmin,valmax
    end subroutine giza_colour_bar_float_c
 end interface

 interface giza_set_colour_index
    subroutine giza_set_colour_index_c(ci) bind(C, name="giza_set_colour_index")
      import
      integer(kind=c_int), value, intent(in) :: ci
    end subroutine giza_set_colour_index_c
 end interface

 interface giza_get_colour_index
    subroutine giza_get_colour_index_c(ci) bind(C, name="giza_get_colour_index")
      import
      integer(kind=c_int),intent(out) :: ci
    end subroutine giza_get_colour_index_c
 end interface

 interface giza_set_colour_palette
    subroutine giza_set_colour_palette_c(palette) bind(C, name="giza_set_colour_palette")
      import
      integer(kind=c_int), value, intent(in) :: palette
    end subroutine giza_set_colour_palette_c
 end interface

 interface giza_set_colour_index_range
    subroutine giza_set_colour_index_range_c(cimin,cimax) bind(C, name="giza_set_colour_index_range")
      import
      integer(kind=c_int), value, intent(in) :: cimin,cimax
    end subroutine giza_set_colour_index_range_c
 end interface

 interface giza_get_colour_index_range
    subroutine giza_get_colour_index_range_c(cimin,cimax) bind(C, name="giza_get_colour_index_range")
      import
      integer(kind=c_int),intent(out) :: cimin,cimax
    end subroutine giza_get_colour_index_range_c
 end interface

 interface giza_set_colour_representation
    subroutine giza_set_colour_representation_float(ci,red,green,blue) bind(C)
      import
      integer(kind=c_int), value, intent(in)    :: ci
      real(kind=c_float), value, intent(in)     :: red,green,blue
    end subroutine giza_set_colour_representation_float

    subroutine giza_set_colour_representation_double(ci,red,green,blue) bind(C, name="giza_set_colour_representation")
      import
      integer(kind=c_int), value, intent(in) :: ci
      real(kind=c_double), value, intent(in) :: red,green,blue
    end subroutine giza_set_colour_representation_double

    subroutine giza_set_colour_representation_alpha_float(ci,red,green,blue,alpha) bind(C)
      import
      integer(kind=c_int), value, intent(in)    :: ci
      real(kind=c_float), value, intent(in)     :: red,green,blue,alpha
    end subroutine giza_set_colour_representation_alpha_float

    subroutine giza_set_colour_representation_alpha(ci,red,green,blue,alpha) bind(C)
      import
      integer(kind=c_int), value, intent(in) :: ci
      real(kind=c_double), value, intent(in) :: red,green,blue,alpha
    end subroutine giza_set_colour_representation_alpha
 end interface

 interface giza_get_colour_representation
    subroutine giza_get_colour_representation_double(ci,red,green,blue) bind(C, name="giza_get_colour_representation")
      import
      integer(kind=c_int),intent(in),value       :: ci
      real(kind=c_double),intent(out) :: red,green,blue
    end subroutine giza_get_colour_representation_double

    subroutine giza_get_colour_representation_float(ci,red,green,blue) bind(C)
      import
      integer(kind=c_int),intent(in),value       :: ci
      real(kind=c_float),intent(out) :: red,green,blue
    end subroutine giza_get_colour_representation_float

    subroutine giza_get_colour_representation_alpha(ci,red,green,blue,alpha) bind(C)
      import
      integer(kind=c_int),intent(in),value       :: ci
      real(kind=c_double),intent(out) :: red,green,blue,alpha
    end subroutine giza_get_colour_representation_alpha

    subroutine giza_get_colour_representation_alpha_float(ci,red,green,blue,alpha) bind(C)
      import
      integer(kind=c_int),intent(in),value       :: ci
      real(kind=c_float),intent(out) :: red,green,blue,alpha
    end subroutine giza_get_colour_representation_alpha_float
 end interface

 interface giza_set_colour_representation_hls
    subroutine giza_set_colour_representation_hls_double(ci,hue,light,sat) bind(C, name="giza_set_colour_representation_hls")
      import
      integer(kind=c_int),intent(in),value :: ci
      real(kind=c_double),intent(in),value :: hue,light,sat
    end subroutine giza_set_colour_representation_hls_double

    subroutine giza_set_colour_representation_hls_float(ci,hue,light,sat) bind(C)
      import
      integer(kind=c_int),intent(in),value :: ci
      real(kind=c_float),intent(in),value  :: hue,light,sat
    end subroutine giza_set_colour_representation_hls_float
 end interface

 interface giza_set_colour_table
    subroutine giza_set_colour_table_double(controlPoints,red,green,blue,n,cont,bright) bind(C, name="giza_set_colour_table")
      import
      integer(kind=c_int),intent(in),value        :: n
      real(kind=c_double),intent(in),dimension(n) :: controlPoints,red,green,blue
      real(kind=c_double),intent(in),value        :: cont,bright
    end subroutine giza_set_colour_table_double

    subroutine giza_set_colour_table_float(controlPoints,red,green,blue,n,cont,bright) bind(C)
      import
      integer(kind=c_int),intent(in),value       :: n
      real(kind=c_float),intent(in),dimension(n) :: controlPoints,red,green,blue
      real(kind=c_float),intent(in),value        :: cont,bright
    end subroutine giza_set_colour_table_float
 end interface

 interface giza_contour
    subroutine giza_contour_double(sizex,sizey,data,i1,i2,j1,j2,ncont,cont,affine) bind(C, name="giza_contour")
      import
      integer(kind=c_int),intent(in),value :: sizex,sizey,i1,i2,j1,j2,ncont
      real(kind=c_double),intent(in) :: data(sizex,sizey)
      real(kind=c_double),intent(in) :: cont(*)
      real(kind=c_double),intent(in) :: affine(6)
    end subroutine giza_contour_double

    subroutine giza_contour_float(sizex,sizey,data,i1,i2,j1,j2,ncont,cont,affine) bind(C)
      import
      integer(kind=c_int),intent(in),value :: sizex,sizey,i1,i2,j1,j2,ncont
      real(kind=c_float),intent(in) :: data(sizex,sizey)
      real(kind=c_float),intent(in) :: cont(*)
      real(kind=c_float),intent(in) :: affine(6)
    end subroutine giza_contour_float
 end interface

 interface giza_contour_blanked
    subroutine giza_contour_blanked_double(sizex,sizey,data,i1,i2,j1,j2,ncont,cont,affine,blank) &
               bind(C, name="giza_contour_blanked")
      import
      integer(kind=c_int),intent(in),value :: sizex,sizey,i1,i2,j1,j2,ncont
      real(kind=c_double),intent(in) :: data(sizex,sizey)
      real(kind=c_double),intent(in) :: cont(*)
      real(kind=c_double),intent(in) :: affine(6)
      real(kind=c_double),intent(in),value :: blank
    end subroutine giza_contour_blanked_double

    subroutine giza_contour_blanked_float(sizex,sizey,data,i1,i2,j1,j2,ncont,cont,affine,blank) bind(C)
      import
      integer(kind=c_int),intent(in),value :: sizex,sizey,i1,i2,j1,j2,ncont
      real(kind=c_float),intent(in) :: data(sizex,sizey)
      real(kind=c_float),intent(in) :: cont(*)
      real(kind=c_float),intent(in) :: affine(6)
      real(kind=c_float),intent(in),value :: blank
    end subroutine giza_contour_blanked_float
 end interface

 interface giza_contour_fill
    subroutine giza_contour_fill_double(sizex,sizey,data,i1,i2,j1,j2,c1,c2,affine) &
               bind(C, name="giza_contour_fill")
      import
      integer(kind=c_int),intent(in),value :: sizex,sizey,i1,i2,j1,j2
      real(kind=c_double),intent(in) :: data(sizex,sizey)
      real(kind=c_double),intent(in),value :: c1,c2
      real(kind=c_double),intent(in) :: affine(6)
    end subroutine giza_contour_fill_double

    subroutine giza_contour_fill_float(sizex,sizey,data,i1,i2,j1,j2,c1,c2,affine) bind(C)
      import
      integer(kind=c_int),intent(in),value :: sizex,sizey,i1,i2,j1,j2
      real(kind=c_float),intent(in) :: data(sizex,sizey)
      real(kind=c_float),intent(in),value :: c1,c2
      real(kind=c_float),intent(in) :: affine(6)
    end subroutine giza_contour_fill_float
 end interface

 interface giza_contour_labelled
    module procedure giza_intern_contour_labelled_f2c
    module procedure giza_intern_contour_labelled_float_f2c
 end interface

 interface giza_contour_labelled_c
    subroutine giza_contour_labelled_double(sizex,sizey,data,i1,i2,j1,j2,c, &
               affine,label,intval,minint) bind(C, name="giza_contour_labelled")
      import
      integer(kind=c_int),intent(in),value :: sizex,sizey,i1,i2,j1,j2,intval,minint
      real(kind=c_double),intent(in) :: data(sizex,sizey)
      real(kind=c_double),intent(in),value :: c
      real(kind=c_double),intent(in) :: affine(6)
      character(kind=c_char),intent(in) :: label(*)
    end subroutine giza_contour_labelled_double

    subroutine giza_contour_labelled_float(sizex,sizey,data,i1,i2,j1,j2,c, &
               affine,label,intval,minint) bind(C)
      import
      integer(kind=c_int),intent(in),value :: sizex,sizey,i1,i2,j1,j2,intval,minint
      real(kind=c_float),intent(in) :: data(sizex,sizey)
      real(kind=c_float),intent(in),value :: c
      real(kind=c_float),intent(in) :: affine(6)
      character(kind=c_char),intent(in) :: label(*)
    end subroutine giza_contour_labelled_float
 end interface

 interface giza_get_current_point
    subroutine giza_get_current_point_double(xpt,ypt) bind(C, name="giza_get_current_point")
      import
      real(kind=c_double),intent(out) :: xpt,ypt
    end subroutine giza_get_current_point_double

    subroutine giza_get_current_point_float(xpt,ypt) bind(C)
      import
      real(kind=c_float),intent(out) :: xpt,ypt
    end subroutine giza_get_current_point_float
 end interface

 interface giza_rgb_from_table
    subroutine giza_rgb_from_table_double(pos,r,g,b) bind(C, name="giza_rgb_from_table")
      import
      real(kind=c_double),intent(in),value :: pos
      real(kind=c_double),intent(out) :: r,g,b
    end subroutine giza_rgb_from_table_double

    subroutine giza_rgb_from_table_float(pos,r,g,b) bind(C)
      import
      real(kind=c_float),intent(in),value :: pos
      real(kind=c_float),intent(out) :: r,g,b
    end subroutine giza_rgb_from_table_float
 end interface

 interface giza_print_device_list
    subroutine giza_print_device_list_c() bind(C, name="giza_print_device_list")
    end subroutine giza_print_device_list_c
 end interface

 interface giza_open_device
    module procedure giza_intern_open_device
 end interface

 interface giza_open_device_c
    integer(kind=c_int) function giza_open_device_intern(dev,prefix) bind(C,name="giza_open_device")
      import
      character(kind=c_char),dimension(*),intent(in) :: dev,prefix
    end function giza_open_device_intern
 end interface

!--open device: requires string conversion
 interface giza_open_device_size
    module procedure giza_intern_open_device_size
 end interface

 interface giza_open_device_size_c
    integer(kind=c_int) function giza_open_device_size_double_c(dev,prefix,width,height,units) &
                        bind(C,name="giza_open_device_size")
      import
      character(kind=c_char),dimension(*),intent(in) :: dev,prefix
      real(kind=c_double),intent(in),value    :: height,width
      integer(kind=c_int),intent(in),value    :: units
    end function giza_open_device_size_double_c

    integer(kind=c_int) function giza_open_device_size_float_c(dev,prefix,width,height,units) &
                        bind(C,name="giza_open_device_size_float")
      import
      character(kind=c_char),dimension(*),intent(in) :: dev,prefix
      real(kind=c_float),intent(in),value     :: height,width
      integer(kind=c_int),intent(in),value    :: units
    end function giza_open_device_size_float_c
 end interface

! device_has_cursor is logical in Fortran but int in c
! (cannot do a generic interface for int/logical), can call c version directly with _int version
 interface giza_device_has_cursor
    module procedure giza_intern_device_has_cursor
 end interface

 interface giza_device_has_cursor_int
    function giza_device_has_cursor_c() bind(C,name="giza_device_has_cursor")
     import
     integer(kind=c_int) :: giza_device_has_cursor_c
    end function giza_device_has_cursor_c
 end interface

 interface giza_select_device
    subroutine giza_select_device_c(devid) bind(C, name="giza_select_device")
      import
      integer(kind=c_int),intent(in),value :: devid
    end subroutine giza_select_device_c
 end interface

 interface giza_get_device_id
    subroutine giza_get_device_id_c(devid) bind(C, name="giza_get_device_id")
      import
      integer(kind=c_int),intent(out) :: devid
    end subroutine giza_get_device_id_c
 end interface

 interface giza_flush_device
    subroutine giza_flush_device_c() bind(C, name="giza_flush_device")
    end subroutine giza_flush_device_c
 end interface

 interface giza_change_page
    subroutine giza_change_page_c() bind(C, name="giza_change_page")
    end subroutine giza_change_page_c
 end interface

 interface giza_close_device
    subroutine giza_close_device_c() bind(C, name="giza_close_device")
    end subroutine giza_close_device_c
 end interface

 interface giza_get_key_press
    function giza_get_key_press_double_c(x,y,ch) bind(C, name="giza_get_key_press")
      import
      integer(kind=c_int)                :: giza_get_key_press_double_c
      real(kind=c_double),intent(out)    :: x,y
      character(kind=c_char),intent(out) :: ch
    end function giza_get_key_press_double_c

    function giza_get_key_press_float(x,y,ch) bind(C)
      import
      integer(kind=c_int)                :: giza_get_key_press_float
      real(kind=c_float),intent(out)     :: x,y
      character(kind=c_char),intent(out) :: ch
    end function giza_get_key_press_float
 end interface

 interface giza_set_motion_callback
    function giza_set_motion_callback_c(func) bind(C,name="giza_set_motion_callback")
      import
      integer(kind=c_int) :: giza_set_motion_callback_c
      abstract interface
       subroutine func(x,y,mode) bind(c)
         import
         real(c_double), intent(in) :: x,y
         integer(c_int), intent(in) :: mode
       end subroutine
      end interface
    end function giza_set_motion_callback_c
 end interface

 interface giza_end_motion_callback
    function giza_end_motion_callback_c() bind(C,name="giza_end_motion_callback")
      import
      integer(kind=c_int) :: giza_end_motion_callback_c
    end function giza_end_motion_callback_c
 end interface

 interface giza_draw
    subroutine giza_draw_double(x,y) bind(C, name="giza_draw")
      import
      real(kind=c_double),intent(in),value :: x,y
    end subroutine giza_draw_double

    subroutine giza_draw_float(x,y) bind(C)
      import
      real(kind=c_float),intent(in),value :: x,y
    end subroutine giza_draw_float
 end interface

 interface giza_draw_background
    subroutine giza_draw_background_c() bind(C, name="giza_draw_background")
    end subroutine giza_draw_background_c
 end interface

 interface giza_set_environment
    subroutine giza_set_environment_double(xmin,xmax,ymin,ymax,just,axis) bind(C, name="giza_set_environment")
      import
      real(kind=c_double),intent(in),value :: xmin,xmax,ymin,ymax
      integer(kind=c_int),intent(in),value :: just,axis
    end subroutine giza_set_environment_double

    subroutine giza_set_environment_float(xmin,xmax,ymin,ymax,just,axis) bind(C)
      import
      real(c_float),intent(in),value       :: xmin,xmax,ymin,ymax
      integer(kind=c_int),intent(in),value :: just,axis
    end subroutine giza_set_environment_float
 end interface

 interface giza_error_bars
    subroutine giza_error_bars_double(dir,n,xpts,ypts,error,term) bind(C, name="giza_error_bars")
      import
      integer(kind=c_int),intent(in),value :: dir,n
      real(kind=c_double),intent(in),value :: term
      real(kind=c_double),dimension(n),intent(in) :: xpts,ypts,error
    end subroutine giza_error_bars_double

    subroutine giza_error_bars_float(dir,n,xpts,ypts,error,term) bind(C)
      import
      integer(kind=c_int),intent(in),value :: dir,n
      real(kind=c_float),intent(in),value :: term
      real(kind=c_float),dimension(n),intent(in) :: xpts,ypts,error
    end subroutine giza_error_bars_float
 end interface

 interface giza_error_bars_x
    subroutine giza_error_bars_hori(n,xpts,ypts1,ypts2,term) bind(C)
      import
      integer(kind=c_int),intent(in),value :: n
      real(kind=c_double),intent(in),value :: term
      real(kind=c_double),dimension(n),intent(in) :: xpts,ypts1,ypts2
    end subroutine giza_error_bars_hori

    subroutine giza_error_bars_hori_float(n,xpts,ypts1,ypts2,term) bind(C)
      import
      integer(kind=c_int),intent(in),value :: n
      real(kind=c_float),intent(in),value :: term
      real(kind=c_float),dimension(n),intent(in) :: xpts,ypts1,ypts2
    end subroutine giza_error_bars_hori_float
 end interface

 interface giza_error_bars_y
    subroutine giza_error_bars_vert(n,xpts,ypts1,ypts2,term) bind(C)
      import
      integer(kind=c_int),intent(in),value :: n
      real(kind=c_double),intent(in),value :: term
      real(kind=c_double),dimension(n),intent(in) :: xpts,ypts1,ypts2
    end subroutine giza_error_bars_vert

    subroutine giza_error_bars_vert_float(n,xpts,ypts1,ypts2,term) bind(C)
      import
      integer(kind=c_int),intent(in),value :: n
      real(kind=c_float),intent(in),value :: term
      real(kind=c_float),dimension(n),intent(in) :: xpts,ypts1,ypts2
    end subroutine giza_error_bars_vert_float
 end interface

 interface giza_set_fill
    subroutine giza_set_fill_c(fs) bind(C, name="giza_set_fill")
      import
      integer(kind=c_int),intent(in),value :: fs
    end subroutine giza_set_fill_c
 end interface

 interface giza_get_fill
    subroutine giza_get_fill_c(fs) bind(C, name="giza_get_fill")
      import
      integer(kind=c_int),intent(out) :: fs
    end subroutine giza_get_fill_c
 end interface

 interface giza_function_x
    subroutine giza_function_x_double(func,n,xmin,xmax,flag) bind(C, name="giza_function_x")
      import
      integer(kind=c_int),intent(in),value :: n,flag
      real(kind=c_double),intent(in),value :: xmin,xmax
      abstract interface
       function func(x) bind(c)
         import
         real(c_double), intent(in) :: x
         real(c_double) :: func
       end function
      end interface
    end subroutine giza_function_x_double

    subroutine giza_function_x_float(func,n,xmin,xmax,flag) bind(C)
      import
      integer(kind=c_int),intent(in),value :: n,flag
      real(kind=c_float), intent(in),value :: xmin,xmax
      abstract interface
       function func(x) bind(c)
         import
         real(c_float), intent(in) :: x
         real(c_float) :: func
       end function
      end interface
    end subroutine giza_function_x_float
 end interface

 interface giza_function_y
    subroutine giza_function_y_double(func,n,ymin,ymax,flag) bind(C, name="giza_function_y")
      import
      integer(kind=c_int),intent(in),value :: n,flag
      real(kind=c_double),intent(in),value :: ymin,ymax
      abstract interface
       function func(x) bind(c)
         import
         real(c_double), intent(in) :: x
         real(c_double) :: func
       end function
      end interface
    end subroutine giza_function_y_double

    subroutine giza_function_y_float(func,n,ymin,ymax,flag) bind(C)
      import
      integer(kind=c_int),intent(in),value :: n,flag
      real(kind=c_float), intent(in),value :: ymin,ymax
      abstract interface
       function func(x) bind(c)
         import
         real(c_float), intent(in) :: x
         real(c_float) :: func
       end function
      end interface
    end subroutine giza_function_y_float
 end interface

 interface giza_function_t
    subroutine giza_function_t_double(funcx,funcy,n,tmin,tmax,flag) bind(C, name="giza_function_t")
      import
      integer(kind=c_int),intent(in),value :: n,flag
      real(kind=c_double),intent(in),value :: tmin,tmax
      abstract interface
       function funcx(x) bind(c)
         import
         real(c_double), intent(in) :: x
         real(c_double) :: funcx
       end function
       function funcy(x) bind(c)
         import
         real(c_double), intent(in) :: x
         real(c_double) :: funcy
       end function
      end interface
    end subroutine giza_function_t_double

    subroutine giza_function_t_float(funcx,funcy,n,tmin,tmax,flag) bind(C)
      import
      integer(kind=c_int),intent(in),value :: n,flag
      real(kind=c_float), intent(in),value :: tmin,tmax
!      real(kind=c_float),external :: funcx,funcy
      abstract interface
       function funcx(x) bind(c)
         import
         real(c_float), intent(in) :: x
         real(c_float) :: funcx
       end function
       function funcy(x) bind(c)
         import
         real(c_float), intent(in) :: x
         real(c_float) :: funcy
       end function
      end interface
    end subroutine giza_function_t_float
 end interface

 interface giza_get_surface_size
    subroutine giza_get_surface_size_float(x1,x2,y1,y2) bind(C)
      import
      real(kind=c_float),intent(out) :: x1,x2,y1,y2
    end subroutine giza_get_surface_size_float

    subroutine giza_get_surface_size_double(x1,x2,y1,y2) bind(C, name="giza_get_surface_size")
      import
      real(kind=c_double),intent(out) :: x1,x2,y1,y2
    end subroutine giza_get_surface_size_double
 end interface

 interface giza_set_hatching_style
    subroutine giza_set_hatching_style_double(angle,spacing,phase) bind(C, name="giza_set_hatching_style")
      import
      real(kind=c_double),intent(in),value :: angle,spacing,phase
    end subroutine giza_set_hatching_style_double

    subroutine giza_set_hatching_style_float(angle,spacing,phase) bind(C)
      import
      real(kind=c_float),intent(in),value :: angle,spacing,phase
    end subroutine giza_set_hatching_style_float
 end interface giza_set_hatching_style

 interface giza_get_hatching_style
    subroutine giza_get_hatching_style_double(angle,spacing,phase) bind(C, name="giza_get_hatching_style")
      import
      real(kind=c_double),intent(out) :: angle,spacing,phase
    end subroutine giza_get_hatching_style_double

    subroutine giza_get_hatching_style_float(angle,spacing,phase) bind(C)
      import
      real(kind=c_float),intent(out) :: angle,spacing,phase
    end subroutine giza_get_hatching_style_float
 end interface giza_get_hatching_style

 interface giza_histogram
    subroutine giza_histogram_double(n,dat,min,max,nbin,flag) bind(C, name="giza_histogram")
      import
      integer(kind=c_int),intent(in), value :: n,nbin,flag
      real(kind=c_double),intent(in) :: dat(*)
      real(kind=c_double),intent(in), value :: min,max
    end subroutine giza_histogram_double

    subroutine giza_histogram_float(n,dat,min,max,nbin,flag) bind(C)
      import
      integer(kind=c_int),intent(in), value :: n,nbin,flag
      real(kind=c_float), intent(in) :: dat(*)
      real(kind=c_float), intent(in), value :: min,max
    end subroutine giza_histogram_float
 end interface

 interface giza_histogram_binned
    subroutine giza_histogram_binned_double(nbin,x,dat,centre) bind(C, name="giza_histogram_binned")
      import
      integer(kind=c_int),intent(in), value :: nbin,centre
      real(kind=c_double),intent(in) :: x(*),dat(*)
    end subroutine giza_histogram_binned_double

    subroutine giza_histogram_binned_float(nbin,x,dat,centre) bind(C)
      import
      integer(kind=c_int),intent(in), value :: nbin,centre
      real(kind=c_float), intent(in) :: x(*),dat(*)
    end subroutine giza_histogram_binned_float
 end interface

 interface giza_label
    module procedure giza_intern_label_f2c
 end interface

 interface giza_label_c
    subroutine giza_label_int (labelx,labely,title) bind(C,name="giza_label")
      import
      character(kind=c_char),dimension(*),intent(in) :: labelx,labely,title
    end subroutine giza_label_int
 end interface giza_label_c

 interface giza_line
    subroutine giza_line_float(n,xpts,ypts) bind(C)
      import
      integer(kind=c_int),value,intent(in)       :: n
      real(kind=c_float),intent(in),dimension(n) :: xpts,ypts
    end subroutine giza_line_float

    subroutine giza_line_double(n,xpts,ypts) bind(C, name="giza_line")
      import
      integer(kind=c_int),value,intent(in)        :: n
      real(kind=c_double),intent(in),dimension(n) :: xpts,ypts
    end subroutine giza_line_double
 end interface

 interface giza_set_line_width
    subroutine giza_set_line_width_double(lw) bind(C, name="giza_set_line_width")
      import
      real(kind=c_double),intent(in), value :: lw
    end subroutine giza_set_line_width_double

    subroutine giza_set_line_width_float(lw) bind(C)
      import
      real(kind=c_float),intent(in), value :: lw
    end subroutine giza_set_line_width_float

    module procedure giza_intern_set_line_width_int
 end interface

 interface giza_get_line_width
    subroutine giza_get_line_width_double(lw) bind(C, name="giza_get_line_width")
      import
      real(kind=c_double),intent(out) :: lw
    end subroutine giza_get_line_width_double

    subroutine giza_get_line_width_float(lw) bind(C)
      import
      real(kind=c_float),intent(out) :: lw
    end subroutine giza_get_line_width_float

    module procedure giza_intern_get_line_width_int
 end interface

 interface giza_set_line_cap
    subroutine giza_set_line_cap_c(lc) bind(C, name="giza_set_line_cap")
      import
      integer(c_int),value,intent(in) :: lc
    end subroutine giza_set_line_cap_c
 end interface

 interface giza_get_line_cap
    subroutine giza_get_line_cap_c(lc) bind(C, name="giza_get_line_cap")
      import
      integer(c_int),intent(out) :: lc
    end subroutine giza_get_line_cap_c
 end interface

 interface giza_set_line_style
    subroutine giza_set_line_style_c(ls) bind(C, name="giza_set_line_style")
      import
      integer(c_int),value,intent(in) :: ls
    end subroutine giza_set_line_style_c
 end interface

 interface giza_get_line_style
    subroutine giza_get_line_style_c(ls) bind(C, name="giza_get_line_style")
      import
      integer(c_int),intent(out) :: ls
    end subroutine giza_get_line_style_c
 end interface

 interface giza_mark_line
    subroutine giza_mark_line_double(maxpts,npts,xpts,ypts) bind(C, name="giza_mark_line")
      import
      integer(kind=c_int),intent(in),value :: maxpts
      integer(kind=c_int),intent(inout) :: npts
      real(kind=c_double), dimension(*), intent(inout) :: xpts
      real(kind=c_double), dimension(*), intent(inout) :: ypts
    end subroutine giza_mark_line_double

    subroutine giza_mark_line_float(maxpts,npts,xpts,ypts) bind(C)
      import
      integer(kind=c_int),intent(in),value :: maxpts
      integer(kind=c_int),intent(inout) :: npts
      real(kind=c_float), dimension(*), intent(inout) :: xpts
      real(kind=c_float), dimension(*), intent(inout) :: ypts
    end subroutine giza_mark_line_float

    subroutine giza_mark_line_char(maxpts,npts,xpts,ypts,ch) bind(C)
      import
      integer(kind=c_int),intent(in),value :: maxpts
      integer(kind=c_int),intent(inout) :: npts
      real(kind=c_double), dimension(*), intent(inout) :: xpts
      real(kind=c_double), dimension(*), intent(inout) :: ypts
      character(kind=c_char),intent(out)   :: ch
    end subroutine giza_mark_line_char

    subroutine giza_mark_line_char_float(maxpts,npts,xpts,ypts,ch) bind(C)
      import
      integer(kind=c_int),intent(in),value :: maxpts
      integer(kind=c_int),intent(inout) :: npts
      real(kind=c_float), dimension(*), intent(inout) :: xpts
      real(kind=c_float), dimension(*), intent(inout) :: ypts
      character(kind=c_char),intent(out)   :: ch
    end subroutine giza_mark_line_char_float
 end interface

 interface giza_mark_line_ordered
    subroutine giza_mark_line_ordered_double(maxpts,npts,xpts,ypts) bind(C, name="giza_mark_line_ordered")
      import
      integer(kind=c_int),intent(in),value :: maxpts
      integer(kind=c_int),intent(inout) :: npts
      real(kind=c_double), dimension(*), intent(inout) :: xpts
      real(kind=c_double), dimension(*), intent(inout) :: ypts
    end subroutine giza_mark_line_ordered_double

    subroutine giza_mark_line_ordered_float(maxpts,npts,xpts,ypts) bind(C)
      import
      integer(kind=c_int),intent(in),value :: maxpts
      integer(kind=c_int),intent(inout) :: npts
      real(kind=c_float), dimension(*), intent(inout) :: xpts
      real(kind=c_float), dimension(*), intent(inout) :: ypts
    end subroutine giza_mark_line_ordered_float
 end interface

 interface giza_mark_points
    subroutine giza_mark_points_double(maxpts,npts,xpts,ypts,symbol) bind(C, name="giza_mark_points")
      import
      integer(kind=c_int),intent(in),value :: maxpts
      integer(kind=c_int),intent(inout) :: npts
      real(kind=c_double), dimension(*), intent(inout) :: xpts
      real(kind=c_double), dimension(*), intent(inout) :: ypts
      integer(kind=c_int),intent(in),value :: symbol
    end subroutine giza_mark_points_double

    subroutine giza_mark_points_float(maxpts,npts,xpts,ypts,symbol) bind(C)
      import
      integer(kind=c_int),intent(in),value :: maxpts
      integer(kind=c_int),intent(inout) :: npts
      real(kind=c_float), dimension(*), intent(inout) :: xpts
      real(kind=c_float), dimension(*), intent(inout) :: ypts
      integer(kind=c_int),intent(in),value :: symbol
    end subroutine giza_mark_points_float
 end interface

 interface giza_mark_points_ordered
    subroutine giza_mark_points_ordered_double(maxpts,npts,xpts,ypts,symbol) bind(C, name="giza_mark_points_ordered")
      import
      integer(kind=c_int),intent(in),value :: maxpts
      integer(kind=c_int),intent(inout) :: npts
      real(kind=c_double), dimension(*), intent(inout) :: xpts
      real(kind=c_double), dimension(*), intent(inout) :: ypts
      integer(kind=c_int),intent(in),value :: symbol
    end subroutine giza_mark_points_ordered_double

    subroutine giza_mark_points_ordered_float(maxpts,npts,xpts,ypts,symbol) bind(C)
      import
      integer(kind=c_int),intent(in),value :: maxpts
      integer(kind=c_int),intent(inout) :: npts
      real(kind=c_float), dimension(*), intent(inout) :: xpts
      real(kind=c_float), dimension(*), intent(inout) :: ypts
      integer(kind=c_int),intent(in),value :: symbol
    end subroutine giza_mark_points_ordered_float
 end interface

 interface giza_move
    subroutine giza_move_double(x,y) bind(C, name="giza_move")
      import
      real(kind=c_double),intent(in),value :: x,y
    end subroutine giza_move_double

    subroutine giza_move_float(x,y) bind(C)
      import
      real(kind=c_float),intent(in),value :: x,y
    end subroutine giza_move_float
 end interface

 interface giza_get_paper_size
    subroutine giza_get_paper_size_double(units,width,height) bind(C, name="giza_get_paper_size")
      import
      integer(kind=c_int), intent(in),value :: units
      real(kind=c_double),intent(out) :: width,height
    end subroutine giza_get_paper_size_double

    subroutine giza_get_paper_size_float(units,width,height) bind(C)
      import
      integer(kind=c_int), intent(in),value :: units
      real(kind=c_float),intent(out) :: width,height
    end subroutine giza_get_paper_size_float
 end interface

 interface giza_set_paper_size
    subroutine giza_set_paper_size_double(units,width,aspect) bind(C, name="giza_set_paper_size")
      import
      integer(kind=c_int), intent(in),value :: units
      real(kind=c_double), intent(in),value :: width,aspect
    end subroutine giza_set_paper_size_double

    subroutine giza_set_paper_size_float(units,width,aspect) bind(C)
      import
      integer(kind=c_int),intent(in),value :: units
      real(kind=c_float), intent(in),value :: width,aspect
    end subroutine giza_set_paper_size_float
 end interface

 interface giza_points
    subroutine giza_points_double(n,xpts,ypts,symbol) bind(C, name="giza_points")
      import
      integer(kind=c_int), value, intent(in) :: n, symbol
      real(kind=c_double), dimension(n), intent(in) :: xpts,ypts
    end subroutine giza_points_double

    subroutine giza_points_float(n,xpts,ypts,symbol) bind(C)
      import
      integer(kind=c_int), value, intent(in) :: n, symbol
      real(kind=c_float), dimension(n), intent(in) :: xpts,ypts
    end subroutine giza_points_float
 end interface

 interface giza_single_point
    subroutine giza_single_point_double(x,y,symbol) bind(C, name="giza_single_point")
      import
      real(kind=c_double), value, intent(in) :: x,y
      integer(kind=c_int), value, intent(in) :: symbol
    end subroutine giza_single_point_double

    subroutine giza_single_point_float(x,y,symbol) bind(C)
      import
      real(kind=c_float),  value, intent(in) :: x,y
      integer(kind=c_int), value, intent(in) :: symbol
    end subroutine giza_single_point_float
 end interface

 interface giza_polygon
    subroutine giza_polygon_double(n,xpts,ypts) bind(C, name="giza_polygon")
      import
      integer(kind=c_int), value, intent(in) :: n
      real(kind=c_double), dimension(n), intent(in) :: xpts,ypts
    end subroutine giza_polygon_double

    subroutine giza_polygon_float(n,xpts,ypts) bind(C)
      import
      integer(kind=c_int), value, intent(in) :: n
      real(kind=c_float), dimension(n), intent(in) :: xpts,ypts
    end subroutine giza_polygon_float
 end interface

 interface giza_print_id
    subroutine giza_print_id_c() bind(C, name="giza_print_id")
    end subroutine giza_print_id_c
 end interface

 interface giza_start_prompting
    subroutine giza_start_prompting_c() bind(C, name="giza_start_prompting")
    end subroutine giza_start_prompting_c
 end interface

 interface giza_stop_prompting
    subroutine giza_stop_prompting_c() bind(C, name="giza_stop_prompting")
    end subroutine giza_stop_prompting_c
 end interface

 interface giza_text
    module procedure giza_intern_text_f2c
    module procedure giza_intern_text_float_f2c
 end interface

 interface giza_set_text_background
    subroutine giza_set_text_background_c(ci) bind(C, name="giza_set_text_background")
      import
      integer(kind=c_int), value, intent(in) :: ci
    end subroutine giza_set_text_background_c
 end interface

 interface giza_get_text_background
    subroutine giza_get_text_background_c(ci) bind(C, name="giza_get_text_background")
      import
      integer(kind=c_int), intent(out) :: ci
    end subroutine giza_get_text_background_c
 end interface

 interface giza_text_c
    subroutine giza_text_double(x,y,text) bind(C,name="giza_text")
      import
      real(kind=c_double),value,intent(in)    :: x,y
      character(kind=c_char),dimension(*),intent(in) :: text
    end subroutine giza_text_double

    subroutine giza_text_float(x,y,text) bind(C)
      import
      real(kind=c_float),value,intent(in)     :: x,y
      character(kind=c_char),dimension(*),intent(in) :: text
    end subroutine giza_text_float
 end interface

 interface giza_open
    module procedure giza_open_sub
 end interface giza_open

 interface giza_ptext
    module procedure giza_intern_ptext_f2c
    module procedure giza_intern_ptext_float_f2c
 end interface

 interface giza_ptext_c
    subroutine giza_ptext_double(x,y,angle,just,text) bind(C,name="giza_ptext")
      import
      real(kind=c_double),value,intent(in)    :: x,y,angle,just
      character(kind=c_char),dimension(*),intent(in) :: text
    end subroutine giza_ptext_double

    subroutine giza_ptext_float(x,y,angle,just,text) bind(C)
      import
      real(kind=c_float),value,intent(in)     :: x,y,angle,just
      character(kind=c_char),dimension(*),intent(in) :: text
    end subroutine giza_ptext_float
 end interface

 interface giza_qtext
    module procedure giza_intern_qtext_f2c
    module procedure giza_intern_qtext_float_f2c
 end interface

 interface giza_qtext_c
    subroutine giza_qtext_double(x,y,angle,just,text,xbox,ybox) bind(C,name="giza_qtext")
      import
      real(kind=c_double),value,intent(in)    :: x,y,angle,just
      real(kind=c_double),intent(out)         :: xbox(4),ybox(4)
      character(kind=c_char),dimension(*),intent(in) :: text
    end subroutine giza_qtext_double

    subroutine giza_qtext_float(x,y,angle,just,text,xbox,ybox) bind(C)
      import
      real(kind=c_float),value,intent(in)     :: x,y,angle,just
      real(kind=c_float),intent(out)          :: xbox(4),ybox(4)
      character(kind=c_char),dimension(*),intent(in) :: text
    end subroutine giza_qtext_float
 end interface

 interface giza_qtextlen
    module procedure giza_intern_qtextlen_f2c
    module procedure giza_intern_qtextlen_float_f2c
 end interface

 interface giza_qtextlen_c
    subroutine giza_qtextlen_double(units,text,xlen,ylen) bind(C,name="giza_qtextlen")
      import
      integer(kind=c_int),value,intent(in)    :: units
      character(kind=c_char),dimension(*),intent(in) :: text
      real(kind=c_double),intent(out)         :: xlen,ylen
    end subroutine giza_qtextlen_double

    subroutine giza_qtextlen_float(units,text,xlen,ylen) bind(C)
      import
      integer(kind=c_int),value,intent(in)    :: units
      character(kind=c_char),dimension(*),intent(in) :: text
      real(kind=c_float),intent(out)          :: xlen,ylen
    end subroutine giza_qtextlen_float
 end interface

 interface giza_render
    subroutine giza_render_double(sizex,sizey,data,i1,i2,j1,j2,valMin,valMax,extend,filter,affine) bind(C, name="giza_render")
      import
      integer(kind=c_int),intent(in),value :: sizex,sizey,i1,i2,j1,j2,extend,filter
      real(kind=c_double),intent(in) :: data(sizex,sizey)
      real(kind=c_double),intent(in),value :: valMin,valMax
      real(kind=c_double),intent(in) :: affine(6)
    end subroutine giza_render_double

    subroutine giza_render_float(sizex,sizey,data,i1,i2,j1,j2,valMin,valMax,extend,filter,affine) bind(C)
      import
      integer(kind=c_int),intent(in),value :: sizex,sizey,i1,i2,j1,j2,extend,filter
      real(kind=c_float),intent(in) :: data(sizex,sizey)
      real(kind=c_float),intent(in),value :: valMin,valMax
      real(kind=c_float),intent(in) :: affine(6)
    end subroutine giza_render_float

    subroutine giza_render_alpha(sizex,sizey,data,alpha,i1,i2,j1,j2,valMin,valMax,extend,filter,affine) bind(C)
      import
      integer(kind=c_int),intent(in),value :: sizex,sizey,i1,i2,j1,j2,extend,filter
      real(kind=c_double),intent(in) :: data(sizex,sizey), alpha(sizex,sizey)
      real(kind=c_double),intent(in),value :: valMin,valMax
      real(kind=c_double),intent(in) :: affine(6)
    end subroutine giza_render_alpha

    subroutine giza_render_alpha_float(sizex,sizey,data,alpha,i1,i2,j1,j2,valMin,valMax,extend,filter,affine) bind(C)
      import
      integer(kind=c_int),intent(in),value :: sizex,sizey,i1,i2,j1,j2,extend,filter
      real(kind=c_float),intent(in) :: data(sizex,sizey), alpha(sizex,sizey)
      real(kind=c_float),intent(in),value :: valMin,valMax
      real(kind=c_float),intent(in) :: affine(6)
    end subroutine giza_render_alpha_float
 end interface

 interface giza_render_transparent
    subroutine giza_render_transparent_double(sizex,sizey,data,i1,i2,j1,j2,&
               valMin,valMax,extend,filter,affine) bind(C, name="giza_render_transparent")
      import
      integer(kind=c_int),intent(in),value :: sizex,sizey,i1,i2,j1,j2,extend,filter
      real(kind=c_double),intent(in) :: data(sizex,sizey)
      real(kind=c_double),intent(in),value :: valMin,valMax
      real(kind=c_double),intent(in) :: affine(6)
    end subroutine giza_render_transparent_double

    subroutine giza_render_transparent_float(sizex,sizey,data,i1,i2,j1,j2,&
               valMin,valMax,extend,filter,affine) bind(C)
      import
      integer(kind=c_int),intent(in),value :: sizex,sizey,i1,i2,j1,j2,extend,filter
      real(kind=c_float),intent(in) :: data(sizex,sizey)
      real(kind=c_float),intent(in),value :: valMin,valMax
      real(kind=c_float),intent(in) :: affine(6)
    end subroutine giza_render_transparent_float
 end interface

 interface giza_render_gray
    subroutine giza_render_gray_double(sizex,sizey,data,i1,i2,j1,j2,&
               valMin,valMax,extend,filter,affine) bind(C, name="giza_render_gray")
      import
      integer(kind=c_int),intent(in),value :: sizex,sizey,i1,i2,j1,j2,extend,filter
      real(kind=c_double),intent(in) :: data(sizex,sizey)
      real(kind=c_double),intent(in),value :: valMin,valMax
      real(kind=c_double),intent(in) :: affine(6)
    end subroutine giza_render_gray_double

    subroutine giza_render_gray_float(sizex,sizey,data,i1,i2,j1,j2,&
               valMin,valMax,extend,filter,affine) bind(C)
      import
      integer(kind=c_int),intent(in),value :: sizex,sizey,i1,i2,j1,j2,extend,filter
      real(kind=c_float),intent(in) :: data(sizex,sizey)
      real(kind=c_float),intent(in),value :: valMin,valMax
      real(kind=c_float),intent(in) :: affine(6)
    end subroutine giza_render_gray_float
 end interface

 interface giza_render_gray_shade
    subroutine giza_render_gray_shade_double(sizex,sizey,data,i1,i2,j1,j2,&
               fg,bg,extend,filter,affine) bind(C, name="giza_render_gray_shade")
      import
      integer(kind=c_int),intent(in),value :: sizex,sizey,i1,i2,j1,j2,extend,filter
      real(kind=c_double),intent(in) :: data(sizex,sizey)
      real(kind=c_double),intent(in),value :: fg,bg
      real(kind=c_double),intent(in) :: affine(6)
    end subroutine giza_render_gray_shade_double

    subroutine giza_render_gray_shade_float(sizex,sizey,data,i1,i2,j1,j2,&
               fg,bg,extend,filter,affine) bind(C, name="giza_render_gray_shade_float")
      import
      integer(kind=c_int),intent(in),value :: sizex,sizey,i1,i2,j1,j2,extend,filter
      real(kind=c_float),intent(in) :: data(sizex,sizey)
      real(kind=c_float),intent(in),value :: fg,bg
      real(kind=c_float),intent(in) :: affine(6)
    end subroutine giza_render_gray_shade_float
 end interface

 interface giza_draw_pixels
    subroutine giza_draw_pixels_double(sizex,sizey,idata,i1,i2,j1,j2,&
               xmin,xmax,ymin,ymax,extend,filter) bind(C, name="giza_draw_pixels")
      import
      integer(kind=c_int),intent(in),value :: sizex,sizey,i1,i2,j1,j2,extend,filter
      integer(kind=c_int),intent(in) :: idata(sizex,sizey)
      real(kind=c_double),intent(in),value :: xmin,xmax,ymin,ymax
    end subroutine giza_draw_pixels_double

    subroutine giza_draw_pixels_float(sizex,sizey,idata,i1,i2,j1,j2,&
               xmin,xmax,ymin,ymax,extend,filter) bind(C)
      import
      integer(kind=c_int),intent(in),value :: sizex,sizey,i1,i2,j1,j2,extend,filter
      integer(kind=c_int),intent(in) :: idata(sizex,sizey)
      real(kind=c_float),intent(in),value :: xmin,xmax,ymin,ymax
    end subroutine giza_draw_pixels_float
 end interface

 interface giza_rectangle
    subroutine giza_rectangle_double(x1,x2,y1,y2) bind(C, name="giza_rectangle")
      import
      real(kind=c_double),intent(in),value :: x1,x2,y1,y2
    end subroutine giza_rectangle_double

    subroutine giza_rectangle_float(x1,x2,y1,y2) bind(C)
      import
      real(kind=c_float),intent(in),value :: x1,x2,y1,y2
    end subroutine giza_rectangle_float

    subroutine giza_rectangle_rounded(x1,x2,y1,y2,r) bind(C)
      import
      real(kind=c_double),intent(in),value :: x1,x2,y1,y2,r
    end subroutine giza_rectangle_rounded

    subroutine giza_rectangle_rounded_float(x1,x2,y1,y2,r) bind(C)
      import
      real(kind=c_float),intent(in),value :: x1,x2,y1,y2,r
    end subroutine giza_rectangle_rounded_float
 end interface giza_rectangle

 interface giza_restore
    subroutine giza_restore_c() bind(C, name="giza_restore")
    end subroutine giza_restore_c
 end interface

 interface giza_round
    function giza_round_double(x,nsub) bind(C,name="giza_round")
      import
      real(kind=c_double), intent(in) :: x
      integer(kind=c_int), intent(out) :: nsub
      real(kind=c_double) :: giza_round_double
    end function giza_round_double

    function giza_round_float(x,nsub) bind(C)
      import
      real(kind=c_float), intent(in) :: x
      integer(kind=c_int), intent(out) :: nsub
      real(kind=c_float) :: giza_round_float
    end function giza_round_float
 end interface giza_round

 interface giza_save
    subroutine giza_save_c() bind(C, name="giza_save")
    end subroutine giza_save_c
 end interface

 interface giza_set_font
    module procedure giza_intern_set_font_f2c
 end interface

 interface giza_set_font_bold
    module procedure giza_intern_set_font_bold_f2c
 end interface

 interface giza_set_font_italic
    module procedure giza_intern_set_font_italic_f2c
 end interface

 interface giza_set_font_bold_italic
    module procedure giza_intern_set_font_bold_italic_f2c
 end interface

 interface giza_set_font_c
    subroutine giza_set_font_intern(font) bind(C,name="giza_set_font")
      import
      character(kind=c_char),dimension(*),intent(in) :: font
    end subroutine giza_set_font_intern
 end interface
 interface giza_set_font_bold_c
    subroutine giza_set_font_bold_intern(font) bind(C,name="giza_set_font_bold")
      import
      character(kind=c_char),dimension(*),intent(in) :: font
    end subroutine giza_set_font_bold_intern
 end interface
 interface giza_set_font_italic_c
    subroutine giza_set_font_italic_c_intern(font) bind(C,name="giza_set_font_italic")
      import
      character(kind=c_char),dimension(*),intent(in) :: font
    end subroutine giza_set_font_italic_c_intern
 end interface
 interface giza_set_font_bold_italic_c
    subroutine giza_set_font_bold_italic_intern(font) bind(C,name="giza_set_font_bold_italic")
      import
      character(kind=c_char),dimension(*),intent(in) :: font
    end subroutine giza_set_font_bold_italic_intern
 end interface

 interface giza_subpanel
    subroutine giza_subpanel_c(nx,ny) bind(C, name="giza_subpanel")
      import
      integer(kind=c_int), intent(in),value :: nx,ny
    end subroutine giza_subpanel_c
 end interface

 interface giza_set_panel
    subroutine giza_set_panel_c(ix,iy) bind(C, name="giza_set_panel")
      import
      integer(kind=c_int), intent(in),value :: ix,iy
    end subroutine giza_set_panel_c
 end interface

 interface giza_get_panel
    subroutine giza_get_panel_c(ix,iy) bind(C, name="giza_get_panel")
      import
      integer(kind=c_int), intent(out) :: ix,iy
    end subroutine giza_get_panel_c
 end interface

 interface giza_vector
    subroutine giza_vector_double(sizex,sizey,horizontal,vertical,i1,i2,j1,j2,&
                                  scale,position,affine,blank) bind(C, name="giza_vector")
      import
      integer(kind=c_int),intent(in),value :: sizex,sizey,i1,i2,j1,j2,position
      real(kind=c_double),intent(in) :: horizontal(sizex,sizey),vertical(sizex,sizey)
      real(kind=c_double),intent(in),value :: scale,blank
      real(kind=c_double),intent(in) :: affine(6)
    end subroutine giza_vector_double

    subroutine giza_vector_float(sizex,sizey,horizontal,vertical,i1,i2,j1,j2,&
                                 scale,position,affine,blank) bind(C)
      import
      integer(kind=c_int),intent(in),value :: sizex,sizey,i1,i2,j1,j2,position
      real(kind=c_float),intent(in) :: horizontal(sizex,sizey),vertical(sizex,sizey)
      real(kind=c_float),intent(in),value :: scale,blank
      real(kind=c_float),intent(in) :: affine(6)
    end subroutine giza_vector_float
 end interface

 interface giza_streamplot
    subroutine giza_streamplot_double(sizex,sizey,u,v,i1,i2,j1,j2,&
                                      density,affine,blank) bind(C, name="giza_streamplot")
      import
      integer(kind=c_int),intent(in),value :: sizex,sizey,i1,i2,j1,j2
      real(kind=c_double),intent(in) :: u(sizex,sizey),v(sizex,sizey)
      real(kind=c_double),intent(in),value :: density,blank
      real(kind=c_double),intent(in) :: affine(6)
    end subroutine giza_streamplot_double

    subroutine giza_streamplot_float(sizex,sizey,u,v,i1,i2,j1,j2,&
                                     density,affine,blank) bind(C)
      import
      integer(kind=c_int),intent(in),value :: sizex,sizey,i1,i2,j1,j2
      real(kind=c_float),intent(in) :: u(sizex,sizey),v(sizex,sizey)
      real(kind=c_float),intent(in),value :: density,blank
      real(kind=c_float),intent(in) :: affine(6)
    end subroutine giza_streamplot_float
 end interface


 interface giza_set_viewport
    subroutine giza_set_viewport_float(xleft,xright,ybot,ytop) bind(C)
      import
      real(kind=c_float), value, intent(in) :: xleft,xright,ybot,ytop
    end subroutine giza_set_viewport_float

    subroutine giza_set_viewport_double(xleft,xright,ybot,ytop) bind(C, name="giza_set_viewport")
      import
      real(kind=c_double), value, intent(in) :: xleft,xright,ybot,ytop
    end subroutine giza_set_viewport_double
 end interface

 interface giza_set_viewport_default
    subroutine giza_set_viewport_default_c() bind(C, name="giza_set_viewport_default")
    end subroutine giza_set_viewport_default_c
 end interface

 interface giza_get_viewport
    subroutine giza_get_viewport_double(units,x1,x2,y1,y2) bind(C, name="giza_get_viewport")
      import
      integer(kind=c_int), value, intent(in)  :: units
      real(kind=c_double),        intent(out) :: x1,x2,y1,y2
    end subroutine giza_get_viewport_double

    subroutine giza_get_viewport_float(units,x1,x2,y1,y2) bind(C)
      import
      integer(kind=c_int),value, intent(in)  :: units
      real(kind=c_float),        intent(out) :: x1,x2,y1,y2
    end subroutine giza_get_viewport_float
 end interface

 interface giza_set_viewport_inches
    subroutine giza_set_viewport_inches_float(xleft,xright,ybot,ytop) bind(C)
      import
      real(kind=c_float), value, intent(in) :: xleft,xright,ybot,ytop
    end subroutine giza_set_viewport_inches_float

    subroutine giza_set_viewport_inches_double(xleft,xright,ybot,ytop) bind(C, name="giza_set_viewport_inches")
      import
      real(kind=c_double), value, intent(in) :: xleft,xright,ybot,ytop
    end subroutine giza_set_viewport_inches_double
 end interface

 interface giza_version
    subroutine giza_version_c(major,minor,micro) bind(C, name="giza_version")
     import
     integer(kind=c_int), intent(out) :: major,minor,micro
    end subroutine giza_version_c
 end interface

 interface giza_start_warnings
    subroutine giza_start_warnings_c() bind(C, name="giza_start_warnings")
    end subroutine giza_start_warnings_c
 end interface

 interface giza_stop_warnings
    subroutine giza_stop_warnings_c() bind(C, name="giza_stop_warnings")
    end subroutine giza_stop_warnings_c
 end interface

 interface giza_set_window
    subroutine giza_set_window_float(x1,x2,y1,y2) bind(C)
      import
      real(kind=c_float), value, intent(in) :: x1,x2,y1,y2
    end subroutine giza_set_window_float

    subroutine giza_set_window_double(x1,x2,y1,y2) bind(C, name="giza_set_window")
      import
      real(kind=c_double), value, intent(in) :: x1,x2,y1,y2
    end subroutine giza_set_window_double
 end interface

 interface giza_set_window_equal_scale
    subroutine giza_set_window_equal_scale_double(x1,x2,y1,y2) &
               bind(C, name="giza_set_window_equal_scale")
      import
      real(kind=c_double), value, intent(in) :: x1,x2,y1,y2
    end subroutine giza_set_window_equal_scale_double

    subroutine giza_set_window_equal_scale_float(x1,x2,y1,y2) bind(C)
      import
      real(kind=c_float), value, intent(in) :: x1,x2,y1,y2
    end subroutine giza_set_window_equal_scale_float
 end interface

 interface giza_get_window
    subroutine giza_get_window_double(x1,x2,y1,y2) bind(C, name="giza_get_window")
      import
      real(kind=c_double),intent(out) :: x1,x2,y1,y2
    end subroutine giza_get_window_double

    subroutine giza_get_window_float(x1,x2,y1,y2) bind(C)
      import
      real(kind=c_float),intent(out) :: x1,x2,y1,y2
    end subroutine giza_get_window_float
 end interface

 interface giza_format_number
    module procedure giza_format_number_f2c
 end interface

 !private :: giza_format_number_c
 interface giza_format_number_c
    subroutine giza_format_number_intern(mantissa,power,iform,string,cstring_len) bind(C,name="giza_format_number")
      import
      integer(kind=c_int),value,intent(in)    :: mantissa,power,iform,cstring_len
      character(kind=c_char),dimension(*),intent(out) :: string
    end subroutine giza_format_number_intern
 end interface

 interface giza_query_device
    module procedure giza_query_device_f2c
 end interface

 interface giza_query_device_c
    integer(kind=c_int) function giza_query_device_intern(qtype,string,rval) bind(C,name="giza_query_device")
      import
      character(kind=c_char),dimension(*),intent(in)  :: qtype
      character(kind=c_char),dimension(*),intent(out) :: string
      integer(kind=c_int),intent(out) :: rval
    end function giza_query_device_intern
 end interface

 interface giza_set_image_transfer_function
    subroutine giza_set_image_transfer_function_c(itf) bind(C, name="giza_set_image_transfer_function")
      import
      integer(kind=c_int), value, intent(in) :: itf
    end subroutine giza_set_image_transfer_function_c
 end interface

 interface giza_get_image_transfer_function
    subroutine giza_get_image_transfer_function_c(itf) bind(C, name="giza_get_image_transfer_function")
      import
      integer(kind=c_int), intent(out) :: itf
    end subroutine giza_get_image_transfer_function_c
 end interface

!------------------ end of interfaces -----------------------

contains

!-------------------------------------------------------
! these are subroutines whose arguments need conversion
! before passing to c (mainly strings)
!-------------------------------------------------------

  subroutine giza_intern_annotate_f2c(side,displacement,coord,justification,text)
    character(len=*),intent(in)    :: side,text
    real,intent(in)                :: displacement,coord,justification
    real(kind=c_double)            :: displacement_c,coord_c,justification_c

    displacement_c = displacement
    coord_c = coord
    justification_c = justification

    call giza_annotate_double_c(cstring(trim(side)),displacement_c,coord_c,justification_c,cstring(text))
  end subroutine giza_intern_annotate_f2c

  subroutine giza_intern_axis_f2c(opt,x1,y1,x2,y2,v1,v2,&
             tick,nsub,dmajl,dmajr,fmin,disp,angle)
    character(len=*),intent(in) :: opt
    real, intent(in)  :: x1,y1,x2,y2,v1,v2
    real, intent(in)  :: tick,dmajl,dmajr,fmin,disp,angle
    integer,intent(in)  :: nsub
    real(kind=c_double) :: x1_c,y1_c,x2_c,y2_c,v1_c,v2_c
    real(kind=c_double) :: tick_c,dmajl_c,dmajr_c,fmin_c,disp_c,angle_c
    integer(kind=c_int) :: nsub_c

    x1_c = x1; y1_c = y1; x2_c = x2; y2_c = y2; v1_c = v1; v2_c = v2
    tick_c = tick; dmajl_c = dmajl; dmajr_c = dmajr; fmin_c = fmin
    disp_c = disp; angle_c = angle
    nsub_c = nsub

    call giza_axis_c(cstring(trim(opt)),x1_c,y1_c,x2_c,y2_c,v1_c,v2_c,&
                     tick_c,nsub_c,dmajl_c,dmajr_c,fmin_c,disp_c,angle_c)

  end subroutine giza_intern_axis_f2c

  subroutine giza_intern_tick_f2c(x1,y1,x2,y2,v,&
             tickl,tickr,disp,angle,label)
    real, intent(in)  :: x1,y1,x2,y2,v
    real, intent(in)  :: tickl,tickr,disp,angle
    character(len=*),intent(in) :: label
    real(kind=c_double) :: x1_c,y1_c,x2_c,y2_c,v_c
    real(kind=c_double) :: tickl_c,tickr_c,disp_c,angle_c

    x1_c = x1; y1_c = y1; x2_c = x2; y2_c = y2; v_c = v
    tickl_c = tickl; tickr_c = tickr; disp_c = disp; angle_c = angle

    call giza_tick_c(x1_c,y1_c,x2_c,y2_c,v_c,&
                     tickl_c,tickr_c,disp_c,angle_c,cstring(label))

  end subroutine giza_intern_tick_f2c

  subroutine giza_intern_box_f2c(xopt,xtick,nxsub,yopt,ytick,nysub)
    character(len=*),intent(in) :: xopt,yopt
    real,intent(in)             :: xtick,ytick
    integer,intent(in)          :: nxsub,nysub
    real(kind=c_double)         :: xtick_c,ytick_c
    integer(kind=c_int)         :: nxsub_c,nysub_c

    xtick_c = xtick; ytick_c = ytick
    nxsub_c = nxsub; nysub_c = nysub

    call giza_box_c(cstring(trim(xopt)),xtick_c,nxsub_c,cstring(yopt),ytick_c,nysub_c)

  end subroutine giza_intern_box_f2c

  subroutine giza_intern_box_time_f2c(xopt,xtick,nxsub,yopt,ytick,nysub)
    character(len=*),intent(in) :: xopt,yopt
    real,intent(in)             :: xtick,ytick
    integer,intent(in)          :: nxsub,nysub
    real(kind=c_double)         :: xtick_c,ytick_c
    integer(kind=c_int)         :: nxsub_c,nysub_c

    xtick_c = xtick; ytick_c = ytick
    nxsub_c = nxsub; nysub_c = nysub

    call giza_box_time_c(cstring(trim(xopt)),xtick_c,nxsub_c,cstring(yopt),ytick_c,nysub_c)

  end subroutine giza_intern_box_time_f2c

  subroutine giza_intern_colour_bar_f2c(side,disp,width,valmin,valmax,label)
    character(len=*), intent(in) :: side,label
    real, intent(in) :: disp,width,valmin,valmax
    real(kind=c_double) :: disp_c,width_c,valmin_c,valmax_c

    disp_c = disp
    width_c = width
    valmin_c = valmin
    valmax_c = valmax

    call giza_colour_bar_c(cstring(side),disp_c,width_c,valmin_c,valmax_c,cstring(label))

  end subroutine giza_intern_colour_bar_f2c

  integer function giza_intern_open_device(dev,prefix)
    character(len=*),intent(in) :: dev,prefix

    giza_intern_open_device = giza_open_device_c(cstring(dev),cstring(prefix))

  end function giza_intern_open_device

  subroutine giza_open_sub(dev,prefix,width,height,units,error)
    character(len=*),intent(in), optional  :: dev
    character(len=*), intent(in), optional :: prefix
    real,intent(in), optional     :: width,height
    integer, intent(in), optional :: units
    integer, intent(out), optional :: error
    integer :: giza_open

    character(len=40) :: fdev
    if (present(dev)) then
       fdev = dev
    else
       fdev = '?'
    endif

    if (present(units) .and. present(width) .and. present(height)) then
       if (present(prefix)) then
          giza_open = giza_open_device_size_c(cstring(fdev),cstring(prefix),width,height,units)
       else
          giza_open = giza_open_device_size_c(cstring(fdev),cstring('giza'),width,height,units)
       endif
    else
       if (present(prefix)) then
          giza_open = giza_open_device_c(cstring(fdev),cstring(prefix))
       else
          giza_open = giza_open_device_c(cstring(fdev),cstring('giza'))
       endif
    endif
    if (present(error)) then
       error = giza_open
    endif

  end subroutine giza_open_sub

  subroutine giza_close
     call giza_close_device_c()
  end subroutine giza_close

  integer function giza_intern_open_device_size(dev,prefix,width,height,units)
    character(len=*),intent(in) :: dev,prefix
    real,intent(in)             :: width,height
    integer, intent(in)         :: units

    giza_intern_open_device_size = giza_open_device_size_c(cstring(dev),&
                                                           cstring(prefix),width,height,units)

  end function giza_intern_open_device_size

  ! So cursor functionality can be queried as logical
  logical function giza_intern_device_has_cursor()

    giza_intern_device_has_cursor = (giza_device_has_cursor_c().eq.1)

  end function giza_intern_device_has_cursor

  subroutine giza_intern_label_f2c(labelx,labely,title)
    character(len=*),intent(in) :: labelx,labely,title

    call giza_label_c(cstring(labelx),cstring(labely),cstring(title))

  end subroutine giza_intern_label_f2c

  subroutine giza_intern_set_line_width_int(lw)
    integer(kind=c_int),value,intent(in) :: lw
    real(kind=c_double) :: reallw

    !--cairo line widths are best as .5, 1.5 etc
    reallw = dble(lw) + 0.5d0
    call giza_set_line_width_double(reallw)
  end subroutine giza_intern_set_line_width_int

  subroutine giza_intern_get_line_width_int(lw)
    integer(kind=c_int),intent(out) :: lw
    real(kind=c_double) :: reallw

    call giza_get_line_width_double(reallw)
    lw = nint(reallw - 0.5d0)

  end subroutine giza_intern_get_line_width_int

  subroutine giza_intern_text_f2c(x,y,text)
    real(kind=c_double),intent(in) :: x,y
    character(len=*),intent(in)    :: text

    call giza_text_double(x,y,cstring(text))

  end subroutine giza_intern_text_f2c

  subroutine giza_intern_text_float_f2c(x,y,text)
    real(kind=c_float),intent(in) :: x,y
    character(len=*),intent(in)    :: text

    call giza_text_float(x,y,cstring(text))

  end subroutine giza_intern_text_float_f2c

  subroutine giza_intern_ptext_f2c(x,y,angle,just,text)
    real(kind=c_double),intent(in) :: x,y,angle,just
    character(len=*),intent(in)    :: text

    call giza_ptext_double(x,y,angle,just,cstring(text))

  end subroutine giza_intern_ptext_f2c

 subroutine giza_intern_ptext_float_f2c(x,y,angle,just,text)
    real(kind=c_float),intent(in) :: x,y,angle,just
    character(len=*),intent(in)    :: text

    call giza_ptext_float(x,y,angle,just,cstring(text))

  end subroutine giza_intern_ptext_float_f2c

  subroutine giza_intern_qtext_f2c(x,y,angle,just,text,xbox,ybox)
    real(kind=c_double),intent(in) :: x,y,angle,just
    real(kind=c_double),intent(out):: xbox(4),ybox(4)
    character(len=*),intent(in)    :: text

    call giza_qtext_double(x,y,angle,just,cstring(text),xbox,ybox)

  end subroutine giza_intern_qtext_f2c

  subroutine giza_intern_qtext_float_f2c(x,y,angle,just,text,xbox,ybox)
    real(kind=c_float),intent(in) :: x,y,angle,just
    real(kind=c_float),intent(out):: xbox(4),ybox(4)
    character(len=*),intent(in)   :: text

    call giza_qtext_float(x,y,angle,just,cstring(text),xbox,ybox)

  end subroutine giza_intern_qtext_float_f2c

  subroutine giza_intern_qtextlen_f2c(units,text,xlen,ylen)
    integer(kind=c_int),intent(in) :: units
    character(len=*),intent(in)    :: text
    real(kind=c_double),intent(out):: xlen,ylen

    call giza_qtextlen_double(units,cstring(text),xlen,ylen)

  end subroutine giza_intern_qtextlen_f2c

  subroutine giza_intern_qtextlen_float_f2c(units,text,xlen,ylen)
    integer(kind=c_int),intent(in) :: units
    character(len=*),intent(in)    :: text
    real(kind=c_float),intent(out) :: xlen,ylen

    call giza_qtextlen_float(units,cstring(text),xlen,ylen)

  end subroutine giza_intern_qtextlen_float_f2c

  subroutine giza_intern_set_font_f2c(font)
    character(len=*),intent(in) :: font

    call giza_set_font_c(cstring(trim(font)))

  end subroutine giza_intern_set_font_f2c

  subroutine giza_intern_set_font_bold_f2c(font)
    character(len=*),intent(in) :: font

    call giza_set_font_bold_c(cstring(trim(font)))

  end subroutine giza_intern_set_font_bold_f2c

  subroutine giza_intern_set_font_italic_f2c(font)
    character(len=*),intent(in) :: font

    call giza_set_font_italic_c(cstring(trim(font)))

  end subroutine giza_intern_set_font_italic_f2c

  subroutine giza_intern_set_font_bold_italic_f2c(font)
    character(len=*),intent(in) :: font

    call giza_set_font_bold_italic_c(cstring(trim(font)))

  end subroutine giza_intern_set_font_bold_italic_f2c

  subroutine giza_format_number_f2c(mantissa,power,iform,string)
    integer(kind=c_int),intent(in) :: mantissa,power,iform
    character(len=*),  intent(out) :: string
    character(kind=c_char), dimension(len(string)+1) :: stringc
    integer(kind=c_int) :: cstring_length
    cstring_length = len(string)+1
    call giza_format_number_c(mantissa,power,iform,stringc,cstring_length)
    string = fstring(stringc)

  end subroutine giza_format_number_f2c

  subroutine giza_query_device_f2c(qtype,string)
    character(len=*),intent(in)  :: qtype
    character(len=*),intent(out) :: string
    integer(kind=c_int) :: rval
    integer(kind=c_int) :: ierr
    character(kind=c_char), dimension(len(string)+1) :: stringc
    rval = len(string)+1
    ierr = giza_query_device_c(cstring(trim(qtype)),stringc,rval)
    string = fstring(stringc)

  end subroutine giza_query_device_f2c


  !---------------------------------------------------------------------------
  !
  ! function to safely convert a string to c format (ie. with a terminating
  ! ascii null character)
  !
  !---------------------------------------------------------------------------
  function cstring(string) result(array)
    character(len=*), intent(in) :: string
    character(kind=c_char), dimension(len(string)+1) :: array
    integer :: i, ilen

    ilen = len(string) ! use the trimmed string length
    do i=1,ilen
       array(i)=string(i:i)
    end do
    array(ilen+1)=achar(0)

  end function cstring

  !---------------------------------------------------------------------------
  !
  ! function to safely convert a string from c format (ie. with a terminating
  ! ascii null character) back to a normal Fortran string
  !
  !---------------------------------------------------------------------------
   function fstring(array)
    character(kind=c_char), dimension(:), intent(in) :: array
    character(len=size(array)-1) :: fstring
    integer :: i

    fstring = ''
    do i=1,size(array)
       if (array(i).eq.achar(0)) exit
       fstring(i:i) = array(i)
    enddo

   end function fstring

!---------------------------------------------------------------------------
!---------------------------------------------------------------------------
!              HIGH LEVEL FORTRAN INTERFACE
!---------------------------------------------------------------------------
!---------------------------------------------------------------------------

subroutine giza_plot(y,x,img,dev,prefix,width,height,units,&
                     xmin,xmax,ymin,ymax,imgmin,imgmax,affine,&
                     vptxmin,vptxmax,vptymin,vptymax, &
                     xlabel,ylabel,title,font,&
                     ls,lw,ci,ch,symbol,just,axis,extend,filter,printid)
 real, intent(in), dimension(:), optional :: y,x
 real, intent(in), dimension(:,:), optional :: img
 integer, intent(in), optional :: units
 real, intent(in), optional :: width,height
 character(len=*), intent(in), optional :: dev,prefix
 real, intent(in), optional :: xmin,xmax,ymin,ymax,imgmin,imgmax
 real, intent(in), optional :: vptxmin,vptxmax,vptymin,vptymax
 character(len=*), intent(in), optional :: xlabel,ylabel,title
 character(len=*), intent(in), optional :: font
 integer, intent(in), optional :: ls,ci,symbol,axis,just,extend,filter
 real, intent(in), optional :: lw,ch
 real, dimension(6), intent(in), optional :: affine
 logical, intent(in), optional :: printid
 integer :: iunits,nx,ny,i,iaxis,ijust
 real(kind=c_double) :: xmini,xmaxi,ymini,ymaxi,valmin,valmax,dx,dy
 real(kind=c_double) :: vptxmini,vptxmaxi,vptymini,vptymaxi
 real(kind=c_double), dimension(6) :: affinei
 character(len=20) :: devi
 character(len=40) :: xlabeli,ylabeli,titlei
 real(kind=c_double), dimension(:), allocatable :: arrtmp

 real(kind=c_double)  :: lw_c, ch_c
 integer(kind=c_int)  :: n, nx_c, ny_c
 integer(kind=c_int)  :: symbol_c, iextend, ifilter

!
!--open giza device
!
 if (present(dev)) then
    devi = dev
 else
    devi = '?'
 endif
 if (present(width) .and. present(height)) then
    if (present(units)) then
       iunits = units
    else
       iunits = giza_units_pixels
    endif
    if (present(prefix)) then
       call giza_open(dev=devi,prefix=prefix,width=width,height=height,units=iunits)
    else
       call giza_open(dev=devi,width=width,height=height,units=iunits)
    endif
 else
    if (present(prefix)) then
       call giza_open(dev=devi,prefix=prefix)
    else
       call giza_open(dev=devi)
    endif
 endif

!
!--max/min limits for plot window
!
 if (present(xmin)) then
    xmini = xmin
 else
    if (present(x)) then
       xmini = minval(x)
    else
       xmini = 0.
    endif
 endif
 if (present(xmax)) then
    xmaxi = xmax
 else
    if (present(x)) then
       xmaxi = maxval(x)
    else
       xmaxi = 1.
    endif
 endif
 if (present(ymin)) then
    ymini = ymin
 else
    if (present(y)) then
       ymini = minval(y)
    else
       ymini = 0.
    endif
 endif
 if (present(ymax)) then
    ymaxi = ymax
 else
    if (present(y)) then
       ymaxi = maxval(y)
    else
       ymaxi = 1.
    endif
 endif
 !--plot labels
 if (present(title)) then
    titlei = title
 else
    titlei = ''
 endif
 if (present(xlabel)) then
    xlabeli = xlabel
 else
    xlabeli = ''
 endif
 if (present(ylabel)) then
    ylabeli = ylabel
 else
    ylabeli = ''
 endif
 if (present(font)) then
    call giza_set_font(font)
 endif
 if (present(ch)) then
    ch_c = ch
    call giza_set_character_height(ch_c)
 endif
 if (present(just)) then
    ijust = just
 else
    ijust = 0
 endif
 if (present(axis)) then
    iaxis = axis
 else
    iaxis = 0
 endif

 if (present(vptxmin) .or. present(vptxmax) .or. present(vptymin) .or. present(vptymax)) then
    call giza_set_viewport_default()
    call giza_get_viewport(giza_units_normalized,vptxmini,vptxmaxi,vptymini,vptymaxi)

    if (present(vptxmin)) vptxmini = vptxmin
    if (present(vptxmax)) vptxmaxi = vptxmax
    if (present(vptymin)) vptymini = vptymin
    if (present(vptymax)) vptymaxi = vptymax

    call giza_set_viewport(vptxmini,vptxmaxi,vptymini,vptymaxi)
    if (ijust.eq.1) then
       call giza_set_window(xmini,xmaxi,ymini,ymaxi)
    else
       call giza_set_window_equal_scale(xmini,xmaxi,ymini,ymaxi)
    endif
    call giza_box("BCTSN",0.,0,"BCTSN",0.,0)
    call giza_label(xlabeli,ylabeli,titlei)
 else
    call giza_set_environment(xmini,xmaxi,ymini,ymaxi,ijust,iaxis)
    call giza_label(xlabeli,ylabeli,titlei)
 endif
 if (present(printid)) then
    if (printid) call giza_print_id()
 endif

 if (present(ls)) then
    call giza_set_line_style(ls)
 endif
 if (present(lw)) then
    lw_c = lw
    call giza_set_line_width(lw_c)
 endif
 if (present(ci)) then
    call giza_set_colour_index(ci)
 endif

 if (present(x) .and. present(y)) then
    n = min(size(x),size(y))
    if (present(symbol)) then
       symbol_c = symbol
       call giza_points(n,real(x,kind=c_double),real(y,kind=c_double),symbol_c)
    else
       call giza_line(n,real(x,kind=c_double),real(y,kind=c_double))
    endif
 elseif (present(x) .and. size(x).gt.1) then
    n = size(x)
    allocate(arrtmp(n))
    do i=1,n
       arrtmp(i) = (i-1)/(real(n-1))
    enddo
    if (present(symbol)) then
       symbol_c = symbol
       call giza_points(n,real(x,kind=c_double),arrtmp,symbol_c)
    else
       call giza_line(n,real(x,kind=c_double),arrtmp)
    endif
    deallocate(arrtmp)
 elseif (present(y) .and. size(y).gt.1) then
    n = size(y)
    allocate(arrtmp(n))
    do i=1,n
       arrtmp(i) = (i-1)/(real(n-1))
    enddo
    if (present(symbol)) then
       symbol_c = symbol
       call giza_points(n,arrtmp,real(y,kind=c_double),symbol_c)
    else
       call giza_line(n,arrtmp,real(y,kind=c_double))
    endif
    deallocate(arrtmp)
 endif

 if (present(img)) then
    nx = size(img(:,1))
    ny = size(img(1,:))
    if (present(imgmin)) then
       valmin = imgmin
    else
       valmin = minval(img)
    endif
    if (present(imgmax)) then
       valmax = imgmax
    else
       valmax = maxval(img)
    endif
    if (present(affine)) then
       affinei = affine
    else
       dx = real((xmaxi - xmini)/real(nx))
       dy = real((ymaxi - ymini)/real(ny))
       affinei = (/dx,0.d0,0.d0,dy,xmini,ymini/)
    endif
    if (present(extend)) then
       iextend = extend
    else
       iextend = giza_extend_none
    endif
    if (present(filter)) then
       ifilter = filter
    else
       ifilter = giza_filter_default
    endif
    nx_c = nx; ny_c = ny
    call giza_render(nx_c,ny_c,real(img,kind=c_double),int(1,kind=c_int),&
                     nx_c,int(1,kind=c_int),ny_c,valmin,valmax,iextend,ifilter,affinei)
 endif

 call giza_close()

end subroutine giza_plot

 subroutine giza_intern_contour_labelled_f2c(sizex,sizey,data,i1,i2,j1,j2,c,affine,label,intval,minint)
    integer(kind=c_int),intent(in) :: sizex,sizey,i1,i2,j1,j2,intval,minint
    real(kind=c_double),intent(in) :: data(sizex,sizey)
    real(kind=c_double),intent(in) :: c
    real(kind=c_double),intent(in) :: affine(6)
    character(len=*),intent(in)    :: label

    call giza_contour_labelled_double(sizex,sizey,data,i1,i2,j1,j2,c,affine,cstring(label),intval,minint)

 end subroutine giza_intern_contour_labelled_f2c

 subroutine giza_intern_contour_labelled_float_f2c(sizex,sizey,data,i1,i2,j1,j2,c,affine,label,intval,minint)
    integer(kind=c_int),intent(in) :: sizex,sizey,i1,i2,j1,j2,intval,minint
    real(kind=c_float),intent(in)  :: data(sizex,sizey)
    real(kind=c_float),intent(in)  :: c
    real(kind=c_float),intent(in)  :: affine(6)
    character(len=*),intent(in)    :: label

    call giza_contour_labelled_float(sizex,sizey,data,i1,i2,j1,j2,c,affine,cstring(label),intval,minint)

 end subroutine giza_intern_contour_labelled_float_f2c

end module giza
