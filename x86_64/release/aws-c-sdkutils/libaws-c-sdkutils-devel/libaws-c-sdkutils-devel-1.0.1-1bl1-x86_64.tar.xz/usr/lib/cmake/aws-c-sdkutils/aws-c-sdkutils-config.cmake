include(CMakeFindDependencyMacro)

find_dependency(aws-c-common)

include(${CMAKE_CURRENT_LIST_DIR}/aws-c-sdkutils-targets.cmake)
