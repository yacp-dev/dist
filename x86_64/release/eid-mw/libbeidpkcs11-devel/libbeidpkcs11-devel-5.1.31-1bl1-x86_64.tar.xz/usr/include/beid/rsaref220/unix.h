

#ifndef UNIX_H
#define UNIX_H

#ifdef __GNUC__
#define EXPORTED __attribute__((visibility("default")))
#endif
#define CK_PTR *

#define CK_DEFINE_FUNCTION(returnType, name) \
   returnType EXPORTED name

#if defined(__CYGWIN__) && !defined(BEIDPKCS11_BUILD)
/* A DLL function only has one address outside the DLL when it is
 * declared dllimport; otherwise it is that of a local import thunk. */
#define CK_DECLARE_FUNCTION(returnType, name) \
   returnType __declspec(dllimport) name
#else
#define CK_DECLARE_FUNCTION(returnType, name) \
   returnType EXPORTED name
#endif

#define CK_DECLARE_FUNCTION_POINTER(returnType, name) \
   returnType (* name)

#define CK_CALLBACK_FUNCTION(returnType, name) \
   returnType (* name)

#ifndef NULL_PTR
#define NULL_PTR 0
#endif

#endif
