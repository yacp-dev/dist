;;; -*- mode:scheme; coding:utf-8; -*-
;;;
;;; rfc/ssh/transport/kex/ecdh.scm - SSH2 protocol ECDH key exchange
;;;  
;;;   Copyright (c) 2025  Takashi Kato  <ktakashi@ymail.com>
;;;   
;;;   Redistribution and use in source and binary forms, with or without
;;;   modification, are permitted provided that the following conditions
;;;   are met:
;;;   
;;;   1. Redistributions of source code must retain the above copyright
;;;      notice, this list of conditions and the following disclaimer.
;;;  
;;;   2. Redistributions in binary form must reproduce the above copyright
;;;      notice, this list of conditions and the following disclaimer in the
;;;      documentation and/or other materials provided with the distribution.
;;;  
;;;   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
;;;   "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
;;;   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
;;;   A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
;;;   OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
;;;   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
;;;   TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
;;;   PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
;;;   LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
;;;   NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
;;;   SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
;;;  

#!nounbound
(library (rfc ssh transport kex ecdh)
    (export ssh-kex-digest
	    (rename (ecdh-sha2? ssh-kex-ecdh-sha2?)
		    (extract-identity ssh-kex-ecdh-identity)
		    (curve-25519/448 ssh-curve-25519/448)
		    (<ECDH-H> <SSH-ECDH-H>)))
    (import (rnrs)
	    (clos user)
	    (srfi :13 strings)
	    (sagittarius)
	    (sagittarius crypto digests)
	    (rfc ssh constants)
	    (rfc ssh types)
	    (rfc ssh crypto)
	    (rfc ssh transport kex api))

(define (ecdh-sha2? n) (string-prefix? "ecdh-sha2" n))

(define-method ssh-kex-digest ((n (?? ecdh-sha2?)))
  (make-message-digest
   (ssh-ecdsa-digest-descriptor
    (ssh-ecdsa-identifier->ec-parameter (extract-identity n)))))

(define (extract-identity n)
  (string->keyword (substring n 10 (string-length n))))

(define curve-25519/448 (list +kex-curve25519-sha256+ +kex-curve448-sha512+))
(define-method ssh-kex-digest ((n (member curve-25519/448)))
  (make-message-digest
   (if (string=? n +kex-curve448-sha512+) *digest:sha-512* *digest:sha-256*)))


(define-ssh-message <ECDH-H> ()
  ((V-C :utf8-string)
   (V-S :utf8-string)
   (I-C :string)
   (I-S :string)
   (K-S :string)
   (Q-C :string)
   (Q-S :string)
   (K   :mpint)))
)
