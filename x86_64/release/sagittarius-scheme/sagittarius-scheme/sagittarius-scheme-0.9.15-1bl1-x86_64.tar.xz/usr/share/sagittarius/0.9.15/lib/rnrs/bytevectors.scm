;; -*- scheme -*-
(library (rnrs bytevectors (6))
    (export endianness native-endianness
	    bytevector? make-bytevector bytevector-length bytevector=?
	    bytevector-fill! bytevector-copy! bytevector-copy
	    bytevector-u8-ref bytevector-s8-ref bytevector-u8-set! bytevector-s8-set!
	    bytevector->u8-list u8-list->bytevector
	    bytevector-u16-ref bytevector-s16-ref bytevector-u16-native-ref bytevector-s16-native-ref
	    bytevector-u16-set! bytevector-s16-set! bytevector-u16-native-set! bytevector-s16-native-set!
	    bytevector-u32-ref bytevector-s32-ref bytevector-u32-native-ref bytevector-s32-native-ref
	    bytevector-u32-set! bytevector-s32-set! bytevector-u32-native-set! bytevector-s32-native-set!
	    bytevector-u64-ref bytevector-s64-ref bytevector-u64-native-ref bytevector-s64-native-ref
	    bytevector-u64-set! bytevector-s64-set! bytevector-u64-native-set! bytevector-s64-native-set!
	    bytevector-ieee-single-ref bytevector-ieee-single-native-ref
	    bytevector-ieee-single-set! bytevector-ieee-single-native-set!
	    bytevector-ieee-double-ref bytevector-ieee-double-native-ref
	    bytevector-ieee-double-set! bytevector-ieee-double-native-set!
	    bytevector-uint-ref bytevector-sint-ref
	    bytevector-uint-set!  bytevector-sint-set!
	    bytevector->uint-list bytevector->sint-list
	    uint-list->bytevector sint-list->bytevector
	    string->utf8 utf8->string
	    string->utf16 utf16->string
	    string->utf32 utf32->string)
    (import (core)
	    (core base)
	    (core syntax))

  (define-syntax endianness
    (lambda (x)
      (syntax-case x ()
	((_ endian)
	 (memq (syntax->datum #'endian) '(big little))
	 #''endian)
	((_ endian)
	 (eq? (syntax->datum #'endian) 'native)
	 #'(native-endianness))
	((_ x) (syntax-violation 'endianness "invalid endianness" #'x)))))
) ; [end]
;; end of file
;; Local Variables:
;; coding: utf-8-unix
;; End:
