/* vm.h                                            -*- mode:c; coding:utf-8; -*-
 *
 *   Copyright (c) 2010-2021  Takashi Kato <ktakashi@ymail.com>
 *
 *   Redistribution and use in source and binary forms, with or without
 *   modification, are permitted provided that the following conditions
 *   are met:
 *
 *   1. Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *   2. Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *
 *   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *   "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *   A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *   OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 *   TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 *   PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 *   LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 *   NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 *   SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *  $Id: $
 */
#ifndef SAGITTARIUS_PRIVATE_VM_H_
#define SAGITTARIUS_PRIVATE_VM_H_

#include "sagittariusdefs.h"
#include "subr.h"		/* for SgSubrProc */
#include "thread.h"
#include "clos.h"
#ifdef HAVE_SETJMP_H
# include <setjmp.h>
#else
# error TODO implement own set jmp
#endif

#define SG_VM_STACK_SIZE      10000

SG_CLASS_DECL(Sg_BoxClass);
SG_CLASS_DECL(Sg_VMClass);
/* &continuation */
SG_CLASS_DECL(Sg_ContinuationViolationClass);
SG_CLASS_DECL(Sg_DynamicWinderClass);

#define SG_CLASS_BOX (&Sg_BoxClass)
#define SG_CLASS_VM  (&Sg_VMClass)
#define SG_CLASS_CONTINUATION_VIOLATION (&Sg_ContinuationViolationClass)
#define SG_CLASS_DYNAMIC_WINDER (&Sg_DynamicWinderClass)

struct SgBoxRec
{
  SG_HEADER;
  SgObject value;
};

#define SG_BOX(obj)  ((SgBox*)(obj))
#define SG_BOXP(obj) SG_XTYPEP(obj, SG_CLASS_BOX)

typedef struct SgContinuationViolationRec
{
  SG_INSTANCE_HEADER;
  SgObject promptTag;
} SgContinuationViolation;
#define SG_CONTINUATION_VIOLATION(o) ((SgContinuationViolation *)o)
#define SG_CONTINUATION_VIOLATIONP(o) SG_ISA(o, SG_CLASS_CONTINUATION_VIOLATION)
#define SG_CONTINUATION_VIOLATION_PROMPT_TAG(o) \
  SG_CONTINUATION_VIOLATION(o)->promptTag

/* continuation frame */
typedef struct SgContFrameRec
{
  struct SgContFrameRec *prev; 	/* previous frame */
#if SIZEOF_VOIDP == 8
  int            size;
  int            type;
#else
  int            size: 29;	/* size of argument frame */
  int            type:  3;
#endif
  SgWord        *pc;		/* next PC */
  SgObject       cl;		/* cl register value */
  SgObject      *fp;		/* fp register value */
  SgObject       env[1];	/* saved arguments */
} SgContFrame;

#define CONT_FRAME_SIZE (sizeof(SgContFrame)/sizeof(SgObject))

typedef SgObject SgCContinuationProc(SgObject result, void **data);

/*
  We need to treat c-stack not the same way as Scheme stack, otherwise
  it'll consume c-stack infinitely.
 */
typedef struct SgCStackRec
{
  struct SgCStackRec *prev;
  SgContFrame *cont;
  jmp_buf      jbuf;
} SgCStack;

typedef enum {
  SG_FULL_CONTINUATION,
  SG_COMPOSABLE_CONTINUATION,
  SG_DELIMIETED_CONTINUATION
} SgContType;

typedef struct SgContMarksRec SgContMarks;

typedef struct SgContinucationRec
{
  struct SgContinucationRec * prev;
  struct SgContinucationRec * floating;
  SgContFrame *cont;
  SgObject     winders;
  SgCStack    *cstack;
  SgObject     ehandler;
  SgObject     xhandler;
  int          errorReporting;
  int          rewindBefore;
  SgContType   type;
  SgContMarks *marks;
} SgContinuation;

#define SG_CONTINUATION(obj)  ((SgContinuation*)obj)
#define SG_VM_FLOATING_EP(vm)			\
  ((vm)->escapePoint? (vm)->escapePoint->floating : (vm)->escapePointFloating)
#define SG_VM_FLOATING_EP_SET(vm, ep)		\
  do {						\
    if ((vm)->escapePoint) {			\
      (vm)->escapePoint->floating = (ep);	\
    } else {					\
      (vm)->escapePointFloating = (ep);		\
    }						\
  } while (0)


typedef struct SgVMProfilerRec SgVMProfiler;

typedef enum {
  COMPILING,
  COMPILED,
  RUNNING,
  IMPORTING,
  FINISHED
} SgVMState;

typedef enum {
  SG_VM_ESCAPE_NONE,
  SG_VM_ESCAPE_CONT,
  SG_VM_ESCAPE_ERROR,
  SG_VM_ESCAPE_RAISE,
  SG_VM_ESCAPE_ABORT
} SgVMEscapeReason;

enum {
  SG_VM_NEW,			/* This VM is just created and not attached
				   to the running thread. */
  SG_VM_RUNNABLE,		/* This VM is attached to a thread which is
				   runnable or blocked. */
  SG_VM_STOPPED,		/* The thread attached to this VM is stopped
				   by the inspector thread for debugging*/
  SG_VM_TERMINATED		/* The thread attached to this VM is
				   terminated. */
};

enum {
  SG_VM_REQUEST_SUSPEND = 1L,
  SG_VM_REQUEST_TERMINATE = 2L,
};

enum {
  SG_ERROR_BEING_HANDLED  = (1L << 0),
  SG_ERROR_BEING_REPORTED = (1L << 1)
};

#define SG_VM_RUNTIME_FLAG_IS_SET(vm, flag) ((vm)->runtimeFlags & (flag))
#define SG_VM_RUNTIME_FLAG_SET(vm, flag)    ((vm)->runtimeFlags |= (flag))
#define SG_VM_RUNTIME_FLAG_CLEAR(vm, flag)  ((vm)->runtimeFlags &= ~(flag))

#define DEFAULT_VALUES_SIZE 32

typedef struct values_buffer_t
{
  int buffer_size;
  SgObject values_buffer[1];
} SgValuesBuffer;

#define SG_ALLOC_VALUES_BUFFER(vm, size)				\
  do {									\
    (vm)->extra_values =						\
      SG_NEW2(SgValuesBuffer*,						\
	      sizeof(SgValuesBuffer)+sizeof(SgObject)*((size)-1));	\
    (vm)->extra_values->buffer_size = (size);				\
  } while (0)

#define SG_VALUES_REF(vm, i)						\
  (((i) < DEFAULT_VALUES_SIZE)						\
   ? (vm)->values[i]							\
   : (vm)->extra_values->values_buffer[(i)-DEFAULT_VALUES_SIZE])

#define SG_VALUES_SET(vm, i, v)						\
  do {									\
    if ((i) < DEFAULT_VALUES_SIZE) {					\
      (vm)->values[i] = (v);						\
    } else {								\
      (vm)->extra_values->values_buffer[(i)-DEFAULT_VALUES_SIZE] = (v);	\
    }									\
  } while (0)

/* A prompt will be installed in a PC of cont frame */
typedef struct SgPromptRec
{
  SgObject tag;
  SgObject handler;
  SgCStack *cstack;
  SgObject winders;
  int      barrierP;
} SgPrompt;
/* deque of prompt
   installation -> prepend
   splice -> append
*/
typedef struct SgPromptNodeRec
{
  SgPrompt        *prompt;
  SgContFrame     *frame;
  struct SgPromptNodeRec *next;
} SgPromptNode;

typedef struct SgMarkEntryRec {
  SgObject key;
  SgObject value;
  struct SgMarkEntryRec *next;
} SgMarkEntry;

struct SgContMarksRec {
  SgContFrame *frame;
  SgMarkEntry *entries;
  struct SgContMarksRec *prev;
};

typedef struct {
  SG_HEADER;
  SgObject     before;
  SgObject     after;
  SgContMarks *marks;		/* winder needs to restore marks separately */
} SgDynamicWinder;

#define SG_DYNAMIC_WINDER(o)  ((SgDynamicWinder *)o)
#define SG_DYNAMIC_WINDERP(o) SG_XTYPEP(o, SG_CLASS_DYNAMIC_WINDER)
#define SG_DYNAMIC_WINDER_BEFORE(w)  (SG_DYNAMIC_WINDER(w)->before)
#define SG_DYNAMIC_WINDER_AFTER(w)   (SG_DYNAMIC_WINDER(w)->after)
#define SG_DYNAMIC_WINDER_MARKS(w)   (SG_DYNAMIC_WINDER(w)->marks)

struct SgVMRec
{
  SG_HEADER;
  SgInternalThread thread;	/* the system thread executing this VM. */
  unsigned int threadErrorP: 1;	/* if thread ended with exception or not */
  unsigned int threadState: 31;	/* thread state. */
  SgInternalMutex  vmlock;	/* mutex to be used to lock this VM. */
  SgInternalCond   cond;
  SgVM *canceller;
  SgVM *inspector;
  SgObject name;		/* Scheme thread name. */
  SgObject specific;		/* Scheme thread specific data. */
  SgProcedure *thunk;		/* Entry point of this VM */
  SgObject result;		/* thread result */

  unsigned int flags;		/* flags */
  unsigned int runtimeFlags;	/* flags for runtime */
  /* Registers */
  SgWord   *pc;			/* program counter */
  SgObject  ac;			/* accumelator */
  SgObject  cl;			/* current closure */
  SgObject *fp;			/* frame pointer */
  SgObject *sp;			/* stack pointer */
  SgContFrame  *cont;     	/* saved continuation frame */
  SgContMarks  *marks;		/* continuation marks */
  SgPromptNode *prompts;	/* prompt chain, this is the top */
  /* values buffer */
  int      valuesCount;
  SgObject values[DEFAULT_VALUES_SIZE];
  SgValuesBuffer *extra_values;

  /*
     load path
   */
  SgObject loadPath;
  SgObject dynamicLoadPath;
  /*
    Stack:
   */
  SgObject  *stack;		/* for convenient */
  SgObject  *stackEnd;

  /* Ports */
  SgPort    *currentOutputPort;
  SgPort    *currentInputPort;
  SgPort    *currentErrorPort;
  SgPort    *logPort;		/* it's not often used.. */

  /* return point */
  SgCStack  *cstack;
  SgContinuation *escapePoint;
  SgContinuation *escapePointFloating;
  SgVMEscapeReason escapeReason;
  void      *escapeData[2];

#ifdef HAVE_JIT
  /* JIT context for exception recovery and re-entry.
   * When JIT code calls C helpers that might throw exceptions,
   * we need to save the JIT register state so it can be restored
   * after longjmp bypasses the JIT epilogue.
   *
   * When JIT yields for a CALL instruction, returnAddr stores the
   * native code address to re-enter after the callee returns.
   */
  struct {
    int       active;           /* Is JIT code currently executing? */
    SgObject *savedSp;          /* Saved Scheme stack pointer */
    SgObject *savedFp;          /* Saved Scheme frame pointer */
    SgObject  savedCl;          /* Saved current closure */
    intptr_t  savedDepth;       /* Saved recursion depth (64-bit for JIT asm access) */
    void     *returnAddr;       /* JIT re-entry address after CALL yield */
  } jitContext;
#endif

  /* libraries */
  SgObject   currentLibrary;
  /* dynamic winders */
  SgObject   dynamicWinders;
  /*
     exception handlers
     this is a list of procedures
   */
  SgObject   exceptionHandlers;

  /* parameters */
  SgObject   parameters;

  /* gc related */
  int finalizerPending;
  int attentionRequest;
  int stopRequest;

  /* statistics */
  SgVMState state;
  int profilerRunning;
  SgVMProfiler *profiler;

  /* temporary storage for compiled cache
     storage structure:
     ((#<code-builder> ...)
      (#<code-builder> ...)
      ...)
     compiled codes are always appended the first list.
     when importing a library, first list will be appended.
   */
  SgObject cache;
  /* Sandbox is a hashtable which contains replaced binding.
     if it's not available then #f is set. */
  SgObject sandbox;
  SgObject kernel;		/* Kernel of this VM */
};

/*
  flag 32bit
  log level optimization reader/mode   misc(cache)
  00000000   00000000     00000000    00000000
 */
typedef enum {
  /* cache mode */
  SG_DISABLE_CACHE       = 0x00000001,
  SG_NO_DEBUG_INFO       = 0x00000002,
  SG_CACHE_MASK          = 0x000000FF,
  /* reader mode */
  SG_R6RS_MODE           = 0x00000100, /* 00000001 */
  SG_COMPATIBLE_MODE     = 0x00000200, /* 00000010 */
  SG_R7RS_MODE           = 0x00000400, /* 00000100 */
  SG_DEPRECATED_FILE     = 0x00001000,
  SG_DISABLE_FILE_CACHE  = 0x00002000, /* for #!nocache */

  /* optimization */
  SG_NO_INLINE_ASM       = 0x00010000,
  SG_NO_INLINE_LOCAL     = 0x00020000,
  SG_NO_LAMBDA_LIFT      = 0x00040000,
  SG_NO_LIBRARY_INLINING = 0x00080000,
  SG_NO_CONST_INLINING   = 0x00100000,
  SG_ALLOW_OVERWRITE     = 0x00200000,
  SG_ERROR_UNBOUND       = 0x00400000,
  /* log level */
  SG_FATAL_LEVEL         = 0x01000000,
  SG_ERROR_LEVEL         = 0x02000000,
  SG_WARN_LEVEL          = 0x04000000,
  SG_INFO_LEVEL          = 0x08000000,
  SG_DEBUG_LEVEL         = 0x10000000,
  SG_TRACE_LEVEL         = 0x20000000,
  SG_LOG_LEVEL_MASK      = 0xff000000,

} VMFlags;

#define SG_VM(obj) ((SgVM *)obj)
#define SG_VMP(obj) SG_XTYPEP(obj, SG_CLASS_VM)

#define SG_VM_SET_FLAG(vm, flag)    ((vm)->flags = ((vm)->flags | (flag)))
#define SG_VM_UNSET_FLAG(vm, flag)  ((vm)->flags = ((vm)->flags & (~(flag))))
#define SG_VM_IS_SET_FLAG(vm, flag) (((vm)->flags & (flag)))

#define SG_VM_LOG_LEVEL(vm, level)  (((vm)->flags & SG_LOG_LEVEL_MASK) >= level)

#define SG_CCONT_DATA_SIZE 10

#define SG_LET_FRAME_SIZE           2
#define SG_FRAME_SIZE               CONT_FRAME_SIZE


/* from Gauche */
/* Unwind protect */
#define SG_UNWIND_PROTECT			\
  do {						\
    SgCStack cstack;				\
    cstack.prev = Sg_VM()->cstack;		\
    cstack.cont = NULL;				\
    Sg_VM()->cstack = &cstack;			\
    if (setjmp(cstack.jbuf) == 0) {

#define SG_WHEN_ERROR				\
    } else {

#define SG_NEXT_HANDLER					\
      do {						\
	if (Sg_VM()->cstack->prev) {			\
	  Sg_VM()->cstack = Sg_VM()->cstack->prev;	\
	  longjmp(Sg_VM()->cstack->jbuf, 1);		\
	}						\
	else Sg_Exit(1);				\
      } while (0)

#define SG_END_PROTECT				\
    }						\
    Sg_VM()->cstack = Sg_VM()->cstack->prev;	\
  } while (0)

typedef enum {
  SG_STACK_TRACE_SOURCE    = 0x0001, /* source location */
  SG_STACK_TRACE_ARGUMENTS = 0x0002,  /* arguments */
  SG_STACK_TRACE_ALL       = SG_STACK_TRACE_SOURCE | SG_STACK_TRACE_ARGUMENTS
} SgVMStackTraceInfo;


SG_CDECL_BEGIN

SG_EXTERN SgVM*    Sg_NewVM(SgVM *proto, SgObject name);
SG_EXTERN SgVM*    Sg_NewThreadVM(SgVM *proto, SgObject name);
SG_EXTERN SgVM*    Sg_SetVMStack(SgVM *vm, SgObject *stack, int stackSize);
SG_EXTERN SgObject Sg_Compile(SgObject sexp, SgObject env);
SG_EXTERN SgObject Sg_Apply(SgObject proc, SgObject args);
SG_EXTERN SgObject Sg_Apply0(SgObject proc);
SG_EXTERN SgObject Sg_Apply1(SgObject proc, SgObject arg);
SG_EXTERN SgObject Sg_Apply2(SgObject proc, SgObject arg0, SgObject arg1);
SG_EXTERN SgObject Sg_Apply3(SgObject proc, SgObject arg0, SgObject arg1, SgObject arg2);
SG_EXTERN SgObject Sg_Apply4(SgObject proc, SgObject arg0, SgObject arg1, SgObject arg2, SgObject arg3);
SG_EXTERN SgObject Sg_VMApply0(SgObject proc);
SG_EXTERN SgObject Sg_VMApply1(SgObject proc, SgObject arg);
SG_EXTERN SgObject Sg_VMApply2(SgObject proc, SgObject arg0, SgObject arg1);
SG_EXTERN SgObject Sg_VMApply3(SgObject proc, SgObject arg0, SgObject arg1, SgObject arg2);
SG_EXTERN SgObject Sg_VMApply4(SgObject proc, SgObject arg0, SgObject arg1, SgObject arg2, SgObject arg3);
SG_EXTERN SgObject Sg_VMApply(SgObject proc, SgObject args);
SG_EXTERN SgObject Sg_VMCallCC(SgObject proc);
/* call-with-continuation-prompt */
SG_EXTERN SgObject Sg_VMCallCP(SgObject proc, SgObject tag,
			       SgObject handler, SgObject args);
/* call-with-continuation-barrier */
SG_EXTERN SgObject Sg_VMCallCB(SgObject thunk);
/* call-with-continuation-mark */
SG_EXTERN SgObject Sg_VMCallCM(SgObject entries, SgObject thunk);
/* call-with-immediate-continuation-mark */
SG_EXTERN SgObject Sg_VMCallImmediateCM(SgObject key, SgObject proc,
					SgObject fallback);
SG_EXTERN SgObject Sg_VMCallComp(SgObject proc, SgObject tag);
SG_EXTERN SgObject Sg_VMCallDelimitedCC(SgObject proc, SgObject tag);
SG_EXTERN SgObject Sg_VMAbortCC(SgObject tag, SgObject args);
SG_EXTERN SgObject Sg_VMCallInCont(SgContinuation *c, SgPrompt *prompt, SgObject proc, SgObject args);
SG_EXTERN SgObject Sg_VMCallInInitialCont(SgObject thunk);
SG_EXTERN SgObject Sg_MakeContinuationPromptTag(SgObject name);
SG_EXTERN int      Sg_ContinuationP(SgObject o);
SG_EXTERN int      Sg_ComposableContinuationP(SgObject o);
SG_EXTERN int      Sg_ContinuationPromptAvailableP(SgObject tag, SgObject cont);
SG_EXTERN int      Sg_ContinuationMarkSetP(SgObject o);
SG_EXTERN SgObject Sg_ContinuationMarks(SgObject k, SgObject promptTag);
SG_EXTERN SgObject Sg_CurrentContinuationMarks(SgObject promptTag);
SG_EXTERN SgMarkEntry * Sg_FirstContinuationMark(SgObject k, SgObject promptTag,
						 SgObject key);
SG_EXTERN SgMarkEntry * Sg_CurrentFirstContinuationMark(SgObject promptTag,
							SgObject key);
SG_EXTERN SgObject Sg_CurrentExceptionHandlersMark();

#ifdef HAVE_JIT
/* JIT continuation mark support */
SG_EXTERN void  Sg_JitPushContMarks(SgVM *vm, SgContFrame *cont);
SG_EXTERN void  Sg_JitSetReturnMark(SgVM *vm, void *returnAddr);
SG_EXTERN void* Sg_JitGetReturnMark(SgVM *vm);
SG_EXTERN void* Sg_JitGetReturnMarkForCont(SgVM *vm, SgContFrame *cont);
SG_EXTERN void  Sg_JitPopContMarks(SgVM *vm, SgContFrame *cont);
SG_EXTERN void  Sg__InitJitMarks(void);
#endif

SG_EXTERN SgVM*    Sg_VM();	/* get vm */
SG_EXTERN int      Sg_SetCurrentVM(SgVM *vm);
SG_EXTERN int      Sg_AttachVM(SgVM *vm);
SG_EXTERN void     Sg_VMDumpCode(SgCodeBuilder *cb);

SG_EXTERN SgObject Sg_AddLoadPath(SgString *path, int appendP);
SG_EXTERN SgObject Sg_AddDynamicLoadPath(SgString *path, int appendP);

/* eval */
SG_EXTERN SgObject Sg_Eval(SgObject sexp, SgObject env);
SG_EXTERN SgObject Sg_VMEval(SgObject sexp, SgObject env);
SG_EXTERN SgObject Sg_Environment(SgObject lib, SgObject spec);
SG_EXTERN SgObject Sg_VMEnvironment(SgObject lib, SgObject spec);

/* dynamic-wind */
SG_EXTERN void     Sg_VMPushCC(SgCContinuationProc *after, void **data, int datasize);
/* only for internal use, e.g. stub generation */
SG_EXTERN SgObject* Sg__VMPushCC(SgCContinuationProc *after, int datasize);
SG_EXTERN SgObject Sg_VMDynamicWind(SgObject before, SgObject thunk, SgObject after);
/* c-friendly wrapper from Gauche */
SG_EXTERN SgObject Sg_VMDynamicWindC(SgSubrProc *before, SgSubrProc *body, SgSubrProc *after, void *data);

/* IO */
SG_EXTERN SgObject Sg_CurrentOutputPort();
SG_EXTERN SgObject Sg_CurrentErrorPort();
SG_EXTERN SgObject Sg_CurrentInputPort();
SG_EXTERN SgObject Sg_CurrentLogPort();

SG_EXTERN void Sg_SetCurrentOutputPort(SgObject p);
SG_EXTERN void Sg_SetCurrentErrorPort(SgObject p);
SG_EXTERN void Sg_SetCurrentInputPort(SgObject p);
SG_EXTERN void Sg_SetCurrentLogPort(SgObject p);

SG_EXTERN SgObject Sg_VMCurrentLibrary();

/* exception */
SG_EXTERN SgObject Sg_VMGetStackTraceOf(SgVM *vm, SgVMStackTraceInfo flags, int framesToSkip);
SG_EXTERN SgObject Sg_VMThrowException(SgVM *vm, SgObject exception,
				       int continuableP);
SG_EXTERN void     Sg_VMDefaultExceptionHandler(SgObject exception);
SG_EXTERN SgObject Sg_VMWithErrorHandler(SgObject handler, SgObject thunk,
					 int rewindBefore);
SG_EXTERN void     Sg_ReportError(SgObject e, SgObject out);
SG_EXTERN void     Sg_ReportErrorInternal(SgObject e, SgObject out);
/* pretty printer for stack trace */
SG_EXTERN void     Sg_FormatStackTrace(SgObject e, SgObject out);

/* finalizer */
SG_EXTERN SgObject Sg_VMFinalizerRun(SgVM *vm);

/* debuging */
SG_EXTERN void     Sg_VMPrintFrameOf(SgVM *vm);

/* root? */
SG_EXTERN int      Sg_MainThreadP();
SG_EXTERN int      Sg_RootVMP(SgVM *vm);

/* values */
SG_EXTERN SgObject Sg_VMValues(SgVM *vm, SgObject args);
SG_EXTERN SgObject Sg_VMValues2(SgVM *vm, SgObject v1, SgObject v2);
SG_EXTERN SgObject Sg_VMValues3(SgVM *vm, SgObject v1,
				SgObject v2, SgObject v3);
SG_EXTERN SgObject Sg_VMValues4(SgVM *vm, SgObject v1,
				SgObject v2, SgObject v3, SgObject v4);
SG_EXTERN SgObject Sg_VMValues5(SgVM *vm, SgObject v1,
				SgObject v2, SgObject v3, SgObject v4,
				SgObject v5);

SG_EXTERN void Sg_VMAcquireGlobalLock();
SG_EXTERN void Sg_VMReleaseGlobalLock();

SG_EXTERN void Sg_EnableSandbox();
SG_EXTERN void Sg_DisableSandbox();

SG_EXTERN SgObject Sg_VMAttachStackTrace(SgVM *vm, SgObject condition,
					 int skipTop);

/* it would be too dangerous to exporse */
/* SG_EXTERN SgObject Sg_RootVM(); */

SG_CDECL_END

#endif /* SAGITTARIUS_VM_H_ */
/*
  end of file
  Local Variables:
  coding: utf-8-unix
  End:
*/
