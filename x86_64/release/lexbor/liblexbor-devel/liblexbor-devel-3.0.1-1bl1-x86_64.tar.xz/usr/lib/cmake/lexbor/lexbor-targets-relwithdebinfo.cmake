#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "lexbor::lexbor" for configuration "RelWithDebInfo"
set_property(TARGET lexbor::lexbor APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(lexbor::lexbor PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/liblexbor.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cyglexbor-3.dll"
  )

list(APPEND _cmake_import_check_targets lexbor::lexbor )
list(APPEND _cmake_import_check_files_for_lexbor::lexbor "${_IMPORT_PREFIX}/lib/liblexbor.dll.a" "${_IMPORT_PREFIX}/bin/cyglexbor-3.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
