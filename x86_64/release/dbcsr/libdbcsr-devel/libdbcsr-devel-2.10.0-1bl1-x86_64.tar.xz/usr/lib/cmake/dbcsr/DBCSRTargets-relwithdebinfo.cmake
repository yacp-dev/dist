#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "DBCSR::dbcsr" for configuration "RelWithDebInfo"
set_property(TARGET DBCSR::dbcsr APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(DBCSR::dbcsr PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libdbcsr.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygdbcsr-2.10.dll"
  )

list(APPEND _cmake_import_check_targets DBCSR::dbcsr )
list(APPEND _cmake_import_check_files_for_DBCSR::dbcsr "${_IMPORT_PREFIX}/lib/libdbcsr.dll.a" "${_IMPORT_PREFIX}/bin/cygdbcsr-2.10.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
