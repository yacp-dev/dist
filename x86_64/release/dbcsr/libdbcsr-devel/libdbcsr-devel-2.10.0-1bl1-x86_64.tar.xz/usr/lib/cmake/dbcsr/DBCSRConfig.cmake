
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was DBCSRConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

# Use original install prefix when loaded through a "/usr move"
# cross-prefix symbolic link such as /lib -> /usr/lib.
get_filename_component(_realCurr "${CMAKE_CURRENT_LIST_DIR}" REALPATH)
get_filename_component(_realOrig "/usr/lib/cmake/dbcsr" REALPATH)
if(_realCurr STREQUAL _realOrig)
  set(PACKAGE_PREFIX_DIR "/usr")
endif()
unset(_realOrig)
unset(_realCurr)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

include(CMakeFindDependencyMacro)

# Hints for locating DBCSR's dependencies (override with your own -D flags)
set(DBCSR_LIBXSROOT "")
set(DBCSR_LIBXSTREAMROOT "")
set(DBCSR_LIBXSMMROOT "")

# Make DBCSR's dependency locations discoverable
set(_dbcsr_prefix_path_save "${CMAKE_PREFIX_PATH}")
if (DBCSR_LIBXSROOT)
  list(PREPEND CMAKE_PREFIX_PATH "${DBCSR_LIBXSROOT}")
endif ()
if (DBCSR_LIBXSTREAMROOT)
  list(PREPEND CMAKE_PREFIX_PATH "${DBCSR_LIBXSTREAMROOT}")
endif ()
if (DBCSR_LIBXSMMROOT)
  list(PREPEND CMAKE_PREFIX_PATH "${DBCSR_LIBXSMMROOT}")
endif ()

set(DBCSR_USE_MPI OFF)
if (OFF)
  find_dependency(MPI)
endif ()

set(DBCSR_USE_OPENMP ON)
if (ON)
  find_dependency(OpenMP)
endif ()

set(DBCSR_USE_LIBXS OFF)
if (OFF)
  find_dependency(libxs CONFIG REQUIRED)
endif ()

set(DBCSR_USE_LIBXSMM OFF)
if (OFF)
  find_dependency(libxsmm CONFIG QUIET)
  if (NOT libxsmm_FOUND)
    find_dependency(PkgConfig)
    pkg_check_modules(DBCSR_LIBXSMM_PC QUIET IMPORTED_TARGET GLOBAL libxsmm)
    if (DBCSR_LIBXSMM_PC_FOUND AND NOT TARGET libxsmm::libxsmm)
      add_library(libxsmm::libxsmm ALIAS PkgConfig::DBCSR_LIBXSMM_PC)
    endif ()
  endif ()
endif ()

set(DBCSR_USE_ACCEL none)
if ("none" MATCHES "cuda")
  enable_language(CUDA)
  find_dependency(CUDAToolkit)
endif ()

if ("none" MATCHES "hip")
  enable_language(HIP)
  find_dependency(hip)
  find_dependency(hipblas)
  find_dependency(hiprtc)
endif ()

if ("none" MATCHES "opencl")
  find_dependency(OpenCL)
  find_dependency(libxstream CONFIG QUIET)
  if (NOT libxstream_FOUND)
    find_dependency(PkgConfig)
    pkg_check_modules(DBCSR_LIBXSTREAM_PC QUIET IMPORTED_TARGET GLOBAL libxstream)
    if (DBCSR_LIBXSTREAM_PC_FOUND AND NOT TARGET libxstream::libxstream)
      add_library(libxstream::libxstream ALIAS PkgConfig::DBCSR_LIBXSTREAM_PC)
    endif ()
  endif ()
endif ()

set(CMAKE_PREFIX_PATH "${_dbcsr_prefix_path_save}")
unset(_dbcsr_prefix_path_save)

include("${CMAKE_CURRENT_LIST_DIR}/DBCSRTargets.cmake")
