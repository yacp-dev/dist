#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "capstone::capstone_shared" for configuration "RelWithDebInfo"
set_property(TARGET capstone::capstone_shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(capstone::capstone_shared PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libcapstone.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygcapstone-5.dll"
  )

list(APPEND _cmake_import_check_targets capstone::capstone_shared )
list(APPEND _cmake_import_check_files_for_capstone::capstone_shared "${_IMPORT_PREFIX}/lib/libcapstone.dll.a" "${_IMPORT_PREFIX}/bin/cygcapstone-5.dll" )

# Import target "capstone::cstool" for configuration "RelWithDebInfo"
set_property(TARGET capstone::cstool APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(capstone::cstool PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cstool.exe"
  )

list(APPEND _cmake_import_check_targets capstone::cstool )
list(APPEND _cmake_import_check_files_for_capstone::cstool "${_IMPORT_PREFIX}/bin/cstool.exe" )

# Import target "capstone::cstest" for configuration "RelWithDebInfo"
set_property(TARGET capstone::cstest APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(capstone::cstest PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cstest.exe"
  )

list(APPEND _cmake_import_check_targets capstone::cstest )
list(APPEND _cmake_import_check_files_for_capstone::cstest "${_IMPORT_PREFIX}/bin/cstest.exe" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
