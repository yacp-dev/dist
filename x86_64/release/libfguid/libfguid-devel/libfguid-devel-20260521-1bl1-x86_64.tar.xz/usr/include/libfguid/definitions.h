/*
 * Definitions for libfguid
 *
 * Copyright (C) 2010-2026, Joachim Metz <joachim.metz@gmail.com>
 *
 * Refer to AUTHORS for acknowledgements.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#if !defined( _LIBFGUID_DEFINITIONS_H )
#define _LIBFGUID_DEFINITIONS_H

#include <libfguid/types.h>

#define LIBFGUID_VERSION					20260521

/* The version string
 */
#define LIBFGUID_VERSION_STRING					"20260521"

/* The byte order definitions
 */
enum LIBFGUID_ENDIAN
{
	LIBFGUID_ENDIAN_BIG					= (int) 'b',
	LIBFGUID_ENDIAN_LITTLE					= (int) 'l'
};

/* The GUID identifier version definitions
 */
enum LIBFGUID_IDENTIFIER_VERSIONS
{
	LIBFGUID_IDENTIFIER_VERSION_TIME_BASED			= 1,
	LIBFGUID_IDENTIFIER_VERSION_DCE				= 2,
	LIBFGUID_IDENTIFIER_VERSION_NAME_BASED			= 3,
	LIBFGUID_IDENTIFIER_VERSION_RANDOM_BASED		= 4
};

/* The string format definition flags
 */
enum LIBFGUID_STRING_FORMAT_FLAGS
{
	/* Format the using lower case
	 */
	LIBFGUID_STRING_FORMAT_FLAG_USE_LOWER_CASE		= 0x00000001UL,

	/* Format the using upper case
	 */
	LIBFGUID_STRING_FORMAT_FLAG_USE_UPPER_CASE		= 0x00000002UL,

	/* Format the using mixed case
	 */
	LIBFGUID_STRING_FORMAT_FLAG_USE_MIXED_CASE		= 0x00000003UL,

	/* Format the using surrounding braces { GUID }
	 */
	LIBFGUID_STRING_FORMAT_FLAG_USE_SURROUNDING_BRACES	= 0x00000004UL
};

#endif /* !defined( _LIBFGUID_DEFINITIONS_H ) */

