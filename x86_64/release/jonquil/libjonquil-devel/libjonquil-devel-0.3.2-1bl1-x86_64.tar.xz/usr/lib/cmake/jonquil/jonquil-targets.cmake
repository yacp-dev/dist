set(CMAKE_IMPORT_FILE_VERSION 1)

set(
  JONQUIL_INCLUDEDIRS
  "/usr/include"
  "/usr/include/jonquil/modules"
)
find_library(
  JONQUIL_LIBRARIES
  "jonquil"
  PATHS "/usr/lib"
  NO_DEFAULT_PATH
)
set(
  JONQUIL_DEPENDENCIES
  "$<$<BOOL:${JONQUIL_USE_TOMLF}>:toml-f::toml-f>"
)

add_library(jonquil::jonquil-lib INTERFACE IMPORTED)
add_library(jonquil::jonquil ALIAS jonquil::jonquil-lib)
target_link_libraries(jonquil::jonquil-lib INTERFACE ${JONQUIL_LIBRARIES} ${JONQUIL_DEPENDENCIES})
target_include_directories(jonquil::jonquil-lib INTERFACE ${JONQUIL_INCLUDEDIRS})
