#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "uvwasi::uvwasi" for configuration "RelWithDebInfo"
set_property(TARGET uvwasi::uvwasi APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(uvwasi::uvwasi PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libuvwasi.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cyguvwasi-0.dll"
  )

list(APPEND _cmake_import_check_targets uvwasi::uvwasi )
list(APPEND _cmake_import_check_files_for_uvwasi::uvwasi "${_IMPORT_PREFIX}/lib/libuvwasi.dll.a" "${_IMPORT_PREFIX}/bin/cyguvwasi-0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
