# wolfSSL Release 5.9.4 (Sep 25, 2026)

Release 5.9.4 has been developed according to wolfSSL's development and QA
process (see link below) and successfully passed the quality criteria.
https://www.wolfssl.com/about/wolfssl-software-development-process-quality-assurance

NOTE:
* liboqs is no longer used for any algorithm: Falcon now has a native wolfCrypt implementation, and the liboqs dependency and its configure and CMake options have been removed (see PQC below).
* Certificates carrying trailing bytes after the DER structure are now rejected unless `WOLFSSL_NO_ASN_STRICT` is defined; only the certificate itself is copied into `WOLFSSL_X509`.
* ABI: `struct OcspRequest` (exported as `OCSP_REQUEST`) loses its trailing `ssl` pointer; consumers that embed the struct must be rebuilt.
* Under FIPS: HMAC-MD5 is rejected, AES-GCM encryption with an IV shorter than 12 bytes returns `FIPS_BAD_VALUE_E` (override with `WC_FIPS_AESGCM_ALLOW_SHORT_NONCES`), the CMAC minimum tag is 64 bits, and RSA-PSS salts longer than the hash are refused (FIPS 186-5). `--enable-wolfclu` no longer enables MD5, Ed25519 or ASN relaxation on FIPS builds.

PR stands for Pull Request, and PR <NUMBER> references a GitHub pull request number where the code change was added.

## Vulnerabilities

* [High] CVE-2026-93302
MatchTrustedPeer ignores the public key used, leading to forged CA clones passing verification. Affected builds are any that enable the macro WOLFSSL_TRUST_PEER_CERT and load CA certificates with wolfSSL_CTX_trust_peer_cert() or wolfSSL_trust_peer_cert(). The peer must know the certificates being loaded to either of those APIs to take advantage of the issue. When OPENSSL_COMPATIBLE_DEFAULTS is also defined this widens the affected API to include all CA certificate loading. Both macros are defined when using autoconf builds such as (nginx, haproxy, stunnel, wpas, apache httpd, hitch, bind, rsyslog, ffmpeg, all, distro). When the certificate is listed as a trusted peer certificate the issue previously allowed for a malicious (D)TLS server to bypass authentication once knowing which CA’s the client would accept. This also affects mutual authentication cases where the client knows which CA’s the server has loaded. If building with any of these configurations and using (D)TLS where the loaded CA’s could be known and authentication of the peer is desired, users should either: update to the latest wolfSSL version, apply the fix patch, or use the configure flag --disable-openssl-compatible-defaults and not load CA’s with wolfSSL_CTX_trust_peer_cert() or wolfSSL_trust_peer_cert() to mitigate the issue. The affected certificate verification path with (D)TLS is in wolfSSL versions 5.3.0 to 5.9.2. Found via the Anthropic OSS program.
Fixed in commit https://github.com/wolfSSL/wolfssl/commit/22bcd51d553eaac1de37bee91fdac80cc47961e1

* [High] CVE-2026-89102
In wolfSSL versions 5.7.2 through 5.9.2 there is a client-side implementation flaw in RFC 6961, multiple OCSP response stapling, which can lead to certificate forgery. When a wolfSSL client enables OCSP stapling with the HAVE_CERTIFICATE_STATUS_REQUEST_V2 feature and calls wolfSSL_UseOCSPStaplingV2(ssl, WOLFSSL_CSR2_OCSP_MULTI, options), the client accepts any certificate in the peer's chain as a certificate authority without verifying that the certificate is actually authorized to act as one. This means that an attacker who possesses any certificate that chains to a CA trusted by the client (along with its private key) can forge certificates for arbitrary identities that will be accepted as valid by the client. The end entity certificate of the server is stored in the persistent trust store, affecting subsequent connections that reuse the context even when OCSP multi usage is not employed. Found by internal wolfSSL testing.
Fixed in PR 11027

* [High] CVE-2026-89136
When using RPK (Raw Public Key), the client side of a TLS 1.2, 1.3 and DTLS 1.2 connection could accept an unsolicited server_cert_type=RawPublicKey which allowed a malicious or misbehaving server to bypass authentication. RPK is off by default and only enabled in --enable-rpk OR --enable-all OR --enable-distro AKA HAVE_RPK builds. This affects versions 5.6.0 to 5.9.2. Thanks to Christos Papakonstantinou (Cantina Security) for the report.
Fixed in PR 11009

* [Medium] CVE-2026-93304
A (D)TLS 1.2 client can accept a ChangeCipherSpec message before it has sent its ClientKeyExchange. No master secret has been derived at that point, so the client installs read keys derived from a known (deterministic) key and checks the server's Finished against that same key. An out-of-order ChangeCipherSpec can therefore be used by an attacker to complete the handshake in place of the server and send data the client accepts as authentic. The client's own traffic still uses correctly derived keys, so the attacker cannot read it, and the genuine server never completes the handshake. DTLS 1.2 clients are exposed because a datagram read can deliver the out-of-order records on its own. TLS 1.2 clients are exposed when the application supplies received bytes with wolfSSL_inject() or enables read ahead. For certificate suites, the attacker must be in a man-in-the-middle position. For PSK (Pre Shared Key) connections, any fake server can succeed without knowing the PSK. The affected versions of wolfSSL are from 4.7.0 to 5.9.2. Found via the Anthropic OSS program.
Fixed in PR 11458

* [Medium] CVE-2026-89133
wolfSSL versions 5.9.2 and earlier contain a flaw in the X.509 certificate validation logic where it fails to properly enforce NameConstraints extensions when there is an unconstrained CA tier between a name-constrained intermediate CA and the leaf certificate. wolfSSL incorrectly accepted certificates for hostnames they shouldn't be allowed to cover, due to a chain-walking state-machine bug that resets the validation state when encountering an intermediate without NameConstraints, thereby bypassing cryptographic delegation controls. This defect exists in the default build configuration that makes use of certificates where name constraint extensions are used. Thanks to Jack Lloyd, PathDiff, and Ben Smyth for reporting the issue.
Fixed in PR 10687

* [Medium] CVE-2026-89134
A certificate with no dNSName SAN but another SAN type present (e.g. registeredID or iPAddress) bypassed the Subject CN dNSName name-constraint check. The CN-as-DNS fallback was gated on cert->subjectCN != NULL && cert->altNames == NULL && !cert->isCA instead of "no dNSName SAN", so an out-of-scope CN was accepted. This incomplete fix from CVE-2026-6731, leading to the name-constraint check issue, was introduced in wolfSSL version 5.9.2. Thanks to Jorge Milla (Pig-Tail) for the report.
Fixed in PR 10837

* [Medium] CVE-2026-89135
A failed X509_verify_cert call permanently plants an unverified attacker CA in the shared CertManager, bypassing certificate validation in every type-blind sibling consumer (native TLS, OCSP, CRL, direct CM verify). This affects version 5.8.4 through 5.9.2 of wolfSSL with the macros (OPENSSL_EXTRA && !NO_CERTS && !WOLFCRYPT_ONLY) defined or built with --enable-opensslextra and the application is specifically making calls to the X509_verify_cert function. Thanks to Christos Papakonstantinou (Cantina Security) for the report.
Fixed in PR 11009

* [Low] CVE-2026-15442
In all builds that make use of (D)TLS, including default builds, there is a series of conditional states during the TLS shutdown which could lead to a heap-use-after free. If an application ended up getting a partial wolfSSL_read() which is sometimes caused by a small user buffer  passed in, then called wolfSSL_shutdown for a bidirectional close and attempted to wolfSSL_read() again while the peer continues trying to send data during the shutdown it would lead to a state where a potential heap-use-after free happened. This affects versions 4.4.0 through 5.9.2 of wolfSSL. Thanks to the Fuzz0x team for the report.
Fixed in PR 10863

* [Low] CVE-2026-94417
When an application enables both OCSP and CRL revocation checking on one WOLFSSL_CTX or certificate manager, wolfSSL skips the CRL check for any peer certificate that carries no Authority Information Access OCSP URL, and accepts a certificate the loaded CRL lists as revoked. The soft-fail policy for a missing responder collapses the OCSP result onto success before the code decides whether the CRL fallback is still needed, so "no responder exists" becomes indistinguishable from "the responder answered good". Affected builds define both HAVE_OCSP and HAVE_CRL: --enable-ocsp --enable-crl directly, and implicitly --enable-all, --enable-distro, --enable-curl, --enable-nginx, --enable-haproxy, --enable-stunnel, --enable-lighty, --enable-wpas, --enable-strongswan, --enable-mosquitto, --enable-jni, --enable-openvpn and --enable-krb. An application is affected only if it calls both wolfSSL_CTX_EnableOCSP() (or wolfSSL_EnableOCSP() / wolfSSL_CertManagerEnableOCSP()) and wolfSSL_CTX_EnableCRL() (or the equivalents) with a CRL loaded; an application that uses OCSP stapling alone through wolfSSL_CTX_EnableOCSPStapling() is not affected, because that sets up a separate OCSP instance. The defect sits in ProcessPeerCerts() and is reachable over TLS 1.0 through TLS 1.3 and DTLS, both on a client verifying a server certificate and on a server verifying a client certificate under mutual or post-handshake authentication. When the skipped check falls on a chain certificate rather than the leaf, the unchecked intermediate is promoted into the certificate manager and stays a trusted signer for every later connection on that context, so an affected long-running process needs its WOLFSSL_CTX torn down and not only its library replaced. All wolfSSL versions from 5.9.2 and earlier are affected; on versions 5.9.1 and 5.9.2 the WOLFSSL_OCSP_CHECKALL configuration fails closed with OCSP_NEED_URL, which leaves wolfSSL_CTX_EnableOCSP() without CHECKALL as the exposed configuration on 5.9.2. Found via the Anthropic OSS program.
Fixed in PR 11500

* [Low] CVE-2026-94418
Under WOLFSSL_SMALL_CERT_VERIFY, ProcessPeerCertParse() runs the certificate signature check separately from the parse to keep peak memory down, then merges the two results, but it merged the signature result back only when the parse returned 0, so any parse error hid it. ParseCertRelative() reaches its validity-date, name-constraint and critical-extension checks only after ConfirmSignature() has passed, so splitting the signature check out inverts the precedence that makes "override date errors" a sound policy, and ASN_SIG_CONFIRM_E is never surfaced anywhere. The attacker needs no key material from the real PKI and no CA compromise: a self-made certificate carrying the expected subject name, the trusted CA's subject as its issuer, arbitrary bytes where the signature goes, a validity window in the past and the attacker's own key pair is sufficient. Affected builds define WOLFSSL_SMALL_CERT_VERIFY, which is off by default, is not set implicitly by any platform or preset header, and is not reachable from any CMake option; the autotools routes are --enable-lowresource, --enable-leantls, --enable-tinytls13=cert and --enable-tinytls13=mutualauth, and examples/configs/user_settings_embedded.h reaches it through WC_CFG_SMALL_CERT_VERIFY, which ships as 0, while neither --enable-all nor --enable-distro enables it at all. The application must additionally install a verify callback through wolfSSL_CTX_set_verify() or wolfSSL_set_verify() with WOLFSSL_VERIFY_PEER that returns 1 for ASN_BEFORE_DATE_E or ASN_AFTER_DATE_E; wolfSSL ships this exact shape as myVerify() in wolfssl/test.h under VERIFY_OVERRIDE_DATE_ERR, which examples/client -D selects. An application with no callback, or whose callback returns preverify for date errors, still fails the handshake, and wolfSSL_CertManagerVerifyBuffer() and wc_CheckCertSignature() report ASN_SIG_CONFIRM_E correctly in the same binary. TLS 1.2 and TLS 1.3 are affected in both directions, and DTLS reaches the same function; where the forged certificate is a chain certificate the callback's consent causes it to be cached in the WOLFSSL_CTX certificate manager, so an exposed deployment must restart the context or the process rather than merely reconnect. Releases v3.15.5 through v5.9.2 are affected. Found via the Anthropic OSS program.
Fixed in PR 11500

* [Low] CVE-2026-94419
Without NO_SESSION_CACHE_REF, wolfSSL_get_session() does not return a session object but a ClientSession reference of the form {row, index, hash(sessionID)} into the process-global SessionCache, and ClientSessionToSession() validates it against that hash alone. Because the TLS 1.2 session ID is chosen by the server and sent in clear, AddSessionToCache() matches any other server's session on the same ID and overwrites the client-side entry with that server's master secret, cipher suite and version, while the handle continues to resolve; nothing on the write path compares the peer, the application's server ID or the WOLFSSL_CTX. Resuming through the handle then produces an abbreviated handshake in which no Certificate message is sent, so neither chain verification nor wolfSSL_check_domain_name() runs, and the attacker is accepted as the original server for the whole of that connection. Affected builds are those leaving NO_SESSION_CACHE_REF, NO_SESSION_CACHE, NO_CLIENT_CACHE and TITAN_SESSION_CACHE all undefined, which includes a plain ./configure, --enable-opensslextra and --enable-opensslall; fifteen integration options define NO_SESSION_CACHE_REF and are therefore not affected, among them --enable-all, --enable-distro, --enable-curl, --enable-nginx, --enable-haproxy, --enable-stunnel, --enable-wpas and the rest of the OPENSSL_COMPATIBLE_DEFAULTS family, and --enable-leanpsk, --enable-leantls, --enable-lowresource and --enable-tinytls13 disable the cache outright. The application must use the legacy reference flow, wolfSSL_get_session() or SSL_get_session() followed by wolfSSL_set_session(); wolfSSL_get1_session() returns the session object itself and is not affected, nor are wolfSSL_SetServerID() lookups. Only TLS 1.2 and below and DTLS 1.2 and below are reachable, since TLS 1.3 and ticket resumption with an empty ServerHello session ID both use a client-chosen cache key. The poisoned entry lives in the process-global cache, so it crosses WOLFSSL_CTX boundaries and persists until the entry is evicted or the session times out, 500 seconds by default. Releases v5.3.0 through v5.9.2 are affected; the fix adds a per-write generation counter to the cache and raises WOLFSSL_CACHE_VERSION from 2 to 3, so a cache persisted by an older build is rejected by a fixed one. Found via the Anthropic OSS program.
Fixed in PR 11500

## New Features

* Added `make sbom` (SPDX 2.3 + CycloneDX 1.6) and `make bomsh` (OmniBOR build provenance) targets for EU Cyber Resilience Act compliance. by @MarkAtwood (PR 10343)
* Added Argon2 (RFC 9106) password hashing with all three variants; Argon2d, Argon2i and Argon2id. `--enable-argon2`. Only version 0x13 is implemented. Provides the one-shot `wc_Argon2()`/`wc_Argon2_ex()` and a reusable context API (`wc_Argon2Init`/`wc_Argon2SetParams`/`wc_Argon2DeriveTag`/`wc_Argon2Free`, plus `wc_Argon2New`/`wc_Argon2Delete` unless `WC_NO_CONSTRUCTORS`) that allocates the memory block array once for applications deriving many tags. `--enable-argon2-threads` fills the segments of a slice in parallel, which does not change the derived tag: the one-shot functions use a thread per lane, and the context API takes a count from `wc_Argon2SetThreads()`. by @SparkiDev (PR 11165)
* Replaced the liboqs-based Falcon wrapper with a native wolfCrypt implementation (levels 1 and 5) with crypto callbacks, ARM DSP and AArch64 NEON acceleration, and removed the liboqs dependency. Falcon's vector backends can now run inside the Linux kernel. by @danielinux (PR 10827, PR 10996)
* Added FrodoKEM with fast, small and small-stack C code and assembly for x86_64, AArch64, AArch32 and Thumb2, plus ASN.1 keys and X.509 certificates. by @SparkiDev (PR 10870)
* Added SLH-DSA (FIPS 205) authentication for the TLS 1.3 and DTLS 1.3 handshake (draft-reddy-tls-slhdsa), all twelve parameter sets. by @Frauschi (PR 10901)
* Added a Xilinx Versal Gen2 ASU port: TRNG, hashes, HMAC, AES ciphers, CMAC, GMAC, RSA (raw, PSS, OAEP), ECC, ECDH, ECIES, EdDSA and X25519/X448 offload, with Vitis 2026.1 support and a port README. by @night1rider (PR 10765, PR 10994, PR 11034, PR 11052, PR 11053, PR 11248, PR 11252)
* Added AES-GCM-SIV (RFC 8452) in C with assembly for Intel x64, ARM64, ARM32 and Thumb2. by @SparkiDev (PR 10807)
* Added KMAC and cSHAKE (SP 800-185), and switched the SHA-3 assembly on AMD CPUs to the faster BMI variant. by @SparkiDev (PR 10888)
* Added AES Key Wrap with Padding (RFC 5649) with crypto callback support. by @night1rider (PR 10718)
* Added a Time-Stamp Protocol (RFC 3161) implementation in wolfCrypt with an OpenSSL compatibility layer, tests, certificates and examples. `wc_TspResponse_Verify()` now requires a trusted TSA certificate, and the request/TstInfo message imprint setters cross-check the digest length against the hash algorithm. by @SparkiDev (PR 10778, PR 10868) and @yosuke-wolfssl (PR 11152, PR 11153)
* Added `--enable-tinytls13`, a TLS 1.3-only footprint profile (PSK + ECDHE floor with optional minimal X.509), and an in-memory smoke test in `examples/tls13/tls13_memio.c`. by @aidangarske (PR 10751)
* Added TLS receive read-ahead (`--enable-readahead`, `WOLFSSL_TLS_READ_AHEAD`) to cut the number of `recv()` calls per record. by @Frauschi (PR 10944)
* Added `wolfSSL_CTX_require_psk()` / `wolfSSL_require_psk()` to require that an external PSK is negotiated for a (D)TLS 1.3 handshake to succeed. by @Frauschi (PR 10745)
* Added `wolfSSL_CTX_RequireExtendedMasterSecret()` / `wolfSSL_RequireExtendedMasterSecret()` and `wolfSSL_CTX_EnableExtendedMasterSecret()` / `wolfSSL_EnableExtendedMasterSecret()` to enforce the Extended Master Secret requirement at runtime; `wolfSSL_CTX_DisableExtendedMasterSecret()` now also disables server-side EMS, not just the client side. by @kareem-wolfssl (PR 10978)
* Added a `WOLFSSL_VERBOSE_LOGGING` tier (`WOLFSSL_MSG_VERBOSE()`, `WOLFSSL_ENTER_VERBOSE()`, `WOLFSSL_LEAVE_VERBOSE()`) and moved the highest-volume traces onto it, cutting `DEBUG_WOLFSSL` unit test output by about 62%; `WOLFSSL_DEBUG_OPENSSL` is honored as an alias. by @dgarske (PR 11387)
* Added a DTLS 1.3 scheduled work API so a reader can send the work it schedules. by @Frauschi (PR 11018)
* Added a CRL unknown extension callback API mirroring the X.509 one, so unrecognized CRL extensions can be handled instead of failing with `ASN_CRIT_EXT_E`. by @anhu (PR 10961)
* Added public alt-name list APIs (`wc_SetDNSEntry()` and friends) so applications can build and attach SAN entries to a Cert without internal functions. by @Frauschi (PR 10768)
* Added `wc_SignCRL_ex2()` for signing CRLs with post-quantum and EdDSA keys. by @Frauschi (PR 10943)
* Added PKCS#7/CMS encode of degenerate certs-only SignedData, SignedData with absent eContent (signed-attributes-only), and a multi-certificate decode fix, for EST/SCEP enrollment. by @Frauschi (PR 10760, PR 10804)
* Added AES-GCM as an ECIES DEM alongside AES-CBC/CTR+HMAC, ECIES crypto callbacks and devId threading; fixed-nonce GCM is opt-in via `WOLFSSL_ECIES_STATIC_GCM_NONCE`. by @night1rider (PR 10883)
* Added `WC_RNG_SEED_DEVICE` to seed the DRBG from a nominated device such as `/dev/hwrng` before the default sources. by @dgarske (PR 11216)
* Added `wc_ConstantCompare()` as a public wrapper (guarded by `WOLFSSL_NO_CONST_CMP`). by @philljj (PR 10867)
* Added `wc_ecc_key_new_ex()`. by @holtrop-wolfssl (PR 11160)
* Added configurable SRAM PUF error correction (`WC_PUF_BCH_T`) and footprint (`WC_PUF_NUM_CODEWORDS`); the default build is byte-for-byte compatible with prior releases. by @dgarske (PR 11057)
* Added zero-copy encryption of AEAD application data in BuildMessage, roughly 1% to 3% faster on the send path; disable with `WOLFSSL_BUILD_MSG_NO_ZERO_COPY`. by @julek-wolfssl (PR 10899)
* Added `WOLFSSL_WIDE_BYTE` support for `CHAR_BIT != 8` targets, validated on the TI C2000 C28x (LAUNCHXL-F28P55X), plus `WOLFSSL_MLDSA_VERIFY_SMALLEST_MEM`. by @dgarske (PR 10724)

## Crypto Callback Additions

* Added `WOLF_CRYPTO_CB_ONLY_SLHDSA`, a crypto-callback-only mode for SLH-DSA that saves about 16 KB when the algorithm is offloaded. by @padelsbach (PR 11055)
* Extended TLS 1.3 asynchronous crypto callback support (`WOLF_CRYPTO_CB` returning `WC_PENDING_E`, driven by `wolfSSL_AsyncPoll()`) to the HKDF key schedule, transcript HMAC, AES-GCM record encrypt/decrypt, RNG, ECC/X25519 key shares and ECDSA/Ed25519 sign and verify; `wc_HKDF_Extract_ex()` and `wc_HKDF_Expand_ex()` now propagate `WC_PENDING_E`. by @dgarske (PR 11231)
* Added `WOLF_CRYPTO_CB_ASYNC_POLL`, a poll-to-complete model for crypto callback devices servicing TLS record ciphers; without it a pending bulk cipher now errors with `ASYNC_OP_E` instead of corrupting the record. by @julek-wolfssl (PR 10990)
* Added `WC_ALGO_TYPE_KEYSTORE`, a crypto callback algorithm type for lifetime operations on keys held in a hardware key store, with the public API in `wolfssl/wolfcrypt/wc_keystore.h` behind `--enable-cryptocbutils=keystore`. Seven operations - plaintext and wrapped import/export, derive, delete and get-info - address keys by an opaque device-defined reference, so a device can create, wrap, derive and destroy keys that never appear in memory. `wc_KeyStore_Derive()` takes a `keySz` argument to request the derived key size. by @Frauschi (PR 11336, PR 11425)
* Added crypto callbacks for HKDF extract/expand, AES CFB/OFB, SHAKE128/256, ECC public key derivation and validation (`WC_PK_TYPE_EC_MAKE_PUB`, `WC_PK_TYPE_EC_CHECK_PUB_KEY`), Ed448 sign/verify, CMAC free, and RSA-PSS verify with digest. by @twcook86 (PR 10598), @night1rider (PR 10748, PR 10750, PR 10886) and @rizlik (PR 10663)
* Added crypto-callback-only modes for Ed25519, Curve25519 (including make_pub and generic, saving about 6 KB) and Curve448 (with new `wc_curve448_init_ex`/`new`/`delete` and `wc_curve448_generic`), and `--enable-cryptocb=only` to turn on every `WOLF_CRYPTO_CB_ONLY_*` flag. by @padelsbach (PR 10830, PR 10832, PR 10955), @night1rider (PR 11209) and @JacobBarthelmeh (PR 11112)
* Added `wc_CryptoCb_IsDeviceRegistered()` and rejection of duplicate device registration with `ALREADY_E`. by @AlexLanzano (PR 10604)
* Added CryptoCb_Free for Falcon with tests and CI for the free hook on other algorithms. by @padelsbach (PR 11204)

## Behavioral Changes

* `ForceZero()` no longer issues CPU fences. The wipe is kept alive by a compiler barrier (`WC_BARRIER_DATA()`) that takes the buffer address, so it is not optimized away for buffers that never leave the inlined code. A caller that needs the zeroed memory to be visible to another core must order it itself with a lock or an atomic release. by @julek-wolfssl (PR 11429)
* `--disable-tlsv12` now defines `WOLFSSL_NO_TLS12` and compiles the TLS 1.2 implementation out. Previously it only changed the configure summary and a peer could still negotiate TLS 1.2. by @Frauschi (PR 11324)
* `PERSIST_SESSION_CACHE` now saves and restores the entire session cache rather than the first session of each row. The on-disk layout changed, so `WOLFSSL_CACHE_VERSION` was bumped from v2 to v3; caches saved with v2 (file and memory) are no longer restorable. by @philljj (PR 11070)
* `wc_PufReadSram()` now health tests the raw SRAM readout and rejects a degenerate one (all-zero or all-one 128-bit blocks, a block repeating the previous one, or a Hamming weight outside `WC_PUF_HW_MIN_PCT`..`WC_PUF_HW_MAX_PCT`, 35% to 65% by default) with `PUF_READ_E`; `wc_PufEnroll()` and `wc_PufReconstruct()` refuse to run on a rejected readout. Qualify a candidate region with the new `wc_PufCheckSram()` and widen the band if the silicon warrants it. The helper-data format and derived key are unchanged, so helper data enrolled by 5.9.2 stays valid. by @dgarske (PR 11143)
* `wolfSSL_shutdown()` on a connection already closed or reset with no close_notify sent now returns `WOLFSSL_FATAL_ERROR` with `SOCKET_PEER_CLOSED_E` instead of 0 (`WOLFSSL_SHUTDOWN_NOT_DONE`), so a loop waiting on 0 terminates. Under `OPENSSL_EXTRA` this reports as `WOLFSSL_ERROR_SYSCALL` and adds an entry to the error queue; call `wolfSSL_ERR_clear_error()` if a non-empty queue after shutdown matters. by @SparkiDev (PR 11022)
* `wolfSSL_X509_STORE_up_ref()` only takes a reference on a store allocated with `wolfSSL_X509_STORE_new()`; a store owned by another object (such as the one `wolfSSL_CTX_get_cert_store()` returns when none was set) returns 1 without touching the count, matching `wolfSSL_X509_STORE_free()`. A NULL store still returns 0. by @SparkiDev (PR 11022)
* `wolfSSL_OCSP_parse_url()` (`OCSP_parse_url`) was rewritten to follow OpenSSL. An omitted scheme means http, the scheme is matched case sensitively, IPv6 literals keep their brackets, userinfo up to the first `@` of the authority is discarded, the port is reported as written, the query stays with the path and the fragment is dropped. A CR or LF anywhere in the URL and an empty host are still refused. Applications that log, pin or allow-list a responder must use the host this function returns rather than the URL it was given. by @SparkiDev (PR 11022)
* `wolfSSL_set0_verify_cert_store()` and `wolfSSL_set1_verify_cert_store()` now treat a NULL store as a request to clear the store set on the SSL object and revert to the context's store, returning 1. by @SparkiDev (PR 11022)
* `wolfSSL_read_ex()` and `wolfSSL_write_ex()` return `BAD_FUNC_ARG` for a NULL object in every build instead of 0, which is also the value for "no application data was transferred". Callers treating any non-1 result as failure are unaffected. by @SparkiDev (PR 11022, PR 10926)
* `wolfSSL_CTX_set_client_cert_cb()` and `client_cert_cb` are now declared only under `WOLFSSL_CERT_SETUP_CB` with `OPENSSL_EXTRA`, the one configuration where the setter could compile. by @SparkiDev (PR 11022)
* `wolfSSL_write_early_data()` now fails with `WOLFSSL_FATAL_ERROR` and `TOO_MUCH_EARLY_DATA` at the AEAD key usage limit instead of sending a KeyUpdate before the handshake completes (RFC 9846 Section 5.5), and the budget stops one record short to leave room for EndOfEarlyData. Callers that hit this should abandon early data rather than resume from an offset. Reaching the limit takes roughly 23.7 million early data records. by @SparkiDev (PR 11215)
* LMS/XMSS keys restored with `wc_LmsKey_Reload()` / `wc_XmssKey_Reload()` carry no public key. The `ExportPubRaw`, `ExportPub`, `ExportPub_ex`, `PublicKeyToDer` and `Verify` functions now return `BAD_STATE_E` for such a key. by @Frauschi (PR 11426)
* A TLS 1.3 server now answers a ClientHello carrying a non-empty legacy_session_id with a ChangeCipherSpec record (RFC 8446 Appendix D.4) in every build, not only under `WOLFSSL_TLS13_MIDDLEBOX_COMPAT`. by @Frauschi (PR 11306)
* The default ticket encryption callback rotates two keys and can only honor a hint below half of `WOLFSSL_TICKET_KEY_LIFETIME`. A larger hint previously left no key available and failed every handshake after the first rotation; the server now continues without issuing a ticket instead. by @mattia-moffa (PR 10822)
* `wolfSSL_X509_STORE_CTX_set_verify_cb()` is now honored, taking precedence over the store's callback. Restrictive callbacks installed on a context, and the pathLen / INVALID_CA overrides, now take effect in `OPENSSL_EXTRA` builds. by @Frauschi (PR 11094)
* `wolfSSL_CTX_set_cipher_list()` and `wolfSSL_set_cipher_list()` now return `WOLFSSL_FAILURE` and leave the configured suites unchanged when the list names only TLS 1.3 suites but the context or object cannot negotiate TLS 1.3 (`OPENSSL_EXTRA` builds). Previously they returned success without applying the list. by @miyazakh (PR 10963)
* `SSL_get_cipher_list()` now enumerates the object's configured cipher list, highest priority first, rather than returning only the negotiated cipher at index 0. by @julek-wolfssl (PR 11003)
* OCSP responder authorization: the OCSP responder certificate's signature is now verified in the default `WOLFSSL_ASN_TEMPLATE` build; a responder whose certificate does not verify is rejected. by @holtrop-wolfssl (PR 11195)
* `WOLFSSL_SEND_HRR_COOKIE` split: `WOLFSSL_TLS13_COOKIE` now enables only client-side cookie echo; `WOLFSSL_SEND_HRR_COOKIE` still selects both server and client behavior. by @padelsbach (PR 11101)
* `--enable-all-crypto` no longer pulls non-FIPS or legacy algorithms into FIPS builds. The new `--enable-all-nonfips-crypto` and `--enable-all-legacy-crypto` bundles hold those algorithms and can be enabled or disabled explicitly alongside `--enable-all-crypto` for subtractive selection. by @douzzer (PR 11383)
* `WC_RNG` gains a per-instance lock and POSIX-conforming fork handlers so one RNG can be shared between threads and across `fork()`; on by default where the build supports it, opt out with `--disable-rng-autolock` and `--disable-rng-autofork`. TLS performance is unchanged since each `WOLFSSL` owns its RNG. by @kaleb-himes (PR 11210)

## Post-Quantum Cryptography (PQC)

* Added support for post-quantum-only TLS 1.3 builds (ML-KEM key exchange with ML-DSA or SLH-DSA authentication, no RSA/ECC/DH), and fixed the TLS 1.3 certificate chain send resuming after WANT_WRITE. by @Frauschi (PR 11096)
* Added ML-DSA (FIPS 204) signing and verification for PKCS#7/CMS SignedData (RFC 9882). by @Frauschi (PR 10759)
* Added ML-DSA to the OpenSSL compatibility layer. PEM/DER private and public key read, `X509_sign`, `X509_REQ_sign`, `X509_set_pubkey`, and fixed `verifyX509orX509REQ()` and the ML-DSA OID handling. by @kojo1 (PR 10962) and @stenslae (PR 10785)
* Added ML-KEM assembly for AVX512F/AVX512VBMI and ML-DSA assembly for AVX512F/BW/VBMI with AVX2 improvements. by @SparkiDev (PR 10981, PR 11032)
* Added `--enable-all-quantum-crypto` to enable every quantum-resistant asymmetric algorithm. by @douzzer (PR 10920)
* Enforced FIPS 205 pre-hash rules for SLH-DSA (SHA-256 and SHAKE128 only at the lowest security level) and fixed a PKCS#7 test callback typedef. by @kaleb-himes (PR 11265)
* Validate ML-DSA s1/s2 coefficient bounds in `wc_dilithium_check_key()` and added further ML-DSA checks. by @MarkAtwood (PR 10254) and @padelsbach (PR 11056)
* Made the ML-DSA low-bits check constant time in the C and x64 assembly implementations. by @SparkiDev (PR 11371)
* Fixed unaligned reads and casts in ML-KEM and ML-DSA, and a misspelled `__aarch64__` guard. by @SparkiDev (PR 10707), @kojiws (PR 10816, PR 10839) and @Frauschi (PR 10958)
* Fixed ML-DSA level auto-detection in `WOLFSSL_MLDSA_NO_ASN1` builds. by @stenslae (PR 10852)
* Route `wc_MlDsaKey_SignCtx()` through the crypto callback before the private key check so device-resident ML-DSA keys can sign. by @aidangarske (PR 10979)
* Fixed signed-shift undefined behavior in the SLH-DSA base_2b accumulator and the ML-DSA gamma1_19 encoder and slow-multiply reductions. Thanks to Dominik Blain of Qreative Lab for the reports. by @MarkAtwood (PR 10917, PR 10918, PR 10919)
* Fixed multiple issues in XMSS and added LMS bounds checks. Thanks to 007bsd for the report. by @kareem-wolfssl (PR 11189)
* Fixed LMS/XMSS Reload skipping the software reload when a read callback is set on a device id. by @Frauschi (PR 11059)
* Runtime-dispatch the ML-KEM SHA-3 crypto extension on ARM64 to fix SIGILL on CPUs without FEAT_SHA3. by @dgarske (PR 11123)
* Added missing ForceZero of ML-KEM/ML-DSA private key data. Identified by Uday Devaraj, SYNE Lab, Syracuse University. by @Frauschi (PR 10683, PR 10697)
* `wc_SlhDsaKey_Export*` now return `MISSING_KEY` when no key is present. by @holtrop-wolfssl (PR 11268)
* Added Windows project support for FIPS v7 with the post-quantum algorithm files in the module hash range. by @kaleb-himes (PR 11338)

## TLS/DTLS

* Added verify-only secondary DTLS cookie secrets for application-driven rotation of the DTLS 1.2 HelloVerifyRequest and DTLS 1.3 HelloRetryRequest cookie secrets. by @julek-wolfssl (PR 10634)
* RFC 9846 (TLS 1.3 update) conformance: added the general_error(117) alert, capped sender key updates at 2^48-1, accept empty CertificateRequest extensions, updated cert_with_extern_psk to RFC 9973, parse the sniffer keylog line by line (RFC 9850), and honor SSLKEYLOGFILE. Early-data AEAD limits, user_canceled handling and decode_error alerts are covered under Behavioral Changes and Bug Fixes. by @Frauschi (PR 10941) and @SparkiDev (PR 11215)
* Enforce Extended Key Usage on chain-supplied intermediate CAs: `ProcessPeerCerts()` now applies the serverAuth/clientAuth purpose check to every CA the peer transmits and fails the handshake with `EXTKEYUSE_AUTH_E` when the CA does not carry the purpose in use. An absent extension and anyExtendedKeyUsage leave all purposes valid (RFC 5280 4.2.1.12), self-signed certificates are exempt, and `IGNORE_KEY_EXTENSIONS` opts out. Adds `WOLFSSL_X509_V_ERR_INVALID_PURPOSE`. by @embhorn (PR 11145)
* Fixed TLS 1.3 early data: fatal bad_record_mac when an accepted 0-RTT record fails to decrypt, reject 0-RTT for tickets minted before the server context existed, and added a `WOLFSSL_TLS13_MIDDLEBOX_COMPAT` build option. by @julek-wolfssl (PR 11097) and @Frauschi (PR 11379)
* Enforce the RFC 5746 renegotiation_info check in the TLS 1.2 client by default, with a new `wolfSSL_CTX_set_scr_check_enabled()`. Thanks to Lucca Hirschi and the puffin team at Inria for the report. by @embhorn (PR 10984)
* Enforce the RFC 8446 SHA-1 certificate rule against the peer's signature_algorithms_cert on TLS 1.3 chains. Thanks to Xiangdong Li (Beijing University of Posts and Telecommunications) for the report. by @embhorn (PR 11185)
* Stopped offering SHA-1 signature schemes for TLS 1.2 by default, enforced attribute certificate validity, zeroized the secure renegotiation key copy, and send unexpected_message on EndOfEarlyData in DTLS 1.3. by @Frauschi (PR 10968)
* Do not export keying material until the handshake is complete, check ticket expiration before using a ticket for resumption, and stop advertising NULL cipher suites by default (`WOLFSSL_TLS13_NULL_CIPHER_IN_DEFAULT` restores them). Thanks to Ben Smyth for the report. by @kareem-wolfssl (PR 10594)
* Enabled the TLS_FALLBACK_SCSV check unconditionally. by @yosuke-wolfssl (PR 10661)
* Mask the top bit of a peer's X25519 public value per RFC 7748 instead of rejecting it, in wolfCrypt and in the TLS 1.2 and 1.3 key exchange paths; `WOLFSSL_X25519_NO_MASK_PEER` restores rejection. by @SparkiDev (PR 10713) and @miyazakh (PR 11283)
* Reject a HelloRetryRequest lacking supported_versions before a downgrade-capable client falls back to TLS 1.2, send missing_extension for it, and avoid duplicate protocol_version alerts. by @embhorn (PR 10892) and @kareem-wolfssl (PR 10811, PR 10764)
* Send illegal_parameter for a bad ServerHello supported_versions, decrypt_error for a TLS 1.3 PSK binder failure, protocol_version when no version can be negotiated, record_overflow in every build, and unexpected_message for a duplicate TLS 1.3 handshake message. by @gasbytes (PR 11106), @Frauschi (PR 11105, PR 11094), @embhorn (PR 10795) and @julek-wolfssl (PR 10930)
* Send unsupported_extension for quic_transport_parameters on a non-QUIC connection (RFC 9001) and reject trusted_ca_keys outside the ClientHello in TLS 1.3. by @gasbytes (PR 11304)
* Forbid supported_versions from being sent for TLS versions below 1.3, forbid sending more than one certificate with Raw Public Keys, confirm the QUIC max_early_data_size is 0xffffffff, and distinguish QUIC alerts from TLS alerts in the alert history. by @kareem-wolfssl (PR 11174)
* Only process ChangeCipherSpec after the ClientKeyExchange has been sent, fixed the verification logic for Raw Public Keys, clear legacy_session_id when using TLS 1.3, and forbid Certificate messages for PSK handshakes. Thanks to Anthropic for the reports. by @kareem-wolfssl (PR 11458)
* `wolfSSL_SetVersion()` is now reflected in the advertised versions and downgrade handling. by @padelsbach (PR 11456)
* Reject a TLS 1.3 ClientHello with no mutually supported group with a handshake_failure alert instead of picking a server-only group and hanging until timeout (RFC 8446 4.2.1). by @julek-wolfssl (PR 11253)
* `wolfSSL_is_init_finished()` no longer reports a TLS 1.3 client handshake complete while its Finished message is still buffered after WANT_WRITE. by @gasbytes (PR 11139)
* Send close_notify after user_canceled even under quiet shutdown, as the RFC 9846 pairing requires. by @night1rider (PR 11264)
* Enforce the RFC 8446 certificate_authorities lower bound on send and receive. by @night1rider (PR 11118)
* Reject a zero-length TLS 1.3 session ticket. by @philljj (PR 11114)
* Harden TLS 1.3 NewSessionTicket handling per RFC 9846: validate the extensions framing in every build (decode_error on malformed framing), and optionally only issue tickets to clients that advertised psk_key_exchange_modes (`WOLFSSL_TLS13_TICKET_CHECK_PSK_MODES`). by @julek-wolfssl (PR 11178)
* The default session ticket encryption callback now uses AES-256-GCM when available; unknown FFDHE-range codepoints in supported_groups are retained per RFC 7919, with enforcement gated on `WOLFSSL_QT`. by @mattia-moffa (PR 11161)
* Reassemble fragmented TLS 1.3 post-handshake messages after the handshake arrays are freed. by @julek-wolfssl (PR 10691)
* Check the context's extensions before rejecting a TLS 1.3 Certificate message extension, so OCSP stapling requested on the CTX is accepted. by @aidangarske (PR 10936)
* Fixed TLS 1.3 post-handshake authentication with OCSP stapling and repeated PHA over write_dup. by @kojo1 (PR 10421)
* Do not select RSA-PSS in TLS 1.2 when the RSA key is too small for the signature. by @kojo1 (PR 10866)
* Reject status_request_v2 ocsp-multi staples bundling multiple SingleResponses. by @gasbytes (PR 10747)
* Reworked ECH public-extension handling into a public extension manager, fixed the ECH AAD offset with read-ahead, and use the DTLS-aware header size for the inner ClientHello. by @sebastian-carpenter (PR 10568), @gasbytes (PR 11310) and @aidangarske (PR 10878)
* Free and reset all five QUIC encryption levels in `wolfSSL_quic_clear()`, declare the QUIC record length from the bytes remaining, and fixed a QUIC buffer underflow. by @gasbytes (PR 11196), @yosuke-wolfssl (PR 11045) and @loganaden (PR 10838)
* Forbid a post-handshake CertificateRequest over QUIC and zero a MAX3266X result buffer before use. by @mattia-moffa (PR 11299)
* Aligned `wolfSSL_set1_groups_list()` with OpenSSL: case-insensitive names and MLKEMxxx aliases. by @Frauschi (PR 10686)
* Fixed `wolfSSL_inject()` appending data at the wrong offset. by @yosuke-wolfssl (PR 11044)
* Clear SSL-owned credentials when switching context with `wolfSSL_set_SSL_CTX()`, fixing a stale chain and a double free. by @yosuke-wolfssl (PR 11330)
* Set sess_free_cb to NULL after calling it. Thanks to Abdullah Al Ishtiaq, Kai Tu, Yilu Dong, Tianwei Yu, Xiaotian Zhou, Ali Ranjbar, Ananna Rahman, Syed Rafiul Hussain for the report. by @philljj (PR 10989)
* Report NID_auth_any for TLS 1.3 ciphers in `wolfSSL_CIPHER_get_auth_nid()`. by @julek-wolfssl (PR 11255)
* Return an error when Raw Public Key is used with the stubbed DANE compatibility API. Thanks to Peter Samarin for the report. by @embhorn (PR 10486)
* Check the CRL when a peer certificate names no OCSP responder instead of collapsing the no-URL result onto success, report a `WOLFSSL_SMALL_CERT_VERIFY` signature failure ahead of the later parse errors, and bind a client session cache reference to the entry contents it was issued for. Thanks to Anthropic for the reports. by @Frauschi (PR 11500)
* Rework post-handshake checks for resumed connections. Thanks to Jauhun Lee for the report. by @kareem-wolfssl (PR 11198)
* TLS 1.3-only builds now leave out the TLS 1.2 transcript state (handshake hashes drop from 864 to 352 bytes) and the SHA-512 transcript unless `WOLFSSL_TLS13_SHA512` is set; new `--enable-tls13-sha512` / CMake `WOLFSSL_TLS13_SHA512` options. by @Frauschi (PR 11343)
* DTLS: allow `WOLFSSL_DTLS_CID` with DTLS 1.2, added receive-side DTLS 1.3 RequestConnectionId/NewConnectionId handling, check a CID record is newest before promoting a pending peer, and return an error on bad CID arguments. by @mattia-moffa (PR 10626) and @rizlik (PR 11364)
* DTLS: preserve the association on invalid record headers during the handshake, take the write lock when setting the pending peer, and clear the dtls_tx_msg cursor when its record is freed. by @yosuke-wolfssl (PR 10826), @Frauschi (PR 11018) and @julek-wolfssl (PR 10982)
* DTLS: only acknowledge DTLS 1.3 handshake records whose messages were processed or buffered (RFC 9147 Section 7), refuse to send a DTLS 1.2 record or accept a renegotiation that would wrap the epoch sequence number and reuse AEAD nonces, and further Connection ID fixes. by @julek-wolfssl (PR 11177)
* DTLS: drop datagrams from an unexpected address once the peer was learned from the first datagram, drop datagrams that do not parse as a handshake message until the server has verified the peer, and prime the replay window when the handshake turns stateful so every earlier record number counts as seen. Found via the Anthropic OSS program. by @gasbytes (PR 11521)
* DTLS 1.3: send the correct second ClientHello when the server sends no HelloRetryRequest, check handshake message lengths, bound the ACK list, verify the echoed legacy_session_id, and improved epoch management. Reported by Jorge Milla (Pig-Tail). by @rizlik (PR 10730, PR 10769, PR 11016), @kareem-wolfssl (PR 10833) and @aidangarske (PR 10922)
* DTLS 1.3: use the correct Connection ID transmit output size. Thanks to Abdullah Al Ishtiaq, Kai Tu, Matthew Carter, Xiaotian Zhou, Ananna Rahman, Yilu Dong, Tianwei Yu, Ali Ranjbar and Syed Rafiul Hussain (SyNSec Lab, The Pennsylvania State University) for the report. by @rizlik (PR 11320)
* Fixed a couple of issues in DTLS ClientHello parsing. Thanks to the Fuzz0x team for the report. by @kareem-wolfssl (PR 11007)
* Corrected the sniffer reassembly logic, fixed the handshake message size in BuildCertificateStatus when renegotiating with OCSP stapling, ensure the MTU is set when using SCTP with DTLS, and improved the SCTP examples. Thanks to 007bsd for the report. by @kareem-wolfssl (PR 11211)
* Added `--enable-asynccrypt-sw` end-to-end support with `--enable-all`, fixing five async defects in the record layer, ECCSI and tests. by @Frauschi (PR 11060)
* Added TLS 1.2 RSA PKCS#1 v1.5 negative tests, a TLS 1.3 CertificateVerify signature algorithm test, and more TLS certificate verification mode tests. by @gasbytes (PR 10777) and @SparkiDev (PR 10815, PR 11333)
* Added `examples/benchmark/dtls_bench`, a DTLS throughput benchmark, and optimized the DTLS send path (cached socket-type probe, sequence number as explicit AEAD nonce). by @julek-wolfssl (PR 10551)

## OpenSSL Compatibility Layer

* Added Ed25519 support across the EVP/PEM/X.509 compatibility surface (requires `--enable-ed25519 --enable-certgen`). by @ordex (PR 10722)
* Added `EVP_PKEY_set1_encoded_public_key()` / `EVP_PKEY_get1_encoded_public_key()` and the deprecated tls_encodedpoint names. by @julek-wolfssl (PR 10607)
* Added `SSL_CTX_add_client_custom_ext()` for TLS 1.2 and below. by @julek-wolfssl (PR 10625)
* Added `BIO_get_new_index()`, `i2d_PUBKEY_bio()` and `OpenSSL_version()`. by @julek-wolfssl (PR 11020)
* Added `SSL_get_negotiated_group()` and `SSL_group_to_name()`, accept FFDHE group names in `SSL_set1_groups_list()`, define `WOLFSSL_SIGNER_DER_CERT` for `OPENSSL_ALL` so `X509_STORE_get0_objects()` returns the added certificates (opt out with `WOLFSSL_NO_SIGNER_DER_CERT`), and run the `X509_VERIFY_PARAM` host/IP checks in `ProcessPeerCerts()` before the application verify callback. by @julek-wolfssl (PR 11108)
* Added `wolfSSL_set_tlsext_debug_callback()` (`SSL_set_tlsext_debug_callback`), invoked for every TLS extension received during the handshake. by @julek-wolfssl (PR 11256)
* Added `SSL_CIPHER_find()`, `sk_SSL_CIPHER_delete()` and `SSL_clear_chain_certs()`, and fixed `SSL_add0_chain_cert()` not counting the chain so TLS 1.3 sent a leaf-only certificate. by @Roy-Carter (PR 10518, PR 10517)
* Added compatibility needed by libodbc: `OBJ_find_sigid_algs`, BIO method accessors, and related constants and macros. by @kojo1 (PR 10813)
* Added `X509_STORE_CTX_set0_crls()` for OpenVPN, with caller-owned CRLs checked during verification. by @julek-wolfssl (PR 10896)
* `d2i_ECPrivateKey()` now derives the public key when it is absent from the DER. by @MarkAtwood (PR 10362)
* `X509_verify_cert()` no longer mutates the shared store certificate stack, fixing races between concurrent verifications. by @julek-wolfssl (PR 10997)
* Report `X509_VERIFY_PARAM` hostname/IP mismatches to the verify callback so it can override them, and map them to `X509_V_ERR_HOSTNAME_MISMATCH` / `X509_V_ERR_IP_ADDRESS_MISMATCH` under `OPENSSL_COMPATIBLE_DEFAULTS`. by @gasbytes (PR 11156) and @julek-wolfssl (PR 11260)
* `X509_STORE_CTX_init()` and a new WOLFSSL object now inherit the full `X509_VERIFY_PARAM` (hostname, IP and host flags) from the store and CTX. by @gasbytes (PR 11513)
* Clear the trusted stack on `X509_STORE_CTX_init()` so it does not carry into a later verification. by @gasbytes (PR 11354)
* Fixed `X509_NAME_print_ex()` flag handling, implemented `ASN1_STRFLGS_ESC_2253`/`ESC_CTRL`/`ESC_MSB`, and write values byte for byte so an embedded NUL no longer leaks heap bytes. by @julek-wolfssl (PR 11395)
* Bounds check the directory path when adding a certificate directory with `X509_LOOKUP_add_dir()`. by @aidankeefe2022 (PR 11269)
* `wolfSSL_EVP_Cipher()` no longer swallows the return code of the single-DES CBC branch, which reported success on a failed operation. by @miyazakh (PR 11411)
* Locked globalRNGMutex around every shared globalRNG access, including `BN_rand`, `AddSession`, ECDH and X25519. by @yosuke-wolfssl (PR 10824, PR 11048)
* Skip the truncation shift for byte-aligned `BN_rand()` requests. by @yosuke-wolfssl (PR 11316)
* Fixed buffer overruns in `SignCert()`, `EVP_PKEY_keygen()` on a populated key and the `WOLFSSL_NO_REALLOC` populate paths, plus stale `EVP_PKEY` key metadata. by @Frauschi (PR 11061)
* Return 0 from the error queue APIs when the queue is not compiled in. by @stenslae (PR 10785)

## ASN and Certificate Parsing

* Added `WOLFSSL_X509_TINY` (minimal-extension X.509 parser with per-feature add-backs) and `WOLFSSL_X509_VERIFY_ONLY` profiles, cutting roughly 6% to 18% off the certificate parser, with CI coverage. by @aidangarske (PR 10823, PR 10975)
* Added true zero-allocation X.509 certificate verification for strict `WOLFSSL_NO_MALLOC` builds via the internal `WC_ASN_NO_HEAP` path. by @aidangarske (PR 10821)
* Fixed a directoryName name constraints bypass by comparing RDN sequences per RFC 5280 7.1 with RFC 4518 string preparation, instead of a byte prefix. by @holtrop-wolfssl (PR 11140)
* Reject certificates with trailing data (opt out with `WOLFSSL_NO_ASN_STRICT`). Thanks to Lucca Hirschi (Inria, France) and the tlspuffin team for the report. by @kareem-wolfssl (PR 10755)
* Enforce RFC 5280 MUSTs under `WOLFSSL_NO_ASN_STRICT`: unknown critical extensions, duplicate extensions and dirName constraints on SANs. by @aidangarske (PR 10922)
* Reject certificates with critical policyConstraints / inhibitAnyPolicy, empty certificatePolicies, trailing bytes after the last PolicyInformation, and duplicate netscape certificate type extensions. by @aidangarske (PR 10878), @gasbytes (PR 11221) and @JacobBarthelmeh (PR 11236)
* Enforce `MAX_CHAIN_DEPTH` when loading chains, sending OCSP status and sending the TLS 1.3 Certificate message, with parser input validation. by @ColtonWilley (PR 10209)
* Fixed X.509 pathLen handling, partial-chain double push, and allow maxPathLen up to `WOLFSSL_MAX_PATH_LEN`. by @kareem-wolfssl (PR 10737)
* Ensure presented chain certificates are not added to the trust store and fixed a missing certChainCnt increment. by @padelsbach (PR 11305)
* Parse x500UniqueIdentifier (OID 2.5.4.45) in certificate DNs. by @embhorn (PR 10999)
* Added SSH server and missing SSH client extended key usage parsing to the ASN template parser and handle EKU OID collisions. Thanks to Satoru Kanno (GMO Connect Inc / GMO Internet Group Inc.) for the report. by @JacobBarthelmeh (PR 11361)
* Fixed certificate name id lookup when `WOLFSSL_CERT_NAME_ALL` is defined (the table lacked entries for the extra OIDs) and fixed `--disable-rsa` builds. by @SparkiDev (PR 11421)
* Track the actual ASN template depth and compare it to the expected depth. by @SparkiDev (PR 11404)
* Improved URI host extraction. Thanks to Satoru Kanno for the report. by @rizlik (PR 11439)
* Encode the basicConstraints critical flag and pathlen into generated CSRs. by @cconlon (PR 11030)
* Encode default certificate validity as UTCTime through 2049. by @aidangarske (PR 11228)
* `MakeAnyCert()` now strips leading zeros from caller-supplied serials so the DER INTEGER is minimal and the generated certificate parses, bounds `serialSz` to `CTC_SERIAL_SIZE`, and rejects a zero serial (RFC 5280 4.1.2.2). by @embhorn (PR 11433)
* Fixed KeyUsage decipherOnly encoding in the template certificate generator and int/word32 type punning in ASN.1 and EVP helpers. by @dgarske (PR 11171)
* Restored the error code from `DecodeGeneralName()` so hostname matching still runs on a SAN with an embedded NUL. by @embhorn (PR 10793)
* Guard an empty otherName SAN copy against a NULL memcpy. by @night1rider (PR 11117)
* Reject CR/LF in OCSP and CRL URLs from certificates and in OpenSSL-compat OCSP request paths and headers, and bound the port in `wolfIO_DecodeUrl()`. by @yosuke-wolfssl (PR 10628), @ejohnstown (PR 10966) and @kareem-wolfssl (PR 10675)
* Fixed a use-after-free in `GetCRLInfo()` under `WOLFSSL_SMALL_STACK`, a CRL load race in `BufferLoadCRL()`, an uninitialized EncryptedInfo in PEM CRL chain loading, and deep copy revoked entry extensions in `DupCRL_Entry()`. by @padelsbach (PR 10693, PR 10716), @yosuke-wolfssl (PR 11046) and @gasbytes (PR 11038)
* Fixed an off-by-one NUL write in `GetCertName()` in the classic ASN.1 parser. Thanks to Frans van Buul (OpenText Fortify) for the report. by @embhorn (PR 10952)
* Fixed a memcpy length overflow in `wolfSSL_d2i_ASN1_INTEGER()`. Thanks to SecBuddyF, Tencent KeenLab, for the report. by @padelsbach (PR 10861)
* Fixed an off-by-one in `pem_find_pattern()` rejecting PEM without a trailing newline. by @gasbytes (PR 11259)
* Check the `CALLOC_ASNGETDATA` result before use in `DecodeCertInternal()`. by @danielinux (PR 11378)
* Fixed the ASN guards for RSA key DER export in ECC-free SE050 builds. by @LinuxJedi (PR 11220)
* Added opt-in OCSP hardening: `WOLFSSL_OCSP_SCREEN_RESPONDER` blocks AIA responder hosts in internal address ranges (SSRF, CWE-918), and `WOLFSSL_OCSP_FAIL_IF_NOT_SUPPORTED` fails a certificate that advertises no responder; a missing responder now reports the distinct `OCSP_NO_URL`. by @ejohnstown (PR 10723, PR 10945)
* Added `WOLFSSL_ASYNC_CERT_YIELD`, an opt-in that returns `WC_PENDING_E` after each certificate in a peer chain is verified during async TLS chain processing. by @dgarske (PR 10738)
* Added a trusted argument to the Ed25519/Ed448 private key DER decode to skip key checks. by @rizlik (PR 10911)

## Hardware and Embedded Ports

* Added an STM32 bare-metal crypto port (HASH, AES, PKA, RNG) needing no HAL, with DHUK (Device Hardware Unique Key) and CCB hardware-protected ECDSA, validated across ~27 STM32 families. by @dgarske (PR 10395, PR 10880)
* Added STM32 CubeMX and RealTek crypto-callback devices for plaintext-key AES, hardware AES-GCM and ECDSA. by @dgarske (PR 10970)
* Added STM32V8 (Cortex-M85, Armv8.1-M) hardware crypto family support (`WOLFSSL_STM32V8`), validated on the NUCLEO-V873XJ. by @dgarske (PR 11296)
* Added STM32CubeMX2 (MX2) support: automatic pickup of the MX2-generated configuration (keyed off `WOLFSSL_MX2_CONF_INCLUDE`), the pack codegen assets, and HAL2 console support in the STM32Cube example. by @dgarske (PR 11348, PR 11466)
* Fixed the STM32 SAES DHUK wrapped-key unwrap so `wc_Stm32_Aes_Wrap()` blobs unwrap and are interchangeable with ST's HAL (this changes every DHUK-derived key), and `wc_ecc_import_wrapped_private()` now takes the curve id so an imported wrapped scalar is ready to sign. by @dgarske (PR 11462, PR 11497)
* Added a RealTek AmebaPro2 (RTL8735B) HUK crypto-callback port (AES, HMAC-SHA256, ECDSA, TRNG). by @dgarske (PR 10677)
* Added a WISeKey/SealSQ VaultIC secure element port (P-256 sign, verify, keygen, ECDH). by @dgarske (PR 10974)
* Added Vorago VA416x0 hardware TRNG support. by @dgarske (PR 10671)
* Added wolfCrypt support for the TI C2000 C28x DSP family, including the AESA hardware AES accelerator (ECB/CBC/CTR) as a crypto-callback device, an oscillator-jitter entropy source, 16-bit-byte fixes, octet packing helpers and an optional precomputed ML-DSA matrix A. by @dgarske (PR 10724, PR 11202, PR 11344)
* Added UDP support to NetX sockets for DTLS sessions. by @hmohide (PR 10408)
* Fixed the NetX I/O porting layer: `NX_NO_PACKET`, `NX_WINDOW_OVERFLOW` and `NX_TX_QUEUE_DEPTH` now map to WANT_READ/WANT_WRITE so non-blocking operation works, `NX_NOT_CONNECTED` to a connection close, and the `HAVE_NETX` socket error aliases were corrected. by @embhorn (PR 11287)
* Zephyr: native k_mutex/k_thread threading without `CONFIG_POSIX_THREADS`, wolfPSA provider support, and stack tracking in the benchmark. by @Frauschi (PR 10983)
* Zephyr: use UMAAL-free SP math on every M-profile core without the DSP extension, build the `.S` assembly files on Zephyr, check OSXSAVE/XGETBV before dispatching AVX code, call Zephyr's clock API instead of remapping the POSIX names, reworked the module's Kconfig, and added Kconfig symbols for a constant-time AES backend (`WOLFSSL_AES_CONSTANT_TIME` with touch-lines or bitsliced) and `WC_ALLOW_ECC_ZERO_HASH` so wolfPSA builds without a settings file. by @Frauschi (PR 11401, PR 11431, PR 11522)
* SE050: dynamic hardware/software offload by key residency, ECDH derive target objects for applet 7.2 middleware, a scratch buffer for raw RSA verify, software ECDH fallback for non-resident keys, C++ header guards, and simulator CI updates. by @rizlik (PR 10862), @LinuxJedi (PR 10971, PR 11194, PR 11206) and @embhorn (PR 11284)
* SE05x: added session lifecycle, policy-aware key insertion and on-chip key generation, binary object management, runtime Platform SCP03 credentials with key rotation, and nonce-bound attestation APIs. by @LinuxJedi (PR 11377)
* Intel QuickAssist: interleave instances across devices, fall back to regular memory when the service is not started, and fixed a Cavium/Nitrox event queue overflow and a TLS 1.3 hybrid PQC key share drop under async crypt. by @dgarske (PR 10772)
* PKCS#11: set label and ID on generated EC public keys, and allow a generated EC key to both derive and sign via `WC_ECC_FLAG_DERIVE`. by @aidangarske (PR 10954) and @dgarske (PR 11201)
* Fixed Octeon AES-GCM non-12-byte IV and tag verification, and TI AES-CTR streaming, hashCopy and alignment checks. by @dgarske (PR 11148, PR 10986)
* Renesas: RX72N TSIP lock leak, hash return and AES-GCM AAD fixes with command-line build/flash/UART tooling, RA6M4 SCE session-key fixes, and bounded crypto callback context slots. by @miyazakh (PR 10842, PR 10903) and @Frauschi (PR 11093)
* Fixed the STM32 CubeMX AES-GCM AAD over-read from HAL word reads (ST SA0076). by @dgarske (PR 11102)
* NXP: DCP hash channel and lock fixes, hashcrypt AES OFB/CFB streaming state and AES ECB/CBC argument and zero-length validation, CAAM/QNX resource manager input checks, and a missing `caamAesCombined` declaration. by @danielinux (PR 11282), @night1rider (PR 11262, PR 11261) and @JacobBarthelmeh (PR 11263, PR 11535)
* PSA and KCAPI AES: restart the cipher stream on `wc_AesSetIV()` so a new IV takes effect. by @danielinux (PR 11158)
* AF-ALG: fixed AES-GCM struct reuse across encrypt and decrypt, redirect AES-ECB, added input checks and a CI workflow; fixed AAD/no-AAD handle interchange and argument validation in AF-ALG and KCAPI. by @JacobBarthelmeh (PR 11162) and @douzzer (PR 10881)
* TROPIC01: keep the caller's IV in the AES-CBC callback and derive the GHASH subkey from the device key. by @danielinux (PR 11366)
* STSAFE: normalize the digest to the field size in ECDSA verify. by @danielinux (PR 11281)
* IoT-Safe: serialize APDU transactions with a port mutex. by @danielinux (PR 11246)
* MAX32666: streaming SHA and bare-metal TRNG health test on the old SDK. by @mattia-moffa (PR 10733)
* ColdFire: clamp the AES-CBC chunk to the remaining length. by @aidangarske (PR 11223)
* RISC-V port: argument checks and `KEYUSAGE_E` for AES without a key schedule. by @danielinux (PR 10864)
* ARM CryptoCell: improved (de)initialization and return an error for disabled hash types in RSA hash mode. by @holtrop-wolfssl (PR 11266) and @dgarske (PR 11170)
* Fixed alignment issues in bitsliced AES, scrypt and SHA-256, and staged block data through aligned buffers in STM32 CRYP and Renesas SCE. by @dgarske (PR 11170)
* Fixed FSPSM RSA outLen, devcrypto init tracking and AES tag placement, and CAAM fixes. by @aidankeefe2022 (PR 10786, PR 10808)
* Zero the kop struct in devcrypto X25519 before use. by @holtrop-wolfssl (PR 10817)
* Fixed `wc_ecc_sign_hash_hw()` overflow under `WOLFSSL_XILINX_CRYPT_VERSAL` with `WOLFSSL_SMALL_STACK`. by @miyazakh (PR 11286)
* Return an error from `atmel_get_random_number()` for unknown targets, and added bounds checks to the Freescale DES port. by @holtrop-wolfssl (PR 11247) and @aidankeefe2022 (PR 11360)
* Reject out-of-range SHE counter, flags and key IDs in the software path. by @yosuke-wolfssl (PR 11155) and @night1rider (PR 11279)
* Fixed compiler errors for `WOLFSSL_RPIPICO`, Apache Mynewt and uITRON4 (`XMALLOC_OVERRIDE`). by @tjko (PR 10742), @stenslae (PR 10914) and @kojo1 (PR 10925)
* Fixed resource cleanup on error paths in the MQX, QNX, IoT-Safe, Azure Sphere and ESP-IDF IDE examples, and certificate verification in the ESP example. Thanks to Arthur Chan for the report. by @rlm2002 (PR 10854) and @kareem-wolfssl (PR 11251)
* Azure Sphere: include `sys/stat.h` only where used and enable `HAVE_SERVER_RENEGOTIATION_INFO` in the project's user_settings.h. by @padelsbach (PR 11489)

## Assembly and Performance

* Intel x64: new AES assembly (AES-XTS and AES-GCM with AVX512/VAES; ECB/CBC/CTR with AVX512/VAES/AVX1/AES-NI), improved AES-GCM performance, and an 8-bit table GCM multiply. by @SparkiDev (PR 10756, PR 10825, PR 10949)
* Intel x64: AVX512 ChaCha20 and Poly1305 with fused ChaCha20-Poly1305 used by TLS, and AVX512 IFMA X25519/Ed25519. by @SparkiDev (PR 10940, PR 11043)
* Intel x86/x64 assembly fixes: x86 builds with assembly under `--enable-all`, AES-NI/AVX1 fixes, unsigned length comparisons above 2 GiB, and a P-256 carry fix. by @SparkiDev (PR 10728, PR 11104, PR 11125)
* Fixed SIGILL from Intel runtime dispatch on CPUs without the feature: AVX/AVX2/AVX-512/VAES are masked unless OSXSAVE and XCR0 enable the YMM/ZMM state, `wc_Sha256HashBlock()` emits `movbe` only when CPUID reports MOVBE, and ML-DSA `encode_w1` initializes the CPU flags before its AVX2 check. by @sameehj (PR 11340)
* Fixed an AES-GCM AVX2 12-byte IV overread, ML-KEM AVX2/AVX-512/AArch64 constants, SP x86_64 SAKKE reduction, the AES-GCM x86 decrypt tag length on the stack, SipHash assembly length comparisons, and X25519/Ed25519 sub/neg reductions. Thanks to Anthropic for the reports. by @SparkiDev (PR 11472)
* Fixed the rdx clobber in the x86 and x86_64 `sp_div_word` inline assembly (a latent miscompile found by Fil-C), regenerated the fixed-size SP C sources for capability targets, and reworked the Fil-C CI job. by @Frauschi (PR 11323)
* Fixed MASM builds: non-AVX VEX instruction in ECC routines, x64 home space, and vzeroupper on VAES exits. by @kaleb-himes (PR 11290)
* MSVC: pass the SP feature defines to ml64 for `sp_x86_64_asm.asm` so `WOLFSSL_SP_4096` / `WOLFSSL_SP_384` builds link. by @embhorn (PR 11254)
* Added Windows x64 and ARM64 assembly files to the build and project files. by @SparkiDev (PR 10801, PR 10844)
* AArch64: runtime CPU id dispatch with software fallback for SHA-256/512, AES-XTS streaming assembly and a key schedule fix, faster SP ECC P-256 and RSA via a transposed table, and general optimizations. by @SparkiDev (PR 10754, PR 11190, PR 10744) and @kaleb-himes (PR 11370)
* ARM32: CPU id flags to choose AES and SHA-256 assembly at runtime, Thumb2 Curve25519 full reduction, and an AES-GCM tmp pointer restore. by @SparkiDev (PR 10957, PR 10725, PR 11068)
* Thumb2: use `.W` encodings for branches whose targets exceed the narrow range, fixing "Branch offset too long" with the IAR compiler. by @mattia-moffa (PR 10939)
* PPC64/PPC32: AES, SHA-2 and SHA-3 assembly, ELF V1 headers, little-endian support, and condition-register SHA-256. by @SparkiDev (PR 10767, PR 10871, PR 10740)
* RISC-V 64-bit: reworked generated assembly, a full SP implementation, an AES-GCM in-place decrypt fix and a GCM table guard. by @SparkiDev (PR 10893, PR 11135, PR 11015, PR 11023)
* SP ARM64 assembly builds under GreenHills, ARMv3 Montgomery multiply fixed, SP ARM64 generator output improved, and 16-byte aligned ECC points under `SP_ALIGN_16`. by @SparkiDev (PR 10890, PR 11274, PR 11298, PR 9634)
* Regenerated SP sources so `sp_*_from_mp()` converts secret inputs in constant time. by @danielinux (PR 10898)

## Rust Wrapper

* Released wolfssl-wolfcrypt crate v2.1.0 and v2.2.0. by @holtrop-wolfssl (PR 10850, PR 11064)
* Added Clone for SHA256/SHA384 via `wc_Sha256Copy`/`wc_Sha384Copy`, and `ChaCha20Poly1305::finalize_verify()`. by @MarkAtwood (PR 10425) and @holtrop-wolfssl (PR 10933)
* Renamed dilithium to mldsa following the C API. by @holtrop-wolfssl (PR 10780)
* Fixed the Ed25519/Ed448 verify functions returning Ok(false) on failure, and a possible dangling `WC_RNG` pointer in curve25519. by @holtrop-wolfssl (PR 10645, PR 11347)
* Check the `DH::shared_secret` buffer size against the prime size. by @holtrop-wolfssl (PR 10924)
* build.rs: validate `WOLFSSL_PREFIX` once, accept lib or lib64, check for the library file and MSVC/Cygwin names, and rebuild when the variable changes. by @holtrop-wolfssl (PR 10703, PR 11312)
* Build-option gating fixes: SHA3 sizes, RSA RNG, AES-OFB, ECC export, LMS, Ed25519/Ed448 RNG use, rsa_direct, verify-only ECC, VerifyingKey without random, and PBKDF2 SHA variants. by @holtrop-wolfssl (PR 11157, PR 11167, PR 11187, PR 11307, PR 11309, PR 11321, PR 11325, PR 11337)
* Copy AEAD keys directly into the return struct and documentation fixes for `pss_check_padding()` and `check()`. by @holtrop-wolfssl (PR 11380, PR 11384, PR 11385)

## Build System and Portability

* CMake: added ~100 options and 37 application bundles matching autotools, wired `WOLFSSL_HAVE_XMSS`, and added LMS/XMSS sub-options. by @SparkiDev (PR 10834) and @Frauschi (PR 10929)
* configure: prevent shell injection through includedir/libdir, enable curve25519 in lighttpd builds, error on SP assembly for MinGW, reject `--enable-trackmemory` with `--enable-staticmemory`, fixed the `-Wno-deprecated-enum-enum-conversion` probe under ccache, and `--enable-mldsa=verify-only`. Thanks to NVIDIA Project Vanessa for the includedir/libdir report. by @kareem-wolfssl (PR 10712), @padelsbach (PR 10977), @julek-wolfssl (PR 10897) and @miyazakh (PR 10923)
* configure now warns when RC4 cipher suites are enabled for TLS and when non-conformant old TLS versions are enabled. by @aidankeefe2022 (PR 11277) and @anhu (PR 11213)
* Fall back to `accept()` on glibc, uClibc and Android bionic versions without `accept4()`. by @kareem-wolfssl (PR 11455)
* Fixed `WOLFSSL_NO_MALLOC` builds with static memory: RSA CA public keys now reach the Signer for chain verification and TLS connections can be established; the wolfCrypt test pool is sized so `make check` covers the configuration. by @Frauschi (PR 11432)
* Fixed make dist failing with "Argument list too long" by distributing IDE trees per directory. by @Frauschi (PR 10951)
* Fixed a link failure with `NO_SESSION_CACHE` and session tickets, and build wolfevent.c under `--enable-usersettings`. by @Frauschi (PR 11107) and @danielinux (PR 11002)
* C89 compliance: flexible array members, trailing enumerator commas, and `W64LIT_FORCE_LONG_LONG`. by @anhu (PR 10858)
* Fixed typedef redefinition errors, SP sp_int sizing for `--enable-sp=rsa4096` on 32-bit targets, and `SOCKET_INVALID` detection on Linux. by @philljj (PR 10855), @night1rider (PR 11168) and @sebastian-carpenter (PR 11054)
* aes.h no longer includes cpuid.h; SHA3-224/256/384/512 prototypes are gated separately. by @SparkiDev (PR 11066) and @holtrop-wolfssl (PR 11157)
* Added user_settings_embedded.h with documented on/off configuration defines. by @SparkiDev (PR 11067)
* Fixed custom RNG builds (`CUSTOM_RAND_GENERATE_BLOCK` with `HAVE_HASHDRBG`, as used by wolfTPM fwTPM on STM32) by guarding the DRBG failure cleanup with the same conditions as its state. by @aidangarske (PR 11504)
* Linux kernel module: native cmac(aes) registration, ECDSA verify on kernel 6.13+, per-CPU native vector register save buffers for hardirq/softirq (`WC_SVR_USE_NATIVE_REG_BUFS`) with a SIMD stress tool, `DEBUG_VECTOR_REGISTER_ACCESS_ALWAYS_{ON,OFF}`, rng_bank refcount fixes, a 25 ms yield budget, `WC_DEBUG_FORCE_KERNEL_SETTINGS`, user-supplied `SAVE_VECTOR_REGISTERS()` support, and FORTIFY_SOURCE/KMSAN/gcc-17 fixes. by @douzzer (PR 10696, PR 10812, PR 10829, PR 10856, PR 10881, PR 10980, PR 11103, PR 11240, PR 11381, PR 11382)
* FreeBSD kernel module: FPU nesting counter, rdseed build fix, `wc_static_assert` define, polymorphic atomic load/store macros, and cleanup. by @philljj (PR 10734, PR 10736, PR 10987, PR 11119, PR 11451) and @douzzer (PR 11509)
* FIPS: added `--enable-fips=dev-no-post`, `FIPS_BAD_VALUE_E`/`FIPS_UNAPPROVED_E`, runtime DH enablement, and centralized `FIPS_NO_WRAPPERS` handling; shimmed `wc_AesGcmEncrypt()` under FIPS via wc_compat.h; stabilized fips-ready. by @douzzer (PR 11031, PR 10920) and @kaleb-himes (PR 10934)
* FIPS: v7 compliance fixes inside the boundary (RSA-PSS salt, full SP 800-56B key validation, PQ pairwise consistency tests), moved wolfEntropy outside the FIPS boundary, added fips-hash-offline.sh, and fixed v6/v7 header guards. by @kaleb-himes (PR 11303, PR 11271), @holtrop-wolfssl (PR 10749), @philljj (PR 10885), @lealem47 (PR 11328, PR 11144, PR 10959) and @rlm2002 (PR 11313)
* Added `DH_MIN_SIZE` and `WC_MIN_DIGEST_SIZE_FOR_SIGN`/`_FOR_VERIFY`. by @lealem47 (PR 10820) and @douzzer (PR 10856)
* Expanded the core RNG facility and `rng_bank` with kernel-facing SP 800-90 semantics (seed pools, next-seed generation, RBG-C constructions, lock and debug-statistics options), with whitebox tests and matching Linux kernel module glue. by @douzzer (PR 11435)

## Bug Fixes

* In PKCS7 an embedded certificate could potentially reset the noDegenerate flag leading to unsigned SignedData that verifies. Requires PKCS7 support enabled and loading of untrusted externally supplied PKCS7 bundles. Found via the Anthropic OSS program. by @kareem-wolfssl (PR 11459)
* `ProcessPeerCertLeafRevocation()` cleared its revocation-lookup flag whenever `ssl->status_request` or `ssl->status_request_v2` was set, but those flags record only that the server's extension was parsed, not that a stapled response arrived or verified, so both the client's own OCSP lookup and its CRL check for the leaf certificate were suppressed in this edge case. Found via the Anthropic OSS program. by @Frauschi (PR 11500)
* Preserve the noDegenerate state in `wc_PKCS7_VerifySignedData()` for bundles that carry certificates, and fixed the size checks in PKCS#12 `GetSafeContent()`. Found via the Anthropic OSS program. by @kareem-wolfssl (PR 11459)
* Fixed a heap overflow in the TLS 1.2 compression receive path (`--with-libz` with `wolfSSL_set_compression()` on both peers): `DoApplicationData()` decompressed a record back over the input buffer sized for the compressed record; the plaintext now goes into a connection-owned buffer with an RFC 5246 6.2.2 length check. by @embhorn (PR 11186)
* Fixed `ShrinkOutputBuffer()` freeing a static buffer, `X509StoreFreeObjList()` logic, unoffered certificate types being allowed in the Raw Public Key case, a TEMP_CA leak in `wolfSSL_X509_verify_cert()`, an implicit length in `CheckIPAddr()`, and zero heap `mp_int` structs on allocation before any error path. Thanks to Christos Papakonstantinou (Cantina Security) for the reports. by @kareem-wolfssl (PR 11009, PR 11029)
* Fix for sniffer Encrypt-Then-MAC (RFC 7366) handling in the ServerHello, so TLS 1.2 CBC captures decrypt, and X25519 decryption by giving the static ephemeral key an RNG; specific errors are no longer overwritten with "Server Client Key Mismatch". by @Frauschi (PR 11319)
* Fix for the sniffer over-reporting plaintext lengths by the MAC or AEAD tag size, which also overread the buffer handed to the `WOLFSSL_SNIFFER_STORE_DATA_CB` callback. by @Frauschi (PR 11319)
* Fix for `ssl_FreeSniffer()` tearing down state shared by every thread; the init entry points now count callers and only the last free releases the shared trace file, mutexes and crypto device. Also fixed a leak of StatsMutex. by @Frauschi (PR 11319)
* Fix for snifftest error tracking (an early bad packet was erased by later good ones), a new `-expectdata` option, threaded decoding that drained nothing and skipped keylog setup, and buffer sizing in the example `WOLFSSL_SNIFFER_STORE_DATA_CB` callback. by @Frauschi (PR 11319)
* Fix for sniffer DTLS 1.3 example handshakes by adjusting the cipher list version checks in the example apps to recognize negative DTLS 1.3 version values (-4), resolving `MATCH_SUITE_ERROR` failures during handshakes. by @Frauschi (PR 11319)
* Fix for a dangling cert store pointer in the cert manager after `wolfSSL_CTX_set_cert_store()`: `wolfSSL_X509_STORE_free()` now clears the manager's pointer when it releases the store and the context setters re-pair the manager with the store the context owns, preventing a use-after-free in issuer lookups (`OPENSSL_ALL` with CRL and hash directory support). by @SparkiDev (PR 11022)
* Fix for `wolfSSL_set_accept_state()` with `WOLFSSL_BLIND_PRIVATE_KEY`: the static-ECC check decoded the masked key buffer directly, so valid static ECC cipher suites were silently dropped; a masked key is now unmasked into a plain copy for the check. by @SparkiDev (PR 11022)
* Fix for a fatal-level user_canceled alert closing a TLS 1.3 connection: RFC 9846 Section 6.1 says the alert is a warning, so it is now ignored whichever level the peer used. TLS 1.2 and earlier are unchanged. by @SparkiDev (PR 11215)
* Fix for the key update cap turning a peer's update_requested into a fatal error: at the 2^48-1 limit the request is now dropped per RFC 9846 Section 4.7.3 and the connection continues on its current keys; an application-initiated `wolfSSL_update_keys()` still reports `BAD_STATE_E`. by @SparkiDev (PR 11215)
* Fix for malformed extension data aborting the handshake without an alert: `BUFFER_E` now maps to decode_error like `BUFFER_ERROR`, per RFC 9846 Section 4.3, covering pre_shared_key, psk_key_exchange_modes, early_data, cookie, post_handshake_auth and the certificate type extensions. by @SparkiDev (PR 11215)
* Blocked AES, AES-CCM, ChaCha20, Camellia, RC2, and 3DES-ECB operations if no key is set; added RSA-PSS hash-binding tests. by @julek-wolfssl (PR 10762), @Frauschi (PR 10803, PR 10958), and @dgarske (PR 11294)
* AES-GCM: Enforced SP 800-38D tag lengths, cleared outputs on auth failure (constant-time) and C-path errors, and fixed AES-CCM decrypt partial-block guards. by @douzzer (PR 10696), @danielinux (PR 10895), @kareem-wolfssl (PR 10675), and @embhorn (PR 11040)
* AES-GCM/AES-CCM `_ex` encrypt: advance the internal nonce counter when an async backend reports `WC_PENDING_E`, fixing nonce reuse on the async path. by @embhorn (PR 11175)
* Added input validation across wolfCrypt, set minimum CMAC tags to 64 bits for FIPS (SP 800-38B), and aligned user-space and kernel `WOLFSSL_MIN_AUTH_TAG_SZ` defaults. by @lealem47 (PR 10819)
* AES: Checked ECB return values in chained modes, permitted empty AES-EAX plaintext, and added NULL checks to `wc_AesCbcEncryptWithKey()`. by @rizlik (PR 11004), @MarkAtwood (PR 10251), and @julek-wolfssl (PR 10930)
* Fixed double frees in `wc_ecc_import_point_der_ex()` on bad format bytes, and fixed `RsaUnPad_PSS()` masking for 1 mod 8 bit moduli. by @MarkAtwood (PR 10592, PR 10256)
* ECC: Implemented constant-time point-at-infinity handling, private scalar import bounds checks, key-blinded scalar handling, full scalar zeroing after SP math signing, and rejection of identity-point ECDH secrets. Thanks to Ravikanth Reddy Gudipati for the scalar zeroing report. by @dgarske (PR 11173, PR 11172, PR 11233), @kareem-wolfssl (PR 11041), and @Frauschi (PR 10958)
* Prevented repeated re-initialization of the ECC OID cache lock and checked `wc_InitMutex()` results. by @cconlon (PR 11111) and @philljj (PR 11141)
* Unified mutex initializers for ECC caches and netRandom, published crypto callbacks after field setup, and masked RSA blinding factors prior to inversion. by @dgarske (PR 11172)
* DH: Honored explicit primes in `wc_DhCheckPrivKey_ex()`, validated untrusted moduli via random-witness Miller-Rabin, and resolved use-after-frees in `wolfSSL_CTX_SetTmpDH*` parameter buffers. by @dgarske (PR 10818), @Frauschi (PR 10958), and @padelsbach (PR 11115)
* Rejected zero moduli in mp_mulmod/mp_sqrmod aliases, added TFM bounds checks, and guarded mp_cnt_lsb digit scans. by @MarkAtwood (PR 11065), @SparkiDev (PR 10964), and @danielinux (PR 10973)
* Fixed a fe_448 reduction corner case, ECCSI verify modifying the key's ssk field, ML-KEM SHAKE initialization on Intel builds without AVX2, SP division and TOOM-3 multiply/square corner cases, and Ed448 non-canonical key checks. Found via the Anthropic OSS program. by @SparkiDev (PR 11480)
* `wc_ed448_make_public()` now stores the derived public key in the key object (matching Ed25519), so a private-only key no longer signs over an all-zero public key after the call. by @Frauschi (PR 11424)
* Fixed `ecc_verify_hash()` fault checks comparing against uninitialized points, `wc_*Init_Id()` accepting a NULL id with a positive length across AES, HMAC, ECC, RSA, Falcon, ML-DSA and XMSS, and LMS/XMSS raw public key export returning success before a key exists. by @Frauschi (PR 11426)
* Fixed big-endian Curve25519 public key checks, DSA parameter import gating, custom RNG PollAndReSeed, and MC/DC coverage findings. by @danielinux (PR 10875, PR 10973, PR 11047)
* Blocked Curve448 public key export on uninitialized keys. by @yosuke-wolfssl (PR 11154)
* Restricted X25519 private scalar offloading to designated key devices and assigned hashType on SHAKE contexts for proper callback handling. by @Frauschi (PR 11308) and @night1rider (PR 11217)
* Ascon: Re-initialized context in Final for reuse and handled empty input in `wc_AsconAEAD128_DecryptUpdate()`. by @yosuke-wolfssl (PR 11150) and @danielinux (PR 10973)
* Prevented `wc_Tls13_HKDF_Extract()` from overwriting caller ikm buffers. by @yosuke-wolfssl (PR 10938)
* Checked return codes in `wc_CryptKey()` (DES/RC4), `wc_BufferKey{Encrypt,Decrypt}` (unknown ciphers), and `wc_EncryptPKCS8Key_ex()` (including padding alignment). by @miyazakh (PR 11193), @holtrop-wolfssl (PR 11049), @embhorn (PR 11327), and @yosuke-wolfssl (PR 10836)
* Fixed `wc_hash2mgf()` returning `WC_MGF1SHA3_224` for MD2/MD4/MD5/MD5-SHA in SHA3-enabled builds instead of `WC_MGF1NONE`. by @miyazakh (PR 11410)
* Fixed the `wc_RsaCleanup()` key type check so ForceZero runs on the key data in non-FIPS builds. Found via the Anthropic OSS program. by @philljj (PR 11474)
* Added a missing ForceZero of the partial block in `wc_srtp_kdf_derive_key()`. Found via the Anthropic OSS program. by @philljj (PR 11502)
* `wolfSSL_cmp_peer_cert_to_file()` now fails gracefully when called before the handshake. Found via the Anthropic OSS program. by @philljj (PR 11487)
* Standardized error codes for uninitialized `wc_Hash*` under `DEBUG_WOLFSSL`, and aligned SHA-512/384 W cache memory free calls. by @danielinux (PR 10927) and @julek-wolfssl (PR 10776)
* PKCS#7: Fixed `wc_PKCS7_VerifySignedData()` truncation and noDegenerate bypasses, added safe length additions, fixed streamed SignedData content drops, corrected implicit SKID tagging and DigestInfo mismatches, fixed definite-length [0] decrypts, validated the IV and authTag lengths in EnvelopedData/AuthEnvelopedData decode, resolved context leaks, and fixed `NO_PKCS7_STREAM` infinite loops. Reported by Jorge Milla (Pig-Tail) (IV and authTag checks). by @miyazakh (PR 11017), @kareem-wolfssl (PR 10882, PR 10833), @aidangarske (PR 10904), @embhorn (PR 10937), and @Frauschi (PR 10928)
* PKCS#12: Corrected PBKDF mp-variant buffer sizing and added missing ForceZero calls. (Reported by Uday Devaraj, SYNE Lab, Syracuse University). by @Frauschi (PR 11093, PR 10872)
* Base64/PEM: Hardened bounds in `mp_read_unsigned_bin()`, PEM write and Base16/Base64 sizing, fixed `EVP_DecodeUpdate()` NUL byte overflows, and capped memory BIO write / `EVP_Encode*` length bounds. by @JacobBarthelmeh (PR 10721), @Frauschi (PR 11093, PR 10803), and @douzzer (PR 10812)
* Hardened length widths for HKDF info, XChaCha20-Poly1305 AAD, BLAKE2-HMAC updates, and TLS 1.3 early data limits. by @aidangarske (PR 10704)
* Resolved use-after-free conditions in `X509_EXTENSION_create_by_OBJ()`, `wolfSSL_X509_EXTENSION_set_data()`, `wolfSSL_ASN1_STRING_set()` self-aliasing, and `wolfSSL_X509_set_ext()` buffer carry-over. (Reported by Kushal Khemka and Mayank Jangid, OpenSec Intelligence). by @JacobBarthelmeh (PR 10706), @Frauschi (PR 11094, PR 10803), and @kareem-wolfssl (PR 11021)
* Fixed `wolfSSL_BUF_MEM_grow_ex()` calculations under `WOLFSSL_NO_REALLOC`. (Reported by Pelioro). by @embhorn (PR 10770) and @kareem-wolfssl (PR 10675)
* Bounded TLS 1.3 CKS extension memory allocations. (Reported by Pelioro). by @embhorn (PR 10953)
* Fixed NULL dereference in refineSuites. (Reported by xiaoshuai). by @kareem-wolfssl (PR 10711)
* Avoided ticket aliasing in `wolfSSL_GetSessionAtIndex()` and added transferExData to `wolfSSL_DupSessionEx()`. (Reported by Clouditera Security, Z.ai Security, and NSFOCUS). by @kareem-wolfssl (PR 11041)
* Freed target certificates prior to InitX509 in `DecodeToX509()`, and freed OCSP chain requests in `TLSX_CSR_Free()`. by @kareem-wolfssl (PR 10965) and @danielinux (PR 11285)
* Sniffer: Added IPv6/handshake bounds checks, sequence/FIN handling, static ephemeral lock releases, non-TLS session table locking, `wc_*Copy` hash copies, and async offset positioning. (Partially reported by NVIDIA Project Vanessa). by @aidangarske (PR 10788), @kareem-wolfssl (PR 11163), @yosuke-wolfssl (PR 11058, PR 11389, PR 11331), and @Frauschi (PR 10968)
* Added hardening fixes across TLS, X.509, PKCS#7/12, DTLS 1.3, QUIC, and sniffer (including BIO read caps and cert ownership). by @aidangarske (PR 10878)
* Applied general hardening across sniffer, QUIC, PKCS#11, TLS, and tooling (including standalone BIO frees in ssl_set_bio). by @aidangarske (PR 10788)
* Clamped CBC pad lengths before MAC input length calculation, zeroized saved HMAC pads/keys during reset, preserved ECIES heap hints, restored caller key RNGs post-HPKE, and set instance addresses as RNG bank nonces. by @Frauschi (PR 11018)
* wolfCrypt Fenrir: Initialized `wc_DsaVerify` error outputs, added RSA `RSA_W_ENC` guards, corrected NETOS thread stack free ordering, and invalidated LMS keys on write errors. by @aidankeefe2022 (PR 10786) and @Frauschi (PR 11093)
* Blocked KeyUpdate on QUIC and checked SendBuffered results in `wolfSSL_process_quic_post_handshake()`. by @Frauschi (PR 10803) and @mattia-moffa (PR 11161)
* Fixed `wc_strlcpy`/`wc_strlcat` returns, resolved a 1-byte OOB read in `wolfssl_local_MatchBaseName()`, and freed MD5/SHA contexts before returning `VERIFY_MAC_ERROR` in `SSL_hmac()`. by @danielinux (PR 11047), @holtrop-wolfssl (PR 11237), and @rlm2002 (PR 10708)
* Fixed example `wolfSSL_read()` limits, corrected wolfEntropy size logic, and set invalid wolfEntropy settings to error. by @rlm2002 (PR 10708) and @kareem-wolfssl (PR 10884)
* Fixed `WOLFSSL_CHECK_SIG_FAULTS` when combined with `HAVE_PK_CALLBACKS` and `--enable-all --enable-pkcallbacks`. by @kareem-wolfssl (PR 11000)
* Checked GrowAnOutputBuffer returns in threaded-crypt SendData. by @aidangarske (PR 11229)
* ISO-TP: Validated frame structures prior to payload copying and removed an unreachable timeout branch. by @yosuke-wolfssl (PR 11317, PR 11332)
* Restricted persistent session cache files to owner-only access permissions. by @gasbytes (PR 11291)
* Prevented stale READY states in `wc_PufEnroll()`/`wc_PufReconstructEx()` upon hash failure. by @miyazakh (PR 11356)
* Crypto callback registration now skips half-filled slots, so a device that registers further devices from its own register command is not handed the same slot. by @night1rider (PR 11278)
* Fixed dead-code macro guards, memory leaks in ECC private key imports (`mp_clear(order)`), and review findings in ssl_api_*.c. by @anhu (PR 11224), @rlm2002 (PR 10891), and @philljj (PR 10972)
* Fixed identicalInnerCondition issues, MSAN unaligned access in MD5, SE050 Ed25519 zero-length NULL messages, missing `OPENSSL_COEXIST` gates in openssl/hmac.h, zeroed reserved PSK binder regions, an identicalInnerCondition in `ecc_verify_hash()`, and FIPS/KCAPI test gating. by @douzzer (PR 11381, PR 11509)
* Removed dead or unreachable conditions in wolfCrypt identified during MC/DC coverage. by @danielinux (PR 11028)
* Expanded `wc_MemZero` buffer checks under `WOLFSSL_CHECK_MEM_ZERO`. by @SparkiDev (PR 10988)
* Hash_DRBG reseed and generate are now failure-atomic (no state mutation on failure), added in-place public reset APIs for SHA-2 and SHA-3/SHAKE, Linux kernel module RNG invalidation recovery and kernel mutex behavior, renamed `WC_RNG_BANK_SUPPORT` to `HAVE_WC_RNG_BANK`, and added `WC_RNG_WANT_BANKREF_SUPPORT` as an explicit flag for the bankref mechanism (always off for FIPS). by @douzzer (PR 11510, PR 11536)
* Fix QUIC record length reset and conform the quictls return values. Found via the Anthropic OSS program. by @gasbytes (PR 11473)

## Documentation and Maintenance

* Added an integrator-focused AGENTS.md and CLAUDE.md, and CONTRIBUTING.md covering the contributor agreement and PR process. by @LinuxJedi (PR 10942) and @dgarske (PR 11147)
* Pointed the in-repo security policy at the canonical disclosure policy and secure@wolfssl.com, updated the contact address to facts@wolfssl.com and renewed the test certificates. by @MarkAtwood (PR 10559) and @stenslae (PR 10787)
* Expanded the ASN template documentation, documented algorithm, assembly and math defines, and added Doxygen for HPKE and the Japanese comments for seven API groups. by @SparkiDev (PR 11244, PR 11067), @miyazakh (PR 11351) and @yosuke-wolfssl (PR 11024)
* Added a version API for wolfEntropy and updated the Doxygen to reflect its split from random.c. by @kaleb-himes (PR 11430)
* Documented that raw ECC import does not validate the point, single-DES key preconditions, DES function size requirements, and the clock-skew macros. by @MarkAtwood (PR 11099), @miyazakh (PR 11301), @kareem-wolfssl (PR 11163) and @aidankeefe2022 (PR 11369)
* Split ssl.c into ssl_api_*.c, ssl_err.c, ssl_asn1.c and ssl_crypt.c, and extracted helpers from the long functions in internal.c. by @SparkiDev (PR 10841, PR 10926, PR 11022)
* MC/DC (ISO 26262) decision coverage campaign for wolfCrypt and TLS 1.3, with a white-box harness under tests/unit-mcdc/. by @danielinux (PR 10845, PR 10876, PR 10912, PR 10967, PR 11039, PR 11122, PR 11222, PR 11355)
* Added unit tests for session cache save and restore, and sanitize imported sessions. by @philljj (PR 11070)
* Added cross-library compile checks for wolfSSH, wolfCLU, wolfTPM, wolfMQTT, wolfPKCS11 and wolfProvider. by @night1rider (PR 10853) and @dgarske (PR 11124)
* Added a software CryptoCb API test, SM2 identical-point verify test, and Wycheproof-driven negative tests. by @AlexLanzano (PR 10604), @padelsbach (PR 10992) and @Frauschi (PR 10958)
* Benchmark: HMAC-SHA3, AES IV/CCM nonce and key wrap sweeps, RSA padding sweep, AArch64 cycle counter under MSVC, numBlocks clamp, guards, a leak fix and zeroing the ML-KEM key objects before the first free; tls_bench now uses `CLOCK_MONOTONIC` and reports MiB/s. by @night1rider (PR 10946, PR 10947, PR 10887, PR 11249), @rizlik (PR 11090) and @dgarske (PR 11176, PR 11505)

# wolfSSL Release 5.9.2 (Jun 23, 2026)

Release 5.9.2 has been developed according to wolfSSL's development and QA
process (see link below) and successfully passed the quality criteria.
https://www.wolfssl.com/about/wolfssl-software-development-process-quality-assurance

NOTE:
* The pre-standardization Dilithium API has been renamed to its FIPS 204 ML-DSA name; the legacy `dilithium.h` header and `wc_dilithium_*` names remain available through a temporary compatibility shim.
* The SLH-DSA Hash sign/verify APIs now require a caller-supplied pre-hashed digest rather than the raw message (see Enhancements below).
* liboqs integrations for ML-KEM, ML-DSA, and SLH-DSA (SPHINCS+) have been removed in favor of the native implementations; the deprecated liblms and libxmss integrations have also been removed.
* **BREAKING (RFC 6960 4.2.2.2)**: OCSP responder authorization is now strictly enforced. Removes the non-compliant `CheckOcspResponderChain()` fallback, which authorized any OCSP responder cert issued by an ancestor of the target's issuer; RFC 6960 4.2.2.2 requires direct issuance by the CA identified in the request. Also removes the now-unused `WOLFSSL_NO_OCSP_ISSUER_CHAIN_CHECK` macro and the `vp` parameter from `CheckOcspResponder()`.

PR stands for Pull Request, and PR <NUMBER> references a GitHub pull request number where the code change was added.

## Vulnerabilities

* [High] CVE-2026-11310
  X.509 trust-chain bypass in the OpenSSL compatibility certificate verifier (wolfSSL_X509_verify_cert()).

  This affects only builds with --enable-opensslextra (OPENSSL_EXTRA) and whose application validates certificates by calling X509_verify_cert() (OpenSSL compatibility layer function) with caller-supplied untrusted intermediate certificates; for those users it is critical, otherwise the library is unaffected.  In particular, native wolfSSL TLS/DTLS usage is not impacted.

  wolfSSL’s X509_verify_cert() temporarily loads each caller-supplied untrusted intermediate into the certificate manager but failed to drop them before the trusted-store check, so an untrusted intermediate could anchor the path itself. An attacker can present a chain that never reaches a configured trust anchor and have it accepted, resulting in acceptance of an attacker-controlled certificate.

  This is certificate verification independent of TLS (e.g. S/MIME/CMS, code/firmware signing, JWT/JWS x5c), is not specific to any key type or algorithm, and a single untrusted intermediate suffices. The default wolfSSL TLS handshake (WOLFSSL_VERIFY_PEER) is not affected; only TLS applications doing manual or deferred peer verification through this API are, which also requires --enable-sessioncerts. Affected: v5.8.4, v5.9.0 and v5.9.1 (introduced by commit 025dbc34); v5.8.2 and earlier are not. Thanks to Corban Villa, Sohee Kim and Austin Chu (UC Berkeley, Sky Lab). Fixed in PR 10674.

* [High] CVE-2026-11999
  X.509 trust-chain bypass (path-depth exhaustion) in the OpenSSL compatibility certificate verifier (wolfSSL_X509_verify_cert()). This affects only builds with --enable-opensslextra whose application calls X509_verify_cert() with caller-supplied untrusted intermediates; for those users it is critical, otherwise the library is unaffected. Native wolfSSL TLS/DTLS usage is not impacted.

  X509_verify_cert() returned success based only on the last verified link rather than on reaching a trust anchor: when the supplied chain is deeper than the verifier's maximum path depth (default 100), path building runs out of depth while still walking untrusted intermediates and the chain is accepted even though it never reaches a configured trust anchor, allowing acceptance of an attacker-controlled certificate. The default TLS handshake (WOLFSSL_VERIFY_PEER) is not affected; only applications doing manual or deferred verification through this API are. Affected versions: v5.7.4 through v5.9.1, introduced in commit 17c9e92b7 (first released in v5.7.4); v5.7.2 and earlier are not affected. Thanks to Corban Villa, Sohee Kim and Austin Chu (UC Berkeley, Sky Lab). Fixed in PR 10674.

* [High] CVE-2026-6679
  A heap buffer overflow could occur in the DTLS 1.3 ACK serialization path before the connecting peer is authenticated. The buffer overflow was due to an integer truncation when computing the length of the ACK record-number list, causing an undersized buffer to be allocated and then overrun. This affects builds using DTLS 1.3 and wolfSSL version 5.9.0 and earlier. A fix was added to the 5.9.1 release. Thanks to Nicholas Carlini from Anthropic for the report. Fixed in PR 10116.

* [High] CVE-2026-55958
  Out-of-bounds write in the Renesas TSIP TLS 1.3 transcript buffer. In tsip_StoreMessage() the capacity check guarding the fixed message bag (MSGBAG_SIZE) sets an error code but fails to return, so execution falls through to an XMEMCPY that writes past the end of the buffer once the accumulated TLS 1.3 handshake transcript exceeds MSGBAG_SIZE (8 KB), corrupting adjacent heap state and potentially causing a remote denial of service crash. The bag is sized to hold a normal handshake, so this is reached only by an unusually large but valid certificate chain, or by a malicious or man-in-the-middle server sending an oversized handshake message to a client that does not strictly verify the chain. This only affects builds using the Renesas TSIP TLS port (WOLFSSL_RENESAS_TSIP_TLS) as a TLS 1.3 client on Renesas MCUs with TSIP hardware enabled, and is rated High within those builds. All other configurations are unaffected. Thanks to NVIDIA Project Vanessa for the report. Fixed in PR 10705.

* [High] CVE-2026-55960
  Un-negotiated Raw Public Key (RFC 7250) accepted in place of an X.509 certificate, bypassing chain validation. A raw public key has no chain, so ParseCertRelative() accepts it without performing any trust verification; it must therefore only be accepted when RPK was actually negotiated for that peer. The check now defaults the expected type to X.509 (per RFC 7250/8446) when no type was negotiated, comparing against the received server certificate type on the client and the selected client certificate type on the server, and rejects any mismatch, including an un-negotiated raw public key, with UNSUPPORTED_CERTIFICATE.  Only affects builds with Raw Public Key support (HAVE_RPK) enabled - disabled by default in a standalone build, but included in --enable-all. Thanks to NVIDIA Project Vanessa for the report. Fixed in PR 10702.

* [High] CVE-2026-55961
  wolfSSL_PKCS7_verify() returning success for a degenerate (certs-only) PKCS#7 object that contains no signer. Such an object has empty signerInfos, so the underlying signed-data verification succeeds without authenticating any content. The compatibility-layer verify path now rejects the object when no signer signature has actually been verified, so a PKCS#7 carrying no valid signature is no longer reported as verified. This is enforced regardless of the PKCS7_NOVERIFY flag, which only suppresses signer certificate chain validation and was never intended to waive the requirement that a signature exist. Only affects OpenSSL compatibility builds that call the PKCS7_verify() compatibility API on potentially degenerate PKCS#7 bundles. Thanks to NVIDIA Project Vanessa for the report. Fixed in PR 10702.

* [High] CVE-2026-10097
  wolfSSL's AVX2-optimized ML-KEM implementation (mlkem_cmp_avx2) compares only 1536 of the 1568 ciphertext bytes during the Fujisaki-Okamoto re-encryption check in ML-KEM-1024 decapsulation. Ciphertexts that differ from the expected re-encryption solely in bytes 1536-1567 bypass implicit rejection and are accepted as valid, breaking IND-CCA2 security. An attacker able to submit chosen ciphertexts to a decapsulation oracle that uses a static ML-KEM-1024 key, and to observe whether the genuine shared secret or the implicit-rejection secret was produced, can use this as a plaintext-checking oracle to recover the private key. A proof of concept recovered a full ML-KEM-1024 private key with approximately 98% success using roughly 350 chosen ciphertexts. The flaw is a deterministic logic error and does not rely on timing measurements. Thanks to 007bsd @007bsd for the report. Fixed in PR 10430.

* [Med] CVE-2026-6731
  X.509 name constraint bypass via the Subject Common Name when treated as a DNS-type name. A certificate whose Subject CN violates an issuing CA's DNS name constraints could be accepted. Thanks to d0sf3t (Aradex) for the report. Fixed in PR 10223.

* [Med] CVE-2026-6091
  Partial-chain certificate verification may accept chains that terminate at a peer-supplied, untrusted intermediate certificate rather than a trusted anchor. An attacker could present a chain that ends at an intermediate they control and have it accepted as valid. Thanks to Dikai Zou for the report. Fixed in PR 10170.

* [Med] CVE-2026-6094
  Heap buffer overread in wc_PKCS7_DecodeEnvelopedData when parsing crafted PKCS7 EnvelopedData. This could theoretically be triggered by attacker-supplied data delivered via S/MIME or CMS. Thanks to Dikai Zou for the report. Fixed in PR 10128.

* [Med] CVE-2026-6329
  PKCS#12 MAC verification uses an attacker-controlled comparison length, weakening the integrity check on the MAC and allowing a mismatched MAC to be accepted. Thanks to Nicholas Carlini from Anthropic for the report. Fixed in PR 10192.

* [Med] CVE-2026-6330
  The ML-KEM ARM64 NEON ciphertext comparison only compares half of the input, breaking the Fujisaki-Okamoto transform's implicit rejection and weakening IND-CCA2 security on that code path. Thanks to Nicholas Carlini from Anthropic for the report. Fixed in PR 10192.

* [Med] CVE-2026-8720
  wc_Blake2bHmacFinal and wc_Blake2sHmacFinal discard the message when the key length exceeds the block size, producing a MAC that is independent of the input. This bug is specific to the HMAC-BLAKE2 API’s that were added in wolfSSL version 5.9.0. Fixed in PR 10447.

* [Med] CVE-2026-10098
  OCSP CertID serial-number length-confusion in wolfSSL_OCSP_resp_find_status allows a same-issuer SingleResponse whose serial is a prefix of the target serial to be reported as the revocation status of a different certificate. Thanks to Kim Youngjoon (Team-Atlanta and Georgia Institute of Technology) for the report. Fixed in PR 10554.

* [Med] CVE-2026-10592
  Certificates with wildcard DNS SANs (e.g. *.example.com) bypassed CA name-constraint checks. Thanks to tonghuaroot for the report. Fixed in PR 10549.

* [Med] CVE-2026-7532
  iPAddress name constraints bypass when WOLFSSL_IP_ALT_NAME is not defined. IP address name constraints are not enforced in that configuration, allowing a certificate to bypass an issuing CA's IP address constraints. Thanks to Ankur Tyagi of Cisco Talos (TALOS-2026-2409) for the report. Fixed in PR 10354.

* [Med] CVE-2026-6291
  Bleichenbacher padding oracle in PKCS#7 KTRI decryption. When decrypting PKCS#7 EnvelopedData using RSA PKCS#1 v1.5 key transport, wolfSSL returned distinguishable error codes depending on whether RSA padding validation failed versus whether the decrypted content was malformed. An attacker able to submit crafted EnvelopedData messages and observe error responses could use this as a padding oracle to incrementally recover the encrypted Content Encryption Key (CEK). The fix generates a deterministic pseudo-random fake CEK on padding failure (via HMAC-SHA256) and proceeds with decryption identically, using constant-time operations throughout, so that all failure paths produce the same error regardless of padding validity. Found with internal wolfSSL review. Fixed in PR 10203.

* [Med] CVE-2026-7511
  PKCS7_verify signer confusion allows forged signatures, where the signer associated with a signature is not correctly bound, permitting a forged signature to be accepted. Thanks to Nicholas Carlini from Anthropic for the report. Fixed in PR 10203.

* [Med] CVE-2026-11703
  Fixed missing SNI/ALPN binding on stateful (session-ID) resumption, which previously skipped the binding check performed for ticket-based resumption. A cached session could be resumed under a different SNI/ALPN than originally negotiated and, where client-authentication policy differs across virtual hosts, carry the cached peer-authentication state into a context it was not established for. Resumption now verifies the SNI/ALPN binding for all paths and declines (falling back to a full handshake) on mismatch. Thanks to Dikai Zou for the report. Fixed in PR 10489.

* [Med] CVE-2026-55962
  TLS 1.3 post-handshake authentication (PHA) issue where a server could accept a client's Finished message without the client having sent a Certificate and CertificateVerify. The post-handshake-auth exemption that allows an empty/absent peer certificate was only intended for the initial handshake, but it was also being applied while a post-handshake CertificateRequest was still outstanding. The check is now scoped to the initial handshake only: on the server, once a post-handshake CertificateRequest has been sent (certReqCtx is set), a peer certificate and a valid CertificateVerify are required again before the Finished is accepted, with empty-certificate handling following the configured verify mode (FAIL_IF_NO_PEER_CERT) just as during first-handshake client authentication. Only affects TLS 1.3 servers built with post-handshake authentication support (WOLFSSL_POST_HANDSHAKE_AUTH / --enable-postauth, included in --enable-all) that enable WOLFSSL_VERIFY_POST_HANDSHAKE and request a client certificate after the handshake via wolfSSL_request_certificate(). Clients, and servers that do not use post-handshake authentication, are unaffected. Thanks to NVIDIA Project Vanessa for the report. Fixed in PR 10702.

* [Med] CVE-2026-55964
  Chain intermediate CA:TRUE without keyCertSign accepted as a signing CA. Intermediate CA certificates are required to have the keyCertSign key usage when a Key Usage extension is present, but chain-supplied temporary CAs (WOLFSSL_TEMP_CA) added while building a certificate path were previously exempted from this check, so an intermediate asserting CA:TRUE but lacking keyCertSign was accepted as a signing CA. The check now applies to chain-supplied temporary CAs as well; only operator-loaded root certificates (WOLFSSL_USER_CA) and self-signed roots remain exempt. Per RFC 5280 an absent Key Usage extension implies all usages, so the requirement is enforced only when the extension is actually present (extKeyUsageSet). Affects the OpenSSL-compatibility certificate-path-building path (X509_verify_cert / X509_STORE, OPENSSL_EXTRA/OPENSSL_ALL), where untrusted chain intermediates are added as temporary CAs; native (non-OpenSSL-compat) certificate verification does not create temporary CAs and is unaffected. Within those builds, the check applies unless ALLOW_INVALID_CERTSIGN is defined. Thanks to NVIDIA Project Vanessa for the report. Fixed in PR 10702.

* [Low] CVE-2026-6092
  When HAVE_ENCRYPT_THEN_MAC is configured, the implementation could fall back to MAC-then-Encrypt rather than enforcing Encrypt-then-MAC. Thanks to Marcin Olejnik (Rockwell Automation) for the report. Fixed in PR 10167.

* [Low] CVE-2026-6331
  HMAC zero-length tag forgery in EVP_DigestVerifyFinal, where a zero-length tag could be accepted as valid during HMAC verification. Thanks to Nicholas Carlini from Anthropic for the report. Fixed in PR 10192.

* [Low] CVE-2026-6681
  The PKCS#7 decode path ignores the caller-supplied output buffer size (outputSz), allowing decoded content to be written past the bounds of the provided buffer. This affects wolfSSL 5.9.0 and earlier and was fixed in the 5.9.1 release. Thanks to Nicholas Carlini from Anthropic for the report. Fixed in PR 10116.

* [Low] CVE-2026-10512
  The X25519 x86_64 assembly implementation fails to clear the most significant bit during the final modular reduction, so the computed result may not be fully reduced modulo the field prime 2^255 - 19. This can leave the field element in a non-canonical form, producing an incorrect result from the scalar multiplication and potentially a wrong shared secret. Thanks to Haruki Oyama for the report. Fixed in PR 10536.

* [Low] CVE-2026-6678
  Integer underflow in wc_PKCS7_DecryptOri when handling crafted Other Recipient Info, leading to incorrect length handling during decryption. Thanks to Dikai Zou for the report. Fixed in PR 10203.

* [Low] CVE-2026-7531
  Use-after-free in PQC hybrid key-share handling. This is an incomplete-fix follow-up to CVE-2026-5460 (released in 5.9.1): a malicious TLS 1.3 server sending a truncated PQC hybrid KeyShare can still trigger the error cleanup path to operate on freed memory. Thanks to Thai Duong (Calif.io / Anthropic) for the report. Fixed in PR 10327.

* [Low] CVE-2026-6325
  Out-of-bounds write in SetSuitesHashSigAlgo when processing an oversized signature algorithms list, allowing a write past the bounds of the destination buffer. Thanks to Muhammad Arya Arjuna Habibullah (Pelioro) for the report. Fixed in PR 10204.

* [Low] CVE-2026-6412
  Certificate policy and RFC 8446 compliance concerns regarding the continued acceptance of SHA-1/MD5 in certificate processing. Thanks to Xiangdong Li (Student, Beijing University of Posts and Telecommunications [BUPT]) for the report. Fixed in PR 10222.

* [Low] CVE-2026-6450
  A CRL critical extension bypass exists in ParseCRL_Extensions where critical extensions are not properly enforced, allowing a crafted CRL with an unhandled critical extension to be accepted. This only affects builds with CRL support enabled and where a crafted CRL had a trusted signature when parsed. Thanks to Oleh Konko (@1seal) for the report. Fixed in PR 10239.

* [Low] CVE-2026-12340
  Out-of-bounds heap read during SM2/SM3 certificate signature verification. When parsing a certificate with an SM3wSM2 signature, the Subject Key Identifier computation reads the trailing 65 bytes of the public key without checking that the key is at least that long. A public key shorter than 65 bytes results in an out-of-bounds heap read, leading to a potential crash (denial of service); there is no out-of-bounds write. Note this only affects builds with SM2 support (--enable-sm2 or --enable-all). Thanks to David Pokora, Trail of Bits (in collaboration with Anthropic). Fixed in PR 10641.

* [Low] CVE-2026-55967
  AES-GCM encryption/decryption with extremely large cumulative single message sizes (>64 GiB) were not properly rejected by the streaming APIs, allowing counter wrap, keystream reuse, and consequent plaintext recovery. Thanks to NVIDIA Project Vanessa for the report. Fixed in PR 10709.

## Enhancements

* **BREAKING (FIPS 205 SLH-DSA)**: `wc_SlhDsaKey_SignHash`, `wc_SlhDsaKey_SignHashDeterministic`, `wc_SlhDsaKey_SignHashWithRandom`, and `wc_SlhDsaKey_VerifyHash` now take the **caller-pre-hashed message digest** via `hash`/`hashSz` parameters (renamed from `msg`/`msgSz`), aligned with ML-DSA's `wc_dilithium_sign_ctx_hash` / `wc_dilithium_verify_ctx_hash` semantics, and NIST ACVP `signatureInterface=external` / `preHash=preHash` test vectors. `hashSz` must equal `wc_HashGetDigestSize(hashType)` (32 bytes for SHAKE128, 64 bytes for SHAKE256 per FIPS 205 Section 10.2.2); otherwise `BAD_LENGTH_E` is returned. Migration: hash the message yourself before the call (callers using positional arguments are source-compatible; only the parameter names changed). Caveat: callers who today pass a raw message whose length happens to equal the digest size for the chosen `hashType` (e.g., signing a 32-byte handle/IV/seed with `WC_HASH_TYPE_SHA256`) will not trip `BAD_LENGTH_E`; the resulting signature is syntactically valid but is over the wrong bytes. The pre-existing `wc_SlhDsaKey_SignMsgDeterministic` and `wc_SlhDsaKey_SignMsgWithRandom` retain their M'-supplied-directly contract (FIPS 205 internal interface, Algorithm 19); their input validation is hardened with the same NULL/length/`MISSING_KEY` checks as the `*Hash*` family. `wc_SlhDsaKey_VerifyMsg` is unchanged. All three gain doxygen coverage. (PR 10450, PR 10465)

* **Behavioral change (Raw Public Key fail-closed)**: With `HAVE_RPK`, a peer
  that presents a Raw Public Key (RFC 7250) is no longer silently accepted while
  it is being authenticated. Previously an RPK handshake always completed and
  the application validated the key out of band afterward (e.g. via
  `wolfSSL_get_verify_result()`); it now fails closed (with `RPK_UNTRUSTED_E`,
  reported as `WOLFSSL_X509_V_ERR_RPK_UNTRUSTED`) whenever the peer is being
  authenticated, i.e. any verify mode other than `WOLFSSL_VERIFY_NONE`. This
  applies to all `HAVE_RPK` builds, including those without `OPENSSL_EXTRA` (no
  prior untrusted-RPK handling) and `NO_SHA256` builds (no in-library pinning).
  To establish trust, pin the expected key with the new
  `wolfSSL_set_expected_rpk()` / `wolfSSL_CTX_set_expected_rpk()` APIs
  (requires SHA-256), install a verify callback that accepts the key, or set
  `WOLFSSL_VERIFY_NONE` to accept without authentication.

* **Behavioral change (RSA-PSS trailerField enforcement)**: `DecodeRsaPssParams`
  (and its public wrapper `wc_DecodeRsaPssParams`) now enforces RFC 8017 A.2.3,
  which mandates `trailerField == trailerFieldBC(1)`.  In the default build
  (i.e., without `WOLFSSL_NO_ASN_STRICT`), any certificate or CMS/PKCS#7
  structure whose RSA-PSS parameters contain a `trailerField` value other than 1
  is now rejected with `ASN_PARSE_E`.  Previously, any positive integer value was
  silently accepted.  This affects all call paths that decode RSA-PSS algorithm
  parameters, including X.509 certificate parsing and PKCS#7 signature
  verification.  Users who need to interoperate with non-conformant peers can
  define `WOLFSSL_NO_ASN_STRICT` to restore the previous permissive behavior. (PR 10595)

* Renamed the post-quantum signature implementation from its pre-standardization name *Dilithium* to its NIST-standardized name **ML-DSA** (FIPS 204), mirroring the earlier Kyber -> ML-KEM rename in `wc_mlkem.{h,c}`. The legacy `<wolfssl/wolfcrypt/dilithium.h>` header, `dilithium_key` type, `wc_dilithium_*` / `wc_Dilithium_*` functions, and `HAVE_DILITHIUM` / `WOLFSSL_DILITHIUM_*` / `WC_DILITHIUM_*` build gates remain available through a temporary compatibility shim, so application code keeps compiling unchanged. See doc/dilithium-to-mldsa-migration.md for the full list of renamed symbols, the new `WOLFSSL_MLDSA` cmake option / `--enable-mldsa` configure switch, and the migration steps for moving consumer code to the canonical API. (PR 10436, PR 10497, PR 10516)

* TLS 1.3: zero traffic key staging buffers in `SetKeysSide()` once a CryptoCB callback has imported the AES key into a Secure Element (`aes->devCtx != NULL`).  Clears `keys->{client,server}_write_key` on the provisioned side(s) after cipher init succeeds.  The static IV buffers (`keys->{client,server}_write_IV`, `keys->aead_{enc,dec}_imp_IV`) are intentionally left intact because `BuildTls13Nonce()` reads them on every AEAD record to construct the per-record nonce.  Scoped to TLS 1.3, non-DTLS, non-QUIC; requires `WOLF_CRYPTO_CB` and `WOLF_CRYPTO_CB_AES_SETKEY`. (PR 10246)

* The `wc_AesCmacVerify/_ex` API were hardened to more closely conform to
  NIST SP 800-38B MAC length guidance, and these verify functions will now
  correctly enforce bounds on tag length checks. As a result, Cmac verification
  that previously were erroneously passing will now return `MAC_CMP_FAILED_E`
  or `BAD_FUNC_ARG`. (PR 10462)

## New Features

* Added wolfCrypt SRAM PUF (Physically Unclonable Function) support, deriving device-unique keys from SRAM power-on state using a BCH fuzzy extractor and HKDF (`wc_PufInit`/`wc_PufEnroll`/`wc_PufReconstruct`). by @dgarske (PR 10066)
* Added SHE (Secure Hardware Extension) support to wolfCrypt with software CMD_LOAD_KEY message generation/verification (M1-M5) and optional crypto callback hardware offload. by @night1rider (PR 10009)
* Added `WOLF_CRYPTO_CB_SETKEY` and `WOLF_CRYPTO_CB_EXPORT_KEY` generic crypto callbacks to bridge raw key bytes to and from hardware key stores. by @night1rider (PR 9851)
* Added key id/label constructors (`wc_InitCmac_Id`/`_Label`, `wc_AesNew_Id`/`_Label`, `wc_NewRsaKey_Id`/`_Label`) so algorithms can forward a hardware key-slot identifier. by @night1rider (PR 10072)
* Added RFC 8773(bis) cert_with_extern_psk support for TLS 1.3, with API and handshake tests. by @Frauschi (PR 10085)
* Added native TLS-ALPN-01 ACME challenge certificate support via the RFC 8737 id-pe-acmeIdentifier extension. by @lealem47 (PR 10334)
* Extended `WOLFSSL_SP_NONBLOCK` to RSA and Diffie-Hellman for the C/Small 2048/3072/4096 backends so handshakes never block for long on a single big-integer operation. by @dgarske (PR 10394)
* Added ML-KEM and ML-DSA support to the C# wrapper. by @dgarske (PR 10191)
* Added an HPKE (RFC 9180) C# wrapper. by @dgarske (PR 10171)
* Added `--enable-wolfzfs` support for the wolfCrypt OpenZFS patch in both kernel-space and user-space builds. by @philljj (PR 10397)
* Added a minimal DTLS 1.3 client-only build via `WOLFSSL_DTLS_ONLY` and an `--enable-dtls13` autoconf cascade. by @julek-wolfssl (PR 10353)
* Raised the `--enable-context-extra-user-data` ex_data index limit to 9999 and increased external cookie/extra-user-data maximum sizes for large-scale deployments. by @Roy-Carter (PR 10236)
* Published wolfSSL's external Security Policy and a structured Vulnerability Report Template (`SECURITY-POLICY.md`, `SECURITY-REPORT-TEMPLATE.md`). by @ColtonWilley (PR 10284)
* Extended the OpenSSL compatibility layer for libevent integration, adding struct-tag compatibility defines, `BIO_get_init`, and short-form alert string helpers. by @Roy-Carter (PR 10158, PR 10160)
* Add support for WOLF_CRYPTO_CB_ONLY_SHA512 by @rizlik (PR 10550)
* Support RFC 9802 LMS and XMSS in X.509 certificate and CSR generation by @Frauschi (PR 10572)

## Post-Quantum Cryptography (PQC)

* Added a SHA-512 DRBG and FIPS module-boundary wrappers for ML-KEM, ML-DSA, LMS, XMSS, and SLH-DSA as part of the upcoming post-quantum FIPS submission. by @kaleb-himes (PR 9843)
* Replaced the liboqs-based pre-standardization SPHINCS+ with the native FIPS 205 SLH-DSA implementation throughout the certificate/ASN.1/X.509 layers. by @Frauschi (PR 10261)
* Removed the liboqs integrations for ML-KEM and ML-DSA in favor of the native implementations. by @Frauschi (PR 10293)
* Removed the deprecated liblms and libxmss integrations now that wolfCrypt has its own LMS/XMSS implementations. by @Frauschi (PR 10292)
* Wired RFC 9802 HSS/LMS and XMSS/XMSS^MT stateful hash-based signatures into X.509 certificate verification. by @Frauschi (PR 10406)
* Added crypto callbacks (`MakeKey`/`Sign`/`Verify`/`SigsLeft`) and id/label support for LMS and XMSS. by @padelsbach (PR 10380)
* Added CryptoCb support for SLH-DSA. by @Frauschi (PR 10466)
* Added dynamic key allocation for ML-KEM (`WOLFSSL_MLKEM_DYNAMIC_KEYS`) to right-size key buffers and reduce handshake memory use on constrained systems. by @Frauschi (PR 10179, PR 10206)
* Added dynamic key allocation for ML-DSA (`WOLFSSL_DILITHIUM_DYNAMIC_KEYS`). by @Frauschi (PR 10180)
* Added ML-KEM support for PKCS#11 via the PKCS#11 3.2 encapsulate/decapsulate interface. by @Frauschi (PR 10077)
* Added ML-DSA to `X509_get_pubkey` and `EVP_PKEY_base_id`. by @kojo1 (PR 9965)
* Added ML-DSA SPKI/PKCS#8 DER support to `d2i_PUBKEY`/`d2i_PrivateKey`, `EVP_PKCS82PKEY`, and `X509_check_private_key`. by @cconlon (PR 10310, PR 10483)
* Added Ed25519/Ed448 support to the EVP_PKEY layer and fixed a d2i key-probe bug affecting RSA/ECC/DH. by @lealem47 (PR 10135)
* Fixed PQC key exchange when a ClientHello offers multiple KEM key shares. by @Frauschi (PR 10299)
* Fixed ML-DSA signing when `WC_DILITHIUM_CACHE_MATRIX_A` is enabled. by @embhorn (PR 10400)
* Fixed ML-KEM AVX2 assembly (5-bit decompression and final-block ciphertext comparison). by @SparkiDev (PR 10430)
* Various ML-KEM correctness and key-state validation improvements. by @SparkiDev (PR 10405)
* Reduced the ML-DSA verify-only key object size and allowed SHAKE-only builds without the SHA-3 APIs. by @SparkiDev (PR 10420)
* LMS fixes and improvements including a 32-bit signature length, hash-algorithm parameter accessors, and empty-message signing. by @SparkiDev (PR 10448)
* Migrate internal ML-KEM consumers to canonical wc_MlKemKey API by @Frauschi (PR 10571)
* Add PQ documentation for LMS, ML-DSA, ML-KEM, XMSS by @kaleb-himes (PR 10514)
* Various leak / alloc and zeroization fixes for SLH-DSA by @Frauschi (PR 10698)

## TLS/DTLS

* Multiple TLS 1.3 Encrypted Client Hello (ECH) compliance fixes per RFC 9849, covering rejection handling, ECHConfig parsing, and inner ClientHello validation. by @sebastian-carpenter (PR 10141)
* Added client-side ECH ech_outer_extensions encoding to shrink the HPKE-sealed inner ClientHello. by @sebastian-carpenter (PR 10306)
* Added maximum_name_length padding for the ECH ClientHelloInner and a new `wolfSSL_CTX_GenerateEchConfigEx()` API. by @sebastian-carpenter (PR 10326)
* Added opt-in ECH trial decryption (`wolfSSL_CTX_SetEchEnableTrialDecrypt()`) and ECH connection-status reporting. by @sebastian-carpenter (PR 10469)
* Evict the session from cache after an accepted 0-RTT resumption to prevent early-data replay (RFC 8446 section 8). by @julek-wolfssl (PR 10221)
* Gate 0-RTT acceptance on a cache-backed resumption ticket and stop auto-advertising 0-RTT unless the application requests it. by @julek-wolfssl (PR 10289)
* Send a missing_extension alert when the SNI extension is absent in TLS 1.3. by @jackctj117 (PR 10332)
* Reject extensions in a TLS 1.3 Certificate message that were not offered in the prior ClientHello/CertificateRequest (RFC 8446 section 4.4.2). by @gasbytes (PR 10338)
* Error out on unknown/unsolicited extensions in TLS 1.3 response messages while still tolerating GREASE in NewSessionTicket. by @Frauschi (PR 10186)
* Fixed encrypt-then-mac handling on the non-resumption path. by @embhorn (PR 10167)
* Fixed a TLS 1.3 AEAD/KeyUpdate limit that used 16-bit counters where 32-bit values were required. by @SparkiDev (PR 10513)
* Decoupled the speculative ClientHello key share from `preferredGroup[0]` via `WOLFSSL_KEY_SHARE_DEFAULT_GROUP` to reduce HelloRetryRequests. by @Frauschi (PR 10435)
* Fixed DTLS 1.3 unnecessary client retransmission after HelloRetryRequest and improved server robustness. by @rizlik (PR 10349)
* Free and NULL the DTLS 1.3 cipher slot on init failure. by @gasbytes (PR 10360)
* Added a `WOLFSSL_DTLS13_5_9_0_COMPAT` compatibility mode for interoperating with pre-5.9.0 DTLS 1.3 clients. by @rizlik (PR 10492)
* Added a missing `WOLFSSL_QUIC_MAX_RECORD_CAPACITY` check on the QUIC early-data path. by @gasbytes (PR 10201)
* Default `WOLFSSL_MAX_SIGALGO` to 128. by @julek-wolfssl (PR 10528)
* Added NID_X25519 and NID_X448 support to the EVP layer. by @julek-wolfssl (PR 10552)
* Enabled the all-zero shared-secret check for Curve25519/Curve448 by default and ensured post_handshake_auth was offered before accepting a post-handshake CertificateRequest. by @kareem-wolfssl (PR 10374)
* Fixed a DupSSL (write-dup) issue with Poly1305 authentication. by @embhorn (PR 10337)
* Various X509 enhancements and fixes by @SparkiDev (PR 10548)
* Cache AEAD record overhead on WOLFSSL by @julek-wolfssl (PR 10476)
* Add keylog support for TLS 1.3 ECH by @sebastian-carpenter (PR 10259)
* Enhance OCSP responder authorization by @rlm2002 (PR 10532)
* Allow RSA client certs on ECDHE-ECDSA mutual auth by @julek-wolfssl (PR 10553)
* Enforce only 1 protocolname in serverhello by @anhu (PR 10443)
* Fix tls_bench DTLS mode failures by @miyazakh (PR 10606)
* Fix cipher property NIDs for SSL_get_current_cipher and add PSK kx mapping by @julek-wolfssl (PR 10639)

## ASN and Certificate Parsing

* Allow serial number 0 for self-signed root CA certificates while keeping the RFC 5280 check for others. by @jackctj117 (PR 9567)
* Fixed peer certificate verification with IP address SAN entries. by @embhorn (PR 10169)
* Fixed partial chain verification to only terminate at a certificate present in the original trust set. by @embhorn (PR 10170)
* Apply DNS name constraints to the Subject CN when no SAN is present. by @rlm2002 (PR 10223)
* Fixed IDNA wildcard matching. Thanks to Andrew Chin, SSLab at Georgia Institute of Technology. by @embhorn (PR 10331)
* Honor the otherName GeneralName form in name-constraint checks and add `WOLFSSL_X509_STORE_ALLOW_NON_CA_INTERMEDIATE` for backward compatibility. by @embhorn (PR 10339)
* Always parse and store iPAddress and registeredID GeneralNames for name-constraint enforcement. by @embhorn (PR 10354) Thanks to Ankur Tyagi of Cisco Talos for the report.
* Hardened X.509 chain validation, session-ticket peer-cert binding, and peer-cert restore, and reject embedded NUL in dNSName/rfc822Name/URI SAN entries. by @julek-wolfssl (PR 10279)
* Restrict domain-name pattern matching and case folding to valid FQDNs via a new `IsValidFQDN()` helper. by @douzzer (PR 10183, PR 10419)
* Report a certificate verify failure for MD5-signed certificates during chain verification. by @embhorn (PR 10222)
* Make SHA-1-with-RSA the last-resort signature type, as SHA-1 signatures are deprecated. by @SparkiDev (PR 10173)
* Tightened the key length check in `wc_SignatureGetSize()` from `>=` to exact equality. by @miyazakh (PR 10122)
* Fixed a malformed AKID extension produced by `wolfSSL_X509_set_authority_key_id()`. by @cconlon (PR 10370)
* Set the PKCS#8 (RFC 5958) version correctly when a private key bundles the optional publicKey field. by @cconlon (PR 10427)
* Bind OCSP responder authorization to the CertID issuerKeyHash. by @julek-wolfssl (PR 10303)
* Fixed multi-CRL PEM bundles being truncated to the first CRL in `wolfSSL_PEM_read_bio_X509_CRL`. by @julek-wolfssl (PR 10336)
* Reject CRLs with unrecognized critical extensions and critical entry extensions per RFC 5280. by @gasbytes (PR 10239, PR 10274)
* Validate DSA parameters when verifying a DSA key. by @kareem-wolfssl (PR 10381).  Thanks to Kr0emer for the report.
* Validate parameters in `wolfSSL_EC_POINT_hex2point`. Thanks to breakingbad6, Yanzhao Shen, and Yingpei Zeng (Hangzhou Dianzi University). by @embhorn (PR 10445)
* Adjusted the CA pathlen check and added glitch hardening when a trust anchor is included in the certificate chain. by @JacobBarthelmeh (PR 10296)
* Added ascii-digit validation in the ASN.1 time decode functions. by @padelsbach (PR 10276)
* Allow a SubjectInfoAccess extension without an id-ad-caRepository entry. by @holtrop-wolfssl (PR 10368)
* Tighten RFC 8017 A.2.3 compliance for RSA-PSS by @miyazakh (PR 10595)

## Hardware and Embedded Ports

* Reworked the Microchip TA-100 port for cryptoauthlib v3.6.0, with AES-GCM now working. by @danielinux (PR 9702)
* Added wolfCrypt hardware crypto support for NXP LPC55S69. by @twcook86 (PR 10278)
* Added STM32U3 hardware crypto support (AES, hash, TRNG). by @dgarske (PR 10361)
* Fixed STM32 AES hardware crypto when `WOLFSSL_ARMASM` is set. by @dgarske (PR 10311)
* Allow custom time functions on STM32 by not forcing `NO_ASN_TIME` when `XTIME` is defined. by @lealem47 (PR 10295)
* Fixed NXP DCP AES multiblock CBC encrypt/decrypt and the in-place case. by @padelsbach (PR 10307)
* Fixed Octeon/Cavium AES-GCM AAD GHASH and non-12-byte IV J0 derivation bugs. by @ejohnstown (PR 10439) and @JacobBarthelmeh (PR 10471)
* SE050 fixes plus new `SE050_RSA_NO_VERIFY`/`SE050_ECDSA_NO_VERIFY`/`SE050_ECDSA_NO_ECDHE` options and simulator CI. by @rizlik (PR 10219)
* Improved MQX/Fusion RTOS compatibility for `XINET_PTON` (MQX RTCS support, IPv6 buffer sizing). by @josepho0918 (PR 10075)
* Added Zephyr 4.3 default TLS-socket support. by @ColtonWilley (PR 10268)
* Fixed wolfSSL support on the CHERI RISC-V architecture. by @wbeasley-thegoodpenguin (PR 10272)
* Revived and hardened the IoT-Safe memory-TLS example. by @danielinux (PR 10457)
* Fixed the NXP CAAM build when WOLFSSL_HASH_KEEP is not defined. by @JacobBarthelmeh (PR 10459)
* Set `hashType` in port hash implementations so SHA-512 modes can be distinguished. by @padelsbach (PR 10193)
* Fixed the LMS/XMSS crypto callback software fallback to propagate `CRYPTOCB_UNAVAILABLE`. by @padelsbach (PR 10456)
* Fixed a PIC32 hardware-acceleration stack-pointer free bug and added PIC32MZ emulator tests. by @LinuxJedi (PR 10495)
* Numerous hardware/embedded port hardening fixes (Xilinx/AMD, PSoC6, TROPIC01, devcrypto, RX64, STM32, KCAPI, QAT) from Fenrir review. by @JacobBarthelmeh (PR 10467, PR 10470, PR 10508) and @dgarske (PR 10496)
* Implements the SHA accelerator for MAX32666 as bare-metal by @mattia-moffa (PR 10431)

## Rust Wrapper

* Added rand_core, aead, and cipher crate trait implementations. by @holtrop-wolfssl (PR 10070)
* Added digest and signature crate trait implementations. by @holtrop-wolfssl (PR 10248)
* Added password-hash, kem, and mac crate trait implementations. by @holtrop-wolfssl (PR 10305)
* Added zeroize-on-drop and fixed Fenrir findings across the crate. by @holtrop-wolfssl (PR 10205)
* Ensured memory safety for the C RNG struct and added functionality found during boringtun integration. by @holtrop-wolfssl (PR 10402)
* Added buffer-size checks to the ChaCha20-Poly1305 one-shot wrappers. by @holtrop-wolfssl (PR 10267)
* Add scrypt KDF and RSA-OAEP support by @holtrop-wolfssl (PR 10556)

## Build System and Portability

* Removed unused m4 macros and updated AX_PTHREAD to the latest autoconf-archive macro. by @BrianAker (PR 10106)
* Guard `<stddef.h>` behind `NO_STDDEF_H` and userspace fcntl/filesystem code behind `WOLFSSL_KERNEL_MODE`. by @philljj (PR 10280, PR 10521)
* Support building `--enable-opensslextra` with `NO_BIO` and `NO_FILESYSTEM`. by @JacobBarthelmeh (PR 10393)
* Allow `--enable-writedup` when DTLS is disabled. by @mattia-moffa (PR 10527)
* Set `WOLFSSL_USE_ALIGN` automatically for ARM user_settings.h builds. by @embhorn (PR 10487)
* Added `WC_LINUXKM_USE_HEAP_WRAPPERS` heap wrappers and AES-CCM LKCAPI shims for the Linux kernel module. by @douzzer (PR 10512, PR 10194)
* linuxkm enhancements for wolfGuard support by @douzzer (PR 10590)
* Added a software CryptoCb test device and `WOLF_CRYPTO_CB_ONLY_*` test infrastructure (SHA-256, SHA-224, AES). by @rizlik (PR 10351, PR 10500)
* Added configure and CMake options for `WOLF_CRYPTO_CB_RSA_PAD`. by @kareem-wolfssl (PR 10428)
* Fixed mem_track.h compilation on multi-threaded non-Linux builds. by @LinuxJedi (PR 10453)
* Fixed CUDA builds with `WOLFSSL_AES_SMALL_TABLES`. by @embhorn (PR 10366)
* Skip testsuite.test for `--enable-leantls` builds. by @miyazakh (PR 10510)
* RPM packaging fixes for examples/cmake artifacts and RHEL10 LTO builds. by @space88man (PR 10270, PR 10356) and @twcook86 (PR 10275)
* Fixed the SGX build to not require fcntl.h. by @JacobBarthelmeh (PR 10524)
* Various linuxkm Fenrir fixes by @douzzer (PR 10688)
* Various bsdkm fixes and cleanup by @philljj (PR 10565)

## Bug Fixes

* AES-CCM encryption/decryption with 13 or 12 byte nonces and large messages (>1 MiB and >256 MiB respectively) were not properly rejected at argument validation time, allowing counter wrap, keystream reuse, and consequent plaintext recovery. Thanks to NVIDIA Project Vanessa for the report. (PR 10709)
* Out-of-bounds write in wolfSSL_get_finished() and wolfSSL_get_peer_finished(). The functions validated the caller buffer against TLS_FINISHED_SZ (12 bytes) but copied the full Finished message, which for TLS 1.3 is the handshake hash size (32 or 48 bytes), overrunning a correctly sized 12-byte buffer. The output length is now validated before the copy. Thanks to Qiushi Wu from IBM Research for the report. (PR 10576)
* Fix for rejecting the import of a public key that is the identity element with Ed448. Use of a public key that is the identity element allows for crafting a forged signature that verifies with that specific public key. wolfSSL does not generate an Ed448 key pair that is the identity element. This defense-in-depth hardening for Ed448 and has been available since release 5.9.1. Thanks to Nicholas Carlini from Anthropic for the report. (PR 10116)
* Fix for !aNULL after an explicit ADH suite leaving the anon suite available. Thanks to NVIDIA Project Vanessa for the report. (PR 10714)
* P-521 ECDH SP-math validates 65 bytes but writes 66 leading to a 1-byte heap overflow. Thanks to NVIDIA Project Vanessa for the report. (PR 10702)
* Fix for FreeBSD kernel module to have additional sanity checks on IV size when copying. This avoids a stack overflow in --enable-freebsdkm-crypto-register builds used for preliminary testing. Thanks to NVIDIA Project Vanessa for the report. (PR 10695)
* Added an upper limit to the PBKDF iteration count and changed iterations <= 0 to fail closed instead of silently clamping to 1. by @anhu (PR 10050) and @miyazakh (PR 10504)
* Added MP integer size bounds checks in `SizeASN_Items`. by @anhu (PR 10051)
* Ensure certificates are correctly added to the cert manager. by @anhu (PR 10073)
* Use `O_CLOEXEC` at file creation to harden against multithread races. by @embhorn (PR 10162)
* BIO improvements and fixes, including an out-of-bounds read and an inverted ctrl_pending check. by @rizlik (PR 10164)
* Guard against negative lengths in BIO, I/O callbacks, and PKCS12 PBKDF. by @ColtonWilley (PR 10208)
* Fixed a dangling `secure_renegotiation` pointer after `TLSX_FreeAll`. by @ColtonWilley (PR 10210)
* Added missing NULL checks across public API entry points. by @ColtonWilley (PR 10216)
* Fixed NULL dereferences, a DSA SignFinal overflow, and the i2d contract across EVP/OCSP/X509. by @ColtonWilley (PR 10217)
* Enforce the minimum auth tag size in `wc_AesGcmDecryptFinal`. by @yosuke-wolfssl (PR 10175)
* AES-EAX and AES-SIV lifecycle and NULL-check fixes. by @SparkiDev (PR 10174)
* Added a C implementation for ARM AES-GCM small-table builds without NEON. by @SparkiDev (PR 10176)
* SP integer fixes for negative numbers, zero-used edge cases, bounds, and truncation, plus added testing. by @SparkiDev (PR 10235, PR 10529) and @embhorn (PR 10478) Thanks to Kr0emer for reporting these issues and testing the fixes.
* Fixed the Curve25519 private-key clamp check to enforce RFC 7748 rule 3. by @MarkAtwood (PR 10363)
* Fixed the Blake2 oversized-key path. by @mattia-moffa (PR 10447)
* Fixed a SAKKE heap buffer overflow and a correctness gap in `sakke_hash_to_range`, plus a `wc_export_int` size check. by @JeremiahM37 (PR 10442) and @philljj (PR 10444)
* Added checks to `PKCS7_VerifySignedData` to prevent out-of-bounds access. Thanks to Feng Ning / Innora. by @padelsbach (PR 10441)
* Various PKCS#7 fixes. by @Frauschi (PR 10203) and @kareem-wolfssl (PR 10128)
* Various PKCS#12 fixes including strict-aliasing, zeroization, and overflow checks. by @rlm2002 (PR 10378)
* Fixed an ECC temporary-key leak and undefined behavior, and an ECC validation regression. by @Frauschi (PR 10346, PR 10260)
* Fixed a double free in `wolfSSL_X509_set_ext`. by @padelsbach (PR 10481)
* Reset the SHA-3 hashType between ML-KEM cryptocb calls. by @night1rider (PR 10211)
* Plumb the caller heap into CMAC before the cryptocb fires. by @night1rider (PR 10401)
* Fixed inverted AllocDer checks in the alt private key id/label paths. by @night1rider (PR 10168)
* TLS extension bounds-checking fixes. Thanks to Suryansh Mansharamani (Plainshift AI). by @embhorn (PR 10220)
* Hardened `TLSX_KeyShare_ProcessPqcHybridClient` against double free and wrong-key NULLing. by @embhorn (PR 10327) and @kareem-wolfssl (PR 10493)
* Various missing bounds and length checks. by @kareem-wolfssl (PR 10142, PR 10277)
* Fixed the `NO_VERIFY_OID` build in `GetOID`. Thanks to @cpsource. by @JeremiahM37 (PR 10440)
* Ensure large buffers are heap-allocated under `WOLFSSL_SMALL_STACK`. by @Frauschi (PR 10245)
* Fixed private key lock issues. by @kaleb-himes (PR 10446)
* Improved HPKE return codes to use defined error values. by @sebastian-carpenter (PR 10455)
* MD4 and MD2 public APIs now return int instead of void, alongside static-analysis fixes for SECO, devcrypto, and ARIA. by @JacobBarthelmeh (PR 10460)
* Extensive wolfCrypt input-validation, key-zeroization, and side-channel hardening across RSA, ECC, EdDSA, Curve25519/448, DH, SRP, PKCS#7, KDF, LMS, and PQ key handling. by @JeremiahM37 (PR 10136, PR 10231, PR 10238, PR 10264, PR 10304, PR 10340, PR 10386, PR 10392, PR 10413, PR 10426, PR 10468), @julek-wolfssl (PR 10230, PR 10247, PR 10398), and @aidangarske (PR 10155)
* Fixed a word32 size overflow in wc_DeCompressDynamic that could under-allocate a buffer and cause a heap overflow on --with-libz + PKCS7-compressed builds. by @JeremiahM37 (PR #10413).
* Resolved numerous Coverity static-analysis findings. by @rlm2002 (PR 10129, PR 10165, PR 10376, PR 10418, PR 10482)
* Enforce MAX_ENTROPY_BITS upper bound in wc_Entropy_Get() by @miyazakh (PR 10593)
* Various EVP API bug fixes by @MarkAtwood (PR 10364, PR 9987)
* Various ppc and armv8 asm and linuxkm fixes by @douzzer (PR 10600)
* Fixes for Zephyr secure sockets integration by @Frauschi (PR 10583)
* Add signed-length validation to d2i, PEM, and buffer-load APIs to harden against potential out of bounds case by @ColtonWilley (PR 10207)
* Reject duplicate certificatePolicies certificate extensions (RFC 5280), previously accepted as last-wins by @Frauschi (PR 10714)
* Strengthen subgroup check in wc_DhAgree by @philljj (PR 10560). Thanks to Muhammad Arya Arjuna Habibullah (Pelioro) for the report.
* Fix missing private key zeroization in ML-KEM by @anhu (PR 10665). Thanks to Uday Devaraj, SYNE Lab, Syracuse University.
* Force-zero wc_AesSivDecrypt output buffer on authentication failure by @holtrop-wolfssl (PR 10668)
* Ed448: check for public key presence on export by @holtrop-wolfssl (PR 10656)
* Hardening fixes in wolfSSL_strnstr and mp_get_digit. Thanks to Dominik Blain / COBALT Security for the bug report. by @padelsbach (PR 10138)

## Documentation and Maintenance

* Added documentation for the new OCSP responder and certificate accessor APIs. by @julek-wolfssl (PR 10147)
* Improved API documentation argument descriptions for the sigalgs/groups/cipher-list/options setters. by @kojo1 (PR 10382)
* Added doxygen coverage for the SHE API. by @night1rider (PR 10243)
* Added the `BN_bn2binpad` API. by @julek-wolfssl (PR 10148)
* Added TLS 1.3 decryption fuzz tests, Monte Carlo / unaligned / in-place cipher tests, and expanded negative test coverage for handshake, AEAD, PKCS7, PSS, DSA, DRBG, and PQ paths. by @SparkiDev (PR 10461, PR 10213, PR 10226) and @JeremiahM37 (PR 10166, PR 10291)
* Various improvements to CI efficiency and parallelism by @julek-wolfssl (PR 10667, PR 10685, PR 10701, PR 10731)


# wolfSSL Release 5.9.1 (Apr. 8, 2026)

Release 5.9.1 has been developed according to wolfSSL's development and QA
process (see link below) and successfully passed the quality criteria.
https://www.wolfssl.com/about/wolfssl-software-development-process-quality-assurance

NOTE:
* --enable-heapmath is deprecated
* MD5 is now disabled by default

PR stands for Pull Request, and PR <NUMBER> references a GitHub pull request number where the code change was added.

## Vulnerabilities

* [Critical] CVE-2026-5194
Missing hash/digest size and OID checks allow digests smaller than allowed by FIPS 186-4 or 186-5 (as appropriate), or smaller than is appropriate for the relevant key type, to be accepted by signature verification functions, reducing the security of certificate-based authentication. Affects multiple signature algorithms, including ECDSA/ECC, DSA, ML-DSA, ED25519, and ED448. Builds that have both ECC and EdDSA or ML-DSA enabled that are doing certificate verification are recommended to update to the latest wolfSSL release. Thanks to Nicholas Carlini from Anthropic for the report. Fixed in PR 10131.

* [High] CVE-2026-5264
Heap buffer overflow in DTLS 1.3 ACK message processing. A remote attacker can send a crafted DTLS 1.3 ACK message that triggers a heap buffer overflow. Thanks to Sunwoo Lee and Seunghyun Yoon, Korea Institute of Energy Technology (KENTECH). Fixed in PR 10076.

* [High] CVE-2026-5263
URI nameConstraints from constrained intermediate CAs are parsed but not enforced during certificate chain verification in wolfcrypt/src/asn.c. A compromised or malicious sub-CA could issue leaf certificates with URI SAN entries that violate the nameConstraints of the issuing CA, and wolfSSL would accept them as valid. Thanks to Oleh Konko @1seal for the report. Fixed in PR 10048.

* [High] CVE-2026-5295
Stack buffer overflow in PKCS7 ORI (Other Recipient Info) OID processing. When parsing a PKCS7 envelope with a crafted ORI OID value, a stack-based buffer overflow can be triggered. Thanks to Sunwoo Lee, Woohyun Choi, and Seunghyun Yoon (Korea Institute of Energy Technology, KENTECH). Fixed in PR 10116.

* [High] CVE-2026-5466
wolfSSL's ECCSI signature verifier `wc_VerifyEccsiHash` decodes the `r` and `s` scalars from the signature blob via `mp_read_unsigned_bin` with no check that they lie in `[1, q-1]`. A crafted forged signature could verify against any message for any identity, using only publicly-known constants. Thanks to Calif.io in collaboration with Claude and Anthropic Research for the report. Fixed in PR 10102.

* [High] CVE-2026-5477
Potential for AES-EAX AEAD and CMAC authentication bypass on messages larger than 4 GiB. An attacker who observes one valid (ciphertext, tag) pair for a >4 GiB EAX message can replace the first 4 GiB of ciphertext arbitrarily while the tag still verifies. Thanks to Calif.io in collaboration with Claude and Anthropic Research for the report. Fixed in PR 10102.

* [High] CVE-2026-5447
Heap buffer overflow in CertFromX509 via AuthorityKeyIdentifier size confusion. A heap buffer overflow occurs when converting an X.509 certificate internally due to incorrect size handling of the AuthorityKeyIdentifier extension. Thanks to Calif.io in collaboration with Claude and Anthropic Research for the report. Fixed in PR 10112.

* [High] CVE-2026-5500
wolfSSL's `wc_PKCS7_DecodeAuthEnvelopedData()` does not properly sanitize the AES-GCM authentication tag length received and has no lower bounds check. A man-in-the-middle can therefore truncate the `mac` field from 16 bytes to 1 byte, reducing the tag check from 2⁻¹²⁸ to 2⁻⁸. Thanks to Calif.io in collaboration with Claude and Anthropic Research for the report. Fixed in PR 10102.

* [High] CVE-2026-5501
`wolfSSL_X509_verify_cert()` in the OpenSSL compatibility layer accepts a certificate chain in which the leaf's signature is not checked, if the attacker supplies an untrusted intermediate with Basic Constraints `CA:FALSE` that is legitimately signed by a trusted root. An attacker who obtains any leaf certificate from a trusted CA (e.g. a free DV cert from Let's Encrypt) can forge a certificate for any subject name with any public key and arbitrary signature bytes, and the function returns `WOLFSSL_SUCCESS` / `X509_V_OK`. The native wolfSSL TLS handshake path (`ProcessPeerCerts`) is not susceptible and the issue is limited to applications using the OpenSSL compatibility API directly. Thanks to Calif.io in collaboration with Claude and Anthropic Research for the report. Fixed in PR 10102.

* [High] CVE-2026-5503
In TLSX_EchChangeSNI, the ctx->extensions branch set extensions unconditionally even when TLSX_Find returned NULL. This caused TLSX_UseSNI to attach the attacker-controlled publicName to the shared WOLFSSL_CTX when no inner SNI was configured. TLSX_EchRestoreSNI then failed to clean it up because its removal was gated on serverNameX != NULL. The inner ClientHello was sized before the pollution but written after it, causing TLSX_SNI_Write to memcpy 255 bytes past the allocation boundary. Thanks to Calif.io in collaboration with Claude and Anthropic Research for the report. Fixed in PR 10102.

* [High] CVE-2026-5479
In wolfSSL's EVP layer, the ChaCha20-Poly1305 AEAD decryption path in wolfSSL_EVP_CipherFinal (and related EVP cipher finalization functions) fails to verify the authentication tag before returning plaintext to the caller. When an application uses the EVP API to perform ChaCha20-Poly1305 decryption, the implementation computes or accepts the tag but does not compare it against the expected value. Thanks to Calif.io in collaboration with Claude and Anthropic Research for the report. Fixed in PR 10102.

* [Med] CVE-2026-5392
Heap out-of-bounds read in PKCS7 parsing. A crafted PKCS7 message can trigger an OOB read on the heap. The missing bounds check is in the indefinite-length end-of-content verification loop in PKCS7_VerifySignedData(). This only affects builds with PKCS7 support enabled. Thanks to J Laratro (d0sf3t) for the report. Fixed in PR 10039.

* [Med] CVE-2026-5446
ARIA-GCM nonce reuse in TLS 1.2 record encryption. ARIA cipher support requires a proprietary Korean library (MagicCrypto) and --enable-aria, limiting real-world exposure. Thanks to Calif.io in collaboration with Claude and Anthropic Research for the report. Fixed in PR 10111.

* [Med] CVE-2026-5460
When a malicious TLS 1.3 server sends a ServerHello with a truncated PQC hybrid KeyShare (e.g., P256_ML_KEM_512 with 10 bytes instead of the required 768+), the error cleanup path double-frees the KyberKey. Thanks to Calvin Young (eWalker Consulting Inc.) and Enoch Chow (Isomorph Cyber). Fixed in PR 10092.

* [Med] CVE-2026-5504
A padding oracle exists in wolfSSL's PKCS7 CBC decryption that could allow an attacker to recover plaintext through repeated decryption queries with modified ciphertext. In previous versions of wolfSSL the interior padding bytes are not validated. Thanks to Sunwoo Lee, Woohyun Choi, and Seunghyun Yoon of Korea Institute of Energy Technology (KENTECH) for the report. Fixed in PR 10088.

* [Med] CVE-2026-5507
When restoring a session from cache, a pointer from the serialized session data is used in a free operation without validation. An attacker who can poison the session cache could trigger an arbitrary free. Exploitation requires the ability to inject a crafted session into the cache and for the application to call specific session restore APIs. Thanks to Sunwoo Lee, Woohyun Choi, and Seunghyun Yoon of Korea Institute of Energy Technology (KENTECH) for the report. Fixed in PR 10088.

* [Low] CVE-2026-5187
Heap out-of-bounds write in DecodeObjectId() caused by an off-by-one bounds check combined with a sizeof mismatch. A crafted ASN.1 object identifier can trigger a small heap OOB write. Thanks to Yuteng for the report. Fixed in PR 10025.

* [Low] CVE-2026-5188
An integer underflow issue exists in wolfSSL when parsing the Subject Alternative Name (SAN) extension of X.509 certificates. A malformed certificate can specify an entry length larger than the enclosing sequence, causing the internal length counter to wrap during parsing. This results in incorrect handling of certificate data. The issue is limited to configurations using the original ASN.1 parsing implementation. The original ASN.1 parsing implementation is off by default. Thanks to Muhammad Arya Arjuna Habibullah for the report. Fixed in PR 10024.

* [Low] CVE-2026-5448
X.509 date buffer overflow in wolfSSL_X509_notAfter / wolfSSL_X509_notBefore. A buffer overflow may occur when parsing date fields from a crafted X.509 certificate via the compatibility layer API. This is only triggered when calling these two APIs directly from an application, and does not affect TLS or certificate verify operations in wolfSSL. Thanks to Sunwoo Lee and Seunghyun Yoon, Korea Institute of Energy Technology (KENTECH) for the report. Fixed in PR 10071.

* [Low] CVE-2026-5772
A 1-byte stack buffer over-read exists in the MatchDomainName function in src/internal.c when processing wildcard patterns with the LEFT_MOST_WILDCARD_ONLY flag active. When a wildcard '*' exhausts the entire hostname string (strLen reaches 0), the function proceeds to compare remaining pattern characters against the now-exhausted buffer without a bounds check, causing an out-of-bounds read. Thanks to Zou Dikai for the report. Fixed in PR 10119.

* [Low] CVE-2026-5778
An integer underflow exists in the ChaCha20-Poly1305 decryption path where a malformed TLS 1.2 record with a payload shorter than the AEAD MAC size causes the message length calculation to underflow, resulting in an out-of-bounds read. This only affects sniffer builds. Thanks to Zou Dikai for the report. Fixed in PR 10125.

## Experimental Build Vulnerability

* [Med] CVE-2026-5393
Dual-Algorithm CertificateVerify out-of-bounds read. When processing a dual-algorithm CertificateVerify message, an out-of-bounds read can occur on crafted input. This can only occur when --enable-experimental and --enable-dual-alg-certs is used when building wolfSSL. Thanks to Sunwoo Lee, Woohyun Choi, and Seunghyun Yoon (Korea Institute of Energy Technology, KENTECH) for testing the fix. Fixed in PR 10079.

## New Features
* Enabled PQC algorithm ML-KEM (FIPS203) on by default. by @Frauschi (PR 9732)
* Added brainpool curve support to wolfSSL_CTX_set1_sigalgs_list. by @kojo1 (PR 9993)
* Implemented wolfSSL_Atomic_Int_Exchange() in wolfssl/wolfcrypt/wc_port.h and wolfcrypt/src/wc_port.c. by @douzzer (PR 10036)
* Added a GPLv2 license exception for VDE (Virtual Distributed Ethernet) to the licensing terms. by @danielinux (PR 10107)
* Added DTLS 1.3/TLS 1.3 write-dup (Duplicate SSL) support so the read-side can delegate post-handshake work (KeyUpdate responses, DTLS13 ACK sending, post-handshake auth) to the write-side, along with new tests and CI coverage. (PR 10006)

## Post-Quantum Cryptography (PQC)
* Fixed Dilithium API to use byte type for context length parameters, enforcing the 0–255 byte constraint. by @SparkiDev (PR 10010)
* Fixed benchmarking for ML-DSA with static memory enabled. by @JacobBarthelmeh (PR 9970)
* Added checks to verify the private key is set before performing private key operations in Ed25519, Ed448, ML-DSA, and ML-KEM. by @anhu (PR 10083)
* Added buffer size and callback validation checks to wc_LmsKey_Sign to prevent signing with insufficient output buffer or missing required callbacks. Thanks to Sunwoo Lee, Woohyun Choi, and Seunghyun Yoon (Korea Institute of Energy Technology, KENTECH) for the report. (PR 10084)
* Fixed an out-of-bounds shift in the ML-DSA implementation by ensuring the cast is performed before large shift operations in dilithium.c. Thanks to Dominik Blain / COBALT Security for the bug report. by @padelsbach (PR 10096)
* Zeroize sensitive memory buffers in the ML-DSA (Dilithium) implementation to prevent leakage of cryptographic material. by @Frauschi (PR 10100)
* Fixed undefined behavior in SLH-DSA key initialization by casting to unsigned before performing a left shift that could set the MSB. by @padelsbach (PR 10104)
* Added null checks for buffer size and callback validity in the external wc_LmsKey_Sign function to prevent CI failures. by @padelsbach (PR 10105)
* Ensured that the heap buffer used (among others) to store sensitive data during ML-DSA signing is zeroized before freeing the memory. Thanks to Abhinav Agarwal (@abhinavagarwal07) for the report. (PR 10113)
* The legacy non-context ML-DSA (Dilithium) API is now guarded behind WOLFSSL_DILITHIUM_NO_CTX, making the context-aware FIPS 204 API the default and adding a no-ctx configure option to explicitly re-enable the legacy path. by @Frauschi (PR 10047)

## TLS/DTLS
* Fixed handling of OCSP_WANT_READ return value in the TLS 1.3 handshake message type processing to prevent incorrect error propagation during OCSP stapling operations. by @julek-wolfssl (PR 9995)
* Fixed a bug in the HPKE implementation where the KDF digest was incorrectly used for the KEM, and refactored HPKE-related code out of the TLS/ECH layer into dedicated local functions, adding tests for all 24 algorithm combination variants. by @sebastian-carpenter (PR 9999)
* Fixed DTLS 1.3 ServerHello to not echo the legacy_session_id field, bringing the implementation into compliance with the DTLS 1.3 specification. by @julek-wolfssl (PR 10007)
* Fixed a TLS 1.3 server issue where a mismatched ciphersuite in a second ClientHello following a HelloRetryRequest was incorrectly accepted instead of rejected. by @sebastian-carpenter (PR 10034)
* Fixed a possible memory leak in ECC non-blocking cryptography operations within the TLS layer. by @dgarske (PR 10065)
* Fixed multiple correctness issues in DTLS 1.3 and TLS 1.3 including wrong return values, missing bounds checks, a PSK identity buffer overread, swapped server/client parameters in finished secret derivation, a static array data race, resource leaks, and a potential NULL dereference in the SM3 exporter path. by @gasbytes (PR 10117)

## ASN and Certificate Parsing
* Added wolfSSL_check_ip_address() to support filtering connections based on Subject Alternative Name (SAN) IP address entries, mirroring the existing domain name check functionality. by @padelsbach (PR 9935)
* Added host name verification from the verification context parameter when calling wolfSSL_X509_verify_cert. by @julek-wolfssl (PR 9952)
* Moved non-template (WOLFSSL_ASN_ORIGINAL) code into asn_orig.c and include from asn.c. by @dgarske (PR 9920)
* Fixed additional potential null pointer dereferences in ASN parsing code identified by Coverity static analysis. by @rlm2002 (PR 9990)
* Fixed wolfssl/wolfcrypt/asn.h to directly include wolfssl/wolfcrypt/sha512.h for WC_SHA384_DIGEST_SIZE and WC_SHA512_DIGEST_SIZE. Previously this relied on transitive include order and broke builds where asn.h is parsed before hash.h/sha512.h. by @danielinux (PR 10014)
* Removed FIPS-conditional guards from the GetASN_BitString length check so the validation applies in all builds. by @embhorn (PR 10027)
* Added validation to reject negative ASN.1 integers in CRL number fields during decoding, preventing an overflow that could corrupt the adjacent hash field. Thanks to Sunwoo Lee for the bug report. by @padelsbach (PR 10087)

## Hardware and Embedded Ports
* Fixed SE050 hardware security module integration by routing RSA-PSS sign/verify operations through the software path to prevent double-hashing, releasing persistent SE050 key slots on free for RSA, ECC, Ed25519, and Curve25519 keys, and adding missing mutex unlock calls before early returns in RSA crypto functions. by @LinuxJedi (PR 9912)
* When WOLFSSL_NO_HASH_RAW is defined due to hardware hash offload, turn on LMS and XMSS full hash. Without this they will not compile automatically when there is hardware SHA acceleration. by @LinuxJedi (PR 9946)
* Applied AI-review fixes across hardware and embedded port implementations spanning Espressif, Renesas, Silicon Labs, NXP, STM32, TI, Xilinx, and numerous other targets to improve correctness and code quality. by @SparkiDev (PR 10003)
* Fixed issues found by the testing of the MAX32666 tests. by @night1rider (PR 10035)
* Fixed buffer overflows, key material exposure, mutex leaks, and logic errors across hardware crypto port backends. by @JeremiahM37 (PR 10080)

## Rust Wrapper
* Released version 1.2.0 of the wolfssl-wolfcrypt Rust crate with updated changelog and README. by @holtrop-wolfssl (PR 9953)
* Updated the Rust wrapper's build script to support cross-compiling and bare-metal targets, including RISC-V architectures. by @holtrop-wolfssl (PR 10031)

## Build System and Portability
* Removed default declaration of WC_ALLOC_DO_ON_FAILURE. by @julek-wolfssl (PR 9905)
* Refactored wc_Hash* so that known wc_HashType values are unconditionally defined in enum wc_HashType, and always either succeed if used properly, or return HASH_TYPE_E if gated out or used improperly; added detailed error code tracing. by @douzzer (PR 9937)
* Removed the forced enabling of MD5 when building with --enable-jni so that MD5 can be explicitly disabled in FIPS builds. by @mattia-moffa (PR 10011)
* Changed the example server/client to not modify macro defines that come from how the wolfSSL library is configured when built. by @JacobBarthelmeh (PR 10037)
* Added __extension__ to __GNUC__&&!__STRICT_ANSI__ variant of wc_debug_trace_error_codes_enabled() in wolfssl/wolfcrypt/error-crypt.h, to inhibit false positive "error: ISO C forbids braced-groups within expressions" with -pedantic. by @douzzer (PR 10041)
* Fixed IAR compiler warnings about undefined volatile access order by reading volatile values into local copies before use in expressions. by @embhorn (PR 10045)
* Automatically enables WOLFSSL_SP_4096 when WOLFSSL_HAVE_SP_DH is defined under the --enable-usersettings configuration to fix a missing dependency for C# user settings builds. by @kojo1 (PR 10054)
* Added volatile casting to a port header definition to address a correctness issue. by @anhu (PR 10062)
* Extended the WC_MAYBE_UNUSED macro definition to cover GCC versions greater than 3 to fix a build error in GCC 3.4.0. by @embhorn (PR 10101)
* Fixed a compile error when building with --enable-crl and --disable-ecc by adding the appropriate preprocessor guards around SetBitString in asn.c. by @padelsbach (PR 10118)
* Fixed -Wcast-qual hygiene in wolfCrypt. by @douzzer (PR 10120)

## Bug Fixes
* Fixed stack memory tracking for the wolfCrypt benchmark. by @Frauschi (PR 9983)
* Fixed a bug in FillSigner where pubKeyStored and subjectCNStored flags were not cleared after transferring pointers from a DecodedCert to a signer, preventing stale NULL pointers from being copied on subsequent calls. by @embhorn (PR 10033)
* Fixed a heap overflow in ssl_DecodePacketInternal caused by silent truncation when summing 64-bit iov_len values into a 32-bit integer, which resulted in an undersized buffer allocation followed by an out-of-bounds copy. by @embhorn (PR 10017)
* Added a bounds check in GetSafeContent to prevent an unsigned integer underflow in the content size calculation when the OID parsed by GetObjectId exceeds the declared ContentInfo SEQUENCE length. by @embhorn (PR 10018)
* Fixed a potential double free issue in non-blocking async handling within ASN parsing. by @dgarske (PR 10022)
* Fixed bounds checking and buffer size calculation in DecodeObjectId to correctly validate two output slots before writing and pass the proper element count instead of byte count when handling unknown ASN.1 extensions. by @embhorn (PR 10025)
* Fixed stack buffer overflow in RSA exponent print via wolfSSL_EVP_PKEY_print_public in evp.c. Printing an RSA public key with a large exponent can overflow a stack buffer in the EVP printing routine. Thanks to Sunwoo Lee, Woohyun Choi, and Seunghyun Yoon (Korea Institute of Energy Technology, KENTECH) for the bug report. (PR 10088)
* Fixed sanity check on hashLen provided to wc_dilithium_verify_ctx_hash. Thanks to Sunwoo Lee, Woohyun Choi, and Seunghyun Yoon (Korea Institute of Energy Technology, KENTECH) for the bug report. (PR 10131)
* Disallowed wildcard partial domains when using MatchDomainName. Thanks to Oleh Konko (@1seal) for the report. (PR 9991)
* Fixed a buffer underflow that occurred when a zero-length size was passed to the devcrypto AES-CBC implementation. by @JeremiahM37 (PR 10005)
* Routed BIO_ctrl_pending, BIO_reset, and BIO_get_mem_data through the custom method's ctrlCb when set, enabling fully custom BIO types to handle these operations. by @julek-wolfssl (PR 10004)
* Fixed multiple issues in the SP integer implementation including negative number handling, edge cases when a->used is zero, missing bounds checks, and redundant code, while also re-implementing wc_PKCS12_PBKDF() without MP and adding 128-bit integer types for cleaner PKCS#12 support. by @SparkiDev (PR 10020)
* Fixed functional bugs in x86_64 AES-XTS register clobbering and ARM32 multiply/accumulate source registers, along with assembly label typos, instruction mnemonic corrections, and comment fixes across AES, ChaCha, SHA-3, SHA-512, ML-KEM, and Curve25519 assembly for x86_64, ARM32, and ARM64 targets. by @SparkiDev (PR 10023)
* Fixed a bug in the SP non-blocking ECC mont_inv_order function where the last bit was not being processed during modular inverse computation. by @SparkiDev (PR 10044)
* Added bounds check to prevent potential out-of-bounds access when parsing end-of-content octets in PKCS7 streaming indefinite-length encoding. by @anhu (PR 10039)
* Refactored the "Increment B by 1" loop in wc_PKCS12_PBKDF_ex() to avoid bugprone-inc-dec-in-conditions. by @douzzer (PR 10059)
* Fixed OpenSSL compatibility layer ASN1_INTEGER and ASN1_STRING to be compatible structs. by @julek-wolfssl (PR 10089)
* Fixed potential data truncation in wc_XChaCha20Poly1305_crypt_oneshot() by replacing long int casts with size_t to correctly handle 64-bit sizes on platforms where long int is 32-bit. by @rlm2002 (PR 10091)
* Fixed error handling in the Linux kernel AES AEAD glue code so that scatterwalk_map failures correctly propagate an error code instead of returning success with uninitialized data. by @sameehj (PR 9996)
* Fixed DTLS Fragment Reassembly to not read uninitialized heap contents. Thanks to Sunwoo Lee, Woohyun Choi, and Seunghyun Yoon (Korea Institute of Energy Technology, KENTECH) for the report. (PR 10090)
* Fixed DTLS 1.3 word16 truncation on handshake send size. A handshake message exceeding 65535 bytes causes silent integer truncation when the size is stored in a word16, leading to malformed or truncated handshake transmissions. Thanks to Sunwoo Lee, Woohyun Choi, and Seunghyun Yoon (Korea Institute of Energy Technology, KENTECH) for the report. (PR 10103)
* Fixed invalid-pointer-pair memory errors reported by clang sanitizer with detect_invalid_pointer_pairs=2 in ASAN_OPTIONS. by @douzzer (PR 10095)
* Hardened default builds by enabling ECC curve validation unconditionally, removing the previous dependency on USE_ECC_B_PARAM. Users on older versions can also harden their builds by enabling WOLFSSL_VALIDATE_ECC_IMPORT. by @Frauschi (PR 10133)

## Documentation and Maintenance
* Added inline Doxygen documentation for previously undocumented macros across TLS, cryptography, and ASN source files, and corrected spelling errors throughout the codebase. by @dgarske (PR 9992)
* Fixed typos in documentation for SSL API function argument descriptions. by @dgarske (PR 10021)
* Updated documentation to reflect support for both FIPS 140-2 and FIPS 140-3. by @anhu (PR 10061)


# wolfSSL Release 5.9.0 (Mar. 18, 2026)

Release 5.9.0 has been developed according to wolfSSL's development and QA
process (see link below) and successfully passed the quality criteria.
https://www.wolfssl.com/about/wolfssl-software-development-process-quality-assurance

NOTE: * --enable-heapmath is deprecated
      * MD5 is now disabled by default

PR stands for Pull Request, and PR <NUMBER> references a GitHub pull request number where the code change was added.

## Vulnerabilities

* [High] CVE-2026-3548
Two buffer overflow vulnerabilities existed in the wolfSSL CRL parser when parsing CRL numbers: a heap-based buffer overflow could occur when improperly storing the CRL number as a hexadecimal string, and a stack-based overflow for sufficiently sized CRL numbers. With appropriately crafted CRLs, either of these out of bound writes could be triggered. Note this only affects builds that specifically enable CRL support, and the user would need to load a CRL from an untrusted source. Found with internal wolfSSL testing. Fixed in PR 9628 and PR 9873.

* [High] CVE-2026-3549
Heap Overflow in TLS 1.3 ECH parsing. An integer underflow existed in ECH extension parsing logic when calculating a buffer length, which resulted in writing beyond the bounds of an allocated buffer. Note that in wolfSSL, ECH is off by default, and the ECH standard is still evolving. Found with internal wolfSSL testing, thanks to Oleh Konko for testing. Fixed in PR 9817.

* [High] CVE-2026-3547
Out-of-bounds read in ALPN parsing due to incomplete validation. wolfSSL 5.8.4 and earlier contained an out-of-bounds read in ALPN handling when built with ALPN enabled (HAVE_ALPN / --enable-alpn). A crafted ALPN protocol list could trigger an out-of-bounds read, leading to a potential process crash (denial of service). Note that ALPN is disabled by default, but is enabled for these 3rd party compatibility features: enable-apachehttpd, enable-bind, enable-curl, enable-haproxy, enable-hitch, enable-lighty, enable-jni, enable-nginx, enable-quic. Users of these features are recommended to update to 5.9.0. Thanks to Oleh Konko for the report. Fixed in PR 9860.

* [Med] CVE-2026-2646
A heap-buffer-overflow vulnerability exists in wolfSSL's wolfSSL_d2i_SSL_SESSION() function. When deserializing session data with SESSION_CERTS enabled, certificate and session id lengths are read from an untrusted input without bounds validation, allowing an attacker to overflow fixed-size buffers and corrupt heap memory. A maliciously crafted session would need to be loaded from an external source to trigger this vulnerability. Internal sessions were not vulnerable. Thanks to Jonathan Bar Or, and Haruto Kimura (Stella) for the report. Fixed in PR 9748 and PR 9949.

* [Med] CVE-2026-3849
Stack Buffer Overflow in wc_HpkeLabeledExtract via oversized ECH config. A vulnerability exists in wolfSSL 5.8.4 and earlier ECH (Encrypted Client Hello) support, where a maliciously crafted ECH config could cause a stack buffer overflow on the client side, leading to client program crash, with a potential for remote execution. This could be exploited by a malicious TLS server supporting ECH. Note that ECH is off by default, and is only enabled with enable-ech. Thanks to Haruto Kimura (Stella) for the report. Fixed in PR 9737.

* [Low] CVE-2026-0819
wolfSSL PKCS7 SignedData encoding OOB write (signed attributes). A vulnerability existed in the API wc_PKCS7_EncodeSignedData, and wc_PKCS7_EncodeSignedData_ex, where when encoding signed data with custom attributes, wolfSSL could write past a fixed size array resulting in a stack out of bounds write. This vulnerability only occurred when trying to create a signed PKCS7 encoding with more than 7 signed attributes, and did not affect PKCS7 parsing in general. Thanks to Maor Caplan for the report. Fixed in PR 9630.

* [Low] CVE-2026-1005
Integer underflow in wolfSSL packet sniffer. wolfSSL 5.8.4 and earlier allows an attacker to cause a buffer overflow in the AEAD decryption path by injecting a TLS record shorter than the explicit IV plus authentication tag into traffic inspected by ssl_DecodePacket. The underflow wraps a 16-bit length to a large value that is passed to AEAD decryption routines, causing a heap buffer overflow and a potential crash. An unauthenticated attacker can trigger this remotely via malformed TLS Application Data records. The sniffer feature is disabled by default and this only affects builds with --enable-sniffer and AEAD support. Thanks to Prasanth Sundararajan for the report. Fixed in PR 9571.

* [Low] CVE-2026-2645
In wolfSSL 5.8.2 and earlier, a logic flaw existed in the TLS 1.2 server state machine implementation. The server could incorrectly accept the CertificateVerify message before the ClientKeyExchange message had been received. This issue affects wolfSSL before 5.8.4 (wolfSSL 5.8.2 and earlier is vulnerable, 5.8.4 is not vulnerable). In 5.8.4 wolfSSL would detect the issue later in the handshake. 5.9.0 was further hardened to catch the issue earlier in the handshake. Thanks to Kai Tian for the report. Fixed in PR 9694.

* [Low] CVE-2026-3230
In versions of wolfSSL 5.8.4 and earlier the client does not catch if the required key_share extension is missing from a ServerHello sent after a crafted HelloRetryRequest. In the missing key_share extension case the client still goes through the process of authenticating the server correctly, and would then continue on to establish a connection with a predictable key being derived. Since the authentication of the server is still established, this only is an issue if the server can unknowingly be forced to send the malformed HelloRetryRequest followed by the ServerHello that omits the key_share extension. Thanks to Jaehun Lee for the report. Fixed in PR 9754.

* [Low] CVE-2026-3229. Integer Overflow in Certificate Chain Allocation. An integer overflow vulnerability existed in the static function wolfssl_add_to_chain, that caused heap corruption when certificate data was written out of bounds of an insufficiently sized certificate buffer. wolfssl_add_to_chain is called by these API: wolfSSL_CTX_add_extra_chain_cert, wolfSSL_CTX_add1_chain_cert, wolfSSL_add0_chain_cert. These API are enabled for 3rd party compatibility features: enable-opensslall, enable-opensslextra, enable-lighty, enable-stunnel, enable-nginx, enable-haproxy. This issue is not remotely exploitable, and would require that the application context loading certificates is compromised. Thanks to Pelioro and Kunyuk for responsibly reporting this issue. Fixed in PR 9827.

* [Low] CVE-2026-3579
wolfSSL 5.8.4 and earlier on RISC-V RV32I architectures lacks a constant-time software implementation for 64-bit multiplication. The compiler-inserted __muldi3 subroutine executes in variable time based on operand values. This affects multiple SP math functions (sp_256_mul_9, sp_256_sqr_9, etc.), leading to a timing side-channel that may expose sensitive cryptographic data. Thanks to Wind Wong for the report. Fixed in PR 9855.

* [Low] CVE-2026-3580. Compiler-induced timing leak in sp_256_get_entry_256_9 on RISC-V. In wolfSSL 5.8.4 and earlier, constant-time masking logic in sp_256_get_entry_256_9 is optimized into conditional branches (bnez) by GCC when targeting RISC-V RV32I with -O3. This transformation breaks the side-channel resistance of ECC scalar multiplication, potentially allowing a local attacker to recover secret keys via timing analysis. Thanks to Wind Wong for the report. Also fixed in PR 9855.

* [Low] CVE-2026-3503
A protection mechanism failure in wolfCrypt post-quantum implementations (ML-KEM and ML-DSA) in wolfSSL on ARM Cortex-M microcontrollers allows a physical attacker to compromise key material and/or cryptographic outcomes via induced transient faults that corrupt or redirect seed/pointer values during Keccak-based expansion. This issue affects wolfSSL (wolfCrypt): commit hash d86575c766e6e67ef93545fa69c04d6eb49400c6. Thanks to Hariprasad Kelassery Valsaraj of Temasek Laboratories for the report. Fixed in PR 9734.

* [Low] CVE-2026-4159
1-byte OOB heap read in wc_PKCS7_DecodeEnvelopedData via zero-length encrypted content. A vulnerability existed in wolfSSL 5.8.4 and earlier, where a 1-byte out-of-bounds heap read in wc_PKCS7_DecodeEnvelopedData could be triggered by a crafted CMS EnvelopedData message with zero-length encrypted content. Note that PKCS7 support is disabled by default. Thanks to Haruto Kimura (Stella). Fixed in PR 9945.

* [Low] CVE-2026-4395
A heap buffer out of bounds write case existed in wolfSSL version 5.8.4 and earlier when importing an ECC key while built with KCAPI support. The fix implemented added a check on the raw pubkey length in wc_ecc_import_x963 before copying it to an internal struct. KCAPI support is turned off by default and only enabled with builds using --enable-kcapi. Thanks to Haruto Kimura (Stella) for the report. Fixed in PR 9988.

## New features
* FIPS 205, SLH-DSA implementation by @SparkiDev (PR 9838).
* Added OCSP responder API and support by @julek-wolfssl (PR 9761).
* Add AES CryptoCB key import support by @sameehj (PR 9658).
* Add the RNG bank facility to wolfCrypt, wc_rng_new_bankref() to avoid expensive seeding operations at runtime by @douzzer (PR 9616).

## Ports, Hardware Integration, and ASM enhancements
* Add Renesas SK-S7G2 support by @miyazakh (PR 9561).
* Support for STM32 HMAC hardware by @dgarske (PR 9745).
* Add STM32G0 hardware crypto support by @danielinux (PR 9707).
* Misc STM32 fixes and testing improvements by @dgarske, @LinuxJedi (PRs 9446, 9563).
* Various Thumb2 AES/SP ASM enhancements and fixes by @SparkiDev (PRs 9464, 9491, 9547, 9615, 9767)
* Add Zephyr 4.1+ build compatibility for wolfssl_tls_sock sample by @night1rider (PR 9765)

## Rust wrapper
* Added FIPS support by @holtrop (PR 9739).
* Added modules for dilithium (PR 9819), chacha20-poly1305 (PR 9599), curve25519 (PR 9594), blake2 (PR 9586), and LMS (PR 9910), ml-kem (PR 9833) by @holtrop.
* Miscellaneous fixes and enhancements for RSA, ECC, HASHDRBG, HMAC-BLAKE2, and XChaCha20-Poly1305 by @holtrop (PRs 9453, 9499, 9500, 9624, 9687).

## Post-Quantum Cryptography (PQC)
* General improvements for WOLFSSL_NO_MALLOC PQC support by @douzzer (PR 9674).
* Various ML-DSA bug fixes by @SparkiDev  (PRs 9575, 9696).
* Fixed a bug with ML-DSA verification with WOLFSSL_DILITHIUM_SMALL, by @SparkiDev (PR 9760). Reported by Sunwoo Lee and Seunghyun Yoon of Korea Institute of Energy Technology (KENTECH).
* ML-KEM bug fixes and improvements by @lealem47, @SparkiDev (PRs 9470, 9621, 9822).
* Collection of ML-KEM fixes including DTLS 1.3 cookie and ClientHello fragment handling, static memory handling, a memory leak in TLS server PQC handling with ECH, and expanded hybrid/individual ML-KEM level test coverage. @Frauschi (PR 9968)

## TLS/DTLS
* Add support for TLS 1.3 Brainpool curves by @Frauschi (PR 9701).
* DTLS retransmission enhancement by @julek-wolfssl (PR 9623).
* Fix DTLS header size calculation by @rizlik (PR 9513).
* Fix (D)TLS fragmentation size checks by @julek-wolfssl (PR 9592).
* Extend AIA interface by @padelsbach (PR 9728).
* Various TLS 1.3 and extension fixes by @SparkiDev, @AlexLanzano, @embhorn (PRs 9528, 9538, 9466, 9662, 9824, 9934). Thanks to Muhammad Arya Arjuna (pelioro) for the report.
* Improve TLS message order checks by @SparkiDev (PRs 9694, 9718).
* TLS ECH improvements by @sebastian-carpenter (PR 9737).
* Harden compare of mac with TLS 1.3 finished by @JacobBarthelmeh (PR 9864).

## PKCS
* Add PKCS7 ECC raw sign callback support by @jackctj117 (PR 9656).
* Add RSA-PSS support for SignedData by @sameehj (PR 9742).
* Support for ML-DSA via PKCS#11 by @Frauschi (PRs 9726, 9836).
* Fix PKCS11 object leak in Pkcs11ECDH by @mattia-moffa (PR 9780).
* Fix PKCS#7 SignedData parsing for non-OCTET_STRING content types by @cconlon (PR 9559).
* Add RSA-PSS certificate support for PKCS7 EnvelopedData KTRI by @sameehj (PR 9854).

## Kernel
* Various linuxkm fixes and enhancements for Tegra kernels by @sameehj, @douzzer (PRs 9478, 9540, 9512).
* freebsdkm: FIPS support (PR 9590), and x86 crypto acceleration support by @philljj (PR 9714).
* Support offline FIPS hash calculation in linuxkm by @douzzer (PR 9800).

## Testing improvements
* Increase test coverage for PQC and CMake by @Frauschi (PR 9637).
* API testing: split out and better organized test cases by @SparkiDev (PR 9641).
* Added test for session deserialization input validation by @gasbytes (PR 9759).
* Added TLS Anvil workflow by @embhorn (PR 9804).
* Added rng-tools 6.17 testing by @julek-wolfssl (PR 9810).
* Added openldap 2.6.9 testing by @julek-wolfssl (PR 9805).
* Add bind 9.20.11 to the test matrix by @julek-wolfssl (PR 9806).
* Misc testing fixes by @miyazakh, @SparkiDev, @julek-wolfssl, @padelsbach, @rlm2002 (PRs 9584, 9670, 9688, 9710, 9716, 9755).
* Implement a stateful port tracking mechanism for test port assignment that eliminates collisions  during high-concurrency test loops in CI by @kaleb-himes (PR 9850).

## Bug Fixes
* Fix for buffer overflow write in the wolfSSL CAAM (Cryptographic Acceleration and Assurance Module) driver for Integrity OS on i.MX6. Thanks to Luigino Camastra for the report.
* API Documentation: various fixes and improvements: @LinuxJedi, @tamasan238,  @kareem-wolfssl, @dgarske (PRs 9458, 9552, 9570, 9585).
* Fix potential memory under-read in TLS ticket processing function.  Thanks to Arjuna Arya for the report.
* Fix IP address check in wolfSSL_X509_check_host() by @rlm2002 (PR 9502).
* Check if ctx and ssl are null when checking public key in certificate by @rlm2002 (PR 9506).
* Fix test when ECH and harden are enabled by @embhorn (PR 9510).
* Fix wc_CmacFree() to use correct heap pointer from internal Aes structure by @night1rider (PR 9527).
* Various Coverity analyzer fixes by @rlm2002 (PRs 9437, 9534, 9619, 9646, 9812, 9842, 9887, 9933).
* Fix dereference before Null check by @rlm2002 (PR 9591).
* Fix memory leak in case of handshake error by @Frauschi (PR 9609).
* Fix MatchBaseName by @rizlik (PR 9626).
* ChaCha20 Aarch64 ASM fix by @SparkiDev (PR 9627).
* Fix TLSX_Parse to correctly handle client and server cert type ext with TLS1.3 by @embhorn (PR 9657).
* Fix cert SW issues in Aes and rng by @tmael (PR 9681).
* Various fixes for NO_RNG builds by @dgarske (PRs 9689, 9698).
* Fixes for STSAFE-A120 ECDHE by @dgarske (PR 9703).
* Fix Crash when using Sha224 Callback with MAX32666 by @night1rider (PR 9712).
* Fix for RSA private key parsing (allowing public) and RSA keygen no malloc support by @dgarske (PR 9715).
* Fix null check in ECDSA encode by @padelsbach (PR 9771).
* Various static analyzer fixes by @LinuxJedi (PRs 9786, 9788, 9795, 9801, 9817).
* Fix switch case handling in TLSX_IsGroupSupported function by @Pushyanth-Infineon (PR 9777).
* Fixes to big-endian bugs found in Curve448 and Blake2S by @LinuxJedi (PR 9778).
* Fix cert chain size issue by @embhorn (PR 9827).
* Fix potential memory leak when copying into existing SHA contexts and zero init tmpSha by @night1rider (PR 9829).
* Add sanity checks in key export by @embhorn (PR 9823). Thanks to Muhammad Arya Arjuna (pelioro) for the report.
* CRL enhancements for revoked entries by @padelsbach (PR 9839).
* Fix DRBG_internal alloc in wc_RNG_HealthTestLocal by @embhorn (PR 9847).
* Various CMake fixes and improvements by @Frauschi (PRs 9605, 9725).
* RISC-V 32 no mul SP C: implement multiplication by @SparkiDev (PR 9855).
* ASN: improve handling of ASN.1 parsing/encoding by @SparkiDev (PR 9872).
* Various fixes to CRL parsing by @miyazakh (PRs 9628, 9873).
* Harden hash comparison in TLS1.2 finished by @Frauschi (PR 9874).
* Various fixes to TLS sniffer by @mattia-moffa, @embhorn, @julek-wolfssl, @Frauschi (PRs 9571, 9643, 9867, 9901, 9924).
* Check ivLen in wolfSSL_EVP_CIPHER_CTX_set_iv_length by @philljj (PR 9943). Thanks to Haruto Kimura (Stella) for the report.
* Validate that the ticket length is at least ID_LEN before use in SetTicket, preventing an undersized buffer from being processed by @kareem-wolfssl (PR 9782).
* Enforce null compression in compression_methods list by @julek-wolfssl (PR 9913).
* Additional sanity check on number of groups in set groups function by @JacobBarthelmeh (PR 9861).
* Resolves issues with asynchronous and crypto callback handling, adding test coverage to prevent regressions by @dgarske (PR 9784).
* Fix checkPad to reject zero PKCS#7 padding value by @embhorn (PR 9878).
* Add sanity check on keysize found with ECC point import by @JacobBarthelmeh (PR 9989).
* Adds a range check to ensure session ticket lifetimes are within the bounds permitted by the TLS specification by @Frauschi (PR 9881).
* Fix potential overflows in hash used-size calculation for TI and SE050 implementations by @kareem-wolfssl (PR 9954).
* Correct a constant mismatch where the draft QUIC transport params branch was returning the wrong extension constant, causing incorrect version detection by @embhorn (PR 9868).
* Correct the key type detection logic in Falcon and the SPHINCS+ signature algorithm's else-if chain to properly identify all key variants by @anhu (PR 9979, 9980).
* XMSS: Fix index copy for signing by @SparkiDev (PR 9978).
* Fix pathlen not copied in ASN1_OBJECT_dup and not marked set in X509_add_ext by @cconlon (PR 9940).
* Ensure CheckHeaders length does not exceed packet size in sniffer by @kareem-wolfssl (PR 9947).
* SP fixes: 32-bit ARM assembly fixes modular exponentiation bug by @SparkiDev (PR 9964).
* Fix buffer-overflow in LMS leaf cache indexing by @anhu (PR 9919).


# wolfSSL Release 5.8.4 (Nov. 20, 2025)

Release 5.8.4 has been developed according to wolfSSL's development and QA
process (see link below) and successfully passed the quality criteria.
https://www.wolfssl.com/about/wolfssl-software-development-process-quality-assurance

NOTE: * --enable-heapmath is deprecated
            * MD5 is now disabled by default

PR stands for Pull Request, and PR <NUMBER> references a GitHub pull request number where the code change was added.

## Vulnerabilities
* [Low CVE-2025-12888] Vulnerability in X25519 constant-time cryptographic implementations due to timing side channels introduced by compiler optimizations and CPU architecture limitations, specifically with the Xtensa-based ESP32 chips. If targeting Xtensa it is recommended to use the low memory implementations of X25519, which is now turned on as the default for Xtensa. Thanks to Adrian Cinal for the report. Fixed in PR 9275.


* [Med. CVE-2025-11936] Potential DoS vulnerability due to a memory leak through multiple KeyShareEntry with the same group in malicious TLS 1.3 ClientHello messages. This affects users who are running wolfSSL on the server side with TLS 1.3. Thanks to Jaehun Lee and Kyungmin Bae, Pohang University of Science and Technology (POSTECH) for the report. Fixed in PR 9117.

* [Low CVE-2025-11935] PSK with PFS (Perfect Forward Secrecy) downgrades to PSK without PFS during TLS 1.3 handshake. If the client sends a ClientHello that has a key share extension and the server responds with a ServerHello that does not have a key share extension the connection would previously continue on without using PFS. Thanks to Jaehun Lee from Pohang University of Science and Technology (POSTECH) for the report. Fixed in PR 9112.

* [Low CVE-2025-11934] Signature Algorithm downgrade from ECDSA P521 to P256 during TLS 1.3 handshake. When a client sends ECDSA P521 as the supported signature algorithm the server previously could respond as ECDSA P256 being the accepted signature algorithm and the connection would continue with using ECDSA P256. Thanks to Jaehun Lee from Pohang University of Science and Technology (POSTECH) for the report. Fixed in PR 9113.


* [Low CVE-2025-11933] DoS Vulnerability in wolfSSL TLS 1.3 CKS extension parsing. Previously duplicate CKS extensions were not rejected leading to a potential memory leak when processing a ClientHello. Thanks to Jaehun Lee from Pohang University of Science and Technology (POSTECH) for the report. Fixed in PR 9132.


* [Low CVE-2025-11931] Integer Underflow Leads to Out-of-Bounds Access in XChaCha20-Poly1305 Decrypt. This issue is hit specifically with a call to the function wc_XChaCha20Poly1305_Decrypt() which is not used with TLS connections, only from direct calls from an application. Thanks to Luigino Camastra from Aisle Research for the report. Fixed in PR 9223.

* [Low CVE-2025-11932] Timing Side-Channel in PSK Binder Verification. The server previously verified the TLS 1.3 PSK binder using a non-constant time method which could potentially leak information about the PSK binder. Thanks to Luigino Camastra from Aisle Research for the report. Fixed in PR 9223.

* [Low CVE-2025-12889] With TLS 1.2 connections a client can use any digest, specifically a weaker digest, rather than those in the CertificateRequest. Thanks to Jaehun Lee from Pohang University of Science and Technology (POSTECH) for the report. Fixed in PR 9395

* [Low CVE-2025-13912] When using the Clang compiler, various optimization levels or flags could result in non-constant-time compiled code. Assembly implementations of the functions in wolfSSL were not affected. The report was done specifically with Clang version 18 but there was shown to be similarities in timing variations when using the optimization levels with Clang 14 and Clang 20.

On the following architectures, the expected constant-time functions were found to have potential timing variations when specific compiler flags or optimization levels were used.

AArch64: Using O3, Ofast, or --enable-nontrivial-unswitch with O1/O2 flags leads to possible timing variations with the software implementations of sp_read_radix, sp_div_2_mod_ct, and sp_addmod_ct. Using O3, O2, Ofast, Os, or Oz with --unroll-force-peel-count=50 leads to possible timing variations with wc_AesGcmDecrypt.

RISC-V: TLS HMAC update/final operations, RSA unpad operations, and DH key pair generation with O1, O2, O3, Ofast, Oz, or Os. wc_AesGcmDecrypt and wc_Chacha_Process with O1, O2, O3, Os, or Ofast. Also SP software operations sp_div_2_mod_ct and sp_addmod_ct using O3 or Ofast.


X86_64: TLS HMAC update/final operations and TimingVerifyPad used with verifying the TLS MAC with --fast-isel or --x86-cmov-converter-force-all compile flags. RSA unpad operations, ECC mulmod, and wc_Chacha_Process with the --x86-cmov-converter-force-all flag. DH key agreement, sp_div_2_mod_ct and sp_addmod_ct with O1, O2, O3, Os, or Ofast. wc_AesGcmDecrypt with the compiler flags O2, O3, Os, Ofast, Oz --x86-cmov-converter-force-all | --unroll-force-peel-count=50, or O1 --x86-cmov-converter-force-all.

Thanks to Jing Liu, Zhiyuan Zhang, LUCÍA MARTÍNEZ GAVIER, Gilles Barthe, Marcel Böhme from Max Planck Institute for Security and Privacy (MPI-SP) for the report. Fixed in PR 9148.

## New Features
* New ML-KEM / ML-DSA APIs and seed/import PKCS8 support; added _new/_delete APIs for ML-KEM/ML-DSA. (PR 9039, 9000, 9049)
* Initial wolfCrypt FreeBSD kernel module support (PR 9392)
* Expanded PKCS7/CMS capabilities: decode SymmetricKeyPackage / OneSymmetricKey, add wc_PKCS7_GetEnvelopedDataKariRid, and allow PKCS7 builds with AES keywrap unset. (PR 9018, 9029, 9032)
* Add custom AES key wrap/unwrap callbacks and crypto callback copy/free operations. (PR 9002, 9309)
* Add support for certificate_authorities extension in ClientHello and certificate manager CA-type selection/unloading. (PR 9209, 9046)
* Large expansion of Rust wrapper modules: random, aes, rsa, ecc, dh, sha, hmac, cmac, ed25519/ed448, pbkdf2/PKCS#12, kdf/prf, SRTP KDFs, and conditional compilation options. (PR 9191, 9212, 9273, 9306, 9320, 9328, 9368, 9389, 9357, 9433)
* Rust: support optional heap and dev_id parameters and enable conditional compilation based on C build options. (PR 9407, 9433)
* STM32 fixes (benchmarking and platform fixes) and PSoC6 hardware acceleration additions. (PR 9228, 9256, 9185)
* STM32U5 added support for SAES and DHUK. (PR 9087)
* Add --enable-curl=tiny option for a smaller build when used with cURL. (PR 9174)

## Improvements / Optimizations
* Regression test fixes and expansion: TLS 1.3/1.2 tests, ARDUINO examples, libssh2 tests, hostap workflows, and nightly test improvements. (PR 9096, 9141, 9091, 9122, 9388)
* Improved test ordering and CI test stability (random tests run order changes, FIPS test fixes). (PR 9204, 9257)
* Docs and readme fixes, docstring updates, AsconAEAD comment placement, and example certificate renewals. (PR 9131, 9293, 9262, 9429)
* Updated GPL exception lists (GPLv2 and GPLv3 exception updates: add Fetchmail and OpenVPN). (PR 9398, 9413)
* Introduced WOLFSSL_DEBUG_CERTS and additional debug/logging refinements. (PR 8902, 9055)
* Expanded crypto-callback support (SHA family, HKDF, SHA-224, sha512_family digest selection) and improved crypto-only build cases. (PR 9070, 9252, 9271, 9100, 9194)
* AES & HW offload improvements including AES-CTR support in PKCS11 driver and AES ECB offload sizing fix. (PR 9277, 9364)
* ESP32: PSRAM allocator support and SHA HW fixes for ESP-IDF v6/v5. (PR 8987, 9225, 9264)
* Renesas FSP / RA examples updated and security-module TLS context improvements. (PR 9047, 9010, 9158, 9150)
* Broad configure/CMake/Autotools workflow improvements (Apple options tracking, Watcom pinning, Debian packaging, ESP-IDF pinning). (PR 9037, 9167, 9161, 9264)
* New assembly introspection / performance helpers for RISC-V and PPC32; benchmarking enhancements (cycle counts). (PR 9101, 9317)
* Update to SGX build for using assembly optimizations. (PR 8463, 9138)
* Testing with Fil-C compiler version to 0.674 (PR 9396)
* Refactors and compressing of small stack code (PR 9153)

## Bug Fixes
* Removed the test feature using popen when defining the macro WOLFSSL_USE_POPEN_HOST and not having HAVE_GETADDRINFO defined, along with having the macro HAVE_HTTP_CLIENT set. There was the potential for vulnerable behavior with the use of popen when the API wolfSSL_BIO_new_connect() was called with this specific build. This exact build configuration is only intended for testing with QEMU and is not enabled with any autoconf/cmake flags. Thanks to linraymond2006 for the report. (PR 9038)
* Fix for C# wrapper Ed25519 potential crash and heap overwrite with raw public key import when using the API Ed25519ImportPublic.This was a broken API with the C# wrapper that would crash on use. Thanks to Luigino Camastra from Aisle Research for the bug report. (PR 9291)
* Coverity, cppcheck, MISRA, clang-tidy, ZeroPath and other static-analysis driven fixes across the codebase. (PR 9006, 9078, 9068, 9265, 9324)
* TLS 1.2/DTLS improvements: client message order checks, DTLS cookie/exchange and replay protections, better DTLS early-data handling. (PR 9387, 9253, 9205, 9367)
* Improved X.509 & cert handling: allow larger pathLen in Basic Constraints, restore inner server name for ECH, retrying cert candidate chains. (PR 8890, 9234, 8692)
* Sniffer robustness: fix infinite recursion, better handling of OOO appData and partial overlaps, and improved retransmission detection. (PR 9051, 9106, 9140, 9094)
* Numerous linuxkm (kernel-mode) fixes, relocation/PIE normalization, and FIPS-related build tweaks across many iterations. (PR 9025, 9035, 9067, 9111, 9121)
* ML-KEM/Kyber and ML-DSA fixes for out-of-bounds and seed-import correctness; multiple ML-related safety fixes. (PR 9142, 9105, 9439)
* Avoid uninitialized-variable and GCC warnings; several fixes for undefined-shift/overflow issues. (PR 9020, 9372, 9195)
* Memory & leak fixes in X509 verification and various struct sizing fixes for WOLFSSL_NO_MALLOC usage. (PR 9258, 9036)
* Fixed RSA / signing / verify-only warnings allowing WOLFSSL_NO_CT_OPS when WOLFSSL_RSA_VERIFY_ONLY is used and API cleanups for using const. (PR 9031, 9263)


# wolfSSL Release 5.8.2 (July 17, 2025)

Release 5.8.2 has been developed according to wolfSSL's development and QA
process (see link below) and successfully passed the quality criteria.
https://www.wolfssl.com/about/wolfssl-software-development-process-quality-assurance

NOTE: * wolfSSL is now GPLv3 instead of GPLv2
            * --enable-heapmath is deprecated
            * MD5 is now disabled by default


PR stands for Pull Request, and PR (NUMBER) references a GitHub pull request number where the code change was added.

## Vulnerabilities

* [Low] There is the potential for a fault injection attack on ECC and Ed25519 verify operations. In versions of wolfSSL 5.7.6 and later the --enable-faultharden option is available to help mitigate against potential fault injection attacks. The mitigation added in wolfSSL version 5.7.6 is to help harden applications relying on the results of the verify operations, such as when used with wolfBoot. If doing ECC or Ed25519 verify operations on a device at risk for fault injection attacks then --enable-faultharden could be used to help mitigate it. Thanks to Kevin from Fraunhofer AISEC for the report.

Hardening option added in PR https://github.com/wolfSSL/wolfssl/pull/8289


* [High CVE-2025-7395] When using WOLFSSL_SYS_CA_CERTS and WOLFSSL_APPLE_NATIVE_CERT_VALIDATION on an Apple platform, the native trust store verification routine overrides errors produced elsewhere in the wolfSSL certificate verification process including failures due to hostname matching/SNI, OCSP, CRL, etc. This allows any trusted cert chain to override other errors detected during chain verification that should have resulted in termination of the TLS connection. If building wolfSSL on versions after 5.7.6 and before 5.8.2 with use of the system CA support and the apple native cert validation feature enabled on Apple devices (on by default for non-macOS Apple targets when using autotools or CMake) we recommend updating to the latest version of wolfSSL. Thanks to Thomas Leong from ExpressVPN for the report.

Fixed in PR https://github.com/wolfSSL/wolfssl/pull/8833


* [Med. CVE-2025-7394] In the OpenSSL compatibility layer implementation, the function RAND_poll() was not behaving as expected and leading to the potential for predictable values returned from RAND_bytes() after fork() is called. This can lead to weak or predictable random numbers generated in applications that are both using RAND_bytes() and doing fork() operations. This only affects applications explicitly calling RAND_bytes() after fork() and does not affect any internal TLS operations. Although RAND_bytes() documentation in OpenSSL calls out not being safe for use with fork() without first calling RAND_poll(), an additional code change was also made in wolfSSL to make RAND_bytes() behave similar to OpenSSL after a fork() call without calling RAND_poll(). Now the Hash-DRBG used gets reseeded after detecting running in a new process. If making use of RAND_bytes() and calling fork() we recommend updating to the latest version of wolfSSL. Thanks to Per Allansson from Appgate for the report.

Fixed in the following PR’s
https://github.com/wolfSSL/wolfssl/pull/8849
https://github.com/wolfSSL/wolfssl/pull/8867
https://github.com/wolfSSL/wolfssl/pull/8898



* [Low CVE-2025-7396] In wolfSSL 5.8.0 the option of hardening the C implementation of Curve25519 private key operations was added with the addition of blinding support (https://www.wolfssl.com/curve25519-blinding-support-added-in-wolfssl-5-8-0/). In wolfSSL release 5.8.2 that blinding support is turned on by default in applicable builds. The blinding configure option is only for the base C implementation of Curve25519. It is not needed, or available with; ARM assembly builds, Intel assembly builds, and the small Curve25519 feature. While the attack would be very difficult to execute in practice, enabling blinding provides an additional layer of protection for devices that may be more susceptible to physical access or side-channel observation. Thanks to Arnaud Varillon, Laurent Sauvage, and Allan Delautre from Telecom Paris for the report.

Blinding enabled by default in PR https://github.com/wolfSSL/wolfssl/pull/8736


## New Features
* Multiple sessions are now supported in the sniffer due to the removal of a cached check. (PR #8723)
* New API ssl_RemoveSession() has been implemented for sniffer cleanup operations. (PR #8768)
* The new ASN X509 API, `wc_GetSubjectPubKeyInfoDerFromCert`, has been introduced for retrieving public key information from certificates. (PR #8758)
* `wc_PKCS12_create()` has been enhanced to support PBE_AES(256|128)_CBC key and certificate encryptions. (PR #8782, PR #8822, PR #8859)
* `wc_PKCS7_DecodeEncryptedKeyPackage()` has been added for decoding encrypted key packages. (PR #8976)
* All AES, SHA, and HMAC functionality has been implemented within the Linux Kernel Module. (PR #8998)
* Additions to the compatibility layer have been introduced for X.509 extensions and RSA PSS. Adding the API i2d_PrivateKey_bio, BN_ucmp and X509v3_get_ext_by_NID. (PR #8897)
* Added support for STM32N6. (PR #8914)
* Implemented SHA-256 for PPC 32 assembly. (PR #8894)

## Improvements / Optimizations

### Linux Kernel Module (LinuxKM) Enhancements
* Registered DH and FFDHE for the Linux Kernel Module. (PR #8707)
* Implemented fixes for standard RNG in the Linux Kernel Module. (PR #8718)
* Added an ECDSA workaround for the Linux Kernel Module. (PR #8727)
* Added more PKCS1 pad SHA variants for RSA in the Linux Kernel Module. (PR #8730)
* Set default priority to 100000 for LKCAPI in the Linux Kernel Module. (PR #8740)
* Ensured ECDH never has FIPS enabled in the Linux Kernel Module. (PR #8751)
* Implemented further Linux Kernel Module and SP tweaks. (PR #8773)
* Added sig_alg support for Linux 6.13 RSA in the Linux Kernel Module. (PR #8796)
* Optimized wc_linuxkm_fpu_state_assoc. (PR #8828)
* Ensured DRBG is multithread-round-1 in the Linux Kernel Module. (PR #8840)
* Prevented toggling of fips_enabled in the Linux Kernel Module. (PR #8873)
* Refactored drbg_ctx clear in the Linux Kernel Module. (PR #8876)
* Set sig_alg max_size and digest_size callbacks for RSA in the Linux Kernel Module. (PR #8915)
* Added get_random_bytes for the Linux Kernel Module. (PR #8943)
* Implemented distro fix for the Linux Kernel Module. (PR #8994)
* Fixed page-flags-h in the Linux Kernel Module. (PR #9001)
* Added MODULE_LICENSE for the Linux Kernel Module. (PR #9005)

### Post-Quantum Cryptography (PQC) & Asymmetric Algorithms
* Kyber has been updated to the MLKEM ARM file for Zephyr (PR #8781)
* Backward compatibility has been implemented for ML_KEM IDs (PR #8827)
* ASN.1 is now ensured to be enabled when only building PQ algorithms (PR #8884)
* Building LMS with verify-only has been fixed (PR #8913)
* Parameters for LMS SHA-256_192 have been corrected (PR #8912)
* State can now be saved with the private key for LMS (PR #8836)
* Support for OpenSSL format has been added for ML-DSA/Dilithium (PR #8947)
* `dilithium_coeff_eta2[]` has been explicitly declared as signed (PR #8955)

### Build System & Portability
* Prepared for the inclusion of v5.8.0 in the Ada Alire index. (PR #8714)
* Introduced a new build option to allow reuse of the Windows crypt provider handle. (PR #8706)
* Introduced general fixes for various build configurations. (PR #8763)
* Made improvements for portability using older GCC 4.8.2. (PR #8753)
* Macro guards updated to allow tests to build with opensslall and no server. (PR #8776)
* Added a check for STDC_NO_ATOMICS macro before use of atomics. (PR #8885)
* Introduced CMakePresets.json and CMakeSettings.json. (PR #8905)
* Added an option to not use constant time code with min/max. (PR #8830)
* Implemented proper MacOS dispatch for conditional signal/wait. (PR #8928)
* Disabled MD5 by default for both general and CMake builds. (PR #8895, PR #8948)
* Improved to allow building OPENSSL_EXTRA without KEEP_PEER_CERT. (PR #8926)
* Added introspection for Intel and ARM assembly speedups. (PR #8954)
* Fixed cURL config to set HAVE_EX_DATA and HAVE_ALPN. (PR #8973)
* Moved FREESCALE forced algorithm HAVE_ECC to IDE/MQX/user_settings.h. (PR #8977)

### Testing & Debugging
* Fixed the exit status for testwolfcrypt. (PR #8762)
* Added WOLFSSL_DEBUG_PRINTF and WOLFSSL_DEBUG_CERTIFICATE_LOADS for improved debugging output. (PR #8769, PR #8770)
* Guarded some benchmark tests with NO_SW_BENCH. (PR #8760)
* Added an additional unit test for wolfcrypt PKCS12 file to improve code coverage. (PR #8831)
* Added an additional unit test for increased DH code coverage. (PR #8837)
* Adjusted for warnings with NO_TLS build and added GitHub actions test. (PR #8851)
* Added additional compatibility layer RAND tests. (PR #8852)
* Added an API unit test for checking domain name. (PR #8863)
* Added bind v9.18.33 testing. (PR #8888)
* Fixed issue with benchmark help options and descriptions not lining up. (PR #8957)

### Certificates & ASN.1
* Changed the algorithm for sum in ASN.1 OIDs. (PR #8655)
* Updated PKCS7 to use X509 STORE for internal verification. (PR #8748)
* Improved handling of temporary buffer size for X509 extension printing. (PR #8710)
* Marked IP address as WOLFSSL_V_ASN1_OCTET_STRING for ALT_NAMES_OID. (PR #8842)
* Fixed printing empty names in certificates. (PR #8880)
* Allowed CA:FALSE on wolftpm. (PR #8925)
* Fixed several inconsistent function prototype parameter names in wc/asn. (PR #8949)
* Accounted for custom extensions when creating a Cert from a WOLFSSL_X509. (PR #8960)

### TLS/DTLS & Handshake
* Checked group correctness outside of TLS 1.3 too for TLSX_UseSupportedCurve. (PR #8785)
* Dropped records that span datagrams in DTLS. (PR #8642)
* Implemented WC_NID_netscape_cert_type. (PR #8800)
* Refactored GetHandshakeHeader/GetHandShakeHeader into one function. (PR #8787)
* Correctly set the current peer in dtlsProcessPendingPeer. (PR #8848)
* Fixed set_groups for TLS. (PR #8824)
* Allowed trusted_ca_keys with TLSv1.3. (PR #8860)
* Moved Dtls13NewEpoch into DeriveTls13Keys. (PR #8858)
* Cleared tls1_3 on downgrade. (PR #8861)
* Always sent ACKs on detected retransmission for DTLS1.3. (PR #8882)
* Removed DTLS from echo examples. (PR #8889)
* Recalculated suites at SSL initialization. (PR #8757)
* No longer using BIO for ALPN. (PR #8969)
* Fixed wolfSSL_BIO_new_connect's handling of IPV6 addresses. (PR #8815)
* Memory Management & Optimizations
* Performed small stack refactors, improved stack size with mlkem and dilithium, and added additional tests. (PR #8779)
* Implemented FREE_MP_INT_SIZE in heap math. (PR #8881)
* Detected correct MAX_ENCODED_SIG_SZ based on max support in math lib. (PR #8931)
* Fixed improper access of sp_int_minimal using sp_int. (PR #8985)

### Cryptography & Hash Functions
* Implemented WC_SIPHASH_NO_ASM for not using assembly optimizations with siphash. (PR #8789, PR #8791)
* Added missing DH_MAX_SIZE define for FIPS and corrected wolfssl.rc FILETYPE to VFT_DLL. (PR #8794)
* Implemented WC_SHA3_NO_ASM for not using assembly with SHA3. (PR #8817)
* Improved Aarch64 XFENCE. (PR #8832)
* Omitted frame pointer for ARM32/Thumb2/RISC-V 64 assembly. (PR #8893)
* Fixed branch instruction in ARMv7a ASM. (PR #8933)
* Enabled EVP HMAC to work with WOLFSSL_HMAC_COPY_HASH. (PR #8944)
* Platform-Specific & Hardware Integration
* Added HAVE_HKDF for wolfssl_test and explicit support for ESP32P4. (PR #8742)
* Corrected Espressif default time setting. (PR #8829)
* Made wc_tsip_* APIs public. (PR #8717)
* Improved PlatformIO Certificate Bundle Support. (PR #8847)
* Fixed the TSIP TLS example program. (PR #8857)
* Added crypto callback functions for TROPIC01 secure element. (PR #8812)
* Added Renesas RX TSIP AES CTR support. (PR #8854)
* Fixed TSIP port using crypto callback. (PR #8937)

### General Improvements & Refactoring
* Attempted wolfssl_read_bio_file in read_bio even when XFSEEK is available. (PR #8703)
* Refactored GetHandshakeHeader/GetHandShakeHeader into one function. (PR #8787)
* Updated libspdm from 3.3.0 to 3.7.0. (PR #8906)
* Fixed missing dashes on the end of header and footer for Falcon PEM key. (PR #8904)
* Fixed minor code typos for macos signal and types.h max block size. (PR #8934)
* Make the API wolfSSL_X509_STORE_CTX_get_error accessible to more build configurations for ease of getting the "store" error code and depth with certificate failure callback implementations. (PR #8903)

## Bug Fixes
* Fixed issues to support _WIN32_WCE (VS 2008 with WinCE 6.0/7.0). (PR #8709)
* Fixed STM32 Hash with IRQ enabled. (PR #8705)
* Fixed raw hash when using crypto instructions on RISC-V 64-bit. (PR #8733)
* Fixed ECDH decode secret in the Linux Kernel Module. (PR #8729)
* Passed in the correct hash type to wolfSSL_RSA_verify_ex. (PR #8726)
* Fixed issues for Intel QuickAssist latest driver (4.28). (PR #8728)
* Speculative fix for CodeSonar overflow issue in ssl_certman.c. (PR #8715)
* Fixed Arduino progmem print and AVR WOLFSSL_USER_IO. (PR #8668)
* Correctly advanced the index in wc_HKDF_Expand_ex. (PR #8737)
* Fixed STM32 hash status check logic, including NO_AES_192 and NO_AES_256. (PR #8732)
* Added missing call to wolfSSL_RefFree in FreeCRL to prevent memory leaks. (PR #8750)
* Fixed sanity check on --group with unit test app and null sanity check with des decrypt. (PR #8711)
* Fixed Curve25519 and static ephemeral issue with blinding. (PR #8766)
* Fixed edge case issue with STM32 AES GCM auth padding. (PR #8745)
* Removed redefinition of MlKemKey and fixed build issue in benchmark. (PR #8755)
* Used proper heap hint when freeing CRL in error case. (PR #8713)
* Added support for no malloc with wc_CheckCertSigPubKey. (PR #8725)
* Fixed C# wrapper Release build. (PR #8802)
* Handled malformed CCS and CCS before CH in TLS1.3. (PR #8788)
* Fixed ML-DSA with WOLFSSL_DILITHIUM_NO_SIGN. (PR #8798)
* Fixed AesGcmCrypt_1 no-stream in the Linux Kernel Module. (PR #8814)
* Fixed return value usage for crypto_sig_sign in the Linux Kernel Module. (PR #8816)
* Fixed issue with CSharp and Windows CE with conversion of ASCII and Unicode. (PR #8799)
* Fixed Renesas SCE on RA6M4. (PR #8838)
* Fixed tests for different configs for ML-DSA. (PR #8865)
* Fixed bug in ParseCRL_Extensions around the size of a CRL number handled and CRL number OID. (PR #8587)
* Fixed uninitialized wc_FreeRng in prime_test. (PR #8886)
* Fixed ECC configuration issues with ECC verify only and no RNG. (PR #8901)
* Fixed issues with max size, openssl.test netcat, and clang-tidy. (PR #8909)
* Fixed for casting down and uninit issues in Dilithium/ML-DSA. (PR #8868)
* Fixed memory allocation failure testing and related unit test cases. (PR #8945, PR #8952)
* Fixed build issue with ML-DSA 44 only. (PR #8981)
* Fixed possible memory leak with X509 reference counter when using x509small. (PR #8982)


# wolfSSL Release 5.8.0 (Apr 24, 2025)

Release 5.8.0 has been developed according to wolfSSL's development and QA
process (see link below) and successfully passed the quality criteria.
https://www.wolfssl.com/about/wolfssl-software-development-process-quality-assurance

NOTE: * --enable-heapmath is deprecated

PR stands for Pull Request, and PR (NUMBER) references a GitHub pull request
 number where the code change was added.


## New Feature Additions
* Algorithm registration in the Linux kernel module for all supported FIPS AES,
 SHA, HMAC, ECDSA, ECDH, and RSA modes, key sizes, and digest sizes.
* Implemented various fixes to support building for Open Watcom including OS/2
 support and Open Watcom 1.9 compatibility (PR 8505, 8484)
* Added support for STM32H7S (tested on NUCLEO-H7S3L8) (PR 8488)
* Added support for STM32WBA (PR 8550)
* Added Extended Master Secret Generation Callback to the --enable-pkcallbacks
 build (PR 8303)
* Implement AES-CTS (configure flag --enable-aescts) in wolfCrypt (PR 8594)
* Added support for libimobiledevice commit 860ffb (PR 8373)
* Initial ASCON hash256 and AEAD128 support based on NIST SP 800-232 IPD
 (PR 8307)
* Added blinding option when using a Curve25519 private key by defining the
 macro WOLFSSL_CURVE25519_BLINDING (PR 8392)


## Linux Kernel Module
* Production-ready LKCAPI registration for cbc(aes), cfb(aes), gcm(aes),
 rfc4106 (gcm(aes)), ctr(aes), ofb(aes), and ecb(aes), ECDSA with P192, P256,
 P384, and P521 curves, ECDH with P192, P256, and P384 curves, and RSA with
 bare and PKCS1 padding
* Various fixes for LKCAPI wrapper for AES-CBC and AES-CFB (PR 8534, 8552)
* Adds support for the legacy one-shot AES-GCM back end (PR 8614, 8567) for
 compatibility with FIPS 140-3 Cert #4718.
* On kernel >=6.8, for CONFIG_FORTIFY_SOURCE, use 5-arg fortify_panic() override
 macro (PR 8654)
* Update calls to scatterwalk_map() and scatterwalk_unmap() for linux commit
 7450ebd29c (merged for Linux 6.15) (PR 8667)
* Inhibit LINUXKM_LKCAPI_REGISTER_ECDH on kernel <5.13 (PR 8673)
* Fix for uninitialized build error with fedora (PR 8569)
* Register ecdsa, ecdh, and rsa for use with linux kernel crypto (PR 8637, 8663,
 8646)
* Added force zero shared secret buffer, and clear of old key with ecdh
 (PR 8685)
* Update fips-check.sh script to pickup XTS streaming support on aarch64 and
 disable XTS-384 as an allowed use in FIPS mode (PR 8509, 8546)


## Enhancements and Optimizations

### Security & Cryptography
* Add constant-time implementation improvements for encoding functions. We thank
 Zhiyuan and Gilles for sharing a new constant-time analysis tool (CT-LLVM) and
 reporting several non-constant-time implementations. (PR 8396, 8617)
* Additional support for PKCS7 verify and decode with indefinite lengths
 (PR 8520, 834, 8645)
* Add more PQC hybrid key exchange algorithms such as support for combinations
 with X25519 and X448 enabling compatibility with the PQC key exchange support
 in Chromium browsers and Mozilla Firefox (PR 7821)
* Add short-circuit comparisons to DH key validation for RFC 7919 parameters
 (PR 8335)
* Improve FIPS compatibility with various build configurations for more resource
 constrained builds (PR 8370)
* Added option to disable ECC public key order checking (PR 8581)
* Allow critical alt and basic constraints extensions (PR 8542)
* New codepoint for MLDSA to help with interoperability (PR 8393)
* Add support for parsing trusted PEM certs having the header
 “BEGIN_TRUSTED_CERT” (PR 8400)
* Add support for parsing only of DoD certificate policy and Comodo Ltd PKI OIDs
 (PR 8599, 8686)
* Update ssl code in `src/*.c` to be consistent with wolfcrypt/src/asn.c
 handling of ML_DSA vs Dilithium and add dual alg. test (PR 8360, 8425)

### Build System, Configuration, CI & Protocols
* Internal refactor for include of config.h and when building with
 BUILDING_WOLFSSL macro. This refactor will give a warning of “deprecated
 function” when trying to improperly use an internal API of wolfSSL in an
 external application. (PR 8640, 8647, 8660, 8662, 8664)
* Add WOLFSSL_CLU option to CMakeLists.txt (PR 8548)
* Add CMake and Zephyr support for XMSS and LMS (PR 8494)
* Added GitHub CI for CMake builds (PR 8439)
* Added necessary macros when building wolfTPM Zephyr with wolfSSL (PR 8382)
* Add MSYS2 build continuous integration test (PR 8504)
* Update DevKitPro doc to list calico dependency with build commands (PR 8607)
* Conversion compiler warning fixes and additional continuous integration test
 added (PR 8538)
* Enable DTLS 1.3 by default in --enable-jni builds (PR 8481)
* Enabled TLS 1.3 middlebox compatibility by default for --enable-jni builds
 (PR 8526)

### Performance Improvements
* Performance improvements AES-GCM and HMAC (in/out hash copy) (PR 8429)
* LMS fixes and improvements adding API to get Key ID from raw private key,
 change to identifiers to match standard, and fix for when
 WOLFSSL_LMS_MAX_LEVELS is 1 (PR 8390, 8684, 8613, 8623)
* ML-KEM/Kyber improvements and fixes; no malloc builds, small memory usage,
 performance improvement, fix for big-endian (PR 8397, 8412, 8436, 8467, 8619,
 8622, 8588)
* Performance improvements for AES-GCM and when doing multiple HMAC operations
 (PR 8445)

### Assembly and Platform-Specific Enhancements
* Poly1305 arm assembly changes adding ARM32 NEON implementation and fix for
 Aarch64 use (PR 8344, 8561, 8671)
* Aarch64 assembly enhancement to use more CPU features, fix for FreeBSD/OpenBSD
 (PR 8325, 8348)
* Only perform ARM assembly CPUID checks if support was enabled at build time
 (PR 8566)
* Optimizations for ARM32 assembly instructions on platforms less than ARMv7
 (PR 8395)
* Improve MSVC feature detection for static assert macros (PR 8440)
* Improve Espressif make and CMake for ESP8266 and ESP32 series (PR 8402)
* Espressif updates for Kconfig, ESP32P4 and adding a sample user_settings.h
 (PR 8422, PR 8641)

### OpenSSL Compatibility Layer
* Modification to the push/pop to/from in OpenSSL compatibility layer. This is
 a pretty major API change in the OpenSSL compatibility stack functions.
 Previously the API would push/pop from the beginning of the list but now they
 operate on the tail of the list. This matters when using the sk_value with
 index values. (PR 8616)
* OpenSSL Compat Layer: OCSP response improvements (PR 8408, 8498)
* Expand the OpenSSL compatibility layer to include an implementation of
 BN_CTX_get (PR 8388)

### API Additions and Modifications
* Refactor Hpke to allow multiple uses of a context instead of just one shot
 mode (PR 6805)
* Add support for PSK client callback with Ada and use with Alire (thanks
 @mgrojo, PR 8332, 8606)
* Change wolfSSL_CTX_GenerateEchConfig to generate multiple configs and add
 functions wolfSSL_CTX_SetEchConfigs and wolfSSL_CTX_SetEchConfigsBase64 to
 rotate the server's echConfigs (PR 8556)
* Added the public API wc_PkcsPad to do PKCS padding (PR 8502)
* Add NULL_CIPHER_TYPE support to wolfSSL_EVP_CipherUpdate (PR 8518)
* Update Kyber APIs to ML-KEM APIs (PR 8536)
* Add option to disallow automatic use of "default" devId using the macro
 WC_NO_DEFAULT_DEVID (PR 8555)
* Detect unknown key format on ProcessBufferTryDecode() and handle RSA-PSSk
 format (PR 8630)

### Porting and Language Support
* Update Python port to support version 3.12.6 (PR 8345)
* New additions for MAXQ with wolfPKCS11 (PR 8343)
* Port to ntp 4.2.8p17 additions (PR 8324)
* Add version 0.9.14 to tested libvncserver builds (PR 8337)

### General Improvements and Cleanups
* Cleanups for STM32 AES GCM (PR 8584)
* Improvements to isascii() and the CMake key log option (PR 8596)
* Arduino documentation updates, comments and spelling corrections (PR 8381,
 8384, 8514)
* Expanding builds with WOLFSSL_NO_REALLOC for use with --enable-opensslall and
 --enable-all builds (PR 8369, 8371)


## Fixes
* Fix a use after free caused by an early free on error in the X509 store
 (PR 8449)
* Fix to account for existing PKCS8 header with
 wolfSSL_PEM_write_PKCS8PrivateKey (PR 8612)
* Fixed failing CMake build issue when standard threads support is not found in
 the system (PR 8485)
* Fix segmentation fault in SHA-512 implementation for AVX512 targets built with
 gcc -march=native -O2 (PR 8329)
* Fix Windows socket API compatibility warning with mingw32 build (PR 8424)
* Fix potential null pointer increments in cipher list parsing (PR 8420)
* Fix for possible stack buffer overflow read with wolfSSL_SMIME_write_PKCS7.
 Thanks to the team at Code Intelligence for the report. (PR 8466)
* Fix AES ECB implementation for Aarch64 ARM assembly (PR 8379)
* Fixed building with VS2008 and .NET 3.5 (PR 8621)
* Fixed possible error case memory leaks in CRL and EVP_Sign_Final (PR 8447)
* Fixed SSL_set_mtu compatibility function return code (PR 8330)
* Fixed Renesas RX TSIP (PR 8595)
* Fixed ECC non-blocking tests (PR 8533)
* Fixed CMake on MINGW and MSYS (PR 8377)
* Fixed Watcom compiler and added new CI test (PR 8391)
* Fixed STM32 PKA ECC 521-bit support (PR 8450)
* Fixed STM32 PKA with P521 and shared secret (PR 8601)
* Fixed crypto callback macro guards with `DEBUG_CRYPTOCB` (PR 8602)
* Fix outlen return for RSA private decrypt with WOLF_CRYPTO_CB_RSA_PAD
 (PR 8575)
* Additional sanity check on r and s lengths in DecodeECC_DSA_Sig_Bin (PR 8350)
* Fix compat. layer ASN1_TIME_diff to accept NULL output params (PR 8407)
* Fix CMake lean_tls build (PR 8460)
* Fix for QUIC callback failure (PR 8475)
* Fix missing alert types in AlertTypeToString for print out with debugging
 enabled (PR 8572)
* Fixes for MSVS build issues with PQC configure (PR 8568)
* Fix for SE050 port and minor improvements (PR 8431, 8437)
* Fix for missing rewind function in zephyr and add missing files for compiling
 with assembly optimizations (PR 8531, 8541)
* Fix for quic_record_append to return the correct code (PR 8340, 8358)
* Fixes for Bind 9.18.28 port (PR 8331)
* Fix to adhere more closely with RFC8446 Appendix D and set haveEMS when
 negotiating TLS 1.3 (PR 8487)
* Fix to properly check for signature_algorithms from the client in a TLS 1.3
 server (PR 8356)
* Fix for when BIO data is less than seq buffer size. Thanks to the team at Code
 Intelligence for the report (PR 8426)
* ARM32/Thumb2 fixes for WOLFSSL_NO_VAR_ASSIGN_REG and td4 variable declarations
 (PR 8590, 8635)
* Fix for Intel AVX1/SSE2 assembly to not use vzeroupper instructions unless ymm
 or zmm registers are used (PR 8479)
* Entropy MemUse fix for when block size less than update bits (PR 8675)


# wolfSSL Release 5.7.6 (Dec 31, 2024)

Release 5.7.6 has been developed according to wolfSSL's development and QA
process (see link below) and successfully passed the quality criteria.
https://www.wolfssl.com/about/wolfssl-software-development-process-quality-assurance

NOTE:
 * --enable-heapmath is deprecated.
 * In this release, the default cipher suite preference is updated to prioritize
 TLS_AES_256_GCM_SHA384 over TLS_AES_128_GCM_SHA256 when enabled.
 * This release adds a sanity check for including wolfssl/options.h or
 user_settings.h.


PR stands for Pull Request, and PR (NUMBER) references a GitHub pull request
 number where the code change was added.


## Vulnerabilities
* [Med] An OCSP (non stapling) issue was introduced in wolfSSL version 5.7.4
 when performing OCSP requests for intermediate certificates in a certificate
 chain. This affects only TLS 1.3 connections on the server side. It would not
 impact other TLS protocol versions or connections that are not using the
 traditional OCSP implementation. (Fix in pull request 8115)


## New Feature Additions
* Add support for RP2350 and improve RP2040 support, both with RNG optimizations
 (PR 8153)
* Add support for STM32MP135F, including STM32CubeIDE support and HAL support
 for SHA2/SHA3/AES/RNG/ECC optimizations. (PR 8223, 8231, 8241)
* Implement Renesas TSIP RSA Public Enc/Private support (PR 8122)
* Add support for Fedora/RedHat system-wide crypto-policies (PR 8205)
* Curve25519 generic keyparsing API added with  wc_Curve25519KeyToDer and
 wc_Curve25519KeyDecode (PR 8129)
* CRL improvements and update callback, added the functions
 wolfSSL_CertManagerGetCRLInfo and wolfSSL_CertManagerSetCRLUpdate_Cb (PR 8006)
* For DTLS, add server-side stateless and CID quality-of-life API. (PR 8224)


## Enhancements and Optimizations
* Add a CMake dependency check for pthreads when required. (PR 8162)
* Update OS_Seed declarations for legacy compilers and FIPS modules (boundary
 not affected). (PR 8170)
* Enable WOLFSSL_ALWAYS_KEEP_SNI by default when using --enable-jni. (PR 8283)
* Change the default cipher suite preference, prioritizing
 TLS_AES_256_GCM_SHA384 over TLS_AES_128_GCM_SHA256. (PR 7771)
* Add SRTP-KDF (FIPS module v6.0.0) to checkout script for release bundling
 (PR 8215)
* Make library build when no hardware crypto available for Aarch64 (PR 8293)
* Update assembly code to avoid `uint*_t` types for better compatibility with
 older C standards. (PR 8133)
* Add initial documentation for writing ASN template code to decode BER/DER.
 (PR 8120)
* Perform full reduction in sc_muladd for EdDSA with Curve448 (PR 8276)
* Allow SHA-3 hardware cryptography instructions to be explicitly not used in
 MacOS builds (PR 8282)
* Make Kyber and ML-KEM available individually and together. (PR 8143)
* Update configuration options to include Kyber/ML-KEM and fix defines used in
 wolfSSL_get_curve_name. (PR 8183)
* Make GetShortInt available with WOLFSSL_ASN_EXTRA (PR 8149)
* Improved test coverage and minor improvements of X509 (PR 8176)
* Add sanity checks for configuration methods, ensuring the inclusion of
 wolfssl/options.h or user_settings.h. (PR 8262)
* Enable support for building without TLS (NO_TLS). Provides reduced code size
 option for non-TLS users who want features like the certificate manager or
 compatibility layer. (PR 8273)
* Exposed get_verify functions with OPENSSL_EXTRA. (PR 8258)
* ML-DSA/Dilithium: obtain security level from DER when decoding (PR 8177)
* Implementation for using PKCS11 to retrieve certificate for SSL CTX (PR 8267)
* Add support for the RFC822 Mailbox attribute (PR 8280)
* Initialize variables and adjust types resolve warnings with Visual Studio in
 Windows builds. (PR 8181)
* Refactors and expansion of opensslcoexist build (PR 8132, 8216, 8230)
* Add DTLS 1.3 interoperability, libspdm and DTLS CID interoperability tests
 (PR 8261, 8255, 8245)
* Remove trailing error exit code in wolfSSL install setup script (PR 8189)
* Update Arduino files for wolfssl 5.7.4 (PR 8219)
* Improve Espressif SHA HW/SW mutex messages (PR 8225)
* Apply post-5.7.4 release updates for Espressif Managed Component examples
 (PR 8251)
* Expansion of c89 conformance (PR 8164)
* Added configure option for additional sanity checks with --enable-faultharden
 (PR 8289)
* Aarch64 ASM additions to check CPU features before hardware crypto instruction
 use (PR 8314)


## Fixes
* Fix a memory issue when using the compatibility layer with
 WOLFSSL_GENERAL_NAME and handling registered ID types. (PR 8155)
* Fix a build issue with signature fault hardening when using public key
 callbacks (HAVE_PK_CALLBACKS). (PR 8287)
* Fix for handling heap hint pointer properly when managing multiple WOLFSSL_CTX
 objects and free’ing one of them (PR 8180)
* Fix potential memory leak in error case with Aria. (PR 8268)
* Fix Set_Verify flag behaviour on Ada wrapper. (PR 8256)
* Fix a compilation error with the NO_WOLFSSL_DIR flag. (PR 8294)
* Resolve a corner case for Poly1305 assembly code on Aarch64. (PR 8275)
* Fix incorrect version setting in CSRs. (PR 8136)
* Correct debugging output for cryptodev. (PR 8202)
* Fix for benchmark application use with /dev/crypto GMAC auth error due to size
 of AAD (PR 8210)
* Add missing checks for the initialization of sp_int/mp_int with DSA to free
 memory properly in error cases. (PR 8209)
* Fix return value of wolfSSL_CTX_set_tlsext_use_srtp (8252)
* Check Root CA by Renesas TSIP before adding it to ca-table (PR 8101)
* Prevent adding a certificate to the CA cache for Renesas builds if it does not
 set CA:TRUE in basic constraints. (PR 8060)
* Fix attribute certificate holder entityName parsing. (PR 8166)
* Resolve build issues for configurations without any wolfSSL/openssl
 compatibility layer headers. (PR 8182)
* Fix for building SP RSA small and RSA public only (PR 8235)
* Fix for Renesas RX TSIP RSA Sign/Verify with wolfCrypt only (PR 8206)
* Fix to ensure all files have settings.h included (like wc_lms.c) and guards
 for building all `*.c` files (PR 8257 and PR 8140)
* Fix x86 target build issues in Visual Studio for non-Windows operating
 systems. (PR 8098)
* Fix wolfSSL_X509_STORE_get0_objects to handle no CA (PR 8226)
* Properly handle reference counting when adding to the X509 store. (PR 8233)
* Fix for various typos and improper size used with FreeRTOS_bind in the Renesas
 example. Thanks to Hongbo for the report on example issues. (PR 7537)
* Fix for potential heap use after free with wolfSSL_PEM_read_bio_PrivateKey.
 Thanks to Peter for the issue reported. (PR 8139)


# wolfSSL Release 5.7.4 (Oct 24, 2024)

Release 5.7.4 has been developed according to wolfSSL's development and QA
process (see link below) and successfully passed the quality criteria.
https://www.wolfssl.com/about/wolfssl-software-development-process-quality-assurance

NOTE: * --enable-heapmath is being deprecated and will be removed by end of 2024

PR stands for Pull Request, and PR (NUMBER) references a GitHub pull request
 number where the code change was added.


## Vulnerabilities
* [Low] When the OpenSSL compatibility layer is enabled, certificate
 verification behaved differently in wolfSSL than OpenSSL, in the
 X509_STORE_add_cert() and X509_STORE_load_locations() implementations.
 Previously, in cases where an application explicitly loaded an intermediate
 certificate, wolfSSL was verifying only up to that intermediate certificate,
 rather than verifying up to the root CA. This only affects use cases where the
 API is called directly, and does not affect TLS connections. Users that call
 the API X509_STORE_add_cert() or X509_STORE_load_locations() directly in their
 applications are recommended to update the version of wolfSSL used or to have
 additional sanity checks on certificates loaded into the X509_STORE when
 verifying a certificate. (https://github.com/wolfSSL/wolfssl/pull/8087)


## PQC TLS Experimental Build Fix
* When using TLS with post quantum algorithms enabled, the connection uses a
 smaller EC curve than agreed on. Users building with --enable-experimental and
 enabling PQC cipher suites with TLS connections are recommended to update the
 version of wolfSSL used. Thanks to Daniel Correa for the report.
 (https://github.com/wolfSSL/wolfssl/pull/8084)


## New Feature Additions
* RISC-V 64 new assembly optimizations added for SHA-256, SHA-512, ChaCha20,
 Poly1305, and SHA-3 (PR 7758,7833,7818,7873,7916)
* Implement support for Connection ID (CID) with DTLS 1.2 (PR 7995)
* Add support for (DevkitPro)libnds (PR 7990)
* Add port for Mosquitto OSP (Open Source Project) (PR 6460)
* Add port for init sssd (PR 7781)
* Add port for eXosip2 (PR 7648)
* Add support for STM32G4 (PR 7997)
* Add support for MAX32665 and MAX32666 TPU HW and ARM ASM Crypto Callback
 Support (PR 7777)
* Add support for building wolfSSL to be used in libspdm (PR 7869)
* Add port for use with Nucleus Plus 2.3 (PR 7732)
* Initial support for RFC5755 x509 attribute certificates (acerts). Enabled with
 --enable-acert (PR 7926)
* PKCS#11 RSA Padding offload allows tokens to perform CKM_RSA_PKCS
 (sign/encrypt), CKM_RSA_PKCS_PSS (sign), and CKM_RSA_PKCS_OAEP (encrypt).
 (PR 7750)
* Added “new” and “delete” style functions for heap/pool allocation and freeing
 of low level crypto structures (PR 3166 and 8089)


## Enhancements and Optimizations
* Increase default max alt. names from 128 to 1024 (PR 7762)
* Added new constant time DH agree function wc_DhAgree_ct (PR 7802)
* Expanded compatibility layer with the API EVP_PKEY_is_a (PR 7804)
* Add option to disable cryptocb test software test using
 --disable-cryptocb-sw-test (PR 7862)
* Add a call to certificate verify callback before checking certificate dates
 (PR 7895)
* Expanded algorithms supported with the wolfCrypt CSharp wrapper. Adding
 support for RNG, ECC(ECIES and ECDHE), RSA, ED25519/Curve25519, AES-GCM, and
 Hashing (PR 3166)
* Expand MMCAU support for use with DES ECB (PR 7960)
* Update AES SIV to handle multiple associated data inputs (PR 7911)
* Remove HAVE_NULL_CIPHER from --enable-openssh (PR 7811)
* Removed duplicate if(NULL) checks when calling XFREE (macro does) (PR 7839)
* Set RSA_MIN_SIZE default to 2048 bits (PR 7923)
* Added support for wolfSSL to be used as the default TLS in the zephyr kernel
 (PR 7731)
* Add enable provider build using --enable-wolfprovider with autotools (PR 7550)
* Renesas RX TSIP ECDSA support (PR 7685)
* Support DTLS1.3 downgrade when the server supports CID (PR 7841)
* Server-side checks OCSP even if it uses v2 multi (PR 7828)
* Add handling of absent hash params in PKCS7 bundle parsing and creation
 (PR 7845)
* Add the use of w64wrapper for Poly1305, enabling Poly1305 to be used in
 environments that do not have a word64 type (PR 7759)
* Update to the maxq10xx support (PR 7824)
* Add support for parsing over optional PKCS8 attributes (PR 7944)
* Add support for either side method with DTLS 1.3 (PR 8012)
* Added PKCS7 PEM support for parsing PEM data with BEGIN/END PKCS7 (PR 7704)
* Add CMake support for WOLFSSL_CUSTOM_CURVES (PR 7962)
* Add left-most wildcard matching support to X509_check_host() (PR 7966)
* Add option to set custom SKID with PKCS7 bundle creation (PR 7954)
* Building wolfSSL as a library with Ada and corrections to Alire manifest
 (PR 7303,7940)
* Renesas RX72N support updated (PR 7849)
* New option WOLFSSL_COPY_KEY added to always copy the key to the SSL object
 (PR 8005)
* Add the new option WOLFSSL_COPY_CERT to always copy the cert buffer for each
 SSL object (PR 7867)
* Add an option to use AES-CBC with HMAC for default session ticket enc/dec.
 Defaults to AES-128-CBC with HMAC-SHA256 (PR 7703)
* Memory usage improvements in wc_PRF, sha256 (for small code when many
 registers are available) and sp_int objects (PR 7901)
* Change in the configure script to work around ">>" with no command. In older
 /bin/sh it can be ambiguous, as used in OS’s such as FreeBSD 9.2 (PR 7876)
* Don't attempt to include system headers when not required (PR 7813)
* Certificates: DER encoding of ECC signature algorithm parameter is now
 allowed to be NULL with a define (PR 7903)
* SP x86_64 asm: check for AVX2 support for VMs (PR 7979)
* Update rx64n support on gr-rose (PR 7889)
* Update FSP version to v5.4.0 for RA6M4 (PR 7994)
* Update TSIP driver version to v1.21 for RX65N RSK (PR 7993)
* Add a new crypto callback for RSA with padding (PR 7907)
* Replaced the use of pqm4 with wolfSSL implementations of Kyber/MLDSA
 (PR 7924)
* Modernized memory fence support for C11 and clang (PR 7938)
* Add a CRL error override callback (PR 7986)
* Extend the X509 unknown extension callback for use with a user context
 (PR 7730)
* Additional debug error tracing added with TLS (PR 7917)
* Added runtime support for library call stack traces with
 –enable-debug-trace-errcodes=backtrace, using libbacktrace (PR 7846)
* Expanded C89 conformance (PR 8077)
* Expanded support for WOLFSSL_NO_MALLOC (PR 8065)
* Added support for cross-compilation of Linux kernel module (PR 7746)
* Updated Linux kernel module with support for kernel 6.11 and 6.12 (PR 7826)
* Introduce WOLFSSL_ASN_ALLOW_0_SERIAL to allow parsing of certificates with a
 serial number of 0 (PR 7893)
* Add conditional repository_owner to all wolfSSL GitHub workflows (PR 7871)

### Espressif / Arduino Updates
* Update wolfcrypt settings.h for Espressif ESP-IDF, template update (PR 7953)
* Update Espressif sha, util, mem, time helpers (PR 7955)
* Espressif _thread_local_start and _thread_local_end fix (PR 8030)
* Improve benchmark for Espressif devices (PR 8037)
* Introduce Espressif common CONFIG_WOLFSSL_EXAMPLE_NAME, Kconfig (PR 7866)
* Add wolfSSL esp-tls and Certificate Bundle Support for Espressif ESP-IDF
 (PR 7936)
* Update wolfssl Release for Arduino (PR 7775)

### Post Quantum Crypto Updates
* Dilithium: support fixed size arrays in dilithium_key (PR 7727)
* Dilithium: add option to use precalc with small sign (PR 7744)
* Allow Kyber to be built with FIPS (PR 7788)
* Allow Kyber asm to be used in the Linux kernel module (PR 7872)
* Dilithium, Kyber: Update to final specification (PR 7877)
* Dilithium: Support FIPS 204 Draft and Final Draft (PR 7909,8016)

### ARM Assembly Optimizations
* ARM32 assembly optimizations added for ChaCha20 and Poly1305 (PR 8020)
* Poly1305 assembly optimizations improvements for Aarch64 (PR 7859)
* Poly1305 assembly optimizations added for Thumb-2 (PR 7939)
* Adding ARM ASM build option to STM32CubePack (PR 7747)
* Add ARM64 to Visual Studio Project (PR 8010)
* Kyber assembly optimizations for ARM32 and Aarch64 (PR 8040,7998)
* Kyber assembly optimizations for ARMv7E-M/ARMv7-M (PR 7706)


## Fixes
* ECC key load: fixes for certificates with parameters that are not default for
 size (PR 7751)
* Fixes for building x86 in Visual Studio for non-windows OS (PR 7884)
* Fix for TLS v1.2 secret callback, incorrectly detecting bad master secret
 (PR 7812)
* Fixes for PowerPC assembly use with Darwin and SP math all (PR 7931)
* Fix for detecting older versions of Mac OS when trying to link with
 libdispatch (PR 7932)
* Fix for DTLS1.3 downgrade to DTLS1.2 when the server sends multiple handshake
 packets combined into a single transmission. (PR 7840)
* Fix for OCSP to save the request if it was stored in ssl->ctx->certOcspRequest
 (PR 7779)
* Fix to OCSP for searching for CA by key hash instead of ext. key id (PR 7934)
* Fix for staticmemory and singlethreaded build (PR 7737)
* Fix to not allow Shake128/256 with Xilinx AFALG (PR 7708)
* Fix to support PKCS11 without RSA key generation (PR 7738)
* Fix not calling the signing callback when using PK callbacks + TLS 1.3
 (PR 7761)
* Cortex-M/Thumb2 ASM fix label for IAR compiler (PR 7753)
* Fix with PKCS11 to iterate correctly over slotId (PR 7736)
* Stop stripping out the sequence header on the AltSigAlg extension (PR 7710)
* Fix ParseCRL_AuthKeyIdExt with ASN template to set extAuthKeyIdSet value
 (PR 7742)
* Use max key length for PSK encrypt buffer size (PR 7707)
* DTLS 1.3 fix for size check to include headers and CID fixes (PR 7912,7951)
* Fix STM32 Hash FIFO and add support for STM32U5A9xx (PR 7787)
* Fix CMake build error for curl builds (PR 8021)
* SP Maths: PowerPC ASM fix to use XOR instead of LI (PR 8038)
* SSL loading of keys/certs: testing and fixes (PR 7789)
* Misc. fixes for Dilithium and Kyber (PR 7721,7765,7803,8027,7904)
* Fixes for building wolfBoot sources for PQ LMS/XMSS (PR 7868)
* Fixes for building with Kyber enabled using CMake and zephyr port (PR 7773)
* Fix for edge cases with session resumption with TLS 1.2 (PR 8097)
* Fix issue with ARM ASM with AES CFB/OFB not initializing the "left" member
 (PR 8099)


# wolfSSL Release 5.7.2 (July 08, 2024)

Release 5.7.2 has been developed according to wolfSSL's development and QA
process (see link below) and successfully passed the quality criteria.
https://www.wolfssl.com/about/wolfssl-software-development-process-quality-assurance

NOTE: * --enable-heapmath is being deprecated and will be removed by end of 2024

## Vulnerabilities
* [Medium] CVE-2024-1544
Potential ECDSA nonce side channel attack in versions of wolfSSL before 5.6.6 with wc_ecc_sign_hash calls. Generating the ECDSA nonce k samples a random number r and then truncates this randomness with a modular reduction mod n where n is the order of the elliptic curve. Analyzing the division through a control-flow revealing side-channel reveals a bias in the most significant bits of k. Depending on the curve this is either a negligible bias or a significant bias large enough to reconstruct k with lattice reduction methods. Thanks to Luca Wilke, Florian Sieck and Thomas Eisenbarth (University of Lübeck) for reporting the vulnerability. Details will appear in the proceedings of CCS 24.
Fixed https://github.com/wolfSSL/wolfssl/pull/7020


* [Medium] CVE-2024-5288
A private key blinding operation, enabled by defining the macro WOLFSSL_BLIND_PRIVATE_KEY, was added to mitigate a potential row hammer attack on ECC operations. If performing ECC private key operations in an environment where a malicious user could gain fine control over the device and perform row hammer style attacks it is recommended to update the version of wolfSSL used and to build with WOLFSSL_BLIND_PRIVATE_KEY defined. Thanks to Kemal Derya, M. Caner Tol, Berk Sunar for the report (Vernam Applied Cryptography and Cybersecurity Lab at Worcester Polytechnic Institute)
Fixed in github pull request https://github.com/wolfSSL/wolfssl/pull/7416


* [Low] When parsing a provided maliciously crafted certificate directly using wolfSSL API, outside of a TLS connection, a certificate with an excessively large number of extensions could lead to a potential DoS. There are existing sanity checks during a TLS handshake with wolfSSL which mitigate this issue. Thanks to Bing Shi for the report.
Fixed in github pull request https://github.com/wolfSSL/wolfssl/pull/7597

* [Low] CVE-2024-5991
In the function MatchDomainName(), input param str is treated as a NULL terminated string despite being user provided and unchecked. Specifically, the Openssl compatibility function X509_check_host() takes in a pointer and length to check against, with no requirements that it be NULL terminated. While calling without a NULL terminated string is very uncommon, it is still technically allowed. If a caller was attempting to do a name check on a non*NULL terminated buffer, the code would read beyond the bounds of the input array until it found a NULL terminator.
Fixed in github pull request https://github.com/wolfSSL/wolfssl/pull/7604

* [Medium] CVE-2024-5814
A malicious TLS1.2 server can force a TLS1.3 client with downgrade capability to use a ciphersuite that it did not agree to and achieve a successful connection. This is because, aside from the extensions, the client was skipping fully parsing the server hello when downgrading from TLS 1.3.
Fixed in github pull request https://github.com/wolfSSL/wolfssl/pull/7619

* [Medium] OCSP stapling version 2 response verification bypass issue when a crafted response of length 0 is received. Found with internal testing.
Fixed in github pull request https://github.com/wolfSSL/wolfssl/pull/7702

* [Medium] OCSP stapling version 2 revocation bypass with a retry of a TLS connection attempt. A revoked CA certificate could incorrectly be loaded into the trusted signers list and used in a repeat connection attempt. Found with internal testing.
Fixed in github pull request https://github.com/wolfSSL/wolfssl/pull/7702


## New Feature Additions
* Added Dilithium/ML-DSA: Implementation of ML-DSA-44/65/87 (PR 7622)
* AES RISC-V 64-bit ASM: ECB/CBC/CTR/GCM/CCM (PR 7569)
* Added CUDA support for AES encryption (PR 7436)
* Added support for gRPC (PR 7445)
* Added function wc_RsaPrivateKeyDecodeRaw to import raw RSA private keys (PR 7608)
* Added crypto callback for SHA-3 (PR 7670)
* Support for Infineon Modus Toolbox with wolfSSL (PR 7369)
* Allow user to send a user_canceled alert by calling wolfSSL_SendUserCanceled (PR 7590)
* C# wrapper SNI support added (PR 7610)
* Quantum-safe algorithm support added to the Linux kernel module (PR 7574)
* Support for NIST 800-56C Option 1 KDF, using the macro WC_KDF_NIST_SP_800_56C added (PR 7589)
* AES-XTS streaming mode added, along with hardware acceleration and kernel module use (PR 7522, 7560, 7424)
* PlatformIO FreeRTOS with ESP build and addition of benchmark and test example applications (PR 7528, 7413, 7559, 7542)


## Enhancements and Optimizations
* Expanded STM32 AES hardware acceleration support for use with STM32H5 (PR 7578)
* Adjusted wc_xmss and wc_lms settings to support use with wolfBoot (PR 7393)
* Added the --enable-rpk option to autotools build for using raw public key support (PR 7379)
* SHA-3 Thumb2, ARM32 assembly implementation added (PR 7667)
* Improvements to RSA padding to expose Pad/Unpad APIs (PR 7612)
* Updates and API additions for supporting socat version 1.8.0.0 (PR 7594)
* cmake build improvements, expanding build options with SINGLE_THREADED and post-quantum algorithms, adjusting the generation of options.h file and using “yes;no” boolean instead of strings (PR 7611, 7546, 7479, 7480, 7380)
* Improvements for Renesas RZ support (PR 7474)
* Improvements to dual algorithm certificates for post-quantum keys (PR 7286)
* Added wolfSSL_SessionIsSetup so the user can check if a session ticket has been sent by the server (PR 7430)
* hostap updates: Implement PACs for EAP-FAST and filter cipher list on TLS version change (PR 7446)
* Changed subject name comparison to match different upper and lower cases (PR 7420)
* Support for DTLS 1.3 downgrade when using PSK (PR 7367)
* Update to static memory build for more generic memory pools used (PR 7418)
* Improved performance of Kyber C implementation (PR 7654)
* Support for ECC_CACHE_CURVE with no malloc (PR 7490)
* Added the configure option --enable-debug-trace-errcodes (macro WOLFSSL_DEBUG_TRACE_ERROR_CODES) which enables more debug tracking of error code values (PR 7634)
* Enhanced wc_MakeRsaKey and wc_RsaKeyToDer to work with WOLFSSL_NO_MALLOC (PR 7362)
* Improvements to assembly implementations of ChaCha20 and Poly1305 ASM for use with MSVC (PR 7319)
* Cortex-M inline assembly labels with unique number appended (PR 7649)
* Added secret logging callback to TLS <= 1.2, enabled with the macro HAVE_SECRET_CALLBACK (PR 7372)
* Made wc_RNG_DRBG_Reseed() a public wolfCrypt API (PR 7386)
* Enabled DES3 support without the DES3 ciphers. To re-enable DES3 cipher suites, use the configure flag --enable-des3-tls-suites (PR 7315)
* Added stubs required for latest nginx (1.25.5) (PR 7449)
* Added option for using a custom salt with the function wc_ecc_ctx_set_own_salt (PR 7552)
* Added PQ files for Windows (PR 7419)
* Enhancements to static memory feature, adding the option for a global heap hint (PR 7478) and build options for a lean or debug setting, enabled with --enable-staticmemory=small or --enable-staticmemory=debug (PR 7597)
* Updated --enable-jni to define SESSION_CERTS for wolfJSSE (PR 7557)
* Exposed DTLS in Ada wrapper and updated examples (PR 7397)
* Added additional minimum TLS extension size sanity checks (PR 7602)
* ESP improvements: updating the examples and libraries, updates for Apple HomeKit SHA/SRP, and fix for endianness with SHA512 software fallback (PR 7607, 7392, 7505, 7535)
* Made the wc_CheckCertSigPubKey API publicly available with the define of the macro WOLFSSL_SMALL_CERT_VERIFY (PR 7599)
* Added an alpha/preview of additional FIPS 140-3 full submission, bringing additional algorithms such as SRTP-KDF, AES-XTS, GCM streaming, AES-CFB, ED25519, and ED448 into the FIPS module boundary (PR 7295)
* XCODE support for v5.2.3 of the FIPS module (PR 7140)
* Expanded OpenSSL compatibility layer and added EC_POINT_hex2point (PR 7191)

## Fixes
* Fixed Kyber control-flow timing leak. Thanks to Antoon Purnal from PQShield for the report
* Fixed the NXP MMCAU HW acceleration for SHA-256 (PR 7389)
* Fixed AES-CFB1 encrypt/decrypt on size (8*x-1) bits (PR 7431)
* Fixed use of %rip with SHA-256 x64 assembly (PR 7409)
* Fixed OCSP response message build for DTLS (PR 7671)
* Handled edge case in wc_ecc_mulmod() with zero (PR 7532)
* Fixed RPK (Raw Public Key) to follow certificate use correctly (PR 7375)
* Added sanity check on record header with QUIC use (PR 7638)
* Added sanity check for empty directory strings in X.509 when parsing (PR 7669)
* Added sanity check on non-conforming serial number of 0 in certificates being parsed (PR 7625)
* Fixed wolfSSL_CTX_set1_sigalgs_list() to make the TLS connection conform to the selected sig hash algorithm (PR 7693)
* Various fixes for dual algorithm certificates including small stack use and support for Certificate Signing Requests (PR 7577)
* Added sanity check for critical policy extension when wolfSSL is built without policy extension support enabled (PR 7388)
* Added sanity check that the ed25519 signature is smaller than the order (PR 7513)
* Fixed Segger emNet to handle non-blocking want read/want write (PR 7581)


# wolfSSL Release 5.7.0 (Mar 20, 2024)

Release 5.7.0 has been developed according to wolfSSL's development and QA
process (see link below) and successfully passed the quality criteria.
https://www.wolfssl.com/about/wolfssl-software-development-process-quality-assurance

NOTE: * --enable-heapmath is being deprecated and will be removed by end of 2024

NOTE: In future releases, --enable-des3 (which is disabled by default) will be insufficient in itself to enable DES3 in TLS cipher suites. A new option, --enable-des3-tls-suites, will need to be supplied in addition.  This option should only be used in backward compatibility scenarios, as it is inherently insecure.

NOTE: This release switches the default ASN.1 parser to the new ASN template code. If the original ASN.1 code is preferred define `WOLFSSL_ASN_ORIGINAL` to use it. See PR #7199.


## Vulnerabilities
* [High] CVE-2024-0901 Potential denial of service and out of bounds read. Affects TLS 1.3 on the server side when accepting a connection from a malicious TLS 1.3 client. If using TLS 1.3 on the server side it is recommended to update the version of wolfSSL used. Fixed in this GitHub pull request https://github.com/wolfSSL/wolfssl/pull/7099


* [Med] CVE-2024-1545 Fault Injection vulnerability in RsaPrivateDecryption function that potentially allows an attacker that has access to the same system with a victims process to perform a Rowhammer fault injection. Thanks to Junkai Liang, Zhi Zhang, Xin Zhang, Qingni Shen for the report (Peking University, The University of Western Australia)."
Fixed in this GitHub pull request https://github.com/wolfSSL/wolfssl/pull/7167


* [Med] Fault injection attack with EdDSA signature operations. This affects ed25519 sign operations where the system could be susceptible to Rowhammer attacks. Thanks to Junkai Liang, Zhi Zhang, Xin Zhang, Qingni Shen for the report (Peking University, The University of Western Australia).
Fixed in this GitHub pull request https://github.com/wolfSSL/wolfssl/pull/7212


## New Feature Additions

* Added --enable-experimental configure flag to gate out features that are currently experimental. Now liboqs, kyber, lms, xmss, and dual-alg-certs require the --enable-experimental flag.

### POST QUANTUM SUPPORT ADDITIONS
* Experimental framework for using wolfSSL’s XMSS implementation (PR 7161)
* Experimental framework for using wolfSSL’s LMS implementation (PR 7283)
* Experimental wolfSSL Kyber implementation and assembly optimizations, enabled with --enable-experimental --enable-kyber (PR 7318)
* Experimental support for post quantum dual key/signature certificates. A few known issues and sanitizer checks are in progress with this feature. Enabled with the configure flags --enable-experimental --enable-dual-alg-certs (PR 7112)
* CryptoCb support for PQC algorithms (PR 7110)

### OTHER FEATURE ADDITIONS
* The Linux kernel module now supports registration of AES-GCM, AES-XTS, AES-CBC, and AES-CFB with the kernel cryptosystem through the new --enable-linuxkm-lkcapi-register option, enabling automatic use of wolfCrypt implementations by the dm-crypt/luks and ESP subsystems.  In particular, wolfCrypt AES-XTS with –enable-aesni is faster than the native kernel implementation.
* CryptoCb hook to one-shot CMAC functions (PR 7059)
* BER content streaming support for PKCS7_VerifySignedData and sign/encrypt operations (PR 6961 & 7184)
* IoT-Safe SHA-384 and SHA-512 support (PR 7176)
* I/O callbacks for content and output with PKCS7 bundle sign/encrypt to reduce peak memory usage (PR 7272)
* Microchip PIC24 support and example project (PR 7151)
* AutoSAR shim layer for RNG, SHA256, and AES (PR 7296)
* wolfSSL_CertManagerUnloadIntermediateCerts API to clear intermediate certs added to certificate store (PR 7245)
* Implement SSL_get_peer_signature_nid and SSL_get_peer_signature_type_nid (PR 7236)


## Enhancements and Optimizations

* Remove obsolete user-crypto functionality and Intel IPP support (PR 7097)
* Support for RSA-PSS signatures with CRL use (PR 7119)
* Enhancement for AES-GCM use with Xilsecure on Microblaze (PR 7051)
* Support for crypto cb only build with ECC and NXP CAAM (PR 7269)
* Improve liboqs integration adding locking and init/cleanup functions (PR 7026)
* Prevent memory access before clientSession->serverRow and clientSession->serverIdx are sanitized (PR 7096)
* Enhancements to reproducible build (PR 7267)
* Update Arduino example TLS Client/Server and improve support for ESP32 (PR 7304 & 7177)
* XC32 compiler version 4.x compatibility (PR 7128)
* Porting for build on PlayStation 3 and 4 (PR 7072)
* Improvements for Espressif use; SHA HW/SW selection and use on ESP32-C2/ESP8684, wolfSSL_NewThread() type, component cmake fix, and update TLS client example for ESP8266 (PR 7081, 7173, 7077, 7148, 7240)
* Allow crypto callbacks with SHA-1 HW (PR 7087)
* Update OpenSSH port to version 9.6p1(PR 7203)
* ARM Thumb2 enhancements, AES-GCM support for GCM_SMALL, alignment fix on key, fix for ASM clobber list (PR 7291,7301,7221)
* Expand heap hint support for static memory build with more x509 functions (PR 7136)
* Improving ARMv8 ChaCha20 ASM (alignment) (PR 7182)
* Unknown extension callback wolfSSL_CertManagerSetUnknownExtCallback added to CertManager (PR 7194)
* Implement wc_rng_new_ex for use with devID’s with crypto callback (PR 7271)
* Allow reading 0-RTT data after writing 0.5-RTT data (PR 7102)
* Send alert on bad PSK binder error (PR 7235)
* Enhancements to CMake build files for use with cross compiling (PR 7188)


## Fixes

* Fix for checking result of MAC verify when no AAD is used with AES-GCM and Xilinx Xilsecure (PR 7051)
* Fix for Aria sign use (PR 7082)
* Fix for invalid `dh_ffdhe_test` test case using Intel QuickAssist (PR 7085)
* Fixes for TI AES and SHA on TM4C with HW acceleration and add full AES GCM and CCM support with TLS (PR 7018)
* Fixes for STM32 PKA use with ECC (PR 7098)
* Fixes for TLS 1.3 with crypto callbacks to offload KDF / HMAC operation (PR 7070)
* Fix include path for FSP 3.5 on Renesas RA6M4 (PR 7101)
* Siphash x64 asm fix for use with older compilers (PR 7299)
* Fix for SGX build with SP (PR 7308)
* Fix to Make it mandatory that the cookie is sent back in new ClientHello when seen in a HelloRetryRequest with (PR 7190)
* Fix for wrap around behavior with BIO pairs (PR 7169)
* OCSP fixes for parsing of response correctly when there was a revocation reason and returning correct error value with date checks (PR 7241 & 7255)
* Fix build with `NO_STDIO_FILESYSTEM` and improve checks for `XGETENV` (PR 7150)
* Fix for DTLS sequence number and cookie when downgrading DTLS version (PR 7214)
* Fix for write_dup use with chacha-poly cipher suites (PR 7206)
* Fix for multiple handshake messages in one record failing with OUT_OF_ORDER_E when downgrading from TLS 1.3 to TLS 1.2 (PR 7141)
* Fix for AES ECB build with Thumb and alignment (PR 7094)
* Fix for negotiate handshake until the end in wolfSSL_read/wolfSSL_write if hitting an edge case with want read/write (PR 7237)

# wolfSSL Release 5.6.6 (Dec 19, 2023)

Release 5.6.6 has been developed according to wolfSSL's development and QA
process (see link below) and successfully passed the quality criteria.
https://www.wolfssl.com/about/wolfssl-software-development-process-quality-assurance

NOTE: * --enable-heapmath is being deprecated and will be removed by 2024

REMINDER: When working with AES Block Cipher algorithms, `wc_AesInit()` should
always be called first to initialize the `Aes` structure, before calling other
Aes API functions. Recently we found several places in our documentation,
comments, and codebase where this pattern was not observed. We have since
fixed this omission in several PRs for this release.

## Vulnerabilities

* [Medium] CVE-2023-6935: After review of the previous RSA timing fix in wolfSSL 5.6.4, additional changes were found to be required. A complete resistant change is delivered in this release. This fix is for the Marvin attack, leading to being able to decrypt a saved TLS connection and potentially forge a signature after probing with a very large number of trial connections. This issue is around RSA decryption and affects the optional static RSA cipher suites on the server side, which are considered weak, not recommended to be used and are off by default in wolfSSL (even with `--enable-all`). Static RSA cipher suites were also removed from the TLS 1.3 protocol and are only present in TLS 1.2 and lower. All padding versions of RSA decrypt are affected since the code under review is outside of the padding processing. Information about the private keys is NOT compromised in affected code. It is recommended to disable static RSA cipher suites and update the version of wolfSSL used if using RSA private decryption alone outside of TLS. Thanks to Hubert Kario for the report. The fix for this issue is located in the following GitHub Pull Request: https://github.com/wolfSSL/wolfssl/pull/6955.

* [Low] CVE-2023-6936: A potential heap overflow read is possible in servers connecting over TLS 1.3 when the optional `WOLFSSL_CALLBACKS` has been defined. The out of bounds read can occur when a server receives a malicious malformed ClientHello. Users should either discontinue use of `WOLFSSL_CALLBACKS` on the server side or update versions of wolfSSL to 5.6.6. Thanks to the tlspuffin fuzzer team for the report which was designed and developed by; Lucca Hirschi (Inria, LORIA), Steve Kremer (Inria, LORIA), and Max Ammann (Trail of Bits). The fix for this issue is located in the following GitHub Pull Request: https://github.com/wolfSSL/wolfssl/pull/6949.

* [Low] CVE-2024-1543: A side channel vulnerability with AES T-Tables is possible in a very controlled environment where precision sub-cache-line inspection can happen, such as inside an Intel SGX enclave. This can lead to recovery of the AES key. To prevent this type of attack, wolfSSL added an AES bitsliced implementation which can be enabled with the “`--enable-aes-bitsliced`” configure option. Thanks to Florian Sieck, Zhiyuan Zhang, Sebastian Berndt, Chitchanok Chuengsatiansup, Thomas Eisenbarth, and Yuval Yarom for the report (Universities of Lübeck, Melbourne, Adelaide and Bochum). The fix for this issue is located in the following GitHub Pull Request: https://github.com/wolfSSL/wolfssl/pull/6854.

* [Low] CVE-2023-6937: wolfSSL prior to 5.6.6 did not check that messages in a single (D)TLS record do not span key boundaries. As a result, it was possible to combine (D)TLS messages using different keys into one (D)TLS record. The most extreme edge case is that, in (D)TLS 1.3, it was possible that an unencrypted (D)TLS 1.3 record from the server containing first a ServerHello message and then the rest of the first server flight would be accepted by a wolfSSL client. In (D)TLS 1.3 the handshake is encrypted after the ServerHello but a wolfSSL client would accept an unencrypted flight from the server. This does not compromise key negotiation and authentication so it is assigned a low severity rating. Thanks to Johannes Wilson for the report (Sectra Communications and Linköping University). The fix for this issue is located in the following GitHub Pull Request: https://github.com/wolfSSL/wolfssl/pull/7029.

## New Feature Additions

* Build option for disabling CRL date checks (`WOLFSSL_NO_CRL_DATE_CHECK`) (PR 6927)
* Support for STM32WL55 and improvements to PKA ECC support (PR 6937)
* Add option to skip cookie exchange on DTLS 1.3 session resumption (PR 6929)
* Add implementation of SRTP KDF and SRTCP KDF (`--enable-srtp-kdf`) (PR 6888)
* Add `wolfSSL_EXTENDED_KEY_USAGE_free()` (PR 6916)
* Add AES bitsliced implementation that is cache attack safe (`--enable-aes-bitsliced`) (PR 6854)
* Add memcached support and automated testing (PR 6430, 7022)
* Add Hardware Encryption Acceleration for ESP32-C3, ESP32-C6, and ESP32-S2 (PR 6990)
* Add (D)TLS 1.3 support for 0.5-RTT data (PR 7010)

## Enhancements and Optimizations

* Better built in testing of “`--sys-ca-certs`” configure option (PR 6910)
* Updated CMakeLists.txt for Espressif wolfSSL component usage (PR 6877)
* Disable TLS 1.1 by default (unless SSL 3.0 or TLS 1.0 is enabled) (PR 6946)
* Add “`--enable-quic`” to “`--enable-all`” configure option (PR 6957)
* Add support to SP C implementation for RSA exponent up to 64-bits (PR 6959)
* Add result of “`HAVE___UINT128_T`” to options.h for CMake builds (PR 6965)
* Add optimized assembly for AES-GCM on ARM64 using hardware crypto instructions (PR 6967)
* Add built-in cipher suite tests for DTLS 1.3 PQC (PR 6952)
* Add wolfCrypt test and unit test to ctest (PR 6977)
* Move OpenSSL compatibility crypto APIs into `ssl_crypto.c` file (PR 6935)
* Validate time generated from XGMTIME() (PR 6958)
* Allow wolfCrypt benchmark to run with microsecond accuracy (PR 6868)
* Add GitHub Actions testing with nginx 1.24.0 (PR 6982)
* Allow encoding of CA:FALSE BasicConstraint during cert generation (PR 6953)
* Add CMake option to enable DTLS-SRTP (PR 6991)
* Add CMake options for enabling QUIC and cURL (PR 7049)
* Improve RSA blinding to make code more constant time (PR 6955)
* Refactor AES-NI implementation macros to allow dynamic fallback to C (PR 6981)
* Default to native Windows threading API on MinGW (PR 7015)
* Return better error codes from OCSP response check (PR 7028)
* Updated Espressif ESP32 TLS client and server examples (PR 6844)
* Add/clean up support for ESP-IDF v5.1 for a variety of ESP32 chips (PR 7035, 7037)
* Add API to choose dynamic certs based on client ciphers/sigalgs (PR 6963)
* Improve Arduino IDE 1.5 project file to match recursive style (PR 7007)
* Simplify and improve apple-universal build script (PR 7025)

## Fixes

* Fix for async edge case with Intel QuickAssist/Cavium Nitrox (PR 6931)
* Fix for building PKCS#7 with RSA disabled (PR 6902)
* Fix for advancing output pointer in `wolfSSL_i2d_X509()` (PR 6891)
* Fix for `EVP_EncodeBlock()` appending a newline (PR 6900)
* Fix for `wolfSSL_RSA_verify_PKCS1_PSS()` with `RSA_PSS_SALTLEN_AUTO` (PR 6938)
* Fixes for CODESonar reports around `isalpha()` and `isalnum()` calls (PR 6810)
* Fix for SP ARM64 integer math to avoid compiler optimization issues (PR 6942)
* Fix for SP Thumb2 inline assembly to add IAR build support (PR 6943, 6971)
* Fix for SP Thumb2 to make functions not inlined (PR 6993)
* Fix for SP Cortex-M assembly large build with IAR (PR 6954)
* Fix for SP ARM64 assembly montgomery reduction by 4 (PR 6947)
* Fix for SP ARM64 P-256 for not inlining functions for iOS compatibility (PR 6979)
* Fix for `WOLFSSL_CALLBACKS` and potential memory error (PR 6949)
* Fixes for wolfSSL’s Zephyr OS port (PR 6930)
* Fix for build errors when building for NXP mmCAU (`FREESCALE_MMCAU`) (PR 6970)
* Fix for TLS 1.3 `SendBuffered()` return code in non-blocking mode (PR 7001)
* Fix for TLS `Hmac_UpdateFinal()` when padding byte is invalid (PR 6998)
* Fix for ARMv8 AES-GCM streaming to check size of IV before storing (PR 6996)
* Add missing calls to `wc_AesInit()` before `wc_AesSetKey()` (PR 7011)
* Fix build errors with DTLS 1.3 enabled but TLS 1.2 disabled (PR 6976)
* Fixes for building wolfSSL in Visual Studio (PR 7040)

# wolfSSL Release 5.6.4 (Oct 30, 2023)

Release 5.6.4 has been developed according to wolfSSL's development and QA process (see link below) and successfully passed the quality criteria.
https://www.wolfssl.com/about/wolfssl-software-development-process-quality-assurance

NOTE: * --enable-heapmath is being deprecated and will be removed by 2024
      * Old CyaSSL/CtaoCrypt shim layer was removed in this release (5.6.4)

## Vulnerabilities

* [Medium] A fix was added, but still under review for completeness, for a Bleichenbacher style attack, leading to being able to decrypt a saved TLS connection and potentially forge a signature after probing with a large number of trial connections. This issue is around RSA decryption and affects static RSA cipher suites on the server side, which are not recommended to be used and are off by default. Static RSA cipher suites were also removed from the TLS 1.3 protocol and only present in TLS 1.2 and lower. All padding versions of RSA decrypt are affected since the code under review is outside of the padding processing. Information about the private keys is NOT compromised in affected code. It's recommended to disable static RSA cipher suites and update the version of wolfSSL used if using RSA private decryption alone outside of TLS. The fix is located in this pull request (https://github.com/wolfSSL/wolfssl/pull/6896)

## New Feature Additions

* DTLS 1.3 PQC: support fragmenting the second ClientHello message. This allows arbitrarily long keys to be used, opening up support for all PQC ciphersuites in DTLS 1.3.
* SM2/SM3/SM4: Chinese cipher support including TLS 1.3 and 1.2 cipher suites. SM2 SP implementation available.
* Ability to parse ASN1 only with SMIME_read_PKCS7
* Added support for MemUse Entropy on Windows
* Added Ada Bindings for wolfSSL
* Added a PEM example that converts to and from DER/PEM.
* Added LMS/HSS and XMSS/XMSS^MT wolfcrypt hooks, both normal and verify-only options.
* Added support for the AES EAX mode of operation
* Port for use with Hitch (https://github.com/varnish/hitch) added
* Add XTS API's to handle multiple sectors in new port to VeraCrypt

## Enhancements and Optimizations

* Turned on SNI by default on hosts with resources
* Improved support for Silicon Labs Simplicity Studio and the ERF32 Gecko SDK
* Thumb-2 and ARM32 Curve25519 and Ed25519 assembly have significantly improved performance.
* Thumb-2 AES assembly code added.
* Thumb-2 and ARM32 SP implementations of RSA, DH and ECC have significantly improved performance.
* Minor performance improvements to SP ECC for Intel x64.
* AES-XTS assembly code added for Intel x64, Aarch64 and ARM32.
* Added support for X963 KDFs to ECIES.
* Added 32-bit type only implementation of AES GMULT using tables.
* Add support for nginx version 1.25.0
* Add support for Kerberos version 5 1.21.1
* Check all CRL entries in case a single issuer has multiple CRL's loaded
* CRL verify the entire chain including loaded CA's
* Added example for building wolfSSL as an Apple universal binary framework using configure
* Sniffer tool now supports decrypting TLS sessions using secrets obtained from a SSLKEYLOGFILE
* Updates made for EBSNET port
* Update "--enable-jni" to include additional defines for expanded JNI support. Also includes JCE and JSSE builds under the single enable option now.

## Fixes

* Fixed error handling when decrypted pre-master secret is too long when using static RSA.
* Added a fix for keymod use with i.MX RT1170 CAAM blobs
* Added a fix for AES-GCM use with Petalinux Xilinx
* Fixed `wc_SignatureGenerate_ex` to not call verify twice
* Fixed wolfCrypt FIPS DLL on Win32
* Fixed TFM math library big-endian reading implementation when a zero length buffer is passed in.
* Fixed NO_CERT configurations to build correctly.
* Fixed ARM AES-GCM streaming assembly when –enable-opensslextra defined.
* Added modulus checks to heap math implementation of mp_exptmod().
* Fixed Windows assembly code to handle that certain XMM registers are non-volatile.
* Aarch64 SP ECC implementation of sp_256_mont_dbl_4 has the register list for the assembly code fixed to include all used registers.
* mp_sqrt_mod_prime fixed to limit the number of iterations of a loop to handle malicious non-prime values being passed in.
* Ignore session ID's shorter than 32 bytes instead of erroring out

# wolfSSL Release 5.6.3 (Jun 16, 2023)

Release 5.6.3 of wolfSSL embedded TLS has 4 bug fixes:

* Fix for setting the atomic macro options introduced in release 5.6.2. This issue affects GNU gcc autoconf builds. The fix resolves a potential mismatch of the generated macros defined in options.h file and the macros used when the wolfSSL library is compiled. In version 5.6.2 this mismatch could result in unstable runtime behavior.
* Fix for invalid suffix error with Windows build using the macro GCM_TABLE_4BIT.
* Improvements to Encrypted Memory support (WC_PROTECT_ENCRYPTED_MEM) implementations for modular exponentiation in SP math-all (sp_int.c) and TFM (tfm.c).
* Improvements to SendAlert for getting output buffer.

# wolfSSL Release 5.6.2 (Jun 09, 2023)

Release 5.6.2 has been developed according to wolfSSL's development and QA process (see link below) and successfully passed the quality criteria.
https://www.wolfssl.com/about/wolfssl-software-development-process-quality-assurance

NOTE: * --enable-heapmath is being deprecated and will be removed by 2024

Release 5.6.2 of wolfSSL embedded TLS has bug fixes and new features including:

## Vulnerabilities
* [Low] In cases where a malicious agent could analyze cache timing at a very detailed level, information about the AES key used could be leaked during T/S Box lookups. One such case was shown on RISC-V hardware using the MicroWalk tool (https://github.com/microwalk-project/Microwalk). A hardened version of T/S Box lookups was added in wolfSSL to help mitigate this potential attack and is now on by default with RISC-V builds and can be enabled on other builds if desired by compiling wolfSSL with the macro WOLFSSL_AES_TOUCH_LINES. Thanks to Jan Wichelmann, Christopher Peredy, Florian Sieck, Anna Pätschke, Thomas Eisenbarth (University of Lübeck): MAMBO-V: Dynamic Side-Channel Leakage Analysis on RISC-V. Fixed in the following GitHub pull request https://github.com/wolfSSL/wolfssl/pull/6309
* [High] In previous versions of wolfSSL if a TLS 1.3 client gets neither a PSK (pre shared key) extension nor a KSE (key share extension) when connecting to a malicious server, a default predictable buffer gets used for the IKM value when generating the session master secret. Using a potentially known IKM value when generating the session master secret key compromises the key generated, allowing an eavesdropper to reconstruct it and potentially allowing surreptitious access to or meddling with message contents in the session. This issue does not affect client validation of connected servers, nor expose private key information, but could result in an insecure TLS 1.3 session when not controlling both sides of the connection. We recommend that TLS 1.3 client side users update the version of wolfSSL used. Thanks to Johannes from Sectra Communications and Linköping University for the report. Fixed in the following GitHub pull request https://github.com/wolfSSL/wolfssl/pull/6412

## New Feature Additions

### New Ports and Expansions
* Add support for STM32H5
* Add support for Renesas TSIP v1.17
* Add Renesas SCE RSA crypto-only support
* STARCORE DSP port and example builds added
* Add the function wc_PKCS7_SetDefaultSignedAttribs for setting PKCS7 signed attributes to use with PKCS7 bundle creation
* NXP IMX6Q CAAM port with QNX and performance optimizations for AES-CTR

### New Build Options
* ASN.1 print utility to decode ASN.1 syntax and print out human readable text --enable-asn-print. Utility app is located in the directory ./examples/asn1/
* Add introspection for math build, wc_GetMathInfo() to get information about the math library compiled into the linked wolfSSL library
* Implement TLS recommendations from RFC 9325 for hardening TLS/DTLS security. Enabled with the autoconf flag --enable-harden-tls.
* Add option to support disabling thread local storage, --disable-threadlocal
* Added wc_DsaSign_ex() and wc_DsaVerify_ex() for handling alternative digest algorithms with DSA Sign/Verify
* Implement atomic operations interface. Macros auto-detect if atomic operations are expected to be available, can be turned off with the macro WOLFSSL_NO_ATOMICS
* Added support for DTLS 1.3 Authentication and Integrity-Only Cipher Suites
* Expand crypto callback to have a device ID find callback function with wc_CryptoCb_SetDeviceFindCb. Enabled with the macro WOLF_CRYPTO_CB_FIND

## Enhancements and Optimizations

### Optimizations
* Increased performance with ChaCha20 C implementation and general XOR operations
* Added integer type to the ASN.1 sequencing with ASN.1 Integer sequence
* With wolfSSL_get_x509_next_altname reset alt name list to head once cycled through if compiling with the macro WOLFSSL_MULTICIRCULATE_ALTNAMELIST
* Additional key validity sanity checks on input to wolfSSL_EC_KEY_set_private_key
* adds support for TLSv1.3 stateful session tickets when using SSL_OP_NO_TICKET

### Memory Optimizations
* Improvements to stack usage and management with SP int math library
* Optimization to TLS 1.3 server to remove caching messages for Ed25519/Ed448
* Added a HAVE_CURL macro build for building a subset of the wolfSSL library when linking with cURL
* Memory usage improvement with reducing the size of alignment needed with AES
* Reduce run time memory used with ECC operations and ALT_ECC_SIZE
* Fixes and improvements for building edge cases such as crypto callback without hash-drbg with low footprint options
* Support HAVE_SESSION_TICKET build option without depending on realloc

### Documentation
* Instructions for GPDMA on STM32 configuration added
* Add in instructions for compiling with zephyr on STM32
* Documentation fixup for wolfSSL_get_chain_cert()
* Fix the file pointed to in the TI RTOS documentation that we maintain
* Documentation for wolfSSL_CertManagerFreeCRL
* Updates made to AES and Chacha documentation
* Update Japanese comments for Ed25519, AES, and other miscellaneous items

### Tests
* Add in an option for easily testing malloc failures when building with WOLFSSL_MEM_FAIL_COUNT macro
* Updated in process for using Expect vs Assert to facilitate more malloc failure tests
* Enhance wolfCrypt test for builds that do not have ECC SECP curves enabled
* ESP32 platform-specific VisualGDB test & benchmark projects
* Update to dependencies in docker container file used for tests
* Fix up for base 10 output with bundled benchmark application

### Port Updates
* Zephyr port update, compile time warning fixes, misc. fixes when used with TLS and update of includes
* Update RIOT-OS to not compile out use of writev by default
* Update Micrium port to enable use of STM32_RNG
* Micrium updates for XMEMOVE and XSTRTOK use
* Various Espressif HW crypto, SHA2, AES, MP updates
* Added in ASIO build option with CMake builds

### General Enhancements
* Global codebase cleanup for C89 compliance and wolfCrypt -Wconversion hygiene
* PKCS#11 enhancement adding a callback for RSA key size when using a hardware key, by default 2048 bit key is used
* Allow for unknown OIDs in extensions in wolfSSL_X509_set_ext()
* Allow user to override XSTAT by defining the macro XSTAT when compiling
* Support UPN and SID with x509 certificate extensions and custom OID build
* Write next IV in wolfSSL_DES_ede3_cbc_encrypt for better handling of inline encryption
* Adding NO_ASN_TIME_CHECK build option for compiling out certificate before/after checks
* Improve different peer recvfrom handling and error reporting with ipv4 vs ipv6

## Fixes
* Fix for STM32 ECC sign and verify out of bounds buffer write when the hash length passed in is larger than the key size. Thanks to Maximilian for the report.
* Fix to skip Async_DevCtxInit when using init rsa/ecc label/id api's
* Revert WOLFSSL_NO_ASN_STRICT macro guard around alternate names directory list
* In async mode, don't retry decrypting if a valid error is encountered on a packet parse attempt
* Add additional sanity check on PKCS7 index value in wc_PKCS7_DecryptKekri
* Fix for padding when using an AuthEnvelope PKCS7 type with GCM/CCM stream ciphers
* Fix siphash assembly so that no register is left behind
* Fix to not send a TLS 1.3 session ID resume response when resuming and downgrading to a protocol less than TLS 1.3
* Fix overwriting serialNumber by favouriteDrink when generating a certificate using Cert struct
* Fix for the default realloc used with EspressIf builds
* Track SetDigest usage to avoid invalid free under error conditions
* DTLS v1.3 fix for epoch 0 check on plaintext message
* Fix for session ticket memory leak in wolfSSL_Cleanup
* Fixes for propagating SendAlert errors when the peer disconnects
* Replace XMEMCPY with XMEMMOVE to fix valgrind-3.15.0 reports "Source and destination overlap in memcpy" when using --enable-aesgcm-stream
* Fix for potential out-of-bounds write edge case in fp_mod_2d with --enable-fastmath math library
* Fix getting ECC key size in stm32_ecc_sign_hash_ex
* Fix for case where wc_PeekErrorNodeLineData was not unlocking error queue on error
* Fix for async ECC shared secret state
* Fix for better error checking with sp_gcd with SP int math library
* Fix memory leak in TLSX_KeyShare_Setup when handling an error case
* Fix for double free edge case in InitOCSPRequest when handling a memory allocation failure
* X509 NAME Entry fix for leaking memory on error case
* Fix wolfssl_asn1_time_to_tm setting unexpected fields in tm struct
* Fix for FIPS ECC integrity check with crypto callback set
* BN_to_ASN1_INTEGER fix for handling leading zero byte padding when needed
* Fix a typo in PP macro and add a ceiling to guard against implementation bugs
* DTLS 1.3 fix for using the correct label when deriving the resumption key
* OCSP fix for GetDateInfo edge case with non ASN template builds
* Allow a user set certificate callback function to override the skipAddCA flag when parsing a certificate
* SP int: sp_radix_size when radix 10 fix temp size for handling edge case
* Fixes and improvements for handling failures with memory allocations
* Fix for DecodeECC_DSA_Sig to handle r and s being initialized
* Fix for wc_ecc_is_point to ensure that the x and y are in range [0, p-1] and z is one (affine ordinates)

### Build Fixes
* Fix for building on Windows with CMake and using USER_SETTINGS and fix for options.h creation with CMake when using USER_SETTINGS
* CMake fixes and improvements for use with mingw32
* Fix for building with wpas and x509 small options
* Check if colrm is available for options.h creation when using autoconf
* Clean up NO_BIG_INT build, removing WOLFSSL_SP_MATH macro and heapmath compile
* Fix PKCS#7 build with NO_PKCS7_STREAM
* Fix compilation error in CC-RX and remove unnecessary public key import
* SP Build fixes for ARM assembly with ARMv6 clz and ARM thumb debug build
* For to not advertise support for RSA in TLS extensions when compiled with NO_RSA

# wolfSSL Release 5.6.0 (Mar 24, 2023)

Release 5.6.0 has been developed according to wolfSSL's development and QA process (see link below) and successfully passed the quality criteria.
https://www.wolfssl.com/about/wolfssl-software-development-process-quality-assurance

NOTE: * --enable-heapmath is being deprecated and will be removed by 2024
      * This release makes ASN Template the default with ./configure, the previous ASN parsing can be built with --enable-asn=original

Release 5.6.0 of wolfSSL embedded TLS has bug fixes and new features including:

## New Feature Additions

* ASN template is now the default ASN parsing implementation when compiling with configure
* Added in support for TLS v1.3 Encrypted Client Hello (ECH) and HPKE (Hybrid Public Key Encryption)
* DTLS 1.3 stateless server ClientHello parsing support added

### Ports
* Add RX64/RX71 SHA hardware support
* Port to RT1170 and expand NXP CAAM driver support
* Add NuttX integration files for ease of use
* Updated Stunnel support for version 5.67
Compatibility Layer
* Add in support for AES-CCM with EVP
* BN compatibility API refactoring and separate API created
* Expanding public key type cipher suite list strings support

### Misc.
* Support pthread_rwlock and add enable option
* Add wolfSSL_CertManagerLoadCABuffer_ex() that takes a user certificate chain flag and additional verify flag options
* Docker build additions for wolfSSL library and wolfCLU application
* Add favorite drink pilot attribute type to get it from the encoding
* Added in support for indefinite length BER parsing with PKCS12
* Add dynamic session cache which allocates sessions from the heap with macro SESSION_CACHE_DYNAMIC_MEM


## Improvements / Optimizations

### Tests
* Additional CI (continuous integration) testing and leveraging of GitHub workflows
* Add CI testing for wpa_supplicant, OpenWrt and OpenVPN using GitHub workflows
* Add compilation of Espressif to GitHub workflows tests
* Refactoring and improving error results with wolfCrypt unit test application
* Minor warning fixes from Coverity static analysis scan
* Add new SHA-512/224 and SHA-512/256 tests
* Used codespell and fixed some minor typos

### Ports
* Improve TLS1.2 client authentication to use TSIP
* Updated Kyber macro to be WOLFSSL_HAVE_KYBER and made changes that make Kyber work on STM32
* AES-GCM Windows assembly additions
* CRLF line endings, trailing spaces for C# Wrapper Projects
Compatibility Layer
* Update `PubKey` and `Key` PEM-to-DER APIs to support return of needed DER size
* Allow reading ENC EC PRIVATE KEY as well via wolfSSL_PEM_read_bio_ECPrivateKey
* Improve wolfSSL_EC_POINT_cmp to handle Jacobian ordinates
* Fix issue with BIO_reset() and add BIO_FLAGS_MEM_RDONLY flag support for read only BIOs

### SP
* In SP math library rework mod 3 and use count leading zero instruction
* Fix with SP ECC sign to reject the random k generated when r is 0
* With SP math add better detection of when add won't work and double is needed with point_add_qz1 internal function
* With SP int fail when buffer writing to is too small for number rather than discarding the extra values

### Builds
* Define WOLFSSL_SP_SMALL_STACK if wolfSSL is build with --enable-smallstack
* Fix CMake to exclude libm when DH is not enabled
* Allow building of SAKKE as external non-FIPS algorithm with wolfmikey product
* Add option to add library suffix, --with-libsuffix
* ASN template compile option WOLFSSL_ASN_INT_LEAD_0_ANY to allow leading zeros
* Add user_settings.h template for wolfTPM to examples/configs/user_settings_wolftpm.h
* Purge the AES variant of Dilithium
* Expand WOLFSSL_NO_ASN_STRICT to allow parsing of explicit ECC public key
* Remove relocatable text in ARMv7a AES assembly for use with FIPS builds
* Expand checking for hardware that supports ARMv7a neon with autotools configure
* Sanity check on allocation fails with DSA and FP_ECC build when zeroizing internal buffer
* Additional TLS alerts sent when compiling with WOLFSSL_EXTRA_ALERTS macro defined

### Benchmarking
* Update wolfCrypt benchmark Windows build files to support x64 Platform
* Add SHA512/224 and SHA512/256 benchmarks, fixed CVS macro and display sizes
* Separate AES-GCM streaming runs when benchmarked
* No longer call external implementation of Kyber from benchmark
* Fix for benchmarking shake with custom block size
* Fixes for benchmark help `-alg` list and block format
Documentation/Examples
* Document use of wc_AesFree() and update documentation of Ed25519 with Doxygen
* Move the wolfSSL Configuration section higher in QUIC.md
* Add Japanese Doxygen documentation for cmac.h, quic.h and remove incomplete Japanese doxygen in asn_public.h
* Espressif examples run with local wolfSSL now with no additional setup needed
* Added a fix for StartTLS use In the example client
* Add a base-line user_settings.h for use with FIPS 140-3 in XCode example app

### Optimizations
* AES-NI usage added for AES modes ECB/CTR/XTS

### Misc
* Update AES-GCM stream decryption to allow long IVs
* Internal refactor to use wolfSSL_Ref functions when incrementing or decrementing the structures reference count and fixes for static analysis reports
* Cleanup function logging making adjustments to the debug log print outs
* Remove realloc dependency in DtlsMsgCombineFragBuckets function
* Refactor to use WOLFSSL_CTX’s cipher suite list when possible
* Update internal padding of 0’s with DSA sign and additional tests with mp_to_unsigned_bin_len function
* With DTLS SRTP use wolfSSL_export_keying_material instead of wc_PRF_TLS
* Updated macro naming from HAVE_KYBER to be WOLFSSL_HAVE_KYBER
* Update AES XTS encrypt to handle in-place encryption properly
* With TLS 1.3 add option to require only PSK with DHE

## Fixes

### Ports
* Fix for AES use with CAAM on imx8qxp with SECO builds
* Fix for PIC32 crypto HW and unused `TLSX_SetResponse`
* Fix warning if ltime is unsigned seen with QNX build
* Updates and fix for Zephyr project support
* Include sys/time.h for WOLFSSL_RIOT_OS
* Move X509_V errors from enums to defines for use with HAProxy CLI
* Fix IAR compiler warnings resolved
* Fix for STM32 Hash peripherals (like on F437) with FIFO depth = 1
* ESP32 fix for SHA384 init with hardware acceleration

### Builds
* Add WOLFSSL_IP_ALT_NAME macro define to --enable-curl
* Fixes for building with C++17 and avoiding clashing with byte naming
* Fixes SP math all build issue with small-stack and no hardening
* Fix for building with ASN template with `NO_ASN_TIME` defined
* Fix building FIPSv2 with WOLFSSL_ECDSA_SET_K defined
* Don't allow aesgcm-stream option with kcapi
* Fix DTLS test case for when able to read peers close notify alert on FreeBSD systems
* Fix for "expression must have a constant value" in tls13.c with Green Hills compiler
* Fixes for building KCAPI with opensslextra enabled
* Fix warnings of shadows min and subscript with i486-netbsd-gcc compiler
* Fix issue with async and `WOLFSSL_CHECK_ALERT_ON_ERR`
* Fix for PKCS7 with asynchronous crypto enabled

### Math Library
* SP Aarch64 fix for conditional changed in asm needing "cc" and fix for ECC P256 mont reduce
* In SP builds add sanity check with DH exp. to check the output length for minimum size
* In SP math fix scalar length check with EC scalar multiply
* With SP int fix handling negative character properly with read radix
* Add error checks before setting variable err in SP int with the function sp_invmod_mont_ct
* Fix to add sanity check for malloc of zero size in fastmath builds
* In fastmath  fix a possible overflow in fp_to_unsigned_bin_len length check
* Heapmath fast mod. reduce fix

### Compatibility Layer
* Fixes for encoding/decoding ecc public keys and ensure i2d public key functions do not include any private key information
* Fix for EVP_EncryptUpdate to update outl on empty input
* Fix SE050 RSA public key loading and RSA/ECC SE050 TLS Compatibility
* Rework EC API and validate point after setting it
* Fix for X509 RSA PSS with compatibility layer functions
* Fix size of structures used with SHA operations when built with opensslextra for Espressif hardware accelerated hashing
* Added sanity check on key length with wolfSSL_CMAC_Init function
* Fix for return value type conversion of bad mutex error in logging function
* Fix NID conflict NID_givenName and NID_md5WithRSAEncryption
* Fix unguarded XFPRINTF calls with opensslextra build
* Fix wolfSSL_ASN1_INTEGER_to_BN for negative values
* Fix for potential ASN1_STRING leak in wolfSSL_X509_NAME_ENTRY_create_by_txt  and wolfSSL_X509_NAME_ENTRY_create_by_NID when memory allocation fails

### Misc.
* Add sanity check to prevent an out of bounds read with OCSP response decoding
* Sanity check to not allow 0 length with bit string and integer when parsing ASN1 syntax
* Adjust RNG sanity checks and remove error prone first byte comparison
* With PKCS7 add a fix for GetAsnTimeString() to correctly increment internal data pointer
* PKCS7 addition of sequence around algo parameters with authenvelop
* DSA fixes for clearing mp_int before re-reading data and avoid mp_clear without first calling mp_init
* Fix for SRTP setting bitfield when it is encoded for the TLS extension
* Fix for handling small http headers when doing CRL verification
* Fix for ECCSI hash function to validate the output size and curve size
* Fix for value of givenName and name being reversed with CSR generation
* Fix for error type returned (OCSP_CERT_UNKNOWN) with OCSP verification
* Fix for a potential memory leak with ProcessCSR when handling OCSP responses
* Fix for VERIFY_SKIP_DATE flag not ignoring date errors when set
* Fix for zlib decompression buffer issue with PKCS7
* Fix for DTLS message pool send size used and DTLS server saving of the handshake sequence
* Fix to propagate WOLFSSL_TICKET_RET_CREATE error return value from DoDecryptTicket()
* Fix for handling long session IDs with TLS 1.3 session tickets
* Fix for AES-GCM streaming when caching an IV
* Fix for test case with older selftest that returns bad padding instead of salt len error
* Add fix for siphash cache and added in additional tests
* Fix potential out of bounds memset to 0 in error case with session export function used with --enable-sessionexport builds
* Fix possible NULL dereference in TLSX_CSR_Parse with TLS 1.3
* Fix for sanity check on RSA pad length with no padding using the build macro WC_RSA_NO_PADDING

# wolfSSL Release 5.5.4 (Dec 21, 2022)

Release 5.5.4 of wolfSSL embedded TLS has bug fixes and new features including:

## New Feature Additions

* QUIC related changes for HAProxy integration and config option
* Support for Analog Devices MAXQ1080 and MAXQ1065
* Testing and build of wolfSSL with NuttX
* New software based entropy gatherer with configure option --enable-entropy-memuse
* NXP SE050 feature expansion and fixes, adding in RSA support and conditional compile of AES and CMAC
* Support for multi-threaded sniffer

## Improvements / Optimizations

### Benchmark and Tests
* Add alternate test case for unsupported static memory API when testing mutex allocations
* Additional unit test cases added for AES CCM 256-bit
* Initialize and free AES object with benchmarking AES-OFB
* Kyber with DTLS 1.3 tests added
* Tidy up Espressif ESP32 test and benchmark examples
* Rework to be able to run API tests individually and add display of time taken per test

### Build and Port Improvements
* Add check for 64-bit ABI on MIPS64 before declaring a 64-bit CPU
* Add support to detect SIZEOF_LONG in armclang and diab
* Added in a simple example working on Rx72n
* Update azsphere support to prevent compilation of file included inline
* --enable-brainpool configure option added and default to on when custom curves are also on
* Add RSA PSS salt defines to engine builds if not FIPS v2

### Post Quantum
* Remove kyber-90s and route all Kyber through wolfcrypt
* Purge older version of NTRU and SABER from wolfSSL

### SP Math
* Support static memory build with sp-math
* SP C, SP int: improve performance
* SP int: support mingw64 again
* SP int: enhancements to guess 64-bit type and check on NO_64BIT macro set before using long long
* SP int: check size required when using sp_int on stack
* SP: --enable-sp-asm now enables SP by default if not set
* SP: support aarch64 big endian

### DTLS
* Allow DTLS 1.3 to compile when FIPS is enabled
* Allow for stateless DTLS client hello parsing

### Misc.
* Easier detection of DRBG health when using Intel’s RDRAND by updating the structures status value
* Detection of duplicate known extensions with TLS
* PKCS#11 handle a user PIN that is a NULL_PTR, compile time check in finding keys, add initialization API
* Update max Cert Policy size based on RFC 5280
* Add Android CA certs path for wolfSSL_CTX_load_system_CA_certs()
* Improve logic for enabling system CA certs on Apple devices
* Stub functions to allow for cpuid public functions with non-intel builds
* Increase RNG_SECURITY_STRENGTH for FIPS
* Improvements in OpenSSL Compat ERR Queue handling
* Support ASN1/DER CRLs in LoadCertByIssuer
* Expose more ECC math functions and improve async shared secret
* Improvement for sniffer error messages
* Warning added that renegotiation in TLS 1.3 requires session ticket
* Adjustment for TLS 1.3 post auth support
* Rework DH API and improve PEM read/write

## Fixes

### Build Fixes
* Fix --enable-devcrypto build error for sys without u_int8_t type
* Fix casts in evp.c and build issue in ParseCRL
* Fixes for compatibility layer building with heap hint and OSSL callbacks
* fix compile error due to Werro=undef on gcc-4.8
* Fix mingw-w64 build issues on windows
* Xcode project fixes for different build settings
* Initialize variable causing failures with gcc-11 and gcc-12 with a unique wolfSSL build configuration
* Prevent WOLFSSL_NO_MALLOC from breaking RSA certificate verification
* Fixes for various tests that do not properly handle `WC_PENDING_E` with async. builds
* Fix for misc `HashObject` to be excluded for `WOLFCRYPT_ONLY`

### OCSP Fixes
* Correctly save next status with OCSP response verify
* When the OCSP responder returns an unknown exception, continue through to checking the CRL

### Math Fixes
* Fix for implicit conversion with 32-bit in SP math
* Fix for error checks when modulus is even with SP int build
* Fix for checking of err in _sp_exptmod_nct with SP int build
* ECC cofactor fix when checking scalar bits
* ARM32 ASM: don't use ldrd on user data
* SP int, fix when ECC specific size code included

### Port Fixes
* Fixes for STM32 PKA ECC (not 256-bit) and improvements for AES-GCM
* Fix for cryptocell signature verification with ECC
* Benchmark devid changes, CCM with SECO fix, set IV on AES import into SECO

### Compat. Layer Fixes
* Fix for handling DEFAULT:... cipher suite list
* Fix memory leak in wolfSSL_X509_NAME_ENTRY_get_object
* Set alt name type to V_ASN1_IA5STRING
* Update name hash functions wolfSSL_X509_subject_name_hash and wolfSSL_X509_issuer_name_hash to hash the canonical form of subject
* Fix wolfSSL_set_SSL_CTX() to be usable during handshake
* Fix X509_get1_ocsp to set num of elements in stack
* X509v3 EXT d2i: fix freeing of aia
* Fix to remove recreation of certificate with wolfSSL_PEM_write_bio_X509()
* Link newly created x509 store's certificate manager to self by default to assist with CRL verification
* Fix for compatibility `EC_KEY_new_by_curve_name` to not create a key if the curve is not found

### Misc.
* Free potential signer malloc in a fail case
* fix other name san parsing and add RID cert to test parsing
* WOLFSSL_OP_NO_TICKET fix for TLSv1.2
* fix ASN template parsing of X509 subject directory attribute
* Fix the wrong IV size with the cipher suite TLS_ECDHE_PSK_WITH_AES_128_GCM_SHA256
* Fix incorrect self signed error return when compiled with certreq and certgen.
* Fix wrong function name in debug comment with wolfSSL_X509_get_name_oneline()
* Fix for decryption after second handshake with async sniffer
* Allow session tickets to properly resume when using PQ KEMs
* Add sanity overflow check to DecodeAltNames input buffer access

# wolfSSL Release 5.5.3 (Nov 2, 2022)

Release 5.5.3 of wolfSSL embedded TLS has the following bug fix:

## Fixes

* Fix for possible buffer zeroization overrun introduced at the end of v5.5.2 release cycle in GitHub pull request 5743 (https://github.com/wolfSSL/wolfssl/pull/5743) and fixed in pull request 5757 (https://github.com/wolfSSL/wolfssl/pull/5757). In the case where a specific memory allocation failed or a hardware fault happened there was the potential for an overrun of 0’s when masking the buffer used for (D)TLS 1.2 and lower operations. (D)TLS 1.3 only and crypto only users are not affected by the issue. This is not related in any way to recent issues reported in OpenSSL.


# wolfSSL Release 5.5.2 (Oct 28, 2022)
Release 5.5.2 of wolfSSL embedded TLS has bug fixes and new features including:

## Vulnerabilities
* [Med] In the case that the WOLFSSL_CALLBACKS macro is set when building wolfSSL, there is a potential heap over read of 5 bytes when handling TLS 1.3 client connections. This heap over read is limited to wolfSSL builds explicitly setting the macro WOLFSSL_CALLBACKS, the feature does not get turned on by any other build options. The macro WOLFSSL_CALLBACKS is intended for debug use only, but if having it enabled in production, users are recommended to disable WOLFSSL_CALLBACKS. Users enabling WOLFSSL_CALLBACKS are recommended to update their version of wolfSSL. Thanks to Lucca Hirschi and Steve Kremer from LORIA, Inria and Max Ammann from Trail of Bits for finding and reporting the bug with the tlspuffin tool developed partly at LORIA and Trail of Bits. CVE 2022-42905

Release 5.5.2 of wolfSSL embedded TLS has bug fixes and new features including:

## New Feature Additions
* Add function wolfSSL_CTX_load_system_CA_certs to load system CA certs into a WOLFSSL_CTX and  --sys-ca-certs option to example client
* Add wolfSSL_set1_host to OpenSSL compatible API
* Added the function sk_X509_shift
* AES x86 ASM for AES-CBC and GCM performance enhancements
* Add assembly for AES for ARM32 without using crypto hardware instructions
* Xilinx Versal port and hardware acceleration tie in
* SP Cortex-M support for ICCARM

## Enhancements
* Add snifftest vcxproj file and documentation
* Nucleus Thread Types supported
* Handle certificates with RSA-PSS signature that have RSAk public keys
* Small stack build improvements
* DTLS 1.3 improvements for Alerts and unit tests
* Add a binary search for CRL
* Improvement of SSL/CTX_set_max_early_data() for client side
* Remove unused ASN1_GENERALIZEDTIME enum value from wolfssl/ssl.h
* Add user_settings.h for Intel/M1 FIPSv2 macOS C++ projects
* Add dtlscid.test to ‘make check’ unit testing
* Generate an assembler-safe user_settings.h in configure.ac and CMakeLists.txt
* ForceZero enabled with USE_FAST_MATH
* Add TLS 1.3 support of ticketNonce sizes bigger than MAX_TICKET_NONCE_SZ
* FIPSv2 builds on win10 adjust for new fastmath default in settings.h
* Add IRQ install for Aruix example

## Fixes
* When looking up the session by ID on the server, check that the protocol version of the SSL and session match on TLS 1.3 or not
* Fix for potential EVP_PKEY_DH memory leak with OPENSSL_EXTRA
* Curve448 32-bit C code: handle corner case
* Fixup builds using WOLFSSL_LOG_PRINTF
* Correct DIST_POINT_NAME type value
* Do not perform IV Wrap test when using cert3389 inlined armasm
* Fix for Linux kernel module and stdio.h
* (D)TLS: send alert on version mismatch
* Fix PKCS#7 SignedData verification when signer cert is not first in SET
* Fix bug with wolfIO_TcpConnect not working with timeout on Windows
* Fix output length bug in SP non-blocking ECC shared secret gen
* Fix build with enable-fastmath and disable-rsa
* Correct wolfSSL_sk_X509_new in OpenSSL compatible API
* Fixes for SP and x86_64 with MSVC
* Fix wrong size using DTLSv1.3 in RestartHandshakeHashWithCookie
* Fix redundant file include with TI RTOS build
* Fix wolfCrypt only build with wincrypt.h
* DTLS 1.2: Reset state when sending HelloVerifyRequest

# wolfSSL Release 5.5.1 (Sep 28, 2022)
Release 5.5.1 of wolfSSL embedded TLS has bug fixes and new features including:

## Vulnerabilities
* [Med] Denial of service attack and buffer overflow against TLS 1.3 servers using session ticket resumption. When built with --enable-session-ticket and making use of TLS 1.3 server code in wolfSSL, there is the possibility of a malicious client to craft a malformed second ClientHello packet that causes the server to crash. This issue is limited to when using both --enable-session-ticket and TLS 1.3 on the server side. Users with TLS 1.3 servers, and having --enable-session-ticket, should update to the latest version of wolfSSL. Thanks to Max at Trail of Bits for the report, found by Lucca Hirschi from LORIA, Inria, France with the tlspuffin tool developed partly at LORIA and Trail of Bits. CVE-2022-39173

## New Feature Additions
* Add support for non-blocking ECC key gen and shared secret gen for P-256/384/521
* Add support for non-blocking ECDHE/ECDSA in TLS/DTLS layer.
* Port to NXP RT685 with FreeRTOS
* Add option to build post quantum Kyber API (--enable-kyber)
* Add post quantum algorithm sphincs to wolfCrypt
* Config. option to force no asm with SP build (--enable-sp=noasm)
* Allow post quantum keyshare for DTLS 1.3

## Enhancements
* DTLSv1.3: Do HRR Cookie exchange by default
* Add wolfSSL_EVP_PKEY_new_CMAC_key to OpenSSL compatible API
* Update ide win10 build files to add missing sp source files
* Improve Workbench docs
* Improve EVP support for CHACHA20_POLY1305
* Improve `wc_SetCustomExtension` documentation
* RSA-PSS with OCSP and add simple OCSP response DER verify test case
* Clean up some FIPS versioning logic in configure.ac and WIN10 user_settings.h
* Don't over-allocate memory for DTLS fragments
* Add WOLFSSL_ATECC_TFLXTLS for Atmel port
* SHA-3 performance improvements with x86_64 assembly
* Add code to fallback to S/W if TSIP cannot handle
* Improves entropy with VxWorks
* Make time in milliseconds 64-bits for longer session ticket lives
* Support for setting cipher list with bytes
* wolfSSL_set1_curves_list(), wolfSSL_CTX_set1_curves_list() improvements
* Add to RSAES-OAEP key parsing for pkcs7
* Add missing DN nid to work with PrintName()
* SP int: default to 16 bit word size when NO_64BIT defined
* Limit the amount of fragments we store per a DTLS connection and error out when max limit is reached
* Detect when certificate's RSA public key size is too big and fail on loading of certificate

## Fixes
* Fix for async with OCSP non-blocking in `ProcessPeerCerts`
* Fixes for building with 32-bit and socket size sign/unsigned mismatch
* Fix Windows CMakeList compiler options
* TLS 1.3 Middle-Box compat: fix missing brace
* Configuration consistency fixes for RSA keys and way to force disable of private keys
* Fix for Aarch64 Mac M1 SP use
* Fix build errors and warnings for MSVC with DTLS 1.3
* Fix HMAC compat layer function for SHA-1
* Fix DTLS 1.3 do not negotiate ConnectionID in HelloRetryRequest
* Check return from call to wc_Time
* SP math: fix build configuration with opensslall
* Fix for async session tickets
* SP int mp_init_size fixes when SP_WORD_SIZE == 8
* Ed. function to make public key now checks for if the private key flag is set
* Fix HashRaw WC_SHA256_DIGEST_SIZE for wc_Sha256GetHash
* Fix for building with PSK only
* Set correct types in wolfSSL_sk_*_new functions
* Sanity check that size passed to mp_init_size() is no more than SP_INT_DIGITS


# wolfSSL Release 5.5.0 (Aug 30, 2022)

Note:
** If not free’ing FP_ECC caches per thread by calling wc_ecc_fp_free there is a possible memory leak during TLS 1.3 handshakes which use ECC. Users are urged to confirm they are free’ing FP_ECC caches per thread if enabled to avoid this issue.

Release 5.5.0 of wolfSSL embedded TLS has bug fixes and new features including:

## Vulnerabilities
* [Low] Fault injection attack on RAM via Rowhammer leads to ECDSA key disclosure. Users doing operations with private ECC keys such as server side TLS connections and creating ECC signatures, who also have hardware that could be targeted with a sophisticated Rowhammer attack should update the version of wolfSSL and compile using the macro WOLFSSL_CHECK_SIG_FAULTS. Thanks to Yarkin Doroz, Berk Sunar, Koksal Must, Caner Tol, and Kristi Rahman all affiliated with the Vernam Applied Cryptography and Cybersecurity Lab at Worcester Polytechnic Institute for the report.
* [Low] In wolfSSL version 5.3.0 if compiled with --enable-session-ticket and the client has non-empty session cache, with TLS 1.2 there is the possibility of a man in the middle passing a large session ticket to the client and causing a crash due to an invalid free. There is also the potential for a malicious TLS 1.3 server to crash a client in a similar manner except in TLS 1.3 it is not susceptible to a man in the middle attack. Users on the client side with –enable-session-ticket compiled in and using wolfSSL version 5.3.0 should update their version of wolfSSL. Thanks to Max at Trail of Bits for the report and "LORIA, INRIA, France" for research on tlspuffin.
* [Low] If using wolfSSL_clear to reset a WOLFSSL object (vs the normal wolfSSL_free/wolfSSL_new) it can result in runtime issues. This exists with builds using the wolfSSL compatibility layer (--enable-opnesslextra) and only when the application is making use of wolfSSL_clear instead of SSL_free/SSL_new. In the case of a TLS 1.3 resumption, after continuing to use the WOLFSSH object after having called wolfSSL_clear, an application could crash. It is suggested that users calling wolfSSL_clear update the version of wolfSSL used. Thanks to Max at Trail of Bits for the report and "LORIA, INRIA, France" for research on tlspuffin.
* Potential DoS attack on DTLS 1.2. In the case of receiving a malicious plaintext handshake message at epoch 0 the connection will enter an error state reporting a duplicate message. This affects both server and client side. Users that have DTLS enabled and in use should update their version of wolfSSL to mitigate the potential for a DoS attack.

## New Feature Additions
* QUIC support added, for using wolfSSL with QUIC implementations like ngtcp2
* SE050 port additions and fixes
* Added support for Dilithium post quantum algorithm use with TLS
* Support for RSA-PSS signed certificates
* Support for Infineon AURIX IDE
* Add Zephyr support for nRF5340 with CryptoCell-312

## Enhancements
* Expanded ABI support by 50 APIs to include wolfCrypt and Certificates making a total of 113 ABIs controlled and maintained
* DTLS 1.3 partial support for ConnectionID as described by RFC9146 and RFC9147
* Added support for X509_CRL_print function
* Remove deprecated algorithms in Renesas cs+ project
* Support more build options disable/enable with i.MX CAAM build
* wolfSSL_CTX_set_options and wolfSSL_CTX_get_options functions added to non compatibility layer builds
* TFM: change inline x86 asm code to compile with clang
* Improvements to error queue and fix for behavior of wolfSSL_ERR_get_error
* scripts/makedistsmall.sh script added for creating a small source/header only package
* TLS 1.3: restrict extension validity by message, Extensions ServerName, SupportedGroups and ALPN must not appear in server_hello
* Add liboqs integration to CMake build system
* Adds wolfSSL_PEM_read_RSAPrivateKey() to the OpenSSL compatible API
* Added support for P384 pre-share in bundled example server
* Replace clz assembly instruction in ARM 32 builds when not supported
* Integrate chacha20-poly1305 into the EVP interface
* Additional validation that extensions appear in correct messages
* Allow SAN to be critical with ASN template build
* Support wolfSSL_CTX_set1_curves_list being available when X25519 and/or X448 only defined
* Adds wolfSSL_PEM_read_RSA_PUBKEY() to the OpenSSL compatible API
* Match OpenSSL self signed error return with compatibility layer build
* Added wolfSSL_dtls_create_peer and wolfSSL_dtls_free_peer to help with Python and Go wrappers for DTLS

## Fixes
* DTLS 1.3 asynchronous use case fixes
* Fix handling of counter to support incrementing across all bytes in ARM crypto asm
* Fixes for ED25519/ED448 private key with public key export (RFC8410)
* Fix for build with NO_TLS macro
* Fix for write dup function to copy over TLS version
* Fix to handle path lengths of 0 when checking certificate CA path lengths
* Fix for CMake not installing sp_int.h for SP math all
* When WOLFSSL_VALIDATE_ECC_IMPORT is defined ECC import validates private key value is less than order
* PSA crypto fixes
* Fix for not having default pkcs7 signed attributes
* DTLS socket and timeout fixes
* SP int: exptmod ensure base is less than modulus
* Fix for AddPacketInfo with WOLFSSL_CALLBACKS to not pass encrypted TLS 1.3 handshake messages to callbacks
* Fix for sniffer to ensure the session was polled before trying to reprocess it

# wolfSSL Release 5.4.0 (July 11, 2022)

Note:
** Future releases of wolfSSL will turn off TLS 1.1 by default
** Release 5.4.0 made SP math the default math implementation. To make an equivalent build as –disable-fastmath from previous versions of wolfSSL, now requires using the configure option –enable-heapmath instead.

Release 5.4.0 of wolfSSL embedded TLS has bug fixes and new features including:

## Vulnerabilities
* [High]  Potential for DTLS DoS attack. In wolfSSL versions before 5.4.0 the return-routability check is wrongly skipped in a specific edge case. The check on the return-routability is there for stopping attacks that either consume excessive resources on the server, or try to use the server as an amplifier sending an excessive amount of messages to a victim IP. If using DTLS 1.0/1.2 on the server side users should update to avoid the potential DoS attack. CVE-2022-34293
* [Medium] Ciphertext side channel attack on ECC and DH operations. Users on systems where rogue agents can monitor memory use should update the version of wolfSSL and change private ECC keys. Thanks to Sen Deng from Southern University of Science and Technology (SUSTech) for the report.
* [Medium] Public disclosure of a side channel vulnerability that has been fixed since wolfSSL version 5.1.0. When running on AMD there is the potential to leak private key information with ECDSA operations due to a ciphertext side channel attack. Users on AMD doing ECDSA operations with wolfSSL versions less than 5.1.0 should update their wolfSSL version used. Thanks to professor Yinqian Zhang from Southern University of Science and Technology (SUSTech), his Ph.D. student Mengyuan Li from The Ohio State University, and his M.S students Sen Deng and Yining Tang from SUStech along with other collaborators; Luca Wilke, Jan Wichelmann and Professor Thomas Eisenbarth from the University of Lubeck, Professor Shuai Wang from Hong Kong University of Science and Technology, Professor Radu Teodorescu from The Ohio State University, Huibo Wang, Kang Li and Yueqiang Cheng from Baidu Security and Shoumeng Yang from Ant Financial Services Group.
CVE-2020-12966 https://www.amd.com/en/corporate/product-security/bulletin/amd-sb-1013 CVE-2021-46744 https://www.amd.com/en/corporate/product-security/bulletin/amd-sb-1033


## New Feature Additions

### DTLS 1.3
* Support for using the new DTLSv1.3 protocol was added
* Enhancements to bundled examples for an event driven server with DTLS 1.3 was added
### Ports
* Update for the version of VxWorks supported, adding in support for version 6.x
* Support for new DPP and EAP-TEAP/EAP-FAST in wpa_supplicant
* Update for TSIP version support, adding support for version 1.15 for RX65N and RX72N
* Improved TSIP build to handle having the options WOLFSSL_AEAD_ONLY defined or NO_AES_CBC defined
* Added support for offloading TLS1.3 operations to Renesas RX boards with TSIP
### Misc.
* Constant time improvements due to development of new constant time tests
* Initial translation of API headers to Japanese and expansion of Japanese help message support in example applications
* Add support for some FPKI (Federal PKI) certificate cases, UUID, FASC-N, PIV extension for use with smart cards
* Add support for parsing additional CSR attributes such as unstructured name and content type
* Add support for Linux getrandom() when defining the macro WOLFSSL_GETRANDOM
* Add TLS 1.2 ciphersuite ECDHE_PSK_WITH_AES_128_GCM_SHA256 from RFC 8442
* Expand CAAM support with QNX to include i.MX8 boards and add AES-CTR support
* Enhanced glitching protection by hardening the TLS encrypt operations

## Math and Performance

### SP Math Additions
* Support for ARMv3, ARMv6 and ARMv7a
    - Changes and improvements to get SP building for armv7-a
    - Updated assembly for moving large immediate values on ARMv6
    - Support for architectures with no ldrd/strd and clz
* Reworked generation using common asm ruby code for 32bit ARM
* Enable wolfSSL SP math all by default (sp_int.c)
* Update SP math all to not use sp_int_word when SQR_MUL_ASM is available
### SP Math Fixes
* Fixes for constant time with div function
* Fix casting warnings for Windows builds and assembly changes to support XMM6-15 being non-volatile
* Fix for div_word when not using div function
* Fixes for user settings with SP ASM and ED/Curve25519 small
* Additional Wycheproof tests ran and fixes
* Fix for SP math ECC non-blocking to always check `hashLen`
* Fix for SP math handling edge case with submod

## Improvements and Optimizations

### Compatibility Layer
* Provide access to "Finished" messages outside of compatibility layer builds
* Remove unneeded FIPS guard on wolfSSL_EVP_PKEY_derive
* Fix control command issues with AES-GCM, control command EVP_CTRL_GCM_IV_GEN
* Add support for importing private only EC key to a WOLFSSL_EVP_PKEY struct
* Add support for more extensions to wolfSSL_X509_print_ex
* Update for internal to DER (i2d) AIPs to move the buffer pointer when passed in and the operation is successful
* Return subject and issuer X509_NAME object even when not set
### Ports
* Renesas RA6M4 example update and fixes
* Support multi-threaded use cases with Renesas SCE protected mode and TSIP
* Add a global variable for heap-hint for use with TSIP
* Changes to support v5.3.0 cube pack for STM32
* Use the correct mutex type for embOS
* ESP-IDF build cleanup and enhancements, adding in note regarding ESP-IDF Version
* Support for SEGGER embOS and emNET
* Fix to handle WOLFSSL_DTLS macro in Micrium build
### Build Options
* Support for verify only and no-PSS builds updated
* Add the enable options wolfssh (mapped to the existing –enable-ssh)
* Remove WOLFSSL_ALT_NAMES restriction on notBefore/notAfter use in Cert struct
* Move several more definitions outside the BUILDING_WOLFSSL gate with linux kernel module build
* Modify --enable-openssh to not enable non-FIPS algos for FIPS builds
* Remove the Python wrappers from wolfSSL source (use pip install instead of using wolfSSL with Python and our separate Python repository)
* Add --enable-openldap option to configure.ac for building the OpenLDAP port
* Resolve DTLS build to handle not having –enable-hrrcookie when not needed
* Add an --enable-strongswan option to configure.ac for building the Strongswan port
* Improve defaults for 64-bit BSDs in configure
* Crypto only build can now be used openssl extra
* Update ASN template build to properly handle WOLFSSL_CERT_EXT and HAVE_OID_ENCODING
* Allow using 3DES and MD5 with FIPS 140-3, as they fall outside of the FIPS boundary
* Add the build option --enable-dh=const which replaces setting the macro WOLFSSL_DH_CONST and now conditionally link to -lm as needed
* Add the macro WOLFSSL_HOSTNAME_VERIFY_ALT_NAME_ONLY which is used to verify hostname/ip address using alternate name (SAN) only and does not use the common name
* WOLFSSL_DTLS_NO_HVR_ON_RESUME macro added (off by default to favor more security). If defined, a DTLS server will not do a cookie exchange on successful client resumption: the resumption will be faster (one RTT less) and will consume less bandwidth (one ClientHello and one HelloVerifyRequest less). On the other hand, if a valid SessionID is collected, forged clientHello messages will consume resources on the server.
* Misc.
* Refactoring of some internal TLS functions to reduce the memory usage
* Make old less secure TimingPadVerify implementation available
* Add support for aligned data with clang LLVM
* Remove subject/issuer email from the list of alt. Email names in the DecodedCerts struct
* Zeroizing of pre-master secret buffer in TLS 1.3
* Update to allow TLS 1.3 application server to send session ticket
* Improve the sniffer asynchronous test case to support multiple concurrent streams
* Clean up wolfSSL_clear() and add more logging
* Update to not error out on bad CRL next date if using NO_VERIFY when parsing
* Add an example C# PSK client
* Add ESP-IDF WOLFSSL_ESP8266 setting for ESP8266 devices
* Support longer sigalg list for post quantum use cases and inter-op with OQS's OpenSSL fork
* Improve AES-GCM word implementation of GMULT to be constant time
* Additional sanity check with Ed25519/Ed448, now defaults to assume public key is not trusted
* Support PSK ciphersuites in benchmark apps
* FIPS in core hash using SHA2-256 and SHA2-384
* Add ability to store issuer name components when parsing a certificate
* Make the critical extension flags in DecodedCert always available
* Updates to the default values for basic constraint with X509’s
* Support using RSA OAEP with no malloc and add additional sanity checks
* Leverage async code paths to support WANT_WRITE while sending packet fragments
* New azsphere example for continuous integration testing
* Update RSA key generation function to handle pairwise consistency tests with static memory pools used
* Resolve build time warning by passing in and checking output length with internal SetCurve function
* Support DTLS bidirectional shutdown in the examples
* Improve DTLS version negotiation and downgrade capability

### General Fixes
* Fixes for STM32 Hash/PKA, add some missing mutex frees, and add an additional benchmark
* Fix missing return checks in KSDK ED25519 code
* Fix compilation warnings from IAR
* Fixes for STM32U5/H7 hash/crypto support
* Fix for using track memory feature with FreeRTOS
* Fixup XSTR processing for MICRIUM
* Update Zephyr fs.h path
* DTLS fixes with WANT_WRITE simulations
* Fixes for BER use with PKCS7 to have additional sanity checks and guards on edge cases
* Fix to handle exceptional edge case with TFM mp_exptmod_ex
* Fix for stack and heap measurements of a 32-bit build
* Fix to allow enabling AES key wrap (direct) with KCAPI
* Fix --enable-openssh FIPS detection syntax in configure.ac
* Fix to move wolfSSL_ERR_clear_error outside gate for OPENSSL_EXTRA
* Remove MCAPI project's dependency on zlib version
* Only use __builtin_offset on supported GCC versions (4+)
* Fix for c89 builds with using WOLF_C89
* Fix 64bit postfix for constants building with powerpc
* Fixed async Sniffer with TLS v1.3, async removal of `WC_HW_WAIT_E` and sanitize leak
* Fix for QAT ECC to gate use of HW based on marker
* Fix the supported version extension to always check minDowngrade
* Fix for TLS v1.1 length sanity check for large messages
* Fixes for loading a long DER/ASN.1 certificate chain
* Fix to expose the RSA public DER export functions with certgen
* Fixes for building with small version of SHA3
* Fix configure with WOLFSSL_WPAS_SMALL
* Fix to free PKCS7 recipient list in error cases
* Sanity check to confirm ssl->hsHashes is not NULL before attempting to dereference it
* Clear the leftover byte count in Aes struct when setting IV

# wolfSSL Release 5.3.0 (May 3rd, 2022)

Release 5.3.0 of wolfSSL embedded TLS has bug fixes and new features including:

## New Feature Additions

### Ports
* Updated support for Stunnel to version 5.61
* Add i.MX8 NXP SECO use for secure private ECC keys and expand cryptodev-linux for use with the RSA/Curve25519 with the Linux CAAM driver
* Allow encrypt then mac with Apache port
* Update Renesas TSIP version to 1.15 on GR-ROSE and certificate signature data for TSIP / SCE example
* Add IAR MSP430 example, located in IDE/IAR-MSP430 directory
* Add support for FFMPEG with the enable option `--enable-ffmpeg`, FFMPEG is used for recording and converting video and audio (https://ffmpeg.org/)
* Update the bind port to version 9.18.0

### Post Quantum
* Add Post-quantum KEM benchmark for STM32
* Enable support for using post quantum algorithms with embedded STM32 boards and port to STM32U585

### Compatibility Layer Additions
* Add port to support libspdm (https://github.com/DMTF/libspdm/blob/main/README.md), compatibility functions added for the port were:
    - ASN1_TIME_compare
    - DH_new_by_nid
    - OBJ_length, OBJ_get0_data,
    - EVP layer ChaCha20-Poly1305, HKDF
    - EC_POINT_get_affine_coordinates
    - EC_POINT_set_affine_coordinates
* Additional functions added were:
    - EC_KEY_print_fp
    - EVP_PKEY_paramgen
    - EVP_PKEY_sign/verify functionality
    - PEM_write_RSAPublicKey
    - PEM_write_EC_PUBKEY
    - PKCS7_sign
    - PKCS7_final
    - SMIME_write_PKCS7
    - EC_KEY/DH_up_ref
    - EVP_DecodeBlock
    - EVP_EncodeBlock
    - EC_KEY_get_conv_form
    - BIO_eof
    - Add support for BIO_CTRL_SET and BIO_CTRL_GET
* Add compile time support for the type SSL_R_NULL_SSL_METHOD_PASSED
* Enhanced X509_NAME_print_ex() to support RFC5523 basic escape
* More checks on OPENSSL_VERSION_NUMBER for API prototype differences
* Add extended key usage support to wolfSSL_X509_set_ext
* SSL_VERIFY_FAIL_IF_NO_PEER_CERT now can also connect with compatibility layer enabled and a TLS 1.3 PSK connection is used
* Improve wolfSSL_BN_rand to handle non byte boundaries and top/bottom parameters
* Changed X509_V_ERR codes to better match OpenSSL values used
* Improve wolfSSL_i2d_X509_name to allow for a NULL input in order to get the expected resulting size
* Enhance the smallstack build to reduce stack size farther when built with compatibility layer enabled

### Misc.
* Sniffer asynchronous support addition, handling of DH shared secret and tested with Intel QuickAssist
* Added in support for OCSP with IPv6
* Enhance SP (single precision) optimizations for use with the ECC P521
* Add new public API wc_CheckCertSigPubKey() for use to easily check the signature of a certificate given a public key buffer
* Add CSR (Certificate Signing Request) userId support in subject name
* Injection and parsing of custom extensions in X.509 certificates
* Add WOLF_CRYPTO_CB_ONLY_RSA and WOLF_CRYPTO_CB_ONLY_ECC to reduce code size if using only crypto callback functions with RSA and ECC
* Created new --enable-engine configure flag used to build wolfSSL for use with wolfEngine
* With TLS 1.3 PSK, when WOLFSSL_PSK_MULTI_ID_PER_CS is defined multiple IDs for a cipher suite can be handled
* Added private key id/label support with improving the PK (Public Key) callbacks
* Support for Intel QuickAssist ECC KeyGen acceleration
* Add the function wolfSSL_CTX_SetCertCbCtx to set user context for certificate call back
* Add the functions wolfSSL_CTX_SetEccSignCtx(WOLFSSL_CTX* ctx, void *userCtx) and wolfSSL_CTX_GetEccSignCtx(WOLFSSL_CTX* ctx) for setting and getting a user context
* wolfRand for AMD --enable-amdrand

## Fixes
### PORT Fixes
* KCAPI memory optimizations and page alignment fixes for ECC, AES mode fixes and reduction to memory usage
* Add the new kdf.c file to the TI-RTOS build
* Fix wait-until-done in RSA hardware primitive acceleration of ESP-IDF port
* IOTSafe workarounds when reading files with ending 0’s and for ECC signatures

### Math Library Fixes
* Sanity check with SP math that ECC points ordinates are not greater than modulus length
* Additional sanity checks that _sp_add_d does not error due to overflow
* Wycheproof fixes, testing integration, and fixes for AVX / AArch64 ASM edge case tests
* TFM fp_div_2_ct rework to avoid potential overflow

### Misc.
* Fix for PKCS#7 with Crypto Callbacks
* Fix for larger curve sizes with deterministic ECC sign
* Fixes for building wolfSSL alongside openssl using --enable-opensslcoexist
* Fix for compatibility layer handling of certificates with SHA256 SKID (Subject Key ID)
* Fix for wolfSSL_ASN1_TIME_diff erroring out on a return value of 0 from mktime
* Remove extra padding when AES-CBC encrypted with PemToDer
* Fixes for TLS v1.3 early data with async.
* Fixes for async disables around the DevCopy calls
* Fixes for Windows AES-NI with clang compiler
* Fix for handling the detection of processing a plaintext TLS alert packet
* Fix for potential memory leak in an error case with TLSX supported groups
* Sanity check on `input` size in `DecodeNsCertType`
* AES-GCM stack alignment fixes with assembly code written for AVX/AVX2
* Fix for PK callbacks with server side and setting a public key

## Improvements/Optimizations
### Build Options and Warnings
* Added example user settings template for FIPS v5 ready
* Automake file touch cleanup for use with Yocto devtool
* Allow disabling forced 'make clean' at the end of ./configure by using --disable-makeclean
* Enable TLS 1.3 early data when specifying `--enable-all` option
* Disable PK Callbacks with JNI FIPS builds
* Add a FIPS cert 3389 ready option, this is the fips-ready build
* Support (no)inline with Wind River Diab compiler
* ECDH_compute_key allow setting of globalRNG with FIPS 140-3
* Add logic equivalent to configure.ac in settings.h for Poly1305
* Fixes to support building opensslextra with SP math
* CPP protection for extern references to x86_64 asm code
* Updates and enhancements for Espressif ESP-IDF wolfSSL setup_win.bat
* Documentation improvements with auto generation
* Fix reproducible-build for working an updated version of libtool, version 2.4.7
* Fixes for Diab C89 and armclang
* Fix `mcapi_test.c` to include the settings.h before crypto.h
* Update and handle builds with NO_WOLFSSL_SERVER and NO_WOLFSSL_CLIENT
* Fix for some macro defines with FIPS 140-3 build so that RSA_PKCS1_PSS_PADDING can be used with RSA sign/verify functions

### Math Libraries
* Add RSA/DH check for even modulus
* Enhance TFM math to handle more alloc failure cases gracefully
* SP ASM performance improvements mostly around AArch64
* SP ASM improvements for additional cache attack resistance
* Add RSA check for small difference between p and q
* 6-8% performance increase with ECC operations using SP int by improving the Montgomery Reduction

### Testing and Validation
* All shell scripts in source tree now tested for correctness using shellcheck and bash -n
* Added build testing under gcc-12 and -std=c++17 and fixed warnings
* TLS 1.3 script test improvement to wait for server to write file
* Unit tests for ECC r/s zeroness handling
* CI server was expanded with a very “quiet” machine that can support multiple ContantTime tests ensuring ongoing mitigation against side-channel timing based attacks. Algorithms being assessed on this machine are: AES-CBC, AES-GCM, CHACHA20, ECC, POLY1305, RSA, SHA256, SHA512, CURVE25519.
* Added new multi configuration windows builds to CI testing for greater testing coverage of windows use-cases

### Misc.
* Support for ECC import to check validity of key on import even if one of the coordinates (x or y) is 0
* Modify example app to work with FreeRTOS+IoT
* Ease of access for cert used for verifying a PKCS#7 bundle
* Clean up Visual Studio output and intermediate directories
* With TLS 1.3 fail immediately if a server sends empty certificate message
* Enhance the benchmark application to support multi-threaded testing
* Improvement for `wc_EccPublicKeyToDer` to not overestimate the buffer size required
* Fix to check if `wc_EccPublicKeyToDer` has enough output buffer space
* Fix year 2038 problem in wolfSSL_ASN1_TIME_diff
* Various portability improvements (Time, DTLS epoch size, IV alloc)
* Prefer status_request_v2 over status_request when both are present
* Add separate "struct stat" definition XSTATSTRUCT to make overriding XSTAT easier for portability
* With SipHash replace gcc specific ASM instruction with generic
* Don't force a ECC CA when a custom CA is passed with `-A`
* Add peer authentication failsafe for TLS 1.2 and below
* Improve parsing of UID from subject and issuer name with the compatibility layer by
* Fallback to full TLS handshake if session ticket fails
* Internal refactoring of code to reduce ssl.c file size

# wolfSSL Release 5.2.0 (Feb 21, 2022)

## Vulnerabilities

* \[High\] A TLS v1.3 server who requires mutual authentication can be
  bypassed. If a malicious client does not send the certificate_verify
  message a client can connect without presenting a certificate even
  if the server requires one. Thank you to Aina Toky Rasoamanana and
  Olivier Levillain of Télécom SudParis.
* \[High\] A TLS v1.3 client attempting to authenticate a TLS v1.3
  server can have its certificate check bypassed. If the sig_algo in
  the certificate_verify message is different than the certificate
  message checking may be bypassed. Thank you to Aina Toky Rasoamanana and
  Olivier Levillain of Télécom SudParis.

## New Feature Additions

* Example applications for Renesas RX72N with FreeRTOS+IoT
* Renesas FSP 3.5.0 support for RA6M3
* For TLS 1.3, improved checks on order of received messages.
* Support for use of SHA-3 cryptography instructions available in
  ARMv8.2-A architecture extensions. (For Apple M1)
* Support for use of SHA-512 cryptography instructions available in
  ARMv8.2-A architecture extensions.  (For Apple M1)
* Fixes for clang -Os on clang >= 12.0.0
* Expose Sequence Numbers so that Linux TLS (kTLS) can be configured
* Fix bug in TLSX_ALPN_ParseAndSet when using ALPN select callback.
* Allow DES3 with FIPS v5-dev.
* Include HMAC for deterministic ECC sign build
* Add --enable-chrony configure option. This sets build options needed
  to build the Chrony NTP (Network Time Protocol) service.
* Add support for STM32U575xx boards.
* Fixes for NXP’s SE050 Ed25519/Curve25519.
* TLS: Secure renegotiation info on by default for compatibility.
* Inline C code version of ARM32 assembly for cryptographic algorithms
  available and compiling for improved performance on ARM platforms
* Configure HMAC: define NO_HMAC to disable HMAC (default: enabled)
* ISO-TP transport layer support added to wolfio for TLS over CAN Bus
* Fix initialization bug in SiLabs AES support
* Domain and IP check is only performed on leaf certificates

## ARM PSA Support (Platform Security Architecture) API

* Initial support added for ARM’s Platform Security Architecture (PSA)
  API in wolfCrypt which allows support of ARM PSA enabled devices by
  wolfSSL, wolfSSH, and wolfBoot and wolfCrypt FIPS.
* Included algorithms: ECDSA, ECDH, HKDF, AES, SHA1, SHA256, SHA224, RNG

## ECICE Updates

* Support for more encryption algorithms: AES-256-CBC, AES-128-CTR,
  AES-256-CTR
* Support for compressed public keys in messages.

## Math Improvements

* Improved performance of X448 and Ed448 through inlining Karatsuba in
  square and multiplication operations for 128-bit implementation
  (64-bit platforms with 128-bit type support).
* SP Math C implementation: fix for corner case in curve specific
  implementations of Montgomery Reduction (P-256, P-384).
* SP math all: assembly snippets added for ARM Thumb. Performance
  improvement on platform.
* SP math all: ARM64/32 sp_div_word assembly snippets added to remove
  dependency on __udiv3.
* SP C implementation: multiplication of two signed types with overflow
  is undefined in C. Now cast to unsigned type before multiplication is
  performed.
* SP C implementation correctly builds when using CFLAG: -m32

## OpenSSL Compatibility Layer

* Added DH_get_2048_256 to compatibility layer.
* wolfSSLeay_version now returns the version of wolfSSL
* Added C++ exports for API’s in wolfssl/openssl/crypto.h. This allows
  better compatibility when building with a C++ compiler.
* Fix for OpenSSL x509_NAME_hash mismatch
* Implement FIPS_mode and FIPS_mode_set in the compat layer.
* Fix for certreq and certgen options with openssl compatibility
* wolfSSL_BIO_dump() and wolfSSL_OBJ_obj2txt() rework
* Fix IV length bug in EVP AES-GCM code.
* Add new ASN1_INTEGER compatibility functions.
* Fix wolfSSL_PEM_X509_INFO_read with NO_FILESYSTEM

## CMake Updates

* Check for valid override values.
* Add `KEYGEN` option.
* Cleanup help messages.
* Add options to support wolfTPM.

## VisualStudio Updates

* Remove deprecated VS solution
* Fix VS unreachable code warning

## New Algorithms and Protocols

* AES-SIV (RFC 5297)
* DTLS SRTP (RFC 5764), used with WebRTC to agree on profile for new
  real-time session keys
* SipHash MAC/PRF for hash tables. Includes inline assembly for
  x86_64 and Aarch64.

## Remove Obsolete Algorithms

* IDEA
* Rabbit
* HC-128


# wolfSSL Release 5.1.1 (Jan 3rd, 2022)
Release 5.1.1 of wolfSSL embedded TLS has a high vulnerability fix:

### Vulnerabilities
* \[High\]  In connections using AES-CBC or DES3 with TLS/DTLS 1.2 or 1.1 the IV being used is not random. Users using wolfSSL version 5.0.0 or 5.1.0 doing TLS/DTLS 1.2 or 1.1 connections, without AEAD only, should update the version of wolfSSL used. (CVE-2022-23408)

# wolfSSL Release 5.1.0 (Dec 27, 2021)
Release 5.1.0 of wolfSSL embedded TLS has bug fixes and new features including:

### Vulnerabilities
* \[Low\]  Potential for DoS attack on a wolfSSL client due to processing hello packets of the incorrect side. This affects only connections using TLS v1.2 or less that have also been compromised by a man in the middle attack. Thanks to James Henderson, Mathy Vanhoef, Chris M. Stone, Sam L. Thomas, Nicolas Bailleut, and Tom Chothia (University of Birmingham, KU Leuven, ENS Rennes for the report.
* \[Low\] Client side session resumption issue once the session resumption cache has been filled up. The hijacking of a session resumption has been demonstrated so far with only non verified peer connections. That is where the client is not verifying the server’s CA that it is connecting to. There is the potential though for other cases involving proxies that are verifying the server to be at risk, if using wolfSSL in a case involving proxies use wolfSSL_get1_session and then wolfSSL_SESSION_free when done where possible. If not adding in the session get/free function calls we recommend that users of wolfSSL that are resuming sessions update to the latest version (wolfSSL version 5.1.0 or later). Thanks to the UK's National Cyber Security Centre (NCSC) for the report.

### New Feature Additions
###### Ports
* Curve25519 support with NXP SE050 added
* Renesas RA6M4 support with SCE Protected Mode and FSP 3.5.0
* Renesas TSIP 1.14 support for RX65N/RX72N

###### Post Quantum
* Post quantum resistant algorithms used with Apache port
* NIST round 3 FALCON Signature Scheme support added to TLS 1.3 connections
* FALCON added to the benchmarking application
* Testing of cURL with wolfSSL post quantum resistant build

###### Compatibility Layer Additions
* Updated NGINX port to NGINX version 1.21.4
* Updated Apache port to Apache version 2.4.51
* Add support for SSL_OP_NO_TLSv1_2 flag with wolfSSL_CTX_set_options function
* Support added for the functions
    - SSL_CTX_get_max_early_data
    - SSL_CTX_set_max_early_data
    - SSL_set_max_early_data
    - SSL_get_max_early_data
    - SSL_CTX_clear_mode
    - SSL_CONF_cmd_value_type
    - SSL_read_early_data
    - SSL_write_early_data

###### Misc.
* Crypto callback support for AES-CCM added. A callback function can be registered and used instead of the default AES-CCM implementation in wolfSSL.
* Added AES-OFB to the FIPS boundary for future FIPS validations.
* Add support for custom OIDs used with CSR (certificate signing request) generation using the macro WOLFSSL_CUSTOM_OID
* Added HKDF extract callback function for use with TLS 1.3
* Add variant from RFC6979 of deterministic ECC signing that can be enabled using the macro WOLFSSL_ECDSA_DETERMINISTIC_K_VARIANT
* Added the function wc_GetPubKeyDerFromCert to get the public key from a DecodedCert structure
* Added the functions wc_InitDecodedCert, wc_ParseCert and wc_FreeDecodedCert for access to decoding a certificate into a DecodedCert structure
* Added the macro WOLFSSL_ECC_NO_SMALL_STACK for hybrid builds where the numerous malloc/free with ECC is undesired but small stack use is desired throughout the rest of the library
* Added the function wc_d2i_PKCS12_fp for reading a PKCS12 file and parsing it

### Fixes
###### PORT Fixes
* Building with Android wpa_supplicant and KeyStore
* Setting initial value of CA certificate with TSIP enabled
* Cryptocell ECC build fix and fix with RSA disabled
* IoT-SAFE improvement for Key/File slot ID size, fix for C++ compile, and fixes for retrieving the public key after key generation

###### Math Library Fixes
* Check return values on TFM library montgomery function in case the system runs out of memory. This resolves an edge case of invalid ECC signatures being created.
* SP math library sanity check on size of values passed to sp_gcd.
* SP math library sanity check on exponentiation by 0 with mod_exp
* Update base ECC mp_sqrtmod_prime function to handle an edge case of zero
* TFM math library with Intel MULX multiply fix for carry in assembly code

###### Misc.
* Fix for potential heap buffer overflow with compatibility layer PEM parsing
* Fix for edge memory leak case with an error encountered during TLS resumption
* Fix for length on inner sequence created with wc_DhKeyToDer when handling small DH keys
* Fix for sanity check on input argument to DSA sign and verify
* Fix for setting of the return value with ASN1 integer get on an i386 device
* Fix for BER to DER size checks with PKCS7 decryption
* Fix for memory leak with PrintPubKeyEC function in compatibility layer
* Edge case with deterministic ECC key generation when the private key has leading 0’s
* Fix for build with OPENSSL_EXTRA and NO_WOLFSSL_STUB both defined
* Use page aligned memory with ECDSA signing and KCAPI
* Skip expired sessions for TLS 1.3 rather than turning off the resume behavior
* Fix for DTLS handling dropped or retransmitted messages

### Improvements/Optimizations
###### Build Options and Warnings
* Bugfix: could not build with liboqs and without DH enabled
* Build with macro NO_ECC_KEY_EXPORT fixed
* Fix for building with the macro HAVE_ENCRYPT_THEN_MAC when session export is enabled
* Building with wolfSentry and HAVE_EX_DATA macro set

###### Math Libraries
* Improvement for performance with SP C implementation of montgomery reduction for ECC (P256 and P384) and SP ARM64 implementation for ECC (P384)
* With SP math handle case of dividing by length of dividend
* SP math improvement for lo/hi register names to be used with older GCC compilers

###### Misc.
* ASN name constraints checking code refactor for better efficiency and readability
* Refactor of compatibility layer stack free’ing calls to simplify and reduce code
* Scrubbed code for trailing spaces, hard tabs, and any control characters
* Explicit check that leaf certificate's public key type match cipher suite signature algorithm
* Additional NULL sanity checks on WOLFSSL struct internally and improve switch statement fallthrough
* Retain OCSP error value when CRL is enabled with certificate parsing
* Update to NATIVE LwIP support for TCP use
* Sanity check on PEM size when parsing a PEM with OpenSSL compatibility layer API.
* SWIG wrapper was removed from the codebase in favor of dedicated Java and Python wrappers.
* Updates to bundled example client for when to load the CA, handling print out of IP alt names, and printing out the peers certificate in PEM format
* Handling BER encoded inner content type with PKCS7 verify
* Checking for SOCKET_EPIPE errors from low level socket
* Improvements to cleanup in the case that wolfSSL_Init fails
* Update test and example certificates expiration dates


# wolfSSL Release 5.0.0 (Nov 01, 2021)
Release 5.0.0 of wolfSSL embedded TLS has bug fixes and new features including:

### Vulnerabilities
* [\Low\] Hang with DSA signature creation when a specific q value is used in a maliciously crafted key. If a DSA key with an invalid q value of either 1 or 0 was decoded and used for creating a signature, it would result in a hang in wolfSSL. Users that are creating signatures with DSA and are using keys supplied from an outside source are affected.
* [\Low\] Issue with incorrectly validating a certificate that has multiple subject alternative names when given a name constraint. In the case where more than one subject alternative name is used in the certificate, previous versions of wolfSSL could incorrectly validate the certificate. Users verifying certificates with multiple alternative names and name constraints, are recommended to either use the certificate verify callback to check for this case or update the version of wolfSSL used. Thanks to Luiz Angelo Daros de Luca for the report.

### New Feature Additions
###### New Product
* FIPS 140-3 -- currently undergoing laboratory testing, code review and ultimately CMVP validation. Targeting the latest FIPS standard.

###### Ports
* IoT-Safe with TLS demo
* SE050 port with support for RNG, SHA, AES, ECC (sign/verify/shared secret) and ED25519
* Support for Renesas TSIP v1.13 on RX72N

###### Post Quantum
* Support for OQS's (liboqs version 0.7.0) implementation of NIST Round 3 KEMs as TLS 1.3 groups --with-liboqs
* Hybridizing NIST ECC groups with the OQS groups
* Remove legacy NTRU and QSH
* Make quantum-safe groups available to the compatibility layer

###### Linux Kernel Module
* Full support for FIPS 140-3, with in-kernel power on self test (POST) and conditional algorithm self test(s) (CAST)
* --enable-linuxkm-pie -- position-independent in-kernel wolfCrypt container, for FIPS
* Vectorized x86 acceleration in PK algs (RSA, ECC, DH, DSA) and AES/AES-GCM
* Vectorized x86 acceleration in interrupt handlers
* Support for Linux-native module signatures
* Complete SSL/TLS and Crypto API callable from other kernel module(s)
* Support for LTS kernel lines: 3.16, 4.4, 4.9, 5.4, 5.10

###### Compatibility Layer Additions
* Ports
    - Add support for libssh2
    - Add support for pyOpenSSL
    - Add support for libimobiledevice
    - Add support for rsyslog
    - Add support for OpenSSH 8.5p1
    - Add support for Python 3.8.5
* API/Structs Added
    - ERR_lib_error_string
    - EVP_blake2
    - wolfSSL_set_client_CA_list
    - wolfSSL_EVP_sha512_224
    - wolfSSL_EVP_sha512_256
    - wc_Sha512_224/2256Hash
    - wc_Sha512_224/256Hash
    - wc_InitSha512_224/256
    - wc_InitSha512_224/256_ex
    - wc_Sha512_224/256Update
    - wc_Sha512_224/256FinalRaw
    - wc_Sha512_224/256Final
    - wc_Sha512_224/256Free
    - wc_Sha512_224/256GetHash
    - wc_Sha512_224/256Copy
    - wc_Sha512_224/256SetFlags
    - wc_Sha512_224/256GetFlags
    - wc_Sha512_224/256Transform
    - EVP_MD_do_all and OBJ_NAME_do_all
    - EVP_shake128
    - EVP_shake256
    - SSL_CTX_set_num_tickets
    - SSL_CTX_get_num_tickets
    - SSL_CIPHER_get_auth_nid
    - SSL_CIPHER_get_cipher_nid
    - SSL_CIPHER_get_digest_nid
    - SSL_CIPHER_get_kx_nid
    - SSL_CIPHER_is_aead
    - SSL_CTX_set_msg_callback
    - a2i_IPADDRESS
    - GENERAL_NAME_print
    - X509_VERIFY_PARAM_set1_ip
    - EVP_CIPHER_CTX_set_iv_length
    - PEM_read_bio_RSA_PUBKEY
    - i2t_ASN1_OBJECT
    - DH_set_length
    - Set_tlsext_max_fragment_length
    - AUTHORITY_iNFO_ACCESS_free
    - EVP_PBE_scrypt
    - ASN1_R_HEADER_TOO_LONG
    - ERR_LIB
    - X509_get_default_cert_file/file_env/dir/dir_env() stubs
    - SSL_get_read_ahead/SSL_set_read_ahead()
    - SSL_SESSION_has_ticket()
    - SSL_SESSION_get_ticket_lifetime_hint()
    - DIST_POINT_new
    - DIST_POINT_free
    - DIST_POINTS_free
    - CRL_DIST_POINTS_free
    - sk_DIST_POINT_push
    - sk_DIST_POINT_value
    - sk_DIST_POINT_num
    - sk_DIST_POINT_pop_free
    - sk_DIST_POINT_free
    - X509_get_extension_flags
    - X509_get_key_usage
    - X509_get_extended_key_usage
    - ASN1_TIME_to_tm
    - ASN1_TIME_diff
    - PEM_read_X509_REQ
    - ERR_load_ERR_strings
    - BIO_ssl_shutdown
    - BIO_get_ssl
    - BIO_new_ssl_connect
    - BIO_set_conn_hostname
    - NID_pkcs9_contentType

###### Misc.
* KCAPI: add support for using libkcapi for crypto (Linux Kernel)
* Configure option for --with-max-rsa-bits= and --with-max-ecc-bits=
* SP ARM Thumb support for Keil and performance improvements
* Add support for WOLFSSL_VERIFY_POST_HANDSHAKE verify mode
* PKCS #11: support static linking with PKCS #11 library --enable-pkcs11=static LIBS=-l
* Add build option --enable-wolfclu for use with wolfCLU product
* Add support for X9.42 header i.e “BEGIN X9.42 DH PARAMETERS”
* Add --enable-altcertchains for configuring wolfSSL with alternate certificate chains feature enabled
* Add public API wc_RsaKeyToPublicDer_ex to allow getting RSA public key without ASN.1 header (can return only seq + n + e)
* Add SNI and TLSx options to CMake build

### Fixes
###### PORT Fixes
* Add return value checking for FREESCALE_RNGA
* Fix MMCAU_SHA256 type warnings
* Fixes for building with Microchip XC32 and ATECC

###### Math Library Fixes
* TFM check that the modulus length is valid for fixed data array size
* TFM fp_submod_ct fix check for greater
* Check return value of mp_grow in mp_mod_2d
* Fix for ECC point multiply to error out on large multipliers
* SP ECC error on multiplier larger than curve order

###### TLS 1.3
* TLS1.3 sanity check for cases where a private key is larger than the configured maximum
* Fix early data max size handling in TLS v1.3
* Fixes for PK callbacks with TLS v1.3
* Check min downgrade when no extensions are sent with the ServerHello

###### Misc.
* Previously wolfSSL enum values were used as NID’s. Now only the compatibility layer NID enums are the NID values:
    - CTC_SHAwDSA -> NID_dsaWithSHA1
    - CTC_SHA256wDSA -> NID_dsa_with_SHA256
    - CTC_MD2wRSA -> NID_md2WithRSAEncryption
    - CTC_MD5wRSA -> NID_md5WithRSAEncryption
    - CTC_SHAwRSA -> NID_sha1WithRSAEncryption
    - CTC_SHA224wRSA -> NID_sha224WithRSAEncryption
    - CTC_SHA256wRSA -> NID_sha256WithRSAEncryption
    - CTC_SHA384wRSA -> NID_sha384WithRSAEncryption
    - CTC_SHA512wRSA -> NID_sha512WithRSAEncryption
    - CTC_SHA3_224wRSA -> NID_RSA_SHA3_224
    - CTC_SHA3_256wRSA -> NID_RSA_SHA3_256
    - CTC_SHA3_384wRSA -> NID_RSA_SHA3_384
    - CTC_SHA3_512wRSA -> NID_RSA_SHA3_512
    - CTC_SHAwECDSA -> NID_ecdsa_with_SHA1
    - CTC_SHA224wECDSA -> NID_ecdsa_with_SHA224
    - CTC_SHA256wECDSA -> NID_ecdsa_with_SHA256
    - CTC_SHA384wECDSA -> NID_ecdsa_with_SHA384
    - CTC_SHA512wECDSA -> NID_ecdsa_with_SHA512
    - CTC_SHA3_224wECDSA -> NID_ecdsa_with_SHA3_224
    - CTC_SHA3_256wECDSA -> NID_ecdsa_with_SHA3_256
    - CTC_SHA3_384wECDSA -> NID_ecdsa_with_SHA3_384
    - CTC_SHA3_512wECDSA -> NID_ecdsa_with_SHA3_512
    - DSAk -> NID_dsa
    - RSAk -> NID_rsaEncryption
    - ECDSAk -> NID_X9_62_id_ecPublicKey
    - BASIC_CA_OID -> NID_basic_constraints
    - ALT_NAMES_OID -> NID_subject_alt_name
    - CRL_DIST_OID -> NID_crl_distribution_points
    - AUTH_INFO_OID -> NID_info_access
    - AUTH_KEY_OID -> NID_authority_key_identifier
    - SUBJ_KEY_OID -> NID_subject_key_identifier
    - INHIBIT_ANY_OID -> NID_inhibit_any_policy
* Fix for DES IV size used with FIPSv2
* Fix signed comparison issue with serialSz
* Fix missing CBIOSend and properly guard hmac in DupSSL()
* Fix calculation of length of encoding in ssl.c
* Fix encoding to check proper length in asn.c
* Fix for wc_ecc_ctx_free and heap hint
* Fix for debug messages with AF_ALG build
* Fix for static memory with bucket size matching.
* Fixes for SRP with heap hint.
* Fixes for CAAM build macros and spelling for Keil build
* Sniffer fix for possible math issue around 64-bit pointer and 32-bit unsigned int
* Fix for sniffer TCP sequence rollover
* wolfSSL_PEM_write_bio_PUBKEY to write only the public part
* Fix for sending only supported groups in TLS extension
* Fix for sniffer to better handle spurious retransmission edge case
* SSL_set_alpn_protos and SSL_CTX_set_alpn_protos now returns 0 on successFixes issue with SSL_CTX_set1_curves_list and SSL_set1_curves_list not checking the last character of the names variable provided, non-0 on failure to better match expected return values
* Fixes and improvements for crypto callbacks with TLS (mutual auth)
* Fix for bad memory_mutex lock on static memory cleanup
* Zero terminate name constraints strings when parsing certificates
* Fix for verifying a certificate when multiple permitted name constraints are used
* Fix typo in ifdef for HAVE_ED448
* Fix typos in comments in SHA512
* Add sanity check on buffer size with ED25519 key decode
* Sanity check on PKCS7 stream amount read
* PKCS7 fix for double free on error case and sanity check on set serial number
* Sanity check on PKCS7 input size wc_PKCS7_ParseSignerInfo
* Forgive a DTLS session trying to send too much at once

### Improvements/Optimizations
###### Build Options and Warnings
* Rework of RC4 disable by default and depreciation
* wolfSSL as a Zephyr module (without setup.sh)
* Add include config.h to bio.c
* Support for PKCS7 without AES CBC.
* Fixes for building without AES CBC
* Added WOLFSSL_DH_EXTRA to --enable-all and --enable-sniffer
* Add a CMake option to build wolfcrypt test and bench code as libraries
* GCC makefile: allow overriding and provide more flexibility

###### Math Libraries
* Improve performance of fp_submod_ct() and fp_addmod_ct()
* Improve performance of sp_submod_ct() and sp_addmod_ct()
* SP int, handle even modulus with exponentiation

###### Misc.
* Cleanups for Arduino examples and memory documentation
* Refactor hex char to byte conversions
* Added GCC-ARM TLS server example
* Improvements to session locking to allow per-row
* Improved sniffer statistics and documentation
* EVP key support for heap hint and crypto callbacks
* Reduced stack size for dh_generation_test and Curve ASN functions
* Espressif README Syntax / keyword highlighting / clarifications
* AARCH64 SHA512: implementation using crypto instructions added
* wc_RsaPSS_CheckPadding_ex2 added for use with HEAP hint
* wc_AesKeyWrap_ex and wc_AesKeyUnWrap_ex bound checks on input and output sizes
* Add additional error handling to wolfSSL_BIO_get_len
* Add code to use popen and the command 'host', useful with qemu
* Adjustment to subject alt names order with compatibility layer to better match expected order
* Reduce BIO compatibility layer verbosity
* Set a default upper bound on error queue size with compatibility layer
* WOLFSSL_CRL_ALLOW_MISSING_CDP macro for Skip CRL verification in case no CDP in peer cert
* Fixes for scan-build LLVM-13 and expanded coverage
* Increase the default DTLS_MTU_ADDITIONAL_READ_BUFFER and make it adjustable

# wolfSSL Release 4.8.1 (July 16, 2021)
Release 4.8.1 of wolfSSL embedded TLS has an OCSP vulnerability fix:

### Vulnerabilities
* [High] OCSP verification issue when response is for a certificate with no relation to the chain in question BUT that response contains the NoCheck extension which effectively disables ALL verification of that one cert. Users who should upgrade to 4.8.1 are TLS client users doing OCSP, TLS server users doing mutual auth with OCSP, and CertManager users doing OCSP independent of TLS. Thanks to Jan Nauber, Marco Smeets, Werner Rueschenbaum and Alissa Kim of Volkswagen Infotainment for the report.


# wolfSSL Release 4.8.0 (July 09, 2021)
Release 4.8.0 of wolfSSL embedded TLS has bug fixes and new features including:

### Vulnerabilities
* [Low] CVE-2021-37155: OCSP request/response verification issue. In the case that the serial number in the OCSP request differs from the serial number in the OCSP response the error from the comparison was not resulting in a failed verification. We recommend users that have wolfSSL version 4.6.0 and 4.7.0 with OCSP enabled update their version of wolfSSL. Version 4.5.0 and earlier are not affected by this report. Thanks to Rainer Mueller-Amersdorffer, Roee Yankelevsky, Barak Gutman, Hila Cohen and Shoshi Berko (from CYMOTIVE Technologies and CARIAD) for the report.
* [Low] CVE-2021-24116: Side-Channel cache look up vulnerability in base64 PEM decoding for versions of wolfSSL 4.5.0 and earlier. Versions 4.6.0 and up contain a fix and do not need to be updated for this report. If decoding a PEM format private key using version 4.5.0 and older of wolfSSL then we recommend updating the version of wolfSSL used. Thanks to Florian Sieck, Jan Wichelmann, Sebastian Berndt and Thomas Eisenbarth for the report.

### New Feature Additions
###### New Product
* Added wolfSentry build with --enable-wolfsentry and tie-ins to wolfSSL code for use with wolfSentry

###### Ports
* QNX CAAM driver added, supporting ECC black keys, CMAC, BLOBs, and TRNG use
*  _WIN32_WCE wolfCrypt port added
* INTIME_RTOS directory support added
* Added support for STM32G0
* Renesas RX: Added intrinsics for rot[rl], revl (thanks @rliebscher)
* Added support for running wolfcrypt/test/testwolfcrypt on Dolphin emulator to test DEVKITPRO port
* Zephyr project port updated to latest version 2.6.X

###### ASN1 and PKCS
* Storing policy constraint extension from certificate added
* Added support for NID_favouriteDrink pilot
* Added the API function wc_EncryptPKCS8Key to handle encrypting a DER, PKCS#8-formatted key

###### Compatibility Layer Additions
* Open Source PORTS Added/Updated
    - OpenVPN
    - OpenLDAP
    - socat-1.7.4.1
    - Updated QT port for 5.15.2
* Changes to extend set_cipher_list() compatibility layer API to have set_ciphersuites compatibility layer API capability
* Added more support for SHA3 in the EVP layer
* API Added
    - MD5/MD5_Transform
    - SHA/SHA_Transform/SHA1_Transform
    - SHA224/SHA256_Transform/SHA512_Transform
    - SSL_CTX_get0_param/SSL_CTX_set1_param
    - X509_load_crl_file
    - SSL_CTX_get_min_proto_version
    - EVP_ENCODE_CTX_new
    - EVP_ENCODE_CTX_free
    - EVP_EncodeInit
    - EVP_EncodeUpdate
    - EVP_EncodeFinal
    - EVP_DecodeInit
    - EVP_DecodeUpdate
    - EVP_DecodeFinal
    - EVP_PKEY_print_public
    - BIO_tell
    - THREADID_current
    - THREADID_hash
    - SSL_CTX_set_ecdh_auto
    - RAND_set_rand_method()
    - X509_LOOKUP_ctrl()
    - RSA_bits
    - EC_curve_nist2nid
    - EC_KEY_set_group
    - SSL_SESSION_set_cipher
    - SSL_set_psk_use_session_callback
    - EVP_PKEY_param_check
    - DH_get0_pqg
    - CRYPTO_get_ex_new_index
    - SSL_SESSION_is_resumable
    - SSL_CONF_cmd
    - SSL_CONF_CTX_finish
    - SSL_CTX_keylog_cb_func
    - SSL_CTX_set_keylog_callback
    - SSL_CTX_get_keylog_callback

###### Misc.
* Added wolfSSL_CTX_get_TicketEncCtx getter function to return the ticket encryption ctx value
* Added wc_AesKeyWrap_ex and wc_AesKeyUnWrap_ex APIs to accept an Aes object to use for the AES operations
* Added implementation of AES-GCM streaming (--enable-aesgcm-stream)
* Added deterministic generation of k with ECC following RFC6979 when the macro WOLFSSL_ECDSA_DETERMINISTIC_K is defined and wc_ecc_set_deterministic function is called
* Implemented wc_DsaParamsDecode and wc_DsaKeyToParamsDer
* Asynchronous support for TLS v1.3 TLSX ECC/DH key generation and key agreement
* Added crypto callback support for Ed/Curve25519 and SHA2-512/384
* TLS 1.3 wolfSSL_key_update_response function added to see if a update response is needed

### Fixes
* Fix for detecting extra unused bytes that are in an ASN1 sequence appended to the end of a valid ECC signature
* Fix for keyid with ktri CMS (breaks compatibility with previous keyid ASN1 syntax)
* Fix for failed handshake if a client offers more than 150 cipher suites. Thanks to Marcel Maehren, Philipp Nieting, Robert Merget from Ruhr University Bochum Sven Hebrok, Juraj Somorovsky from Paderborn University
* Fix for default order of deprecated elliptic curves SECP224R1, SECP192R1, SECP160R1. Thanks to Marcel Maehren, Philipp Nieting, Robert Merget from Ruhr University Bochum Sven Hebrok, Juraj Somorovsky from Paderborn University
* Fix for corner TLS downgrade case where a TLS 1.3 setup that allows for downgrades but has TLS 1.3 set as the minimum version would still downgrade to TLS 1.2

###### PKCS7 (Multiple fixes throughout regarding memory leaks with SMIME and heap buffer overflows due to streaming functionality)
* Fix PKCS7 dynamic content save/restore in PKCS7_VerifySignedData
* Fix for heap buffer overflow on compare with wc_PKCS7_DecryptKtri
* Fix for heap buffer overflow with wc_PKCS7_VerifySignedData
* Fix for heap buffer overflow with wc_PKCS7_DecodeEnvelopedData
* Check size of public key used with certificate passed into wc_PKCS7_InitWithCert before XMEMCPY to avoid overflow
* Fix for heap buffer overflow fix for wolfSSL_SMIME_read_PKCS7
* Fix to cleanly free memory in error state with wolfSSL_SMIME_read_PKCS7
* SMIME error checking improvements and canonicalize multi-part messages before hashing

###### DTLS Fixes
* DTLS fix to correctly move the Tx sequence number forward
* DTLS fix for sequence and epoch number with secure renegotiation cookie exchange
* Fix for Chacha-Poly AEAD for DTLS 1.2 with secure renegotiation

###### PORT Fixes
* Fix AES, aligned key for the HW module with DCP port
* Fix ATECC608A TNGTLS certificate size issue (thanks @vppillai)
* Fixes for mingw compile warnings
* Fixes for NXP LTC ECC/RSA
* Fix ESP32 RSA hw accelerator initialization issue
* Fixes for STM32 PKA with ECC
* Fixes for STM32 AES GCM for HAL's that support byte sized headers
* Espressif ESP32 SHA_CTX macro conflict resolved

###### Math Library Fixes
* For platforms that support limits.h or windows make sure both SIZEOF_LONG_LONG and SIZEOF_LONG are set to avoid issues with CTC_SETTINGS
* SP C 32/64: fix corner cases around subtraction affecting RSA PSS use
* Fix to return the error code from sp_cond_swap_ct when malloc fails
* Fix potential memory leak with small stack in the function fp_gcd
* Static Analysis Fixes
* Fixes made from Coverity analysis including:
* Cleanups for some return values,
* Fix for leak with wolfSSL_a2i_ASN1_INTEGER
* Sanity check on length in wolfSSL_BN_rand
* Sanity check size in TLSX_Parse catching a possible integer overflow
* Fixes found with -fsanitize=undefined testing
* Fix null dereferences or undefined memcpy calls
* Fix alignment in myCryptoDevCb
* Fix default DTLS context assignment
* Added align configure option to force data alignment

###### Misc.
* Fix for wolfSSL_ASN1_TIME_adj set length
* Fix for freeing structure on error case in the function AddTrustedPeer
* Return value of SSL_read when called after bidirectional shutdown
* Fix for build options ./configure --enable-dtls --disable-asn
* FIx for detection of a salt length from an RSA PSS signature
* Fix to free up globalRNGMutex mutex when cleaning up global RNG
* Fix leak when multiple hardware names are in SAN
* Fix nonblocking ret value from CRL I/O callbacks
* Fix wolfSSL_BIO_free_all return type to better match for compatibility layer
* Fix for make distcheck, maintainer-clean, to allow distribution builds
* Fix for async with fragmented packets
* Fix for the build or RSA verify or public only
* Fix for return value of wolfSSL_BIO_set_ssl to better match expected compatibility layer return value
* Fix for sanity checks on size of issuer hash and key along with better freeing on error cases with DecodeBasicOcspResponse
* Fix for potential memory leak with wolfSSL_OCSP_cert_to_id

### Improvements/Optimizations
###### DTLS/TLS Code Base
* Improved TLS v1.3 time rollover support
* TLS 1.3 PSK: use the hash algorithm to choose cipher suite
* TLS Extended Master Secret ext: TLS13 - send in second Client Hello if in first
* TLS Encrypt then MAC: check all padding bytes are the same value
* wolfSSL_GetMaxRecordSize updated to now take additional cipher data into account
* Updated session export/import with DTLS to handle a new internal options flag
* Refactored dtls_expected_peer_handshake_number handling
* Added wolfSSL_CTX_get_ephemeral_key and wolfSSL_get_ephemeral_key for loading a constant key in place of an ephemeral one
* Improved checking of XSNPRINTF return value in DecodePolicyOID

###### Build Options and Warnings
* Added wolfSSL_CTX_set_verify to the ABI list
* Adjusted FP_ECC build to not allow SECP160R1, SECP160R2, SECP160K1 and SECP224K1. FP_ECC does not work with scalars that are the length of the order when the order is longer than the prime.
* Added CMake support for CURVE25519, ED25519, CURVE448, and ED448
* cmake addition to test paths when building
* Added support for session tickets in CMake
* Added support for reproducible builds with CMake
* Turn on reproducible-build by default when enable-distro
* Windows Project: Include the X448 and Ed448 files
* GCC-11 compile time warning fixes
* Fix for compiling build of ./configure '--disable-tlsv12' '-enable-pkcallbacks'
* Added build error for insecure build combination of secure renegotiation enabled with extended master secret disabled when session resumption is enabled
* Updated building and running with Apple M1
* Apache httpd build without TLS 1.3 macro guard added
* Enable SHA3 and SHAKE256 requirements automatically when ED448 is enabled
* Added option for AES CBC cipher routines to return BAD_LENGTH_E when called with an input buffer length not a multiple of AES_BLOCK_SIZE
* Macro WOLFSSL_SP_INT_DIGIT_ALIGN added for alignment on buffers with SP build. This was needed for compiler building on a Renesas board.
* Build support with no hashes enabled an no RNG compiled in
* Allow use of FREESCALE hardware RNG without a specific port
* Resolved some warnings with Windows builds and PBKDF disabled
* Updated the version of autoconf and automake along with fixes for some new GCC-10 warnings

###### Math Libraries
* SP: Thumb implementation that works with clang
* SP math all: sp_cmp handling of negative values
* SP C ECC: mont sub - always normalize after sub before check for add
* TFM math library prime checking, added more error checks with small stack build
* Sanity checks on 0 value with GCD math function
* fp_exptmod_ct error checking and small stack variable free on error
* Sanity check on supported digit size when calling mp_add_d in non fastmath builds
* Support for mp_dump with SP Math ALL
* WOLFSSL_SP_NO_MALLOC for both the normal SP build and small SP build now
* WOLFSSL_SP_NO_DYN_STACK added for SP small code that is not small stack build to avoid dynamic stack

###### PKCS 7/8
* wc_PKCS7_DecodeCompressedData to optionally handle a packet without content wrapping
* Added setting of content type parsed with PKCS7  wc_PKCS7_DecodeAuthEnvelopedData and wc_PKCS7_DecodeEnvelopedData
* PKCS8 code improvements and refactoring

###### Misc.
* Sanity checks on null inputs to the functions wolfSSL_X509_get_serialNumber and wolfSSL_X509_NAME_print_ex
* Added ARM CryptoCell support for importing public key with wc_ecc_import_x963_ex()
* Improved checking for possible use of key->dp == NULL cases with ECC functions
* Updated SHAKE256 to compile with NIST FIPS 202 standard and added support for OID values (thanks to strongX509)
* Improved ECC operations when using WOLFSSL_NO_MALLOC
* Added WOLFSSL_SNIFFER_FATAL_ERROR for an return value when sniffer is in a fatal state
* Allow parsing spaces in Base64_SkipNewline
* Issue callback when exceeding depth limit rather than error out with OPENSSL_EXTRA build
* Added NXP LTC RSA key generation acceleration

# wolfSSL Release 4.7.0 (February 16, 2021)
Release 4.7.0 of wolfSSL embedded TLS has bug fixes and new features including:

### New Feature Additions
* Compatibility Layer expansion SSL_get_verify_mode, X509_VERIFY_PARAM API, X509_STORE_CTX API added
* WOLFSSL_PSK_IDENTITY_ALERT macro added for enabling a subset of TLS alerts
* Function wolfSSL_CTX_NoTicketTLSv12 added to enable turning off session tickets with TLS 1.2 while keeping TLS 1.3 session tickets available
* Implement RFC 5705: Keying Material Exporters for TLS
* Added --enable-reproducible-build flag for making more deterministic library outputs to assist debugging
* Added support for S/MIME (Secure/Multipurpose Internet Mail Extensions) bundles

### Fixes
* Fix to free mutex when cert manager is free’d
* Compatibility layer EVP function to return the correct block size and type
* DTLS secure renegotiation fixes including resetting timeout and retransmit on duplicate HelloRequest
* Fix for edge case with shrink buffer and secure renegotiation
* Compile fix for type used with curve448 and PPC64
* Fixes for SP math all with PPC64 and other embedded compilers
* SP math all fix when performing montgomery reduction on one word modulus
* Fixes to SP math all to better support digit size of 8-bit
* Fix for results of edge case with SP integer square operation
* Stop non-ct mod inv from using register x29 with SP ARM64 build
* Fix edge case when generating z value of ECC with SP code
* Fixes for PKCS7 with crypto callback (devId) with RSA and RNG
* Fix for compiling builds with RSA verify and public only
* Fix for PKCS11 not properly exporting the public key due to a missing key type field
* Call certificate callback with certificate depth issues
* Fix for out-of-bounds read in TLSX_CSR_Parse()
* Fix incorrect AES-GCM tag generation in the EVP layer
* Fix for out of bounds write with SP math all enabled and an edge case of calling sp_tohex on the result of sp_mont_norm
* Fix for parameter check in sp_rand_prime to handle 0 length values
* Fix for edge case of failing malloc resulting in an out of bounds write with SHA256/SHA512 when small stack is enabled


### Improvements/Optimizations
* Added --enable-wolftpm option for easily building wolfSSL to be used with wolfTPM
* DTLS macro WOLFSSL_DTLS_RESEND_ONLY_TIMEOUT added for resending flight only after a timeout
* Update linux kernel module to use kvmalloc and kvfree
* Add user settings option to cmake build
* Added support for AES GCM session ticket encryption
* Thread protection for global RNG used by wolfSSL_RAND_bytes function calls
* Sanity check on FIPs configure flag used against the version of FIPs bundle
* --enable-aesgcm=table now is compatible with --enable-linuxkm
* Increase output buffer size that wolfSSL_RAND_bytes can handle
* Out of directory builds resolved, wolfSSL can now be built in a separate directory than the root wolfssl directory

### Vulnerabilities
* [HIGH] CVE-2021-3336: In earlier versions of wolfSSL there exists a potential man in the middle attack on TLS 1.3 clients. Malicious attackers with a privileged network position can impersonate TLS 1.3 servers and bypass authentication. Users that have applications with client side code and have TLS 1.3 turned on, should update to the latest version of wolfSSL. Users that do not have TLS 1.3 turned on, or that are server side only, are NOT affected by this report. For the code change see https://github.com/wolfSSL/wolfssl/pull/3676. Thanks to Aina Toky Rasoamanana and Olivier Levillain from Télécom SudParis for the report.
* [LOW] In the case of using custom ECC curves there is the potential for a crafted compressed ECC key that has a custom prime value to cause a hang when imported. This only affects applications that are loading in ECC keys with wolfSSL builds that have compressed ECC keys and custom ECC curves enabled.
* [LOW] With TLS 1.3 authenticated-only ciphers a section of the server hello could contain 16 bytes of uninitialized data when sent to the connected peer. This affects only a specific build of wolfSSL with TLS 1.3 early data enabled and using authenticated-only ciphers with TLS 1.3.

# wolfSSL Release 4.6.0 (December 22, 2020)
Release 4.6.0 of wolfSSL embedded TLS has bug fixes and new features including:

### New Feature Additions
###### New Build Options
* wolfSSL now enables linux kernel module support. Big news for Linux kernel module developers with crypto requirements! wolfCrypt and wolfSSL are now loadable as modules in the Linux kernel, providing the entire libwolfssl API natively to other kernel modules. For the first time on Linux, the entire TLS protocol stack can be loaded as a module, allowing fully kernel-resident TLS/DTLS endpoints with in-kernel handshaking.  (--enable-linuxkm, --enable-linuxkm-defaults, --with-linux-source) (https://www.wolfssl.com/loading-wolfssl-into-the-linux-kernel/)
* Build tests and updated instructions for use with Apple’s A12Z chipset  (https://www.wolfssl.com/preliminary-cryptographic-benchmarks-on-new-apple-a12z-bionic-platform/)
* Expansion of wolfSSL SP math implementation and addition of --enable-sp-math-all build option
* Apache httpd w/TLS 1.3 support added
* Sniffer support for TLS 1.3 and AES CCM
* Support small memory footprint build with only TLS 1.3 and PSK without code for (EC)DHE and certificates

###### New Hardware Acceleration
* Added support for NXP DCP (i.MX RT1060/1062) crypto co-processor
* Add Silicon Labs hardware acceleration using [SL SE Manager](https://docs.silabs.com/gecko-platform/latest/service/api/group-sl-se-manager)

###### New Algorithms
* RC2 ECB/CBC added for use with PKCS#12 bundles
* XChaCha and the XChaCha20-Poly1305 AEAD algorithm support added

###### Misc
* Added support for 802.11Q VLAN frames to sniffer
* Added OCSP function wolfSSL_get_ocsp_producedDate
* Added API to set CPU ID flags cpuid_select_flags, cpuid_set_flag, cpuid_clear_flag
* New DTLS/TLS non-blocking Secure Renegotiation example added to server.c and client.c

### Fixes
###### Math Library
* Fix mp_to_unsigned_bin_len out of bounds read with buffers longer than maximum MP
* Fix for fp_read_radix_16 out of bounds read
* Fix to add wrapper for new timing resistant wc_ecc_mulmod_ex2 function version in HW ECC acceleration
* Handle an edge case with RSA-PSS encoding message to hash

###### Compatibility Layer Fixes
* Fix for setting serial number wolfSSL_X509_set_serialNumber
* Fix for setting ASN1 time not before / not after with WOLFSSL_X509
* Fix for order of components in issuer name when using X509_sign
* Fix for compatibility layer API DH_compute_key
* EVP fix incorrect block size for GCM and buffer up AAD for encryption/decryption
* EVP fix for AES-XTS key length return value and fix for string compare calls
* Fix for mutex freeing during RNG failure case with EVP_KEY creation
* Non blocking use with compatibility layer BIOs in TLS connections

###### Build Configuration
* Fix for custom build with WOLFSSL_USER_MALLOC defined
* ED448 compiler warning on Intel 32bit systems
* CURVE448_SMALL build fix for 32bit systems with Curve448
* Fix to build SP math with IAR
* CMake fix to only set ranlib arguments for Mac, and for stray typo of , -> ;
* Build with --enable-wpas=small fix
* Fix for building fips ready using openssl extra
* Fixes for building with Microchip (min/max and undef SHA_BLOCK_SIZE)
* FIx for NO_FILESYSTEM build on Windows
* Fixed SHA256 support for IMX-RT1060
* Fix for ECC key gen with NO_TFM_64BIT

###### Sniffer
* Fixes for sniffer when using static ECC keys. Adds back TLS v1.2 static ECC key fallback detection and fixes new ECC RNG requirement for timing resistance
* Fix for sniffer with SNI enabled to properly handle WOLFSSL_SUCCESS error code in ProcessClientHello
* Fix for sniffer using HAVE_MAX_FRAGMENT in "certificate" type message
* Fix build error with unused "ret" when building with WOLFSSL_SNIFFER_WATCH.
* Fix to not treat cert/key not found as error in myWatchCb and WOLFSSL_SNIFFER_WATCH.
* Sniffer fixes for handling TCP `out-of-range sequence number`
* Fixes SSLv3 use of ECDH in sniffer

###### PKCS
* PKCS#11 fix to generate ECC key for decrypt/sign or derive
* Fix for resetting internal variables when parsing a malformed PKCS#7 bundle with PKCS7_VerifySignedData()
* Verify the extracted public key in wc_PKCS7_InitWithCert
* Fix for internal buffer size when using decompression with PKCS#7

###### Misc
* Pin the C# verify callback function to keep from garbage collection
* DH fixes for when public key is owned and free’d after a handshake
* Fix for TLS 1.3 early data packets
* Fix for STM32 issue with some Cube HAL versions and STM32 example timeout
* Fix mmCAU and LTC hardware mutex locking to prevent double lock
* Fix potential race condition with CRL monitor
* Fix for possible malformed encrypted key with 3DES causing negative length
* AES-CTR performance fixed with AES-NI

### Improvements/Optimizations
##### SP and Math
* mp_radix_size adjustment for leading 0
* Resolve implicit cast warnings with SP build
* Change mp_sqr to return an error if the result won't fit into the fixed length dp
* ARM64 assembly with clang improvements, clang doesn't always handle use of x29 (FP or Frame Pointer) in inline assembly code correctly - reworked sp_2048_sqr_8 to not use x29
* SP mod exp changed to support exponents of different lengths
* TFM div: fix initial value of size in q so clamping doesn't OOB read
* Numerous stack depth improvements with --enable-smallstack
* Improve cache resistance with Base64 operations

###### TLS 1.3
* TLS 1.3 wolfSSL_peek want read return addition
* TLS 1.3: Fix P-521 algorithm matching

###### PKCS
* Improvements and refactoring to PKCS#11 key look up
* PKCS #11 changes for signing and loading RSA public key from private
* check PKCS#7 SignedData private key is valid before using it
* check PKCS#7 VerifySignedData content length against total bundle size to avoid large malloc

###### Compatibility Layer
* EVP add block size for more ciphers in wolfSSL_EVP_CIPHER_block_size()
* Return long names instead of short names in wolfSSL_OBJ_obj2txt()
* Add additional OpenSSL compatibility functions to update the version of Apache httpd supported
* add "CCM8" variants to cipher_names "CCM-8" ciphers, for OpenSSL compat

###### Builds
* Cortex-M SP ASM support for IAR 6.70
* STM Cube pack support (IDE/STM32Cube)
* Build option --enable-aesgcm=4bit added for AES-GCM GMULT using 4 bit table
* Xilinx IDE updates to allow XTIME override for Xilinx, spelling fixes in Xilinx README.md, and add Xilinx SDK printf support
* Added ED448 to the "all" options and ED448 check key null argument sanity check
* Added ARC4, 3DES, nullcipher, BLAKE2, BLAKE2s, XChaCha, MD2, and MD4 to the “all” options
* Added an --enable-all-crypto option, to enable only the wolfCrypt features of --enable-all, combinable with --enable-cryptonly
* Added the ability to selectively remove features from --enable-all and --enable-all-crypto using specific --disable-<feature> options
* Use Intel intrinsics with Windows for RDSEED and RDRAND (thanks to dr-m from MariaDB)
* Add option to build with WOLFSSL_NO_CLIENT_AUTH
* Updated build requirements for wolfSSH use to be less restrictive
* lighttpd support update for v1.4.56
* Added batch file to copy files to ESP-IDF folders and resolved warnings when using v4.0 ESP-IDF
* Added --enable-stacksize=verbose, showing at a glance the stack high water mark for each subtest in testwolfcrypt

###### ECC
* Performance increase for ECC verify only, using non constant time SP modinv
* During ECC verify add validation of r and s before any use
* Always use safe add and dbl with ECC
* Timing resistant scalar multiplication updated with use of Joye double-add ladder
* Update mp_jacobi function to reduce stack and increase performance for base ECC build
* Reduce heap memory use with wc_EccPrivateKeyDecode, Improvement to ECC wc_ecc_sig_to_rs and wc_ecc_rs_raw_to_sig to reduce memory use (avoid the mp_int)
* Improve StoreECC_DSA_Sig bounds checking

###### OCSP
* OCSP improvement to handle extensions in singleResponse
* support for OCSP request/response for multiple certificates
* OCSP Must Staple option added to require OCSP stapling response
* Add support for id-pkix-ocsp-nocheck extension

###### Misc
* Additional code coverage added for ECC and RSA, PKCS#7, 3DES, EVP and Blake2b operations
* DTLS MTU: check MTU on write
* Refactor hash sig selection and add the macros WOLFSSL_STRONGEST_HASH_SIG (picks the strongest hash) and WOLFSSL_ECDSA_MATCH_HASH (will pick the hash to match the ECC curve)
* Strict certificate version allowed from client, TLS 1.2 / 1.3 can not accept client certificates lower than version 3
* wolfSSL_get_ciphers_compat(), skip the fake indicator ciphers like the renegotiation indication and the quantum-safe hybrid
* When parsing session ticket, check TLS version to see whether they are version compatible
* Additional sanity check for invalid ASN1 padding on integer type
* Adding in ChaCha20 streaming feature with Mac and Intel assembly build
* Sniffer build with --enable-oldtls option on

# wolfSSL Release 4.5.0 (August 19, 2020)

If you have questions about this release, feel free to contact us on our
info@ address.

Release 4.5.0 of wolfSSL embedded TLS has bug fixes and new features including:

## New Feature Additions

* Added Xilinx Vitis 2019.2 example and README updates
* TLS v1.3 is now enabled by default
* Building FIPS 140-2 code and test on Solaris
* Secure renegotiation with DTLS 1.2
* Update RSA calls for hardware acceleration with Xilsecure
* Additional OpenSSL compatibility layer functions added
* Cypress PSoC6 wolfCrypt driver added
* Added STM32CubeIDE support
* Added certificate parsing and inspection to C# wrapper layer
* TLS v1.3 sniffer support added
* TSIP v1.09 for target board GR-ROSE support added
* Added support for the "X72N Envision Kit" evaluation board
* Support for ECC nonblocking using the configure options
  "--enable-ecc=nonblock --enable-sp=yes,nonblock CFLAGS=-DWOLFSSL_PUBLIC_MP"
* Added wc_curve25519_make_pub function to generate a public key given the
  private one

## Fixes

* PIC32MZ hardware cache and large hashes fix
* AES-GCM use with EVP layer in compatibility layer code
* Fix for RSA_LOW_MEM with ARM build of SP code
* Sanity check on tag length with AES-CCM to conform with RFC 3610
* Fixes for 32 and 64 bit software implementations of SP code when
  WOLFSSL_SP_CACHE_RESISTANT is defined
* GCC warning fixes for GCC 9 and later
* Sanity check on HKDF expand length to conform with RFC 5869
* Fixes for STM32 CubeMX HAL with AES-GCM
* Fixed point cache look up table (LUT) implementation fixes
* Fix for ARM 32bit SP code when calling div word
* Fix for potential out of bounds read when parsing CRLs
* Fix for potential out of bounds read with RSA unpadding
* AES-CCM optimized counter fix
* Updates to Xcode projects for new files and features
* Fix for adding CRL’s to a WOLFSSL_X509_STORE structure
* FIPSv2 build with opensslall build fixes
* Fixes for CryptoCell use with ECC and signature wrappers
* Fix for mod calculation with SP code dealing with 3072 bit keys
* Fix for handling certificates with multiple OU’s in name
* Fix for SP math implementation of sp_add_d and add a sanity check on
  rshb range
* Fix for sanity check on padding with DES3 conversion of PEM to DER
* Sanity check for potential out of bounds read with fp_read_radix_16
* Additional checking of ECC scalars.
* Fixing the FIPS Ready build w.r.t. ecc.c.
* When processing certificate names with OpenSSL compatibility layer
  enabled, unknown name item types were getting handled as having NID 0,
  and failing. Added a couple more items to what is handled correctly,
  and ignoring anything that is an unknown type.

## Improvements/Optimizations

* TLS 1.3 certificate verify update to handle 8192 bit RSA keys
* wpa_supplicant support with reduced code size option
* TLS 1.3 alerts encrypted when possible
* Many minor coverity fixes added
* Error checking when parsing PKCS12 DER
* IAR warning in test.c resolved
* ATECC608A improvements for use with Harmony 3 and PIC32 MZ
* Support for AES-GCM and wc_SignatureVerifyHash with static memory and no
  malloc’s
* Enable SNI by default with JNI/JSSE builds
* NetBSD GCC compiler warnings resolved
* Additional test cases and code coverage added including curve25519 and
  curve448 tests
* Option for user defined mutexes with WOLFSSL_USER_MUTEX
* Sniffer API’s for loading buffer directly
* Fixes and improvements from going through the DO-178 process were added
* Doxygen updates and fixes for auto documentation generation
* Changed the configure option for FIPS Ready builds to be
  `--enable-fips=ready`.

## This release of wolfSSL includes fixes for 6 security vulnerabilities.

wolfSSL version 4.5.0 contains 6 vulnerability fixes: 2 fixes for TLS 1.3,
2 side channel attack mitigations, 1 fix for a potential private key leak
in a specific use case, 1 fix for DTLS.

* In earlier versions of wolfSSL there exists a potential man in the middle
  attack on TLS 1.3 clients. Malicious attackers with a privileged network
  position can impersonate TLS 1.3 servers and bypass authentication. Users
  that have applications with client side code and have TLS 1.3 turned on,
  should update to the latest version of wolfSSL. Users that do not have
  TLS 1.3 turned on, or that are server side only, are NOT affected by this
  report. Thanks to Gerald Doussot from NCC group for the report.
* Denial of service attack on TLS 1.3 servers from repetitively sending
  ChangeCipherSpecs messages. This denial of service results from the
  relatively low effort of sending a ChangeCipherSpecs message versus the
  effort of the server to process that message. Users with TLS 1.3 servers are
  recommended to update to the most recent version of wolfSSL which limits the
  number of TLS 1.3 ChangeCipherSpecs that can be received in order to avoid
  this DoS attack. CVE-2020-12457 was reserved for the report. Thanks to
  Lenny Wang of Tencent Security Xuanwu LAB.
* Potential cache timing attacks on public key operations in builds that are
  not using SP (single precision). Users that have a system where malicious
  agents could execute code on the system, are not using the SP build with
  wolfSSL, and are doing private key operations on the system (such as signing
  with a private key) are recommended to regenerate private keys and update to
  the most recent version of wolfSSL. CVE-2020-15309 is reserved for this
  issue. Thanks to Ida Bruhns from Universität zu Lübeck and Samira Briongos
  from NEC Laboratories Europe for the report.
* When using SGX with EC scalar multiplication the possibility of side-channel
  attacks are present. To mitigate the risk of side channel attacks wolfSSL’s
  single precision EC operations should be used instead. Release 4.5.0 turns
  this on be default now with SGX builds and in previous versions of wolfSSL
  this can be turned on by using the WOLFSSL_SP macros. Thank you to
  Alejandro Cabrera Aldaya, Cesar Pereida García and Billy Bob Brumley from
  the Network and Information Security Group (NISEC) at Tampere University for
  the report.
* Leak of private key in the case that PEM format private keys are bundled in
  with PEM certificates into a single file. This is due to the
  misclassification of certificate type versus private key type when parsing
  through the PEM file. To be affected, wolfSSL would need to have been built
  with OPENSSL_EXTRA (--enable-opensslextra). Some build variants such as
  --enable-all and --enable-opensslall also turn on this code path, checking
  wolfssl/options.h for OPENSSL_EXTRA will show if the macro was used with the
  build. If having built with the opensslextra enable option and having placed
  PEM certificates with PEM private keys in the same file when loading up the
  certificate file, then we recommend updating wolfSSL for this use case and
  also recommend regenerating any private keys in the file.
* During the handshake, clear application_data messages in epoch 0 are
  processed and returned to the application. Fixed by dropping received
  application_data messages in epoch 0. Thank you to Paul Fiterau of Uppsala
  University and Robert Merget of Ruhr-University Bochum for the report.

For additional vulnerability information visit the vulnerability page at
https://www.wolfssl.com/docs/security-vulnerabilities/

See INSTALL file for build instructions.
More info can be found on-line at https://wolfssl.com/wolfSSL/Docs.html


# wolfSSL Release 4.4.0 (04/22/2020)

If you have questions about this release, then feel free to contact us on our
info@ address.

Release 4.4.0 of wolfSSL embedded TLS has bug fixes and new features including:

## New Feature Additions

* Hexagon support.
* DSP builds to offload ECC verify operations.
* Certificate Manager callback support.
* New APIs for running updates to ChaCha20/Poly1305 AEAD.
* Support for use with Apache.
* Add support for IBM s390x.
* PKCS8 support for ED25519.
* OpenVPN support.
* Add P384 curve support to SP.
* Add BIO and EVP API.
* Add AES-OFB mode.
* Add AES-CFB mode.
* Add Curve448, X448, and Ed448.
* Add Renesas Synergy S7G2 build and hardware acceleration.

## Fixes

* Fix for RSA public encrypt / private sign with RSA key sizes over 2048-bit.
* Correct misspellings.
* Secure renegotiation fix.
* Fix memory leak when using ATECC and non-SECP256R1 curves for sign, verify,
  or shared secret.
* Fix for K64 MMCAU with `WOLFSSL_SMALL_STACK_CACHE`.
* Fix the RSA verify only build.
* Fix in SP C implementation for small stack.
* Fix using the auth key id extension is set, hash might not be present.
* Fix when flattening certificate structure to include the subject alt names.
* Fixes for building with ECC sign/verify only.
* Fix for ECC and no cache resistance.
* Fix memory leak in DSA.
* Fix build on minGW.
* Fix `PemToDer()` call in `ProcessBuffer()` to set more than ECC.
* Fix for using RSA without SHA-512.
* Add some close tags to the echoserver HTTP example output.
* Miscellaneous fixes and updates for static analysis reports.
* Fixes for time structure support.
* Fixes for VxWorks support.
* Fixes for Async crypto support.
* Fix cache resist compile to work with SP C code.
* Fixes for Curve25519 x64 asm.
* Fix for SP x64 div.
* Fix for DTLS edge case where CCS and Finished come out of order and the
  retransmit pool gets flushed.
* Fix for infinite loop in SHA-1 with small inputs. Thanks to Peter W.
* Fix for FIPS Hmac where `wc_HmacInit()` isn't used. `wc_HmacSetKey()` needs
  to initialize the Hmac structure. Type is set to NONE, and checked against
  NONE, not 0.
* Fixes for SP RSA private operations.
* Fixes for Xilinx SDK and Zynq UltraScale+ MPSoC
* Fix leak when building with HAVE_AESGCM and NO_AES_DECRYPT. Thanks G.G.
* Fixes for building ECC without ASN.
* Fix for async TLSv1.3 issues.
* Fix `wc_KeyPemToDer()` with PKCS1 and empty key.
* Omit `-fomit-frame-pointer` from CFLAGS in configure.ac.

## Improvements/Optimizations

* Qt 5.12 and 5.13 support.
* Added more digest types to Cryptocell RSA sign/verify.
* Some memory usage improvements.
* Speed improvements for mp_rand.
* Improvements to CRL and OCSP support.
* Refactor Poly1305 AEAD/MAC to reduce duplicate code.
* Add blinding to RSA key gen.
* Improvements to blinding.
* Improvement and expansion of OpenSSL Compatibility Layer.
* Improvements to ChaCha20.
* Improvements to X.509 processing.
* Improvements to ECC support.
* Improvement in detecting 64-bit support.
* Refactor to combine duplicate ECC parameter parsing code.
* Improve keyFormat to be set by algId and let later key parsing produce fail.
* Add test cases for 3072-bit and 4096-bit RSA keys.
* Improve signature wrapper and DH test cases.
* Improvements to the configure.ac script.
* Added constant time RSA q modinv p.
* Improve performance of SP Intel 64-bit asm.
* Added a few more functions to the ABI list.
* Improve TLS bidirectional shutdown behavior.
* OpenSSH 8.1 support.
* Improve performance of RSA/DH operations on x64.
* Add support for PKCS7/CMS Enveloped data with fragmented encrypted content.
* Example linker description for FIPS builds to enforce object ordering.
* C# wrapper improvements. Added TLS client example and TLSv1.3 methods.
* Allow setting MTU in DTLS.
* Improve PKCS12 create for outputting encrypted bundles.
* Constant time EC map to affine for private operations.
* Improve performance of RSA public key ops with TFM.
* Smaller table version of AES encrypt/decrypt.
* Support IAR with position independent code (ROPI).
* Improve speed of AArch64 assembly.
* Support AES-CTR on esp32.
* Add a no malloc option for small SP math.

## This release of wolfSSL includes fixes for 2 security vulnerabilities.

* For fast math, use a constant time modular inverse when mapping to affine
  when operation involves a private key - keygen, calc shared secret, sign.
  Thank you to Alejandro Cabrera Aldaya, Cesar Pereida García and
  Billy Bob Brumley from the Network and Information Security Group (NISEC)
  at Tampere University for the report.

* Change constant time and cache resistant ECC mulmod. Ensure points being
  operated on change to make constant time. Thank you to Pietro Borrello at
  Sapienza University of Rome.

For additional vulnerability information visit the vulnerability page at
https://www.wolfssl.com/docs/security-vulnerabilities/

See INSTALL file for build instructions.
More info can be found on-line at https://wolfssl.com/wolfSSL/Docs.html



# wolfSSL Release 4.3.0 (12/20/2019)

If you have questions about this release, then feel free to contact us on our info@ address.

Release 4.3.0 of wolfSSL embedded TLS has bug fixes and new features including:

##### New Feature Additions
* Add --enable-libwebsockets option for support of libwebsockets build
* Updated support for NGINX 1.15.0 and added support for 1.16.1
* Add wc_scrypt_ex API which can take in iterations rather than cost
* Updates to RSA-PSS salt lengths. Macro WOLFSSL_PSS_SALT_LEN_DISCOVER allows for discovering the salt length. Passing RSA_PSS_SALT_LEN_DISCOVER value into wc_RsaPSS_Verify_ex attempts to discover salt length and can use larger salt lengths
* Additional OpenSSL compatibility API wolfSSL_CertManagerGetCerts and wolfSSL_X509_STORE_GetCerts for retrieving certificates
* Add support for 4096-bit RSA/DH operations to SP (single precision) build
* Update support for Google WebRTC to branch m79
* Adds new FREESCALE_MQX_5_0 macro for MQX 5.0 support
* Adds a CMS/PKCS#7 callback for signing SignedData raw digests enabled with macro HAVE_PKCS7_RSA_RAW_SIGN_CALLBACK and call to function wc_PKCS7_SetRsaSignRawDigestCb
* Add --disable-errorqueue feature to disable adding debug nodes to queue with --enable-opensslextra build
* After defining WOLFSSL_SHUTDOWNONCE macro the function wolfSSL_shutdown will return a specific error code of SSL_SHUTDOWN_ALREADY_DONE_E, to indicate to the application that the shutdown has already occurred
* Add AES-CCM decryption to benchmarking app bundled with wolfSSL


##### Fixes
* Fixes IAR warnings with IAR-EWARM 7.50.2
* Alignment fixes for mmCAU with AES and hashing algorithms
* Fix check for plaintext length when using Encrypt-Then-MAC
* Fix for unit tests with NGINX and debug mode
* Fix for macro names in test cases (WOLFSSL_PUBLIC_MP) and pkcs7.c (HAVE_AESCCM)
* Fix for Apache want read case with BIO retry flag
* Fix for PKCS7 streaming mode that would error rather than verify bundle
* Fix for freeing mutex for X509 and wolfSSL_EVP_PKEY_free, applies to OPENSSL_EXTRA / --enable-opensslextra builds
* Fix for encrypt then MAC when re-handshaking, encrypted handshakes change over to ETM now
* Fix for curve25519 assembly optimizations with GCC + AVX2
* Fix to hang onto certificate for retrieval if using secure renegotiation and session resumption
* Fixes case where the heap hint is created before WOLFSSL_CTX, when calling wc_LoadStaticMemory instead of wolfSSL_CTX_load_static_memory
* Fix for setting correct return value in PKCS12 parse error case
* Reset certificate extension policy count
* Fix for memcpy with TLS I/O buffers when using staticmemory pools and loading memory as WOLFMEM_IO_POOL_FIXED
* Fixes and updates for STM32 port, including additional mutex protection, AES-GCM decrypt auth tag, AES-CTR mode with CubeMX, update to OpenSTM32 project
* Fix for EVP CipherUpdate decrypt and add a test case
* DTLS fixes including; some DTLS sequence number issues in general where the sequence was incremented twice for each record and some offset values in the DTLS window checking
* Fix sp_add to handle carries properly (--enable-sp-math build)
* Additional sanity check on OCSP response decoder
* Fix for vasprintf with Solaris and AIX builds
* Fix for missing variable declaration with --enable-scep --with-libz build
* Fix for certificate date check with async build
* Sanity check on “out” length with Base64_Decode added
* Decode X.509 name - check input length for jurisdiction
* Additional sanity check on variable out index with DecodePolicyOID
* Fix for PKCS#12 PBKDF buffer size for buffer overflow
* TLS supported curve extension check curve name is in range before checking for disabled
* Sanity check for non TLS 1.3 cipher suite with TLS 1.3 connection
* Poly1305 AVX2 assembly optimization fix for carry with large input values
* Fixes for coverity report including null termination of test case strings and initialization of PKCS7 variables
* Fix for API visibility of wc_ed25519_check_key which resolves a wolfcrypt-py install issue
* Sanity check on max ALPN length accepted
* Additional sanity check when parsing CRL’s for copying the structure, fix for bounds checking
* Additional checks on error string length for debug mode and check for null termination
* ProcessPeerCerts allocating memory for exts with OPENSSL_EXTRA properly
* Clear the top bit when generating a serial number
* Sanity check that ASN date characters are valid ASCII characters
* Fix to add deterministic ECDSA and fix corner cases for add point.
* When getting the DH public key, initialize the P, G, and Pub pointers to NULL, then set that we own the DH parameters flag. This allows FreeSSL to correctly clean up the DH key.

##### Improvements/Optimizations
* Added configure error report with using invalid build of --enable-opensslextra and --enable-opensslcoexist together
* Update PKCS11 for determining key type given the private key type
* Update DoVerifyCallback to check verify param hostName and ipasc (--enable-opensslextra builds)
* additional null sanity checks on input arguments with QSH and Cryptocell builds
* Additional checks on RSA key added to the function wc_CheckRsaKey
* Updates for EBSNET support, including fseek, revised macros in settings.h, and realloc support
* MISRA-C updates for SP math code
* Update to allow compiling for pwdbased/PBKDF2 with having NO_ASN defined
* Modify KeyShare and PreSharedKey TLS 1.3 extension linked list advancement to be easier for compilers to handle
* Optimization to parsing certificate extension name strings
* Adjustment to example server -x runtime behavior when encountering an unrecoverable error case
* Remove Blake2b support from HMAC
* Adds new hash wrapper init wc_HashInit_ex and Adds new PBKDF2 API wc_PBKDF2_ex for using heap hints for custom memory pools
* Adding script to cleanup generated test files,  scripts/cleanup_testfiles.sh
* Support 20-byte serial numbers and disallow 0
* sp_div improved to handle when a has less digits than d (--enable-sp-math build)
* When decoding a policy OID and turning it into a human readable string use snprintf()
* set the IV length of EVP AES GCM to 96-bits by default
* Allow adding CAs for root CA's over the wire that do not have the extended key usage cert_sign set
* Added logging messages for SendAlert call and update to send alert after verify certificate callback
* updates for synchronous OCTEON support in the Sniffer
* Rework BER to DER functions to not be recursive
* Updates to find CRL by AuthKeyId
* Add a check for subject name hash after matching AKID
* Enhancement to mp_invmod/fp_exptmod/sp_exptmod to handle more inputs
* Remove requirement for macro NO_SKID when CRL use is enabled
* Improvements on XFTELL return code and MAX_WOLFSSL_FILE_SIZE checking
* When checking if value is prime return NO in the case of the value 1
* Improve Cortex-M RSA/DH assembly code performance
* Additional sanity checks on arrays and buffers with OCSP


##### This release of wolfSSL includes a fix for 6 security vulnerabilities.


A fix for having an additional sanity check when parsing certificate domain names was added. This fix checks that the domain name location index is not past the maximum value before setting it. The reported issue affects users that are parsing certificates and have --enable-opensslextra (macro OPENSSL_EXTRA), or build options that turn this on such as --enable-all, when building wolfSSL. The CVE associated with the fix is CVE-2019-18840.

Fix to set a limit on the maximum size of DTLS handshake messages. By default the RFC allows for handshake message sizes of up to 2^24-1 bytes long but in typical field use cases the handshake messages are not this large. Setting a maximum size limit on the handshake message helps avoid a potential DoS attack due to memory being malloc’d. The new default max size is set to handle a certificate chain length of approximately 9, 2048 bit RSA certificates. This only effects builds that have DTLS turned on and have applications that are using DTLS.

Fix for a potential hang when ECC caching is enabled (off by default) and --enable-fastmath is used. ECC caching is off by default and is turned on in builds that are using --enable-all or --enable-fpecc. This issue does not affect builds that are using the macro WOLFSSL_VALIDATE_ECC_IMPORT which turns on validating all ECC keys that are imported. To fix this potential hang case a sanity check on the input values to the internal invmod function was added.


To fix a potential fault injection attack on a wrapper function for wolfCrypt RSA signature generations an additional sanity check verifying the signature after it’s creation was added. This check is already done automatically in current versions of wolfSSL with TLS connections (internal function call of VerifyRsaSign during TLS state machine). The report only affects users making calls to the wolfCrypt function wc_SignatureGenerateHash and does not affect current TLS use cases. Thanks to Daniel Moghimi (@danielmgmi) from Worcester Polytechnic Institute for the report.


Blinding was added for DSA signing operations. The DSA signing uses the BEEA algorithm during modular inversion of the nonce which can potentially leak the nonce through side channels such as cache and power fluctuations. The fix of adding in blinding makes the DSA signing operation more resistant to side channel attacks. Users who have turned on DSA (disabled by default) and are performing signing operations should update. Note that DSA is not used in any TLS connections. Thanks to Daniel Moghimi (@danielmgmi) from Worcester Polytechnic Institute for the report.


Fix to add additional side channel cache attack resistance to the internal ECC function wc_ecc_mulmod_ex. This function by default is used with ECDSA signing operations. Users should update if performing ECDSA singing operations (server side ECC TLS connections, mutual authentication on client side) or calling wolfCrypt ECC sign functions and have the potential for outside users to perform sophisticated monitoring of the cache.Thanks to Daniel Moghimi (@danielmgmi) from Worcester Polytechnic Institute for the report.


For additional vulnerability information visit the vulnerability page at https://www.wolfssl.com/docs/security-vulnerabilities/

See INSTALL file for build instructions.
More info can be found on-line at http://wolfssl.com/wolfSSL/Docs.html


# wolfSSL Release 4.2.0 (10/22/2019)

If you have questions about this release, then feel free to contact us on our info@ address.

Release 4.2.0 of wolfSSL embedded TLS has bug fixes and new features including:


##### New Feature Additions
* Over 198 OpenSSL compatibility API’s added
* Apache port added for compiling with wolfSSL using --enable-apachehttpd
* Port for using wolfSSL with OpenVSwitch
* Port for Renesas TSIP added
* Visual Studio Solution for Azure Sphere Devices (MT3620 and MT3620-mini) added to the directory IDE/VS-AZURE-SPHERE
* Addition of Coldfire MCF5441X NetBurner example to the directory IDE/M68K/
* Added support for prime checking to SP math build
* Addition of DYNAMIC_TYPE_BIGINT type for tracking mp_int allocations
* Addition of wc_ecc_get_curve_params API for getting ecc_set_type params for a curve
* Adding in TLS_SHA256_SHA256 and TLS_SHA384_SHA384 TLS1.3 cipher suites (null ciphers)
* Added in PKCS7 decryption callbacks for CMS operations
* Added handling for optional ECC parameters with PKCS7 KARI
* Addition to configure.ac for FIPS wolfRand builds
* Adding the flag WOLFSSL_LOAD_FLAG_DATE_ERR_OKAY for ignoring certificate date checks with the functions wolfSSL_CTX_load_verify_buffer_ex and wolfSSL_CTX_load_verify_locations_ex
* Support for PKCS8 keys added to the function wolfSSL_CTX_use_PrivateKey_buffer
* Support for KECCAK hashing. Build with macro WOLFSSL_HASH_FLAGS and call wc_Sha3_SetFlags(&sha, WC_HASH_SHA3_KECCAK256) before the first SHA3 update
* Addition of setting secure renegotiation at CTX level
* Addition of KDS (NXP Kinetis Design Studio) example project to directory IDE/KDS/
* Support for Encrypt-Then-MAC to TLS 1.2 and below
* Added a new build option for a TITAN session cache that can hold just over 2 million session entries (--enable-titancache)
* Synchronous Quick Assist Support for Sniffer
* Added Support for SiFive HiFive Unleashed board
* Support for Google WebRTC added in to compatibility layer build
* Additional Sniffer features; IPv6 sniffer support, Fragment chain input, Data store callback, Various statistics tweaks and other Sniffer fixes


##### Fixes
* Addition of internal content digest checks for PKCS7 SignedData message types that also have signed attributes present. Users could previously check the content digest against the messageDigest attribute, but this adds a default internal check. It’s advised that if users are not doing their own checks that they update wolfSSL version.
* A fix for BIO and base64 encoding/decoding
* A fix for memory management of CTX / WOLFSSL_METHOD pointer with staticmemory build
* A fix for detection of AES-NI support to read bit 25 from ECX
* A fix a DTLS handshake message retransmit bug corner case
* Additional fixes to coding style and uninitialized values using cppcheck tool
* Fixes for failing IAR builds, thanks to Joseph C. for the report
* Fixes for ARMv8 Poly1305 inline assembly code to compile with clang 3.5
* Fixes for esp-idf build warnings
* A fix for XSNPRINTF with mingw32 builds
* Fixes for strncpy warnings when compiling with newer versions of GCC
* A fix for using IV of all 0’s as default case with AES-NI when no IV passed in
* Fixes for types with 16 bit systems, thanks to Ralf Schlatterbeck
* Fixes for build with devcrypto/afalg and aesccm, thanks to GitHub user cotequeiroz for the report
* Fixes for addressing handling of pathLen constraint when parsing certificate chains
* A DTLS fix for alert packet injection at end of handshake
* Fixes for Poly1305 AArch64 assembly code
* A fix for memory management in error cases when adding a CA, this resolves a coverity report
* A fix for SP math for precomputation tables to not include infinity field
* Fixes for checks on defines with AVX2 and Poly1305 build
* Fixes for CubeMX HAL v1.15 with STM32F7
* A fix for TLS 1.3 to always send Key Share extension
* A fix for a potential buffer over read in TLS 1.3 DoTls13SupportedVersions, thanks to Artem for the report


##### Improvements/Optimizations
* Optimization to SP math, changing variables to const where possible. Thanks to Yair Poleg (yair.poleg@ayyeka.com) of Ayyeka for proposing static declaration of global constant variables in SP code
* Additional fuzz testing and fixes for TLS 1.3 use, including additional TLS 1.3 alert messages (PR#2440 for more information)
* Additional sanity check that ciphersuite from client hello is used in server hello response (check can be removed with the macro WOLFSSL_NO_STRICT_CIPHER_SUITE)
* Improved MMCAU performance: SHA-1 by 35%, SHA-256 by 20% and MD5 by 78%
* By default, disallow SHA-2 cipher suites from being used in TLS 1.0 and 1.1 handshakes (can be ignored with macro WOLFSSL_OLDTLS_SHA2_CIPHERSUITES)
* Optimization of export session buffer size with enable option --enable-sessionexport=nopeer
* Spelling fixes in comments and some cast warnings resolved
* Updates to abstract atoi to XATOI when used, this allows for better portability when making calls to the system function atoi for converting strings to integers
* Improvements to the STSAFE-A100 error code handling, providing better debug information
* Adding a sanity check on TLS 1.3 ticket encrypt callback
* Specialized implementations of mod exp when base is 2



##### This release of wolfSSL includes a fix for 5 security vulnerabilities.

Fix for sanity check on reading TLS 1.3 pre-shared key extension. This fixes a potential for an invalid read when TLS 1.3 and pre-shared keys is enabled. Users without TLS 1.3 enabled are unaffected. Users with TLS 1.3 enabled and HAVE_SESSION_TICKET defined or NO_PSK not defined should update wolfSSL versions. Thanks to Robert Hoerr for the report.

Fix for potential program hang when ocspstapling2 is enabled. This is a moderate level fix that affects users who have ocspstapling2 enabled(off by default) and are on the server side. In parsing a CSR2 (Certificate Status Request v2 ) on the server side, there was the potential for a malformed extension to cause a program hang. Thanks to Robert Hoerr for the report.

Two moderate level fixes involving an ASN.1 over read by one byte. CVE-2019-15651 is for a fix that is due to a potential one byte over read when decoding certificate extensions. CVE-2019-16748 is for a fix on a potential one byte overread with checking certificate signatures. This affects builds that do certificate parsing and do not have the macro NO_SKID defined.Thanks to Yan Jia and the researcher team  from Institute of Software, Chinese Academy of Sciences for the report.

High level fix for DSA operations involving an attack on recovering DSA private keys. This fix affects users that have DSA enabled and are performing DSA operations (off by default). All users that have DSA enabled and are using DSA keys are advised to regenerate DSA keys and update wolfSSL version. ECDSA is NOT affected by this and TLS code is NOT affected by this issue. Thanks to Ján Jančár for the report.


For additional vulnerability information visit the vulnerability page at https://www.wolfssl.com/docs/security-vulnerabilities/

See INSTALL file for build instructions.
More info can be found on-line at http://wolfssl.com/wolfSSL/Docs.html



# wolfSSL Release 4.1.0 (07/22/2019)

Release 4.1.0 of wolfSSL embedded TLS has bug fixes and new features including:

* A fix for the check on return value when verifying PKCS7 bundle signatures, all users with applications using the function wc_PKCS7_VerifySignedData should update
* Adding the function wc_PKCS7_GetSignerSID for PKCS7 firmware bundles as a getter function for the signers SID
* PKCS7 callback functions for unwrapping of CEK and for decryption
* Adding the error value PKCS7_SIGNEEDS_CHECK when no certificates are available in a PKCS7 bundle to verify the signature
* TLS 1.3 fixes including if major version is TLS Draft then it is now ignored and if version negotiation occurs but none were matched then an alert is now sent
* Addition of the WOLFSSL_PSK_ONE_ID macro for indicating that only one identity in TLS 1.3 PSK is available and will be cached
* Adding sanity checks on length of PSK identity from a TLS 1.3 pre-shared key extension
* Additional sanity checks and alert messages added for TLS 1.3
* Adding XTIME_MS macro to simplify the tls13.c time requirement
* Improvements and refactoring of code related to parsing and creating TLS 1.3 client hello packets
* TLS 1.3 version renegotiation now happens before interpreting ClientHello message
* Chacha20 algorithm optimizations on the ARM architecture for performance increase
* Poly1305 algorithm performance enhancements for the ARM architecture using the SIMD NEON extension
* Curve25519 and Ed25519 optimized for ARM architecture for performance increase
* SHA-512/384 optimizations for performance with ARM architecture using the SIMD NEON extension
* Sniffer updates including adding support for the null cipher and static ECDH key exchange and new SSLWatchCb callback
* Cipher suite TLS_RSA_WITH_NULL_MD5 for use with the sniffer (off by default)
* Sniffer statistic print outs with the macro WOLFSSL_SNIFFER_STATS defined
* A fix for wolfSSL_DH_generate_key when WOLFSSL_SMALL_STACK is defined
* wolfSSL_BN_Init implementation for opensslextra builds
* Updates to the function wolfSSL_i2d_RSAPrivateKey and additional automated tests
* Fixes for EVP_CipherFinal edge cases to match behavior desired
* Check for appropriate private vs public flag with ECC key decode in wolfSSL_EC_KEY_LoadDer_ex, thanks to Eric Miller for the report
* Implementation of the function wolfSSL_PEM_write_DHparams
* wolfSSL_RAND_seed is called in wolfSSL_Init now when opensslextra is enabled
* CryptoCell-310 support on nRF52840 added
* Fixes for atmel_ecc_create_pms to free the used slot.
* Fixes for building ATECC with ATCAPRINTF or WOLFSSL_PUBLIC_MP
* Cortex-M code changes to support IAR compiler
* Improvements to STM32 AES-GCM performance
* Fixes for 16-bit systems including PK callbacks, ATECC and LowResTimer function ptoto.
* IAR-EWARM compiler warning fix
* Clean up of user_settings for CS+ port
* Updating Renesas example projects to the latest version
* Micrium updates adjusting STATIC macro name and added inline flag
* Fixes for building with WOLFSSL_CUSTOM_CURVES on Windows
* Updates and refactor to the default build settings with Arduino
* Fixes for visibility tags with Cygwin build
* STSAFE Improvements to support wolfSSL Crypto Callbacks
* Improvements to NetBSD builds and mutex use in test case
* Updating TI hardware offload with WOLFSSL_TI_CRYPT build
* Maintaining Xilinx FreeRTOS port by adjusting time.h include in wolfSSL
* SiFive HiFive E31 RISC‐V core family port
* Port for Telit IoT AppZone SDK
* OCSP Response signed by issuer with identical SKID fix
* Fix for sending revoked certificate with OCSP
* Honor the status sent over connection with peers and do not perform an internal OCSP lookup
* Adding the build flag `--enable-ecccustcurves=all` to enable all curve types
* Support add for Ed25519ctx and Ed25519ph sign/verify algorithms as per RFC 8032
* Addition of the macro WOLFSSL_NO_SIGALG to disable signature algorithms extension
* wc_AesCtrEncrypt in place addition, where input and output buffer can be the same buffer
* Single shot API added for SHA3; wc_Sha3_224Hash, wc_Sha3_256Hash, wc_Sha3_384Hash, wc_Sha3_512Hash
* Function additions for JSSE support some of which are wolfSSL_get_ciphers_iana and wolfSSL_X509_verify along with expansion of the --enable-jni option
* Macro guards for more modular SHA3 build (i.e. support for 384 size only)
* Benchmarking -thread <num> argument support for asynchronous crypto
* Blake2s support (--enable-blake2s), which provides 32-bit Blake2 support
* Macro SHA256_MANY_REGISTERS addition to potentially speed up SHA256 depending on architecture
* Additional TLS alert messages sent with the macro WOLFSSL_EXTRA_ALERTS defined
* Feature to fail resumption of a session if the session’s cipher suite is not in the client’s list, this can be overridden by defining the macro NO_RESUME_SUITE_CHECK
* Fallback SCSV (Signaling Cipher Suite Value) support on Server only (--enable-fallback-scsv)
* DTLS export state only (wolfSSL_dtls_export_state_only) which is a subset of the information exported from previous DTLS export function
* Function wc_DhCheckPubValue added to perform simple validity checks on DH keys
* Support for RSA SHA-224 signatures with TLS added
* Additional option “-print” to the benchmark app for printing out a brief summary after benchmarks are complete
*  Adding (--disable-pkcs12) option and improvements for disabled sections in pwdbased.c, asn.c, rsa.c, pkcs12.c and wc_encrypt
* Added DES3 support to the wolfSSL crypto callbacks
* Compile time fixes for build case with SP math and RSA only
* Fixes for Coverity static analysis report including explicit initialization of reported stack variables some additional Coverity fixes added thanks to Martin
* Fixes for scan build warnings (i.e possible null dereference in ecc.c)
* Resetting verify send value with a call to wolfSSL_clear function
* Fix for extern with sp_ModExp_2048 when building with --cpp option
* Fix for typo issue with --enable-sp=cortexm
* Adding #pragma warning disable 4127 for tfm.c when building with Visual Studio
* Improvements to the maximum ECC signature calculations
* Improvements to TLS write handling in error cases which helps user application not go through with a wolfSSL_write attempt after a wolfSSL_read failure
* Fix for read directory functions with Windows (wc_ReadDirFirst and wc_ReadDirNext)
* Sanity check on index before accessing domain component buffer in call to wolfSSL_X509_NAME_get_entry
* Sending fatal alert from client side on version error
* Fix for static RSA cipher suite with PK callback and no loaded private key
* Fix for potential memory leak in error case with the function wc_DsaKeyToDer, thanks to Chris H. for the report
* Adjusting STRING_USER macro to remove includes of standard lib <string.h> or <stdio.h>
* Bug fix for checking wrong allocation assignment in the function wc_PBKDF2 and handling potential leak on allocation failure. This case is only hit when the specific call to malloc fails in the function wc_PBKDF2. Thanks to Robert Altnoeder (Linbit) for the report
* Improved length checks when parsing ASN.1 certificates
* extern "C" additions to header files that were missing them
* Improved checking of return values with TLS extension functions and error codes
* Removing redundant calls to the generate function when instantiating and reseeding DRBG
* Refactoring and improvements to autoconf code with consolidating AM_CONDITIONAL statements
* Improvements for handling error return codes when reading input from transport layer
* Improvements to efficiency of SNI extension parsing and error checking with ALPN parsing
* Macro WOLFSSL_DEBUG_TLS addition for printing out extension data being parsed during a TLS connection
* Adjustment of prime testing with --disable-fastmath builds


This release of wolfSSL includes a fix for 2 security vulnerabilities.

There is a fix for a potential buffer overflow case with the TLSv1.3 PSK extension parsing. This affects users that are enabling TLSv1.3 (--enable-tls13). Thanks to Robert Hoerr for the report. The CVE associated with the report is CVE-2019-11873.

There is a fix for the potential leak of nonce sizes when performing ECDSA signing operations. The leak is considered to be difficult to exploit but it could potentially be used maliciously to perform a lattice based timing attack against previous wolfSSL versions. ECC operations with --enable-sp and --enable-sp-asm are not affected, users with private ECC keys in other builds that are performing ECDSA signing operations should update versions of wolfSSL along with private ECC keys. Thanks to Ján Jančár from Masaryk University for the report.


# wolfSSL Release 4.0.0 (03/20/2019)

Release 4.0.0 of wolfSSL embedded TLS has bug fixes and new features including:

* Support for wolfCrypt FIPS v4.0.0, certificate #3389
* FIPS Ready Initiative
* Compatibility fixes for secure renegotiation with Chrome
* Better size check for TLS record fragment reassembly
* Improvements to non-blocking and handshake message retry support for DTLS
* Improvements to OCSP with ECDSA signers
* Added TLS server side secure renegotiation
* Added TLS Trusted CA extension
* Add support for the Deos Safety Critical RTOS
* OCSP fixes for memory management and initializations
* Fixes for EVP Cipher decryption padding checks
* Removal of null terminators on `wolfSSL_X509_print` substrings
* `wolfSSL_sk_ASN1_OBJCET_pop` function renamed to `wolfSSL_sk_ASN1_OBJECT_pop`
* Adjustment to include path in compatibility layer for evp.h and objects.h
* Fixes for decoding BER encoded PKCS7 contents
* TLS handshake now supports using PKCS #11 for private keys
* PKCS #11 support of HMAC, AES-CBC and random seeding/generation
* Support for named FFDHE parameters in TLS 1.2 (RFC 7919)
* Port to Zephyr Project
* Move the TLS PRF to wolfCrypt.
* Update to CMS KARI support
* Added ESP32 WROOM support
* Fixes and additions to the OpenSSL compatibility layer
* Added WICED Studio Support
* MDK CMSIS RTOS v2
* Xcode project file update
* Fixes for ATECC508A/ATECC608A
* Fixes issue with CA path length for self signed root CA's
* Fixes for Single Precision (SP) ASM when building sources directly
* Fixes for STM32 AES GCM
* Fixes for ECC sign with hardware to ensure the input is truncated
* Fixes for proper detection of PKCS7 buffer overflow case
* Fixes to handle degenerate PKCS 7 with BER encoding
* Fixes for TLS v1.3 handling of 6144 and 8192 bit keys
* Fixes for possible build issues with SafeRTOS
* Added `ECC_PUBLICKEY_TYPE` to the support PEM header types
* Added strict checking of the ECDSA signature DER encoding length
* Added ECDSA option to limit sig/algos in client_hello to key size with
  `USE_ECDSA_KEYSZ_HASH_ALGO`
* Added Cortex-M support for Single Precision (SP) math
* Added wolfCrypt RSA non-blocking time support
* Added 16-bit compiler support using --enable-16bit option
* Improved Arduino sketch example
* Improved crypto callback features
* Improved TLS benchmark tool
* Added new wrapper for snprintf for use with certain Visual Studio builds,
  thanks to David Parnell (Cambridge Consultants)

This release of wolfSSL includes a fix for 1 security vulnerability.

* Fixed a bug in tls_bench.c example test application unrelated to the crypto
  or TLS portions of the library. (CVE-2019-6439)


# wolfSSL Release 3.15.7 (12/26/2018)

Release 3.15.7 of wolfSSL embedded TLS has bug fixes and new features including:

* Support for Espressif ESP-IDF development framework
* Fix for XCode build with iPhone simulator on i386
* PKCS7 support for generating and verify bundles using a detached signature
* Fix for build disabling AES-CBC and enabling opensslextra compatibility layer
* Updates to sniffer for showing session information and handling split messages across records
* Port update for Micrium uC/OS-III
* Feature to adjust max fragment size post handshake when compiled with the macro WOLFSSL_ALLOW_MAX_FRAGMENT_ADJUST
* Adding the macro NO_MULTIBYTE_PRINT for compiling out special characters that embedded devices may have problems with
* Updates for Doxygen documentation, including PKCS #11 API and more
* Adding Intel QuickAssist v1.7 driver support for asynchronous crypto
* Adding Intel QuickAssist RSA key generation and SHA-3 support
* RSA verify only (--enable-rsavfy) and RSA public only (--enable-rsapub) builds added
* Enhancements to test cases for increased code coverage
* Updates to VxWorks port for use with Mongoose, including updates to the OpenSSL compatibility layer
* Yocto Project ease of use improvements along with many updates and build instructions added to the INSTALL file
* Maximum ticket nonce size was increased to 8
* Updating --enable-armasm build for ease of use with autotools
* Updates to internal code checking TLS 1.3 version with a connection
* Removing unnecessary extended master secret from ServerHello if using TLS 1.3
* Fix for TLS v1.3 HelloRetryRequest to be sent immediately and not grouped



This release of wolfSSL includes a fix for 1 security vulnerability.

Medium level fix for potential cache attack with a variant of Bleichenbacher’s attack. Earlier versions of wolfSSL leaked PKCS #1 v1.5 padding information during private key decryption that could lead to a potential padding oracle attack. It is recommended that users update to the latest version of wolfSSL if they have RSA cipher suites enabled and have the potential for malicious software to be ran on the same system that is performing RSA operations. Users that have only ECC cipher suites enabled and are not performing RSA PKCS #1 v1.5 Decryption operations are not vulnerable. Also users with TLS 1.3 only connections are not vulnerable to this attack. Thanks to Eyal Ronen (Weizmann Institute), Robert Gillham (University of Adelaide), Daniel Genkin (University of Michigan), Adi Shamir (Weizmann Institute), David Wong (NCC Group), and Yuval Yarom (University of Adelaide and Data61) for the report.

The paper for further reading on the attack details can be found at http://cat.eyalro.net/cat.pdf.


See INSTALL file for build instructions.
More info can be found on-line at http://wolfssl.com/wolfSSL/Docs.html


# wolfSSL Release 3.15.5 (11/07/2018)

Release 3.15.5 of wolfSSL embedded TLS has bug fixes and new features including:

* Fixes for GCC-8 warnings with strings
* Additional compatibility API’s added, including functions like wolfSSL_X509_CA_num and wolfSSL_PEM_read_X509_CRL
* Fixes for OCSP use with NGINX port
* Renamed the macro INLINE to WC_INLINE for inline functions
* Doxygen updates and formatting for documentation generation
* Added support for the STM32L4 with AES/SHA hardware acceleration
* Adds checking for critical extension with certificate Auth ID and the macro WOLFSSL_ALLOW_CRIT_SKID to override the check
* Added public key callbacks to ConfirmSignature function to expand public key callback support
* Added ECC and Curve25519 key generation callback support
* Fix for memory management with wolfSSL_BN_hex2bn function
* Added support for dynamic allocation of PKCS7 structure using wc_PKCS7_New and wc_PKCS7_Free
* Port to apache mynewt added in the directory wolfssl-3.15.5/IDE/mynewt/*
* OCSP stapling in TLS 1.3 additions
* Port for ASIO added with --enable-asio configure flag
* Contiki port added with macro WOLFSSL_CONTIKI
* Memory free optimizations with adding in earlier free’s where possible
* Made modifications to the primality testing so that the Miller-Rabin tests check against up to 40 random numbers rather than a fixed list of small primes
* Certificate validation time generation updated
* Fixes for MQX classic 4.0 with IAR-EWARM
* Fix for assembly optimized version of Curve25519
* Make SOCKET_PEER_CLOSED_E consistent between read and write cases
* Relocate compatibility layer functions for OpenSSH port update
* Update to Intel® SGX port, files included by Windows version and macros defined when using WOLFSSL_SGX
* Updates to Nucleus version supported
* Stack size reduction with smallstack build
* Updates to Rowley-Crossworks settings for CMSIS 4
* Added reference STSAFE-A100 public key callbacks for TLS support
* Added reference ATECC508A/ATECC608A public key callbacks for TLS support
* Updated support for latest CryptoAuthLib (10/25/2018)
* Added a wolfSSL static library project for Atollic TrueSTUDIO
* Flag to disable AES-CBC and have only AEAD cipher suites with TLS
* AF_ALG and cryptodev-linux crypto support added
* Update to IO callbacks with use of WOLFSSL_BIO
* Additional support for parsing certificate subject OIDs (businessCategory, jurisdiction of incorporation country, and jurisdiction of incorporation state)
* Added  wc_ecc_ecport_ex and wc_export_inti API's for ECC hex string exporting
* Updates to XCODE build with wolfSSL
* Fix for guard on when to include sys/time.h header
* Updates and enhancements to the GCC-ARM example
* Fix for PKCS8 padding with encryption
* Updates for wolfcrypt JNI wrapper
* ALT_ECC_SIZE use with SP math
* PIC32MZ hardware acceleration buffer alignment fixes
* Renesas e2studio project files added
* Renesas RX example project added
* Fix for DH algorithm when using SP math with ARM assembly
* Fixes and enhancements for NXP K82 support
* Benchmark enhancements to print in CSV format and in Japanese
* Support for PKCS#11 added with --enable-pkcs11
* Fixes for asynchronous crypto use with TLS 1.3
* TLS 1.3 only build, allows for disabling TLS 1.2 and earlier protocols
* Fix for GCC warnings in function wolfSSL_ASN1_TIME_adj
* Added --enable-asn=nocrypt for certificate only parsing support
* Added support for parsing PIV format certificates with the function wc_ParseCertPIV and macro WOLFSSL_CERT_PIV
* Added APIs to support GZIP
* Updates to support Lighttpd
* Version resource added for Windows DLL builds
* Increased code coverage with additional testing
* Added support for constructed OCTET_STRING with PKCS#7 signed data
* Added DTLS either (server/client) side initialization setting
* Minor fixes for building with MINGW32 compiler
* Added support for generic ECC PEM header/footer with PKCS8 parsing
* Added Japanese output to example server and client with “-1 1” flag
* Added USE_ECDSA_KEYSZ_HASH_ALGO macro for building to use digest sizes that match ephemeral key size
* Expand PKCS#7 CMS support with KEKRI, PWRI and ORI
* Streaming capability for PKCS#7 decoding and sign verify added


See INSTALL file for build instructions.
More info can be found on-line at http://wolfssl.com/wolfSSL/Docs.html


# wolfSSL Release 3.15.3 (6/20/2018)

Release 3.15.3 of wolfSSL embedded TLS has bug fixes and new features including:

* ECDSA blinding added for hardening against side channel attacks
* Fix for compatibility layer build with no server and no client defined
* Use of optimized Intel assembly instructions on compatible AMD processor
* wolfCrypt Nucleus port additions
* Fix added for MatchDomainName and additional tests added
* Fixes for building with ‘WOLFSSL_ATECC508A’ defined
* Fix for verifying a PKCS7 file in BER format with indefinite size


This release of wolfSSL fixes 2 security vulnerability fixes.

Medium level fix for PRIME + PROBE attack combined with a variant of Lucky 13. Constant time hardening was done to avoid potential cache-based side channel attacks when verifying the MAC on a TLS packet. CBC cipher suites are susceptible on systems where an attacker could gain access and run a parallel program for inspecting caching. Only wolfSSL users that are using TLS/DTLS CBC cipher suites need to update. Users that have only AEAD and stream cipher suites set, or have built with WOLFSSL_MAX_STRENGTH (--enable-maxstrength), are not vulnerable. Thanks to Eyal Ronen, Kenny Paterson, and Adi Shamir for the report.

Medium level fix for a ECDSA side channel attack. wolfSSL is one of over a dozen vendors mentioned in the recent Technical Advisory “ROHNP” by author Ryan Keegan. Only wolfSSL users with long term ECDSA private keys using our fastmath or normal math libraries on systems where attackers can get access to the machine using the ECDSA key need to update.  An attacker gaining access to the system could mount a memory cache side channel attack that could recover the key within a few thousand signatures. wolfSSL users that are not using ECDSA private keys, that are using the single precision math library, or that are using ECDSA offloading do not need to update. (blog with more information https://www.wolfssl.com/wolfssh-and-rohnp/)


See INSTALL file for build instructions.
More info can be found on-line at http://wolfssl.com/wolfSSL/Docs.html

# wolfSSL Release 3.15.0 (06/05/2018)

Release 3.15.0 of wolfSSL embedded TLS has bug fixes and new features including:

* Support for TLS 1.3 Draft versions 23, 26 and 28.
* Add FIPS SGX support!
* Single Precision assembly code added for ARM and 64-bit ARM to enhance performance.
* Improved performance for Single Precision maths on 32-bit.
* Improved downgrade support for the TLS 1.3 handshake.
* Improved TLS 1.3 support from interoperability testing.
* Added option to allow TLS 1.2 to be compiled out to reduce size and enhance security.
* Added option to support Ed25519 in TLS 1.2 and 1.3.
* Update wolfSSL_HMAC_Final() so the length parameter is optional.
* Various fixes for Coverity static analysis reports.
* Add define to use internal struct timeval (USE_WOLF_TIMEVAL_T).
* Switch LowResTimer() to call XTIME instead of time(0) for better portability.
* Expanded OpenSSL compatibility layer with a bevy of new functions.
* Added Renesas CS+ project files.
* Align DH support with NIST SP 800-56A, add wc_DhSetKey_ex() for q parameter.
* Add build option for CAVP self test build (--enable-selftest).
* Expose mp_toradix() when WOLFSSL_PUBLIC_MP is defined.
* Example certificate expiration dates and generation script updated.
* Additional optimizations to trim out unused strings depending on build options.
* Fix for DN tag strings to have “=” when returning the string value to users.
* Fix for wolfSSL_ERR_get_error_line_data return value if no more errors are in the queue.
* Fix for AES-CBC IV value with PIC32 hardware acceleration.
* Fix for wolfSSL_X509_print with ECC certificates.
* Fix for strict checking on URI absolute vs relative path.
* Added crypto device framework to handle PK RSA/ECC operations using callbacks, which adds new build option `./configure --enable-cryptodev` or `WOLF_CRYPTO_DEV`.
* Added devId support to ECC and PKCS7 for hardware based private key.
* Fixes in PKCS7 for handling possible memory leak in some error cases.
* Added test for invalid cert common name when set with `wolfSSL_check_domain_name`.
* Refactor of the cipher suite names to use single array, which contains internal name, IANA name and cipher suite bytes.
* Added new function `wolfSSL_get_cipher_name_from_suite` for getting IANA cipher suite name using bytes.
* Fixes for fsanitize reports.
* Fix for openssl compatibility function `wolfSSL_RSA_verify` to check returned size.
* Fixes and improvements for FreeRTOS AWS.
* Fixes for building openssl compatibility with FreeRTOS.
* Fix and new test for handling match on domain name that may have a null terminator inside.
* Cleanup of the socket close code used for examples, CRL/OCSP and BIO to use single macro `CloseSocket`.
* Refactor of the TLSX code to support returning error codes.
* Added new signature wrapper functions `wc_SignatureVerifyHash` and `wc_SignatureGenerateHash` to allow direct use of hash.
* Improvement to GCC-ARM IDE example.
* Enhancements and cleanups for the ASN date/time code including new API's `wc_GetDateInfo`, `wc_GetCertDates` and `wc_GetDateAsCalendarTime`.
* Fixes to resolve issues with C99 compliance. Added build option `WOLF_C99` to force C99.
* Added a new `--enable-opensslall` option to enable all openssl compatibility features.
* Added new `--enable-webclient` option for enabling a few HTTP API's.
* Added new `wc_OidGetHash` API for getting the hash type from a hash OID.
* Moved `wolfSSL_CertPemToDer`, `wolfSSL_KeyPemToDer`, `wolfSSL_PubKeyPemToDer` to asn.c and renamed to `wc_`. Added backwards compatibility macro for old function names.
* Added new `WC_MAX_SYM_KEY_SIZE` macro for helping determine max key size.
* Added `--enable-enckeys` or (`WOLFSSL_ENCRYPTED_KEYS`) to enable support for encrypted PEM private keys using password callback without having to use opensslextra.
* Added ForceZero on the password buffer after done using it.
* Refactor unique hash types to use same internal values (ex WC_MD5 == WC_HASH_TYPE_MD5).
* Refactor the Sha3 types to use `wc_` naming, while retaining old names for compatibility.
* Improvements to `wc_PBKDF1` to support more hash types and the non-standard extra data option.
* Fix TLS 1.3 with ECC disabled and CURVE25519 enabled.
* Added new define `NO_DEV_URANDOM` to disable the use of `/dev/urandom`.
* Added `WC_RNG_BLOCKING` to indicate block w/sleep(0) is okay.
* Fix for `HAVE_EXT_CACHE` callbacks not being available without `OPENSSL_EXTRA` defined.
* Fix for ECC max bits `MAX_ECC_BITS` not always calculating correctly due to macro order.
* Added support for building and using PKCS7 without RSA (assuming ECC is enabled).
* Fixes and additions for Cavium Nitrox V to support ECC, AES-GCM and HMAC (SHA-224 and SHA3).
* Enabled ECC, AES-GCM and SHA-512/384 by default in (Linux and Windows)
* Added `./configure --enable-base16` and `WOLFSSL_BASE16` configuration option to enable Base16 API's.
* Improvements to ATECC508A support for building without `WOLFSSL_ATMEL` defined.
* Refactor IO callback function names to use `_CTX_` to eliminate confusion about the first parameter.
* Added support for not loading a private key for server or client when `HAVE_PK_CALLBACK` is defined and the private PK callback is set.
* Added new ECC API `wc_ecc_sig_size_calc` to return max signature size for a key size.
* Cleanup ECC point import/export code and added new API `wc_ecc_import_unsigned`.
* Fixes for handling OCSP with non-blocking.
* Added new PK (Primary Key) callbacks for the VerifyRsaSign. The new callbacks API's are `wolfSSL_CTX_SetRsaVerifySignCb` and `wolfSSL_CTX_SetRsaPssVerifySignCb`.
* Added new ECC API `wc_ecc_rs_raw_to_sig` to take raw unsigned R and S and encodes them into ECDSA signature format.
* Added support for `WOLFSSL_STM32F1`.
* Cleanup of the ASN X509 header/footer and XSTRNCPY logic.
* Add copyright notice to autoconf files. (Thanks Brian Aker!)
* Updated the M4 files for autotools. (Thanks Brian Aker!)
* Add support for the cipher suite TLS_DH_anon_WITH_AES256_GCM_SHA384 with test cases. (Thanks Thivya Ashok!)
* Add the TLS alert message unknown_psk_identity (115) from RFC 4279, section 2. (Thanks Thivya Ashok!)
* Fix the case when using TCP with timeouts with TLS. wolfSSL shall be agnostic to network socket behavior for TLS. (DTLS is another matter.) The functions `wolfSSL_set_using_nonblock()` and `wolfSSL_get_using_nonblock()` are deprecated.
* Hush the AR warning when building the static library with autotools.
* Hush the “-pthread” warning when building in some environments.
* Added a dist-hook target to the Makefile to reset the default options.h file.
* Removed the need for the darwin-clang.m4 file with the updates provided by Brian A.
* Renamed the AES assembly file so GCC on the Mac will build it using the preprocessor.
* Add a disable option (--disable-optflags) to turn off the default optimization flags so user may supply their own custom flags.
* Correctly touch the dummy fips.h header.

If you have questions on any of this, then email us at facts@wolfssl.com.
See INSTALL file for build instructions.
More info can be found on-line at http://wolfssl.com/wolfSSL/Docs.html


# wolfSSL Release 3.14.0 (03/02/2018)

Release 3.14.0 of wolfSSL embedded TLS has bug fixes and new features including:

* TLS 1.3 draft 22 and 23 support added
* Additional unit tests for; SHA3, AES-CMAC, Ed25519, ECC, RSA-PSS, AES-GCM
* Many additions to the OpenSSL compatibility layer were made in this release. Some of these being enhancements to PKCS12, WOLFSSL_X509 use, WOLFSSL_EVP_PKEY, and WOLFSSL_BIO operations
* AVX1 and AVX2 performance improvements with ChaCha20 and Poly1305
* Added i.MX CAAM driver support with Integrity OS support
* Improvements to logging with debugging, including exposing more API calls and adding options to reduce debugging code size
* Fix for signature type detection with PKCS7 RSA SignedData
* Public key call back functions added for DH Agree
* RSA-PSS API added for operating on non inline buffers (separate input and output buffers)
* API added for importing and exporting raw DSA parameters
* Updated DSA key generation to be FIPS 186-4 compliant
* Fix for wolfSSL_check_private_key when comparing ECC keys
* Support for AES Cipher Feedback(CFB) mode added
* Updated RSA key generation to be FIPS 186-4 compliant
* Update added for the ARM CMSIS software pack
* WOLFSSL_IGNORE_FILE_WARN macro added for avoiding build warnings when not working with autotools
* Performance improvements for AES-GCM with AVX1 and AVX2
* Fix for possible memory leak on error case with wc_RsaKeyToDer function
* Make wc_PKCS7_PadData function available
* Updates made to building SGX on Linux
* STM32 hashing algorithm improvements including clock/power optimizations and auto detection of if SHA2 is supported
* Update static memory feature for FREERTOS use
* Reverse the order that certificates are compared during PKCS12 parse to account for case where multiple certificates have the same matching private key
* Update NGINX port to version 1.13.8
* Support for HMAC-SHA3 added
* Added stricter ASN checks to enforce RFC 5280 rules. Thanks to the report from Professor Zhenhua Duan, Professor Cong Tian, and Ph.D candidate Chu Chen from Institute of Computing Theory and Technology (ICTT) of Xidian University.
* Option to have ecc_mul2add function public facing
* Getter function wc_PKCS7_GetAttributeValue added for PKCS7 attributes
* Macros NO_AES_128, NO_AES_192, NO_AES_256 added for AES key size selection at compile time
* Support for writing multiple organizations units (OU) and domain components (DC) with CSR and certificate creation
* Support for indefinite length BER encodings in PKCS7
* Added API for additional validation of prime q in a public DH key
* Added support for RSA encrypt and decrypt without padding


See INSTALL file for build instructions.
More info can be found on-line at http://wolfssl.com/wolfSSL/Docs.html


# wolfSSL (Formerly CyaSSL) Release 3.13.0 (12/21/2017)

wolfSSL 3.13.0 includes bug fixes and new features, including support for
TLS 1.3 Draft 21, performance and footprint optimizations, build fixes,
updated examples and project files, and one vulnerability fix. The full list
of changes and additions in this release include:

* Fixes for TLS 1.3, support for Draft 21
* TLS 1.0 disabled by default, addition of “--enable-tlsv10” configure option
* New option to reduce SHA-256 code size at expense of performance
  (USE_SLOW_SHA256)
* New option for memory reduced build (--enable-lowresource)
* AES-GCM performance improvements on AVX1 (IvyBridge) and AVX2
* SHA-256 and SHA-512 performance improvements using AVX1/2 ASM
* SHA-3 size and performance optimizations
* Fixes for Intel AVX2 builds on Mac/OSX
* Intel assembly for Curve25519, and Ed25519 performance optimizations
* New option to force 32-bit mode with “--enable-32bit”
* New option to disable all inline assembly with “--disable-asm”
* Ability to override maximum signature algorithms using WOLFSSL_MAX_SIGALGO
* Fixes for handling of unsupported TLS extensions.
* Fixes for compiling AES-GCM code with GCC 4.8.*
* Allow adjusting static I/O buffer size with WOLFMEM_IO_SZ
* Fixes for building without a filesystem
* Removes 3DES and SHA1 dependencies from PKCS#7
* Adds ability to disable PKCS#7 EncryptedData type (NO_PKCS7_ENCRYPTED_DATA)
* Add ability to get client-side SNI
* Expanded OpenSSL compatibility layer
* Fix for logging file names with OpenSSL compatibility layer enabled, with
  WOLFSSL_MAX_ERROR_SZ user-overridable
* Adds static memory support to the wolfSSL example client
* Fixes for sniffer to use TLS 1.2 client method
* Adds option to wolfCrypt benchmark to benchmark individual algorithms
* Adds option to wolfCrypt benchmark to display benchmarks in powers
  of 10 (-base10)
* Updated Visual Studio for ARM builds (for ECC supported curves and SHA-384)
* Updated Texas Instruments TI-RTOS build
* Updated STM32 CubeMX build with fixes for SHA
* Updated IAR EWARM project files
* Updated Apple Xcode projects with the addition of a benchmark example project

This release of wolfSSL fixes 1 security vulnerability.

wolfSSL is cited in the recent ROBOT Attack by Böck, Somorovsky, and Young.
The paper notes that wolfSSL only gives a weak oracle without a practical
attack but this is still a flaw.  This release contains a fix for this report.
Please note that wolfSSL has static RSA cipher suites disabled by default as
of version 3.6.6 because of the lack of perfect forward secrecy.  Only users
who have explicitly enabled static RSA cipher suites with WOLFSSL_STATIC_RSA
and use those suites on a host are affected.  More information will be
available on our website at:

https://wolfssl.com/wolfSSL/security/vulnerabilities.php

See INSTALL file for build instructions.
More info can be found on-line at http://wolfssl.com/wolfSSL/Docs.html


# wolfSSL (Formerly CyaSSL) Release 3.12.2 (10/23/2017)

## Release 3.12.2 of wolfSSL has bug fixes and new features including:

This release includes many performance improvements with Intel ASM (AVX/AVX2) and AES-NI. New single precision math option to speedup RSA, DH and ECC. Embedded hardware support has been expanded for STM32, PIC32MZ and ATECC508A. AES now supports XTS mode for disk encryption. Certificate improvements for setting serial number, key usage and extended key usage. Refactor of SSL_ and hash types to allow openssl coexistence. Improvements for TLS 1.3. Fixes for OCSP stapling to allow disable and WOLFSSL specific user context for callbacks. Fixes for openssl and MySQL compatibility. Updated Micrium port. Fixes for asynchronous modes.

* Added TLS extension for Supported Point Formats (ec_point_formats)
* Fix to not send OCSP stapling extensions in client_hello when not enabled
* Added new API's for disabling OCSP stapling
* Add check for SIZEOF_LONG with sun and LP64
* Fixes for various TLS 1.3 disable options (RSA, ECC and ED/Curve 25519).
* Fix to disallow upgrading to TLS v1.3
* Fixes for wolfSSL_EVP_CipherFinal() when message size is a round multiple of a block size.
* Add HMAC benchmark and expanded AES key size benchmarks
* Added simple GCC ARM Makefile example
* Add tests for 3072-bit RSA and DH.
* Fixed DRAFT_18 define and fixed downgrading with TLS v1.3
* Fixes to allow custom serial number during certificate generation
* Add method to get WOLFSSL_CTX certificate manager
* Improvement to `wolfSSL_SetOCSP_Cb` to allow context per WOLFSSL object
* Alternate certificate chain support `WOLFSSL_ALT_CERT_CHAINS`. Enables checking cert against multiple CA's.
* Added new `--disable-oldnames` option to allow for using openssl along-side wolfssl headers (without OPENSSL_EXTRA).
* Refactor SSL_ and hashing types to use wolf specific prefix (WOLFSSL and WC_) to allow openssl coexistence.
* Fixes for HAVE_INTEL_MULX
* Cleanup include paths for MySQL cmake build
* Added configure option for building library for wolfSSH (--enable-wolfssh)
* Openssl compatibility layer improvements
* Expanded API unit tests
* Fixes for STM32 crypto hardware acceleration
* Added AES XTS mode (--enable-xts)
* Added ASN Extended Key Usage Support (see wc_SetExtKeyUsage).
* Math updates and added TFM_MIPS speedup.
* Fix for creation of the KeyUsage BitString
* Fix for 8k keys with MySQL compatibility
* Fixes for ATECC508A.
* Fixes for PIC32MZ hashing.
* Fixes and improvements to asynchronous modes for Intel QuickAssist and Cavium Nitrox V.
* Update HASH_DRBG Reseed mechanism and add test case
* Rename the file io.h/io.c to wolfio.h/wolfio.c
* Cleanup the wolfIO_Send function.
* OpenSSL Compatibility Additions and Fixes
* Improvements to Visual Studio DLL project/solution.
* Added function to generate public ECC key from private key
* Added async blocking support for sniffer tool.
* Added wolfCrypt hash tests for empty string and large data.
* Added ability to use of wolf implementation of `strtok` using `USE_WOLF_STRTOK`.
* Updated Micrium uC/OS-III Port
* Updated root certs for OCSP scripts
* New Single Precision math option for RSA, DH and ECC (off by default). See `--enable-sp`.
* Speedups for AES GCM with AESNI (--enable-aesni)
* Speedups for SHA2, ChaCha20/Poly1035 using AVX/AVX2


# wolfSSL (Formerly CyaSSL) Release 3.12.0 (8/04/2017)

## Release 3.12.0 of wolfSSL has bug fixes and new features including:

- TLS 1.3 with Nginx! TLS 1.3 with ARMv8! TLS 1.3 with Async Crypto! (--enable-tls13)
- TLS 1.3 0RTT feature added
- Added port for using Intel SGX with Linux
- Update and fix PIC32MZ port
- Additional unit testing for MD5, SHA, SHA224, SHA256, SHA384, SHA512, RipeMd, HMAC, 3DES, IDEA, ChaCha20, ChaCha20Poly1305 AEAD, Camellia, Rabbit, ARC4, AES, RSA, Hc128
- AVX and AVX2 assembly for improved ChaCha20 performance
- Intel QAT fixes for when using --disable-fastmath
- Update how DTLS handles decryption and MAC failures
- Update DTLS session export version number for --enable-sessionexport feature
- Add additional input argument sanity checks to ARMv8 assembly port
- Fix for making PKCS12 dynamic types match
- Fixes for potential memory leaks when using --enable-fast-rsa
- Fix for when using custom ECC curves and add BRAINPOOLP256R1 test
- Update TI-RTOS port for dependency on new wolfSSL source files
- DTLS multicast feature added, --enable-mcast
- Fix for Async crypto with GCC 7.1 and HMAC when not using Intel QuickAssist
- Improvements and enhancements to Intel QuickAssist support
- Added Xilinx port
- Added SHA3 Keccak feature, --enable-sha3
- Expand wolfSSL Python wrapper to now include a client side implementation
- Adjust example servers to not treat a peer closed error as a hard error
- Added more sanity checks to fp_read_unsigned_bin function
- Add SHA224 and AES key wrap to ARMv8 port
- Update MQX classics and mmCAU ports
- Fix for potential buffer over read with wolfSSL_CertPemToDer
- Add PKCS7/CMS decode support for KARI with IssuerAndSerialNumber
- Fix ThreadX/NetX warning
- Fixes for OCSP and CRL non blocking sockets and for incomplete cert chain with OCSP
- Added RSA PSS sign and verify
- Fix for STM32F4 AES-GCM
- Added enable all feature (--enable-all)
- Added trackmemory feature (--enable-trackmemory)
- Fixes for AES key wrap and PKCS7 on Windows VS
- Added benchmark block size argument
- Support use of staticmemory with PKCS7
- Fix for Blake2b build with GCC 5.4
- Fixes for compiling wolfSSL with GCC version 7, most dealing with switch statement fall through warnings.
- Added warning when compiling without hardened math operations


Note:
There is a known issue with using ChaCha20 AVX assembly on versions of GCC earlier than 5.2. This is encountered with using the wolfSSL enable options --enable-intelasm and --enable-chacha. To avoid this issue ChaCha20 can be enabled with --enable-chacha=noasm.
If using --enable-intelasm and also using --enable-sha224 or --enable-sha256 there is a known issue with trying to use -fsanitize=address.

This release of wolfSSL fixes 1 low level security vulnerability.

Low level fix for a potential DoS attack on a wolfSSL client. Previously a client would accept many warning alert messages without a limit. This fix puts a limit to the number of warning alert messages received and if this limit is reached a fatal error ALERT_COUNT_E is returned. The max number of warning alerts by default is set to 5 and can be adjusted with the macro WOLFSSL_ALERT_COUNT_MAX. Thanks for the report from Tarun Yadav and Koustav Sadhukhan from Defence Research and Development Organization, INDIA.


See INSTALL file for build instructions.
More info can be found on-line at http://wolfssl.com/wolfSSL/Docs.html


# wolfSSL (Formerly CyaSSL) Release 3.11.1 (5/11/2017)

## Release 3.11.1 of wolfSSL is a TLS 1.3 BETA release, which includes:

- TLS 1.3 client and server support for TLS 1.3 with Draft 18 support

This is strictly a BETA release, and designed for testing and user feedback.
Please send any comments, testing results, or feedback to wolfSSL at
support@wolfssl.com.

See INSTALL file for build instructions.
More info can be found on-line at http://wolfssl.com/wolfSSL/Docs.html


# wolfSSL (Formerly CyaSSL) Release 3.11.0 (5/04/2017)

## Release 3.11.0 of wolfSSL has bug fixes and new features including:

- Code updates for warnings reported by Coverity scans
- Testing and warning fixes for FreeBSD on PowerPC
- Updates and refactoring done to ASN1 parsing functions
- Change max PSK identity buffer to account for an identity length of 128 characters
- Update Arduino script to handle recent files and additions
- Added support for PKCS#7 Signed Data with ECDSA
- Fix for interoperability with ChaCha20-Poly1305 suites using older draft versions
- DTLS update to allow multiple handshake messages in one DTLS record. Thanks to Eric Samsel over at Welch Allyn for reporting this bug.
- Intel QuickAssist asynchronous support (PR #715 - https://www.wolfssl.com/wolfSSL/Blog/Entries/2017/1/18_wolfSSL_Asynchronous_Intel_QuickAssist_Support.html)
- Added support for HAproxy load balancer
- Added option to allow SHA1 with TLS 1.2 for IIS compatibility (WOLFSSL_ALLOW_TLS_SHA1)
- Added Curve25519 51-bit Implementation, increasing performance on systems that have 128 bit types
- Fix to not send session ID on server side if session cache is off unless we're echoing
session ID as part of session tickets
- Fixes for ensuring all default ciphers are setup correctly (see PR #830)
- Added NXP Hexiwear example in `IDE/HEXIWEAR`.
- Added wolfSSL_write_dup() to create write only WOLFSSL object for concurrent access
- Fixes for TLS elliptic curve selection on private key import.
- Fixes for RNG with Intel rdrand and rdseed speedups.
- Improved performance with Intel rdrand to use full 64-bit output
- Added new --enable-intelrand option to indicate use of RDRAND preference for RNG source
- Removed RNG ARC4 support
- Added ECC helpers to get size and id from curve name.
- Added ECC Cofactor DH (ECC-CDH) support
- Added ECC private key only import / export functions.
- Added PKCS8 create function
- Improvements to TLS layer CTX handling for switching keys / certs.
- Added check for duplicate certificate policy OID in certificates.
- Normal math speed-up to not allocate on mp_int and defer until mp_grow
- Reduce heap usage with fast math when not using ALT_ECC_SIZE
- Fixes for building CRL with Windows
- Added support for inline CRL lookup when HAVE_CRL_IO is defined
- Added port for tenAsys INtime RTOS
- Improvements to uTKernel port (WOLFSSL_uTKERNEL2)
- Updated WPA Supplicant support
- Added support for Nginx
- Update stunnel port for version 5.40
- Fixes for STM32 hardware crypto acceleration
- Extended test code coverage in bundled test.c
- Added a sanity check for minimum authentication tag size with AES-GCM. Thanks to Yueh-Hsun Lin and Peng Li at KNOX Security at Samsung Research America for suggesting this.
- Added a sanity check that subject key identifier is marked as non-critical and a check that no policy OIDS appear more than once in the cert policies extension. Thanks to the report from Professor Zhenhua Duan, Professor Cong Tian, and Ph.D candidate Chu Chen from Institute of Computing Theory and Technology (ICTT) of Xidian University, China. Profs. Zhenhua Duan and Cong Tian are supervisors of Ph.D candidate Chu Chen.

This release of wolfSSL fixes 5 low and 1 medium level security vulnerability.

3 Low level fixes reported by Yueh-Hsun Lin and Peng Li from KNOX Security, Samsung Research America.
- Fix for out of bounds memory access in wc_DhParamsLoad() when GetLength() returns a zero. Before this fix there is a case where wolfSSL would read out of bounds memory in the function wc_DhParamsLoad.
- Fix for DH key accepted by wc_DhAgree when the key was malformed.
- Fix for a double free case when adding CA cert into X509_store.

Low level fix for memory management with static memory feature enabled. By default static memory is disabled. Thanks to GitHub user hajjihraf for reporting this.


Low level fix for out of bounds write in the function wolfSSL_X509_NAME_get_text_by_NID. This function is not used by TLS or crypto operations but could result in a buffer out of bounds write by one if called explicitly in an application. Discovered by Aleksandar Nikolic of Cisco Talos. http://talosintelligence.com/vulnerability-reports/

Medium level fix for check on certificate signature. There is a case in release versions 3.9.10, 3.10.0 and 3.10.2 where a corrupted signature on a peer certificate would not be properly flagged. Thanks to Wens Lo, James Tsai, Kenny Chang, and Oscar Yang at Castles Technology.


See INSTALL file for build instructions.
More info can be found on-line at http://wolfssl.com/wolfSSL/Docs.html


# wolfSSL (Formerly CyaSSL) Release 3.10.2 (2/10/2017)

## Release 3.10.2 of wolfSSL has bug fixes and new features including:

- Poly1305 Windows macros fix. Thanks to GitHub user Jay Satiro
- Compatibility layer expanded with multiple functions added
- Improve fp_copy performance with ALT_ECC_SIZE
- OCSP updates and improvements
- Fixes for IAR EWARM 8 compiler warnings
- Reduce stack usage with ECC_CACHE_CURVE disabled
- Added ECC export raw for public and private key
- Fix for NO_ASN_TIME build
- Supported curves extensions now populated by default
- Add DTLS build without big integer math
- Fix for static memory feature with wc_ecc_verify_hash_ex and not SHAMIR
- Added PSK interoperability testing to script bundled with wolfSSL
- Fix for Python wrapper random number generation. Compiler optimizations with Python could place the random number in same buffer location each time. Thanks to GitHub user Erik Bray (embray)
- Fix for tests on unaligned memory with static memory feature
- Add macro WOLFSSL_NO_OCSP_OPTIONAL_CERTS to skip optional OCSP certificates
- Sanity checks on NULL arguments added to wolfSSL_set_fd and wolfSSL_DTLS_SetCookieSecret
- mp_jacobi stack use reduced, thanks to Szabi Tolnai for providing a solution to reduce stack usage


This release of wolfSSL fixes 2 low and 1 medium level security vulnerability.

Low level fix of buffer overflow for when loading in a malformed temporary DH file. Thanks to Yueh-Hsun Lin and Peng Li from KNOX Security, Samsung Research America for the report.

Medium level fix for processing of OCSP response. If using OCSP without hard faults enforced and no alternate revocation checks like OCSP stapling then it is recommended to update.

Low level fix for potential cache attack on RSA operations. If using wolfSSL RSA on a server that other users can have access to monitor the cache, then it is recommended to update wolfSSL. Thanks to Andreas Zankl, Johann Heyszl and Georg Sigl at Fraunhofer AISEC for the initial report.

See INSTALL file for build instructions.
More info can be found on-line at http://wolfssl.com/wolfSSL/Docs.html


# wolfSSL (Formerly CyaSSL) Release 3.10.0 (12/21/2016)

## Release 3.10.0 of wolfSSL has bug fixes and new features including:

- Added support for SHA224
- Added scrypt feature
- Build for Intel SGX use, added in directory IDE/WIN-SGX
- Fix for ChaCha20-Poly1305 ECDSA certificate type request
- Enhance PKCS#7 with ECC enveloped data and AES key wrap support
- Added support for RIOT OS
- Add support for parsing PKCS#12 files
- ECC performance increased with custom curves
- ARMv8 expanded to AArch32 and performance increased
- Added ANSI-X9.63-KDF support
- Port to STM32 F2/F4 CubeMX
- Port to Atmel ATECC508A board
- Removed fPIE by default when wolfSSL library is compiled
- Update to Python wrapper, dropping DES and adding wc_RSASetRNG
- Added support for NXP K82 hardware acceleration
- Added SCR client and server verify check
- Added a disable rng option with autoconf
- Added more tests vectors to test.c with AES-CTR
- Updated DTLS session export version number
- Updated DTLS for 64 bit sequence numbers
- Fix for memory management with TI and WOLFSSL_SMALL_STACK
- Hardening RSA CRT to be constant time
- Fix uninitialized warning with IAR compiler
- Fix for C# wrapper example IO hang on unexpected connection termination


This release of wolfSSL fixes a low level security vulnerability. The vulnerability reported was a potential cache attack on RSA operations. If using wolfSSL RSA on a server that other users can have access to monitor the cache, then it is recommended to update wolfSSL. Thanks to Andreas Zankl, Johann Heyszl and Georg Sigl at Fraunhofer AISEC for the report. More information will be available on our site:

https://wolfssl.com/wolfSSL/security/vulnerabilities.php

See INSTALL file for build instructions.
More info can be found on-line at http://wolfssl.com/wolfSSL/Docs.html


# wolfSSL (Formerly CyaSSL) Release 3.9.10 (9/23/2016)

## Release 3.9.10 of wolfSSL has bug fixes and new features including:

- Default configure option changes:
  1. DES3 disabled by default
  2. ECC Supported Curves Extension enabled by default
  3. New option Extended Master Secret enabled by default
- Added checking CA certificate path length, and new test certs
- Fix to DSA pre padding and sanity check on R/S values
- Added CTX level RNG for single-threaded builds
- Intel RDSEED enhancements
- ARMv8 hardware acceleration support for AES-CBC/CTR/GCM, SHA-256
- Arduino support updates
- Added the Extended Master Secret TLS extension
  1. Enabled by default in configure options, API to disable
  2. Added support for Extended Master Secret to sniffer
- OCSP fix with issuer key hash, lookup refactor
- Added support for Frosted OS
- Added support for DTLS over SCTP
- Added support for static memory with wolfCrypt
- Fix to ECC Custom Curve support
- Support for asynchronous wolfCrypt RSA and TLS client
- Added distribution build configure option
- Update the test certificates

This release of wolfSSL fixes medium level security vulnerabilities.  Fixes for
potential AES, RSA, and ECC side channel leaks is included that a local user
monitoring the same CPU core cache could exploit.  VM users, hyper-threading
users, and users where potential attackers have access to the CPU cache will
need to update if they utilize AES, RSA private keys, or ECC private keys.
Thanks to Gorka Irazoqui Apecechea and Xiaofei Guo from Intel Corporation for
the report.  More information will be available on our site:

https://wolfssl.com/wolfSSL/security/vulnerabilities.php

See INSTALL file for build instructions.
More info can be found on-line at https://wolfssl.com/wolfSSL/Docs.html


# wolfSSL (Formerly CyaSSL) Release 3.9.8 (7/29/2016)

##Release 3.9.8 of wolfSSL has bug fixes and new features including:

- Add support for custom ECC curves.
- Add cipher suite ECDHE-ECDSA-AES128-CCM.
- Add compkey enable option. This option is for compressed ECC keys.
- Add in the option to use test.h without gettimeofday function using the macro
  WOLFSSL_USER_CURRTIME.
- Add RSA blinding for private key operations. Enable option of harden which is
  on by default. This negates timing attacks.
- Add ECC and TLS support for all SECP, Koblitz and Brainpool curves.
- Add helper functions for static memory option to allow getting optimum buffer
  sizes.
- Update DTLS behavior on bad MAC. DTLS silently drops packets with bad MACs now.
- Update fp_isprime function from libtom enhancement/cleanup repository.
- Update sanity checks on inputs and return values for AES-CMAC.
- Update wolfSSL for use with MYSQL v5.6.30.
- Update LPCXpresso eclipse project to not include misc.c when not needed.
- Fix retransmit of last DTLS flight with timeout notification. The last flight
  is no longer retransmitted on timeout.
- Fixes to some code in math sections for compressed ECC keys. This includes
  edge cases for buffer size on allocation and adjustments for compressed curves
  build. The code and full list can be found on github with pull request #456.
- Fix function argument mismatch for build with secure renegotiation.
- X.509 bug fixes for reading in malformed certificates, reported by researchers
  at Columbia University
- Fix GCC version 6 warning about hard tabs in poly1305.c. This was a warning
  produced by GCC 6 trying to determine the intent of code.
- Fixes for static memory option. Including avoid potential race conditions with
  counters, decrement handshake counter correctly.
- Fix anonymous cipher with Diffie Hellman on the server side. Was an issue of a
  possible buffer corruption. For information and code see pull request #481.


- One high level security fix that requires an update for use with static RSA
  cipher suites was submitted. This fix was the addition of RSA blinding for
  private RSA operations. We recommend servers who allow static RSA cipher
  suites to also generate new private RSA keys. Static RSA cipher suites are
  turned off by default.

See INSTALL file for build instructions.
More info can be found on-line at //http://wolfssl.com/wolfSSL/Docs.html

# wolfSSL (Formerly CyaSSL) Release 3.9.6 (6/14/2016)

##Release 3.9.6 of wolfSSL has bug fixes and new features including:

- Add staticmemory feature
- Add public wc_GetTime API with base64encode feature
- Add AES CMAC algorithm
- Add DTLS sessionexport feature
- Add python wolfCrypt wrapper
- Add ECC encrypt/decrypt benchmarks
- Add dynamic session tickets
- Add eccshamir option
- Add Whitewood netRandom support --with-wnr
- Add embOS port
- Add minimum key size checks for RSA and ECC
- Add STARTTLS support to examples
- Add uTasker port
- Add asynchronous crypto and wolf event support
- Add compile check for misc.c with inline
- Add RNG benchmark
- Add reduction to stack usage with hash-based RNG
- Update STM32F2_CRYPTO port with additional algorithms supported
- Update MDK5 projects
- Update AES-NI
- Fix for STM32 with STM32F2_HASH defined
- Fix for building with MinGw
- Fix ECC math bugs with ALT_ECC_SIZE and key sizes over 256 bit (1)
- Fix certificate buffers github issue #422
- Fix decrypt max size with RSA OAEP
- Fix DTLS sanity check with DTLS timeout notification
- Fix free of WOLFSSL_METHOD on failure to create CTX
- Fix memory leak in failure case with wc_RsaFunction (2)

- No high level security fixes that requires an update though we always
recommend updating to the latest
- (1) Code changes for ECC fix can be found at pull requests #411, #416, and #428
- (2) Builds using RSA with using normal math and not RSA_LOW_MEM should update

See INSTALL file for build instructions.
More info can be found on-line at //http://wolfssl.com/wolfSSL/Docs.html

# wolfSSL (Formerly CyaSSL) Release 3.9.0 (03/18/2016)

##Release 3.9.0 of wolfSSL has bug fixes and new features including:

- Add new leantls configuration
- Add RSA OAEP padding at wolfCrypt level
- Add Arduino port and example client
- Add fixed point DH operation
- Add CUSTOM_RAND_GENRATE_SEED_OS and CUSTOM_RAND_GENERATE_BLOCK
- Add ECDHE-PSK cipher suites
- Add PSK ChaCha20-Poly1305 cipher suites
- Add option for fail on no peer cert except PSK suites
- Add port for Nordic nRF51
- Add additional ECC NIST test vectors for 256, 384 and 521
- Add more granular ECC, Ed25519/Curve25519 and AES configs
- Update to ChaCha20-Poly1305
- Update support for Freescale KSDK 1.3.0
- Update DER buffer handling code, refactoring and reducing memory
- Fix to AESNI 192 bit key expansion
- Fix to C# wrapper character encoding
- Fix sequence number issue with DTLS epoch 0 messages
- Fix RNGA with K64 build
- Fix ASN.1 X509 V3 certificate policy extension parsing
- Fix potential free of uninitialized RSA key in asn.c
- Fix potential underflow when using ECC build with FP_ECC
- Fixes for warnings in Visual Studio 2015 build

- No high level security fixes that requires an update though we always
recommend updating to the latest
- FP_ECC is off by default, users with it enabled should update for the zero
sized hash fix

See INSTALL file for build instructions.
More info can be found on-line at //http://wolfssl.com/yaSSL/Docs.html

# wolfSSL (Formerly CyaSSL) Release 3.8.0 (12/30/2015)

##Release 3.8.0 of wolfSSL has bug fixes and new features including:

- Example client/server with VxWorks
- AESNI use with AES-GCM
- Stunnel compatibility enhancements
- Single shot hash and signature/verify API added
- Update cavium nitrox port
- LPCXpresso IDE support added
- C# wrapper to support wolfSSL use by a C# program
- (BETA version)OCSP stapling added
- Update OpenSSH compatibility
- Improve DTLS handshake when retransmitting finished message
- fix idea_mult() for 16 and 32bit systems
- fix LowResTimer on Microchip ports

- No high level security fixes that requires an update though we always
recommend updating to the latest

See INSTALL file for build instructions.
More info can be found on-line at //http://wolfssl.com/yaSSL/Docs.html

# wolfSSL (Formerly CyaSSL) Release 3.7.0 (10/26/2015)

##Release 3.7.0 of wolfSSL has bug fixes and new features including:

- ALPN extension support added for HTTP2 connections with --enable-alpn
- Change of example/client/client max fragment flag -L -> -F
- Throughput benchmarking, added scripts/benchmark.test
- Sniffer API ssl_FreeDecodeBuffer added
- Addition of AES_GCM to Sniffer
- Sniffer change to handle unlimited decrypt buffer size
- New option for the sniffer where it will try to pick up decoding after a
  sequence number acknowldgement fault. Also includes some additional stats.
- JNI API setter and getter function for jobject added
- User RSA crypto plugin abstraction. An example placed in wolfcrypt/user-crypto
- fix to asn configuration bug
- AES-GCM/CCM fixes.
- Port for Rowley added
- Rowley Crossworks bare metal examples added
- MDK5-ARM project update
- FreeRTOS support updates.
- VXWorks support updates.
- Added the IDEA cipher and support in wolfSSL.
- Update wolfSSL website CA.
- CFLAGS is usable when configuring source.

- No high level security fixes that requires an update though we always
recommend updating to the latest

See INSTALL file for build instructions.
More info can be found on-line at //http://wolfssl.com/yaSSL/Docs.html

#wolfSSL (Formerly CyaSSL) Release 3.6.8 (09/17/2015)

##Release 3.6.8 of wolfSSL fixes two high severity vulnerabilities.
##It also includes bug fixes and new features including:

- Two High level security fixes, all users SHOULD update.
  a) If using wolfSSL for DTLS on the server side of a publicly accessible
     machine you MUST update.
  b) If using wolfSSL for TLS on the server side with private RSA keys allowing
     ephemeral key exchange without low memory optimizations you MUST update and
     regenerate the private RSA keys.

     Please see https://www.wolfssl.com/wolfSSL/Blog/Blog.html for more details

- No filesystem build fixes for various configurations
- Certificate generation now supports several extensions including KeyUsage,
    SKID, AKID, and Certificate Policies
- CRLs can be loaded from buffers as well as files now
- SHA-512 Certificate Signing generation
- Fixes for sniffer reassembly processing

See INSTALL file for build instructions.
More info can be found on-line at //http://wolfssl.com/yaSSL/Docs.html

#wolfSSL (Formerly CyaSSL) Release 3.6.6 (08/20/2015)

##Release 3.6.6 of wolfSSL has bug fixes and new features including:

- OpenSSH  compatibility with --enable-openssh
- stunnel  compatibility with --enable-stunnel
- lighttpd compatibility with --enable-lighty
- SSLv3 is now disabled by default, can be enabled with --enable-sslv3
- Ephemeral key cipher suites only are now supported by default
    To enable static ECDH cipher suites define WOLFSSL_STATIC_DH
    To enable static  RSA cipher suites define WOLFSSL_STATIC_RSA
    To enable static  PSK cipher suites define WOLFSSL_STATIC_PSK
- Added QSH (quantum-safe handshake) extension with --enable-ntru
- SRP is now part of wolfCrypt, enable with --enabe-srp
- Certificate handshake messages can now be sent fragmented if the record
  size is smaller than the total message size, no user action required.
- DTLS duplicate message fixes
- Visual Studio project files now support DLL and static builds for 32/64bit.
- Support for new Freesacle I/O
- FreeRTOS FIPS support

- No high level security fixes that requires an update though we always
  recommend updating to the latest

See INSTALL file for build instructions.
More info can be found on-line at //http://wolfssl.com/yaSSL/Docs.html


#wolfSSL (Formerly CyaSSL) Release 3.6.0 (06/19/2015)

##Release 3.6.0 of wolfSSL has bug fixes and new features including:

- Max Strength build that only allows TLSv1.2, AEAD ciphers, and PFS (Perfect
   Forward Secrecy).  With --enable-maxstrength
- Server side session ticket support, the example server and echosever use the
   example callback myTicketEncCb(), see wolfSSL_CTX_set_TicketEncCb()
- FIPS version submitted for iOS.
- TI Crypto Hardware Acceleration
- DTLS fragmentation fixes
- ECC key check validation with wc_ecc_check_key()
- 32bit code options to reduce memory for Curve25519 and Ed25519
- wolfSSL JNI build switch with --enable-jni
- PicoTCP support improvements
- DH min ephemeral key size enforcement with wolfSSL_CTX_SetMinDhKey_Sz()
- KEEP_PEER_CERT and AltNames can now be used together
- ChaCha20 big endian fix
- SHA-512 signature algorithm support for key exchange and verify messages
- ECC make key crash fix on RNG failure, ECC users must update.
- Improvements to usage of time code.
- Improvements to VS solution files.
- GNU Binutils 2.24 ld has problems with some debug builds, to fix an ld error
  add -fdebug-types-section to C_EXTRA_FLAGS

- No high level security fixes that requires an update though we always
  recommend updating to the latest (except note 14, ecc RNG failure)

See INSTALL file for build instructions.
More info can be found on-line at //http://wolfssl.com/yaSSL/Docs.html


#wolfSSL (Formerly CyaSSL) Release 3.4.8 (04/06/2015)

##Release 3.4.8 of wolfSSL has bug fixes and new features including:

- FIPS version submitted for iOS.
- Max Strength build that only allows TLSv1.2, AEAD ciphers, and PFS.
- Improvements to usage of time code.
- Improvements to VS solution files.

See INSTALL file for build instructions.
More info can be found on-line at //http://wolfssl.com/yaSSL/Docs.html


#wolfSSL (Formerly CyaSSL) Release 3.4.6 (03/30/2015)

##Release 3.4.6 of wolfSSL has bug fixes and new features including:

- Intel Assembly Speedups using instructions rdrand, rdseed, aesni, avx1/2,
  rorx, mulx, adox, adcx .  They can be enabled with --enable-intelasm.
  These speedup the use of RNG, SHA2, and public key algorithms.
- Ed25519 support at the crypto level. Turn on with --enable-ed25519.  Examples
  in wolcrypt/test/test.c ed25519_test().
- Post Handshake Memory reductions.  wolfSSL can now hold less than 1,000 bytes
  of memory per secure connection including cipher state.
- wolfSSL API and wolfCrypt API fixes, you can still include the cyassl and
  ctaocrypt headers which will enable the compatibility APIs for the
  foreseeable future
- INSTALL file to help direct users to build instructions for their environment
- For ECC users with the normal math library a fix that prevents a crash when
  verify signature fails.  Users of 3.4.0 with ECC and the normal math library
  must update
- RC4 is now disabled by default in autoconf mode
- AES-GCM and ChaCha20/Poly1305 are now enabled by default to make AEAD ciphers
  available without a switch
- External ChaCha-Poly AEAD API, thanks to Andrew Burks for the contribution
- DHE-PSK cipher suites can now be built without ASN or Cert support
- Fix some NO MD5 build issues with optional features
- Freescale CodeWarrior project updates
- ECC curves can be individually turned on/off at build time.
- Sniffer handles Cert Status message and other minor fixes
- SetMinVersion() at the wolfSSL Context level instead of just SSL session level
  to allow minimum protocol version allowed at runtime
- RNG failure resource cleanup fix

- No high level security fixes that requires an update though we always
  recommend updating to the latest (except note 6 use case of ecc/normal math)

See INSTALL file for build instructions.
More info can be found on-line at //http://wolfssl.com/yaSSL/Docs.html


#wolfSSL (Formerly CyaSSL) Release 3.4.0 (02/23/2015)

## Release 3.4.0 wolfSSL has bug fixes and new features including:

- wolfSSL API and wolfCrypt API, you can still include the cyassl and ctaocrypt
  headers which will enable the compatibility APIs for the foreseeable future
- Example use of the wolfCrypt API can be found in wolfcrypt/test/test.c
- Example use of the wolfSSL API can be found in examples/client/client.c
- Curve25519 now supported at the wolfCrypt level, wolfSSL layer coming soon
- Improvements in the build configuration under AIX
- Microchip Pic32 MZ updates
- TIRTOS updates
- PowerPC updates
- Xcode project update
- Bidirectional shutdown examples in client/server with -w (wait for full
  shutdown) option
- Cycle counts on benchmarks for x86_64, more coming soon
- ALT_ECC_SIZE for reducing ecc heap use with fastmath when also using large RSA
  keys
- Various compile warnings
- Scan-build warning fixes
- Changed a memcpy to memmove in the sniffer (if using sniffer please update)
- No high level security fixes that requires an update though we always
  recommend updating to the latest


# CyaSSL Release 3.3.0 (12/05/2014)

- Countermeasuers for Handshake message duplicates, CHANGE CIPHER without
  FINISHED, and fast forward attempts.  Thanks to Karthikeyan Bhargavan from
  the Prosecco team at INRIA Paris-Rocquencourt for the report.
- FIPS version submitted
- Removes SSLv2 Client Hello processing, can be enabled with OLD_HELLO_ALLOWED
- User can set minimum downgrade version with CyaSSL_SetMinVersion()
- Small stack improvements at TLS/SSL layer
- TLS Master Secret generation and Key Expansion are now exposed
- Adds client side Secure Renegotiation, * not recommended *
- Client side session ticket support, not fully tested with Secure Renegotiation
- Allows up to 4096bit DHE at TLS Key Exchange layer
- Handles non standard SessionID sizes in Hello Messages
- PicoTCP Support
- Sniffer now supports SNI Virtual Hosts
- Sniffer now handles non HTTPS protocols using STARTTLS
- Sniffer can now parse records with multiple messages
- TI-RTOS updates
- Fix for ColdFire optimized fp_digit read only in explicit 32bit case
- ADH Cipher Suite ADH-AES128-SHA for EAP-FAST

The CyaSSL manual is available at:
http://www.wolfssl.com/documentation/CyaSSL-Manual.pdf.  For build instructions
and comments about the new features please check the manual.


# CyaSSL Release 3.2.0 (09/10/2014)

#### Release 3.2.0 CyaSSL has bug fixes and new features including:

- ChaCha20 and Poly1305 crypto and suites
- Small stack improvements for OCSP, CRL, TLS, DTLS
- NTRU Encrypt and Decrypt benchmarks
- Updated Visual Studio project files
- Updated Keil MDK5 project files
- Fix for DTLS sequence numbers with GCM/CCM
- Updated HashDRBG with more secure struct declaration
- TI-RTOS support and example Code Composer Studio project files
- Ability to get enabled cipher suites, CyaSSL_get_ciphers()
- AES-GCM/CCM/Direct support for Freescale mmCAU and CAU
- Sniffer improvement checking for decrypt key setup
- Support for raw ECC key import
- Ability to convert ecc_key to DER, EccKeyToDer()
- Security fix for RSA Padding check vulnerability reported by Intel Security
  Advanced Threat Research team

The CyaSSL manual is available at:
http://www.wolfssl.com/documentation/CyaSSL-Manual.pdf.  For build instructions
and comments about the new features please check the manual.


# CyaSSL Release 3.1.0 (07/14/2014)

#### Release 3.1.0 CyaSSL has bug fixes and new features including:

- Fix for older versions of icc without 128-bit type
- Intel ASM syntax for AES-NI
- Updated NTRU support, keygen benchmark
- FIPS check for minimum required HMAC key length
- Small stack (--enable-smallstack) improvements for PKCS#7, ASN
- TLS extension support for DTLS
- Default I/O callbacks external to user
- Updated example client with bad clock test
- Ability to set optional ECC context info
- Ability to enable/disable DH separate from opensslextra
- Additional test key/cert buffers for CA and server
- Updated example certificates

The CyaSSL manual is available at:
http://www.yassl.com/documentation/CyaSSL-Manual.pdf.  For build instructions
and comments about the new features please check the manual.


# CyaSSL Release 3.0.2 (05/30/2014)

#### Release 3.0.2 CyaSSL has bug fixes and new features including:

- Added the following cipher suites:
  * TLS_PSK_WITH_AES_128_GCM_SHA256
  * TLS_PSK_WITH_AES_256_GCM_SHA384
  * TLS_PSK_WITH_AES_256_CBC_SHA384
  * TLS_PSK_WITH_NULL_SHA384
  * TLS_DHE_PSK_WITH_AES_128_GCM_SHA256
  * TLS_DHE_PSK_WITH_AES_256_GCM_SHA384
  * TLS_DHE_PSK_WITH_AES_128_CBC_SHA256
  * TLS_DHE_PSK_WITH_AES_256_CBC_SHA384
  * TLS_DHE_PSK_WITH_NULL_SHA256
  * TLS_DHE_PSK_WITH_NULL_SHA384
  * TLS_DHE_PSK_WITH_AES_128_CCM
  * TLS_DHE_PSK_WITH_AES_256_CCM
- Added AES-NI support for Microsoft Visual Studio builds.
- Changed small stack build to be disabled by default.
- Updated the Hash DRBG and provided a configure option to enable.

The CyaSSL manual is available at:
http://www.yassl.com/documentation/CyaSSL-Manual.pdf.  For build instructions
and comments about the new features please check the manual.


# CyaSSL Release 3.0.0 (04/29/2014)

#### Release 3.0.0 CyaSSL has bug fixes and new features including:

- FIPS release candidate
- X.509 improvements that address items reported by Suman Jana with security
  researchers at UT Austin and UC Davis
- Small stack size improvements, --enable-smallstack. Offloads large local
  variables to the heap. (Note this is not complete.)
- Updated AES-CCM-8 cipher suites to use approved suite numbers.

The CyaSSL manual is available at:
http://www.yassl.com/documentation/CyaSSL-Manual.pdf.  For build instructions
and comments about the new features please check the manual.


# CyaSSL Release 2.9.4 (04/09/2014)

#### Release 2.9.4 CyaSSL has bug fixes and new features including:

- Security fixes that address items reported by Ivan Fratric of the Google
  Security Team
- X.509 Unknown critical extensions treated as errors, report by Suman Jana with
  security researchers at UT Austin and UC Davis
- Sniffer fixes for corrupted packet length and Jumbo frames
- ARM thumb mode assembly fixes
- Xcode 5.1 support including new clang
- PIC32 MZ hardware support
- CyaSSL Object has enough room to read the Record Header now w/o allocs
- FIPS wrappers for AES, 3DES, SHA1, SHA256, SHA384, HMAC, and RSA.
- A sample I/O pool is demonstrated with --enable-iopool to overtake memory
  handling and reduce memory fragmentation on I/O large sizes

The CyaSSL manual is available at:
http://www.yassl.com/documentation/CyaSSL-Manual.pdf.  For build instructions
and comments about the new features please check the manual.


# CyaSSL Release 2.9.0 (02/07/2014)

#### Release 2.9.0 CyaSSL has bug fixes and new features including:
- Freescale Kinetis RNGB support
- Freescale Kinetis mmCAU support
- TLS Hello extensions
  - ECC
  - Secure Renegotiation (null)
  - Truncated HMAC
- SCEP support
  - PKCS #7 Enveloped data and signed data
  - PKCS #10 Certificate Signing Request generation
- DTLS sliding window
- OCSP Improvements
  - API change to integrate into Certificate Manager
  - IPv4/IPv6 agnostic
  - example client/server support for OCSP
  - OCSP nonces are optional
- GMAC hashing
- Windows build additions
- Windows CYGWIN build fixes
- Updated test certificates
- Microchip MPLAB Harmony support
- Update autoconf scripts
- Additional X.509 inspection functions
- ECC encrypt/decrypt primitives
- ECC Certificate generation

The Freescale Kinetis K53 RNGB documentation can be found in Chapter 33 of the
K53 Sub-Family Reference Manual:
http://cache.freescale.com/files/32bit/doc/ref_manual/K53P144M100SF2RM.pdf

Freescale Kinetis K60 mmCAU (AES, DES, 3DES, MD5, SHA, SHA256) documentation
can be found in the "ColdFire/ColdFire+ CAU and Kinetis mmCAU Software Library
User Guide":
http://cache.freescale.com/files/32bit/doc/user_guide/CAUAPIUG.pdf


# CyaSSL Release 2.8.0 (8/30/2013)

#### Release 2.8.0 CyaSSL has bug fixes and new features including:
- AES-GCM and AES-CCM use AES-NI
- NetX default IO callback handlers
- IPv6 fixes for DTLS Hello Cookies
- The ability to unload Certs/Keys after the handshake, CyaSSL_UnloadCertsKeys()
- SEP certificate extensions
- Callback getters for easier resource freeing
- External CYASSL_MAX_ERROR_SZ for correct error buffer sizing
- MacEncrypt and DecryptVerify Callbacks for User Atomic Record Layer Processing
- Public Key Callbacks for ECC and RSA
- Client now sends blank cert upon request if doesn't have one with TLS <= 1.2


The CyaSSL manual is available at:
http://www.yassl.com/documentation/CyaSSL-Manual.pdf.  For build instructions
and comments about the new features please check the manual.


# CyaSSL Release 2.7.0 (6/17/2013)

#### Release 2.7.0 CyaSSL has bug fixes and new features including:
- SNI support for client and server
- KEIL MDK-ARM projects
- Wildcard check to domain name match, and Subject altnames are checked too
- Better error messages for certificate verification errors
- Ability to discard session during handshake verify
- More consistent error returns across all APIs
- Ability to unload CAs at the CTX or CertManager level
- Authority subject id support for Certificate matching
- Persistent session cache functionality
- Persistent CA cache functionality
- Client session table lookups to push serverID table to library level
- Camellia support to sniffer
- User controllable settings for DTLS timeout values
- Sniffer fixes for caching long lived sessions
- DTLS reliability enhancements for the handshake
- Better ThreadX support

When compiling with Mingw, libtool may give the following warning due to
path conversion errors:

```
libtool: link: Could not determine host file name corresponding to **
libtool: link: Continuing, but uninstalled executables may not work.
```

If so, examples and testsuite will have problems when run, showing an
error while loading shared libraries. To resolve, please run "make install".

The CyaSSL manual is available at:
http://www.yassl.com/documentation/CyaSSL-Manual.pdf.  For build instructions
and comments about the new features please check the manual.


# CyaSSL Release 2.6.0 (04/15/2013)

#### Release 2.6.0 CyaSSL has bug fixes and new features including:
- DTLS 1.2 support including AEAD ciphers
- SHA-3 finalist Blake2 support, it's fast and uses little resources
- SHA-384 cipher suites including ECC ones
- HMAC now supports SHA-512
- Track memory use for example client/server with -t option
- Better IPv6 examples with --enable-ipv6, before if ipv6 examples/tests were
  turned on, localhost only was used.  Now link-local (with scope ids) and ipv6
  hosts can be used as well.
- Xcode v4.6 project for iOS v6.1 update
- settings.h is now checked in all *.c files for true one file setting detection
- Better alignment at SSL layer for hardware crypto alignment needs
    * Note, SSL itself isn't friendly to alignment with 5 byte TLS headers and
      13 bytes DTLS headers, but every effort is now made to align with the
      CYASSL_GENERAL_ALIGNMENT flag which sets desired alignment requirement
- NO_64BIT flag to turn off 64bit data type accumulators in public key code
    * Note, some systems are faster with 32bit accumulators
- --enable-stacksize for example client/server stack use
    * Note, modern desktop Operating Systems may add bytes to each stack frame
- Updated compression/decompression with direct crypto access
- All ./configure options are now lowercase only for consistency
- ./configure builds default to fastmath option
    * Note, if on ia32 and building in shared mode this may produce a problem
      with a missing register being available because of PIC, there are at least
      6 solutions to this:
      1) --disable-fastmath , don't use fastmath
      2) --disable-shared, don't build a shared library
      3) C_EXTRA_FLAGS=-DTFM_NO_ASM , turn off assembly use
      4) use clang, it just seems to work
      5) play around with no PIC options to force all registers being open,
         e.g., --without-pic
      6) if static lib is still a problem try removing fPIE
- Many new ./configure switches for option enable/disable for example
    * rsa
    * dh
    * dsa
    * md5
    * sha
    * arc4
    * null    (allow NULL ciphers)
    * oldtls  (only use TLS 1.2)
    * asn     (no certs or public keys allowed)
- ./configure generates cyassl/options.h which allows a header the user can
  include in their app to make sure the same options are set at the app and
  CyaSSL level.
- autoconf no longer needs serial-tests which lowers version requirements of
  automake to 1.11 and autoconf to 2.63

The CyaSSL manual is available at:
http://www.yassl.com/documentation/CyaSSL-Manual.pdf.  For build instructions
and comments about the new features please check the manual.



# CyaSSL Release 2.5.0 (02/04/2013)

#### Release 2.5.0 CyaSSL has bug fixes and new features including:
- Fix for TLS CBC padding timing attack identified by Nadhem Alfardan and
  Kenny Paterson: http://www.isg.rhul.ac.uk/tls/
- Microchip PIC32 (MIPS16, MIPS32) support
- Microchip MPLAB X example projects for PIC32 Ethernet Starter Kit
- Updated CTaoCrypt benchmark app for embedded systems
- 1024-bit test certs/keys and cert/key buffers
- AES-CCM-8 crypto and cipher suites
- Camellia crypto and cipher suites
- Bumped minimum autoconf version to 2.65, automake version to 1.12
- Addition of OCSP callbacks
- STM32F2 support with hardware crypto and RNG
- Cavium NITROX support

CTaoCrypt now has support for the Microchip PIC32 and has been tested with
the Microchip PIC32 Ethernet Starter Kit, the XC32 compiler and
MPLAB X IDE in both MIPS16 and MIPS32 instruction set modes. See the README
located under the <cyassl_root>/mplabx directory for more details.

To add Cavium NITROX support do:

./configure --with-cavium=/home/user/cavium/software

pointing to your licensed cavium/software directory.  Since Cavium doesn't
build a library we pull in the cavium_common.o file which gives a libtool
warning about the portability of this.  Also, if you're using the github source
tree you'll need to remove the -Wredundant-decls warning from the generated
Makefile because the cavium headers don't conform to this warning.  Currently
CyaSSL supports Cavium RNG, AES, 3DES, RC4, HMAC, and RSA directly at the crypto
layer.  Support at the SSL level is partial and currently just does AES, 3DES,
and RC4.  RSA and HMAC are slower until the Cavium calls can be utilized in non
blocking mode.  The example client turns on cavium support as does the crypto
test and benchmark.  Please see the HAVE_CAVIUM define.

CyaSSL is able to use the STM32F2 hardware-based cryptography and random number
generator through the STM32F2 Standard Peripheral Library. For necessary
defines, see the CYASSL_STM32F2 define in settings.h. Documentation for the
STM32F2 Standard Peripheral Library can be found in the following document:
http://www.st.com/internet/com/TECHNICAL_RESOURCES/TECHNICAL_LITERATURE/USER_MANUAL/DM00023896.pdf

The CyaSSL manual is available at:
http://www.yassl.com/documentation/CyaSSL-Manual.pdf.  For build instructions
and comments about the new features please check the manual.



# CyaSSL Release 2.4.6 (12/20/2012)

#### Release 2.4.6 CyaSSL has bug fixes and a few new features including:
- ECC into main version
- Lean PSK build (reduced code size, RAM usage, and stack usage)
- FreeBSD CRL monitor support
- CyaSSL_peek()
- CyaSSL_send() and CyaSSL_recv() for I/O flag setting
- CodeWarrior Support
- MQX Support
- Freescale Kinetis support including Hardware RNG
- autoconf builds use jobserver
- cyassl-config
- Sniffer memory reductions

Thanks to Brian Aker for the improved autoconf system, make rpm, cyassl-config,
warning system, and general good ideas for improving CyaSSL!

The Freescale Kinetis K70 RNGA documentation can be found in Chapter 37 of the
K70 Sub-Family Reference Manual:
http://cache.freescale.com/files/microcontrollers/doc/ref_manual/K70P256M150SF3RM.pdf

The CyaSSL manual is available at:
http://www.yassl.com/documentation/CyaSSL-Manual.pdf.  For build instructions
and comments about the new features please check the manual.


# CyaSSL Release 2.4.0 (10/10/2012)

#### Release 2.4.0 CyaSSL has bug fixes and a few new features including:
- DTLS reliability
- Reduced memory usage after handshake
- Updated build process

The CyaSSL manual is available at:
http://www.yassl.com/documentation/CyaSSL-Manual.pdf.  For build instructions
and comments about the new features please check the manual.



# CyaSSL Release 2.3.0 (8/10/2012)

#### Release 2.3.0 CyaSSL has bug fixes and a few new features including:
- AES-GCM crypto and cipher suites
- make test cipher suite checks
- Subject AltName processing
- Command line support for client/server examples
- Sniffer SessionTicket support
- SHA-384 cipher suites
- Verify cipher suite validity when user overrides
- CRL dir monitoring
- DTLS Cookie support, reliability coming soon

The CyaSSL manual is available at:
http://www.yassl.com/documentation/CyaSSL-Manual.pdf.  For build instructions
and comments about the new features please check the manual.



# CyaSSL Release 2.2.0 (5/18/2012)

#### Release 2.2.0 CyaSSL has bug fixes and a few new features including:
- Initial CRL support (--enable-crl)
- Initial OCSP support (--enable-ocsp)
- Add static ECDH suites
- SHA-384 support
- ECC client certificate support
- Add medium session cache size (1055 sessions)
- Updated unit tests
- Protection against mutex reinitialization


The CyaSSL manual is available at:
http://www.yassl.com/documentation/CyaSSL-Manual.pdf.  For build instructions
and comments about the new features please check the manual.



# CyaSSL Release 2.0.8 (2/24/2012)

#### Release 2.0.8 CyaSSL has bug fixes and a few new features including:
- A fix for malicious certificates pointed out by Remi Gacogne (thanks)
  resulting in NULL pointer use.
- Respond to renegotiation attempt with no_renegoatation alert
- Add basic path support for load_verify_locations()
- Add set Temp EC-DHE key size
- Extra checks on rsa test when porting into


The CyaSSL manual is available at:
http://www.yassl.com/documentation/CyaSSL-Manual.pdf.  For build instructions
and comments about the new features please check the manual.



# CyaSSL Release 2.0.6 (1/27/2012)

#### Release 2.0.6 CyaSSL has bug fixes and a few new features including:
- Fixes for CA basis constraint check
- CTX reference counting
- Initial unit test additions
- Lean and Mean Windows fix
- ECC benchmarking
- SSMTP build support
- Ability to group handshake messages with set_group_messages(ctx/ssl)
- CA cache addition callback
- Export Base64_Encode for general use

The CyaSSL manual is available at:
http://www.yassl.com/documentation/CyaSSL-Manual.pdf.  For build instructions
and comments about the new features please check the manual.



# CyaSSL Release 2.0.2 (12/05/2011)

#### Release 2.0.2 CyaSSL has bug fixes and a few new features including:
- CTaoCrypt Runtime library detection settings when directly using the crypto
  library
- Default certificate generation now uses SHAwRSA and adds SHA256wRSA generation
- All test certificates now use 2048bit and SHA-1 for better modern browser
  support
- Direct AES block access and AES-CTR (counter) mode
- Microchip pic32 support

The CyaSSL manual is available at:
http://www.yassl.com/documentation/CyaSSL-Manual.pdf.  For build instructions
and comments about the new features please check the manual.



# CyaSSL Release 2.0.0rc3 (9/28/2011)

#### Release 2.0.0rc3 for CyaSSL has bug fixes and a few new features including:
- updated autoconf support
- better make install and uninstall  (uses system directories)
- make test / make check
- CyaSSL headers now in <cyassl/*.h>
- CTaocrypt headers now in <cyassl/ctaocrypt/*.h>
- OpenSSL compatibility headers now in <cyassl/openssl/*.h>
- examples and tests all run from home directory so can use certs in ./certs
        (see note 1)

So previous applications that used the OpenSSL compatibility header
<openssl/ssl.h> now need to include <cyassl/openssl/ssl.h> instead, no other
changes are required.

Special Thanks to Brian Aker for his autoconf, install, and header patches.

The CyaSSL manual is available at:
http://www.yassl.com/documentation/CyaSSL-Manual.pdf.  For build instructions
and comments about the new features please check the manual.

# CyaSSL Release 2.0.0rc2 (6/6/2011)

#### Release 2.0.0rc2 for CyaSSL has bug fixes and a few new features including:
- bug fixes (Alerts, DTLS with DHE)
- FreeRTOS support
- lwIP support
- Wshadow warnings removed
- asn public header
- CTaoCrypt public headers now all have ctc_ prefix (the manual is still being
        updated to reflect this change)
- and more.

This is the 2nd and perhaps final release candidate for version 2.
Please send any comments or questions to support@yassl.com.

The CyaSSL manual is available at:
http://www.yassl.com/documentation/CyaSSL-Manual.pdf.  For build instructions
and comments about the new features please check the manual.

# CyaSSL Release 2.0.0rc1 (5/2/2011)

#### Release 2.0.0rc1 for CyaSSL has many new features including:
- bug fixes
- SHA-256 cipher suites
- Root Certificate Verification (instead of needing all certs in the chain)
- PKCS #8 private key encryption (supports PKCS #5 v1-v2 and PKCS #12)
- Serial number retrieval for x509
- PBKDF2 and PKCS #12 PBKDF
- UID parsing for x509
- SHA-256 certificate signatures
- Client and server can send chains (SSL_CTX_use_certificate_chain_file)
- CA loading can now parse multiple certificates per file
- Dynamic memory runtime hooks
- Runtime hooks for logging
- EDH on server side
- More informative error codes
- More informative logging messages
- Version downgrade more robust (use SSL_v23*)
- Shared build only by default through ./configure
- Compiler visibility is now used, internal functions not polluting namespace
- Single Makefile, no recursion, for faster and simpler building
- Turn on all warnings possible build option, warning fixes
- and more.

Because of all the new features and the multiple OS, compiler, feature-set
options that CyaSSL allows, there may be some configuration fixes needed.
Please send any comments or questions to support@yassl.com.

The CyaSSL manual is available at:
http://www.yassl.com/documentation/CyaSSL-Manual.pdf.  For build instructions
and comments about the new features please check the manual.

# CyaSSL Release 1.9.0 (3/2/2011)

Release 1.9.0 for CyaSSL adds bug fixes, improved TLSv1.2 through testing and
better hash/sig algo ids, --enable-webServer for the yaSSL embedded web server,
improper AES key setup detection, user cert verify callback improvements, and
more.

The CyaSSL manual offering is included in the doc/ directory.  For build
instructions and comments about the new features please check the manual.

Please send any comments or questions to support@yassl.com.

# CyaSSL Release 1.8.0 (12/23/2010)

Release 1.8.0 for CyaSSL adds bug fixes, x509 v3 CA signed certificate
generation, a C standard library abstraction layer, lower memory use, increased
portability through the os_settings.h file, and the ability to use NTRU cipher
suites when used in conjunction with an NTRU license and library.

The initial CyaSSL manual offering is included in the doc/ directory.  For
build instructions and comments about the new features please check the manual.

Please send any comments or questions to support@yassl.com.

Happy Holidays.


# CyaSSL Release 1.6.5 (9/9/2010)

Release 1.6.5 for CyaSSL adds bug fixes and x509 v3 self signed certificate
generation.

For general build instructions see doc/Building_CyaSSL.pdf.

To enable certificate generation support add this option to ./configure
./configure --enable-certgen

An example is included in ctaocrypt/test/test.c and documentation is provided
in doc/CyaSSL_Extensions_Reference.pdf item 11.

# CyaSSL Release 1.6.0 (8/27/2010)

Release 1.6.0 for CyaSSL adds bug fixes, RIPEMD-160, SHA-512, and RSA key
generation.

For general build instructions see doc/Building_CyaSSL.pdf.

To add RIPEMD-160 support add this option to ./configure
./configure --enable-ripemd

To add SHA-512 support add this option to ./configure
./configure --enable-sha512

To add RSA key generation support add this option to ./configure
./configure --enable-keygen

Please see ctaocrypt/test/test.c for examples and usage.

For Windows, RIPEMD-160 and SHA-512 are enabled by default but key generation is
off by default.  To turn key generation on add the define CYASSL_KEY_GEN to
CyaSSL.


# CyaSSL Release 1.5.6 (7/28/2010)

Release 1.5.6 for CyaSSL adds bug fixes, compatibility for our JSSE provider,
and a fix for GCC builds on some systems.

For general build instructions see doc/Building_CyaSSL.pdf.

To add AES-NI support add this option to ./configure
./configure --enable-aesni

You'll need GCC 4.4.3 or later to make use of the assembly.

# CyaSSL Release 1.5.4 (7/7/2010)

Release 1.5.4 for CyaSSL adds bug fixes, support for AES-NI, SHA1 speed
improvements from loop unrolling, and support for the Mongoose Web Server.

For general build instructions see doc/Building_CyaSSL.pdf.

To add AES-NI support add this option to ./configure
./configure --enable-aesni

You'll need GCC 4.4.3 or later to make use of the assembly.

# CyaSSL Release 1.5.0 (5/11/2010)

Release 1.5.0 for CyaSSL adds bug fixes, GoAhead WebServer support, sniffer
support, and initial swig interface support.

For general build instructions see doc/Building_CyaSSL.pdf.

To add support for GoAhead WebServer either --enable-opensslExtra or if you
don't want all the features of opensslExtra you can just define GOAHEAD_WS
instead.  GOAHEAD_WS can be added to ./configure with CFLAGS=-DGOAHEAD_WS or
you can define it yourself.

To look at the sniffer support please see the sniffertest app in
sslSniffer/sslSnifferTest.  Build with --enable-sniffer on *nix or use the
vcproj files on windows.  You'll need to have pcap installed on *nix and
WinPcap on windows.

A swig interface file is now located in the swig directory for using Python,
Java, Perl, and others with CyaSSL.  This is initial support and experimental,
please send questions or comments to support@yassl.com.

When doing load testing with CyaSSL, on the echoserver example say, the client
machine may run out of tcp ephemeral ports, they will end up in the TIME_WAIT
queue, and can't be reused by default.  There are generally two ways to fix
this.

1. Reduce the length sockets remain on the TIME_WAIT queue OR
2. Allow items on the TIME_WAIT queue to be reused.


To reduce the TIME_WAIT length in OS X to 3 seconds (3000 milliseconds)

`sudo sysctl -w net.inet.tcp.msl=3000`

In Linux

`sudo sysctl -w net.ipv4.tcp_tw_reuse=1`

allows reuse of sockets in TIME_WAIT

`sudo sysctl -w net.ipv4.tcp_tw_recycle=1`

works but seems to remove sockets from  TIME_WAIT entirely?

`sudo sysctl -w net.ipv4.tcp_fin_timeout=1`

doesn't control TIME_WAIT, it controls FIN_WAIT(2) contrary to some posts


# CyaSSL Release 1.4.0 (2/18/2010)

Release 1.3.0 for CyaSSL adds bug fixes, better multi TLS/SSL version support
through SSLv23_server_method(), and improved documentation in the doc/ folder.

For general build instructions doc/Building_CyaSSL.pdf.

# CyaSSL Release 1.3.0 (1/21/2010)

Release 1.3.0 for CyaSSL adds bug fixes, a potential security problem fix,
better porting support, removal of assert()s, and a complete THREADX port.

For general build instructions see rc1 below.

# CyaSSL Release 1.2.0 (11/2/2009)

Release 1.2.0 for CyaSSL adds bug fixes and session negotiation if first use is
read or write.

For general build instructions see rc1 below.

# CyaSSL Release 1.1.0 (9/2/2009)

Release 1.1.0 for CyaSSL adds bug fixes, a check against malicious session
cache use, support for lighttpd, and TLS 1.2.

To get TLS 1.2 support please use the client and server functions:

```c
SSL_METHOD *TLSv1_2_server_method(void);
SSL_METHOD *TLSv1_2_client_method(void);
```

CyaSSL was tested against lighttpd 1.4.23.  To build CyaSSL for use with
lighttpd use the following commands from the CyaSSL install dir <CyaSSLDir>:

```
./configure --disable-shared --enable-opensslExtra --enable-fastmath --without-zlib

make
make openssl-links
```

Then to build lighttpd with CyaSSL use the following commands from the
lighttpd install dir:

```
./configure --with-openssl --with-openssl-includes=<CyaSSLDir>/include --with-openssl-libs=<CyaSSLDir>/lib LDFLAGS=-lm

make
```

On some systems you may get a linker error about a duplicate symbol for
MD5_Init or other MD5 calls.  This seems to be caused by the lighttpd src file
md5.c, which defines MD5_Init(), and is included in liblightcomp_la-md5.o.
When liblightcomp is linked with the SSL_LIBs the linker may complain about
the duplicate symbol.  This can be fixed by editing the lighttpd src file md5.c
and adding this line to the beginning of the file:

\#if 0

and this line to the end of the file

\#endif

Then from the lighttpd src dir do a:

```
make clean
make
```

If you get link errors about undefined symbols more than likely the actual
OpenSSL libraries are found by the linker before the CyaSSL openssl-links that
point to the CyaSSL library, causing the linker confusion.  This can be fixed
by editing the Makefile in the lighttpd src directory and changing the line:

`SSL_LIB = -lssl -lcrypto`

to

`SSL_LIB = -lcyassl`

Then from the lighttpd src dir do a:

```
make clean
make
```

This should remove any confusion the linker may be having with missing symbols.

For any questions or concerns please contact support@yassl.com .

For general build instructions see rc1 below.

# CyaSSL Release 1.0.6 (8/03/2009)

Release 1.0.6 for CyaSSL adds bug fixes, an improved session cache, and faster
math with a huge code option.

The session cache now defaults to a client mode, also good for embedded servers.
For servers not under heavy load (less than 200 new sessions per minute), define
BIG_SESSION_CACHE.  If the server will be under heavy load, define
HUGE_SESSION_CACHE.

There is now a fasthugemath option for configure.  This enables fastmath plus
even faster math by greatly increasing the code size of the math library. Use
the benchmark utility to compare public key operations.


For general build instructions see rc1 below.

# CyaSSL Release 1.0.3 (5/10/2009)

Release 1.0.3 for CyaSSL adds bug fixes and add increased support for OpenSSL
compatibility when building other applications.

Release 1.0.3 includes an alpha release of DTLS for both client and servers.
This is only for testing purposes at this time.  Rebroadcast and reordering
aren't fully implemented at this time but will be for the next release.

For general build instructions see rc1 below.

# CyaSSL Release 1.0.2 (4/3/2009)

Release 1.0.2 for CyaSSL adds bug fixes for a couple I/O issues.  Some systems
will send a SIGPIPE on socket recv() at any time and this should be handled by
the application by turning off SIGPIPE through setsockopt() or returning from
the handler.

Release 1.0.2 includes an alpha release of DTLS for both client and servers.
This is only for testing purposes at this time.  Rebroadcast and reordering
aren't fully implemented at this time but will be for the next release.

For general build instructions see rc1 below.

## CyaSSL Release Candidate 3 rc3-1.0.0 (2/25/2009)


Release Candidate 3 for CyaSSL 1.0.0 adds bug fixes and adds a project file for
iPhone development with Xcode.  cyassl-iphone.xcodeproj is located in the root
directory.  This release also includes a fix for supporting other
implementations that bundle multiple messages at the record layer, this was
lost when cyassl i/o was re-implemented but is now fixed.

For general build instructions see rc1 below.

## CyaSSL Release Candidate 2 rc2-1.0.0 (1/21/2009)


Release Candidate 2 for CyaSSL 1.0.0 adds bug fixes and adds two new stream
ciphers along with their respective cipher suites.  CyaSSL adds support for
HC-128 and RABBIT stream ciphers.  The new suites are:

```
TLS_RSA_WITH_HC_128_SHA
TLS_RSA_WITH_RABBIT_SHA
```

And the corresponding cipher names are

```
HC128-SHA
RABBIT-SHA
```

CyaSSL also adds support for building with devkitPro for PPC by changing the
library proper to use libogc.  The examples haven't been changed yet but if
there's interest they can be.  Here's an example ./configure to build CyaSSL
for devkitPro:

```
./configure --disable-shared CC=/pathTo/devkitpro/devkitPPC/bin/powerpc-gekko-gcc --host=ppc --without-zlib --enable-singleThreaded RANLIB=/pathTo/devkitpro/devkitPPC/bin/powerpc-gekko-ranlib CFLAGS="-DDEVKITPRO -DGEKKO"
```

For linking purposes you'll need

`LDFLAGS="-g -mrvl -mcpu=750 -meabi -mhard-float -Wl,-Map,$(notdir $@).map"`

For general build instructions see rc1 below.


## CyaSSL Release Candidate 1 rc1-1.0.0 (12/17/2008)


Release Candidate 1 for CyaSSL 1.0.0 contains major internal changes.  Several
areas have optimization improvements, less dynamic memory use, and the I/O
strategy has been refactored to allow alternate I/O handling or Library use.
Many thanks to Thierry Fournier for providing these ideas and most of the work.

Because of these changes, this release is only a candidate since some problems
are probably inevitable on some platform with some I/O use.  Please report any
problems and we'll try to resolve them as soon as possible.  You can contact us
at support@yassl.com or todd@yassl.com.

Using TomsFastMath by passing --enable-fastmath to ./configure now uses assembly
on some platforms.  This is new so please report any problems as every compiler,
mode, OS combination hasn't been tested.  On ia32 all of the registers need to
be available so be sure to pass these options to CFLAGS:

`CFLAGS="-O3 -fomit-frame-pointer"`

OS X will also need -mdynamic-no-pic added to CFLAGS

Also if you're building in shared mode for ia32 you'll need to pass options to
LDFLAGS as well on OS X:

`LDFLAGS=-Wl,-read_only_relocs,warning`

This gives warnings for some symbols but seems to work.


#### To build on Linux, Solaris, *BSD, Mac OS X, or Cygwin:

    ./configure
    make

    from the ./testsuite/ directory run ./testsuite

#### To make a debug build:

    ./configure --enable-debug --disable-shared
    make



#### To build on Win32

Choose (Re)Build All from the project workspace

Run the testsuite program





# CyaSSL version 0.9.9 (7/25/2008)

This release of CyaSSL adds bug fixes, Pre-Shared Keys, over-rideable memory
handling, and optionally TomsFastMath.  Thanks to Moisés Guimarães for the
work on TomsFastMath.

To optionally use TomsFastMath pass --enable-fastmath to ./configure
Or define USE_FAST_MATH in each project from CyaSSL for MSVC.

Please use the benchmark routine before and after to see the performance
difference, on some platforms the gains will be little but RSA encryption
always seems to be faster.  On x86-64 machines with GCC the normal math library
may outperform the fast one when using CFLAGS=-m64 because TomsFastMath can't
yet use -m64 because of GCCs inability to do 128bit division.

     *** UPDATE GCC 4.2.1 can now do 128bit division ***

See notes below (0.2.0) for complete build instructions.


# CyaSSL version 0.9.8 (5/7/2008)

This release of CyaSSL adds bug fixes, client side Diffie-Hellman, and better
socket handling.

See notes below (0.2.0) for complete build instructions.


# CyaSSL version 0.9.6 (1/31/2008)

This release of CyaSSL adds bug fixes, increased session management, and a fix
for gnutls.

See notes below (0.2.0) for complete build instructions.


# CyaSSL version 0.9.0 (10/15/2007)

This release of CyaSSL adds bug fixes, MSVC 2005 support, GCC 4.2 support,
IPV6 support and test, and new test certificates.

See notes below (0.2.0) for complete build instructions.


# CyaSSL version 0.8.0 (1/10/2007)

This release of CyaSSL adds increased socket support, for non-blocking writes,
connects, and interrupted system calls.

See notes below (0.2.0) for complete build instructions.


# CyaSSL version 0.6.3 (10/30/2006)

This release of CyaSSL adds debug logging to stderr to aid in the debugging of
CyaSSL on systems that may not provide the best support.

If CyaSSL is built with debugging support then you need to call
CyaSSL_Debugging_ON() to turn logging on.

On Unix use ./configure --enable-debug

On Windows define DEBUG_CYASSL when building CyaSSL


To turn logging back off call CyaSSL_Debugging_OFF()

See notes below (0.2.0) for complete build instructions.


# CyaSSL version 0.6.2 (10/29/2006)

This release of CyaSSL adds TLS 1.1.

Note that CyaSSL has certificate verification on by default, unlike OpenSSL.
To emulate OpenSSL behavior, you must call SSL_CTX_set_verify() with
SSL_VERIFY_NONE.  In order to have full security you should never do this,
provide CyaSSL with the proper certificates to eliminate impostors and call
CyaSSL_check_domain_name() to prevent man in the middle attacks.

See notes below (0.2.0) for build instructions.

# CyaSSL version 0.6.0 (10/25/2006)

This release of CyaSSL adds more SSL functions, better autoconf, nonblocking
I/O for accept, connect, and read.  There is now an --enable-small configure
option that turns off TLS, AES, DES3, HMAC, and ERROR_STRINGS, see configure.in
for the defines.  Note that TLS requires HMAC and AES requires TLS.

See notes below (0.2.0) for build instructions.


# CyaSSL version 0.5.5 (09/27/2006)

This mini release of CyaSSL adds better input processing through buffered input
and big message support.  Added SSL_pending() and some sanity checks on user
settings.

See notes below (0.2.0) for build instructions.


# CyaSSL version 0.5.0 (03/27/2006)

This release of CyaSSL adds AES support and minor bug fixes.

See notes below (0.2.0) for build instructions.


# CyaSSL version 0.4.0 (03/15/2006)

This release of CyaSSL adds TLSv1 client/server support and libtool.

See notes below for build instructions.


# CyaSSL version 0.3.0 (02/26/2006)

This release of CyaSSL adds SSLv3 server support and session resumption.

See notes below for build instructions.


# CyaSSL version 0.2.0 (02/19/2006)


This is the first release of CyaSSL and its crypt brother, CTaoCrypt.  CyaSSL
is written in ANSI C with the idea of a small code size, footprint, and memory
usage in mind.  CTaoCrypt can be as small as 32K, and the current client
version of CyaSSL can be as small as 12K.


The first release of CTaoCrypt supports MD5, SHA-1, 3DES, ARC4, Big Integer
Support, RSA, ASN parsing, and basic x509 (en/de)coding.

The first release of CyaSSL supports normal client RSA mode SSLv3 connections
with support for SHA-1 and MD5 digests.  Ciphers include 3DES and RC4.


#### To build on Linux, Solaris, *BSD, Mac OS X, or Cygwin:

    ./configure
    make

    from the ./testsuite/ directory run ./testsuite

#### to make a debug build:

    ./configure --enable-debug --disable-shared
    make



#### To build on Win32

Choose (Re)Build All from the project workspace

Run the testsuite program



*** The next release of CyaSSL will support a server and more OpenSSL
compatibility functions.


Please send questions or comments to todd@wolfssl.com
