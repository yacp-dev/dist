#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "uri-template::uri-template" for configuration "RelWithDebInfo"
set_property(TARGET uri-template::uri-template APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(uri-template::uri-template PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/liburi-template.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cyguri-template-1.2.1.dll"
  )

list(APPEND _cmake_import_check_targets uri-template::uri-template )
list(APPEND _cmake_import_check_files_for_uri-template::uri-template "${_IMPORT_PREFIX}/lib/liburi-template.dll.a" "${_IMPORT_PREFIX}/bin/cyguri-template-1.2.1.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
