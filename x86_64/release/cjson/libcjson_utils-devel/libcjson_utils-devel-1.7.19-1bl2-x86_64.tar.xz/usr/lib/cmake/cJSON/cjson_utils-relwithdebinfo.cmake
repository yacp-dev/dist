#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "cjson_utils" for configuration "RelWithDebInfo"
set_property(TARGET cjson_utils APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(cjson_utils PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "/usr/lib/libcjson_utils.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "/usr/bin/cygcjson_utils-1.dll"
  )

list(APPEND _cmake_import_check_targets cjson_utils )
list(APPEND _cmake_import_check_files_for_cjson_utils "/usr/lib/libcjson_utils.dll.a" "/usr/bin/cygcjson_utils-1.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
