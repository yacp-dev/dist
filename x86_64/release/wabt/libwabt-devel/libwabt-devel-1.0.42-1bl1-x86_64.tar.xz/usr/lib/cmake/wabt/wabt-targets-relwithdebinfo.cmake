#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "wabt::wabt" for configuration "RelWithDebInfo"
set_property(TARGET wabt::wabt APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(wabt::wabt PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libwabt.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygwabt-1.dll"
  )

list(APPEND _cmake_import_check_targets wabt::wabt )
list(APPEND _cmake_import_check_files_for_wabt::wabt "${_IMPORT_PREFIX}/lib/libwabt.dll.a" "${_IMPORT_PREFIX}/bin/cygwabt-1.dll" )

# Import target "wabt::wasm-rt-impl" for configuration "RelWithDebInfo"
set_property(TARGET wabt::wasm-rt-impl APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(wabt::wasm-rt-impl PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libwasm-rt-impl.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygwasm-rt-impl-1.dll"
  )

list(APPEND _cmake_import_check_targets wabt::wasm-rt-impl )
list(APPEND _cmake_import_check_files_for_wabt::wasm-rt-impl "${_IMPORT_PREFIX}/lib/libwasm-rt-impl.dll.a" "${_IMPORT_PREFIX}/bin/cygwasm-rt-impl-1.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
