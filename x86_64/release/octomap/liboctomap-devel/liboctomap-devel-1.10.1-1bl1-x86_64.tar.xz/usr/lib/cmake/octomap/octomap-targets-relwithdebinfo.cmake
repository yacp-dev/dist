#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "octomath" for configuration "RelWithDebInfo"
set_property(TARGET octomath APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(octomath PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/liboctomath.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygoctomath-1.10.dll"
  )

list(APPEND _cmake_import_check_targets octomath )
list(APPEND _cmake_import_check_files_for_octomath "${_IMPORT_PREFIX}/lib/liboctomath.dll.a" "${_IMPORT_PREFIX}/bin/cygoctomath-1.10.dll" )

# Import target "octomap" for configuration "RelWithDebInfo"
set_property(TARGET octomap APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(octomap PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/liboctomap.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygoctomap-1.10.dll"
  )

list(APPEND _cmake_import_check_targets octomap )
list(APPEND _cmake_import_check_files_for_octomap "${_IMPORT_PREFIX}/lib/liboctomap.dll.a" "${_IMPORT_PREFIX}/bin/cygoctomap-1.10.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
