#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "LIBMINC::minc2" for configuration "RelWithDebInfo"
set_property(TARGET LIBMINC::minc2 APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(LIBMINC::minc2 PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libminc2.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygminc2-5.3.0.dll"
  )

list(APPEND _cmake_import_check_targets LIBMINC::minc2 )
list(APPEND _cmake_import_check_files_for_LIBMINC::minc2 "${_IMPORT_PREFIX}/lib/libminc2.dll.a" "${_IMPORT_PREFIX}/bin/cygminc2-5.3.0.dll" )

# Import target "LIBMINC::minc_io" for configuration "RelWithDebInfo"
set_property(TARGET LIBMINC::minc_io APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(LIBMINC::minc_io PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libminc_io.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygminc_io-5.3.0.dll"
  )

list(APPEND _cmake_import_check_targets LIBMINC::minc_io )
list(APPEND _cmake_import_check_files_for_LIBMINC::minc_io "${_IMPORT_PREFIX}/lib/libminc_io.dll.a" "${_IMPORT_PREFIX}/bin/cygminc_io-5.3.0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
