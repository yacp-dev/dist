# UseLIBMINC.cmake — legacy "use file" for backward compatibility
#
# New code should use the imported targets instead:
#   target_link_libraries(myapp PRIVATE LIBMINC::minc2)
#   target_link_libraries(myapp PRIVATE LIBMINC::minc_io)  # for ezminc
#
# The targets automatically propagate include directories, compile
# definitions, and transitive link dependencies.

message(DEPRECATION
  "UseLIBMINC.cmake is deprecated. "
  "Prefer linking against the imported targets LIBMINC::minc2 (and LIBMINC::minc_io for ezminc) "
  "which automatically propagate include directories, compile definitions, and link dependencies."
)

include_directories(${LIBMINC_INCLUDE_DIRS})

if(HAVE_MINC1)
  add_definitions( -DHAVE_MINC1=1)

  include_directories(${NETCDF_INCLUDE_DIR})
endif()

if(HAVE_MINC2)
  set(MINC2 "1")
  add_definitions( -DMINC2=1 -DHAVE_MINC2=1)

  include_directories(${HDF5_INCLUDE_DIR})
endif()

link_directories(${LIBMINC_LIBRARY_DIRS})
