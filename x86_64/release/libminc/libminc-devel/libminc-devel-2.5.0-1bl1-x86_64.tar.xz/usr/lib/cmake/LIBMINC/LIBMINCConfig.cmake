# LIBMINCConfig.cmake — installed package configuration
#
# Provides:
#   Modern imported targets:
#     LIBMINC::minc2   — the core minc2 + volume_io library
#     LIBMINC::minc_io — the C++ ezminc wrapper (if built)
#
#   Legacy variables (backward compatibility):
#     LIBMINC_FOUND
#     LIBMINC_INCLUDE_DIRS
#     LIBMINC_LIBRARY_DIRS
#     LIBMINC_LIBRARIES
#     VOLUME_IO_LIBRARIES
#     EZMINC_LIBRARIES
#     LIBMINC_STATIC_LIBRARIES
#     VOLUME_IO_STATIC_LIBRARIES
#     LIBMINC_USE_FILE
#     HAVE_MINC1, HAVE_MINC2, HAVE_EZMINC

cmake_minimum_required(VERSION 3.10)

include(CMakeFindDependencyMacro)

get_filename_component(LIBMINC_INSTALL_PREFIX "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)
get_filename_component(LIBMINC_CMAKE_DIR "${CMAKE_CURRENT_LIST_FILE}" PATH)

# ----- Feature flags (substituted at configure time) -----
set(HAVE_MINC2    1)
set(HAVE_EZMINC   ON)
set(HAVE_MINC1    ON)
set(LIBMINC_NIFTI_SUPPORT ON)

# ----- Resolve transitive dependencies -----
find_dependency(ZLIB REQUIRED)

set(HDF5_NO_FIND_PACKAGE_CONFIG_FILE ON)
# Provide hints so the system FindHDF5 can find the same HDF5 we were built with
# (especially important on Debian/Ubuntu where the serial variant lives in
#  non-standard paths like /usr/include/hdf5/serial)
set(_LIBMINC_SAVED_HDF5_INCLUDE_DIR "/usr/include")
set(_LIBMINC_SAVED_HDF5_LIBRARY     "/usr/lib/libhdf5.dll.a")
if(_LIBMINC_SAVED_HDF5_INCLUDE_DIR)
  if(NOT HDF5_C_INCLUDE_DIR)
    set(HDF5_C_INCLUDE_DIR "${_LIBMINC_SAVED_HDF5_INCLUDE_DIR}" CACHE PATH "HDF5 C include dir (from libminc)")
  endif()
endif()
if(_LIBMINC_SAVED_HDF5_LIBRARY)
  if(NOT HDF5_hdf5_LIBRARY_RELEASE)
    set(HDF5_hdf5_LIBRARY_RELEASE "${_LIBMINC_SAVED_HDF5_LIBRARY}" CACHE FILEPATH "HDF5 C library (from libminc)")
  endif()
endif()
unset(_LIBMINC_SAVED_HDF5_INCLUDE_DIR)
unset(_LIBMINC_SAVED_HDF5_LIBRARY)
find_dependency(HDF5 REQUIRED COMPONENTS C)

if(HAVE_MINC1)
  # NetCDF is required when MINC1 support was enabled
  list(APPEND CMAKE_MODULE_PATH "${LIBMINC_CMAKE_DIR}")
  find_dependency(NETCDF REQUIRED)
endif()

# ----- Import the exported targets -----
if(NOT TARGET LIBMINC::minc2)
  include("${LIBMINC_CMAKE_DIR}/LIBMINC-targets.cmake")
endif()

# ----- Legacy variables (backward compatibility) -----
set(LIBMINC_INCLUDE_DIRS "${LIBMINC_INSTALL_PREFIX}/include/libminc")
set(LIBMINC_LIBRARY_DIRS "${LIBMINC_INSTALL_PREFIX}/lib")
set(LIBMINC_USE_FILE     "${LIBMINC_INSTALL_PREFIX}/lib/cmake/LIBMINC/UseLIBMINC.cmake")

set(LIBMINC_LIBRARIES    "minc2;libhdf5.dll.a;libniftiio.dll.a;libznz.dll.a;libz.dll.a;m;dl;libnetcdf.dll.a")
set(VOLUME_IO_LIBRARIES  "minc2;libhdf5.dll.a;libniftiio.dll.a;libznz.dll.a;libz.dll.a;m;dl;libnetcdf.dll.a")
set(EZMINC_LIBRARIES     "minc_io;minc2;libhdf5.dll.a;libniftiio.dll.a;libznz.dll.a;libz.dll.a;m;dl;libnetcdf.dll.a")

set(LIBMINC_STATIC_LIBRARIES    "")
set(VOLUME_IO_STATIC_LIBRARIES  "")

set(LIBMINC_FOUND 1)
