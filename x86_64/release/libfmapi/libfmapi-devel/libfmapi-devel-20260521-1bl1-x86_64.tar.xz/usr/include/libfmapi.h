/*
 * Library to support the MAPI data types
 *
 * Copyright (C) 2009-2026, Joachim Metz <joachim.metz@gmail.com>
 *
 * Refer to AUTHORS for acknowledgements.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#if !defined( _LIBFMAPI_H )
#define _LIBFMAPI_H

#include <libfmapi/definitions.h>
#include <libfmapi/error.h>
#include <libfmapi/extern.h>
#include <libfmapi/features.h>
#include <libfmapi/types.h>

#include <stdio.h>

#if defined( __cplusplus )
extern "C" {
#endif

/* -------------------------------------------------------------------------
 * Support functions
 * ------------------------------------------------------------------------- */

/* Returns the library version
 */
LIBFMAPI_EXTERN \
const char *libfmapi_get_version(
             void );

/* -------------------------------------------------------------------------
 * Error functions
 * ------------------------------------------------------------------------- */

/* Frees an error
 */
LIBFMAPI_EXTERN \
void libfmapi_error_free(
      libfmapi_error_t **error );

/* Prints a descriptive string of the error to the stream
 * Returns the amount of printed characters if successful or -1 on error
 */
LIBFMAPI_EXTERN \
int libfmapi_error_fprint(
     libfmapi_error_t *error,
     FILE *stream );

/* Prints a descriptive string of the error to the string
 * The end-of-string character is not included in the return value
 * Returns the amount of printed characters if successful or -1 on error
 */
LIBFMAPI_EXTERN \
int libfmapi_error_sprint(
     libfmapi_error_t *error,
     char *string,
     size_t size );

/* Prints a backtrace of the error to the stream
 * Returns the amount of printed characters if successful or -1 on error
 */
LIBFMAPI_EXTERN \
int libfmapi_error_backtrace_fprint(
     libfmapi_error_t *error,
     FILE *stream );

/* Prints a backtrace of the error to the string
 * The end-of-string character is not included in the return value
 * Returns the amount of printed characters if successful or -1 on error
 */
LIBFMAPI_EXTERN \
int libfmapi_error_backtrace_sprint(
     libfmapi_error_t *error,
     char *string,
     size_t size );

/* -------------------------------------------------------------------------
 * Entry identifier functions
 * ------------------------------------------------------------------------- */

/* Creates an entry identifier
 * Make sure the value entry_identifier is referencing, is set to NULL
 * Returns 1 if successful or -1 on error
 */
LIBFMAPI_EXTERN \
int libfmapi_entry_identifier_initialize(
     libfmapi_entry_identifier_t **entry_identifier,
     libfmapi_error_t **error );

/* Frees an entry identifier
 * Returns 1 if successful or -1 on error
 */
LIBFMAPI_EXTERN \
int libfmapi_entry_identifier_free(
     libfmapi_entry_identifier_t **entry_identifier,
     libfmapi_error_t **error );

/* Converts a byte stream into an entry identifier
 * Returns 1 if successful or -1 on error
 */
LIBFMAPI_EXTERN \
int libfmapi_entry_identifier_copy_from_byte_stream(
     libfmapi_entry_identifier_t *entry_identifier,
     const uint8_t *byte_stream,
     size_t byte_stream_size,
     libfmapi_error_t **error );

/* Retrieves the service provider identifier
 * Returns 1 if successful or -1 on error
 */
LIBFMAPI_EXTERN \
int libfmapi_entry_identifier_get_service_provider_identifier(
     libfmapi_entry_identifier_t *entry_identifier,
     uint8_t *guid_data,
     size_t guid_data_size,
     libfmapi_error_t **error );

/* -------------------------------------------------------------------------
 * One-off entry identifier functions
 * ------------------------------------------------------------------------- */

/* Creates an one-off entry identifier
 * Make sure the value entry_identifier is referencing, is set to NULL
 * Returns 1 if successful or -1 on error
 */
LIBFMAPI_EXTERN \
int libfmapi_one_off_entry_identifier_initialize(
     libfmapi_one_off_entry_identifier_t **entry_identifier,
     libfmapi_error_t **error );

/* Frees an one-off entry identifier
 * Returns 1 if successful or -1 on error
 */
LIBFMAPI_EXTERN \
int libfmapi_one_off_entry_identifier_free(
     libfmapi_one_off_entry_identifier_t **entry_identifier,
     libfmapi_error_t **error );

/* Converts a byte stream into an one-off entry identifier
 * Returns 1 if successful or -1 on error
 */
LIBFMAPI_EXTERN \
int libfmapi_one_off_entry_identifier_copy_from_byte_stream(
     libfmapi_one_off_entry_identifier_t *entry_identifier,
     const uint8_t *byte_stream,
     size_t byte_stream_size,
     int ascii_codepage,
     libfmapi_error_t **error );

/* Retrieves the format version
 * Returns 1 if successful or -1 on error
 */
LIBFMAPI_EXTERN \
int libfmapi_one_off_entry_identifier_get_version(
     libfmapi_one_off_entry_identifier_t *entry_identifier,
     uint16_t *format_version,
     libfmapi_error_t **error );

/* Retrieves the flags
 * Returns 1 if successful or -1 on error
 */
LIBFMAPI_EXTERN \
int libfmapi_one_off_entry_identifier_get_flags(
     libfmapi_one_off_entry_identifier_t *entry_identifier,
     uint16_t *flags,
     libfmapi_error_t **error );

/* Retrieves the UTF-8 string size of the one-off entry identifier display name
 * The returned size includes the end of string character
 * Returns 1 if successful or -1 on error
 */
LIBFMAPI_EXTERN \
int libfmapi_one_off_entry_identifier_get_utf8_display_name_size(
     libfmapi_one_off_entry_identifier_t *entry_identifier,
     size_t *utf8_string_size,
     libfmapi_error_t **error );

/* Retrieves the UTF-8 string of the one-off entry identifier display name
 * The size should include the end of string character
 * Returns 1 if successful or -1 on error
 */
LIBFMAPI_EXTERN \
int libfmapi_one_off_entry_identifier_get_utf8_display_name(
     libfmapi_one_off_entry_identifier_t *entry_identifier,
     uint8_t *utf8_string,
     size_t utf8_string_size,
     libfmapi_error_t **error );

/* Retrieves the UTF-16 string size of the one-off entry identifier display name
 * The returned size includes the end of string character
 * Returns 1 if successful or -1 on error
 */
LIBFMAPI_EXTERN \
int libfmapi_one_off_entry_identifier_get_utf16_display_name_size(
     libfmapi_one_off_entry_identifier_t *entry_identifier,
     size_t *utf16_string_size,
     libfmapi_error_t **error );

/* Retrieves the UTF-16 string of the one-off entry identifier display name
 * The size should include the end of string character
 * Returns 1 if successful or -1 on error
 */
LIBFMAPI_EXTERN \
int libfmapi_one_off_entry_identifier_get_utf16_display_name(
     libfmapi_one_off_entry_identifier_t *entry_identifier,
     uint16_t *utf16_string,
     size_t utf16_string_size,
     libfmapi_error_t **error );

/* Retrieves the UTF-8 string size of the one-off entry identifier address type
 * The returned size includes the end of string character
 * Returns 1 if successful or -1 on error
 */
LIBFMAPI_EXTERN \
int libfmapi_one_off_entry_identifier_get_utf8_address_type_size(
     libfmapi_one_off_entry_identifier_t *entry_identifier,
     size_t *utf8_string_size,
     libfmapi_error_t **error );

/* Retrieves the UTF-8 string of the one-off entry identifier address type
 * The size should include the end of string character
 * Returns 1 if successful or -1 on error
 */
LIBFMAPI_EXTERN \
int libfmapi_one_off_entry_identifier_get_utf8_address_type(
     libfmapi_one_off_entry_identifier_t *entry_identifier,
     uint8_t *utf8_string,
     size_t utf8_string_size,
     libfmapi_error_t **error );

/* Retrieves the UTF-16 string size of the one-off entry identifier address type
 * The returned size includes the end of string character
 * Returns 1 if successful or -1 on error
 */
LIBFMAPI_EXTERN \
int libfmapi_one_off_entry_identifier_get_utf16_address_type_size(
     libfmapi_one_off_entry_identifier_t *entry_identifier,
     size_t *utf16_string_size,
     libfmapi_error_t **error );

/* Retrieves the UTF-16 string of the one-off entry identifier address type
 * The size should include the end of string character
 * Returns 1 if successful or -1 on error
 */
LIBFMAPI_EXTERN \
int libfmapi_one_off_entry_identifier_get_utf16_address_type(
     libfmapi_one_off_entry_identifier_t *entry_identifier,
     uint16_t *utf16_string,
     size_t utf16_string_size,
     libfmapi_error_t **error );

/* Retrieves the UTF-8 string size of the one-off entry identifier email address
 * The returned size includes the end of string character
 * Returns 1 if successful or -1 on error
 */
LIBFMAPI_EXTERN \
int libfmapi_one_off_entry_identifier_get_utf8_email_address_size(
     libfmapi_one_off_entry_identifier_t *entry_identifier,
     size_t *utf8_string_size,
     libfmapi_error_t **error );

/* Retrieves the UTF-8 string of the one-off entry identifier email address
 * The size should include the end of string character
 * Returns 1 if successful or -1 on error
 */
LIBFMAPI_EXTERN \
int libfmapi_one_off_entry_identifier_get_utf8_email_address(
     libfmapi_one_off_entry_identifier_t *entry_identifier,
     uint8_t *utf8_string,
     size_t utf8_string_size,
     libfmapi_error_t **error );

/* Retrieves the UTF-16 string size of the one-off entry identifier email address
 * The returned size includes the end of string character
 * Returns 1 if successful or -1 on error
 */
LIBFMAPI_EXTERN \
int libfmapi_one_off_entry_identifier_get_utf16_email_address_size(
     libfmapi_one_off_entry_identifier_t *entry_identifier,
     size_t *utf16_string_size,
     libfmapi_error_t **error );

/* Retrieves the UTF-16 string of the one-off entry identifier email address
 * The size should include the end of string character
 * Returns 1 if successful or -1 on error
 */
LIBFMAPI_EXTERN \
int libfmapi_one_off_entry_identifier_get_utf16_email_address(
     libfmapi_one_off_entry_identifier_t *entry_identifier,
     uint16_t *utf16_string,
     size_t utf16_string_size,
     libfmapi_error_t **error );

/* -------------------------------------------------------------------------
 * MAPI class identifiers
 * ------------------------------------------------------------------------- */

LIBFMAPI_EXTERN_VARIABLE \
uint8_t libfmapi_class_identifier_mapi[ 16 ];

LIBFMAPI_EXTERN_VARIABLE \
uint8_t libfmapi_class_identifier_public_strings[ 16 ];

LIBFMAPI_EXTERN_VARIABLE \
uint8_t libfmapi_class_identifier_internet_headers[ 16 ];

LIBFMAPI_EXTERN_VARIABLE \
uint8_t libfmapi_class_identifier_appointment[ 16 ];

LIBFMAPI_EXTERN_VARIABLE \
uint8_t libfmapi_class_identifier_task[ 16 ];

LIBFMAPI_EXTERN_VARIABLE \
uint8_t libfmapi_class_identifier_address[ 16 ];

LIBFMAPI_EXTERN_VARIABLE \
uint8_t libfmapi_class_identifier_common[ 16 ];

LIBFMAPI_EXTERN_VARIABLE \
uint8_t libfmapi_class_identifier_journal[ 16 ];

LIBFMAPI_EXTERN_VARIABLE \
uint8_t libfmapi_class_identifier_sticky_note[ 16 ];

LIBFMAPI_EXTERN_VARIABLE \
uint8_t libfmapi_class_identifier_sharing[ 16 ];

LIBFMAPI_EXTERN_VARIABLE \
uint8_t libfmapi_class_identifier_rss_feed[ 16 ];

LIBFMAPI_EXTERN_VARIABLE \
uint8_t libfmapi_class_identifier_unified_messaging[ 16 ];

LIBFMAPI_EXTERN_VARIABLE \
uint8_t libfmapi_class_identifier_calendar[ 16 ];

LIBFMAPI_EXTERN_VARIABLE \
uint8_t libfmapi_class_identifier_air_sync[ 16 ];

LIBFMAPI_EXTERN_VARIABLE \
uint8_t libfmapi_class_identifier_attachment[ 16 ];

/* -------------------------------------------------------------------------
 * LZFu (de)compression functions
 * ------------------------------------------------------------------------- */

/* Determines the uncompressed data size from the LZFu header in the compressed data
 * Returns 1 on success or -1 on error
 */
LIBFMAPI_EXTERN \
int libfmapi_lzfu_get_uncompressed_data_size(
     const uint8_t *compressed_data,
     size_t compressed_data_size,
     size_t *uncompressed_data_size,
     libfmapi_error_t **error );

/* Decompresses data using LZFu compression
 * Returns 1 on success or -1 on error
 */
LIBFMAPI_EXTERN \
int libfmapi_lzfu_decompress(
     const uint8_t *compressed_data,
     size_t compressed_data_size,
     uint8_t *uncompressed_data,
     size_t *uncompressed_data_size,
     libfmapi_error_t **error );

#if defined( __cplusplus )
}
#endif

#endif /* !defined( _LIBFMAPI_H ) */

