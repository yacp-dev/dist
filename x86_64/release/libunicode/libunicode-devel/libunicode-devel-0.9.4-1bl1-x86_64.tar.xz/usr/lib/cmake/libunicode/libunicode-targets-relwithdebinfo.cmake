#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "unicode::unicode_ucd" for configuration "RelWithDebInfo"
set_property(TARGET unicode::unicode_ucd APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(unicode::unicode_ucd PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libunicode_ucd.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygunicode_ucd-0.9.dll"
  )

list(APPEND _cmake_import_check_targets unicode::unicode_ucd )
list(APPEND _cmake_import_check_files_for_unicode::unicode_ucd "${_IMPORT_PREFIX}/lib/libunicode_ucd.dll.a" "${_IMPORT_PREFIX}/bin/cygunicode_ucd-0.9.dll" )

# Import target "unicode::unicode" for configuration "RelWithDebInfo"
set_property(TARGET unicode::unicode APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(unicode::unicode PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libunicode.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygunicode-0.9.dll"
  )

list(APPEND _cmake_import_check_targets unicode::unicode )
list(APPEND _cmake_import_check_files_for_unicode::unicode "${_IMPORT_PREFIX}/lib/libunicode.dll.a" "${_IMPORT_PREFIX}/bin/cygunicode-0.9.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
