#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "hidapi::libusb" for configuration "RelWithDebInfo"
set_property(TARGET hidapi::libusb APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(hidapi::libusb PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libhidapi-libusb.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cyghidapi-libusb-0.dll"
  )

list(APPEND _cmake_import_check_targets hidapi::libusb )
list(APPEND _cmake_import_check_files_for_hidapi::libusb "${_IMPORT_PREFIX}/lib/libhidapi-libusb.dll.a" "${_IMPORT_PREFIX}/bin/cyghidapi-libusb-0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
