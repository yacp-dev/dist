#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "vvdec::vvdec" for configuration "RelWithDebInfo"
set_property(TARGET vvdec::vvdec APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(vvdec::vvdec PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libvvdec.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygvvdec-3.dll"
  )

list(APPEND _cmake_import_check_targets vvdec::vvdec )
list(APPEND _cmake_import_check_files_for_vvdec::vvdec "${_IMPORT_PREFIX}/lib/libvvdec.dll.a" "${_IMPORT_PREFIX}/bin/cygvvdec-3.dll" )

# Import target "vvdec::vvdecapp" for configuration "RelWithDebInfo"
set_property(TARGET vvdec::vvdecapp APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(vvdec::vvdecapp PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/vvdecapp.exe"
  )

list(APPEND _cmake_import_check_targets vvdec::vvdecapp )
list(APPEND _cmake_import_check_files_for_vvdec::vvdecapp "${_IMPORT_PREFIX}/bin/vvdecapp.exe" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
