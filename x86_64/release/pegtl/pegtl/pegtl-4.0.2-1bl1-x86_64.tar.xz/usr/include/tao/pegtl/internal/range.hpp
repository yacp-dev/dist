// Copyright (c) 2026 Dr. Colin Hirsch and Daniel Frey
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at https://www.boost.org/LICENSE_1_0.txt)

#ifndef TAO_PEGTL_INTERNAL_RANGE_HPP
#define TAO_PEGTL_INTERNAL_RANGE_HPP

#include "../config.hpp"

#include "enable_control.hpp"
#include "match_mode.hpp"
#include "one.hpp"
#include "range_not_range.hpp"
#include "terminal.hpp"

namespace TAO_PEGTL_NAMESPACE::internal
{
   template< typename Peek, typename Peek::data_t Lo, typename Peek::data_t Hi >
   struct range
      : terminal< range< Peek, Lo, Hi >, Peek >,
        range_not_range< match_mode::normal, Peek, Lo, Hi >
   {};

   template< typename Peek, typename Peek::data_t C >
   struct range< Peek, C, C >
      : one< Peek, C >
   {};

   template< typename Peek, typename Peek::data_t Lo, typename Peek::data_t Hi >
   inline constexpr bool enable_control< range< Peek, Lo, Hi > > = false;

}  // namespace TAO_PEGTL_NAMESPACE::internal

#endif
