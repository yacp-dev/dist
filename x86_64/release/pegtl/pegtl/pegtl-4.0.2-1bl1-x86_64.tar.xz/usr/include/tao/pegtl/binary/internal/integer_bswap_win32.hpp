// Copyright (c) 2017-2026 Dr. Colin Hirsch and Daniel Frey
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at https://www.boost.org/LICENSE_1_0.txt)

#ifndef TAO_PEGTL_BINARY_INTERNAL_INTEGER_BSWAP_WIN32_HPP
#define TAO_PEGTL_BINARY_INTERNAL_INTEGER_BSWAP_WIN32_HPP

#include <cstdint>
#include <stdlib.h>

#include "../../config.hpp"

#include "../../internal/dependent_false.hpp"
#include "../../internal/is_simple_type.hpp"

namespace TAO_PEGTL_NAMESPACE::internal
{
   template< typename T >
   [[nodiscard]] T integer_bswap( const T n ) noexcept
   {
      static_assert( is_simple_type_v< T > );

      if constexpr( sizeof( T ) == 1 ) {
         return n;
      }
      else if constexpr( sizeof( T ) == 2 ) {
         return static_cast< T >( _byteswap_ushort( static_cast< std::uint16_t >( n ) ) );
      }
      else if constexpr( sizeof( T ) == 4 ) {
         return static_cast< T >( _byteswap_ulong( static_cast< std::uint32_t >( n ) ) );
      }
      else if constexpr( sizeof( T ) == 8 ) {
         return static_cast< T >( _byteswap_uint64( static_cast< std::uint64_t >( n ) ) );
      }
      else {
         static_assert( dependent_false< T > );
      }
   }

}  // namespace TAO_PEGTL_NAMESPACE::internal

#endif
