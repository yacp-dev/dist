// Copyright (c) 2020-2026 Dr. Colin Hirsch and Daniel Frey
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at https://www.boost.org/LICENSE_1_0.txt)

#ifndef TAO_PEGTL_DEBUG_INTERNAL_ANALYZE_ENUM_HPP
#define TAO_PEGTL_DEBUG_INTERNAL_ANALYZE_ENUM_HPP

#include "../../config.hpp"

namespace TAO_PEGTL_NAMESPACE::internal
{
   enum class analyze_enum
   {
      any,
      opt,
      seq,
      sor
   };

}  // namespace TAO_PEGTL_NAMESPACE::internal

// FCOV_EXCL_FILE
#endif
