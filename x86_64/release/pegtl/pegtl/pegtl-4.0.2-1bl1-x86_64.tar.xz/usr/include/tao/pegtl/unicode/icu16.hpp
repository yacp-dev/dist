// Copyright (c) 2018-2026 Dr. Colin Hirsch and Daniel Frey
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at https://www.boost.org/LICENSE_1_0.txt)

#ifndef TAO_PEGTL_UNICODE_ICU16_HPP
#define TAO_PEGTL_UNICODE_ICU16_HPP

#include "../config.hpp"
#include "../system.hpp"

#include "internal/icu_binary_property.hpp"
#include "internal/icu_property_value.hpp"
#include "internal/peek_utf16.hpp"

namespace TAO_PEGTL_NAMESPACE
{
   namespace utf16_be::icu
   {
      template< UProperty P, bool V = true >
      struct binary_property
         : internal::icu_binary_property< internal::peek_utf16_be, P, V >
      {};

      template< UProperty P, int V >
      struct property_value
         : internal::icu_property_value< internal::peek_utf16_be, P, V >
      {};

#include "internal/icu_rules.ipp"  // NOLINT(readability-duplicate-include)

   }  // namespace utf16_be::icu

   namespace utf16_le::icu
   {
      template< UProperty P, bool V = true >
      struct binary_property
         : internal::icu_binary_property< internal::peek_utf16_le, P, V >
      {};

      template< UProperty P, int V >
      struct property_value
         : internal::icu_property_value< internal::peek_utf16_le, P, V >
      {};

#include "internal/icu_rules.ipp"  // NOLINT(readability-duplicate-include)

   }  // namespace utf16_le::icu

   namespace utf16 = TAO_PEGTL_ENDIAN_SUFFIXED( utf16_ );

}  // namespace TAO_PEGTL_NAMESPACE

// FCOV_EXCL_FILE
#endif
