// Copyright (c) 2020-2026 Dr. Colin Hirsch and Daniel Frey
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at https://www.boost.org/LICENSE_1_0.txt)

#ifndef TAO_PEGTL_DEBUG_INTERNAL_ANALYZE_CYCLES_HPP
#define TAO_PEGTL_DEBUG_INTERNAL_ANALYZE_CYCLES_HPP

#include <cassert>
#include <cstddef>
#include <iostream>
#include <map>
#include <set>
#include <string_view>
#include <utility>
#include <vector>

#include "../../config.hpp"
#include "../../demangle.hpp"

#include "../analyze_traits.hpp"

#include "analyze_guards.hpp"

namespace TAO_PEGTL_NAMESPACE::internal
{
   struct analyze_entry
   {
      explicit analyze_entry( const analyze_enum g ) noexcept
         : group( g )
      {}

      const analyze_enum group;
      std::vector< std::string_view > subs;
   };

   class analyze_cycles_impl
   {
   public:
      analyze_cycles_impl( analyze_cycles_impl&& ) = delete;
      analyze_cycles_impl( const analyze_cycles_impl& ) = delete;

      ~analyze_cycles_impl() = default;

      void operator=( analyze_cycles_impl&& ) = delete;
      void operator=( const analyze_cycles_impl& ) = delete;

      [[nodiscard]] std::size_t problems()
      {
         for( auto& i : m_entries ) {
            assert( m_trace.empty() );
            assert( m_stack.empty() );
            m_results[ i.first ] = work( i, false );
         }
         // The number of problems returned is not very informative as some problems will be found multiple times.
         return m_problems;
      }

      template< typename Rule >
      [[nodiscard]] bool consumes() const
      {
         // The name "consumes" is a shortcut for "the analyze cycles algorithm could prove that this rule always consumes when it succeeds".
         return m_results.at( demangle< Rule >() );
      }

   protected:
      explicit analyze_cycles_impl( const int verbose ) noexcept
         : m_verbose( verbose )
      {}

      [[nodiscard]] const std::pair< const std::string_view, analyze_entry >& find( const std::string_view name ) const noexcept
      {
         const auto iter = m_entries.find( name );
         assert( iter != m_entries.end() );
         return *iter;
      }

      [[nodiscard]] bool work( const std::pair< const std::string_view, analyze_entry >& entry, const bool accum )
      {
         if( const auto g = set_stack_guard( m_stack, entry.first ) ) {
            const auto v = vector_stack_guard( m_trace, entry.first );
            switch( entry.second.group ) {
               case analyze_enum::any: {
                  bool a = false;
                  for( const auto& r : entry.second.subs ) {
                     a = a || work( find( r ), accum || a );
                  }
                  return true;
               }
               case analyze_enum::opt: {
                  bool a = false;
                  for( const auto& r : entry.second.subs ) {
                     a = a || work( find( r ), accum || a );
                  }
                  return false;
               }
               case analyze_enum::seq: {
                  bool a = false;
                  for( const auto& r : entry.second.subs ) {
                     a = a || work( find( r ), accum || a );
                  }
                  return a;
               }
               case analyze_enum::sor: {
                  bool a = true;
                  for( const auto& r : entry.second.subs ) {
                     a = a && work( find( r ), accum );
                  }
                  return a;
               }
            }
            assert( false );  // LCOV_EXCL_LINE
         }
         assert( !m_trace.empty() );

         if( !accum ) {
            ++m_problems;
            // LCOV_EXCL_START
            if( ( m_verbose >= 0 ) && ( m_trace.front() == entry.first ) ) {
               for( const auto& r : m_trace ) {
                  if( r < entry.first ) {
                     return accum;
                  }
               }
               std::cerr << "WARNING: Possible cycle without progress at rule " << entry.first << std::endl;
               if( m_verbose > 0 ) {
                  for( const auto& r : m_trace ) {
                     std::cerr << "- involved (transformed) rule: " << r << std::endl;
                  }
               }
            }
            // LCOV_EXCL_STOP
         }
         return accum;
      }

      const int m_verbose;

      std::size_t m_problems = 0;

      std::set< std::string_view > m_stack;
      std::vector< std::string_view > m_trace;
      std::map< std::string_view, bool > m_results;
      std::map< std::string_view, analyze_entry > m_entries;
   };

   template< typename Name >
   [[nodiscard]] std::string_view analyze_insert( std::map< std::string_view, analyze_entry >& entry )
   {
      using Traits = analyze_traits< Name, typename Name::rule_t >;

      const auto [ i, b ] = entry.try_emplace( demangle< Name >(), Traits::enum_v );
      if( b ) {
         analyze_insert_impl( typename Traits::subs_t(), i->second.subs, entry );
      }
      return i->first;
   }

   template< typename... Subs >
   void analyze_insert_impl( type_list< Subs... > /*unused*/, std::vector< std::string_view >& subs, std::map< std::string_view, analyze_entry >& entry )
   {
      ( subs.emplace_back( analyze_insert< Subs >( entry ) ), ... );
   }

   template< typename Grammar >
   struct analyze_cycles
      : analyze_cycles_impl
   {
      explicit analyze_cycles( const int verbose )
         : analyze_cycles_impl( verbose )
      {
         (void)analyze_insert< Grammar >( m_entries );
      }
   };

}  // namespace TAO_PEGTL_NAMESPACE::internal

#endif
