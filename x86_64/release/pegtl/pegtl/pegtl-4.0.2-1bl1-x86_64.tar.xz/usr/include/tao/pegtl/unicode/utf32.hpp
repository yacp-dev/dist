// Copyright (c) 2014-2026 Dr. Colin Hirsch and Daniel Frey
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at https://www.boost.org/LICENSE_1_0.txt)

#ifndef TAO_PEGTL_UNICODE_UTF32_HPP
#define TAO_PEGTL_UNICODE_UTF32_HPP

#include "../config.hpp"
#include "../system.hpp"

#include "../internal/rules.hpp"

#include "internal/peek_utf32.hpp"
#include "internal/utf_one.hpp"
#include "internal/utf_string.hpp"

#define TAO_PEGTL_UTF_NAME utf32_be
#include "internal/utf_rules.ipp"  // NOLINT(readability-duplicate-include)

#define TAO_PEGTL_UTF_NAME utf32_le
#include "internal/utf_rules.ipp"  // NOLINT(readability-duplicate-include)

namespace TAO_PEGTL_NAMESPACE
{
   namespace utf32 = TAO_PEGTL_ENDIAN_SUFFIXED( utf32_ );

}  // namespace TAO_PEGTL_NAMESPACE

// FCOV_EXCL_FILE
#endif
