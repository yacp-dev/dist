#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "atl::atl" for configuration "RelWithDebInfo"
set_property(TARGET atl::atl APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(atl::atl PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libadios2_atl.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygadios2_atl-2.12.dll"
  )

list(APPEND _cmake_import_check_targets atl::atl )
list(APPEND _cmake_import_check_files_for_atl::atl "${_IMPORT_PREFIX}/lib/libadios2_atl.dll.a" "${_IMPORT_PREFIX}/bin/cygadios2_atl-2.12.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
