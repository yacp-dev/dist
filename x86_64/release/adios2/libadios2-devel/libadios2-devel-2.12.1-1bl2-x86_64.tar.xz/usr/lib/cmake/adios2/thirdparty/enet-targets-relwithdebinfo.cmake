#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "enet::enet" for configuration "RelWithDebInfo"
set_property(TARGET enet::enet APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(enet::enet PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libadios2_enet.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygadios2_enet-2.12.dll"
  )

list(APPEND _cmake_import_check_targets enet::enet )
list(APPEND _cmake_import_check_files_for_enet::enet "${_IMPORT_PREFIX}/lib/libadios2_enet.dll.a" "${_IMPORT_PREFIX}/bin/cygadios2_enet-2.12.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
