#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "ffs::ffs" for configuration "RelWithDebInfo"
set_property(TARGET ffs::ffs APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(ffs::ffs PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libadios2_ffs.dll.a"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELWITHDEBINFO "dill::dill"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygadios2_ffs-2.12.dll"
  )

list(APPEND _cmake_import_check_targets ffs::ffs )
list(APPEND _cmake_import_check_files_for_ffs::ffs "${_IMPORT_PREFIX}/lib/libadios2_ffs.dll.a" "${_IMPORT_PREFIX}/bin/cygadios2_ffs-2.12.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
