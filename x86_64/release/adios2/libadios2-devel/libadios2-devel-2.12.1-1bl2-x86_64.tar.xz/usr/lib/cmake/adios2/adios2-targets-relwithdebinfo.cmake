#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "adios2::perfstubs" for configuration "RelWithDebInfo"
set_property(TARGET adios2::perfstubs APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(adios2::perfstubs PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libadios2_perfstubs.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygadios2_perfstubs-2.12.dll"
  )

list(APPEND _cmake_import_check_targets adios2::perfstubs )
list(APPEND _cmake_import_check_files_for_adios2::perfstubs "${_IMPORT_PREFIX}/lib/libadios2_perfstubs.dll.a" "${_IMPORT_PREFIX}/bin/cygadios2_perfstubs-2.12.dll" )

# Import target "adios2::core" for configuration "RelWithDebInfo"
set_property(TARGET adios2::core APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(adios2::core PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libadios2_core.dll.a"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELWITHDEBINFO "sodium;zfp::zfp"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygadios2_core-2.12.dll"
  )

list(APPEND _cmake_import_check_targets adios2::core )
list(APPEND _cmake_import_check_files_for_adios2::core "${_IMPORT_PREFIX}/lib/libadios2_core.dll.a" "${_IMPORT_PREFIX}/bin/cygadios2_core-2.12.dll" )

# Import target "adios2::EncryptionOperator" for configuration "RelWithDebInfo"
set_property(TARGET adios2::EncryptionOperator APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(adios2::EncryptionOperator PROPERTIES
  IMPORTED_COMMON_LANGUAGE_RUNTIME_RELWITHDEBINFO ""
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/adios2/cygEncryptionOperator.dll"
  )

list(APPEND _cmake_import_check_targets adios2::EncryptionOperator )
list(APPEND _cmake_import_check_files_for_adios2::EncryptionOperator "${_IMPORT_PREFIX}/lib/adios2/cygEncryptionOperator.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
