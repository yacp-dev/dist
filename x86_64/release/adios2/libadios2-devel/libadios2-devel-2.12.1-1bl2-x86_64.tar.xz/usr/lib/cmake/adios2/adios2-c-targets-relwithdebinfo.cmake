#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "adios2::c" for configuration "RelWithDebInfo"
set_property(TARGET adios2::c APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(adios2::c PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libadios2_c.dll.a"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELWITHDEBINFO "adios2::core"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygadios2_c-2.12.dll"
  )

list(APPEND _cmake_import_check_targets adios2::c )
list(APPEND _cmake_import_check_files_for_adios2::c "${_IMPORT_PREFIX}/lib/libadios2_c.dll.a" "${_IMPORT_PREFIX}/bin/cygadios2_c-2.12.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
