#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "EVPath::EVPath" for configuration "RelWithDebInfo"
set_property(TARGET EVPath::EVPath APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(EVPath::EVPath PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libadios2_evpath.dll.a"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELWITHDEBINFO "dill::dill;enet::enet"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygadios2_evpath-2.12.dll"
  )

list(APPEND _cmake_import_check_targets EVPath::EVPath )
list(APPEND _cmake_import_check_files_for_EVPath::EVPath "${_IMPORT_PREFIX}/lib/libadios2_evpath.dll.a" "${_IMPORT_PREFIX}/bin/cygadios2_evpath-2.12.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
