rm -f /usr/share/icons/hicolor/icon-theme.cache
rm -f /usr/share/icons/hicolor/icon-theme.cache
