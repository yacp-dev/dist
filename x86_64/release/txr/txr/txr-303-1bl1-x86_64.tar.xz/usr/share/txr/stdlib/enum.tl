;; Copyright 2025
;; Kaz Kylheku <kaz@kylheku.com>
;; Vancouver, Canada
;; All rights reserved.
;;
;; Redistribution and use in source and binary forms, with or without
;; modification, are permitted provided that the following conditions are met:
;;
;; 1. Redistributions of source code must retain the above copyright notice,
;;    this list of conditions and the following disclaimer.
;;
;; 2. Redistributions in binary form must reproduce the above copyright notice,
;;    this list of conditions and the following disclaimer in the documentation
;;    and/or other materials provided with the distribution.
;;
;; THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
;; AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
;; IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
;; ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
;; LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
;; CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
;; SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
;; INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
;; CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
;; ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
;; POSSIBILITY OF SUCH DAMAGE.

(defun normalize-enum-pairs (f enum-pairs)
  (let ((n 0))
    (keep-matches (@(or (@sym @init)
                        @(with @sym init n))
                    enum-pairs)
      (unless (bindable sym)
        (compile-error f "~s isn't a bindable symbol" sym))
      (unless (or (integerp init) (chrp init))
        (compile-error f "~s must be an integer or character" init))
      (set n (succ init))
      ^(,sym ,init))))
                   
(defmacro defenum (:form f . enum-pairs)
  (let ((nep (normalize-enum-pairs f enum-pairs)))
    ^(progn ,*(mapcar (op cons 'defsymacro) nep))))

(defmacro enumlet (:form f enum-pairs . body)
  (let ((nep (normalize-enum-pairs f enum-pairs)))
    ^(symacrolet ,nep ,*body)))
