(defvarl lib-version 303)
(defvarl *lib-version* lib-version)
