;; Copyright 2025
;; Kaz Kylheku <kaz@kylheku.com>
;; Vancouver, Canada
;; All rights reserved.
;;
;; Redistribution and use in source and binary forms, with or without
;; modification, are permitted provided that the following conditions are met:
;;
;; 1. Redistributions of source code must retain the above copyright notice,
;;    this list of conditions and the following disclaimer.
;;
;; 2. Redistributions in binary form must reproduce the above copyright notice,
;;    this list of conditions and the following disclaimer in the documentation
;;    and/or other materials provided with the distribution.
;;
;; THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
;; AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
;; IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
;; ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
;; LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
;; CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
;; SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
;; INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
;; CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
;; ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
;; POSSIBILITY OF SUCH DAMAGE.

(defun hmac-impl (key message
                  digest-fn begin-fn update-fn end-fn
                  block-size)
  (if (stringp key)
    (upd key buf-str))

  (if (stringp message)
    (upd message buf-str))

  (if (> (len key) block-size)
    (upd key digest-fn))

  (buf-set-length key block-size)

  (let ((okey (buf-xor-pattern key #x5c))
        (ikey (buf-xor-pattern key #x36))
        (ctx0 [begin-fn])
        (ctx1 [begin-fn]))
    [update-fn ctx0 ikey]
    [update-fn ctx0 message]
    [update-fn ctx1 okey]
    [update-fn ctx1 [end-fn ctx0]]
    [end-fn ctx1]))

(defun hmac-sha1 (key message)
  [hmac-impl key message sha1 sha1-begin sha1-hash sha1-end 64])

(defun hmac-sha256 (key message)
  [hmac-impl key message sha256 sha256-begin sha256-hash sha256-end 64])

(defun hmac-md5 (key message)
  [hmac-impl key message md5 md5-begin md5-hash md5-end 64])
