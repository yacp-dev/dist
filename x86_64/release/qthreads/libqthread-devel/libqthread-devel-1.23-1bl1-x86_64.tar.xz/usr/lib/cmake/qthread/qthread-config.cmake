include("${CMAKE_CURRENT_LIST_DIR}/qthread.cmake")
