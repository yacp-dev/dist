/* wolftpm options.h
 * generated from configure options
 *
 * Copyright (C) 2006-2026 wolfSSL Inc.
 *
 * * This file is part of wolfTPM.
 *
 */

#ifndef WOLFMTPM_OPTIONS_H
#define WOLFMTPM_OPTIONS_H


#ifdef __cplusplus
extern "C" {
#endif

#ifndef WOLFSSL_OPTIONS_IGNORE_SYS
#undef  _FORTIFY_SOURCE
#define _FORTIFY_SOURCE 3
#endif

#undef  WOLF_CRYPTO_CB
#define WOLF_CRYPTO_CB

#undef  XREWIND
#define XREWIND rewind

#undef  HAVE_THREAD_LS
#define HAVE_THREAD_LS

#undef  SIZEOF_LONG
#define SIZEOF_LONG 8

#undef  WOLFTPM_AUTODETECT
#define WOLFTPM_AUTODETECT

#undef  WOLFTPM_EXAMPLE_HAL
#define WOLFTPM_EXAMPLE_HAL

#undef  WOLFTPM_CHECK_WAIT_STATE
#define WOLFTPM_CHECK_WAIT_STATE

#undef  WOLFTPM_FIRMWARE_UPGRADE
#define WOLFTPM_FIRMWARE_UPGRADE

#undef  WOLFTPM_PROVISIONING
#define WOLFTPM_PROVISIONING


#ifdef __cplusplus
}
#endif


#endif /* WOLFMTPM_OPTIONS_H */

