/* reset.c
 *
 * Copyright (C) 2006-2026 wolfSSL Inc.
 *
 * This file is part of wolfTPM.
 *
 * wolfTPM is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * wolfTPM is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1335, USA
 */

/* This is a helper tool for resetting the value of a TPM2.0 PCR */

#ifdef HAVE_CONFIG_H
    #include <config.h>
#endif

#include <wolftpm/tpm2_wrap.h>

#ifndef WOLFTPM2_NO_WRAPPER

#include <examples/pcr/pcr.h>
#include <hal/tpm_io.h>
#include <examples/tpm_test.h>

#include <stdio.h>


/******************************************************************************/
/* --- BEGIN TPM2.0 PCR Reset example tool  -- */
/******************************************************************************/

static void usage(void)
{
    printf("Expected usage:\n");
    printf("./examples/pcr/reset [pcr] [-loc=n]\n");
    printf("* pcr is a PCR index between 0-23 (default %d)\n", TPM2_TEST_PCR);
    printf("* -loc=n switch to TPM locality n (0-4) before reset\n");
    printf("    (PCR 17-19 need locality 4; 20-22 need locality 2-4;\n");
    printf("     enforced by the fwTPM and by discrete TPMs like the ST33)\n");
    printf("Demo usage without parameters, resets PCR%d.\n", TPM2_TEST_PCR);
}

int TPM2_PCR_Reset_Test(void* userCtx, int argc, char *argv[])
{
    int i, j, pcrIndex = TPM2_TEST_PCR, rc = -1;
    int locality = -1; /* -1 means leave at default locality */
    int localitySwitched = 0;
    WOLFTPM2_DEV dev;

    union {
        PCR_Read_In pcrRead;
        PCR_Reset_In pcrReset;
        byte maxInput[MAX_COMMAND_SIZE];
    } cmdIn;
    union {
        PCR_Read_Out pcrRead;
        byte maxOutput[MAX_RESPONSE_SIZE];
    } cmdOut;

    /* Parse arguments: an optional PCR index and an optional -loc=n flag */
    for (i = 1; i < argc; i++) {
        if (XSTRNCMP(argv[i], "-loc=", 5) == 0) {
            /* Require exactly one digit 0-4; XATOI would silently map
             * non-numeric input (e.g. -loc=abc or -loc=) to locality 0. */
            if (argv[i][5] < '0' || argv[i][5] > '4' || argv[i][6] != '\0') {
                printf("Locality is out of range (0-4)\n");
                usage();
                goto exit_badargs;
            }
            locality = argv[i][5] - '0';
        }
        else if (argv[i][0] >= '0' && argv[i][0] <= '9') {
            pcrIndex = XATOI(argv[i]);
            if (pcrIndex < 0 || pcrIndex > 23) {
                printf("PCR index is out of range (0-23)\n");
                usage();
                goto exit_badargs;
            }
        }
        else {
            printf("Incorrect arguments\n");
            usage();
            goto exit_badargs;
        }
    }

    printf("Demo how to reset a PCR (clear PCR value)\n");
    rc = wolfTPM2_Init(&dev, TPM2_IoCb, userCtx);
    if (rc != TPM_RC_SUCCESS) {
        printf("wolfTPM2_Init failed 0x%x: %s\n", rc, TPM2_GetRCString(rc));
        goto exit;
    }
    printf("wolfTPM2_Init: success\n");

    if (locality >= 0) {
        printf("Switching to locality %d...\n", locality);
        rc = wolfTPM2_SetLocality(&dev, locality);
        if (rc != TPM_RC_SUCCESS) {
            printf("wolfTPM2_SetLocality(%d) failed 0x%x: %s\n", locality, rc,
                TPM2_GetRCString(rc));
            goto exit;
        }
        printf("wolfTPM2_SetLocality: now at locality %d\n", locality);
        localitySwitched = 1;
    }

    /* Prepare PCR Reset command */
    XMEMSET(&cmdIn.pcrReset, 0, sizeof(cmdIn.pcrReset));
    cmdIn.pcrReset.pcrHandle = pcrIndex;
    printf("Trying to reset PCR%d...\n", cmdIn.pcrReset.pcrHandle);
    rc = TPM2_PCR_Reset(&cmdIn.pcrReset);
    if (rc != TPM_RC_SUCCESS) {
        printf("TPM2_PCR_Reset failed 0x%x: %s\n", rc,
            TPM2_GetRCString(rc));
        goto exit;
    }
    printf("TPM2_PCR_Reset success\n");

    XMEMSET(&cmdIn.pcrRead, 0, sizeof(cmdIn.pcrRead));
    TPM2_SetupPCRSel(&cmdIn.pcrRead.pcrSelectionIn, TEST_WRAP_DIGEST, pcrIndex);
    rc = TPM2_PCR_Read(&cmdIn.pcrRead, &cmdOut.pcrRead);
    if (rc != TPM_RC_SUCCESS) {
        printf("TPM2_PCR_Read failed 0x%x: %s\n", rc, TPM2_GetRCString(rc));
        goto exit;
    }
    for (i=0; i < (int)cmdOut.pcrRead.pcrValues.count; i++) {
        printf("PCR%d (idx %d) digest:\n", pcrIndex, i);
        for (j=0; j < cmdOut.pcrRead.pcrValues.digests[i].size; j++)
            printf("%02X", cmdOut.pcrRead.pcrValues.digests[i].buffer[j]);
        printf("\n");
    }

exit:

    /* Return to the default locality so a non-zero one is not left active
     * (which would block the next TPM startup on TPMs that do not preempt).
     * Only when a switch actually succeeded - never on a failed Init. */
    if (localitySwitched) {
        (void)wolfTPM2_SetLocality(&dev, 0);
    }

    wolfTPM2_Cleanup(&dev);

exit_badargs:

    return rc;
}

/******************************************************************************/
/* --- END TPM2.0 PCR Reset example tool -- */
/******************************************************************************/
#endif /* !WOLFTPM2_NO_WRAPPER */

#ifndef NO_MAIN_DRIVER
int main(int argc, char *argv[])
{
    int rc = -1;

#ifndef WOLFTPM2_NO_WRAPPER
    rc = TPM2_PCR_Reset_Test(NULL, argc, argv);
#else
    printf("Wrapper code not compiled in\n");
    (void)argc;
    (void)argv;
#endif /* !WOLFTPM2_NO_WRAPPER */

    return rc;
}
#endif
