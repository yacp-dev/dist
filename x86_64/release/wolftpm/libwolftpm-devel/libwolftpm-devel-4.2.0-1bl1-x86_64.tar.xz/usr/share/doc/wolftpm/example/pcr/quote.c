/* quote.c
 *
 * Copyright (C) 2006-2026 wolfSSL Inc.
 *
 * This file is part of wolfTPM.
 *
 * wolfTPM is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * wolfTPM is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1335, USA
 */

/* This example shows how to generate a TPM2.0 Quote that holds a signed
 * PCR measurement. PCR values are used as basis for system integrity.
 */

#ifdef HAVE_CONFIG_H
    #include <config.h>
#endif

#include <wolftpm/tpm2_wrap.h>

#ifndef WOLFTPM2_NO_WRAPPER
#include <examples/pcr/quote.h>
#include <hal/tpm_io.h>
#include <examples/tpm_test.h>
#include <examples/tpm_test_keys.h>

#include <stdio.h>

/******************************************************************************/
/* --- BEGIN TPM2.0 Quote Test -- */
/******************************************************************************/

static void usage(void)
{
    printf("Expected usage:\n");
    printf("./examples/pcr/quote [pcr] [filename] [-ecc] [-aes/xor]\n");
    printf("* pcr: PCR index between 0-23 (default %d)\n", TPM2_TEST_PCR);
    printf("* filename: for saving the TPMS_ATTEST structure to a file\n");
    printf("* -ecc: Use RSA or ECC for SRK/AIK\n");
    printf("* -aes/xor: Use Parameter Encryption\n");
#ifdef WOLFTPM_MLKEM
    printf("* -mlkem[=512|768|1024]: Use an ML-KEM key as the param-enc "
           "session salt (v1.85, default 768)\n");
#endif
#ifdef WOLFTPM_MLDSA
    printf("* -mldsa[=44|65|87]: Use an ML-DSA key as the param-enc "
           "session bind (v1.85, default 65)\n");
#endif
    printf("Demo usage without parameters, generates quote over PCR%d and\n"
           "saves the output TPMS_ATTEST structure to \"quote.blob\" file.\n",
           TPM2_TEST_PCR);
}

int TPM2_PCR_Quote_Test(void* userCtx, int argc, char *argv[])
{
    int pcrIndex = TPM2_TEST_PCR, rc = -1;
    const char *outputFile = "quote.blob";
    BYTE *data = NULL;
    int dataSz;
#if defined(HAVE_ECC) && !defined(WOLFTPM2_NO_HEAP) && \
    defined(WOLFSSL_PUBLIC_MP)
    byte *pubKey = NULL;
    word32 pubKeySz = 0;
#endif
    WOLFTPM2_DEV dev;
    TPMS_ATTEST attestedData;
    TPMI_ALG_PUBLIC alg = TPM_ALG_RSA; /* TPM_ALG_ECC */
    WOLFTPM2_KEY storage; /* SRK */
    WOLFTPM2_KEY aik;  /* AIK */
    union {
        Quote_In quoteAsk;
        byte maxInput[MAX_COMMAND_SIZE];
    } cmdIn;
    union {
        Quote_Out quoteResult;
        byte maxOutput[MAX_RESPONSE_SIZE];
    } cmdOut;
    TPM_ALG_ID paramEncAlg = TPM_ALG_NULL;
    WOLFTPM2_SESSION tpmSession;
#if defined(WOLFTPM_MLKEM) || defined(WOLFTPM_MLDSA)
    TPM_ALG_ID pqcParamEncAlg = TPM_ALG_NULL;
    int pqcParamSet = 0;
    int pqcRc = 0;
    WOLFTPM2_KEY pqcKey;
#endif
#if !defined(NO_FILESYSTEM) && !defined(NO_WRITE_TEMP_FILES)
    XFILE f;
#endif

    XMEMSET(&storage, 0, sizeof(storage));
    XMEMSET(&aik, 0, sizeof(aik));
    XMEMSET(&tpmSession, 0, sizeof(tpmSession));
#if defined(WOLFTPM_MLKEM) || defined(WOLFTPM_MLDSA)
    XMEMSET(&pqcKey, 0, sizeof(pqcKey));
#endif

    if (argc >= 2) {
        if (XSTRCMP(argv[1], "-?") == 0 ||
            XSTRCMP(argv[1], "-h") == 0 ||
            XSTRCMP(argv[1], "--help") == 0) {
            usage();
            return 0;
        }

        /* Advanced usage */
        if (argv[1][0] != '-') {
            if (*argv[1] < '0' || *argv[1] > '9') {
                printf("PCR index is out of range (0-23)\n");
                usage();
                return 0;
            }
            pcrIndex = XATOI(argv[1]);
            if (pcrIndex < 0 || pcrIndex > 23) {
                printf("PCR index is out of range (0-23)\n");
                usage();
                return 0;
            }
        }
        if (argc >= 3 && argv[2][0] != '-')
            outputFile = argv[2];
    }
    while (argc > 1) {
        if (XSTRCMP(argv[argc-1], "-ecc") == 0) {
            alg = TPM_ALG_ECC;
        }
        else if (XSTRCMP(argv[argc-1], "-aes") == 0) {
            paramEncAlg = TPM_ALG_CFB;
        }
        else if (XSTRCMP(argv[argc-1], "-xor") == 0) {
            paramEncAlg = TPM_ALG_XOR;
        }
#if defined(WOLFTPM_MLKEM) || defined(WOLFTPM_MLDSA)
        else if ((pqcRc = parsePqcParamEncArg(argv[argc-1], &pqcParamEncAlg,
                     &pqcParamSet)) != 0) {
            /* An unsupported parameter set (parser returns -1) is a fatal typo,
             * not a silent drop of parameter encryption. Branch on the parser
             * result directly: pqcParamEncAlg may already hold a valid alg from
             * an earlier PQC option (argv is parsed right-to-left). */
            if (pqcRc < 0) {
                usage();
                return -1;
            }
        }
#endif
        argc--;
    }

#if defined(WOLFTPM_MLKEM) || defined(WOLFTPM_MLDSA)
    /* A PQC param-enc key only supplies the salt/bind material; a symmetric
     * session cipher is still required. Default to AES-CFB if none given. */
    if (pqcParamEncAlg != TPM_ALG_NULL && paramEncAlg == TPM_ALG_NULL) {
        paramEncAlg = TPM_ALG_CFB;
        printf("PQC param-enc key selected; defaulting session cipher to "
            "AES-CFB.\n");
    }
#endif

    printf("PCR Quote example - Demo of signed PCR measurement\n");
    printf("\tOutput file: %s\n", outputFile);
    printf("\tPCR Index: %d\n", pcrIndex);
    printf("\tUse %s SRK/AIK\n", TPM2_GetAlgName(alg));
    printf("\tUse Parameter Encryption: %s\n", TPM2_GetAlgName(paramEncAlg));

    rc = wolfTPM2_Init(&dev, TPM2_IoCb, userCtx);
    if (rc != TPM_RC_SUCCESS) {
        printf("wolfTPM2_Init failed 0x%x: %s\n", rc, TPM2_GetRCString(rc));
        goto exit;
    }
    printf("wolfTPM2_Init: success\n");

    /* get SRK */
    rc = getPrimaryStoragekey(&dev, &storage, alg);
    if (rc != 0) goto exit;

    /* Create key for Attestation purposes */
    rc = wolfTPM2_CreateAndLoadAIK(&dev, &aik, alg, &storage,
        (const byte*)gUsageAuth, sizeof(gUsageAuth)-1);
    if (rc != TPM_RC_SUCCESS) {
        printf("wolfTPM2_CreateAndLoadAIK failed 0x%x: %s\n", rc,
            TPM2_GetRCString(rc));
        goto exit;
    }
    printf("wolfTPM2_CreateAndLoadAIK: AIK 0x%x (%d bytes)\n",
        (word32)aik.handle.hndl, aik.pub.size);

#if defined(HAVE_ECC) && !defined(WOLFTPM2_NO_HEAP) && \
    defined(WOLFSSL_PUBLIC_MP)
    if (alg == TPM_ALG_ECC) {
        word32 i;

        rc = wolfTPM2_ExportPublicKeyBuffer(&dev, &aik, ENCODING_TYPE_ASN1,
            NULL, &pubKeySz);
        if (rc != TPM_RC_SUCCESS) {
            printf("wolfTPM2_ExportPublicKeyBuffer failed 0x%x: %s\n", rc,
                TPM2_GetRCString(rc));
            goto exit;
        }

        pubKey = (byte*)XMALLOC(pubKeySz, NULL, DYNAMIC_TYPE_PUBLIC_KEY);
        if (pubKey == NULL) {
            printf("Failed to malloc buffer for public key\n");
            rc = MEMORY_E;
            goto exit;
        }

        rc = wolfTPM2_ExportPublicKeyBuffer(&dev, &aik, ENCODING_TYPE_ASN1,
            pubKey, &pubKeySz);
        if (rc != TPM_RC_SUCCESS) {
            printf("wolfTPM2_ExportPublicKeyBuffer failed 0x%x: %s\n", rc,
                TPM2_GetRCString(rc));
            goto exit;
        }

        printf("Public Key for AIK [in Hex] : ");
        for (i = 0; i < pubKeySz; i++)
            printf("%02X", pubKey[i]);
        printf("\n");
    }
#endif

    if (paramEncAlg != TPM_ALG_NULL) {
        WOLFTPM2_KEY* bindKey = &storage;
    #ifndef HAVE_ECC
        if (alg == TPM_ALG_ECC)
            bindKey = NULL; /* cannot bind to key without ECC enabled */
    #endif
    #ifdef NO_RSA
        if (alg == TPM_ALG_RSA)
            bindKey = NULL; /* cannot bind to key without RSA enabled */
    #endif
    #if defined(WOLFTPM_MLKEM) || defined(WOLFTPM_MLDSA)
        if (pqcParamEncAlg != TPM_ALG_NULL) {
            /* Use a PQC primary as the param-enc session key: ML-KEM salt
             * or ML-DSA bind. The RSA/ECC SRK stays the AIK parent. */
            rc = getPrimaryParamEncKey(&dev, &tpmSession, &pqcKey,
                pqcParamEncAlg, pqcParamSet, paramEncAlg);
        }
        else
    #endif
        {
            /* Start an authenticated session (salted / unbound) with parameter encryption */
            rc = wolfTPM2_StartSession(&dev, &tpmSession, bindKey, NULL,
                TPM_SE_HMAC, paramEncAlg);
        }
        if (rc != 0) goto exit;
        printf("TPM2_StartAuthSession: sessionHandle 0x%x\n",
            (word32)tpmSession.handle.hndl);

        /* set session for authorization of the storage key */
        rc = wolfTPM2_SetAuthSession(&dev, 1, &tpmSession,
            (TPMA_SESSION_decrypt | TPMA_SESSION_encrypt | TPMA_SESSION_continueSession));
        if (rc != 0) goto exit;
    }

    /* set auth for using the AIK */
    wolfTPM2_SetAuthHandle(&dev, 0, &aik.handle);

    /* Prepare Quote request */
    XMEMSET(&cmdIn.quoteAsk, 0, sizeof(cmdIn.quoteAsk));
    XMEMSET(&cmdOut.quoteResult, 0, sizeof(cmdOut.quoteResult));
    cmdIn.quoteAsk.signHandle = aik.handle.hndl;
    cmdIn.quoteAsk.inScheme.scheme = alg == TPM_ALG_RSA ? TPM_ALG_RSASSA : TPM_ALG_ECDSA;
    cmdIn.quoteAsk.inScheme.details.any.hashAlg = TPM_ALG_SHA256;
    cmdIn.quoteAsk.qualifyingData.size = 0; /* optional */
    /* Choose PCR for signing */
    TPM2_SetupPCRSel(&cmdIn.quoteAsk.PCRselect, TPM_ALG_SHA256, pcrIndex);

    /* Get the PCR measurement signed by the TPM using the AIK key */
    rc = TPM2_Quote(&cmdIn.quoteAsk, &cmdOut.quoteResult);
    if (rc != TPM_RC_SUCCESS) {
        printf("TPM2_Quote failed 0x%x: %s\n", rc, TPM2_GetRCString(rc));
        goto exit;
    }
    printf("TPM2_Quote: success\n");

    rc = TPM2_ParseAttest(&cmdOut.quoteResult.quoted, &attestedData);
    if (rc != TPM_RC_SUCCESS) {
        printf("TPM2_Packet_ParseAttest failed 0x%x: %s\n", rc,
            TPM2_GetRCString(rc));
        goto exit;
    }
    if (attestedData.magic != TPM_GENERATED_VALUE) {
        printf("\tError, attested data not generated by the TPM = 0x%X\n",
            attestedData.magic);
    }

    /* Save quote blob to the disk */
    data = cmdOut.quoteResult.quoted.attestationData;
    dataSz = cmdOut.quoteResult.quoted.size;
#if !defined(NO_FILESYSTEM) && !defined(NO_WRITE_TEMP_FILES)
    f = XFOPEN(outputFile, "wb");
    if (f == XBADFILE) {
        printf("Failed to open %s for writing\n", outputFile);
        rc = BAD_FUNC_ARG;
        goto exit;
    }
    dataSz = (int)XFWRITE(data, 1, dataSz, f);
    XFCLOSE(f);
    if (dataSz != (int)cmdOut.quoteResult.quoted.size) {
        printf("Failed to write quote to %s\n", outputFile);
        rc = BAD_FUNC_ARG;
        goto exit;
    }
    printf("Wrote %d bytes to %s\n", dataSz, outputFile);
#else
    printf("Quote Blob %d\n", dataSz);
    TPM2_PrintBin(data, dataSz);
    (void)data;
    (void)dataSz;
#endif

    printf("TPM with signature attests (type 0x%x):\n", attestedData.type);
    printf("\tTPM signed %lu count of PCRs\n",
        (unsigned long)attestedData.attested.quote.pcrSelect.count);
#ifdef DEBUG_WOLFTPM
    printf("\tPCR digest:\n");
    TPM2_PrintBin(attestedData.attested.quote.pcrDigest.buffer,
        attestedData.attested.quote.pcrDigest.size);
    printf("\tTPM generated signature:\n");
    TPM2_PrintBin(cmdOut.quoteResult.signature.signature.rsassa.sig.buffer,
        cmdOut.quoteResult.signature.signature.rsassa.sig.size);
#endif

#if defined(HAVE_ECC) && !defined(WOLFTPM2_NO_HEAP) && \
    defined(WOLFSSL_PUBLIC_MP)
    if (alg == TPM_ALG_ECC &&
          cmdOut.quoteResult.signature.signature.ecdsa.hash == TPM_ALG_SHA256) {
        int res = 0;
        word32 inOutIdx = 0;
        mp_int r,s;
        ecc_key ecKey;
        wc_Sha256 sha256;
        byte digest[WC_SHA256_DIGEST_SIZE];

        printf("Attempting to manually verify the quotes signature :");

        /* re-create the hash that was signed */
        rc = wc_InitSha256(&sha256);
        if (cmdIn.quoteAsk.qualifyingData.size > 0) {
            /* do a wc_Sha256Update with qualifying data first if used */
        }
        if (rc == 0) {
            rc = wc_Sha256Update(&sha256,
                cmdOut.quoteResult.quoted.attestationData,
                cmdOut.quoteResult.quoted.size);
        }
        if (rc == 0) {
            wc_Sha256Final(&sha256, digest);
        }
        wc_Sha256Free(&sha256);

        /* read in the public key and the signature r/s values */
        rc = wc_ecc_init(&ecKey);
        if (rc == 0) {
            rc = wc_EccPublicKeyDecode(pubKey, &inOutIdx, &ecKey, pubKeySz);
        }
        mp_init(&r);
        mp_init(&s);
        mp_read_unsigned_bin(&r,
            cmdOut.quoteResult.signature.signature.ecdsa.signatureR.buffer,
            cmdOut.quoteResult.signature.signature.ecdsa.signatureR.size);
        mp_read_unsigned_bin(&s,
            cmdOut.quoteResult.signature.signature.ecdsa.signatureS.buffer,
            cmdOut.quoteResult.signature.signature.ecdsa.signatureS.size);

        /* try to confirm the signature */
        if (rc == 0) {
            rc = wc_ecc_verify_hash_ex(&r, &s, digest, WC_SHA256_DIGEST_SIZE,
                &res, &ecKey);
        }
        mp_free(&r);
        mp_free(&s);
        wc_ecc_free(&ecKey);
        printf("%s [rc = %d, result = %d]\n", (res == 1)? "SUCCESS": "FAILURE",
            rc, res);
    }
#endif

exit:

    /* Close key handles */
    wolfTPM2_UnloadHandle(&dev, &aik.handle);
    wolfTPM2_UnloadHandle(&dev, &storage.handle);
    wolfTPM2_UnloadHandle(&dev, &tpmSession.handle);
#if defined(WOLFTPM_MLKEM) || defined(WOLFTPM_MLDSA)
    wolfTPM2_UnloadHandle(&dev, &pqcKey.handle);
#endif

    wolfTPM2_Cleanup(&dev);

#if defined(HAVE_ECC) && !defined(WOLFTPM2_NO_HEAP) && \
    defined(WOLFSSL_PUBLIC_MP)
    if (pubKey != NULL) {
        XFREE(pubKey, NULL, DYNAMIC_TYPE_PUBLIC_KEY);
    }
#endif
    return rc;
}

/******************************************************************************/
/* --- END TPM2.0 Quote Test -- */
/******************************************************************************/

#endif /* !WOLFTPM2_NO_WRAPPER */

#ifndef NO_MAIN_DRIVER
int main(int argc, char *argv[])
{
    int rc = -1;

#ifndef WOLFTPM2_NO_WRAPPER
    rc = TPM2_PCR_Quote_Test(NULL, argc, argv);
#else
    printf("Wrapper code not compiled in\n");
    (void)argc;
    (void)argv;
#endif /* !WOLFTPM2_NO_WRAPPER */
    return rc;
}
#endif
