#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "ISAL::isal" for configuration "RelWithDebInfo"
set_property(TARGET ISAL::isal APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(ISAL::isal PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libisal.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygisal-2.dll"
  )

list(APPEND _cmake_import_check_targets ISAL::isal )
list(APPEND _cmake_import_check_files_for_ISAL::isal "${_IMPORT_PREFIX}/lib/libisal.dll.a" "${_IMPORT_PREFIX}/bin/cygisal-2.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
