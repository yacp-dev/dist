#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "mailio::mailio" for configuration "RelWithDebInfo"
set_property(TARGET mailio::mailio APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(mailio::mailio PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libmailio.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygmailio-2.dll"
  )

list(APPEND _cmake_import_check_targets mailio::mailio )
list(APPEND _cmake_import_check_files_for_mailio::mailio "${_IMPORT_PREFIX}/lib/libmailio.dll.a" "${_IMPORT_PREFIX}/bin/cygmailio-2.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
