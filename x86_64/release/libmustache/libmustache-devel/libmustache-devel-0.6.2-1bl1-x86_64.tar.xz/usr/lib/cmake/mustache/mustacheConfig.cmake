
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was mustacheConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

# Use original install prefix when loaded through a "/usr move"
# cross-prefix symbolic link such as /lib -> /usr/lib.
get_filename_component(_realCurr "${CMAKE_CURRENT_LIST_DIR}" REALPATH)
get_filename_component(_realOrig "/usr/lib/cmake/mustache" REALPATH)
if(_realCurr STREQUAL _realOrig)
  set(PACKAGE_PREFIX_DIR "/usr")
endif()
unset(_realOrig)
unset(_realCurr)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

set(_mustache_supported_components shared static)
if(NOT mustache_FIND_COMPONENTS)
    set(mustache_FIND_COMPONENTS shared)
endif()

foreach(_mustache_component IN LISTS mustache_FIND_COMPONENTS)
    if(NOT _mustache_component IN_LIST _mustache_supported_components)
        set(mustache_${_mustache_component}_FOUND FALSE)
        set(mustache_NOT_FOUND_MESSAGE
            "Unsupported mustache component: ${_mustache_component}")
    endif()
endforeach()

if(shared IN_LIST mustache_FIND_COMPONENTS)
    include("${CMAKE_CURRENT_LIST_DIR}/mustacheSharedTargets.cmake")
    set(mustache_shared_FOUND TRUE)
endif()

if(static IN_LIST mustache_FIND_COMPONENTS)
    set(_mustache_static_dependencies_found TRUE)
    if(ON)
        if(MSVC)
            find_package(yaml QUIET CONFIG)
            if(NOT TARGET yaml AND NOT TARGET yaml::yaml)
                set(_mustache_static_dependencies_found FALSE)
            endif()
        else()
            find_package(PkgConfig QUIET)
            if(PkgConfig_FOUND)
                pkg_check_modules(YAML QUIET IMPORTED_TARGET yaml-0.1)
            endif()
            if(NOT PkgConfig_FOUND OR NOT YAML_FOUND)
                set(_mustache_static_dependencies_found FALSE)
            endif()
        endif()
    endif()

    if(ON)
        if(OFF)
            find_package(xxHash 0.8 QUIET CONFIG)
            if(NOT TARGET xxHash::xxhash)
                set(_mustache_static_dependencies_found FALSE)
            endif()
        endif()
    endif()

    if(_mustache_static_dependencies_found)
        include("${CMAKE_CURRENT_LIST_DIR}/mustacheStaticTargets.cmake")
        set(mustache_static_FOUND TRUE)
    else()
        set(mustache_static_FOUND FALSE)
        if(mustache_FIND_REQUIRED_static)
            set(mustache_FOUND FALSE)
            set(mustache_NOT_FOUND_MESSAGE
                "The mustache static component's private dependencies are unavailable")
            return()
        endif()
    endif()
endif()

check_required_components(mustache)
