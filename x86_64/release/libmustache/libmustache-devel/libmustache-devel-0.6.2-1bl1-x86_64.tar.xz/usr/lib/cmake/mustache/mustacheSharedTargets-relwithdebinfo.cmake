#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "mustache::mustache" for configuration "RelWithDebInfo"
set_property(TARGET mustache::mustache APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(mustache::mustache PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libmustache.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygmustache-6.dll"
  )

list(APPEND _cmake_import_check_targets mustache::mustache )
list(APPEND _cmake_import_check_files_for_mustache::mustache "${_IMPORT_PREFIX}/lib/libmustache.dll.a" "${_IMPORT_PREFIX}/bin/cygmustache-6.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
