
#ifndef MUSTACHE_UTILS_HPP
#define MUSTACHE_UTILS_HPP

#include "mustache_export.hpp"

#include <string>
#include <string_view>
#include <vector>

namespace mustache {

//! Whitespace character list
inline constexpr std::string_view whiteSpaces(" \f\n\r\t\v");

//! Special HTML character list
inline constexpr std::string_view specialChars("&\"'<>");

//! String whitespace from a string
/*!
  /param str The string to strip
  /param trimChars The charaters to strip
*/
MUSTACHE_API void stripWhitespace(std::string& str, std::string_view chars = whiteSpaces);

//! Trim trailing zeros from a decimal-like string
/*!
  /param str The string to trim
*/
MUSTACHE_API void trimDecimal(std::string& str);

//! Trim a string (right)
/*!
  http://stackoverflow.com/a/479091
  /param str The string to trim
  /param trimChars The charaters to trim off
*/
MUSTACHE_API void trimRight(std::string& str, std::string_view trimChars = whiteSpaces);

//! Trim a string (left)
/*!
  http://stackoverflow.com/a/479091
  /param str The string to trim
  /param trimChars The charaters to trim off
*/
MUSTACHE_API void trimLeft(std::string& str, std::string_view trimChars = whiteSpaces);

//! Trim a string
/*!
  http://stackoverflow.com/a/479091
  /param str The string to trim
  /param trimChars The charaters to trim off
*/
MUSTACHE_API void trim(std::string& str, std::string_view trimChars = whiteSpaces);

//! Escape special HTML charcters.
/*!
  Not multibyte safe
  /param str The string to escape
  \throws mustache::Exception if str is null
*/
MUSTACHE_API void htmlspecialchars(std::string * str);

//! Escape special HTML charcters and append to string.
/*!
  Not multibyte safe
  /param str The string to escape
  /param buf The string to append to
  \throws mustache::Exception if str or buf is null
*/
MUSTACHE_API void htmlspecialchars_append(std::string * str, std::string * buf);

//! Const-safe overload for owned scalar values. Throws mustache::Exception if buf is null.
MUSTACHE_API void htmlspecialchars_append(const std::string& str, std::string * buf);

//! Explode a string.
/*!
  http://www.zedwood.com/article/106/cpp-explode-function
  /param delimiter The delimiter to explode by
  /param str The string to explode
  /param arr The chunks are stored here
  \throws mustache::Exception if arr is null
*/
MUSTACHE_API void explode(const std::string& delimiter, const std::string& str, std::vector<std::string> * arr);

//! Tokenize a string (strtok for std::string)
/*!
  http://oopweb.com/CPP/Documents/CPPHOWTO/Volume/C++Programming-HOWTO-7.html
  /param str The string to tokenize
  /param delimiters The delimiters to tokenize by
  /param tokens The tokens are stored here
  \throws mustache::Exception if tokens is null
*/
MUSTACHE_API void stringTok(const std::string& str, std::string_view delimiters, std::vector<std::string> * tokens);

} // namespace mustache

#endif
