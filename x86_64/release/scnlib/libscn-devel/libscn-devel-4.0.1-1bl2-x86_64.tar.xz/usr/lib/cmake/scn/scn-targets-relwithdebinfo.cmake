#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "scn::scn" for configuration "RelWithDebInfo"
set_property(TARGET scn::scn APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(scn::scn PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libscn.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygscn-4.dll"
  )

list(APPEND _cmake_import_check_targets scn::scn )
list(APPEND _cmake_import_check_files_for_scn::scn "${_IMPORT_PREFIX}/lib/libscn.dll.a" "${_IMPORT_PREFIX}/bin/cygscn-4.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
