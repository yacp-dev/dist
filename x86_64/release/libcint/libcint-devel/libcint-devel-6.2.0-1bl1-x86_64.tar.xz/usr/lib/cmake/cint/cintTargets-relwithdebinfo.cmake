#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "cint::cint" for configuration "RelWithDebInfo"
set_property(TARGET cint::cint APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(cint::cint PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libcint.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygcint-6.dll"
  )

list(APPEND _cmake_import_check_targets cint::cint )
list(APPEND _cmake_import_check_files_for_cint::cint "${_IMPORT_PREFIX}/lib/libcint.dll.a" "${_IMPORT_PREFIX}/bin/cygcint-6.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
