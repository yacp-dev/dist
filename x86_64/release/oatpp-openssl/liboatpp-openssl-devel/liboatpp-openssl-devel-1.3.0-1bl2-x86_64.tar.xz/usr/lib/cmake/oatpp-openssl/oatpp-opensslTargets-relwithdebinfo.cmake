#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "oatpp::oatpp-openssl" for configuration "RelWithDebInfo"
set_property(TARGET oatpp::oatpp-openssl APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(oatpp::oatpp-openssl PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/liboatpp-openssl.dll.a"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELWITHDEBINFO "oatpp::oatpp;oatpp::oatpp-test"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygoatpp-openssl-1.dll"
  )

list(APPEND _cmake_import_check_targets oatpp::oatpp-openssl )
list(APPEND _cmake_import_check_files_for_oatpp::oatpp-openssl "${_IMPORT_PREFIX}/lib/liboatpp-openssl.dll.a" "${_IMPORT_PREFIX}/bin/cygoatpp-openssl-1.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
