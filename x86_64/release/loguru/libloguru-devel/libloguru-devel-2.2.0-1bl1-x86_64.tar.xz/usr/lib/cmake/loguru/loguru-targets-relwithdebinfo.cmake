#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "loguru::loguru" for configuration "RelWithDebInfo"
set_property(TARGET loguru::loguru APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(loguru::loguru PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libloguru.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygloguru-2.dll"
  )

list(APPEND _cmake_import_check_targets loguru::loguru )
list(APPEND _cmake_import_check_files_for_loguru::loguru "${_IMPORT_PREFIX}/lib/libloguru.dll.a" "${_IMPORT_PREFIX}/bin/cygloguru-2.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
