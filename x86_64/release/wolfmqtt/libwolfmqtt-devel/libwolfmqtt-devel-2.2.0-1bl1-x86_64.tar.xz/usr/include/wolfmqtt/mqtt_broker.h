/* mqtt_broker.h
 *
 * Copyright (C) 2006-2026 wolfSSL Inc.
 *
 * This file is part of wolfMQTT.
 *
 * wolfMQTT is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * wolfMQTT is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1335, USA
 */

#ifndef WOLFMQTT_BROKER_H
#define WOLFMQTT_BROKER_H

/* Windows uses the vs_settings.h file included via mqtt_types.h */
#if !defined(WOLFMQTT_USER_SETTINGS) && \
    !defined(_WIN32) && !defined(USE_WINDOWS_API)
    /* If options.h is missing use the "./configure" script. Otherwise, copy
     * the template "wolfmqtt/options.h.in" into "wolfmqtt/options.h" */
    #include <wolfmqtt/options.h>
#endif
#include "wolfmqtt/mqtt_types.h"
#include "wolfmqtt/mqtt_socket.h"
#include "wolfmqtt/mqtt_client.h"

#ifdef __cplusplus
    extern "C" {
#endif

#ifdef WOLFMQTT_BROKER

/* -------------------------------------------------------------------------- */
/* Socket type abstraction - override for non-POSIX platforms                  */
/* -------------------------------------------------------------------------- */
#ifndef BROKER_SOCKET_T
    #define BROKER_SOCKET_T        int
#endif
#ifndef BROKER_SOCKET_INVALID
    #define BROKER_SOCKET_INVALID  (-1)
#endif

/* -------------------------------------------------------------------------- */
/* Time abstraction - override for platforms without time.h                    */
/* -------------------------------------------------------------------------- */
#ifndef WOLFMQTT_BROKER_TIME_T
    #define WOLFMQTT_BROKER_TIME_T  unsigned long
#endif
/* Note: WOLFMQTT_BROKER_GET_TIME_S() default is defined in mqtt_broker.c
 * because it depends on <time.h> which is only included for POSIX builds.
 * Override this macro for custom platforms. */

/* -------------------------------------------------------------------------- */
/* Log levels                                                                  */
/* -------------------------------------------------------------------------- */
#define BROKER_LOG_ERROR  1
#define BROKER_LOG_INFO   2
#define BROKER_LOG_DEBUG  3

#ifndef BROKER_LOG_LEVEL_DEFAULT
    #define BROKER_LOG_LEVEL_DEFAULT  BROKER_LOG_INFO
#endif

/* -------------------------------------------------------------------------- */
/* Buffer and limit defaults                                                   */
/* -------------------------------------------------------------------------- */
#ifndef BROKER_RX_BUF_SZ
    #define BROKER_RX_BUF_SZ       4096
#endif
#ifndef BROKER_TX_BUF_SZ
    #define BROKER_TX_BUF_SZ       4096
#endif
#ifndef BROKER_TIMEOUT_MS
    #define BROKER_TIMEOUT_MS      1000
#endif
#ifndef BROKER_LISTEN_BACKLOG
    #define BROKER_LISTEN_BACKLOG  128
#endif

/* Static allocation limits */
#ifndef BROKER_MAX_CLIENTS
    #define BROKER_MAX_CLIENTS       8
#endif
#ifndef BROKER_MAX_SUBS
    #define BROKER_MAX_SUBS          32
#endif
/* Per-client subscription cap so one client cannot occupy the whole shared
 * subscription table and deny other clients. */
#ifndef BROKER_MAX_SUBS_PER_CLIENT
    /* Fair share of the shared table, but floored at 8 (and never above the
     * table size) so the default does not silently reject a client that
     * subscribes to a normal handful of topics. Override to tighten the
     * anti-DoS cap or to raise it for subscription-heavy clients. */
    #if (BROKER_MAX_SUBS / BROKER_MAX_CLIENTS) >= 8
        #define BROKER_MAX_SUBS_PER_CLIENT (BROKER_MAX_SUBS / BROKER_MAX_CLIENTS)
    #elif BROKER_MAX_SUBS < 8
        #define BROKER_MAX_SUBS_PER_CLIENT BROKER_MAX_SUBS
    #else
        #define BROKER_MAX_SUBS_PER_CLIENT 8
    #endif
#endif
#ifndef BROKER_MAX_CLIENT_ID_LEN
    #define BROKER_MAX_CLIENT_ID_LEN 64
#endif
#ifndef BROKER_MAX_USERNAME_LEN
    #define BROKER_MAX_USERNAME_LEN  64
#endif
#ifndef BROKER_MAX_PASSWORD_LEN
    #define BROKER_MAX_PASSWORD_LEN  64
#endif
#ifndef BROKER_MAX_FILTER_LEN
    #define BROKER_MAX_FILTER_LEN    128
#endif
#ifndef BROKER_MAX_RETAINED
    #define BROKER_MAX_RETAINED      16
#endif
#ifndef BROKER_MAX_TOPIC_LEN
    #define BROKER_MAX_TOPIC_LEN     128
#endif
#ifndef BROKER_MAX_PAYLOAD_LEN
    #define BROKER_MAX_PAYLOAD_LEN   4096
#endif
#ifndef BROKER_MAX_WILL_PAYLOAD_LEN
    #define BROKER_MAX_WILL_PAYLOAD_LEN 256
#endif
#ifndef BROKER_MAX_PENDING_WILLS
    #define BROKER_MAX_PENDING_WILLS 4
#endif
/* Upper bound (seconds) the broker accepts for a v5 Will Delay Interval.
 * Caps how long a deferred-will slot can be monopolized so a few clients
 * advertising near-UINT32_MAX delays cannot permanently exhaust the pool. */
#ifndef BROKER_MAX_WILL_DELAY_SEC
    #define BROKER_MAX_WILL_DELAY_SEC 3600
#endif
/* Seconds a freshly accepted client has to complete a CONNECT before the
 * broker evicts it, so half-open pre-CONNECT sockets cannot exhaust the client
 * table (Slowloris / slot exhaustion). */
#ifndef BROKER_CONNECT_TIMEOUT_SEC
    #define BROKER_CONNECT_TIMEOUT_SEC 10
#endif
/* Maximum concurrent inbound QoS 2 packet IDs awaiting PUBREL per client.
 * Used to dedup duplicate PUBLISHes per [MQTT-4.3.3] (Method B). 16 covers
 * any reasonable client; a misbehaving client that exceeds this gets a
 * malformed-packet rejection. */
#ifndef BROKER_MAX_INBOUND_QOS2
    #define BROKER_MAX_INBOUND_QOS2 16
#endif

/* Per-subscriber outbound delivery shaping.
 *
 * BROKER_MAX_INFLIGHT_PER_SUB bounds the number of outbound QoS 1/2 PUBLISHes
 * the broker may have in flight to a single subscriber at once. This gives
 * users a Mosquitto "max_inflight_messages" equivalent that works on both
 * v3.1.1 and v5; for v5 clients it is further clamped by the client's
 * Receive Maximum property (MQTT v5 sec 3.1.2.11.3).
 *
 * The default is derived from BROKER_TX_BUF_SZ so that the per-subscriber
 * outbound queue is "roughly the size that the tx buffer could plausibly
 * pipeline" without picking an arbitrary number. Override with
 *   -DBROKER_MAX_INFLIGHT_PER_SUB=N   to set a hard cap (1 = strict serial),
 *   -DBROKER_DEFAULT_AVG_MSG_SZ=N     to retune the derivation.
 *
 * Dynamic mode applies this to each client queue. Static mode applies it
 * while draining a persistent Session carrier. */
#ifndef BROKER_DEFAULT_AVG_MSG_SZ
    #define BROKER_DEFAULT_AVG_MSG_SZ 256
#endif
#ifndef BROKER_MIN_INFLIGHT_PER_SUB
    #define BROKER_MIN_INFLIGHT_PER_SUB 8
#endif
#ifndef BROKER_MAX_INFLIGHT_PER_SUB
    #define BROKER_MAX_INFLIGHT_PER_SUB \
        (((BROKER_TX_BUF_SZ / BROKER_DEFAULT_AVG_MSG_SZ) < \
            BROKER_MIN_INFLIGHT_PER_SUB) ? \
         BROKER_MIN_INFLIGHT_PER_SUB : \
         (BROKER_TX_BUF_SZ / BROKER_DEFAULT_AVG_MSG_SZ))
#endif

/* Static-memory persistent Session caps. */
#ifdef WOLFMQTT_STATIC_MEMORY
#ifndef BROKER_MAX_STATIC_ORPHAN_SESSIONS
    #define BROKER_MAX_STATIC_ORPHAN_SESSIONS BROKER_MAX_CLIENTS
#endif
#ifndef BROKER_MAX_STATIC_OFFLINE_MSGS_PER_SUB
    #define BROKER_MAX_STATIC_OFFLINE_MSGS_PER_SUB 8
#endif
#ifndef BROKER_MAX_STATIC_OFFLINE_DATA_LEN
    #if BROKER_TX_BUF_SZ > (BROKER_MAX_TOPIC_LEN + 272)
        #define BROKER_MAX_STATIC_OFFLINE_DATA_LEN 256
    #else
        #define BROKER_MAX_STATIC_OFFLINE_DATA_LEN \
            (BROKER_TX_BUF_SZ - BROKER_MAX_TOPIC_LEN - 16)
    #endif
#endif
#if BROKER_MAX_STATIC_ORPHAN_SESSIONS < 1
    #error BROKER_MAX_STATIC_ORPHAN_SESSIONS must be at least 1
#endif
#if BROKER_MAX_STATIC_OFFLINE_MSGS_PER_SUB < 1
    #error BROKER_MAX_STATIC_OFFLINE_MSGS_PER_SUB must be at least 1
#endif
#if BROKER_MAX_STATIC_OFFLINE_DATA_LEN < 1
    #error BROKER_MAX_STATIC_OFFLINE_DATA_LEN must be at least 1
#endif
#if (BROKER_MAX_STATIC_OFFLINE_DATA_LEN + BROKER_MAX_TOPIC_LEN + 16) > \
        BROKER_TX_BUF_SZ
    #error BROKER_MAX_STATIC_OFFLINE_DATA_LEN exceeds BROKER_TX_BUF_SZ
#endif
#endif /* WOLFMQTT_STATIC_MEMORY */
#ifndef BROKER_MAX_PERSIST_SESSIONS
    #define BROKER_MAX_PERSIST_SESSIONS 64
#endif
#ifndef BROKER_MAX_OFFLINE_MSGS_PER_SUB
    #define BROKER_MAX_OFFLINE_MSGS_PER_SUB 32
#endif
#if BROKER_MAX_OFFLINE_MSGS_PER_SUB >= 65535
    #error BROKER_MAX_OFFLINE_MSGS_PER_SUB must leave a free packet identifier
#endif

/* BROKER_MAX_QUEUED_MSGS_PER_SUB bounds the total depth of a *connected*
 * subscriber's outbound queue (out_q_count) in dynamic-memory mode.
 *
 * BROKER_MAX_INFLIGHT_PER_SUB (above) only bounds how many QoS>0 PUBLISHes
 * are on the wire awaiting an ack - i.e. bytes in flight. It does NOT bound
 * how many entries may sit QUEUED behind the inflight window. A subscriber
 * that stops sending PUBACK/PUBREC (a slow consumer, or an attacker keeping
 * the session alive with PINGREQ) saturates the inflight window and then
 * every subsequent matching PUBLISH still allocates a fresh BrokerOutPub plus
 * heap copies of the topic and payload onto out_q. Without a depth cap that
 * queue grows without limit until the broker exhausts memory.
 *
 * When a fan-out would exceed this depth the broker disconnects that
 * subscriber (v5: DISCONNECT reason 0x97 Quota Exceeded) rather than growing
 * the heap or silently dropping accepted QoS 1/2 messages; a persistent
 * session is then reclaimable on reconnect via the (separately capped)
 * offline queue. The default leaves room for a full inflight window plus an
 * offline-sized backlog of not-yet-sent entries. Override with
 *   -DBROKER_MAX_QUEUED_MSGS_PER_SUB=N
 * Only used in dynamic-memory mode. */
#ifndef BROKER_MAX_QUEUED_MSGS_PER_SUB
    #define BROKER_MAX_QUEUED_MSGS_PER_SUB \
        (BROKER_MAX_INFLIGHT_PER_SUB + BROKER_MAX_OFFLINE_MSGS_PER_SUB)
#endif
#if BROKER_MAX_QUEUED_MSGS_PER_SUB >= 65535
    #error BROKER_MAX_QUEUED_MSGS_PER_SUB must leave a free packet identifier
#endif

/* Schema version stamped on every persisted record. Bump when the
 * encoding of any namespace changes incompatibly; a startup with stored
 * records carrying a different version logs a warning, wipes all
 * persisted state, and starts clean (per plan: wipe-and-restart). */
#ifndef WOLFMQTT_BROKER_PERSIST_SCHEMA_VER
    /* Bumped from 1 -> 2 when the header layout split a dedicated
     * wrap_mode byte out of the schema-version field. Bumped 2 -> 3 when
     * the NS_SESSION record gained an orphan_since timestamp. Bumped 3 -> 4
     * when NS_OUTQ gained an explicit enqueue sequence, then 4 -> 5 when it
     * gained retransmission state. */
    #define WOLFMQTT_BROKER_PERSIST_SCHEMA_VER 5
#endif

/* Header wrap_mode byte values (record body framing on disk). */
#define WOLFMQTT_BROKER_PERSIST_WRAP_PLAIN    0
#define WOLFMQTT_BROKER_PERSIST_WRAP_AES_GCM  1

/* Magic bytes prefixing every persisted record so a stray file in the
 * backend directory cannot be misinterpreted as broker state. */
#define WOLFMQTT_BROKER_PERSIST_MAGIC0  'W'
#define WOLFMQTT_BROKER_PERSIST_MAGIC1  'M'
#define WOLFMQTT_BROKER_PERSIST_MAGIC2  'Q'
#define WOLFMQTT_BROKER_PERSIST_MAGIC3  'B'

/* Default storage directory for the POSIX backend. Application can pass
 * a different path at MqttBrokerNet_PersistPosix_Init time. */
#ifndef BROKER_PERSIST_DIR_DEFAULT
    #ifdef __MACH__
        #define BROKER_PERSIST_DIR_DEFAULT  "/private/var/lib/wolfmqtt"
    #else
        #define BROKER_PERSIST_DIR_DEFAULT  "/var/lib/wolfmqtt"
    #endif
#endif

/* Persistence namespaces. One per logical record type. The backend
 * is free to map each namespace to a separate directory, table,
 * keyspace, or sub-region; the broker just passes the namespace byte
 * verbatim. Values are stable across schema versions. */
#define BROKER_PERSIST_NS_META      1   /* schema version, broker meta */
#define BROKER_PERSIST_NS_SESSION   2   /* per-client_id session record */
#define BROKER_PERSIST_NS_SUBS      3   /* per-client_id subscription list */
#define BROKER_PERSIST_NS_RETAINED  4   /* per-topic retained message */
#define BROKER_PERSIST_NS_OUTQ      5   /* per-client_id outbound queue + inflight */

/* -------------------------------------------------------------------------- */
/* Feature toggles (opt-out: define WOLFMQTT_BROKER_NO_xxx to disable)        */
/* -------------------------------------------------------------------------- */
#ifndef WOLFMQTT_BROKER_NO_RETAINED
    #define WOLFMQTT_BROKER_RETAINED
#endif
#ifndef WOLFMQTT_BROKER_NO_WILL
    #define WOLFMQTT_BROKER_WILL
#endif
#ifndef WOLFMQTT_BROKER_NO_WILDCARDS
    #define WOLFMQTT_BROKER_WILDCARDS
#endif
#ifndef WOLFMQTT_BROKER_NO_AUTH
    #define WOLFMQTT_BROKER_AUTH
#endif
#ifndef WOLFMQTT_BROKER_NO_INSECURE
    #define WOLFMQTT_BROKER_INSECURE
#endif
#if defined(WOLFMQTT_BROKER_NO_INSECURE) && !defined(ENABLE_MQTT_TLS)
    #error "WOLFMQTT_BROKER_NO_INSECURE requires ENABLE_MQTT_TLS"
#endif

/* -------------------------------------------------------------------------- */
/* Forward declarations                                                        */
/* -------------------------------------------------------------------------- */
struct MqttBroker;

/* -------------------------------------------------------------------------- */
/* Broker network callback types                                               */
/* -------------------------------------------------------------------------- */
typedef int (*MqttBrokerNet_ListenCb)(void* ctx, BROKER_SOCKET_T* sock,
    word16 port, int backlog);
typedef int (*MqttBrokerNet_AcceptCb)(void* ctx, BROKER_SOCKET_T listen_sock,
    BROKER_SOCKET_T* client_sock);
typedef int (*MqttBrokerNet_ReadCb)(void* ctx, BROKER_SOCKET_T sock,
    byte* buf, int buf_len, int timeout_ms);
typedef int (*MqttBrokerNet_WriteCb)(void* ctx, BROKER_SOCKET_T sock,
    const byte* buf, int buf_len, int timeout_ms);
typedef int (*MqttBrokerNet_CloseCb)(void* ctx, BROKER_SOCKET_T sock);

typedef struct MqttBrokerNet {
    MqttBrokerNet_ListenCb  listen;
    MqttBrokerNet_AcceptCb  accept;
    MqttBrokerNet_ReadCb    read;
    MqttBrokerNet_WriteCb   write;
    MqttBrokerNet_CloseCb   close;
    void*                   ctx;
} MqttBrokerNet;

/* -------------------------------------------------------------------------- */
/* Persistent storage hooks                                                    */
/* -------------------------------------------------------------------------- */
#ifdef WOLFMQTT_BROKER_PERSIST
/* The persistence layer is intentionally hook-based so the broker can run
 * on top of POSIX files, embedded flash, an external KV store, or an
 * in-RAM stub used by tests. Each hook returns 0 on success or a negative
 * error code. Shadow-write failures are logged while in-memory state remains
 * authoritative. Iterator failures during restore abort MqttBroker_Start.
 *
 * The broker currently uses only the key/value API. At minimum kv_put,
 * kv_get, and kv_iter must be installed for sessions, subscriptions,
 * retained messages, and outbound queues to round-trip. kv_del is required
 * to remove persisted records. */

/* Iterator callback supplied by the broker to kv_iter. Return 0 to
 * continue, non-zero to stop iteration early. */
typedef int (*MqttBrokerPersist_IterCb)(const byte* key, word16 key_len,
    const byte* blob, word32 blob_len, void* cb_ctx);

/* Stream open mode. */
#define BROKER_PERSIST_STREAM_READ    1
#define BROKER_PERSIST_STREAM_WRITE   2
#define BROKER_PERSIST_STREAM_APPEND  3

typedef struct MqttBrokerPersistHooks {
    /* Key/value blob API. key bytes are opaque to the backend; len is
     * always <= 256 in current use (a client_id or topic). */
    int (*kv_put)(void* ctx, byte ns, const byte* key, word16 key_len,
                  const byte* blob, word32 blob_len);
    int (*kv_get)(void* ctx, byte ns, const byte* key, word16 key_len,
                  byte* out, word32* inout_len);
    int (*kv_del)(void* ctx, byte ns, const byte* key, word16 key_len);
    int (*kv_iter)(void* ctx, byte ns, MqttBrokerPersist_IterCb cb,
                   void* cb_ctx);

    /* Reserved for future use. Ignored when a complete KV family is present;
     * a stream-only hook structure is rejected. */
    int (*stream_open)(void* ctx, byte ns, const byte* key, word16 key_len,
                       int mode, void** handle);
    int (*stream_read)(void* ctx, void* handle, byte* buf, word32 len,
                       word32* out_len);
    int (*stream_write)(void* ctx, void* handle, const byte* buf,
                        word32 len);
    int (*stream_close)(void* ctx, void* handle);

    /* Force all pending writes to durable storage. Called after every
     * shadow-write commit per plan's "fsync after each commit" choice. */
    int (*sync)(void* ctx);

    /* Encryption-at-rest key derivation. Called once at broker init when
     * WOLFMQTT_BROKER_PERSIST_ENCRYPT is enabled. Must fill 32 bytes
     * (AES-256) into out_key. */
#ifdef WOLFMQTT_BROKER_PERSIST_ENCRYPT
    int (*derive_key)(void* ctx, byte* out_key, word32 key_len);
#endif

    /* Backend context pointer passed back into every callback. */
    void* ctx;
} MqttBrokerPersistHooks;
#endif /* WOLFMQTT_BROKER_PERSIST */

/* -------------------------------------------------------------------------- */
/* WebSocket per-client context                                                */
/* -------------------------------------------------------------------------- */
#ifdef ENABLE_MQTT_WEBSOCKET
#ifdef WOLFMQTT_STATIC_MEMORY
    #error "WebSocket support (ENABLE_MQTT_WEBSOCKET) is incompatible with " \
           "static memory mode (WOLFMQTT_STATIC_MEMORY). libwebsockets " \
           "requires dynamic allocation internally."
#endif
#ifndef BROKER_WS_RX_BUF_SZ
    #define BROKER_WS_RX_BUF_SZ  BROKER_RX_BUF_SZ
#endif
typedef struct BrokerWsCtx {
    void  *wsi;                 /* struct lws* (opaque to avoid lws header) */
    byte   rx_buffer[BROKER_WS_RX_BUF_SZ];
    size_t rx_len;
    byte  *tx_pending;          /* allocated with LWS_PRE prefix room */
    size_t tx_len;
    int    status;              /* 1=established, 0=closed, -1=error */
    int    pending_close;       /* 1 when broker-initiated close is in progress */
    int    processing;          /* 1 while BrokerClient_Process is dispatching a packet */
    int    pending_remove;      /* 1 when peer closed during processing; deferred free */
} BrokerWsCtx;
#endif /* ENABLE_MQTT_WEBSOCKET */

/* -------------------------------------------------------------------------- */
/* Inbound QoS 2 dedup state                                                   */
/* -------------------------------------------------------------------------- */
/* Per-client set of QoS 2 packet IDs that have been received and PUBREC'd
 * but not yet PUBREL'd. Used to skip the fan-out for duplicate PUBLISHes
 * per [MQTT-4.3.3] / Method B. Gated by WOLFMQTT_MAX_QOS so capped-QoS
 * broker builds drop the dedup state and PUBREC/PUBREL/PUBCOMP handlers. */
#if WOLFMQTT_MAX_QOS >= 2
#ifndef WOLFMQTT_STATIC_MEMORY
typedef struct BrokerInboundQos2 {
    word16  packet_id;
    struct BrokerInboundQos2* next;
} BrokerInboundQos2;
#endif
#endif /* WOLFMQTT_MAX_QOS >= 2 */

/* -------------------------------------------------------------------------- */
/* Per-subscriber outbound publish queue.
 *
 * Each entry owns the topic and payload bytes via heap copy so the queue is
 * independent of the publisher's rx_buf lifetime. The state field tracks
 * the QoS handshake position for that one delivery to that one subscriber:
 *
 *   BROKER_OUTQ_QUEUED        Not yet sent on the wire.
 *   BROKER_OUTQ_PUBLISH_SENT  QoS 1: awaiting PUBACK. QoS 2: awaiting PUBREC.
 *   BROKER_OUTQ_PUBREL_SENT   QoS 2 only: PUBREC received, PUBREL sent,
 *                             awaiting PUBCOMP.
 *
 * Dynamic-memory QoS 0 entries are deleted as soon as the PUBLISH is written;
 * they never leave the QUEUED state or increment the inflight counter. */
enum BrokerOutPubState {
    BROKER_OUTQ_QUEUED       = 0,
    BROKER_OUTQ_PUBLISH_SENT = 1,
    BROKER_OUTQ_PUBREL_SENT  = 2
};

#ifdef WOLFMQTT_STATIC_MEMORY
typedef struct BrokerStaticOutPub {
    char    topic[BROKER_MAX_TOPIC_LEN];
    byte    data[BROKER_MAX_STATIC_OFFLINE_DATA_LEN];
    word32  payload_len;
#ifdef WOLFMQTT_V5
    word32  prop_len;
#endif
    MqttQoS qos;
    word16  packet_id;
    byte    retain;
    byte    duplicate;
    byte    state;
    byte    was_sent;
    byte    has_expiry;
    WOLFMQTT_BROKER_TIME_T enq_time;
    word32  expiry_sec;
} BrokerStaticOutPub;

typedef struct BrokerStaticOrphanSession {
    byte    in_use;
    byte    protocol_level;
    char    client_id[BROKER_MAX_CLIENT_ID_LEN];
    word32  session_expiry_sec;
    WOLFMQTT_BROKER_TIME_T orphan_since;
#if WOLFMQTT_MAX_QOS >= 2
    word16  qos2_pending[BROKER_MAX_INBOUND_QOS2];
#endif
    int     out_q_count;
    int     out_q_inflight;
    BrokerStaticOutPub out_q[BROKER_MAX_STATIC_OFFLINE_MSGS_PER_SUB];
} BrokerStaticOrphanSession;
#else
typedef struct BrokerOutPub {
    char*   topic;          /* heap-owned, NUL-terminated */
    byte*   payload;        /* heap-owned, may be NULL when payload_len == 0 */
    word32  payload_len;
    MqttQoS qos;
    word16  packet_id;      /* 0 for QoS 0 */
    byte    retain;
    byte    state;          /* BROKER_OUTQ_* */
    /* On session resumption, BrokerOrphan_Reclaim resets any entry
     * that was previously PUBLISH_SENT back to QUEUED and sets
     * retransmit_dup=1. The drain encodes the PUBLISH with
     * MqttPublish.duplicate=1 on first re-send, as required by
     * MQTT-4.4.0-1, then clears the flag. */
    byte    retransmit_dup; /* 0 or 1 */
    byte    partial_send;   /* QoS 0 PUBLISH started on the old socket */
    WOLFMQTT_BROKER_TIME_T enq_time;
    word64  enqueue_seq;    /* persistent FIFO order within this session */
    word32  expiry_sec;     /* v5 Message Expiry Interval, 0 = no expiry */
    byte    protocol_level; /* echoed back to subscriber on send */
#ifdef WOLFMQTT_V5
    /* Deep copy (BrokerProps_Clone) of the originating PUBLISH's v5
     * Application Message properties (Payload Format Indicator, Content
     * Type, Response Topic, Correlation Data, User Property, etc.), or
     * NULL if none. Owned by this entry; freed once by BrokerOutPub_Free
     * via BrokerProps_FreeClone - never via MqttProps_Free().
     * Not serialized by the persist layer: a queued message replayed after a
     * broker restart is delivered without these properties. */
    MqttProp* props;
#endif
    struct BrokerOutPub* next;
} BrokerOutPub;

/* -------------------------------------------------------------------------- */
/* Orphan session (dynamic memory only).                                       */
/*                                                                            */
/* Holds the persistent-session state of a disconnected client (Clean         */
/* Start=0): its outbound message queue, in-flight QoS 1/2 receipts, and      */
/* enough identity to be reclaimed on reconnect. Smaller than a full          */
/* BrokerClient because no socket / tx_buf / rx_buf / TLS state is needed     */
/* while disconnected. Subs that belonged to the original BrokerClient        */
/* keep sub->client=NULL while orphaned; reconnect rebinds them.              */
/* -------------------------------------------------------------------------- */
typedef struct BrokerOrphanSession {
    char*       client_id;       /* heap-owned, NUL-terminated */
    byte        protocol_level;
    word32      session_expiry_sec;  /* v5 Session Expiry; 0xFFFFFFFF=never */
    WOLFMQTT_BROKER_TIME_T orphan_since;
    BrokerOutPub* out_q_head;
    BrokerOutPub* out_q_tail;
    int           out_q_count;
    int           out_q_inflight;
#if WOLFMQTT_MAX_QOS >= 2
    /* Inbound QoS 2 dedup state (see BrokerClient.qos2_pending), moved
     * here on disconnect so a retransmitted PUBLISH after reconnect is
     * still recognized as a duplicate instead of being re-fanned-out.
     * Ownership transfers by pointer reassignment, mirroring out_q_head
     * above - see BrokerOrphan_Take / BrokerOrphan_Reclaim. */
    BrokerInboundQos2* qos2_pending;
    int                qos2_pending_count;
#endif
    struct BrokerOrphanSession* next;
} BrokerOrphanSession;
#endif

/* -------------------------------------------------------------------------- */
/* Broker client tracking                                                      */
/* -------------------------------------------------------------------------- */
/* One outbound QoS > 0 delivery this client has not acknowledged yet. */
typedef struct BrokerStaticOutId {
    word16  packet_id;      /* 0 = empty slot */
    byte    qos;            /* MqttQoS the delivery went out with */
} BrokerStaticOutId;

typedef struct BrokerClient {
#ifdef WOLFMQTT_STATIC_MEMORY
    byte    in_use;
    char    client_id[BROKER_MAX_CLIENT_ID_LEN];
#ifdef WOLFMQTT_BROKER_AUTH
    char    username[BROKER_MAX_USERNAME_LEN];
    char    password[BROKER_MAX_PASSWORD_LEN];
#endif
    byte    tx_buf[BROKER_TX_BUF_SZ];
    byte    rx_buf[BROKER_RX_BUF_SZ];
#ifdef WOLFMQTT_BROKER_WILL
    char    will_topic[BROKER_MAX_TOPIC_LEN];
    byte    will_payload[BROKER_MAX_WILL_PAYLOAD_LEN];
#endif
#else
    char*   client_id;
#ifdef WOLFMQTT_BROKER_AUTH
    char*   username;
    char*   password;
#endif
    byte*   tx_buf;
    byte*   rx_buf;
    int     tx_buf_len;
    int     rx_buf_len;
#ifdef WOLFMQTT_BROKER_WILL
    char*   will_topic;
    byte*   will_payload;
#endif
    struct BrokerClient* next;
#endif
    BROKER_SOCKET_T sock;
    byte    protocol_level;
    word16  keep_alive_sec;
    WOLFMQTT_BROKER_TIME_T last_rx;
    byte    clean_session;
    byte    connected;       /* set after successful CONNECT handshake */
    int     sub_count;       /* active subscriptions owned by this client */
#ifdef WOLFMQTT_BROKER_WILL
    byte    has_will;
    word16  will_payload_len;
    MqttQoS will_qos;
    byte    will_retain;
    word32  will_delay_sec;     /* v5 Will Delay Interval (seconds) */
#endif
    MqttNet net;
    MqttClient client;
    struct MqttBroker* broker;  /* back-pointer to parent broker context */
#ifdef ENABLE_MQTT_TLS
    byte    tls_handshake_done;
#endif
#ifdef ENABLE_MQTT_WEBSOCKET
    void   *ws_ctx;             /* BrokerWsCtx* (NULL for TCP clients) */
#endif
#ifdef WOLFMQTT_BROKER_AUTH
    /* Actual stored length of password bytes. Tracked separately because
     * [MQTT-3.1.3.5] defines Password as Binary Data, which may legally
     * contain 0x00 - XSTRLEN would truncate at the first embedded NUL. */
    word16  password_len;
#endif
    /* [MQTT-4.3.3] Inbound QoS 2 packet IDs that have been PUBREC'd but
     * not yet PUBREL'd. A duplicate PUBLISH carrying one of these IDs is
     * acked again (PUBREC) but NOT re-fanned-out to subscribers. The
     * BROKER_MAX_INBOUND_QOS2 cap is enforced in both memory modes; a
     * client that exceeds it is disconnected with malformed-packet error.
     * Compiled out for capped-QoS builds (WOLFMQTT_MAX_QOS < 2). */
#if WOLFMQTT_MAX_QOS >= 2
#ifdef WOLFMQTT_STATIC_MEMORY
    word16  qos2_pending[BROKER_MAX_INBOUND_QOS2]; /* 0 = empty slot */
#else
    BrokerInboundQos2* qos2_pending;
    int                qos2_pending_count;
#endif
#endif /* WOLFMQTT_MAX_QOS >= 2 */
#ifdef WOLFMQTT_STATIC_MEMORY
    /* Outbound QoS 1/2 Packet Identifiers sent to this client and not yet
     * released by its PUBACK or PUBCOMP. [MQTT-2.3.1-4] applies the Client
     * identifier rule to a Server sending a QoS > 0 PUBLISH, so a new one
     * must not reuse an identifier still awaiting acknowledgement. The QoS is
     * kept with it so a mismatched acknowledgement (a PUBACK for a QoS 2
     * delivery, say) cannot free a slot whose PUBREC/PUBCOMP flow is still
     * running. packet_id 0 marks an empty slot. Dynamic-memory builds derive
     * this from the per-subscriber out_q instead, via
     * BrokerNextPacketIdForQueue. */
    BrokerStaticOutId out_inflight[BROKER_MAX_INFLIGHT_PER_SUB];
#endif
#ifndef WOLFMQTT_STATIC_MEMORY
    /* Per-subscriber outbound publish queue. FIFO from head to tail;
     * drain pulls from head. out_q_inflight is the number of entries in
     * state PUBLISH_SENT or PUBREL_SENT (QoS 1/2 awaiting an ack);
     * BROKER_MAX_INFLIGHT_PER_SUB and client_receive_max together bound
     * how many of those may exist at once. out_q_count is total entries
     * including not-yet-sent QUEUED ones. Used for fan-out at every
     * QoS level (QoS 0 forwards transit the queue too). */
    BrokerOutPub* out_q_head;
    BrokerOutPub* out_q_tail;
    int           out_q_count;
    int           out_q_inflight;
    /* Encoded length of an out_q packet whose nonblocking/TLS-async write is
     * still in progress. While nonzero, tx_buf remains owned by that write. */
    int           out_q_pending_len;
    /* Encoded length of a direct broker response still being written. */
    int           direct_pending_len;
    /* v5 Receive Maximum advertised by this client in CONNECT, or 65535
     * (per MQTT v5 sec 3.1.2.11.3) when the client did not include the
     * property. For v3.1.1 clients this is left at 65535 - the cap
     * comes from BROKER_MAX_INFLIGHT_PER_SUB alone. */
    word16        client_receive_max;
#endif /* !WOLFMQTT_STATIC_MEMORY */
    word32        session_expiry_sec;
#ifdef WOLFMQTT_STATIC_MEMORY
    word16        static_client_receive_max;
#endif
    byte          session_established;
#ifndef WOLFMQTT_STATIC_MEMORY
    /* Length of a CONNACK still being written (0 = none). While nonzero,
     * tx_buf is owned by that write and no other packet may be read from or
     * written to this client. */
    int           connack_pending_len;
    /* The pending CONNACK carries a non-zero return code. MQTT 3.1.1 section
     * 3.1.4 requires the Server to send the refusal and then close the
     * Network Connection, so the client is kept only until those bytes are
     * fully delivered and is then dropped without becoming connected. */
    unsigned int  connack_refused : 1;
#endif
} BrokerClient;

/* -------------------------------------------------------------------------- */
/* Broker subscription tracking                                                */
/* -------------------------------------------------------------------------- */
typedef struct BrokerSub {
#ifdef WOLFMQTT_STATIC_MEMORY
    byte    in_use;
    char    filter[BROKER_MAX_FILTER_LEN];
    char    client_id[BROKER_MAX_CLIENT_ID_LEN]; /* For session persistence */
#else
    char*   filter;
    char*   client_id; /* For session persistence */
    struct BrokerSub* next;
#endif
    struct BrokerClient* client; /* NULL if client disconnected (session persisted) */
    MqttQoS qos;
} BrokerSub;

/* -------------------------------------------------------------------------- */
/* Retained message store                                                      */
/* -------------------------------------------------------------------------- */
#ifdef WOLFMQTT_BROKER_RETAINED
typedef struct BrokerRetainedMsg {
#ifdef WOLFMQTT_STATIC_MEMORY
    byte    in_use;
    char    topic[BROKER_MAX_TOPIC_LEN];
    byte    payload[BROKER_MAX_PAYLOAD_LEN];
#else
    char*   topic;
    byte*   payload;
    struct BrokerRetainedMsg* next;
#endif
    word32  payload_len;
    WOLFMQTT_BROKER_TIME_T store_time;  /* when stored (seconds) */
    word32  expiry_sec;                 /* v5 message expiry (0=none) */
    MqttQoS qos;                        /* [MQTT-3.3.1-5] stored QoS */
    byte    pending_delete;             /* deferred free during delivery */
} BrokerRetainedMsg;
#endif /* WOLFMQTT_BROKER_RETAINED */

/* -------------------------------------------------------------------------- */
/* Pending will messages (v5 Will Delay Interval)                              */
/* -------------------------------------------------------------------------- */
#ifdef WOLFMQTT_BROKER_WILL
typedef struct BrokerPendingWill {
#ifdef WOLFMQTT_STATIC_MEMORY
    byte    in_use;
    char    client_id[BROKER_MAX_CLIENT_ID_LEN];
    char    topic[BROKER_MAX_TOPIC_LEN];
    byte    payload[BROKER_MAX_WILL_PAYLOAD_LEN];
#else
    char*   client_id;
    char*   topic;
    byte*   payload;
    struct BrokerPendingWill* next;
#endif
    word16  payload_len;
    MqttQoS qos;
    byte    retain;
    WOLFMQTT_BROKER_TIME_T publish_time; /* absolute time to publish */
} BrokerPendingWill;
#endif /* WOLFMQTT_BROKER_WILL */

/* -------------------------------------------------------------------------- */
/* Broker context                                                              */
/* -------------------------------------------------------------------------- */
typedef struct MqttBroker {
    BROKER_SOCKET_T listen_sock;
    word16  port;
    int     running;
    byte    log_level;
#ifdef WOLFMQTT_BROKER_AUTH
    /* Broker authentication credentials. auth_user and auth_pass MUST be set
     * together: configuring only one is rejected by MqttBroker_Start, since a
     * partial config would check only the configured half and accept any value
     * for the other (single-factor downgrade). Leave both NULL to disable
     * authentication. */
    const char* auth_user;
    const char* auth_pass;
#endif
    MqttBrokerNet net;
    word16  next_packet_id;
    word32  next_auto_id; /* monotonically increasing counter for
                           * server-assigned ClientIds (empty-ID accepts) */
#ifdef ENABLE_MQTT_TLS
    BROKER_SOCKET_T listen_sock_tls; /* TLS listener socket */
    word16       port_tls;           /* TLS port (default 8883) */
    WOLFSSL_CTX* tls_ctx;
    const char*  tls_cert;     /* Server certificate file path */
    const char*  tls_key;      /* Server private key file path */
    const char*  tls_ca;       /* CA cert for mutual auth (optional) */
    byte         use_tls;
    byte         tls_version;  /* 0=auto (v23), 12=TLS 1.2, 13=TLS 1.3 */
    byte         tls_ctx_owned; /* 1 if BrokerTls_Init created tls_ctx */
#endif
#ifdef WOLFMQTT_STATIC_MEMORY
    BrokerClient clients[BROKER_MAX_CLIENTS];
    BrokerSub    subs[BROKER_MAX_SUBS];
#ifdef WOLFMQTT_BROKER_RETAINED
    BrokerRetainedMsg retained[BROKER_MAX_RETAINED];
#endif
#ifdef WOLFMQTT_BROKER_WILL
    BrokerPendingWill pending_wills[BROKER_MAX_PENDING_WILLS];
#endif
#else
    BrokerClient* clients;
    BrokerSub*    subs;
    /* Bumped on every structural change to `subs`. */
    word32        subs_gen;
    /* Bumped whenever a BrokerClient is linked into or unlinked from
     * `clients`. A fan-out snapshots it before the writes and only re-validates
     * its collected destinations when it changed, so the common (nothing
     * removed) case avoids an O(n) rescan per destination. */
    word32        clients_gen;
#ifdef WOLFMQTT_BROKER_RETAINED
    BrokerRetainedMsg* retained;
    int                retained_count;
    int                retained_delivering; /* re-entrancy guard for delete */
#endif
#ifdef WOLFMQTT_BROKER_WILL
    BrokerPendingWill* pending_wills;
#endif
#endif
#ifdef ENABLE_MQTT_WEBSOCKET
    void   *ws_ctx;             /* struct lws_context* (opaque) */
    word16  ws_port;
    byte    use_websocket;
    const char *ws_tls_cert;
    const char *ws_tls_key;
    const char *ws_tls_ca;
    /* Optional exact Origin allowlist for browser WebSocket connections. When
     * non-NULL, a request whose HTTP Origin header is present and does not
     * match is rejected (CSWSH defense). NULL = no Origin enforcement. */
    const char *ws_allowed_origin;
#endif
#ifdef WOLFMQTT_BROKER_PERSIST
    /* Pointer (not embedded struct) so the broker stays small when no
     * application installs hooks. NULL means "in-memory only", which is
     * the same behavior as a build without WOLFMQTT_BROKER_PERSIST. */
    const MqttBrokerPersistHooks* persist;
    #ifdef WOLFMQTT_BROKER_PERSIST_ENCRYPT
    /* AES-256 key cache for at-rest encryption. Populated by the first
     * encrypt/decrypt call via derive_key(); zeroed (ForceZero) on
     * MqttBroker_Free. Per-broker so multiple broker instances in one
     * process don't share key material. */
    byte persist_key_cache[32];
    byte persist_key_loaded; /* 0 or 1 */
    #endif
#endif
#ifndef WOLFMQTT_STATIC_MEMORY
    /* Linked list of disconnected persistent sessions. Each entry holds
     * its own outbound queue + identity so messages published while the
     * owning client is offline are retained until reconnect (or
     * BROKER_MAX_PERSIST_SESSIONS forces drop-oldest eviction). Subs
     * pointing at orphaned sessions keep sub->client=NULL; fan-out
     * branches on that to look up the orphan by client_id. */
    BrokerOrphanSession* orphan_sessions;
    int                  orphan_session_count;
#endif
    /* Rate-limits the orphan expiry sweep in MqttBroker_Step. */
    WOLFMQTT_BROKER_TIME_T orphan_last_expire_check;
#ifdef WOLFMQTT_STATIC_MEMORY
    BrokerStaticOrphanSession static_orphans[BROKER_MAX_STATIC_ORPHAN_SESSIONS];
#endif
#ifdef WOLFMQTT_BROKER_PERSIST
    byte persist_restored;
#endif
} MqttBroker;

/* -------------------------------------------------------------------------- */
/* Public API                                                                  */
/* -------------------------------------------------------------------------- */

/* Initialize the broker context with network callbacks */
WOLFMQTT_API int MqttBroker_Init(MqttBroker* broker, MqttBrokerNet* net);

/* Run the broker main loop (blocking) */
WOLFMQTT_API int MqttBroker_Run(MqttBroker* broker);

/* Execute a single iteration of the broker loop (for embedded main loops) */
WOLFMQTT_API int MqttBroker_Step(MqttBroker* broker);

/* Signal the broker loop to stop */
WOLFMQTT_API int MqttBroker_Stop(MqttBroker* broker);

/* Clean up broker resources */
WOLFMQTT_API int MqttBroker_Free(MqttBroker* broker);

/* Start the broker (listen + TLS init). Call once before MqttBroker_Step().
 * For embedded systems that use a cooperative main loop with Step(). */
WOLFMQTT_API int MqttBroker_Start(MqttBroker* broker);

#ifdef WOLFMQTT_BROKER_AUTH
/* Internal: copy a CLI -P password into broker-owned storage, clearing any
 * prior residue and wiping the source argv slot. Returns
 * MQTT_CODE_ERROR_BAD_ARG if the password does not fit. WOLFMQTT_LOCAL keeps
 * it out of the public ABI; exposed for unit tests. */
WOLFMQTT_LOCAL int wolfmqtt_broker_set_auth_pass(MqttBroker* broker,
    char* pass_arg, char* auth_pass_buf, word32 auth_pass_buf_sz);
#endif

/* wolfIP backend initializer.
 * wolfIP_stack is a (struct wolfIP*) pointer to the wolfIP stack instance. */
#ifdef WOLFMQTT_WOLFIP
WOLFMQTT_API int MqttBrokerNet_wolfIP_Init(MqttBrokerNet* net,
    void* wolfIP_stack);
#endif

/* Default POSIX backend initializer.
 * Only available when WOLFMQTT_BROKER_CUSTOM_NET is NOT defined. */
#if !defined(WOLFMQTT_WOLFIP) && !defined(WOLFMQTT_BROKER_CUSTOM_NET)
WOLFMQTT_API int MqttBrokerNet_Init(MqttBrokerNet* net);
#endif

#ifdef WOLFMQTT_BROKER_PERSIST
/* Install non-NULL persistence hooks after MqttBroker_Init and before the
 * first MqttBroker_Start, or after MqttBroker_Free. Passing NULL may detach
 * the current hooks at any time. The MqttBrokerPersistHooks struct must
 * outlive the broker while installed. Stream-only hooks are unsupported;
 * deprecated stream members are ignored when all four KV callbacks are
 * provided. */
WOLFMQTT_API int MqttBroker_SetPersistHooks(MqttBroker* broker,
    const MqttBrokerPersistHooks* hooks);

/* Initialize the default POSIX file-based persistence backend. Stores
 * each record as a file under dir (defaults to BROKER_PERSIST_DIR_DEFAULT
 * when dir is NULL). fsync's every commit. Caller is responsible for
 * keeping the hooks struct alive while the broker runs. */
WOLFMQTT_API int MqttBrokerNet_PersistPosix_Init(
    MqttBrokerPersistHooks* hooks, const char* dir);

/* Tear down the POSIX backend - releases the directory descriptor and
 * any per-handle state. Does not delete persisted files. */
WOLFMQTT_API void MqttBrokerNet_PersistPosix_Free(
    MqttBrokerPersistHooks* hooks);

/* -------------------------------------------------------------------------- */
/* Internal shadow-write helpers (linked from mqtt_broker.c into the
 * mqtt_broker binary). All are no-ops when broker->persist is NULL so
 * call sites do not need to guard. WOLFMQTT_LOCAL keeps them out of
 * the public shared-library ABI. The encoders use a heap-allocated
 * scratch buffer sized to the record - too large to live on the
 * select-loop stack and bursty enough that a per-call alloc is the
 * least surprising approach. Backends can themselves choose how to
 * persist or fsync. Forward-compat is via WOLFMQTT_BROKER_PERSIST_SCHEMA_VER. */
struct BrokerClient;
struct BrokerSub;
struct BrokerRetainedMsg;
struct BrokerOutPub;

WOLFMQTT_LOCAL int BrokerPersist_PutSession(MqttBroker* broker,
    const struct BrokerClient* bc);
WOLFMQTT_LOCAL int BrokerPersist_PutOrphanSession(MqttBroker* broker,
    const char* client_id, byte protocol_level, word32 session_expiry_sec,
    WOLFMQTT_BROKER_TIME_T orphan_since);
WOLFMQTT_LOCAL int BrokerPersist_DelSession(MqttBroker* broker,
    const char* client_id);

WOLFMQTT_LOCAL int BrokerPersist_PutSubs(MqttBroker* broker,
    const char* client_id);
WOLFMQTT_LOCAL int BrokerPersist_DelSubs(MqttBroker* broker,
    const char* client_id);

#ifdef WOLFMQTT_BROKER_RETAINED
WOLFMQTT_LOCAL int BrokerPersist_PutRetained(MqttBroker* broker,
    const struct BrokerRetainedMsg* rm);
WOLFMQTT_LOCAL int BrokerPersist_DelRetained(MqttBroker* broker,
    const char* topic);
#endif

WOLFMQTT_LOCAL int BrokerPersist_PutOutPub(MqttBroker* broker,
    const char* client_id, const struct BrokerOutPub* e);
WOLFMQTT_LOCAL int BrokerPersist_DelOutPub(MqttBroker* broker,
    const char* client_id, word16 packet_id);
WOLFMQTT_LOCAL int BrokerPersist_DelOutQueue(MqttBroker* broker,
    const char* client_id);
/* Startup-time restore on a freshly initialized, empty broker. Rebuilds the
 * in-memory tables before the first MqttBroker_Start accepts clients. Wipes
 * and re-stamps META when the persisted schema version does not match. */
WOLFMQTT_LOCAL int BrokerPersist_Restore(MqttBroker* broker);
/* Discard state loaded by a failed startup restore. Defined in
 * mqtt_broker.c because it uses the broker's shared teardown helpers. */
WOLFMQTT_LOCAL void BrokerPersist_RestoreRollback(MqttBroker* broker);
#endif /* WOLFMQTT_BROKER_PERSIST */

#ifdef WOLFMQTT_STATIC_MEMORY
WOLFMQTT_LOCAL void BrokerStaticOrphan_DropFull(MqttBroker* broker,
    BrokerStaticOrphanSession* orphan);
#else
/* Full orphan teardown: delete persisted records (no-op without
 * WOLFMQTT_BROKER_PERSIST), drop any orphan-bound subs
 * (sub->client == NULL with matching client_id) from broker->subs,
 * unlink and free the orphan slot. Used by both eviction (cap reached)
 * and restore-time expiry sweep so the two paths can't drift. */
WOLFMQTT_LOCAL void BrokerOrphan_DropFull(MqttBroker* broker,
    BrokerOrphanSession* o);
#endif

/* CLI wrapper interface */
WOLFMQTT_API int wolfmqtt_broker(int argc, char** argv);

/* -------------------------------------------------------------------------- */
/* Local declarations */
/* -------------------------------------------------------------------------- */
WOLFMQTT_LOCAL int BrokerSend_SubAck(BrokerClient* bc, word16 packet_id,
    const byte* return_codes, int return_code_count);


#endif /* WOLFMQTT_BROKER */

#ifdef __cplusplus
    } /* extern "C" */
#endif

#endif /* WOLFMQTT_BROKER_H */
