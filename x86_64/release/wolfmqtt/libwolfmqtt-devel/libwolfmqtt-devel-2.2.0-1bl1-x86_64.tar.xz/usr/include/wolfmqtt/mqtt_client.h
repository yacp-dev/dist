/* mqtt_client.h
 *
 * Copyright (C) 2006-2026 wolfSSL Inc.
 *
 * This file is part of wolfMQTT.
 *
 * wolfMQTT is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * wolfMQTT is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1335, USA
 */

/* Implementation by: David Garske
 * Based on specification for MQTT v3.1.1
 * See http://mqtt.org/documentation for additional MQTT documentation.
 */

#ifndef WOLFMQTT_CLIENT_H
#define WOLFMQTT_CLIENT_H

#ifdef __cplusplus
    extern "C" {
#endif

/* Windows uses the vs_settings.h file included vis mqtt_types.h */
#if !defined(WOLFMQTT_USER_SETTINGS) && \
    !defined(_WIN32) && !defined(USE_WINDOWS_API)
    /* If options.h is missing use the "./configure" script. Otherwise, copy
     * the template "wolfmqtt/options.h.in" into "wolfmqtt/options.h" */
    #include <wolfmqtt/options.h>
#endif
#include "wolfmqtt/mqtt_types.h"
#include "wolfmqtt/mqtt_packet.h"
#include "wolfmqtt/mqtt_socket.h"

#ifdef WOLFMQTT_SN
#include "wolfmqtt/mqtt_sn_packet.h"
#endif

/* Automatic keep-alive scheduling. When a non-zero keep-alive is negotiated in
 * CONNECT, the core client sends a PINGREQ once the outbound link has been idle
 * for about three quarters of that interval, so the application does not have
 * to schedule pings itself and the ping reaches the broker before the deadline.
 * This mirrors the broker keep-alive handling.
 *
 * The scheduler is evaluated at the start of each MqttClient_WaitMessage call,
 * not during the blocking read, so the application must call it with a
 * timeout_ms (poll cadence) shorter than the keep-alive interval. A single
 * wait longer than the interval can let the broker deadline pass unchecked.
 *
 * When a ping is due, MqttClient_WaitMessage performs the PINGREQ/PINGRESP
 * round-trip inline using cmd_timeout_ms, so the call may take up to
 * cmd_timeout_ms longer to return; if other packets keep arriving the round
 * trip can extend past a single cmd_timeout_ms before the PINGRESP is seen. A
 * packet that arrives while waiting for the PINGRESP is delivered through the
 * message callback, not the MqttObject passed to MqttClient_WaitMessage_ex.
 *
 * In a blocking build a ping left unanswered returns MQTT_CODE_ERROR_NETWORK
 * rather than MQTT_CODE_ERROR_TIMEOUT, so a caller can tell a dead link from an
 * idle one. Under WOLFMQTT_NONBLOCK the library cannot time the ping out, so
 * the application stays responsible for its own liveness deadline.
 *
 * The keep-alive bookkeeping fields (last_tx_time, keep_alive_sec) are updated
 * without a lock under WOLFMQTT_MULTITHREAD; a mis-scheduled or skipped ping
 * self-corrects on the next MqttClient_WaitMessage.
 *
 * WOLFMQTT_GET_TIME_S() returns a clock in seconds; only elapsed differences
 * are used, so a monotonic source is fine. The default is time(NULL), except
 * on Zephyr where its minimal libc has no linkable time() and the kernel
 * uptime is used instead. Override it in user_settings.h on targets without a
 * suitable clock, or define WOLFMQTT_NO_TIME to compile out automatic
 * scheduling entirely; the explicit MqttClient_Ping / MqttClient_Ping_ex APIs
 * still work in that case.
 *
 * To keep the feature compiled in but turn it off for a specific client at
 * runtime - for example an application that already schedules its own PINGREQ
 * and must not double-ping - set MQTT_CLIENT_FLAG_NO_AUTO_KEEPALIVE with
 * MqttClient_Flags before connecting; the keep-alive negotiated with the broker
 * in CONNECT is unaffected. */
#ifndef WOLFMQTT_NO_TIME
    #ifndef WOLFMQTT_GET_TIME_S
        #ifdef __ZEPHYR__
            #include <zephyr/kernel.h>
            #define WOLFMQTT_GET_TIME_S() ((word32)(k_uptime_get() / 1000))
        #else
            #include <time.h>
            #define WOLFMQTT_GET_TIME_S() ((word32)time(NULL))
        #endif
    #endif
#endif


/* This macro allows the disconnect callback to be triggered when
 * MqttClient_Disconnect_ex is called. Normally the CB is only used to handle
 * errors from MqttPacket_HandleNetError.
 */
#ifndef WOLFMQTT_USE_CB_ON_DISCONNECT
    #undef WOLFMQTT_USE_CB_ON_DISCONNECT
    /* #define WOLFMQTT_USE_CB_ON_DISCONNECT */
#endif

#if defined(WOLFMQTT_PROPERTY_CB) && !defined(WOLFMQTT_V5)
    #error "WOLFMQTT_V5 must be defined to use WOLFMQTT_PROPERTY_CB"
#endif

struct _MqttClient;

/*! \brief      Mqtt Message Callback.
 *  If the message payload is larger than the maximum RX buffer
    then this callback is called multiple times.
    If msg_new = 1 its a new message.
    The topic_name and topic_name length are only valid when msg_new = 1.
    If msg_new = 0 then we are receiving additional payload.
    Each callback populates the payload in MqttMessage.buffer.
    The MqttMessage.buffer_len is the size of the buffer payload.
    The MqttMessage.buffer_pos is the location in the total payload.
    The MqttMessage.total_len is the length of the complete payload message.
    If msg_done = 1 the entire publish payload has been received.
 *  \param      client      Pointer to MqttClient structure
 *  \param      message     Pointer to MqttMessage structure that has been
                            initialized with the payload properties
 *  \param      msg_new     If non-zero value then message is new and topic
                            name / len is provided and valid.
 *  \param      msg_done    If non-zero value then we have received the entire
                            message and payload.
 *  \return     MQTT_CODE_SUCCESS to remain connected (other values will cause
                net disconnect - see enum MqttPacketResponseCodes)
 */
typedef int (*MqttMsgCb)(struct _MqttClient *client, MqttMessage *message,
    byte msg_new, byte msg_done);

/*! \brief      Mqtt Publish Callback.
 *  If the publish payload is larger than the maximum TX buffer
    then this callback is called multiple times. This callback is executed from
    within a call to MqttPublish. It is expected to provide a buffer and its
    size and return the number of valid bytes written. The library limits the
    final callback result to the remaining MqttPublish.total_len.
    Each callback populates the payload in MqttPublish.buffer.
    The MqttPublish.buffer_len is the size of the buffer payload.
    The MqttPublish.total_len is the length of the complete payload message.
 *  \param      publish     Pointer to MqttPublish structure
 *  \return     >= 0        Indicates success
 */
typedef int (*MqttPublishCb)(MqttPublish* publish);

/* Client flags */
enum MqttClientFlags {
    MQTT_CLIENT_FLAG_IS_CONNECTED = 0x01 << 0,
    MQTT_CLIENT_FLAG_IS_TLS       = 0x01 << 1,
    MQTT_CLIENT_FLAG_IS_DTLS      = 0x01 << 2,
    MQTT_CLIENT_FLAG_WOLFSSL_INIT = 0x01 << 3, /* this client called wolfSSL_Init */
    /* Disable the core automatic keep-alive PINGREQ at runtime, e.g. for an
     * application that schedules its own ping, without changing the keep-alive
     * negotiated with the broker. Set via MqttClient_Flags before connecting.
     * Has no effect when built with WOLFMQTT_NO_TIME. */
    MQTT_CLIENT_FLAG_NO_AUTO_KEEPALIVE = 0x01 << 4,
    /* A CONNECT has been written on the current Network Connection. Tracks the
     * MQTT handshake, which MQTT_CLIENT_FLAG_IS_CONNECTED does not: that flag
     * means only that the transport is up. [MQTT-3.1.0-1] requires CONNECT to
     * be the first packet a Client sends on a Network Connection and
     * [MQTT-3.1.0-2] allows only one, so the send APIs consult this flag.
     * Managed by the library - set by MqttClient_Connect and cleared by
     * MqttSocket_Connect and MqttSocket_Disconnect. Applications must not set
     * or clear it through MqttClient_Flags. */
    MQTT_CLIENT_FLAG_CONNECT_SENT = 0x01 << 5,
    /* A DISCONNECT has been written on the current Network Connection.
     * [MQTT-3.14.4-1] forbids any further Control Packet on it, so the send
     * APIs refuse one. Kept separate from MQTT_CLIENT_FLAG_CONNECT_SENT
     * because MqttClient_Disconnect does not close the transport: clearing
     * CONNECT_SENT instead would reopen the [MQTT-3.1.0-2] duplicate-CONNECT
     * guard and let a second CONNECT go out on the same Network Connection.
     * Managed by the library - set by MqttClient_Disconnect_ex and cleared by
     * MqttSocket_Connect and MqttSocket_Disconnect. */
    MQTT_CLIENT_FLAG_DISCONNECT_SENT = 0x01 << 6,
    /* TLS callback configured a certificate identity on client->tls.ssl.
     * Set only after wolfSSL_check_domain_name/check_ip_address succeeds. */
    MQTT_CLIENT_FLAG_TLS_CUSTOM_PEER_NAME = 0x01 << 7,
    /* Library-created VERIFY_NONE context. Managed by the library so TLS
     * retries retain the default verification policy. */
    MQTT_CLIENT_FLAG_TLS_DEFAULT_CTX = 0x01 << 8,
    /* Skip host identity setup when the callback disables authentication.
     * Does not change wolfSSL's certificate verification policy. */
    MQTT_CLIENT_FLAG_TLS_SKIP_HOST_CHECK = 0x01 << 9
};
/*! \brief      Sets flags in the MqttClient structure. To be used from
                the application before calling MqttClient_NetConnect.
 *  \param      client      Pointer to MqttClient structure
 *  \param      mask        Flags to clear
 *  \param      flags       Flags to set
 *  \return     Value of flags in the MqttClient structure
 */
WOLFMQTT_API word32 MqttClient_Flags(struct _MqttClient *client,  word32 mask, word32 flags);

typedef enum _MqttPkStat {
    MQTT_PK_BEGIN = 0,
    MQTT_PK_READ_HEAD,
    MQTT_PK_READ
} MqttPkStat;

typedef struct _MqttPkRead {
    MqttPkStat stat;
    int header_len;
    int remain_len;
    int buf_len;
} MqttPkRead;

typedef struct _MqttSk {
    int pos;   /* position inside current buffer */
    int len;   /* length of current segment being sent */
    int total; /* number bytes sent or received */

    /* status bit for if client read or write is active */
    byte isActive:1;
} MqttSk;

#ifdef WOLFMQTT_DISCONNECT_CB
    typedef int (*MqttDisconnectCb)(struct _MqttClient* client, int error_code, void* ctx);
#endif
#ifdef WOLFMQTT_PROPERTY_CB
    typedef int (*MqttPropertyCb)(struct _MqttClient* client, MqttProp* head, void* ctx);
#endif


#ifdef WOLFMQTT_SN
    /*! \brief      Mqtt-SN Register Callback.
     *  A GW sends a REGISTER message to a client if it wants to
        inform that client about the topic name and the assigned topic id that
        it will use later on when sending PUBLISH messages of the corresponding
        topic name. This callback allows the client to accept and save the new
        ID, or reject it if the ID is unknown. If the callback is not defined,
        then the regack will contain the "unsupported" return code.
     *  \param      topicId     New topic ID value
     *  \param      topicName   Pointer to topic name
     *  \param      reg_ctx     Pointer to user context
     *  \return     >= 0        Indicates acceptance
     */
    typedef int (*SN_ClientRegisterCb)(word16 topicId, const char* topicName, void *reg_ctx);
#endif

#if WOLFMQTT_MAX_QOS >= 2
    /* Max distinct inbound QoS 2 packet ids tracked awaiting PUBREL, used to
     * suppress re-delivery of a retransmitted PUBLISH [MQTT-4.3.3-10].
     * Override in user_settings.h to trade memory for a larger dedup window. */
    #ifndef MQTT_MAX_RECV_QOS2
        #define MQTT_MAX_RECV_QOS2 16
    #endif
    /* Also advertised as the v5 CONNECT Receive Maximum (see
     * MqttClient_Connect), so it must be a legal value for that property:
     * 0 is a Protocol Error [MQTT-3.1.2.11.3] and the field is 16-bit. */
    #if (MQTT_MAX_RECV_QOS2 < 1) || (MQTT_MAX_RECV_QOS2 > 65535)
        #error "MQTT_MAX_RECV_QOS2 must be between 1 and 65535"
    #endif
#endif

/* Max distinct outbound Packet Identifiers tracked as in flight. Each new
 * SUBSCRIBE, UNSUBSCRIBE or QoS>0 PUBLISH must use a currently unused
 * identifier [MQTT-2.3.1-2], and it only becomes reusable once the matching
 * SUBACK / UNSUBACK / PUBACK / PUBCOMP has been processed [MQTT-2.3.1-3].
 * Override in user_settings.h to trade memory for a larger in-flight window. */
#ifndef MQTT_MAX_SEND_INFLIGHT
    #define MQTT_MAX_SEND_INFLIGHT 16
#endif
#if (MQTT_MAX_SEND_INFLIGHT < 1) || (MQTT_MAX_SEND_INFLIGHT > 65535)
    #error "MQTT_MAX_SEND_INFLIGHT must be between 1 and 65535"
#endif

/* Client-side Session state for outbound QoS > 0 messages. MQTT 3.1.1
 * section 4.1 lists "QoS 1 and QoS 2 messages which have been sent to the
 * Server, but have not been completely acknowledged" as Session state the
 * Client stores, and [MQTT-4.4.0-1] requires them re-sent with their original
 * Packet Identifiers when it reconnects with CleanSession 0.
 *
 * Replaying a PUBLISH needs its topic and payload after the caller's
 * MqttPublish is gone, so the client keeps its own copy. That costs memory,
 * hence a pool sized separately from the (much cheaper) identifier table:
 * raise MQTT_MAX_REPLAY_MSGS to retain more in-flight messages, or define
 * WOLFMQTT_NO_SESSION_REPLAY to compile the store out entirely. A message
 * that does not fit is still sent, just not retained for replay.
 *
 * A PUBREL awaiting its PUBCOMP is retained regardless of the size limits:
 * it carries no payload, only the Packet Identifier. */
#ifndef WOLFMQTT_NO_SESSION_REPLAY
#ifndef MQTT_MAX_REPLAY_MSGS
    #define MQTT_MAX_REPLAY_MSGS 4
#endif
/* A zero-length array is a GNU extension, not C89, and would silently disable
 * the store rather than fail the build. Use WOLFMQTT_NO_SESSION_REPLAY to
 * remove it deliberately. */
#if (MQTT_MAX_REPLAY_MSGS < 1) || (MQTT_MAX_REPLAY_MSGS > 65535)
    #error "MQTT_MAX_REPLAY_MSGS must be between 1 and 65535"
#endif
#ifdef WOLFMQTT_STATIC_MEMORY
    /* Bounds of the in-struct copies when there is no allocator. */
    #ifndef MQTT_MAX_REPLAY_TOPIC
        #define MQTT_MAX_REPLAY_TOPIC 64
    #endif
    #ifndef MQTT_MAX_REPLAY_PAYLOAD
        #define MQTT_MAX_REPLAY_PAYLOAD 256
    #endif
    /* The topic copy is NUL terminated, so it needs room for the terminator
     * plus at least one character [MQTT-4.7.3-1]. */
    #if (MQTT_MAX_REPLAY_TOPIC < 2) || (MQTT_MAX_REPLAY_TOPIC > 65536)
        #error "MQTT_MAX_REPLAY_TOPIC must be between 2 and 65536"
    #endif
    #if (MQTT_MAX_REPLAY_PAYLOAD < 1)
        #error "MQTT_MAX_REPLAY_PAYLOAD must be at least 1"
    #endif
#endif

typedef struct _MqttReplayMsg {
    word32  payload_len;
#ifdef WOLFMQTT_STATIC_MEMORY
    char    topic[MQTT_MAX_REPLAY_TOPIC];
    byte    payload[MQTT_MAX_REPLAY_PAYLOAD];
#else
    char*   topic;      /* heap-owned, NUL-terminated */
    byte*   payload;    /* heap-owned, NULL when payload_len is 0 */
#endif
    word16  packet_id;  /* 0 = free slot */
    byte    qos;
    byte    retain;
    /* QoS 2 has advanced past PUBREC, so the replay is a PUBREL rather than
     * the PUBLISH [MQTT-4.4.0-1]. */
    byte    pubrelSent;
    /* The topic/payload copy is present. Clear when the message was too large
     * for the pool or came from a payload callback, which has nothing to
     * copy; such an entry can still replay a PUBREL but not a PUBLISH. */
    byte    haveCopy;
} MqttReplayMsg;
#endif /* !WOLFMQTT_NO_SESSION_REPLAY */

/* [MQTT-3.1.3-2] The ClientId identifies the Client and its Session. Both the
 * inbound QoS 2 de-duplication table and the outbound Session replay store use
 * a fingerprint of it to tell a resumed Session from a different one, so the
 * fingerprint exists whenever either of them does. Derived from those two
 * settings rather than set by hand: a command-line or user_settings.h define
 * is discarded here, since on its own it would redefine the macro and select
 * a build that records a fingerprint nothing reads. Use WOLFMQTT_MAX_QOS and
 * WOLFMQTT_NO_SESSION_REPLAY to control it. */
#undef WOLFMQTT_SESSION_ID_TRACK
#if (WOLFMQTT_MAX_QOS >= 2) || !defined(WOLFMQTT_NO_SESSION_REPLAY)
    #define WOLFMQTT_SESSION_ID_TRACK
    /* Bytes of the ClientId retained for that comparison. It is an exact
     * match, not a digest: a digest of this state is attacker-relevant when
     * the ClientId derives from untrusted input (a per-tenant or per-device
     * name), because finding two inputs with the same short digest is cheap
     * and would let one identity's Session state be replayed into another's.
     * A ClientId longer than this is simply not recorded, so the next Session
     * Present is treated as a different Session and the state is dropped -
     * safe, at the cost of no replay for such Clients. Raise it in
     * user_settings.h if longer ClientIds need Session replay. MQTT 3.1.1
     * section 3.1.3.1 requires Servers to accept at least 23 bytes. */
    #ifndef MQTT_MAX_SESSION_CLIENT_ID
        #define MQTT_MAX_SESSION_CLIENT_ID 64
    #endif
    #if (MQTT_MAX_SESSION_CLIENT_ID < 23)
        #error "MQTT_MAX_SESSION_CLIENT_ID must be at least 23"
    #endif
#endif

/* One outbound Packet Identifier reservation. packet_id 0 marks a free slot;
 * a Packet Identifier is never 0 [MQTT-2.3.1-1]. owner is the message object
 * that made the reservation, so MqttClient_CancelMessage can give it back
 * without knowing which packet type the object holds. */
typedef struct _MqttSendId {
    void*  owner;
    word16 packet_id;
    /* MqttPacketType of the acknowledgement that ends this exchange (PUBACK,
     * PUBCOMP, SUBACK or UNSUBACK), so a different response type naming the
     * same identifier cannot release it early [MQTT-2.3.1-3].
     * MQTT_PACKET_TYPE_RESERVED means "any". */
    byte   ack_type;
} MqttSendId;

#ifdef WOLFMQTT_V5
    /* Max CONNECT Authentication Method bytes retained to enforce reuse by a
     * later AUTH [MQTT-4.12.0-1]; a longer method cannot be verified so re-auth
     * is refused. Override in user_settings.h for longer names. */
    #ifndef MQTT_AUTH_METHOD_MAX
        #define MQTT_AUTH_METHOD_MAX 32
    #endif
#endif

/* Client structure */
typedef struct _MqttClient {
    word32       flags; /* MqttClientFlags */
    int          cmd_timeout_ms;

    byte        *tx_buf;
    int          tx_buf_len;
    byte        *rx_buf;
    int          rx_buf_len;

    MqttNet     *net;   /* Pointer to network callbacks and context */
#ifdef ENABLE_MQTT_CURL
    byte         curl_initialized; /* Owns one curl global init reference. */
#endif
#ifdef ENABLE_MQTT_TLS
    MqttTls      tls;   /* WolfSSL context for TLS */
#endif

    MqttPkRead   packet; /* publish packet state - protected by read lock */
    MqttPublishResp packetAck; /* publish ACK - protected by write lock */
    MqttSk       read;   /* read socket state - protected by read lock */
    MqttSk       write;  /* write socket state - protected by write lock */

    MqttMsgCb    msg_cb;
    MqttObject   msg;   /* generic incoming message used by MqttClient_WaitType */
#ifdef WOLFMQTT_SN
    SN_Object    msgSN;
    SN_PingReq   pingSN; /* persistent state for a NULL SN ping request */
    byte         pingSN_busy; /* one caller at a time owns pingSN */
    /* Persistent state for a NULL SN disconnect, so a partial write keeps its
     * resume position across MQTT_CODE_CONTINUE like every other send. */
    SN_Disconnect disconnectSN;
    byte         disconnectSN_busy; /* one caller at a time owns disconnectSN */
    SN_MsgType  sn_wait_packet_type;
    word16      sn_wait_packet_id;
    SN_ClientRegisterCb reg_cb;
    void               *reg_ctx;
#endif
    void*        ctx;   /* user supplied context for publish callbacks */

#ifdef WOLFMQTT_V5
    word32 packet_sz_max; /* Server property */
    byte   max_qos;       /* Server property */
    byte   retain_avail;  /* Server property */
    byte   enable_eauth;  /* Enhanced authentication */
    byte   protocol_level;
    byte   props_initialized; /* Internal property-stack ownership flag. */
#endif

#ifdef WOLFMQTT_DISCONNECT_CB
    MqttDisconnectCb disconnect_cb;
    void            *disconnect_ctx;
#endif
#ifdef WOLFMQTT_PROPERTY_CB
    MqttPropertyCb property_cb;
    void          *property_ctx;
#endif
#ifdef WOLFMQTT_MULTITHREAD
    byte   init_flags; /* Internal resource-initialization flags. */
    #ifdef WOLFMQTT_THREAD_ID_T
    byte   write_owner_valid; /* lockSend owner is known. */
    WOLFMQTT_THREAD_ID_T write_owner;
    #endif
    wm_Sem lockSend;
    wm_Sem lockRecv;
    wm_Sem lockClient;
    #ifdef ENABLE_MQTT_CURL
    wm_Sem lockCURL;
    #endif
    struct _MqttPendResp* firstPendResp; /* protected with client lock */
    struct _MqttPendResp* lastPendResp;  /* protected with client lock */
#endif
#if defined(WOLFMQTT_NONBLOCK) && defined(WOLFMQTT_DEBUG_CLIENT)
    int lastRc;
#endif
#ifndef WOLFMQTT_NO_TIME
    MqttPing keep_alive_ping; /* dedicated object for auto keep-alive PINGREQ */
    word32   last_tx_time;    /* WOLFMQTT_GET_TIME_S() at last control-pkt TX */
    word16   keep_alive_sec;  /* negotiated keep-alive; 0 disables auto-ping */
    /* v5 Server Keep Alive applied (0 is itself a valid keep-alive). Single-bit
     * flag per the wolfSSL struct guidance for booleans. */
    unsigned int keep_alive_from_server : 1;
#endif

#ifdef WOLFMQTT_V5
    /* Max unacked QoS>0 in flight; absent CONNACK means 65535 [3.1.2.11.3]. */
    word16 server_recv_max;
    /* Ceiling server_recv_max replenishes to; a spurious/duplicate ack
     * must not inflate the live quota above the negotiated value. */
    word16 server_recv_max_negotiated;
    /* Max Topic Alias value; absent CONNACK means 0 [3.1.2.11.8]. */
    word16 topic_alias_max;
    /* Set when the current connection's CONNECT carried an Authentication
     * Method; gates MqttClient_Auth so an AUTH is never sent on a connection
     * that never negotiated enhanced authentication [MQTT-4.12.0-1]. */
    byte   auth_method_set;
#endif

#if WOLFMQTT_MAX_QOS >= 2
    /* Inbound QoS 2 packet ids delivered to the application and awaiting their
     * PUBREL. A retransmitted PUBLISH with an id still listed here is answered
     * with PUBREC but not delivered a second time [MQTT-4.3.3-10]. Slot value 0
     * is empty; a QoS 2 packet id is never 0. */
    word16 recv_qos2_pending[MQTT_MAX_RECV_QOS2];
#endif
#ifdef WOLFMQTT_SESSION_ID_TRACK
    /* The ClientId whose Session state this client holds - the inbound QoS 2
     * pending ids and the outbound replay pool. A Session Present answer for a
     * different ClientId is a different Session and must not inherit either
     * [MQTT-3.1.3-2]. Length 0 means no Session is recorded. */
    char   session_client_id[MQTT_MAX_SESSION_CLIENT_ID];
    word16 session_client_id_len;
#endif

    /* Outbound Packet Identifiers written on the current Network Connection
     * and not yet released by their acknowledgement. Cleared when a connection
     * starts or ends, since the client keeps no outbound session state across
     * one. */
    MqttSendId send_inflight[MQTT_MAX_SEND_INFLIGHT];

#ifndef WOLFMQTT_NO_SESSION_REPLAY
    /* Unacknowledged outbound QoS > 0 messages retained for [MQTT-4.4.0-1]
     * replay after a CleanSession 0 reconnect. */
    MqttReplayMsg replay[MQTT_MAX_REPLAY_MSGS];
    /* Next replay slot to send; MQTT_MAX_REPLAY_MSGS when none is pending.
     * Kept on the client so a nonblocking replay can resume where it left
     * off. */
    int replayIdx;
#endif

#ifdef WOLFMQTT_V5
    /* CONNECT Authentication Method, retained so a later AUTH must reuse it
     * [MQTT-4.12.0-1]. auth_method_len is the full length; when it exceeds
     * MQTT_AUTH_METHOD_MAX the value is not stored and re-auth is refused. */
    word16 auth_method_len;
    byte   auth_method[MQTT_AUTH_METHOD_MAX];
#endif
} MqttClient;

#ifdef WOLFMQTT_SN
#include "wolfmqtt/mqtt_sn_client.h"
#endif

/* Application Interfaces */

/*! \brief      Initializes the MqttClient structure
 *  \param      client      Pointer to MqttClient structure
                            (uninitialized is okay)
 *  \param      net         Pointer to MqttNet structure that has been
                            initialized with callback pointers and context
 *  \param      msg_cb       Pointer to message callback function
 *  \param      tx_buf      Pointer to transmit buffer used during encoding
 *  \param      tx_buf_len  Maximum length of the transmit buffer
 *  \param      rx_buf      Pointer to receive buffer used during decoding
 *  \param      rx_buf_len  Positive maximum length of the receive buffer;
                            protocol packet readers enforce their minimum size
 *  \param      cmd_timeout_ms
                            Maximum command wait timeout in milliseconds
 *  \return     MQTT_CODE_SUCCESS or MQTT_CODE_ERROR_BAD_ARG
                (see enum MqttPacketResponseCodes)
 */
WOLFMQTT_API int MqttClient_Init(
    MqttClient *client,
    MqttNet *net,
    MqttMsgCb msg_cb,
    byte *tx_buf, int tx_buf_len,
    byte *rx_buf, int rx_buf_len,
    int cmd_timeout_ms);

/*! \brief      Cleans up resources allocated to the MqttClient structure
 *  \param      client      Pointer to MqttClient structure
 */
WOLFMQTT_API void MqttClient_DeInit(MqttClient *client);

#ifdef WOLFMQTT_DISCONNECT_CB
/*! \brief      Sets a disconnect callback with custom context
 *  \param      client      Pointer to MqttClient structure
                            (uninitialized is okay)
 *  \param      discb       Pointer to disconnect callback function
 *  \param      ctx         Pointer to your own context
 *  \return     MQTT_CODE_SUCCESS or MQTT_CODE_ERROR_BAD_ARG
                (see enum MqttPacketResponseCodes)
 */
WOLFMQTT_API int MqttClient_SetDisconnectCallback(
    MqttClient *client,
    MqttDisconnectCb discb,
    void* ctx);
#endif

#ifdef WOLFMQTT_PROPERTY_CB
/*! \brief      Sets a property callback with custom context
 *  \param      client      Pointer to MqttClient structure
                            (uninitialized is okay)
 *  \param      propCb      Pointer to property callback function
 *  \param      ctx         Pointer to your own context
 *  \return     MQTT_CODE_SUCCESS or MQTT_CODE_ERROR_BAD_ARG
                (see enum MqttPacketResponseCodes)
 */
WOLFMQTT_API int MqttClient_SetPropertyCallback(
    MqttClient *client,
    MqttPropertyCb propCb,
    void* ctx);
#endif

/*! \brief      Encodes and sends the MQTT Connect packet and waits for the
                Connect Acknowledgment packet
 *  \note This is a blocking function that will wait for MqttNet.read
 *  \param      client      Pointer to MqttClient structure
 *  \param      connect     Pointer to MqttConnect structure initialized
                            with connect parameters
 *  \return     MQTT_CODE_SUCCESS if the broker accepted the connection,
                MQTT_CODE_ERROR_CONNECT_REFUSED if the broker returned a
                non-zero CONNACK return_code (check
                connect->ack.return_code for the specific reason),
                MQTT_CODE_ERROR_STAT if a CONNECT has already been sent on
                this Network Connection - close it with
                MqttClient_NetDisconnect before connecting again
                [MQTT-3.1.0-2] - or another MQTT_CODE_ERROR_* for
                transport/protocol failures
                (see enum MqttPacketResponseCodes)
 */
WOLFMQTT_API int MqttClient_Connect(
    MqttClient *client,
    MqttConnect *connect);

/*! \brief      Encodes and sends the MQTT Publish packet and waits for the
                Publish response (if QoS > 0). If the total size of the
                payload is larger than the buffer size, it can be called
                successively to transmit the full payload.
                (if QoS > 0)
 *  \note       This function that will wait for MqttNet.read to complete,
                timeout or MQTT_CODE_CONTINUE if non-blocking.
                    If QoS level = 1 then will wait for PUBLISH_ACK.
                    If QoS level = 2 then will wait for PUBLISH_REC then send
                        PUBLISH_REL and wait for PUBLISH_COMP.
 *  \param      client      Pointer to MqttClient structure
 *  \param      publish     Pointer to MqttPublish structure initialized
                            with message data
 *                          Note: MqttPublish and MqttMessage are same
                            structure.
 *  \return     MQTT_CODE_SUCCESS, MQTT_CODE_CONTINUE (for non-blocking),
                MQTT_CODE_ERROR_PUBLISH_REJECTED if a v5 broker rejected a
                QoS>0 PUBLISH via a PUBACK (QoS 1) or PUBREC/PUBCOMP (QoS 2)
                reason code >= 0x80 (see MqttPublish.resp.reason_code),
                MQTT_CODE_ERROR_SERVER_PROP if the request violates a
                CONNACK-advertised v5 server property before sending (QoS above
                Maximum QoS, Retain unavailable, Topic Alias above the server
                maximum, or Receive Maximum quota exhausted),
                MQTT_CODE_ERROR_STAT if CONNECT has not been sent on this
                Network Connection [MQTT-3.1.0-1],
                MQTT_CODE_ERROR_PACKET_ID if the Packet Identifier is still
                awaiting its acknowledgement [MQTT-2.3.1-2],
                or MQTT_CODE_ERROR_* (see enum MqttPacketResponseCodes)
    \sa         MqttClient_Publish_WriteOnly
    \sa         MqttClient_Publish_ex
 */
WOLFMQTT_API int MqttClient_Publish(
    MqttClient *client,
    MqttPublish *publish);

/*! \brief      Encodes and sends the MQTT Publish packet and waits for the
                Publish response (if QoS > 0). The callback function is used to
                copy the payload data, allowing the use of transmit buffers
                smaller than the total size of the payload.
 *  \note       This function that will wait for MqttNet.read to complete,
                timeout or MQTT_CODE_CONTINUE if non-blocking.
                    If QoS level = 1 then will wait for PUBLISH_ACK.
                    If QoS level = 2 then will wait for PUBLISH_REC then send
                        PUBLISH_REL and wait for PUBLISH_COMP.
 *  \param      client      Pointer to MqttClient structure
 *  \param      publish     Pointer to MqttPublish structure initialized
                            with message data
 *                          Note: MqttPublish and MqttMessage are same
                            structure.
*   \param      pubCb       Function pointer to callback routine
 *  \return     MQTT_CODE_SUCCESS, MQTT_CODE_CONTINUE (for non-blocking),
                MQTT_CODE_ERROR_PUBLISH_REJECTED if a v5 broker rejected a
                QoS>0 PUBLISH via a PUBACK (QoS 1) or PUBREC/PUBCOMP (QoS 2)
                reason code >= 0x80 (see MqttPublish.resp.reason_code),
                MQTT_CODE_ERROR_SERVER_PROP if the request violates a
                CONNACK-advertised v5 server property before sending (QoS above
                Maximum QoS, Retain unavailable, Topic Alias above the server
                maximum, or Receive Maximum quota exhausted), or
                MQTT_CODE_ERROR_* (see enum MqttPacketResponseCodes)
 */
WOLFMQTT_API int MqttClient_Publish_ex(
    MqttClient *client,
    MqttPublish *publish,
    MqttPublishCb pubCb);


#ifdef WOLFMQTT_MULTITHREAD
/*! \brief      Same as MqttClient_Publish_ex, however this API will only
                perform writes and requires another thread to handle the read
                ACK processing using MqttClient_WaitMessage_ex
 *  \note       This function does not wait for MqttNet.read or any ACK; it only
                writes the PUBLISH (and, for QoS 2, the PUBREL once the reading
                thread has processed the PUBREC). The reading thread handles all
                ACK processing via MqttClient_WaitMessage_ex.
 *  \param      client      Pointer to MqttClient structure
 *  \param      publish     Pointer to MqttPublish structure initialized
                            with message data
 *                          Note: MqttPublish and MqttMessage are same
                            structure.
 *  \param      pubCb       Function pointer to callback routine
 *  \note       Only one v5 broker rejection is surfaced on this path: a QoS 2
                PUBREC with a reason code >= 0x80. The reading thread returns
                MQTT_CODE_ERROR_PUBLISH_REJECTED for it (suppressing an illegal
                PUBREL per [MQTT-4.3.3]) and completes this publish's pending
                response with the same code, so a later poll of this function
                returns MQTT_CODE_ERROR_PUBLISH_REJECTED instead of spinning on
                MQTT_CODE_CONTINUE. A QoS 1 PUBACK or QoS 2 PUBCOMP reason code
                >= 0x80 is NOT detected on this path and the publish appears
                successful. Use MqttClient_Publish/_ex when reliable v5
                broker-rejection detection for QoS>0 is required.
 *  \return     MQTT_CODE_SUCCESS, MQTT_CODE_CONTINUE (for non-blocking),
                MQTT_CODE_ERROR_STAT if CONNECT has not been sent on this
                Network Connection [MQTT-3.1.0-1],
                MQTT_CODE_ERROR_PACKET_ID if the Packet Identifier is still
                awaiting its acknowledgement [MQTT-2.3.1-2],
                or MQTT_CODE_ERROR_* (see enum MqttPacketResponseCodes)
    \sa         MqttClient_Publish
    \sa         MqttClient_Publish_ex
    \sa         MqttClient_WaitMessage_ex
 */
WOLFMQTT_API int MqttClient_Publish_WriteOnly(
    MqttClient *client,
    MqttPublish *publish,
    MqttPublishCb pubCb);
#endif

/*! \brief      Encodes and sends the MQTT Subscribe packet and waits for the
                Subscribe Acknowledgment packet
 *  \note This is a blocking function that will wait for MqttNet.read
 *  \param      client      Pointer to MqttClient structure
 *  \param      subscribe   Pointer to MqttSubscribe structure initialized with
                            subscription topic list and desired QoS.
 *  \return     MQTT_CODE_SUCCESS if every topic filter was accepted by the
                broker, MQTT_CODE_ERROR_SUBSCRIBE_REJECTED if the SUBACK was
                received but one or more filters were rejected (inspect each
                subscribe->topics[i].return_code for the per-filter result;
                v3.1.1 rejection is 0x80, v5 rejection is any reason_code
                >= 0x80),
                MQTT_CODE_ERROR_STAT if CONNECT has not been sent on this
                Network Connection [MQTT-3.1.0-1],
                MQTT_CODE_ERROR_PACKET_ID if the Packet Identifier is still
                awaiting its acknowledgement [MQTT-2.3.1-2],
                or another MQTT_CODE_ERROR_* for transport/protocol
                failures (see enum MqttPacketResponseCodes).
 */
WOLFMQTT_API int MqttClient_Subscribe(
    MqttClient *client,
    MqttSubscribe *subscribe);

/*! \brief      Encodes and sends the MQTT Unsubscribe packet and waits for the
                Unsubscribe Acknowledgment packet
 *  \note This is a blocking function that will wait for MqttNet.read
 *  \param      client      Pointer to MqttClient structure
 *  \param      unsubscribe Pointer to MqttUnsubscribe structure initialized
                            with topic list.
 *  \return     MQTT_CODE_SUCCESS,
                MQTT_CODE_ERROR_STAT if CONNECT has not been sent on this
                Network Connection [MQTT-3.1.0-1],
                MQTT_CODE_ERROR_PACKET_ID if the Packet Identifier is still
                awaiting its acknowledgement [MQTT-2.3.1-2],
                or MQTT_CODE_ERROR_* (see enum MqttPacketResponseCodes)
 */
WOLFMQTT_API int MqttClient_Unsubscribe(
    MqttClient *client,
    MqttUnsubscribe *unsubscribe);

/*! \brief      Encodes and sends the MQTT Ping Request packet and waits for the
                Ping Response packet
 *  \note This is a blocking function that will wait for MqttNet.read
 *  \param      client      Pointer to MqttClient structure
 *  \return     MQTT_CODE_SUCCESS,
                MQTT_CODE_ERROR_STAT if CONNECT has not been sent on this
                Network Connection [MQTT-3.1.0-1],
                or MQTT_CODE_ERROR_* (see enum MqttPacketResponseCodes)
 */
WOLFMQTT_API int MqttClient_Ping(
    MqttClient *client);

/*! \brief      Encodes and sends the MQTT Ping Request packet and waits for the
                Ping Response packet. This version takes a MqttPing structure
                and can be used with non-blocking applications.
 *  \note This is a blocking function that will wait for MqttNet.read
 *  \param      client      Pointer to MqttClient structure
 *  \param      ping        Pointer to MqttPing structure
 *  \return     MQTT_CODE_SUCCESS,
                MQTT_CODE_ERROR_STAT if CONNECT has not been sent on this
                Network Connection [MQTT-3.1.0-1],
                or MQTT_CODE_ERROR_* (see enum MqttPacketResponseCodes)
 */
WOLFMQTT_API int MqttClient_Ping_ex(MqttClient *client, MqttPing* ping);

#ifdef WOLFMQTT_V5
/*! \brief      Encodes and sends the MQTT Authentication Request packet and
                waits for the Ping Response packet
 *  \note This is a blocking function that will wait for MqttNet.read
 *  \param      client      Pointer to MqttClient structure
 *  \param      auth        Pointer to MqttAuth structure
 *  \return     MQTT_CODE_SUCCESS or MQTT_CODE_ERROR_*
                (see enum MqttPacketResponseCodes)
 */
WOLFMQTT_API int MqttClient_Auth(
    MqttClient *client,
    MqttAuth *auth);


/*! \brief      Add a new property.
 *  Allocate a property structure and add it to the head of the list
    pointed to by head. To be used prior to calling packet command.
 *  \param      head        Pointer-pointer to a property structure
 *  \return     MQTT_CODE_SUCCESS or MQTT_CODE_ERROR_BAD_ARG
 */
WOLFMQTT_API MqttProp* MqttClient_PropsAdd(
    MqttProp **head);

/*! \brief      Free property list.
 *  Deallocate the list pointed to by head. Must be used after the
                packet command that used MqttClient_Prop_Add.
 *  \param      head        Pointer-pointer to a property structure
 *  \return     MQTT_CODE_SUCCESS or -1 on error (and sets errno)
 */
WOLFMQTT_API int MqttClient_PropsFree(
    MqttProp *head);
#endif


/*! \brief      Encodes and sends the MQTT Disconnect packet (no response)
 *  \note This is a non-blocking function that will try and send using
                MqttNet.write
 *  \param      client      Pointer to MqttClient structure
 *  \return     MQTT_CODE_SUCCESS,
                MQTT_CODE_ERROR_STAT if CONNECT has not been sent on this
                Network Connection [MQTT-3.1.0-1],
                or MQTT_CODE_ERROR_* (see enum MqttPacketResponseCodes)
 */
WOLFMQTT_API int MqttClient_Disconnect(
    MqttClient *client);


/*! \brief      Encodes and sends the MQTT Disconnect packet (no response)
 *  \note This is a non-blocking function that will try and send using
                MqttNet.write
 *  \param      client      Pointer to MqttClient structure
 *  \param      disconnect  Pointer to MqttDisconnect structure. NULL is valid.
 *  \return     MQTT_CODE_SUCCESS,
                MQTT_CODE_ERROR_STAT if CONNECT has not been sent on this
                Network Connection [MQTT-3.1.0-1],
                or MQTT_CODE_ERROR_* (see enum MqttPacketResponseCodes)
 */
WOLFMQTT_API int MqttClient_Disconnect_ex(
    MqttClient *client,
    MqttDisconnect *disconnect);


/*! \brief      Waits for packets to arrive. Incoming publish messages
                will arrive via callback provided in MqttClient_Init.
 *  \note This is a blocking function that will wait for MqttNet.read
 *  \note A fatal protocol error in received data (malformed data, unexpected
                packet type or id, or an invalid v5 property) marks the
                connection disconnected (clears the connected flag); the
                application should call MqttClient_NetDisconnect to tear down
                the transport.
 *  \param      client      Pointer to MqttClient structure
 *  \param      timeout_ms  Milliseconds until read timeout
 *  \return     MQTT_CODE_SUCCESS or MQTT_CODE_ERROR_*
                (see enum MqttPacketResponseCodes)
 */
WOLFMQTT_API int MqttClient_WaitMessage(
    MqttClient *client,
    int timeout_ms);

/*! \brief      Waits for packets to arrive. Incoming publish messages
                will arrive via callback provided in MqttClient_Init.
 *  \note This is a blocking function that will wait for MqttNet.read
 *  \note A fatal protocol error in received data (malformed data, unexpected
                packet type or id, or an invalid v5 property) marks the
                connection disconnected (clears the connected flag); the
                application should call MqttClient_NetDisconnect to tear down
                the transport.
 *  \param      client      Pointer to MqttClient structure
 *  \param      msg         Pointer to MqttObject structure
 *  \param      timeout_ms  Milliseconds until read timeout
 *  \return     MQTT_CODE_SUCCESS or MQTT_CODE_ERROR_*
                (see enum MqttPacketResponseCodes)
 */
WOLFMQTT_API int MqttClient_WaitMessage_ex(
    MqttClient *client,
    MqttObject *msg,
    int timeout_ms);

#if defined(WOLFMQTT_MULTITHREAD) || defined(WOLFMQTT_NONBLOCK)
/*! \brief      In a multi-threaded and non-blocking mode this allows you to
                cancel an MQTT object that was previously submitted.
 *  \note This is a blocking function that will wait for MqttNet.read
 *  \param      client      Pointer to MqttClient structure
 *  \param      msg         Pointer to MqttObject structure
 *  \return     MQTT_CODE_SUCCESS or MQTT_CODE_ERROR_*
                (see enum MqttPacketResponseCodes)
 */
WOLFMQTT_API int MqttClient_CancelMessage(
    MqttClient *client,
    MqttObject *msg);
#endif

#ifdef WOLFMQTT_NONBLOCK
/*! \brief      In a non-blocking mode this checks if the message has a read
                or write pending (state is not MQTT_MSG_BEGIN).
 *  \note This function assumes caller owns the object
 *  \param      client      Pointer to MqttClient structure
 *  \param      msg         Pointer to MqttObject structure
 *  \return     MQTT_CODE_SUCCESS or MQTT_CODE_ERROR_*
                (see enum MqttPacketResponseCodes)
 */
WOLFMQTT_API int MqttClient_IsMessageActive(
    MqttClient *client,
    MqttObject *msg);
#endif /* WOLFMQTT_NONBLOCK */

/*! \brief      Performs network connect with TLS (if use_tls is non-zero value)
 *  Will perform the MqttTlsCb callback if use_tls is non-zero value
 *  \param      client      Pointer to MqttClient structure
 *  \param      host        Broker DNS name or IP address. TLS checks the peer
 *                          certificate against this value when the callback
 *                          supplies a TLS context. Use a fully qualified DNS
 *                          name for portable verification.
 *  \param      port        Optional custom port. If zero will use defaults
 *  \param      timeout_ms  Milliseconds until read timeout
 *  \param      use_tls     If non-zero value will connect with and use TLS for
                            encryption of data
 *  \param      cb          A function callback for configuration of the SSL
                            context certificate checking. To use a certificate
                            identity other than host, set it on client->tls.ssl
                            and set MQTT_CLIENT_FLAG_TLS_CUSTOM_PEER_NAME.
                            Callbacks that disable server authentication must
                            set MQTT_CLIENT_FLAG_TLS_SKIP_HOST_CHECK.
 *  \return     MQTT_CODE_SUCCESS or MQTT_CODE_ERROR_*
                (see enum MqttPacketResponseCodes)
 */
WOLFMQTT_API int MqttClient_NetConnect(
    MqttClient *client,
    const char *host,
    word16 port,
    int timeout_ms,
    int use_tls,
    MqttTlsCb cb);

/*! \brief      Performs a network disconnect
 *  \param      client      Pointer to MqttClient structure
 *  \return     MQTT_CODE_SUCCESS or MQTT_CODE_ERROR_*
                (see enum MqttPacketResponseCodes)
 */
WOLFMQTT_API int MqttClient_NetDisconnect(
    MqttClient *client);

/*! \brief      Gets number version of connected protocol version
 *  \param      client      Pointer to MqttClient structure
 *  \return     4 (v3.1.1) or 5 (v5)
 */
WOLFMQTT_API int MqttClient_GetProtocolVersion(MqttClient *client);

/*! \brief      Gets string version of connected protocol version
 *  \param      client      Pointer to MqttClient structure
 *  \return     String v3.1.1 or v5
 */
WOLFMQTT_API const char* MqttClient_GetProtocolVersionString(MqttClient *client);

#ifndef WOLFMQTT_NO_ERROR_STRINGS
/*! \brief      Performs lookup of the WOLFMQTT_API return values
 *  \param      return_code The return value from a WOLFMQTT_API function
 *  \return     String representation of the return code
 */
WOLFMQTT_API const char* MqttClient_ReturnCodeToString(
    int return_code);
#else
    #define MqttClient_ReturnCodeToString(x) \
                                        "not compiled in"
#endif /* WOLFMQTT_NO_ERROR_STRINGS */

/* Internal functions */
WOLFMQTT_LOCAL int MqttWriteStart(MqttClient* client, MqttMsgStat* stat);
WOLFMQTT_LOCAL void MqttWriteStop(MqttClient* client, MqttMsgStat* stat);
WOLFMQTT_LOCAL int MqttReadStart(MqttClient* client, MqttMsgStat* stat);
WOLFMQTT_LOCAL void MqttReadStop(MqttClient* client, MqttMsgStat* stat);
#ifdef WOLFMQTT_MULTITHREAD
WOLFMQTT_LOCAL int MqttClient_RespList_Find(MqttClient *client,
        MqttPacketType packet_type, word16 packet_id, MqttPendResp **retResp);
WOLFMQTT_LOCAL void MqttClient_RespList_Remove(MqttClient *client,
        MqttPendResp *rmResp);
WOLFMQTT_LOCAL int MqttClient_RespList_Add(MqttClient *client,
        MqttPacketType packet_type, word16 packet_id, MqttPendResp *newResp,
        void *packet_obj);
WOLFMQTT_LOCAL int MqttClient_CheckPendResp(MqttClient *client, byte wait_type,
        word16 wait_packet_id);
#endif
WOLFMQTT_LOCAL int MqttPacket_HandleNetError(MqttClient *client, int rc);

/* Securely zero `len` bytes of `mem` (e.g. client->tx_buf) to scrub plaintext
 * such as credentials or will payloads before releasing the send lock. Uses a
 * volatile pointer so the stores are not optimized away. */
WOLFMQTT_LOCAL void MqttClient_ForceZero(void* mem, word32 len);
#define CLIENT_FORCE_ZERO(mem, len) \
    MqttClient_ForceZero(mem, (word32)(len))

#ifdef __cplusplus
    } /* extern "C" */
#endif

#endif /* WOLFMQTT_CLIENT_H */
