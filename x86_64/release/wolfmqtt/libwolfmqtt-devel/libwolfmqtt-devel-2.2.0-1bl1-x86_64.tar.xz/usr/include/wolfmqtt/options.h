/* wolfmqtt options.h
 * generated from configure options
 *
 * Copyright (C) 2006-2020 wolfSSL Inc.
 *
 * * This file is part of wolfMQTT.
 *
 */

#ifndef WOLFMQTT_OPTIONS_H
#define WOLFMQTT_OPTIONS_H


#ifdef __cplusplus
extern "C" {
#endif

#ifndef WOLFSSL_OPTIONS_IGNORE_SYS
#undef  _FORTIFY_SOURCE
#define _FORTIFY_SOURCE 3
#endif

#undef  SIZEOF_LONG
#define SIZEOF_LONG 8

#undef  ENABLE_MQTT_TLS
#define ENABLE_MQTT_TLS

#undef  WOLFMQTT_DISCONNECT_CB
#define WOLFMQTT_DISCONNECT_CB

#undef  WOLFMQTT_MAX_QOS
#define WOLFMQTT_MAX_QOS 2


#ifdef __cplusplus
}
#endif


#endif /* WOLFMQTT_OPTIONS_H */

