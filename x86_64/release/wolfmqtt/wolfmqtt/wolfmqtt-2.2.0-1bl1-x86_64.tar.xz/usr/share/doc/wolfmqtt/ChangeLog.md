## Release Notes

### v2.2.0 (10/08/2026)
Release 2.2.0 has been developed according to wolfSSL's development and QA
process (see link below) and successfully passed the quality criteria.
https://www.wolfssl.com/about/wolfssl-software-development-process-quality-assurance

* New Features
    - Automatic client keep-alive: the core client now sends a `PINGREQ` from
      `MqttClient_WaitMessage` / `MqttClient_WaitMessage_ex` once the outbound
      link has been idle for about three quarters of the negotiated keep-alive
      interval, so the application no longer has to schedule pings itself and
      the ping reaches the broker before the deadline. Active whenever a
      non-zero keep-alive is set in `CONNECT`, and honors a v5 CONNACK Server
      Keep Alive override. In a blocking build a keep-alive ping left
      unanswered surfaces from `MqttClient_WaitMessage` as
      `MQTT_CODE_ERROR_NETWORK` rather than a timeout, so a dead link is
      distinguishable from an idle one; under `WOLFMQTT_NONBLOCK` the
      application remains responsible for its own liveness deadline. Because the
      ping round-trip runs inline using `cmd_timeout_ms`, a
      `MqttClient_WaitMessage` call that starts a keep-alive can take up to
      `cmd_timeout_ms` longer to return, so poll with a `timeout_ms` shorter
      than the keep-alive interval. The time source is the
      compile-time macro `WOLFMQTT_GET_TIME_S()` (defaults to `time(NULL)`,
      overridable in `user_settings.h`); define `WOLFMQTT_NO_TIME` to compile
      the scheduler out on clock-less targets, where the explicit
      `MqttClient_Ping` APIs still work. An application that already sends its
      own `PINGREQ` can disable the core scheduler at runtime - without changing
      the negotiated keep-alive - by setting `MQTT_CLIENT_FLAG_NO_AUTO_KEEPALIVE`
      with `MqttClient_Flags` before connecting, avoiding duplicate pings. The
      `mqttclient` example now relies on the automatic ping, keeping its
      previous manual keep-alive loop under `WOLFMQTT_NO_TIME` (#501)

* API / Behavior Changes
    - The broker now treats retaining a message as best-effort. When a
      `RETAIN=1` PUBLISH cannot be stored (retained table full, oversized
      payload, or allocation failure), the message is still delivered to all
      current subscribers and acknowledged with success at every QoS and
      protocol level; only the retained copy is skipped, and the skip is logged.
      This matches Mosquitto and replaces the previous inconsistent handling
      that could drop delivery on a retained-store failure. See `BROKER.md`.
    - The client rejects an inbound v5 PUBLISH that carries a Topic Alias and no
      longer advertises a nonzero Topic Alias Maximum in `CONNECT`. Inbound
      alias resolution is not implemented, so the client advertises Topic Alias
      Maximum 0 and a server that sends an alias anyway is treated as a protocol
      error. Outbound Topic Alias (client to server) is unchanged. An
      application that supplies a nonzero `MQTT_PROP_TOPIC_ALIAS_MAX` now gets
      `MQTT_CODE_ERROR_PROPERTY` from `MqttClient_Connect`.
    - A v5 `CONNECT` now advertises `Receive Maximum` set to
      `MQTT_MAX_RECV_QOS2` (16 by default) unless the application supplied its
      own `MQTT_PROP_RECEIVE_MAX`. This bounds the QoS 1 and QoS 2 PUBLISH
      packets a conforming server may have in flight toward the client
      [MQTT-3.3.4], keeping inbound QoS 2 within the client's de-duplication
      table so a retransmitted PUBLISH cannot be delivered twice
      [MQTT-4.3.3-10]. Override `MQTT_MAX_RECV_QOS2` in `user_settings.h` to
      trade memory for a larger window, or set the property explicitly to keep
      full control.
    - In `WOLFMQTT_MULTITHREAD` builds, a QoS 2 PUBREC rejection processed by
      the reading thread now also completes the originating
      `MqttClient_Publish_WriteOnly` pending response with
      `MQTT_CODE_ERROR_PUBLISH_REJECTED`, so the publisher's next poll returns
      that error instead of spinning on `MQTT_CODE_CONTINUE` until
      `cmd_timeout_ms`. This is the only v5 rejection surfaced on the write-only
      path; a QoS 1 PUBACK or QoS 2 PUBCOMP reason code >= 0x80 is still not
      detected there. Supersedes the v2.1.0 note below.
    - The client now tracks the MQTT handshake separately from the transport.
      `MqttClient_Publish`, `MqttClient_Subscribe`, `MqttClient_Unsubscribe`,
      `MqttClient_Ping` and `MqttClient_Disconnect` return
      `MQTT_CODE_ERROR_STAT` when called before `MqttClient_Connect` on a
      Network Connection [MQTT-3.1.0-1], and a second `MqttClient_Connect` on
      the same connection is refused with the same code [MQTT-3.1.0-2]. An
      application that reconnects must call `MqttClient_NetDisconnect` first,
      as the bundled examples already do (#590, #591)
    - The client keeps a connection-level record of outbound Packet
      Identifiers still awaiting their `PUBACK`, `PUBCOMP`, `SUBACK` or
      `UNSUBACK`, in every build rather than only under
      `WOLFMQTT_MULTITHREAD`. A new `SUBSCRIBE`, `UNSUBSCRIBE` or QoS>0
      `PUBLISH` reusing one is refused with `MQTT_CODE_ERROR_PACKET_ID`
      [MQTT-2.3.1-2]. Re-sending the same `PUBLISH` with `duplicate` set keeps
      its identifier, as [MQTT-2.3.1-3] requires. The window is
      `MQTT_MAX_SEND_INFLIGHT` (16 by default), overridable in
      `user_settings.h` (#589, #599, #601, #605, #611, #612, #613)
    - `MqttEncode_Connect` rejects a zero-byte ClientId paired with
      `clean_session` 0 for MQTT v3.1.1 [MQTT-3.1.3-7]. MQTT v5.0 drops the
      coupling and still allows it (#585)
    - `MqttConnect` gains `password_len`. [MQTT-3.1.3.5] defines the Password
      as Binary Data, which may contain 0x00, but the encoder measured it with
      `XSTRLEN` and truncated at the first one. Set `password_len` to send
      binary password bytes verbatim; leaving it 0 keeps the previous
      NUL-terminated behaviour, so existing callers are unaffected.
      `MqttDecode_Connect` reports the wire length here, so a decode/re-encode
      round trip no longer falls back to `XSTRLEN` over a pointer into a
      buffer that is not NUL terminated. The field is at the end of the
      struct, so the offsets of the existing members are unchanged (#588)
    - `MqttMsgStat` and `MqttConnect` grew. `MqttMsgStat` is the first member
      of every packet object, so `sizeof` changes for all of them and an
      application must be rebuilt against this header rather than relinked
      against the library. `MqttClient` also grows by the
      `MQTT_MAX_SEND_INFLIGHT` identifier table and, unless
      `WOLFMQTT_NO_SESSION_REPLAY` is defined, the `MQTT_MAX_REPLAY_MSGS`
      replay pool - about 1.3 KB under `WOLFMQTT_STATIC_MEMORY` at the
      defaults, which matters most on the targets that use it.

* Fixes
    - The v3.1.1 `CONNACK` decoder accepted a Remaining Length above 2 and
      swallowed the extra bytes; it now requires exactly 2 outside v5 (#603)
    - `PUBACK`, `PUBREC`, `PUBREL` and `PUBCOMP` carrying Packet Identifier 0
      were treated as spurious and ignored. They are now rejected with
      `MQTT_CODE_ERROR_PACKET_ID`, which closes the connection
      [MQTT-4.8.0-1] (#607)
    - Broker: a refused `CONNACK` whose write returned `MQTT_CODE_CONTINUE`
      was never resumed, so the client saw a truncated packet and never
      received the return code. The connection is now held open until the
      refusal is fully written and then closed (#592)
    - Broker: keep-alive monitoring no longer runs while an accepted `CONNACK`
      is still partly written, which could close the connection mid-handshake
      in `WOLFMQTT_NONBLOCK` builds. The handshake stays bounded by
      `BROKER_CONNECT_TIMEOUT_SEC` (#594)
    - Broker: a QoS>0 `PUBLISH` that got some bytes out and then failed inside
      one blocking write is now marked for retransmission, so session recovery
      replays it with `DUP` set [MQTT-3.3.1-1] (#604)
    - Broker: a partly written QoS 0 `PUBLISH` is dropped instead of following
      the session into an orphan, where it was delivered a second time after
      reconnect. QoS 0 allows no sender retry (#596). A transient
      `MQTT_CODE_ERROR_TIMEOUT` no longer counts as such a failure: the entry
      stays queued so the drain resumes from its offset instead of leaving a
      truncated packet on the wire, and the drop happens at the orphan
      hand-off
    - WebSocket: both receive callbacks now close the connection on a
      non-binary data frame instead of feeding its payload to the MQTT parser
      [MQTT-6.0.0-1] (#610)
    - Broker: static-memory fan-out now tracks the outbound QoS 1/2 Packet
      Identifiers each subscriber has not yet acknowledged, so a new PUBLISH
      cannot reuse one still awaiting its PUBACK or PUBCOMP [MQTT-2.3.1-4].
      Dynamic-memory builds already derived this from the per-subscriber
      queue. A delivery is skipped rather than sent with a reused identifier
      when all BROKER_MAX_INFLIGHT_PER_SUB slots are outstanding (#614). The
      slot is released when a delivery ends without an acknowledgement: an
      encode or write failure, or a v5 subscriber rejecting the QoS 2 delivery
      at the PUBREC stage [MQTT-4.3.3]
    - The client now keeps unacknowledged outbound QoS > 0 messages as Session
      state and re-sends them after a `CleanSession=0` reconnect the server
      answers with Session Present = 1: a PUBLISH goes out again with its
      original Packet Identifier and `DUP` set, and a QoS 2 exchange already
      past PUBREC re-sends the PUBREL instead [MQTT-4.4.0-1],
      [MQTT-3.3.1-1]. Replaying a PUBLISH needs its topic and payload after
      the caller's `MqttPublish` is gone, so the client copies them into a
      bounded pool of `MQTT_MAX_REPLAY_MSGS` entries (4 by default; under
      `WOLFMQTT_STATIC_MEMORY` also bounded by `MQTT_MAX_REPLAY_TOPIC` and
      `MQTT_MAX_REPLAY_PAYLOAD`). A message that does not fit, or one streamed
      through a payload callback, is still sent but not retained. Define
      `WOLFMQTT_NO_SESSION_REPLAY` to compile the store out (#597, #598, #602)
    - A v5 `PUBREC` with a reason code >= 0x80 ends the QoS 2 exchange
      [MQTT-4.3.3], so the client now releases the Packet Identifier there
      [MQTT-2.3.1-3] and drops the message from Session state instead of
      replaying a PUBLISH the server explicitly refused
    - The QoS acknowledgement for a received PUBLISH is now staged on the wait
      object rather than in a field shared by every reader. Another thread
      completing its own read could previously overwrite it between the read
      lock being dropped and the send lock being taken, sending the later
      Packet Identifier twice and never the earlier one [MQTT-4.6.0-2] (#608)
    - Session state is keyed on the ClientId itself rather than a 32-bit hash
      of it. Two different ClientIds sharing a hash would have let one
      identity's replay entries and QoS 2 pending ids be treated as the
      other's, which matters when the ClientId derives from untrusted input.
      A ClientId longer than `MQTT_MAX_SESSION_CLIENT_ID` (64 by default) is
      not recorded, so its Session state is dropped rather than partially
      matched [MQTT-3.1.3-2]
    - `MqttClient_Disconnect` no longer clears the CONNECT-sent flag. It
      writes the DISCONNECT packet but does not close the transport, so
      clearing that flag reopened the duplicate-CONNECT guard and allowed a
      second CONNECT on the same Network Connection [MQTT-3.1.0-2]. A separate
      flag now refuses further packets after DISCONNECT [MQTT-3.14.4-1]
    - `MqttClient_CancelMessage` keeps the Packet Identifier of a packet that
      already reached the wire. The peer can still answer it, and that
      acknowledgement would otherwise complete whatever new exchange had taken
      the identifier over; [MQTT-2.3.1-3] makes it reusable only once the
      acknowledgement is processed. A packet that never fully went out still
      releases its identifier immediately
    - Retained replay copies of topics and payloads are zeroized before being
      freed, so application data - which may include credentials - is not left
      in reusable heap
    - Outbound Session state is now bound to the ClientId that created it, so
      a client object reused under a new ClientId no longer replays the
      previous Session's messages into the new one when the server answers
      Session Present = 1 [MQTT-3.1.3-2]
    - A zero-byte QoS 1/2 PUBLISH is retained for replay. Section 3.3.3 allows
      an empty payload and [MQTT-4.4.0-1] asks for it back like any other
      unacknowledged message; it was previously treated as a payload that
      could not be copied
    - A v5 PUBLISH carrying properties is no longer retained for replay. The
      pool stores no properties, so re-sending would strip Response Topic,
      Correlation Data and the rest - a different message from the one the
      server is waiting on. Retaining properties for replay is not implemented
    - A replay entry that can never be re-sent (no retained payload) is dropped
      on reconnect instead of holding its Packet Identifier for the life of the
      connection, since no acknowledgement will release it [MQTT-2.3.1-3]
    - The Packet Identifier reservation now records the acknowledgement that
      ends its exchange, so a PUBACK naming a QoS 2 identifier cannot complete
      it early [MQTT-2.3.1-3]. The reservation and its replay record are
      released under one lock, closing a window where a publisher could reuse
      the identifier in between and have the old ack delete the new exchange's
      state
    - The replay record is created before the PUBLISH reaches the wire. In
      `WOLFMQTT_MULTITHREAD` builds a reader thread could otherwise process the
      acknowledgement first, leaving an already-acknowledged message retained
      and replayed after the next reconnect
    - `MqttClient_Publish`, `MqttClient_Subscribe`, `MqttClient_Unsubscribe`
      and `MqttClient_Ping` are refused after `MqttClient_Disconnect`
      [MQTT-3.14.4-1]
    - The duplicate-CONNECT guard reads the handshake flag under `lockClient`
      rather than through `MqttClient_Flags`, which reports "no flags set" when
      the lock cannot be taken and would have let a second CONNECT through
      [MQTT-3.1.0-2]
    - `MqttClient_Connect` now resets the CONNACK wait state on the
      `MqttConnect` object it was given. Reusing one across reconnects - what
      the bundled examples do - left `mc_connect->ack` mid-read, so the second
      handshake skipped the CONNACK read and handed whatever was still in
      `rx_buf` to the PUBLISH payload handler instead of waiting for the new
      CONNACK [MQTT-3.2.0-1]
    - The client's inbound QoS 2 de-duplication table is now bound to the
      ClientId that populated it. Reusing one `MqttClient` under a new
      ClientId no longer inherits the previous Session's pending packet ids
      when the server answers Session Present = 1 [MQTT-3.1.3-2] (#595)
    - `WOLFMQTT_NO_STDIO` builds failed to compile because the default
      `WOLFMQTT_MALLOC` / `WOLFMQTT_FREE` expand to `malloc()` / `free()` but
      `<stdlib.h>` was only included alongside `<stdio.h>`. The header is now
      included with the allocator defaults that need it, which also fixes
      `WOLFMQTT_CUSTOM_PRINTF` ports such as MPLAB Harmony, and a port that
      supplies both macros no longer pulls it in for the allocator. The
      default `XATOI` needs `atoi` from the same header, so it is included
      with that macro too (#619)
    - `WOLFMQTT_CUSTOM_MALLOC` without `WOLFMQTT_MALLOC` and `WOLFMQTT_FREE`
      now fails in the header with a message naming both macros, instead of an
      implicit declaration reported from inside `mqtt_client.c` (#619)
    - `<string.h>` is no longer pulled in for `WOLFMQTT_CUSTOM_STRING` ports.
      It was previously included alongside `<stdio.h>` whatever the setting, so
      such a port picked up the standard string declarations by accident; it
      must now supply its own string macros and any headers those need (#619)
    - `WOLFMQTT_SESSION_ID_TRACK` is derived from `WOLFMQTT_MAX_QOS` and
      `WOLFMQTT_NO_SESSION_REPLAY`, so a build that also defined it on the
      command line hit a macro redefinition, fatal under `-Werror`. Such a
      define is now discarded rather than redefining the macro (#619)
    - `WOLFMQTT_NO_STDIO` broker builds failed to compile because the log
      calls drop their arguments once `PRINTF` is a no-op, leaving the log
      string sanitizer with no callers. `WOLFMQTT_NO_STDIO` now implies
      `WOLFMQTT_BROKER_NO_LOG`, except where `WOLFMQTT_CUSTOM_PRINTF` supplies
      a working sink (#619)

* What's Changed
    - Low-severity hardening, encode/decode validation, credential/payload zeroization, and SN/example fixes (#560)
    - Fenrir fixes (#559)
    - Fenrir fixes (#561)
    - Coverity fixes (#562)
    - Add auto-ping feature to client (#563)
    - Coverity and fenrir fixes (#564)
    - Fix fenrir issues (#565)
    - Fenrir fixes (#566)
    - Serialize curl getinfo under lockCURL to fix multithread stress race (#568)
    - Low-severity hardening and compliance fixes (#567)
    - Harden CONNECT credential handling compliance (#572)
    - Preserve nonblocking enhanced authentication state (#574)
    - Preserve persistent sessions on WebSocket close (#573)
    - Add contribution guidance (CONTRIBUTING.md) (#569)
    - Preserve the static persistent session delivery (#570)
    - Propagate persistence restore failures (#571)
    - Fix broker session persistence and nonblocking CONTINUE handling (#575)
    - Fenrir fixes: MQTT v5 client and broker (#576)
    - Harden MQTT protocol validation and lifecycle handling (#577)
    - Ensure expired messages have their records removed (#578)
    - Reject AUTH, server-sent DISCONNECT and payload bytes in UNSUBACK below v5. Publish Will on write failure. (#583)
    - MQTT compliance fixes for CONNECT ordering, Packet Identifier tracking, CONNACK, keepalive, and QoS replay (#615)
    - Harden QoS delivery, persistent sessions, reauthentication, and MQTT SN sends (#579)
    - Fix MQTT 5 property validation and QoS 2 state handling in broker and client (#618)
    - Reject undersized MQTT-SN Length field in SN_Packet_Read (#621)
    - Broker returns v5 UNSUBACK "No subscription existed" reason code when no filter matched (#617)
    - Preserve resumed MQTT sessions and verify TLS broker identity (#623)
    - Fix non-TLS builds and static analysis issues (#620)

* New Contributors
    - @ageprocpp made their first contribution (#617)

### v2.1.0 (07/02/2026)
Release 2.1.0 has been developed according to wolfSSL's development and QA
process (see link below) and successfully passed the quality criteria.
https://www.wolfssl.com/about/wolfssl-software-development-process-quality-assurance

* New Features
    - wolfMQTT Broker session persistence: pluggable persistence hooks via
      `MqttBroker_SetPersistHooks` with a POSIX backend
      (`MqttBrokerNet_PersistPosix_Init` / `MqttBrokerNet_PersistPosix_Free`),
      message ordering, an offline message queue, and AES-GCM encryption of
      persisted state at rest (#538)
    - New packet-validation helpers: `MqttPacket_TopicNameValid`,
      `MqttPacket_TopicFilterValid`, `MqttPacket_TopicFilterIsWildcard`,
      `MqttPacket_FixedHeaderFlagsValid`, and `MqttPacket_SubAckReturnCodeValid`
      (#552)
    - `WOLFMQTT_MAX_QOS` build cap to compile out the QoS 2 state machine and
      advertise v5 `MAX_QOS` in CONNACK (#537)

* Security Hardening
    - Reject ill-formed UTF-8 in MQTT UTF-8 string fields per [MQTT-1.5.3-1].
      `MqttDecode_String` now validates each decoded string against RFC 3629
      and rejects encodings of surrogate code points (U+D800..U+DFFF) with
      `MQTT_CODE_ERROR_MALFORMED_DATA`. Receivers MUST close the network
      connection on malformed packets, which the broker's existing decode-
      error path enforces. The check covers ClientId, Will Topic, Topic Name,
      Topic Filter, Username, and v5 STRING/STRING_PAIR property values.
    - The broker now requires `auth_user` and `auth_pass` to be configured as
      a pair. Previously, setting only one (e.g. the `-u` CLI flag without
      `-P`) silently enabled single-factor authentication: the unconfigured
      side was never checked, so any password authenticated against a matching
      username (or any username against a matching password). `MqttBroker_Start`
      now rejects a partial credential configuration with
      `MQTT_CODE_ERROR_BAD_ARG`, and the connect-time gate fails closed as a
      defense in depth if only one credential is set. Leaving both NULL still
      disables authentication.

* API / Behavior Changes
    - `MqttDecode_String` may now return `MQTT_CODE_ERROR_MALFORMED_DATA`
      on ill-formed UTF-8. This applies to client builds as well as broker
      builds — [MQTT-1.5.3-1] is normative for both. wolfMQTT clients that
      previously accepted PUBLISH messages with non-UTF-8 topics from
      misbehaving brokers will now error on those messages. There is no
      opt-out: the spec is a MUST.
    - `MqttDecode_Publish` now propagates the underlying error from
      `MqttDecode_String` (e.g. `MALFORMED_DATA`) instead of always
      returning `MQTT_CODE_ERROR_OUT_OF_BUFFER` on topic decode failure.
    - `MqttDecode_Props` similarly now propagates the underlying error from
      `MqttDecode_String` for v5 STRING and STRING_PAIR property types
      (Reason String, Content Type, User Property, etc.) instead of masking
      it as `MQTT_CODE_ERROR_PROPERTY`.
    - The CONNECT Password decode no longer goes through `MqttDecode_String`
      because [MQTT-3.1.3.5] defines Password as Binary Data, not a UTF-8
      string. A binary password containing bytes that are not valid UTF-8
      (e.g., `0xC0`, `0xFF`) would otherwise be incorrectly rejected.
    - `MqttClient_Publish` / `MqttClient_Publish_ex` now return the new
      `MQTT_CODE_ERROR_PUBLISH_REJECTED` (-21) when a v5 broker rejects a
      QoS>0 PUBLISH via a PUBACK (QoS 1), PUBREC, or PUBCOMP (QoS 2) reason
      code >= 0x80 (e.g. Not authorized, Quota exceeded, Topic Name invalid,
      Payload format invalid). Previously these were reported as
      `MQTT_CODE_SUCCESS`, so the application proceeded as if the broker had
      accepted the message. The specific reason is available in
      `MqttPublish.resp.reason_code`. For QoS 2, a PUBREC reason code >= 0x80
      now ends the exchange without sending PUBREL per [MQTT-4.3.3] instead of
      timing out. v3.1.1 publishes are unaffected, as is the return value of
      the fire-and-forget `MqttClient_Publish_WriteOnly` call itself. Callers
      that treat any non-success return as fatal may need to handle this code.
      In `WOLFMQTT_MULTITHREAD` builds where a dedicated thread drives reads,
      that reading thread now returns `MQTT_CODE_ERROR_PUBLISH_REJECTED` when it
      processes a QoS 2 PUBREC rejection (instead of advancing the handshake
      with an illegal PUBREL); the originating write-only publish's pending
      response is not auto-completed in that case, so it blocks until
      `cmd_timeout_ms`. A QoS 1 PUBACK or QoS 2 PUBCOMP rejection is NOT
      detected on the write-only path (the publish appears successful), matching
      prior behavior; use `MqttClient_Publish`/`_ex` for reliable detection.
    - An incoming PUBLISH received by a client with no message callback
      registered (`msg_cb == NULL`) now returns `MQTT_CODE_ERROR_CALLBACK`
      (-13) instead of `MQTT_CODE_SUCCESS`. Previously the payload was silently
      read and discarded, and for QoS 1/2 a PUBACK/PUBREC was still sent,
      falsely telling the broker the message was delivered while the application
      never saw it. `MqttClient_HandlePacket` no longer populates an ACK in this
      case, so no false acknowledgement is sent. This affects standard MQTT
      (`MqttClient_Publish_ReadPayload`) and MQTT-SN (`SN_Client_HandlePacket`).
      A registered `msg_cb` is now required to receive a PUBLISH; this includes
      the receive-into-object pattern via `MqttClient_WaitMessage_ex` /
      `SN_Client_WaitMessage_ex`, which previously returned success after
      decoding into the caller-supplied object without a callback. A NULL
      callback is still valid for a publish-only client that never receives
      messages; the error surfaces only if such a client is actually pushed a
      PUBLISH. The built-in broker is unaffected (it handles incoming PUBLISH
      through its own path, not this one).

* Fixes
    - `SN_Client_Unsubscribe` now registers its pending UNSUBACK response under
      the real Packet Identifier instead of a hard-coded `0`. In
      `WOLFMQTT_MULTITHREAD` builds where a dedicated reader thread processes the
      UNSUBACK first, `MqttClient_RespList_Find` matches on the decoded packet
      id, so the id-0 entry never matched and the response was consumed into the
      generic object, leaving the unsubscribing thread blocked until
      `cmd_timeout_ms`. The registration now matches `SN_Client_Subscribe`,
      `SN_Client_Register`, and `SN_Client_Publish`.

* What's Changed
    - Fix BrokerHandle_Connect null check (#477)
    - Fenrir fixes (#478)
    - Add testing validation and fixes for wolfMQTT (#480)
    - Replace deprecated VeriSign CA with Amazon Root CA 1 + Starfield G2 (#481)
    - Update testing with a more flexible framework (#482)
    - Fix new Fenrir reports (#483)
    - Always check MqttDecode_Num's return code (#479)
    - Add Fenrir suggested test cases (#484)
    - Reject null chars in strings (#503)
    - Fix various spec compliance gaps (#504)
    - Fix MQTTv5 QoS 2 CONNACK interop and add WOLFMQTT_MAX_QOS build cap (#537)
    - Fix Coverity nightly: inline action, drop broken md5 hash lookup (#547)
    - Harden param checks in MqttDecode_FixedHeader and MqttDecode_ConnectAck (#546)
    - Harden Coverity tool download: curl -L --fail + gzip sanity check (#549)
    - Fix broker disconnect to better handle SIGPIPE (#548)
    - wolfMQTT broker: ordering, persistence, offline queue, AES-GCM at rest (#538)
    - Speed up CI and stabilize aws-ca-regression (#551)
    - MQTT-SN fixes (#550)
    - Broker, client, and MQTT v5 packet validation and reliability fixes (#552)
    - Fenrir fixes (#554)

* New Contributors
    - @night1rider made their first contribution (#481)

### v2.0.0 (03/20/2026)
Release 2.0.0 has been developed according to wolfSSL's development and QA
process (see link below) and successfully passed the quality criteria.
https://www.wolfssl.com/about/wolfssl-software-development-process-quality-assurance

* New Features
    - Lightweight MQTT Broker — New built-in MQTT broker implementation (#457)
    - MQTT v3.1.1 spec compliance checks (#462)
    - Secure and non-secure port listening support (#465)
    - WebSocket transport support (#466)
    - wolfIP (embedded TCP/IP stack) support (#463)
    - Retained messages, session persistence, graceful disconnect, QoS subscription updates (#465)
    - libFuzzer-based broker fuzzing infrastructure (#474)
    - wolfIP Integration — Added wolfIP support for both MQTT client and broker (#463)
    - lastError Field — Preserve TLS error code via new lastError in the network context (#458)
 
* Bug Fixes
    - Fix race condition in wm_SemLock (#475)
    - Fix wildcard topic matching (#472)
    - Fix LWT (Last Will and Testament) length checks and payload free issues (#472, #473)
    - Fix subAck buffer size check and topic count validation (#472)
    - Fix MqttPacket_Write failure return handling (#473)
    - Fix MQTT-SN: null pointer dereference, non-blocking read, encode/decode issues (#473)
    - Fix MqttDecode_Auth reason code issue (#473)
    - Fix broker client connect status check (#472)
    - Fix SN_Client_WaitType issues (#456)
    - Fix curl transport: use internal loops for partial read/write handling (#459)

* Security Hardening
    - Add overflow checks in network and socket IO (#467)
    - Add checks for negative return values in MqttDecode_String calls (#467)
    - Add encoding error checks (#467)
    - Add remain_len validation check (#471)
    - Static analysis fixes for MqttClient_Auth, MqttProps_Add, MqttDecode_SubscribeAck, MqttDecode_Props (#469)
    - Static analysis fixes for SN_Decode_Register, SN_Decode_GWInfo, SN_Client_WillTopicUpdate, SN_Encode_Publish, SN_Encode_RegAck, SN_Client_Connect (#468)
    - Add debug warning when using VERIFY_NONE (#475)

* CI / Testing
    - Add CI workflows for codespell, multi-compiler, and sanitizer tests (#470)
    - Add Coverity workflow schedule (#450, #451)
    - Add WebSocket broker configurations to CI (#466)
    - Expanded broker edge case testing (#465)
    - Improved broker test execution speed (#465)

* Other
    - Updated client certificates (#455)
    - Added wolfSSL as submodule option (#452)

### v1.21.0 (12/03/2025)
Release 1.21.0 has been developed according to wolfSSL's development and QA
process (see link below) and successfully passed the quality criteria.
https://www.wolfssl.com/about/wolfssl-software-development-process-quality-assurance

* Add port for NETX use by @JacobBarthelmeh in #427
* Fix heap buffer overflow in MqttDecode_Num with bounds checking by @embhorn in #430
* Restore instructions for testing against OQS mosquitto integration. by @anhu in #432
* initial threadx test by @JacobBarthelmeh in #429
* Rename ML-KEM hybrids to match IETF Draft. by @anhu in #435
* Update expired test certs by @lealem47 in #441
* Pin to ESP-IDF v5.5, limit workflow push branches, line endings by @gojimmypi in #444
* Fix: MQTT v5 Property-Packet Protocol Validation and Decode Safety by @kaabia in #440
* Fix: Correct state transition check in MqttClient_Auth by @kaabia in #439
* fix: correct variable in MQTT property decode error checks by @kaabia in #445
* Add fflush to mqtt-sub example by @embhorn in #447
* Update license to GPLv3 by @embhorn in #448

### v1.20.0 (05/02/2025)
Release 1.20.0 has been developed according to wolfSSL's development and QA
process (see link below) and successfully passed the quality criteria.
https://www.wolfssl.com/about/wolfssl-software-development-process-quality-assurance

* OQS's Mosquitto is out of date. by @anhu in #417
* Add support for websocket by @embhorn in #418
* Add support for secure websockets by @embhorn in #419
* Add secure ws CI test by @embhorn in #421
* Update examples for latest Managed Components by @gojimmypi in #420
* Improve cmake duplicate component check by @gojimmypi in #422

### v1.19.2 (01/31/2025)
Release 1.19.2 has been developed according to wolfSSL's development and QA
process (see link below) and successfully passed the quality criteria.
https://www.wolfssl.com/about/wolfssl-software-development-process-quality-assurance

* Handle connection error in mqttsimple client by @embhorn in #407
* Fix stat reset for ping response by @embhorn in #414

### v1.19.1 (11/06/2024)
Release 1.19.1 has been developed according to wolfSSL's development and QA process (see link below) and successfully passed the quality criteria.
https://www.wolfssl.com/about/wolfssl-software-development-process-quality-assurance

* wolfssl 5.7.2 time_helper type adjustments for Espressif example by @gojimmypi in #404
* Fix Doxygen issues by @embhorn in #403

### v1.19.0 (3/22/2024)
Release 1.19.0 has been developed according to wolfSSL's development and QA process (see link below) and successfully passed the quality criteria.
https://www.wolfssl.com/about/wolfssl-software-development-process-quality-assurance

* Add stress test. by @philljj in #387
* Add cmake CI test and fix pthread detection by @embhorn in #389
* Initial wolfMQTT Espressif ESP32 template and AWS IoT examples by @gojimmypi in #388
* Add curl test dependencies by @lealem47 in #392
* Improving and fixing typos for STM32CUBE build by @lealem47 in #391
* Fix string prop OOB read by @embhorn in #394
* Fix some Helgrind thread errors with enable-tls, and enable-curl. by @philljj in #396
* Initial Espressif CI; limit Zepher CI by @gojimmypi in #390
* Fix double unlock and double lock in multithread example. by @philljj in #397
* Fix double lock of lockRecv. by @philljj in #398

### v1.18.0 (12/22/2023)
Release 1.18.0 has been developed according to wolfSSL's development and QA process (see link below) and successfully passed the quality criteria.
https://www.wolfssl.com/about/wolfssl-software-development-process-quality-assurance

* Add curl easy socket backend. by @philljj in #380
* WOLFMQTT_EXAMPLE_CERT allowing static or extern cert assignment by @gojimmypi in #354
* Tiny readme cleanup. by @philljj in #381
* Fix high coverity issues by @embhorn in #379
* Add broker check to scripts by @embhorn in #385
* Cmake build fixes by @embhorn in #384

### v1.17.1 (11/29/2023)
Release 1.17.1 has been developed according to wolfSSL's development and QA process (see link below) and successfully passed the quality criteria.
https://www.wolfssl.com/about/wolfssl-software-development-process-quality-assurance

* Include stdint.h in userio_template.h by @lealem47 in #371
* Improvements to multithread locking and tests. by @dgarske in #369
* Cleanup executable status on src files. by @philljj in #372
* Close socket on error in NetConnect by @embhorn in #375
* Fixes for non-blocking with larger payload and improvements to the test and examples by @dgarske in #373
* Add MQTT-SN CI tests by @embhorn in #376
* Fix Wild read in MqttProps_Free by @embhorn in #377
* Fix fuzzer issues in MqttDecode_Props by @embhorn in #378

### v1.17.0 (11/2/2023)
Release 1.17.0 has been developed according to wolfSSL's development and QA process (see link below) and successfully passed the quality criteria.
https://www.wolfssl.com/about/wolfssl-software-development-process-quality-assurance

* Fix for declaration after executable block by @lealem47 in #341
* Add QNX IDE, Makefile, and remove source code exec bit by @JacobBarthelmeh 
  in #317
* update for cmake after wolfssl added NAMESPACE by @JacobBarthelmeh in #343
* Add mutex protection to MqttClient_NetDisconnect by @embhorn in #342
* Add DTLS support to MQTT-SN client by @embhorn in #348
* Tie zephyr tests to a release by @julek-wolfssl in #350
* add documentation link to README by @gojimmypi in #355
* Possible patch for POSIX conditional wait issue by @dgarske in #356
* Fix publish with topic ID >=127 by @embhorn in #351
* Adding publish and subscribe atomic client examples by @embhorn in #347
* Allow disabling the posix conditional signal by @dgarske in #360
* Exclude CI tests with external brokers by @embhorn in #362
* Improvements for client property stack by @dgarske in #361
* Add mosquitto to CI tests by @embhorn in #365
* Fixes for non-blocking edge cases by @dgarske in #363
* Refactor MQTT-SN code by @embhorn in #366

### v1.16.0 (6/29/2023)
* Add testing for TLS mutual auth, and fsanitize gh test by @lealem47 in #321
* Add support for pkcs8 keys to mqtt client by @lealem47 in #322
* Fix null ptr deref in MqttClient_WaitType by @embhorn in #323
* Cleanup enum last entry to not have comma by @dgarske in #324
* Cleanup the AWS example by @dgarske in #326
* Fix for multi-threaded non-blocking use of sockRc, which could collide
  between read and write by @dgarske in #328
* Add API to check if message is active (non-blocking only) by @dgarske in #329
* Fix configure warnings by @embhorn in #330
* Support MQTTv5 in AWS example by @embhorn in #332
* Zephyr port by @julek-wolfssl in #333
* Improve example headers and small sanitizer fixes by @lealem47 in #334
* Adding in STM32CubeIDE support by @lealem47 in #335
* Add dynamic property support by @embhorn in #336

### v1.15.1 (3/14/2023)
* Fix to protect read from client->write.len, which resolve edge case issue
  when using multi-threading. (PR #318 and PR #319)

### v1.15.0 (12/30/2022)
* Fix for --with-libwolfssl-prefix config option #312
* Call disconn CB with MQTTv5 reason code #314
* Add github CIFuzz action by @DavidKorczynski #315
* Fix SN disconnect with sleep should not use CB #294

### v1.14.1 (8/31/2022)
* Fix cmake builds #307
* Fix for Vcpkg on Windows not getting wolfssl/options.h included #305

### v1.14.0 (7/25/2022)
* Support post-quantum KYBER_LEVEL1 and P256_KYBER_LEVEL1 with FALCON_LEVEL1 
  in wolfMQTT. by @anhu #300
* Add WOLFMQTT_USE_CB_ON_DISCONNECT for CB on client disconnect by @embhorn 
  in #302
* Fix to release connect ack props by @embhorn in #301

### v1.13.0 (5/4/2022)
* Fix windows build test by @lealem47 in #286
* Add async support for wolfMQTT by @dgarske in #285
* Allow message callback to set reason code for response by @embhorn in #287
* Porting WolfMQTT to NUCLEO F767ZI  with TOPPERS OS by @nekoman2187 in #254
* Fixes for non-blocking state and large payload by @dgarske in #288
* Add CMake support build by @elms in #292
* Fix for improper reset of shared object by @dgarske in #291
* cmake: add example option and fixes for vcpkg by @elms in #293
* cmake: shared/static lib build and cleanup by @elms in #295
* Fix example msg cb print error @embhorn in #298

### v1.12 (2/23/2022)
* Allow MqttClient_WaitType to return MQTT_CODE_CONTINUE with MT (PR #283)
* Fix decoding user property and add example (PR #282)
* Fix issue with MqttClient_Publish_WriteOnly not waiting properly for ACK
  (PR #281)
* Fix MQTTv5 disconnect with props (PR #279)
* Add new publish write only API for multi-threading (PR #277)
* Fix for multithreaded cancel (PR #276)
* MQTT-SN Add disconnect_cb when disconnect recv from broker; Fix PUB ACK
  return status handling (PR #274)
* Enable TLS1.3 in examples (PR #273)
* Adding windows github actions build test (PR #272)

### v1.11 (1/7/2022)
* Return correct error code in SN_Client_Connect (PR #268)
* Removing unsupported TLS and SNI options in sn-client (PR #266)
* Fixes for multithreading with non-blocking (PR #252)
* Doxygen work removing depreciated command and fixing other warnings (PR #264)
* Fix overwriting TLS error in connect (PR #259)
* Add GitHub Actions (PR #256 #260 #263)
* Fix wm_Sem on Windows (PR #255 #261)
* Fix scripts for host without mosquitto (PR #257 #265)
* Trim whitespace and convert tab to spaces (PR #251)
* Refactor of write length (PR #250)
* Fixes for publish edge cases (PR #248)
* Remove unused sub_id element, add support for local test broker (PR #249)
* Fix to make sure MqttClient_DecodePacket called in all cases (PR #246)

* Known bug with multithread and without nonblocking enabled in this release.

### v1.10 (11/2/2021)
* Improve FALL_THROUGH macro logic for XC32. (PR #227)
* Fix potential NULL printf in MqttSocket_Connect with verbose debug enabled. (PR #229)
* Fix non-block chunked transfer. (PR #230)
* Fix QoS responses (PR #231, 240)
* Fix MQTTv5 property handling (PR #232, 233, 234, 236, 238, 241)
* Fix fuzzing test issues (PR #242)

### v1.9 (07/16/2021)
* Fixes for Sensor Network client (PR #204, 214, 219)
* Fixes for non-blocking (PR #205)
* Fixes for multithread (PR #207, 209, 211, 218)
* Fix for MQTTv5 publish response handling (PR #224, 220)
* Fix subscribe return code list (PR #210)
* Fix switch statement fallthrough on other toolchains (PR #225)
* Add HiveMQ Cloud capability with SNI feature (PR #222)
* Add ability to publish files from example client, fix chunked publish (PR# 223)

### v1.8 (02/19/2021)
* Fixes for non-blocking in WIN32 and large payload (PR #202)
* Make TLS IO callback functions public (PR #201)
* Bug fixes (PR #186, 188, 189, 193, 196, 199, 200)
* Update default test broker (PR #194)
* MQTT-SN fixes for multithread and register topic name (PR #185, 190)
* Fix multi-thread to use pthread mutex with condition (PR #183)
* Fix for WIN thread create macro (PR #182)
* Use options.h with Arduino build (PR #181)
* Use MqttClient_Ping_ex instead of MqttClient_Ping in examples (PR #179)
* Fixes for building with MinGW (PR #178)
* MQTT-SN support for multithread (PR #176)
* TLS mutual auth in client examples (PR #175)
* MQTT-SN feature enhancements (PR #173)
* Add runtime message option to client (PR #171)

### v1.7 (08/21/2020)

* Fix for publish with short topic name and example. (PR #169)
* Add MqttProps_ShutDown(). Fix MqttProp leaks(PR #167)
* Multithread fixes. (PR #166)
* Fix buffer overrun in strcpy(). Fix logic around getaddrinfo(). (PR #165)
* Fix MqttClient_WaitType for nonblock mode. (PR #164)
* Change anon union for ARMv6 error. (PR #163)
* Fix for publish large payload. (PR #162)
* Fixing LWT prop and allow null LWT. (PR #161)
* Fix for receive timeout in mqttsimple example. (PR #158)

### v1.6 (04/24/2020)

* Fixes to improve buffer size checking when using a small tx or rx buffer. (PR #137)
* Fix for MQTT v5 issue with using wrong property free. (PR #152)
* Refactor of the thread locking to use binary semaphore, which resolves issue with thread synchronization. (PR #146)
* Improved multi-thread example exit (ctrl+c). Use internal pipe to wake "select()" and use semaphore signal to "wake" ping thread. (PR #146)
* Adjust multi-threading use case to use separate thread for ping keep-alive. (PR #146)
* Added simple standalone MQTT client example. (PR #138)
* Added include for "user_settings.h" when `WOLFMQTT_USER_SETTINGS` is defined. (PR #138)
* Added broker compatibility list (PR #145)
* Added protocol version API's. (PR #152)
* Added multithread example for Windows and Visual Studio. (PR #146)
* Made protocol level a run time option (PR #147)
* Remove obsolete "sched_yield" call. (PR #146)
* Remove deprecated call to `wolfSSL_set_using_nonblock()` (PR #148)
* Sync automake fixes from wolfSSL to wolfMQTT. (PR #150)
* Moved `MAX_PACKET_ID` to library. (PR #138)

### v1.4 (12/27/19)

* Fixes for non-blocking and multi-threading edge cases. (PR #130)
    - Improved logic for processing objects from different threads.
    - Improved network connect/read to handle runtime option for block/non-block.
    - Improved examples to support adding random hex string to client_id and topic name when "-T" option is used.
    - Fix for test scripts to check non-zero return code.
    - Enabled the mqttclient, multithread and wiot examples when non-blocking is enabled.
    - Added encode debug log messages when `WOLFMQTT_DEBUG_CLIENT` is defined.
    - Added thread logging when `WOLFMQTT_DEBUG_THREAD` is defined with multi-threading support enabled.
* Fixes for Visual Studio project (PR #122)
    - Improvements to catch use of socket file descriptor before its been created/opened.
    - Improved handling for Windows socket want write.
    - Added library references to wolfSSL project.
    - Adjusted include to have IDE/WIN for user_settings.h.
* Fixes for Visual Studio conversion warning (PR #128)
* Fix visibility warnings in Cygwin (PR #127)
* Fix global declaration conflicts for CentOS (PR #133)
* Fix Microchip Harmony for `mqtt_socket.c` with non-blocking and `errno.h`  (PR #135)
* Fix to not return from `MqttClient_WaitMessage` if response from another thread (PR #129)
* Refactor of the multi-threading code to better handle edge case and state for non-blocking (PR #126)
    - Fixes for multi-thread handling of ack's when processing.
    - Refactor to use `stat` from own struct, not shared `msg->stat`.
    - Eliminated use of `client->msg` except for `MqttClient_WaitMessage`.
    - Fixes to restore "state" after performing MqttClient operation.
    - Refactor of publish read and write payload.
    - Improvements to multithread example.
    - Refactor of the SN code to support new object type and unique state for future multi-thread support.
    - Added build option `TEST_NONBLOCK` to force testing non-blocking edge cases.
    - Fix for fwpush getting stuck in stop loop on Ctrl+c exit.
* Update Azure login and default broker (PR #131)

### v1.3 (08/01/19)

* Fix `fwpush` example to use filename option `-f`. (PR #117)
* Added multiple thread support using `--enable-mt` or `WOLFMQTT_MULTITHREAD`. (PR #115)
* Fix for `MQTT_DATA_TYPE_BINARY` data length encoded twice. (PR #112)
* Fix to clear local structures for subscribe and unsubscribe ACK's. (PR #112)
* Fix for `SN_Encode_Unsubscribe` using wrong data type for topic name ID. (PR #110)
* Add `WOLFSSL_USER_SETTINGS` to VS project files. (PR #109)
* Fixes for using RTCS in `mqttnet.c` socket example code. (PR #108)
* Fix MQTT-SN decode publish parsing and QoS2 response. (PR #107)
* Make MqttSocket_TlsSocket callbacks public. (PR #104)
* Improved the disconnect network error callback example. (PR #102)
* Add MQTT context information to socket callback examples. (PR #101)
* Initialize subscribe state to `MQTT_MSG_BEGIN`. (PR #99)
* Fix for Harmony possible circular include issue. (PR #98)

### v1.2 (11/07/18)

* Added MQTT Sensor Network (SN) client support (`--enable-sn` or `WOLFMQTT_SN`). (PR #96)
* Added MQTT v5.0 support with (`--enable-mqtt5` or `WOLFMQTT_V5`). (PR #87)
* Added property callback support (MQTT v5.0 only). Enabled with `--enable-propcb` or `WOLFMQTT_PROPERTY_CB`). (PR #87)
* Fix for Harmony NetConnect function incorrectly checking `EWOULDBLOCK`. Fixes issue #88. (PR #89)
* Fix to reset the TLS ctx and ssl pointers when they have been free'd. (PR #85)
* Add way to pass custom context to the wolfMQTT TLS verify callback example `mqtt_tls_verify_cb`. PR #94)
* Create nonblocking mqttclient example `./examples/nbclient/nbclient`. (PR #93)
* Add support for publishing in smaller chunks using new API `MqttClient_Publish_ex`. (PR #92)
* Added simplified Microchip Harmony wolfMQTT network callback example. (PR #83)

### v1.1 (06/21/18)
* Fixed case when `use_tls` was requested but TLS feature not compiled in. (PR #57)
* Fixed non-blocking issue that caused out of buffer error if not all of packet were received. (PR #65)
* Fixed non-blocking mode issue that was sending multiple connect requests for examples. (PR #65)
* Fixed non-blocking issue with ping keep alive in examples. (PR #68)
* Fixed the Arduino example with `ENABLE_MQTT_TLS` defined (PR #78)
* Added support for FreeRTOS TCP in wolfMQTT. (PR #58)
* Added `README.md` section for building wolfMQTT. (PR #63)
* Added new option to enable verbose logging `./configure --enable-debug=verbose`. (PR #65)
* Added support for disconnect callback using `WOLFMQTT_DISCONNECT_CB` or `./configure --enable-discb`. (PR #69)
* Added `WOLFMQTT_LOCAL` to internal API's for hidden visibility. (PR #73)
* Added include for `wolfmqtt/options.h`. (PR #79)
* Added IBM Watson IoT example (see `./examples/wiot/wiot`). (PR #80)
* Updated the autoconf M4 files and added generation of `./configure` options to `wolfmqtt/options.h`. (PR #71)
* Improved the message callback to support a custom context per message. (PR #62)
* Improved the non-blocking unsubscribe handling in mqttclient example for timeout. (PR #65)

### v1.0 (04/03/18)
* Fixed `MqttClient_WaitMessage` to use provided `timeout_ms` arg. With TLS enabled it was using the `MqttClient_Init` `cmd_timeout_ms` arg. Thanks PeterL for that report.
* Fixed cast warnings when building with Visual Studio.
* Cleanup socket code to use existing `SOCK_CLOSE` for `NetDisconnect`.
* Cleanup to move the `sockRc` into the `MqttTls` struct, since it only applies when TLS is enabled.
* Added configure option to disable error strings for reduced code size (`./configure disable-errorstrings` or `#define WOLFMQTT_NO_ERROR_STRINGS`).
* Added support for ChibiOS.

### v0.14 (11/22/17)
* Fixed non-blocking connect to check for `EINPROGRESS` for all platforms (not just Harmony).
* Fixed buffer overflow position check on read/write.
* Fixed typo on internal packet function `MqttDecode_ConnectAck`.
* Fixed the socket close for Harmony to use `closesocket`.
* Fixed non-blocking connect where `WOLFMQTT_NO_STDIO` is defined.
* Fixed GCC 7's new fall-through check.
* Added check for EAGAIN in non-blocking mode (was only EWOULDBLOCK).
* Added non-blocking support for write operations when `WOLFMQTT_NONBLOCK` is defined.
* Added support for DH and setting the default minimum key bits.
* Added support for keep-alive ping when using non-blocking mode.
* Improvements to example TLS callback handling of return code failures.
* Improvements and fixes to Visual Studio projects.
* Enhancement to adjust wolfSSL options.h include based on `WOLFSSL_USER_SETTINGS`.

### v0.13 (05/10/17)
* Fixed issue with `msg->stat` in non-blocking.
* Fixed Arduino library build.
* Fixed examples with non-blocking (--enable-nonblock).
* Enhancement to pass network callback return codes through context when using TLS.
* Added option to disable the blocking timeouts for `select()` using `--disable-timeout` (or `WOLFMQTT_NO_TIMEOUT`).
* Added option to disable STDIN/fgets capture for examples using `--disable-stdincap` (or `WOLFMQTT_NO_STDIN_CAP`)
* Refactor to use new `MQTT_CODE_STDIN_WAKE` return code for examples using STDIN to send publish messages (normal blocking mode only).

### v0.12 (12/20/16)
* Fixes issue with read timeout in non-blocking mode with TLS enabled being treated as socket error.
* Fixed issue with “msg->stat” not getting reset on failure or timeout.
* Fix to not link libwolfssl with ./configure --disable-tls.
* Added AWS IoT Example and test script.

### v0.11 (11/28/16)
* Fix for building MQTT client example without the wolfSSL headers present.
* Fix for Microchip Harmony IP check so it works with non 192 subnets.

### v0.10 (09/26/16)
* Enabled big endian support.
* Fixes for building with Visual Studio.

### v0.9 (08/22/16)
* Added Microchip Harmony support (see new readme in `IDE/Microchip-Harmony/README.md`).
* Added non-blocking mode `--enable-nonblock` or `WOLFMQTT_NONBLOCK`, which uses new `MQTT_CODE_CONTINUE` response code.
* Added `scripts/azureiothub.test`.
* Added `./commit-tests.sh` for testing all configurations.
* Added git pre-commit hook to run `commit-tests.sh`.
* Combined duplicate code in the examples into `examples/mqttexample.c`.
* Examples now use `MQTTCtx` structure as argument for tracking info/state.

### v0.8 (06/13/16)
* Fixed stdin capture bug and improved signal (ctrl+c) handling.
* Added Azure IoT hub MQTT client example.
* Added support for MQX / RTCS.
* Added "--disable-tls" and "--disable-examples" configure options.
* Added comment about max packet size.
* Added example for how to load a client certificate to mqttclient example.
* Added return code for firmware and azure examples that are not compiled in due to older / incompatible version of wolfSSL.
* Moved the support for custom printf/line endings into the mqtt_types.h for use throughout the project.
* Updated README.md with information about the examples.

### v0.6 (03/18/2016)
* Fixes to support MinGW compiler.
* Fixed bug with include of the wolfSSL include of options.h.
* Fix to properly handle negative return code from wc_SignatureGetSize.
* Added Arduino IDE example in `IDE/ARDUINO`. See `IDE/ARDUINOREADME.md` for details.
* Added example UART interface for wolfMQTT. See `examples/mqttuart.c`.
* Added the ability to pass additional arguments to the scripts. Example: `./scripts/client.test "-h localhost"`

### v0.5 (01/27/2016)
* Fixed build error when using older wolfSSL in firmware examples.
* Updated the get error string function in `mqtt_socket.c` from `wc_GetErrorString` to `wolfSSL_ERR_reason_error_string` so both wolfSSL and wolfCrypt error codes are resolved.
* Added `-n <str>` option so a custom topic name can be used.
* The mqttclient example now listens to stdin and will send a publish message with the data entered on the console when end-of-line (return) is detected (Linux only).
* Added keep-alive ping to the mqttclient and fwclient examples.
* Moved the TLS callback prior to the `client->tls.ctx` creation, allowing the callback function to implement its own client method cert verification.
* Enhanced `MqttClient_WaitMessage` so it will return if we get a message, not just on timeout
* Added make check/test scripts (scripts/client.test and scripts/firmware.test) to validate client TLS (with and without) plus QoS 0-2 levels and the firmware update example.
* Adjusted the example include paths for more flexibility.
* Added new `-T` option for using examples to test.
* Added new `-C` option to allow custom command timeout.
* Combined duplicate example code into new header `mqttexample.h`.
* Added a PRINTF helper macro to the examples for easier porting.
* Added better error trapping in examples so return code is populated for testing.
* Changed the example test functions to return int.

### v0.4 (12/30/2015)
* Fixed bug with subscribe not populating acknowledgment return code(s) properly.
* Fixed build error if using wolfSSL 3.7.1 or older due to missing signature.c/.h wrappers. This fix disables the firmware examples if the wolfSSL version isn't greater than 3.7.1.
* Fix to ensure `topic_name` pointer is reset when publish callback message is not new `msg_new = 0`.
* Fixes to suppress possible warning "Value stored to [] is never read".
* Fixed firmware example to trap case where file isn't found.
* Fixed possible ./autogen.sh error with missing "config.rpath".
* Fixed Windows issue with SetConsoleCtrlHandler incorrectly reporting error.
* Fixed issue with Visual Studio 2015 wolfssl.lib reference.
* Fixed build errors with G++ (./configure CC=g++).
* Fixed "FirmwareHeader" to use WOLFMQTT_PACK macro.
* Added helper macro's and comments for topic names/filters.
* Added TLS certification verification reference implementation to examples.
* Updated the topic names in examples to use "wolfMQTT/example/".
* Added QoS level to example console output.
* Added memset to initialize some of the example stack variables.
* Removed the LWT from the firmware examples.
* Added retain flag "-r" option on the "fwpush" example.
* Updated the examples to use macros for all memory and string functions, so they are more portable.
* Added Visual Studio projects for "fwpush" and "fwclient".

### v0.3 (11/18/2015)
* Fixes bug with first byte of payload being null'd if QoS level was 0.
* Fixed issue with stdint types (uint#_t) being used.
* Fixes for remaining length encoding/decoding for large packets.
* Added support for large payloads using new message callback flags `msg_done` and `msg_new` along with MqttMessage `buffer_pos` and `buffer_len`.
* Added example for secure firmware upgrade. Uses the MQTT client library to push a signed payload `fwpush` to a broker, then uses another client `fwclient` to receive the signed payload and verify its signature using a provided public key.

### v0.2 (11/06/2015)
* Fixes to handle receival of publish and QoS messages while performing packet writes/waits.
* Added support / tested with Windows.
* Added Visual Studio 2015 solution and projects.
* Added support / tested with FreeRTOS and Lwip.
* Fixes for compiler warnings.

### v0.1 (10/26/15)
* Initial release with support for MQTT v3.1.1, QoS 0-2, TLS and example client.
