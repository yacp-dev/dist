#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Proton::qpid-proton" for configuration "RelWithDebInfo"
set_property(TARGET Proton::qpid-proton APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(Proton::qpid-proton PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libqpid-proton.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygqpid-proton-11.dll"
  )

list(APPEND _cmake_import_check_targets Proton::qpid-proton )
list(APPEND _cmake_import_check_files_for_Proton::qpid-proton "${_IMPORT_PREFIX}/lib/libqpid-proton.dll.a" "${_IMPORT_PREFIX}/bin/cygqpid-proton-11.dll" )

# Import target "Proton::core" for configuration "RelWithDebInfo"
set_property(TARGET Proton::core APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(Proton::core PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libqpid-proton-core.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygqpid-proton-core-10.dll"
  )

list(APPEND _cmake_import_check_targets Proton::core )
list(APPEND _cmake_import_check_files_for_Proton::core "${_IMPORT_PREFIX}/lib/libqpid-proton-core.dll.a" "${_IMPORT_PREFIX}/bin/cygqpid-proton-core-10.dll" )

# Import target "Proton::proactor" for configuration "RelWithDebInfo"
set_property(TARGET Proton::proactor APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(Proton::proactor PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libqpid-proton-proactor.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygqpid-proton-proactor-1.dll"
  )

list(APPEND _cmake_import_check_targets Proton::proactor )
list(APPEND _cmake_import_check_files_for_Proton::proactor "${_IMPORT_PREFIX}/lib/libqpid-proton-proactor.dll.a" "${_IMPORT_PREFIX}/bin/cygqpid-proton-proactor-1.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
