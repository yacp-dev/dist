#ifndef PROTON_SESSION_HPP
#define PROTON_SESSION_HPP

/*
 *
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 *
 */

#include "./fwd.hpp"
#include "./internal/export.hpp"
#include "./endpoint.hpp"
#include "./receiver.hpp"
#include "./sender.hpp"

#include <string>

/// @file
/// @copybrief proton::session

struct pn_session_t;

namespace proton {

/// A container of senders and receivers.
class
PN_CPP_CLASS_EXTERN session : public internal::object<pn_session_t>, public endpoint {
  public:
    /// @cond INTERNAL
    PN_CPP_EXTERN session(pn_session_t* s) : internal::object<pn_session_t>(s) {}
    /// @endcond

  public:
    /// Create an empty session.
    session() : internal::object<pn_session_t>(0) {}

    PN_CPP_EXTERN ~session();

    PN_CPP_EXTERN bool uninitialized() const;
    PN_CPP_EXTERN bool active() const;
    PN_CPP_EXTERN bool closed() const;

    PN_CPP_EXTERN class error_condition error() const;

    /// Open the session.
    PN_CPP_EXTERN void open();

    /// @copydoc open
    PN_CPP_EXTERN void open(const session_options &opts);

    PN_CPP_EXTERN void close();
    PN_CPP_EXTERN void close(const error_condition&);

    /// Get the container for this session.
    PN_CPP_EXTERN class container &container() const;

    /// Get the work_queue for the session.
    PN_CPP_EXTERN class work_queue& work_queue() const;

    /// Get the connection this session belongs to.
    PN_CPP_EXTERN class connection connection() const;

    /// Open a sender for `addr`.
    PN_CPP_EXTERN sender open_sender(const std::string &addr);

    /// @copydoc open_sender
    PN_CPP_EXTERN sender open_sender(const std::string &addr, const sender_options &opts);

    /// Open a receiver for `addr`.
    PN_CPP_EXTERN receiver open_receiver(const std::string &addr);

    /// @copydoc open_receiver
    PN_CPP_EXTERN receiver open_receiver(const std::string &addr, const receiver_options &opts);

    /// The number of incoming bytes currently buffered.
    PN_CPP_EXTERN size_t incoming_bytes() const;

    /// The number of outgoing bytes currently buffered.
    PN_CPP_EXTERN size_t outgoing_bytes() const;

    /// Return the senders on this session.
    PN_CPP_EXTERN sender_range senders() const;

    /// Return the receivers on this session.
    PN_CPP_EXTERN receiver_range receivers() const;

    /// Set user data on this session.
    PN_CPP_EXTERN void user_data(void* user_data) const;

    /// Get user data from this session.
    PN_CPP_EXTERN void* user_data() const;

    /// **Unsettled API** - Declare a new local transaction on this session.
    ///
    /// When the transactions coordinator accepts, the application receives
    /// messaging_handler::on_session_transaction_declared. A rejected declare is reported as
    /// messaging_handler::on_session_transaction_error.
    ///
    /// @see transactions_page
    PN_CPP_EXTERN void transaction_declare();

    /// @copydoc transaction_declare
    /// **Unsettled API** - Declare using transaction options (see proton::transaction_options).
    PN_CPP_EXTERN void transaction_declare(const transaction_options& opts);

    /// **Unsettled API** - Commit the currently declared transaction.
    ///
    /// Outcome is delivered asynchronously via messaging_handler::on_session_transaction_committed
    /// or messaging_handler::on_session_transaction_aborted.
    PN_CPP_EXTERN void transaction_commit();

    /// **Unsettled API** - Abort the currently declared transaction.
    ///
    /// This completes with messaging_handler::on_session_transaction_aborted (see also
    /// transaction_commit()).
    PN_CPP_EXTERN void transaction_abort();

    /// **Unsettled API** - Return true if a transaction is currently declared.
    PN_CPP_EXTERN bool transaction_is_declared() const;

    /// **Unsettled API** - Return the identifier of the current transaction.
    ///
    /// There will be a valid transaction id from the tranacrtion declared callback until after any transaction
    /// dicharge callback.
    PN_CPP_EXTERN binary transaction_id() const;

    /// **Unsettled API** - Return the error condition associated with transaction.
    PN_CPP_EXTERN error_condition transaction_error() const;

    /// @cond INTERNAL
    friend class internal::factory<session>;
    friend class sender;
    friend class session_iterator;
    /// @endcond
};

/// @cond INTERNAL

/// An iterator of sessions.
class session_iterator : public internal::iter_base<session, session_iterator> {
  public:
    explicit session_iterator(session s = nullptr) : internal::iter_base<session, session_iterator>(s) {}

    /// Advance to the next session.
    PN_CPP_EXTERN session_iterator operator++();
};

/// A range of sessions.
typedef internal::iter_range<session_iterator> session_range;

/// @endcond

} // proton

#endif // PROTON_SESSION_HPP
