#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Proton::cpp" for configuration "RelWithDebInfo"
set_property(TARGET Proton::cpp APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(Proton::cpp PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libqpid-proton-cpp.dll.a"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELWITHDEBINFO "Proton::core;Proton::proactor"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygqpid-proton-cpp-12.dll"
  )

list(APPEND _cmake_import_check_targets Proton::cpp )
list(APPEND _cmake_import_check_files_for_Proton::cpp "${_IMPORT_PREFIX}/lib/libqpid-proton-cpp.dll.a" "${_IMPORT_PREFIX}/bin/cygqpid-proton-cpp-12.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
