# SNAPD_INCLUDE_DIRS - The snapd-qt include directories
# SNAPD_LIBRARIES - The libraries needed to use snapd-qt

set(SNAPD_LIBRARIES /usr/lib/libsnapd-qt.so)
set(SNAPD_INCLUDE_DIRS /usr/include/snapd-qt/)

add_library(Snapd::Core SHARED IMPORTED)
set_target_properties(Snapd::Core PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES "Qt5::Core"
  IMPORTED_LOCATION "${SNAPD_LIBRARIES}"
  IMPORTED_SONAME "libsnapd-qt.so"
  )

set_property(TARGET Snapd::Core PROPERTY INTERFACE_INCLUDE_DIRECTORIES ${SNAPD_INCLUDE_DIRS})
