# Apache Thrift Release Management

Instructions for preparing and distributing a release of Apache Thrift are fairly complex.  These procedures are documented here, and we're working to automate as much of this as possible.  There are few projects like ours that integrate with 28 programming languages.  Given the extreme number of package management systems that Apache Thrift integrates with (compared to perhaps any), part of the burden of releasing Apache Thrift is to manually package and upload some of these [language-specific packages](http://thrift.apache.org/lib).

It is important to note here that Apache Thrift is designed for version interoperability, so one can use a version 0.7.0 client with a 0.12.0 server.  A particular version number does not make any guarantees as to the features available in any given language.  See the [Language Feature Matrix](https://github.com/apache/thrift/blob/master/LANGUAGES.md) to learn more.

## Concepts

### Versioning

Apache Thrift and the vast majority of package management systems out there conform to the [SemVer 2.0](https://semver.org/spec/v2.0.0.html) version numbering specification.  Apache Thrift uses the following versioning rules:

- *major* is currently always zero;
- *minor* is increased for each release cycle;
- *patch* is increased for patch builds between release cycles to address critical defect, security, or packaging issues

Further, if there are only packaging changes for a single third-party distribution point to correct an issue, the major.minor.patch may remain the same while adding a suffix compatible with that distribution point, for example, "0.12.0.1" for nuget, or "0.12.0-1" for maven.

#### External Package Patches

It is common to have language-specific critical defects or packaging errors that need to be resolved between releases of Apache Thrift.  The project handles these on a case-by-case basis for languages that have their own [package management systems](http://thrift.apache.org/lib).  When a language-specific patch is made, the patch level of the distribution pushed to the external package manager is bumped.

 As such, there may be cases between Apache Thrift releases where there are (for example) a `0.12.1` and `0.12.2` version of a Haskell Hackage package, and perhaps also a `0.12.3` version of a dlang dub package.  You will not find a tag or an official project release in these cases, however, the code changes will be reflected in the release branch and in master.  In these cases we would not release a version of Apache Thrift nor would we refresh all the external language packages.

#### Version in the master branch

The master branch will always contain the next anticipated release version.  When a release cycle begins, a branch is cut from master.  The release branch will already have all of the correct versions, and therefore release branches can be easily merged back into master.  (This was not true of releases before 0.12.0).

### Code Repository

The authoritative repository for Apache Thrift is stored in [GitHub](https://github.com/apache/thrift).  It is mirrored by [GitBox](https://gitbox.apache.org/repos/asf?p=thrift.git).

### Branches

All code (submitted via pull request or direct push) is committed to the `master` branch.  Former Apache Thrift release branches up to and including 0.23.0 were named `<version>`, for example in version `0.12.0` there is a branch named the same. Releases beyond 0.23.0 will have a branch named `release/<version>`.

### Tags

Up to version `0.12.0` each release of Apache Thrift was tagged with a `<version>` tag.  Starting with the `0.12.0` release, each release of Apache Thrift will be tagged with a `v<version>` tag to satisfy external package management tools (such as ones for dlang and golang).  For example the tag of version `0.12.0` is `v0.12.0`.

## Release Procedures

### Release Schedule

Apache Thrift has no official release schedule, however the project aims to release at least twice per year.

A complete release cycle will take about 1 week to complete, if things go well, with half of that time waiting for a vote.

### Release Manager

Before a release cycle begins, someone must nominate themselves on the development mailing list as the release manager for that release.  In order to be a release manager you must meet the following criteria:

1. You are a [member](http://people.apache.org/phonebook.html?pmc=thrift) of the Apache PMC group.
1. Your profile at https://id.apache.org/ is valid and contains a PGP key.  If it does not, see the [Apache OpenPGP Instructions](https://www.apache.org/dev/openpgp.html).  If your PGP private key creation seems to hang indefinitely while creating entropy, try these fixes:
    - Generate disk I/O with: `dd if=/dev/sda of=/dev/zero`
    - Install the `rng-tools` package.
1. Your PGP key is visible in the [Apache Committer Keys](http://people.apache.org/keys/committer/) for code signing.  This list is updated periodically from your Apache ID (see previous step).
1. You have read and agree with the contents of the [ASF Release Distribution Policy](https://www.apache.org/dev/release-distribution.html).
1. You have access and the ability to use subversion.  All distribution artifacts are released through a subversion commit.
1. You can build in the Linux Docker Container, and you have Visual Studio 2017.
1. You have sufficient time to complete a release distribution.

### Release Candidate

All Apache Thrift releases go through a 72-hour final release candidate voting procedure.  Votes from members of the Apache Thrift PMC are binding, and all others are non-binding.  For these examples, the `master` branch is at version 1.0.0 and that is the next release.

1. Scrub the Apache Jira backlog.  There are a couple things to do:

    1. [Open Issues without a Component](https://issues.apache.org/jira/issues/?filter=-1&jql=project%20%3D%20THRIFT%20and%20status%20!%3D%20Closed%20and%20component%20is%20empty) - make sure everything has an assigned component, as the release notes are grouped together by language.

    1. [Open Issues with a Fix Version](https://issues.apache.org/jira/issues/?filter=-1&jql=project%20%3D%20THRIFT%20and%20status%20in%20(OPEN%2C%20%27IN%20PROGRESS%27%2C%20REOPENED)%20and%20fixVersion%20is%20not%20empty) - these will be issues that someone placed a fixVersion on in Jira, but have not been resolved or closed yet.  They are likely stale somehow.  Resolutions for these issues include resolving or closing the issue in Jira, or simply removing the fixVersion if the issue hasn't been fixed.

    1. [Open Blocking Issues](https://issues.apache.org/jira/issues/?filter=-1&jql=project%20%3D%20THRIFT%20and%20priority%20in%20(blocker)%20and%20status%20not%20in%20(closed,resolved)%20order%20by%20component%20ASC) - blocking issues should block a release.  Scrub the list to see if they are really blocking the release, and if not change their priority.

    1. [Open Critical Issues](https://issues.apache.org/jira/issues/?filter=-1&jql=project%20%3D%20THRIFT%20and%20priority%20in%20(critical)%20and%20status%20not%20in%20(closed,resolved)%20and%20type%20not%20in%20(%22wish%22)%20order%20by%20component%20ASC) - this list will end up in the known critical issues list in the changes file.  Scrub it to make sure everything is actually critical.

    It is healthy to scrub these periodically, whether or not you are making a new release.

1. Check that the version number in the `master` branch matches the version number of the upcoming release.  To check the `master` branch version, run:

    ```bash
    thrift$ grep AC_INIT configure.ac | cut -d'[' -f3 | cut -d']' -f1
    1.0.0
    ```

    If it does not match (this should be extremely rare), you need to submit a pull request setting the `master` branch to the desired version of the upcoming release.  In the following example, we prepare to commit a branch where the version number is changed from `1.0.0` to `1.1.0`:

    ```bash
    thrift$ git checkout -b fix-version-for-release
    thrift$ build/veralign.sh 1.0.0 1.1.0
    # check to see if any of the manually modified files needs changes
    thrift$ git push ... # make a pull request
    ```

1. Create a release branch for the release, in this example `1.0.0`:

    ```bash
    thrift$ git checkout master
    thrift$ git pull
    thrift$ git checkout -b "release/1.0.0"
    thrift$ git push
    ```

    Now there is a `release/1.0.0` branch in GitHub for Apache Thrift.

    By creating a release branch we allow work to continue on the `master` branch for the next release while we finalize this one.  Note that `release/1.0.0` and `master` in this example are now identical, and therefore it is possible to merge the release branch back into `master` at the end of the release!

1. Modify these files manually, inserting the release into them at the appropriate location.  Follow existing patterns in each file:
    - `doap.rdf`
    - `debian/changelog`

1. Generate the content for `CHANGES.md` - this is one of the most time-consuming parts of the release cycle.  It is a lot of work, but the result is well worth it to the consumers of Apache Thrift:

    1. Look at the ["Generate CHANGES draft" action artifact](https://github.com/apache/thrift/actions/workflows/generate-changes.yml) and pick the right branch. If that worked, copy and paste the data into `CHANGES.md` and you're basically done. However, if that did **not** work out, the rest of this shows the old manual method as a fallback:
  
    1. Find all [Issues with fixed in 1.0.0 that are not open](https://issues.apache.org/jira/issues/?filter=-1&jql=project%20%3D%20thrift%20and%20resolution%20%3DFixed%20%20AND%20fixVersion%20%3D%201.0.0%20AND%20status%20!%3D%20Open) (adjust the version in the link to suit your needs).

    1. Export the list of issues to a CSV (Current Fields) and open in Excel (or a similar spreadsheet).

    1. Hide all columns except for the issue id (i.e. THRIFT-nnnn), the component (first one), and the summary.

    1. Sort by component ascending and then by id ascending.

    1. Create a fourth column that will contain the contents of each line that goes into the release notes.  Once you have the formula working in one cell paste it into the other rows to populate them.  Use a formula to get the column to look like this:

        ```vcol
        Issue       Component      Summary     RelNote
        THRIFT-123  C++ - Library  Drop C++03  [THRIFT-123](https://issues.apache.org/jira/browse/THRIFT-3978) - Drop C++03
        ```

        For example, if the row above was row "1" in EXCEL it would look something like:

        ```text
        =CONCAT("[", A1, "]",
                "https://issues.apache.org/jira/browse/", 
                A1, " - ", C1)
        ```

    1. Create a level 3 section in `CHANGES.md` under the release for each component and copy the items from the RelNote column into the changes file.

    1. Find all [Open Critical Issues](https://issues.apache.org/jira/issues/?filter=-1&jql=project%20%3D%20THRIFT%20and%20priority%20in%20(critical)%20and%20status%20not%20in%20(closed,resolved)%20and%20type%20not%20in%20(%22wish%22)%20order%20by%20component%20ASC) and add them to `CHANGES.md` in the list of known critical issues for the release.

1. Commit all changes to the release branch.

1. Generate the source tarball.

    1. On a linux system get a clean copy of the release branch, for example:

        ```bash
        git clone -b "release/1.0.0" git@github.com:apache/thrift.git thrift-1.0.0-src
        ```

    1. In the clean copy of the release branch, build the container image:
	
        ```bash
        docker build -t thrift:jammy build/docker/ubuntu-jammy
        ```
	
    1. Run the container and `make dist`:
	
        ```bash
        docker run -v $(pwd):/thrift/src -it --rm thrift:jammy /bin/bash -c "./bootstrap.sh && ./configure && make dist"
        ```
		
        The result will be a file named `thrift-1.0.0.tar.gz`.  Check the size and make sure it is roughly 4MB.  It could get larger over time, but it shouldn't jump by orders of magnitude.  Once satisfied you can exit the docker container with `exit`.

    1. Validate the contents of the tarball
	
		Unpack the tarball in some empty folder and do a fresh git clone of the branch into another. 
		Now compare both folders and check for any files missing. These need to be added to the appropriate `EXTRA_DIST` 
		makefile section(s). If necessary, commit the changes and repeat generating the source tarball until no more
		differences can be found.

    1. Generate signatures and checksums for the tarball:

        ```bash
        gpg --armor --output thrift-1.0.0.tar.gz.asc --detach-sig thrift-1.0.0.tar.gz
        md5sum thrift-1.0.0.tar.gz > thrift-1.0.0.tar.gz.md5
        sha1sum thrift-1.0.0.tar.gz > thrift-1.0.0.tar.gz.sha1
        sha256sum thrift-1.0.0.tar.gz > thrift-1.0.0.tar.gz.sha256

1. Generate the Windows Thrift Compiler.  The compiler is portable and folks find it useful to be able to download one, especially if they are using third-party distributed runtime libraries for interpreted languages on Windows. It requires Visual C++ Runtime due to ASF regulations.  There are two ways to generate this:

    - Using a Development VM

        1. On a Windows machine with Visual Studio, pull down the source code and checkout the release branch.
        1. Open an x64 Native Tools Command Prompt for VS 2017 and create an out-of-tree build directory.
        1. Install the latest version of cmake.
        1. Install chocolatey and install winflexbison with chocolatey.
        1. Run cmake to generate an out-of-tree build environment:
            ```cmd
            C:\build> cmake ..\thrift -DBISON_EXECUTABLE=c:\ProgramData\chocolatey\lib\winflexbison\tools\win_bison.exe -DFLEX_EXECUTABLE=c:\ProgramData\chocolatey\lib\winflexbison\tools\win_flex.exe -DWITH_SHARED_LIB=OFF -DWITH_CPP=OFF -DWITH_JAVA=OFF -DWITH_HASKELL=OFF -DWITH_PYTHON=OFF -DWITH_C_GLIB=OFF -DBUILD_TESTING=OFF -DBUILD_TUTORIALS=OFF -DBUILD_COMPILER=ON
            C:\build> cmake --build . --config Release
            ```

    - Using [Docker for Windows](../build/docker/msvc/README.md), follow the instructions for building the compiler.
    - In both cases:
        1. Verify that the executable depends only on Windows system DLLs and on the Visual
            C++ runtime, and on nothing else - no Boost, OpenSSL, zlib or libevent:
            ```powershell
            PS C:\thrift> .\build\windows\check-compiler-imports.ps1 -Path C:\install\bin\thrift.exe
            ```
            The same check runs on every push in the `compiler-windows` job of
            [`.github/workflows/cmake.yml`](../.github/workflows/cmake.yml).

            Do **not** build a statically linked compiler to make that list shorter.  The
            project moved away from one deliberately, and the released compiler is expected
            to require the Visual C++ redistributable; the check fails if it does not.
        1. Copy the executable `thrift.exe` to your linux system where the signed tarball lives and rename it to `thrift-1.0.0.exe` (substitute the correct version, of course).
        1. Sign the executable the same way you signed the tarball.
        1. Build the Windows installer from the very same executable:
            ```powershell
            PS C:\thrift> .\build\windows\build-installer.ps1 -Version 1.0.0 -Compiler C:\install\bin\thrift.exe -OutputDir dist
            ```
            This needs [Inno Setup](https://jrsoftware.org/isdl.php) 6.3 or later.  The result is
            `dist\thrift-1.0.0-setup.exe`.

            Rather than installing Inno Setup, you can run the
            [`Windows packages`](../.github/workflows/windows-packages.yml) workflow against the
            release branch from the Actions tab and download its `windows-installer` artifact.  The
            workflow builds the compiler the same way and also installs and uninstalls the result to
            check it.
        1. Copy the installer to your linux system and sign and checksum it the same way you signed
            the tarball and the executable.

1. Upload the release artifacts to the Apache Dist/Dev site.  This requires subversion:

    ```bash
    ~$ mkdir -p dist/dev
    ~$ cd dist/dev
    ~/dist/dev$ svn co "https://dist.apache.org/repos/dist/dev/thrift" thrift
    ~/dist/dev$ cd thrift
    ```

    Copy the tarball, windows compiler executable, and 8 additional signing files into a new directory for the release:

    ``` bash
    ~/dist/dev/thrift$ mkdir 1.0.0-rc0
    # copy the files into the directory
    ~/dist/dev/thrift$ svn add 1.0.0-rc0
    ```

    The layout of the files should match the [current release](https://www.apache.org/dist/thrift/).  Once done, add the release candidate and check it in:

    ```bash
    ~/dist/dev/thrift$ svn status
    # verify everything is correct
    ~/dist/dev/thrift$ svn commit -m "Apache Thrift 1.0.0-rc0 in dist dev" \
        --username <apache-username> --password <apache-password>
    ```

1. Verify the release candidate artifacts are available at:

    [https://dist.apache.org/repos/dist/dev/thrift/](https://dist.apache.org/repos/dist/dev/thrift/)

1. Send a voting announcement message to `dev@thrift.apache.org` following this template as a guide:

    ```code
    To: dev@thrift.apache.org
    Subject: [VOTE] Apache Thrift 1.0.0-rc0 release candidate
    ---
    All,

    I propose that we accept the following release candidate as the official Apache Thrift 1.0.0 release:

    https://dist.apache.org/repos/dist/dev/thrift/1.0.0-rc0/thrift-1.0.0-rc0.tar.gz

    The release candidate was created from the release/1.0.0 branch and can be cloned using:

    git clone -b release/1.0.0 https://github.com/apache/thrift.git

    The release candidates GPG signature can be found at:
    https://dist.apache.org/repos/dist/dev/thrift/1.0.0-rc0/thrift-1.0.0-rc0.tar.gz.asc

    The release candidates checksums are:
    md5: 
    sha1: 
    sha256: 


    A prebuilt Windows compiler is available at:
    https://dist.apache.org/repos/dist/dev/thrift/1.0.0-rc0/thrift-1.0.0-rc0.exe

    Prebuilt Windows compiler GPG signature:
    https://dist.apache.org/repos/dist/dev/thrift/1.0.0-rc0/thrift-1.0.0-rc0.exe.asc

    Prebuilt Windows compiler checksums are:
    md5: 
    sha1: 
    sha256: 


    A Windows installer for the compiler is available at:
    https://dist.apache.org/repos/dist/dev/thrift/1.0.0-rc0/thrift-1.0.0-rc0-setup.exe

    Windows installer GPG signature:
    https://dist.apache.org/repos/dist/dev/thrift/1.0.0-rc0/thrift-1.0.0-rc0-setup.exe.asc

    Windows installer checksums are:
    md5: 
    sha1: 
    sha256: 

    
    The source tree as ZIP file to be published via Github releases:
    https://dist.apache.org/repos/dist/dev/thrift/1.0.0-rc0/thrift-1.0.0-rc0.zip

    ZIP source tree GPG signature:
    https://dist.apache.org/repos/dist/dev/thrift/1.0.0-rc0/thrift-1.0.0-rc0.zip.asc

    ZIP source tree checksums are:
    md5: 
    sha1: 
    sha256: 
    
    The CHANGES list for this release is available at:
    https://github.com/apache/thrift/blob/release/1.0.0/CHANGES.md

    Please download, verify sig/sum, install and test the libraries and languages of your choice.

    I start this voting thread with my own +1 vote.

    This vote will close in 72 hours on 2019-07-06 21:00 UTC

    [ ] +1 Release this as Apache Thrift 1.0.0
    [ ] +0
    [ ] -1 Do not release this as Apache Thrift 1.0.0 because...
    ```

1. If any issues are brought up with the release candidate, you will need to package another and reset the voting clock.

Voting on the development mailing list provides additional benefits (wisdom from [Christopher Tubbs](https://issues.apache.org/jira/browse/THRIFT-4506?focusedCommentId=16791902&page=com.atlassian.jira.plugin.system.issuetabpanels:comment-tabpanel#comment-16791902)):
- It creates a public record for the vote,
- It allows for participation/evaluation from our wider user audience (more diversity in evaluators improves quality), and
- It provides more entry points for potential future committers/PMC members to earn merit through participation.

### Official Release

1. Send a message to `dev@thrift.apache.org` with the voting results.  Use this template as a guide:

    ```code
    To: dev~thrift.apache.org
    Subject: [VOTE][RESULT] Release Apache Thrift 1.0.0
    ---
    All,

    Including my own vote of +1 we have N binding +1 and no -1.
    The vote for the Apache Thrift 1.0.0 release is ***successful***.
    Thank you to all who helped test and verify.
    ```

1. Use svn to checkout the release part of thrift (similar to dev) and copy the files over from dev, matching the previous release structure:

    ```bash
    ~$ mkdir -p dist/release
    ~$ cd dist/release
    ~/dist/release$ svn co "https://dist.apache.org/repos/dist/release/thrift" thrift
    ~/dist/release$ cd thrift
    ~/dist/release/thrift$ mkdir 1.0.0
    ~/dist/release/thrift$ cp -p ../../dev/thrift/1.0.0-rc0/* 1.0.0/
    ~/dist/release/thrift$ svn status
    # verify everything is correct
    ~/dist/release/thrift$ svn commit -m "Apache Thrift 1.0.0 official release" \
        --username <apache-username> --password <apache-password>
    ```

    **NOTE** Once you check-in, you need to wait about a day for all the mirrors to update.  You cannot send the announcement email or update the web site until the mirrors are updated.

1. Create and push a tag for the release, for example "v1.0.0".

    **NOTE:** All new releases must have the "v" prefix to satisfy third-party package managers (dlang dub, golang, etc..)

    **NOTE:** You **should** [sign the release tag](https://git-scm.com/book/en/v2/Git-Tools-Signing-Your-Work).  Since you already have a GPG signing key for publishing the Apache Release, you want to [upload that key to your GitHub account](https://help.github.com/en/articles/adding-a-new-gpg-key-to-your-github-account).  Once the key is known by GitHub you can sign the tag.

    ```bash
    ~/thrift$ # make sure you are on the release branch
    ~/thrift$ git checkout release/1.0.0
    ~/thrift$ git pull
    ~/thrift$ git tag -s v1.0.0 -m "Version 1.0.0"
    ~/thrift$ git push --tags
    ```

    **NOTE:** If you get the error "gpg failed to sign the data" when tagging, try this fix: ```export GPG_TTY=$(tty)```. Alternatively, it may be necessary to specify the ```-u <keyid>``` as an additional argument.

1. Create a new release from the [GitHub Tags Page](https://github.com/apache/thrift/tags).

    Attach the Windows thrift compiler and the Windows installer as binaries here.  Use the very
    files that were voted on and are now under `dist/release`, not a fresh build, so that the
    signatures on `dist.apache.org` cover what people download from GitHub.

    You may find it useful to use the button that automates release notes.

    We have *some* automation in place to get packages published to various package managers.  To leverage this:
    
    - Please first create a "pre-release" and save.
    - Then look at the Actions tab and look for the prereleased action.  It will upload packages to package managers that we have automated and support "test" or "staging" modes.
    - Go check out those packages and make sure they look correct.
    - Come back to the release page and uncheck the "pre-release" checkbox and save.  This will cause another action to get launched that publishes     packages for real.

1. Merge the release branch into master.  This ensures all changes made to fix up the release are in master.

    ```bash
    ~/thrift$ git checkout master
    ~/thrift$ git pull
    ~/thrift$ git merge release/1.0.0
    ```

    The merge of 1.0.0 into master should proceed as a fast-forward since the 1.0.0 release branch.  If there are discrepancies the best thing to do is resolve them and then submit a pull request.  This pull request must be *MERGED* and not *REBASED* after the CI build is successful.  You may want to do this yourself and mark the pull request as `[DO NOT MERGE]`.

1. Update the web site content to include the new release. The repository is located at https://github.com/apache/thrift-website and there are plenty of instructions how to update both staging and live web site. With regard to the release, its actually quite simple: check out the main branch and edit two lines in _config.yml, then commit. The build bot will update staging. After checking everything is right, simply fast-forward "asf-site" to "asf-staging" and push, then production site will automatically get updated as well

1. Update the Docker Official Image packaging. Docker images are convenience artifacts built from the voted ASF source release; they are not ASF release artifacts and must not block the source release announcement if Docker Library review is delayed. Submit Docker updates only after the vote has passed, release artifacts have been promoted, and the web site/download page has been updated.

    The Docker Official Image library tracks the two latest full Apache Thrift releases. Initial restored Docker image maintenance starts with the current release only; older releases are not backfilled. `latest` and unqualified OS aliases move according to the newest retained release and the explicit base metadata in `docker/versions.json`.

    ```bash
    thrift$ cd docker
    thrift/docker$ ./update.sh 1.0.0
    thrift/docker$ ./test.sh --all-platforms
    ```

    `update.sh` records archive.apache.org source URLs so retained Docker tags remain rebuildable; if the archive has not synced yet, wait and rerun it. Commit and push the Docker packaging update to Apache Thrift before generating the Docker Library manifest. Then run `./generate-official-images-library.sh /path/to/official-images/library/thrift` from `thrift/docker`; Docker Library manifests are generated artifacts and are not checked into this repository.

    See [`docker/README.md`](../docker/README.md) for the detailed Docker Official Images workflow. Include Docker image availability in the announcement only if the Docker tags have already landed; otherwise follow up after Docker Official Images publishes them.

1. Make an announcement on the dev@ and user@ mailing lists of the release.  There's no template to follow, but you can point folks to the official web site at https://thrift.apache.org, and to the GitHub site at https://github.org/apache.thrift.

### Release Automation Credentials

Six workflows publish something when a GitHub release is published.  What each
of them needs is described where that package is described, further down; this
is the list, so that it can be checked before a release rather than discovered
during one.

Most of it needs no stored credential.  PyPI, RubyGems, crates.io and NuGet are
all published over **trusted publishing**: the workflow exchanges the run's OIDC
token for a short-lived key, so nothing is kept in the repository.  What has to
exist is a policy on the receiving side naming this repository, the workflow
file and the `release` environment.

| Needed | Kind | Used by | Without it |
|---|---|---|---|
| PyPI trusted publisher for `.github/workflows/pypi.yml` | policy on pypi.org | `pypi.yml` | the publish step fails |
| crates.io trusted publisher for `.github/workflows/release_rust.yml` | policy on crates.io | `release_rust.yml` | the publish step fails |
| RubyGems trusted publisher for `.github/workflows/release_ruby.yml` | policy on rubygems.org | `release_ruby.yml` | the publish step fails |
| NuGet trusted publisher for `.github/workflows/dotnet-tool.yml` | policy on nuget.org | `dotnet-tool.yml` | the publish step fails |
| `NUGET_USER` | repository **variable** | `dotnet-tool.yml` | the publish step fails |
| `WINGET_TOKEN` | repository **secret** | `winget.yml` | nothing is submitted; see below |
| `CHOCO_API_KEY` | repository **secret** | `chocolatey.yml` | nothing is pushed; see below |

All of them are scoped to the `release` [environment](https://docs.github.com/en/actions/how-tos/deploy/configure-and-manage-deployments/manage-environments).
`GITHUB_TOKEN` is provided by Actions itself and needs no setup.

Two notes that are easy to get wrong:

* **`WINGET_TOKEN` has to be a _classic_ personal access token** with the
  `public_repo` scope.  Fine-grained tokens are not supported by `wingetcreate`.
* **A green run does not prove anything was published.**  The WinGet and
  Chocolatey steps deliberately do *not* fail when their secret is missing: they
  build and upload the artifact, emit a warning, and print in the run summary how
  to publish by hand.  That keeps a missing secret from failing a release, but it
  means the run summary is what to read, not the tick.

`CHOCO_API_KEY` is expected to be missing for now - see
[Chocolatey](#chocolatey) below, the package id has not been handed over yet.

### Post-Release

1. Visit https://reporter.apache.org/addrelease.html?thrift and register it.  You will get an automated reminder as the one who committed into dist.  This informs the Apache Board of Directors of releases through project reports.

1. Create a local branch to bump the release number to the next anticipated release:

    ```bash
    ~/thrift$ git checkout -b bump-master
    ~/thrift$ build/veralign.sh 1.0.0 1.1.0
    ```

    The veralign script will set the version number in all of the language packaging files and headers.  You do not need to worry about the manually modified files at this time.  You should however ensure everything is correct by looking at the diff.

1. Create a pull request to advance master to the next anticipated release.

1. In Apache Jira, select all tickets where the fix version is the release and the status is not closed ([example](https://issues.apache.org/jira/issues/?jql=project%20%3D%20THRIFT%20AND%20fixVersion%20%3D%201.0%20%20and%20status%20!%3D%20Closed)) and use the bulk editing tool to close them.
1. **FIXME** Ask someone with admin access to Apache Jira to change the fixVersion in question from unreleased to released, for example:
    https://issues.apache.org/jira/browse/THRIFT-4686

1. Ensure that the [Jira release page](https://issues.apache.org/jira/projects/THRIFT?selectedItem=com.atlassian.jira.jira-projects-plugin%3Arelease-page&status=unreleased) for the version has the same number of issues in the version as issues done, and that there are no issues in progress and no issues to do, and no warnings.  Finally, mark it as released and set the date of the release.
  
* [Report any CVEs](https://apache.org/security/committers.html) that were fixed.  You can email `security@apache.org` if you are not sure if there are any CVEs to report.

#### Windows Packages

The Windows installer is a release artifact like the tarball and the prebuilt
compiler: it is built, signed and voted on before the release, and distributed
from `dist.apache.org`.  The file the vote covers has to carry a release
manager's signature, so it cannot be produced by a workflow at release time.

What *is* automated is building and testing it.  The
[`Windows packages`](../.github/workflows/windows-packages.yml) workflow builds
the compiler on a Windows runner the way a release build does, checks what the
executable imports, packages it with Inno Setup, and then installs and
uninstalls the result to check that the compiler runs, that the install
directory lands on `PATH`, and that uninstalling takes that one `PATH` entry
away and leaves the others alone.  It runs on every pull request that touches
the packaging, and on demand from the Actions tab - which is how you get the
artifact to sign while preparing the release candidate, described above under
*Generate the Windows Thrift Compiler*.

When the GitHub release is published, the same workflow attaches an installer to
it as an unsigned convenience copy, so that the download link is there
immediately.  **One thing is left to do after the release:** overwrite that asset
with the signed file from `dist/release`, so that what people download from
GitHub is what the signatures on `dist.apache.org` cover.

```bash
~$ gh release upload v1.0.0 thrift-1.0.0-setup.exe --clobber --repo apache/thrift
```

##### Chocolatey

The [`Chocolatey`](../.github/workflows/chocolatey.yml) workflow builds the
[Chocolatey](https://chocolatey.org/) package, so that the compiler can be
installed with `choco install thrift`.

The package does not carry the compiler.  It downloads the installer from
`archive.apache.org` and records its checksum, so it can only be built once the
archive has the release - `downloads.apache.org` only carries the current
release, and a package naming it would stop installing at the next one.  If the
release run was too early, run it again from the Actions tab once the archive
has the file.

**Nothing is pushed yet.**  The `thrift` id on the Chocolatey community
repository belongs to a third-party package that last shipped 0.12.0 in February
2019, maintained by `chaliy` and `Lite` from
<https://github.com/Litee/chocolatey-packages>.  Before Apache Thrift can publish
under that id, a maintainer takeover has to be requested from Chocolatey under
their process for abandoned packages:

1. Contact the current maintainers through their Chocolatey profile page and
   allow the response time Chocolatey's policy requires.
1. If there is no response, open a maintainer takeover request with Chocolatey.
1. Once the id has been handed over, add the API key of the account that owns it
   as a secret named `CHOCO_API_KEY` in the `release` environment.

Until then the workflow builds and checks the package, attaches it to the run as
an artifact, and says in its summary that it did not push.  If the takeover is
refused, the free ids `apache-thrift` and `thrift-compiler` are the fallback;
changing the id means editing `build/windows/chocolatey/thrift.nuspec.in` and
the package name the build script expects.

##### WinGet

The [`WinGet`](../.github/workflows/winget.yml) workflow submits the installer to
the [Windows Package Manager](https://github.com/microsoft/winget-pkgs) as
`Apache.Thrift`, so that it can be installed with `winget install Apache.Thrift`.

It runs when the release is published, but it can only succeed once the release
has been promoted to `dist.apache.org` **and** `archive.apache.org` has picked it
up - the manifest points at the archive, because `downloads.apache.org` only
carries the current release and a manifest naming it would stop working at the
next one.  This is the same wait the Docker Official Image update has.

So expect to run it again, from the Actions tab, a while after the release:

1. Actions → `WinGet` → *Run workflow*, entering the released version.
1. The workflow renders the manifests, downloads the published installer to
   compute its checksum, validates the manifests against the WinGet schemas, and
   opens a pull request against `microsoft/winget-pkgs`.
1. Watch that pull request.  Submissions are reviewed, and validation failures
   are reported there.

For the submission step the `release` environment needs a secret named
`WINGET_TOKEN`: a **classic** GitHub personal access token with the `public_repo`
scope.  Fine-grained tokens are not supported by `wingetcreate`.  Without it the
workflow still renders and validates the manifests and leaves them as an
artifact, and says in its summary how to submit them by hand.

#### Third Party Package Managers

See https://thrift.apache.org/lib/ for the current status of each external package manager's distribution.  The information below is from the 0.12.0 release:

  > This section needs to be updated with detailed instructions for each language, or pointers to the README.md files in each language directory with detailed release instructions for the given package management system.

* [dart] Releasing this requires a google account.
  * You will need to install the same version of dart that is used in the docker image.
  * Go into lib/dart and run "pub publish --dry-run" and resolve any warnings.
  * Run "pub publish" and go through the google account authorization to allow it.
* [dlang] Within a day, the dlang dub site https://code.dlang.org/packages/apache-thrift?tab=info
  should pick up the release based on the tag.  No action is needed.
* [npmjs] @jfarrell is the only one who can do this right now.
    https://issues.apache.org/jira/browse/THRIFT-4688
* [nuget] The `.NET tool` GitHub Actions workflow publishes
  [`Apache.Thrift.Compiler`](https://www.nuget.org/packages/Apache.Thrift.Compiler/) when the
  GitHub release is published.  This is the Windows compiler packaged as a .NET tool, so that it
  can be installed with `dotnet tool install --global Apache.Thrift.Compiler`.  It is not the
  `ApacheThrift` runtime library, which is still published by hand following the instructions in
  `ApacheThrift.nuspec`.
  * Before publishing, verify that nuget.org has a trusted publishing policy for the
    `apache/thrift` repository, the `.github/workflows/dotnet-tool.yml` workflow and the
    `release` environment, and that the repository variable `NUGET_USER` names the nuget.org
    account that owns it.
  * A NuGet version can never be replaced.  If a package went out with the wrong contents,
    prepare a new Apache Thrift release rather than trying to overwrite it.
  * Do not publish release candidates or pre-releases; the workflow skips them.
* [perl] A submission to CPAN is necessary (normally jeking3 does this):
  * Checkout the release branch or tag on a linux system.
  * Fire up the docker build container.
  * Run "make clean" and remove any gen-perl directories.
  * Inside `lib/perl` run the script `build-cpan-dist.sh`.
  * Upload the resulting package.  If there's a mistake that needs to be corrected,
    increase the suffix. (_1, _2, ...) and upload another.  You cannot replace a release on CPAN.
* [php] @jfarrell, @bufferoverflow, @jeking3 are the only ones who can do this right now.
  * Once the release is tagged, one just has to hit the "Update" button to pick it up.
* [pypi] The `PyPI publishing` GitHub Actions workflow publishes the Python
  package when the GitHub release is published. It builds the source
  distribution and platform wheel distributions, then publishes them from a
  separate job using PyPI Trusted Publishing.
  * Before publishing, verify that the PyPI `thrift` project has a trusted
    publisher configured for the `apache/thrift` repository, the
    `.github/workflows/pypi.yml` workflow, and the `release` environment.
  * After publishing the GitHub release, verify that the workflow completed and
    that the PyPI release contains both the `.tar.gz` source distribution and
    the `.whl` Linux manylinux, Linux musllinux, macOS, and Windows wheel
    distributions. The manylinux wheels are built on the manylinux2014
    baseline for glibc 2.17+ compatibility.
  * Do not upload release candidates, prereleases, branch builds, nightlies, or
    continuous builds to PyPI.
  * PyPI distribution filenames are immutable. If an artifact was published with
    the wrong contents, prepare a new Apache Thrift release rather than trying
    to replace the existing PyPI file.
* [rust] Any thrift project committer is allowed to upload a new crate.

If you have any questions email `dev@thrift.apache.org`.
