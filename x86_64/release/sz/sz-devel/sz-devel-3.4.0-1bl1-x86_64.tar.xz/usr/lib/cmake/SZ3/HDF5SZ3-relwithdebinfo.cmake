#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "SZ3::hdf5sz3" for configuration "RelWithDebInfo"
set_property(TARGET SZ3::hdf5sz3 APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(SZ3::hdf5sz3 PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libhdf5sz3.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cyghdf5sz3-3.4.dll"
  )

list(APPEND _cmake_import_check_targets SZ3::hdf5sz3 )
list(APPEND _cmake_import_check_files_for_SZ3::hdf5sz3 "${_IMPORT_PREFIX}/lib/libhdf5sz3.dll.a" "${_IMPORT_PREFIX}/bin/cyghdf5sz3-3.4.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
