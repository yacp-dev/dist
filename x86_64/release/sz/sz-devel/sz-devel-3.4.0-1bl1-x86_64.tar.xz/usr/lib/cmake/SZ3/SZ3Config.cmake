
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was SZ3Config.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

# Use original install prefix when loaded through a "/usr move"
# cross-prefix symbolic link such as /lib -> /usr/lib.
get_filename_component(_realCurr "${CMAKE_CURRENT_LIST_DIR}" REALPATH)
get_filename_component(_realOrig "/usr/lib/cmake/SZ3" REALPATH)
if(_realCurr STREQUAL _realOrig)
  set(PACKAGE_PREFIX_DIR "/usr")
endif()
unset(_realOrig)
unset(_realCurr)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

include(CMakeFindDependencyMacro)

# Every search that can decline runs before any SZ3:: target exists, so a decline leaves none behind
# for a consumer's own copy of SZ3 to collide with.
if(NOT "OFF")
  # Found again, not taken from the export: the build machine's path need not exist here.
  find_library(SZ3_ZSTD_LIBRARY NAMES zstd)
  if(NOT SZ3_ZSTD_LIBRARY)
    set(SZ3_NOT_FOUND_MESSAGE "SZ3 was built against the system Zstd and no libzstd was found here. Install Zstd's development package, or set SZ3_ZSTD_LIBRARY.")
    set(SZ3_FOUND FALSE)
    return()
  endif()
endif()

if(EXISTS "${CMAKE_CURRENT_LIST_DIR}/HDF5SZ3.cmake")
  # Not again when the consumer already found it: FindHDF5 would reset its HDF5_* variables to C only.
  if(NOT TARGET HDF5::HDF5)
    # find_dependency, so this does not demand HDF5 on its own: a consumer who did not write
    # REQUIRED gets SZ3_FOUND FALSE and a reason.
    find_dependency(HDF5 COMPONENTS C)
  endif()
  set(SZ3_hdf5sz3_FOUND TRUE)
endif()
if(EXISTS "${CMAKE_CURRENT_LIST_DIR}/SZ3c.cmake")
  set(SZ3_SZ3c_FOUND TRUE)
endif()
if(TRUE)
  # QUIET and never declining: SZ3::SZ3 goes without OpenMP when the consumer's compiler has none, and
  # SZ3::SZ3core and SZ3::hdf5sz3 do not use it. Asked per language, because FindOpenMP fails outright
  # when it searches for one the consumer did not enable. C and C++ share one runtime everywhere SZ3
  # builds, so either will do.
  get_property(sz3_enabled_languages GLOBAL PROPERTY ENABLED_LANGUAGES)
  if("CXX" IN_LIST sz3_enabled_languages)
    find_package(OpenMP QUIET COMPONENTS CXX)
    if(OpenMP_CXX_FOUND)
      set(sz3_openmp OpenMP::OpenMP_CXX)
    endif()
  elseif("C" IN_LIST sz3_enabled_languages)
    find_package(OpenMP QUIET COMPONENTS C)
    if(OpenMP_C_FOUND)
      set(sz3_openmp OpenMP::OpenMP_C)
    endif()
  endif()
  unset(sz3_enabled_languages)
endif()
check_required_components(SZ3)
# find_package clears a false SZ3_FOUND before running this file, so only check_required_components
# can have set it false here.
if(DEFINED SZ3_FOUND AND NOT SZ3_FOUND)
  return()
endif()

include("${CMAKE_CURRENT_LIST_DIR}/SZ3Targets.cmake")
if(EXISTS "${CMAKE_CURRENT_LIST_DIR}/HDF5SZ3.cmake")
  include("${CMAKE_CURRENT_LIST_DIR}/HDF5SZ3.cmake")
endif()
if(EXISTS "${CMAKE_CURRENT_LIST_DIR}/SZ3c.cmake")
  include("${CMAKE_CURRENT_LIST_DIR}/SZ3c.cmake")
endif()
if(NOT "OFF")
  set_property(TARGET SZ3::SZ3core APPEND PROPERTY INTERFACE_LINK_LIBRARIES "${SZ3_ZSTD_LIBRARY}")
endif()
if(sz3_openmp)
  set_property(TARGET SZ3::SZ3 APPEND PROPERTY INTERFACE_LINK_LIBRARIES ${sz3_openmp})
  unset(sz3_openmp)
endif()

# Without these, target_link_libraries(x PRIVATE hdf5sz3) silently becomes -lhdf5sz3.
foreach(sz3_target SZ3 hdf5sz3)
  if(TARGET SZ3::${sz3_target} AND NOT TARGET ${sz3_target})
    add_library(${sz3_target} INTERFACE IMPORTED)
    target_link_libraries(${sz3_target} INTERFACE SZ3::${sz3_target})
  endif()
endforeach()
