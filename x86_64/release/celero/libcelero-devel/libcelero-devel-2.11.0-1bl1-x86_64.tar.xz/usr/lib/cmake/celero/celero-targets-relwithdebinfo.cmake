#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "celero" for configuration "RelWithDebInfo"
set_property(TARGET celero APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(celero PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libcelero.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygcelero-2.dll"
  )

list(APPEND _cmake_import_check_targets celero )
list(APPEND _cmake_import_check_files_for_celero "${_IMPORT_PREFIX}/lib/libcelero.dll.a" "${_IMPORT_PREFIX}/bin/cygcelero-2.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
