#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Ptex::Ptex_dynamic" for configuration "RelWithDebInfo"
set_property(TARGET Ptex::Ptex_dynamic APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(Ptex::Ptex_dynamic PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libPtex.dll.a"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELWITHDEBINFO "libdeflate::libdeflate_shared"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygPtex-2.5.dll"
  )

list(APPEND _cmake_import_check_targets Ptex::Ptex_dynamic )
list(APPEND _cmake_import_check_files_for_Ptex::Ptex_dynamic "${_IMPORT_PREFIX}/lib/libPtex.dll.a" "${_IMPORT_PREFIX}/bin/cygPtex-2.5.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
