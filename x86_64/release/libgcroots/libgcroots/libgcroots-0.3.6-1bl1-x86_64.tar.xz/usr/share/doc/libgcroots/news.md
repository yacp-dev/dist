# News

## 0.3.6 - 2026-10-11

### Improvements

  * Suppressed a `unused-but-set-variable` warning.

## 0.3.5 - 2026-10-06

### Improvements

  * Meson: Changed the default values to adjust Meson style.

## 0.3.4 - 2026-10-06

### Improvements

  * Added support for Meson.

## 0.3.3 - 2026-09-22

### Improvements

  * Added missing `autogen.sh` to archive.
    * [uim/uim#342](https://github.com/uim/uim/issues/342)
    * Reported by NOKUBI Takatsugu

### Thanks

  * NOKUBI Takatsugu

## 0.3.2 - 2020-08-23

### Improvements

  * Added support for RISC-V.
    [GitHub #3][Patch by Shea Levy]

  * Added support for GCC 10.
    [GitHub #4][Patch by Jeroen Roovers]

### Thanks

  * Shea Levy

  * Jeroen Roovers

## 0.3.1 - 2018-05-10

### Improvements

  * Added AArch64 support
    [GitHub #1][Patch by Andreas Schwab]

### Thanks

  * Andreas Schwab

## 0.3.0 - 2018-05-09

No feature changes. This is just a repackaged version of 0.2.3.

