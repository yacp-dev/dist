/*
 * Definitions for libfmos
 *
 * Copyright (C) 2019-2026, Joachim Metz <joachim.metz@gmail.com>
 *
 * Refer to AUTHORS for acknowledgements.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#if !defined( _LIBFMOS_DEFINITIONS_H )
#define _LIBFMOS_DEFINITIONS_H

#include <libfmos/types.h>

#define LIBFMOS_VERSION		20260520

/* The version string
 */
#define LIBFMOS_VERSION_STRING	"20260520"

#endif /* !defined( _LIBFMOS_DEFINITIONS_H ) */

