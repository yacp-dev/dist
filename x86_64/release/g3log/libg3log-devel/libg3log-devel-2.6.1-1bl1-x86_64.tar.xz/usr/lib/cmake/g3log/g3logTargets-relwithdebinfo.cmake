#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "g3log" for configuration "RelWithDebInfo"
set_property(TARGET g3log APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(g3log PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libg3log.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygg3log-2.dll"
  )

list(APPEND _cmake_import_check_targets g3log )
list(APPEND _cmake_import_check_files_for_g3log "${_IMPORT_PREFIX}/lib/libg3log.dll.a" "${_IMPORT_PREFIX}/bin/cygg3log-2.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
