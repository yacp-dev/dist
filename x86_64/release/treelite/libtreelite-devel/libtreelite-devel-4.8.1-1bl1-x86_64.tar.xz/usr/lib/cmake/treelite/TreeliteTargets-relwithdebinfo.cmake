#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "treelite::treelite" for configuration "RelWithDebInfo"
set_property(TARGET treelite::treelite APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(treelite::treelite PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libtreelite.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygtreelite-4.dll"
  )

list(APPEND _cmake_import_check_targets treelite::treelite )
list(APPEND _cmake_import_check_files_for_treelite::treelite "${_IMPORT_PREFIX}/lib/libtreelite.dll.a" "${_IMPORT_PREFIX}/bin/cygtreelite-4.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
