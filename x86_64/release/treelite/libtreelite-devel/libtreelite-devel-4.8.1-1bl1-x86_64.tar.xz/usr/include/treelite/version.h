/*!
 * Copyright (c) 2023 by Contributors
 */
#ifndef TREELITE_VERSION_H_
#define TREELITE_VERSION_H_

#define TREELITE_VER_MAJOR 4
#define TREELITE_VER_MINOR 8
#define TREELITE_VER_PATCH 1
#define TREELITE_VERSION_STR "4.8.1"

#endif  // TREELITE_VERSION_H_
