if [ ! -e /etc/umurmur/umurmur.conf ]
then
    /usr/bin/mkdir -p /etc/umurmur
    /usr/bin/cp /etc/defaults/etc/umurmur/umurmur.conf /etc/umurmur/umurmur.conf
fi

