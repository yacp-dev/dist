if [ -f /etc/umurmur/umurmur.conf ] && cmp -s /etc/defaults/etc/umurmur/umurmur.conf /etc/umurmur/umurmur.conf
then
    rm /etc/umurmur/umurmur.conf
fi

