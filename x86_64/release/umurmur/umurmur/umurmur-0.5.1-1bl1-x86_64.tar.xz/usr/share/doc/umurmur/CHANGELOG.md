# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.5.1](https://github.com/umurmur/umurmur/compare/v0.5.0...v0.5.1) (2026-09-16)


### Fixed

* Add missing return when SSLi returns 0 ([#274](https://github.com/umurmur/umurmur/issues/274)) ([ffc39b5](https://github.com/umurmur/umurmur/commit/ffc39b533b90228114d30c8218b9fa0e1a8af975))
* Allow TLS 1.3 only when provided ([#277](https://github.com/umurmur/umurmur/issues/277)) ([c9ee778](https://github.com/umurmur/umurmur/commit/c9ee77842ac5784a60613e2623cabfd3ccda46e3))
* Memory leaks involving mbedtls_ssl_session ([#276](https://github.com/umurmur/umurmur/issues/276)) ([68b3027](https://github.com/umurmur/umurmur/commit/68b3027c02d1e35092b44f51d87c7de9548fb948))

## [0.5.0](https://github.com/umurmur/umurmur/compare/v0.4.1...v0.5.0) (2026-09-09)


### Added

* Autogenerate certificate with GnuTLS ([#269](https://github.com/umurmur/umurmur/issues/269)) ([4ed5dbb](https://github.com/umurmur/umurmur/commit/4ed5dbb7b31d6ad3e646ca578c1d5357d632f741))
* Autogenerate certificate with Mbed TLS ([#268](https://github.com/umurmur/umurmur/issues/268)) ([39bc055](https://github.com/umurmur/umurmur/commit/39bc0552e97427210a64a78cef292b7890f9576b))
* Display SSL implementation in version string ([#270](https://github.com/umurmur/umurmur/issues/270)) ([eb01ffc](https://github.com/umurmur/umurmur/commit/eb01ffc0949b8f85701d681f5d19b3e6ff23ddea))
* Remove legacy codec support ([#262](https://github.com/umurmur/umurmur/issues/262)) ([0a1b67d](https://github.com/umurmur/umurmur/commit/0a1b67d7f37f50b1ca74a72f29cae81f9f2ca793))
* Support Mbed TLS 4.x and PSA Crypto API ([#240](https://github.com/umurmur/umurmur/issues/240)) ([09a9851](https://github.com/umurmur/umurmur/commit/09a98514b8529456d311b6c927a37a156f0de014))


### Fixed

* Add format attribute to log wrappers ([#256](https://github.com/umurmur/umurmur/issues/256)) ([07f2693](https://github.com/umurmur/umurmur/commit/07f269376a308ccbeb428487af071d20be7ba666))
* Memory leak in OpenSSL X509 handling ([#271](https://github.com/umurmur/umurmur/issues/271)) ([9a0a947](https://github.com/umurmur/umurmur/commit/9a0a947ada4733537249254485f3b079b7bcec01))
* Remove unused parameter in Sharedmemory_init() ([#253](https://github.com/umurmur/umurmur/issues/253)) ([5f62561](https://github.com/umurmur/umurmur/commit/5f6256123815672d164c9fddf69a861e8d0f757e))
* Simplify extension feature-test macros ([#252](https://github.com/umurmur/umurmur/issues/252)) ([c41b614](https://github.com/umurmur/umurmur/commit/c41b6140f95200e18cd112aaa5eae58525d23a62))
* Tidy extraneous newlines ([#261](https://github.com/umurmur/umurmur/issues/261)) ([071657c](https://github.com/umurmur/umurmur/commit/071657c5f1d8eb1cbd1a74c57b190a9cdfb06f04))
* Usage typos ([#272](https://github.com/umurmur/umurmur/issues/272)) ([8159d91](https://github.com/umurmur/umurmur/commit/8159d910e0c7394d9757fdb864897178facf9945))
* Use properly-sized buffer for system_string ([#255](https://github.com/umurmur/umurmur/issues/255)) ([427450a](https://github.com/umurmur/umurmur/commit/427450a91237b46791abaf4c69bb90608e8c17da))
* Use snprintf in SSLi_init() ([#254](https://github.com/umurmur/umurmur/issues/254)) ([d691392](https://github.com/umurmur/umurmur/commit/d691392c01389d0b65fea4784c89d601584a8622))

## [0.4.1](https://github.com/umurmur/umurmur/compare/v0.4.0...v0.4.1) (2026-08-18)


### Fixed

* builds on MacOS ([#250](https://github.com/umurmur/umurmur/issues/250)) ([ae30ccf](https://github.com/umurmur/umurmur/commit/ae30ccf040e81c89cdac62acb0ed6248a00f2d81))
* Correct endian header and fix non-Linux LP64 build ([#246](https://github.com/umurmur/umurmur/issues/246)) ([392f3a2](https://github.com/umurmur/umurmur/commit/392f3a21a10c80c0f39f9eca0bac91f9ca22048a))
* Use-after-free crash when client is freed inside message handler ([#251](https://github.com/umurmur/umurmur/issues/251)) ([01b0dea](https://github.com/umurmur/umurmur/commit/01b0dea1bfa17ec4dd192ae63db91a0d315cd1a6))
* Wsometimes-uninitialized ([#247](https://github.com/umurmur/umurmur/issues/247)) ([0ebaaf9](https://github.com/umurmur/umurmur/commit/0ebaaf9494ff24677bd488285393d7b0c177c06f))

## [0.4.0](https://github.com/umurmur/umurmur/compare/v0.3.1...v0.4.0) (2026-08-12)


### Added

* Add CodeRabbit AI ([#237](https://github.com/umurmur/umurmur/issues/237)) ([4d1a8bc](https://github.com/umurmur/umurmur/commit/4d1a8bc7d95d8ed367e4c742c4171a804bb9ace2))
* Adjust logfile ownership for privilege dropping ([#231](https://github.com/umurmur/umurmur/issues/231)) ([aa98d6a](https://github.com/umurmur/umurmur/commit/aa98d6a2745007b67618c0f879c795a28765accf))
* implement pledge and unveil for OpenBSD ([#239](https://github.com/umurmur/umurmur/issues/239)) ([8011c8b](https://github.com/umurmur/umurmur/commit/8011c8b03a4026e9059a92182bf6a3d851e77898))
* Prepare README for better automation ([#217](https://github.com/umurmur/umurmur/issues/217)) ([81a42f0](https://github.com/umurmur/umurmur/commit/81a42f0238f2aac134d530962a8b5afa0050af73))
* Remove OpenWrt related files to simplify ([#223](https://github.com/umurmur/umurmur/issues/223)) ([209edb5](https://github.com/umurmur/umurmur/commit/209edb5c887e5a5d3ab2c95ab4a8aeb8c1e6e8f3))
* Stricter compiler flags ([#232](https://github.com/umurmur/umurmur/issues/232)) ([9c94175](https://github.com/umurmur/umurmur/commit/9c9417507e3302f452814f194d951fefd6e2beb7))
* Switch auto-contributors action ([#218](https://github.com/umurmur/umurmur/issues/218)) ([69b8d98](https://github.com/umurmur/umurmur/commit/69b8d98204cdbfd045881585dd00bff0a0b38ada))


### Fixed

* bound TCP body reads to remaining buffer space ([#245](https://github.com/umurmur/umurmur/issues/245)) ([8bfaed4](https://github.com/umurmur/umurmur/commit/8bfaed4f857a6c2f0a80efa5fdc4fb2828e3d2be))
* Fork PRs get read-only tokens from GitHub ([#234](https://github.com/umurmur/umurmur/issues/234)) ([1685d0e](https://github.com/umurmur/umurmur/commit/1685d0ec3dbe03a2d1857131859025f5a7c58c8d))
* Send text messages to deafened users ([#221](https://github.com/umurmur/umurmur/issues/221)) ([15b76cb](https://github.com/umurmur/umurmur/commit/15b76cb35d4da38a685a80d7bb2bbf09d2dd19bf))
* Update error message from config_read_file() ([#227](https://github.com/umurmur/umurmur/issues/227)) ([209a3e5](https://github.com/umurmur/umurmur/commit/209a3e5c10240d94120eb13c8850c0a351ba07cb))
* Work around Alpine latest shipping Mbed TLS 4.x ([#238](https://github.com/umurmur/umurmur/issues/238)) ([6e559ae](https://github.com/umurmur/umurmur/commit/6e559ae74129d2f19af06956125f610eaf96a962))

## [0.3.1] - 2025-04-15

### Added

- Per-channel setting to explicitly allow temporary channel creation.
- GitHub Actions and Docker CI ([#200](https://github.com/umurmur/umurmur/pull/200)).
- GnuTLS in the build pipeline ([#209](https://github.com/umurmur/umurmur/pull/209)).

### Changed

- Namespace the default configuration file location ([#170](https://github.com/umurmur/umurmur/pull/170)) (dvzrv).
- CMake finds libraries more reliably and installs to `/sbin` ([#199](https://github.com/umurmur/umurmur/pull/199)).
- Drop privileges whenever a user is configured, not only when daemonizing ([#201](https://github.com/umurmur/umurmur/pull/201)).
- Raise the CMake minimum version and add a Debug build option.
- Use Debian Stable for CI builds ([#208](https://github.com/umurmur/umurmur/pull/208)).

### Fixed

- `initgroups(3)` invalidating data returned by `getgrnam(3)` ([#183](https://github.com/umurmur/umurmur/pull/183)) (omar-polo).
- Too few arguments to a formatting function ([#204](https://github.com/umurmur/umurmur/pull/204)).
- Clearer `initgroups()` error message ([#206](https://github.com/umurmur/umurmur/pull/206)).
- Segfault when the client does not provide OS information.

## [0.3.0] - 2025-01-28

### Added

- Mbed TLS 3.x support (Glenn Strauss).

### Fixed

- OpenSSL compatibility with Mumble clients that require TLS 1.3 ciphers (Petre Rodan).

## [0.2.20] - 2021-03-21

### Fixed

- OpenSSL compilation against a library built without deprecated APIs (Rosen Penev).

## [0.2.19] - 2021-01-23

### Fixed

- CMake install location for the config file (dvzrv).
- Do not use ECC when OpenSSL is compiled without support for it.

## [0.2.18] - 2020-12-31

### Added

- Priority speaker support (unterwulf).
- OpenSSL EC-key support. Note that some clients (for example Mumla on Android) do not handle this (fatbob313).

### Changed

- mbedTLS error reporting and deprecated-API handling (fatbob313).
- Remove duplicated and unused code (unterwulf).
- Log the OpenSSL version at init time (fatbob313).
- Update the OpenSSL cipher list (fatbob313).
- Regenerate protobuf files with protoc-c 1.3.3.

### Fixed

- Possible segmentation fault from authenticating clients too early (unterwulf).
- Default config file location when building with CMake.
- Always forward speech to linked channels, not only when whispering or screaming (fatbob313).
- Build against OpenSSL without the 1.1 API enabled (Eneas U de Queiroz).
- Do not generate a cert and key when the files are present but unusable or unreadable (unterwulf).
- Compiler warnings (Rosen Penev).
- Nonce and crypt handling (feinerer).
- Autotools deprecation warning (C4K3).
- Automake dist target (unterwulf).
- Various fixes (doctaweeks, concatime).

## [0.2.17] - 2017-04-29

Stable release of 0.2.17rc1.

## [0.2.17rc1] - 2017-02-06

### Added

- Support for mbed TLS >= 2 (Rawi666, l2dy). Enable with `--with-ssl=mbedtls` (Autotools) or `-DSSL=mbedtls` (CMake).
- Configuration option to hide IP addresses from clients (C4K3). Set `show_addresses = false;` to hide addresses.
- Export the client hash in the SHM interface (snowblind).

### Fixed

- Multiple possible NULL pointer dereferences (TinnedTuna).
- Set the scheduler policy before switching users (C4K3).
- Set up TLS infrastructure before switching users (Nauxuron).
- Default `bindport6` to `bindport` if it is not set explicitly (C4K3).
- Default to modern TLS cipher suites (l2dy, adufray).
- Do not leave garbage when setting socket options (pfmooney).
- Replace a stray `bool` with `bool_t` (andres-erbsen).
- Restrict TLS connections to TLS >= 1.0 (fmorgner).

## [0.2.16a] - 2015-06-20

### Fixed

- Crash in the SHM API during update (doctaweeks).
- Failure to detect missing IPv6 support in FreeBSD jails (marcusball).
- Compile-time check for availability of `version_get_string` (fatbob313).

## [0.2.16] - 2015-04-07

### Added

- Shared-memory API (snowblind). Enable with `--with-shmapi` (Autotools) or `-DENABLE_SHAREDMEMORY_API=on` (CMake). See [umurmur-monitor](https://github.com/umurmur/umurmur-monitor) for an example client.
- GnuTLS backend (fmorgner).
- SELinux type-enforcement rules (fmorgner), published at [umurmur-selinux](https://github.com/umurmur/umurmur-selinux).

### Fixed

- Reworked timestamping (fatbob313).
- Banning when using IPv6 (fatbob313 and fmorgner).

## [0.2.15] - 2014-08-08

### Added

- IPv6 dual-stack support (fmorgner).
- CMake build system alongside Autotools (fmorgner).

### Changed

- Update to Protobuf-C 1.0.0.

## [0.2.14] - 2014-01-02

### Added

- `silent` option for channel configuration.
- `position` option for channel configuration.
- PolarSSL 1.3.x support.
- Support for PolarSSL built with zlib.
- Certificate chain delivery for OpenSSL via the new `ca_path` option.

### Changed

- Use `CLOCK_MONOTONIC` instead of `gettimeofday()`, which can misbehave if the clock jumps (for example after NTP sync).

## [0.2.13] - 2013-06-09

### Added

- Timestamps when logging to a file.

### Fixed

- Opus not working.

## [0.2.12] - 2013-05-20

### Fixed

- Crash at client disconnect with PolarSSL >= 1.2.6.
- Use of `/dev/urandom` for random numbers (PolarSSL).

## [0.2.11] - 2013-05-13

### Added

- Mumble protocol 1.2.4 support.
- Opus codec support.
- Config option for the Opus threshold.
- PolarSSL 1.2.x support.
- Autoconf `./configure` switches:
  - `--enable-polarssl-test-certificate` — use and link the PolarSSL test certificate. Off by default; umurmurd exits with an error if no certificate and/or key file is found.
  - `--enable-polarssl-havege` — use PolarSSL's HAVEGE random number generator. Defaults to `/dev/urandom`.

### Removed

- Support for PolarSSL versions prior to 1.0.0.

### Fixed

- Disconnect when using PTT.
- Possible crash when many clients disconnect simultaneously.
- Error message at client disconnect when using OpenSSL.

## [0.2.10] - 2012-03-18

### Changed

- Update the version string everywhere.
- Better logging when a connection fails.

## [0.2.9] - 2012-03-17

### Added

- PolarSSL 1.1.x support.
- Admin user via token password.
- Mute, deafen, kick, and optional ban for the admin user.
- Optional banlist persistence to a file.
- Bans via IP and user certificate.
- Banlist editing in Mumble.
- Option to disallow text messages.
- Release codename.

### Fixed

- Compile on \*BSD (J Sisson).
- Building on OS X.
- Self-deafen also self-mutes.

## [0.2.8] - 2011-10-11

### Added

- Channel passwords (`password = "<password>";` in the channel configuration).
- PolarSSL 1.x.x support (0.x.x remains supported).
- Configuration test flag (`-t`).

### Removed

- Pointless CA cert handling with PolarSSL (it did not work).

### Fixed

- Portability issues in the configure script, including adding `poll.h` to header checks.
- Unnecessary fatal exit when a client is disconnected due to an SSL error.

## [0.2.7] - 2011-04-18

### Added

- Autotools build system (Diaoul).
- Configuration option to log to a file.

### Fixed

- Codec alpha/beta in the message sent to the client.

### Changed

- Miscellaneous cleanup.

## [0.2.6] - 2011-02-09

### Added

- Privilege dropping, enabled in the config file (tilman2).
- Mumble protocol 1.2.3.
- UserStats message support.
- Recording support.

### Fixed

- PID file handling and various other fixes (tilman2).
- BSD portability (J Sisson).

### Changed

- Configuration file errors now go to the log instead of stderr.

## [0.2.5] - 2010-11-13

### Added

- Bind IP and port command-line parameters.

### Changed

- Warn instead of exiting fatally when setting TOS on the UDP socket fails.
- Update Protobuf-C to 0.14.

### Fixed

- Mute/unmute status not showing correctly in other clients' GUIs.
- False "authenticated" status showing for other clients.

## [0.2.4] - 2010-03-24

### Fixed

- Broken Makefile in the 0.2.3 release.

## [0.2.3] - 2010-03-24

### Fixed

- Byte-order handling so uMurmur works on big-endian platforms.

## [0.2.2] - 2010-03-07

### Fixed

- Crash when a user adds an Access Token while connected.
- Crash when dragging the self user from a temporary channel and dropping it back into the same channel.

## [0.2.1] - 2010-02-17

### Fixed

- Version string left at `0.2.0-beta2` in the 0.2.0 release.

## [0.2.0] - 2010-02-17

### Added

- Mumble protocol 1.2.x (1.2.x clients are supported).
- PolarSSL as an alternative to OpenSSL.
- Whisper targets for channels, channel trees, and linked channels.
- Temporary channels created by users.
- Channel links in the configuration file.
- Non-enterable channels in the configuration file.

### Changed

- Strip positional audio if users are not in the same plugin context (not playing the same game).

## [0.1.3] - 2009-11-18

### Added

- Command-line switch to enable realtime priority.

### Fixed

- TCP-mode memory leak.

## [0.1.2] - 2009-09-26

### Changed

- Increase max string size.
- Force a close when the inactivity timer triggers.
- Correct log levels.

## [0.1.1] - 2009-08-29

### Added

- Initial release.

[0.3.1]: https://github.com/umurmur/umurmur/compare/0.3.0...v0.3.1
[0.3.0]: https://github.com/umurmur/umurmur/compare/0.2.20...0.3.0
[0.2.20]: https://github.com/umurmur/umurmur/compare/0.2.19...0.2.20
[0.2.19]: https://github.com/umurmur/umurmur/compare/0.2.18...0.2.19
[0.2.18]: https://github.com/umurmur/umurmur/compare/0.2.17...0.2.18
[0.2.17]: https://github.com/umurmur/umurmur/compare/0.2.17rc1...0.2.17
[0.2.17rc1]: https://github.com/umurmur/umurmur/compare/0.2.16a...0.2.17rc1
[0.2.16a]: https://github.com/umurmur/umurmur/compare/0.2.16...0.2.16a
[0.2.16]: https://github.com/umurmur/umurmur/compare/0.2.15...0.2.16
[0.2.15]: https://github.com/umurmur/umurmur/compare/0.2.14...0.2.15
[0.2.14]: https://github.com/umurmur/umurmur/compare/0.2.13...0.2.14
[0.2.13]: https://github.com/umurmur/umurmur/compare/0.2.12...0.2.13
[0.2.12]: https://github.com/umurmur/umurmur/compare/0.2.11...0.2.12
[0.2.11]: https://github.com/umurmur/umurmur/compare/0.2.10...0.2.11
[0.2.10]: https://github.com/umurmur/umurmur/compare/0.2.9...0.2.10
[0.2.9]: https://github.com/umurmur/umurmur/compare/0.2.8...0.2.9
[0.2.8]: https://github.com/umurmur/umurmur/compare/0.2.7...0.2.8
[0.2.7]: https://github.com/umurmur/umurmur/compare/0.2.6...0.2.7
[0.2.6]: https://github.com/umurmur/umurmur/compare/0.2.5...0.2.6
[0.2.5]: https://github.com/umurmur/umurmur/compare/0.2.4...0.2.5
[0.2.4]: https://github.com/umurmur/umurmur/compare/0.2.3...0.2.4
[0.2.3]: https://github.com/umurmur/umurmur/compare/0.2.2...0.2.3
[0.2.2]: https://github.com/umurmur/umurmur/compare/0.2.1...0.2.2
[0.2.1]: https://github.com/umurmur/umurmur/compare/0.2.0...0.2.1
[0.2.0]: https://github.com/umurmur/umurmur/compare/0.1.3...0.2.0
[0.1.3]: https://github.com/umurmur/umurmur/compare/0.1.2...0.1.3
[0.1.2]: https://github.com/umurmur/umurmur/compare/0.1.1...0.1.2
[0.1.1]: https://github.com/umurmur/umurmur/releases/tag/0.1.1
