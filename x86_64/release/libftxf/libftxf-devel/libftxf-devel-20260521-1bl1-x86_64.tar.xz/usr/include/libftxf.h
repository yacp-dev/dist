/*
 * Library to access the Transactional NTFS (TxF) format
 *
 * Copyright (C) 2011-2026, Joachim Metz <joachim.metz@gmail.com>
 *
 * Refer to AUTHORS for acknowledgements.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#if !defined( _LIBFTXF_H )
#define _LIBFTXF_H

#include <libftxf/codepage.h>
#include <libftxf/definitions.h>
#include <libftxf/error.h>
#include <libftxf/extern.h>
#include <libftxf/features.h>
#include <libftxf/types.h>

#include <stdio.h>

#if defined( __cplusplus )
extern "C" {
#endif

/* -------------------------------------------------------------------------
 * Support functions
 * ------------------------------------------------------------------------- */

/* Returns the library version
 */
LIBFTXF_EXTERN \
const char *libftxf_get_version(
             void );

/* -------------------------------------------------------------------------
 * Error functions
 * ------------------------------------------------------------------------- */

/* Frees an error
 */
LIBFTXF_EXTERN \
void libftxf_error_free(
      libftxf_error_t **error );

/* Prints a descriptive string of the error to the stream
 * Returns the amount of printed characters if successful or -1 on error
 */
LIBFTXF_EXTERN \
int libftxf_error_fprint(
     libftxf_error_t *error,
     FILE *stream );

/* Prints a descriptive string of the error to the string
 * The end-of-string character is not included in the return value
 * Returns the amount of printed characters if successful or -1 on error
 */
LIBFTXF_EXTERN \
int libftxf_error_sprint(
     libftxf_error_t *error,
     char *string,
     size_t size );

/* Prints a backtrace of the error to the stream
 * Returns the amount of printed characters if successful or -1 on error
 */
LIBFTXF_EXTERN \
int libftxf_error_backtrace_fprint(
     libftxf_error_t *error,
     FILE *stream );

/* Prints a backtrace of the error to the string
 * The end-of-string character is not included in the return value
 * Returns the amount of printed characters if successful or -1 on error
 */
LIBFTXF_EXTERN \
int libftxf_error_backtrace_sprint(
     libftxf_error_t *error,
     char *string,
     size_t size );

/* -------------------------------------------------------------------------
 * Record functions
 * ------------------------------------------------------------------------- */

/* Creates a record
 * Make sure the value record is referencing, is set to NULL
 * Returns 1 if successful or -1 on error
 */
LIBFTXF_EXTERN \
int libftxf_record_initialize(
     libftxf_record_t **txf_record,
     libftxf_error_t **error );

/* Frees a record
 * Returns 1 if successful or -1 on error
 */
LIBFTXF_EXTERN \
int libftxf_record_free(
     libftxf_record_t **txf_record,
     libftxf_error_t **error );

/* Copies the record from the byte stream
 * Returns 1 if successful or -1 on error
 */
LIBFTXF_EXTERN \
int libftxf_record_copy_from_byte_stream(
     libftxf_record_t *txf_record,
     const uint8_t *byte_stream,
     size_t byte_stream_size,
     libftxf_error_t **error );

#if defined( __cplusplus )
}
#endif

#endif /* !defined( _LIBFTXF_H ) */

