/*
 * Definitions for libftxf
 *
 * Copyright (C) 2011-2026, Joachim Metz <joachim.metz@gmail.com>
 *
 * Refer to AUTHORS for acknowledgements.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#if !defined( _LIBFTXF_DEFINITIONS_H )
#define _LIBFTXF_DEFINITIONS_H

#include <libftxf/types.h>

#define LIBFTXF_VERSION					20260521

/* The version string
 */
#define LIBFTXF_VERSION_STRING				"20260521"

/* The byte order definitions
 */
enum LIBFTXF_ENDIAN
{
	LIBFTXF_ENDIAN_BIG				= (int) 'b',
	LIBFTXF_ENDIAN_LITTLE				= (int) 'l'
};

/* The record types
 */
enum LIBFTXF_RECORD_TYPES
{
	LIBFTXF_RECORD_TYPE_UPDATE_JOURNAL_ENTRIES_LIST	= 0x0017,
};

/* The file attribute flags
 */
enum LIBFTXF_FILE_ATTRIBUTE_FLAGS
{
	LIBFTXF_FILE_ATTRIBUTE_FLAG_READ_ONLY		= 0x00000001UL,
	LIBFTXF_FILE_ATTRIBUTE_FLAG_HIDDEN		= 0x00000002UL,
	LIBFTXF_FILE_ATTRIBUTE_FLAG_SYSTEM		= 0x00000004UL,

	LIBFTXF_FILE_ATTRIBUTE_FLAG_DIRECTORY		= 0x00000010UL,
	LIBFTXF_FILE_ATTRIBUTE_FLAG_ARCHIVE		= 0x00000020UL,
	LIBFTXF_FILE_ATTRIBUTE_FLAG_DEVICE		= 0x00000040UL,
	LIBFTXF_FILE_ATTRIBUTE_FLAG_NORMAL		= 0x00000080UL,
	LIBFTXF_FILE_ATTRIBUTE_FLAG_TEMPORARY		= 0x00000100UL,
	LIBFTXF_FILE_ATTRIBUTE_FLAG_SPARSE_FILE		= 0x00000200UL,
	LIBFTXF_FILE_ATTRIBUTE_FLAG_REPARSE_POINT	= 0x00000400UL,
	LIBFTXF_FILE_ATTRIBUTE_FLAG_COMPRESSED		= 0x00000800UL,
	LIBFTXF_FILE_ATTRIBUTE_FLAG_OFFLINE		= 0x00001000UL,
	LIBFTXF_FILE_ATTRIBUTE_FLAG_NOT_CONTENT_INDEXED	= 0x00002000UL,
	LIBFTXF_FILE_ATTRIBUTE_FLAG_ENCRYPTED		= 0x00004000UL,

	LIBFTXF_FILE_ATTRIBUTE_FLAG_VIRTUAL		= 0x00010000UL
};

#endif /* !defined( _LIBFTXF_DEFINITIONS_H ) */

