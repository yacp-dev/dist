document.addEventListener('DOMContentLoaded', function() {
    var btn = document.getElementById('captcha-btn');
    var barCont = document.getElementById('bargraph-container');
    var barFill = document.getElementById('bargraph-fill');
    var sPre = document.getElementById('status-pre');
    var sReady = document.getElementById('status-ready');
    var sPressed = document.getElementById('status-pressed');
    var msg = document.getElementById('countdown-msg');
    var form = document.getElementById('captcha-form');
    var headerImg = document.getElementById('header-img');

    if (!btn) return;

    var pre_delay = (typeof lws_interceptor_pre_delay_ms !== 'undefined') ? lws_interceptor_pre_delay_ms : 2000;
    var post_delay = (typeof lws_interceptor_post_delay_ms !== 'undefined') ? lws_interceptor_post_delay_ms : 5000;

    // Load and stats
    var statLoad = document.getElementById('stat-load');
    var statServed = document.getElementById('stat-served');
    var statPassed = document.getElementById('stat-passed');

    if (statLoad && typeof lws_system_load !== 'undefined') statLoad.innerText = lws_system_load;
    if (statServed && typeof lws_interceptor_served !== 'undefined') statServed.innerText = lws_interceptor_served;
    if (statPassed && typeof lws_interceptor_passed !== 'undefined') statPassed.innerText = lws_interceptor_passed;

    if (headerImg) {
        var images = ['scrapers-1.jpg', 'scrapers-2.jpg', 'scrapers-3.jpg'];
        var randomImg = images[Math.floor(Math.random() * images.length)];

        /*
         * This page is served at the URI that was originally asked for (the
         * diverted, protected URL).  A relative image URI would resolve
         * against that URL, so the browser would ask the protected mount for
         * eg /git/.../scrapers-2.jpg, get the HTML captcha page back for an
         * <img> and cancel the load.  Ask for the image on the interceptor
         * mount instead, where the real image file lives.  When the page is
         * served directly from the interceptor mount (no diversion), fall
         * back to a plain relative URI.
         */
        headerImg.src = (typeof lws_interceptor_path === 'undefined')
            ? randomImg
            : lws_interceptor_path + '/' + randomImg;
    }

    btn.style.display = 'none';
    if (barCont) barCont.style.display = 'block';

    function setStatus(id) {
        if (sPre) sPre.style.display = (id === 'pre') ? 'block' : 'none';
        if (sReady) sReady.style.display = (id === 'ready') ? 'block' : 'none';
        if (sPressed) sPressed.style.display = (id === 'pressed') ? 'block' : 'none';
    }

    function animateBar(duration, callback) {
        var start = Date.now();
        function frame() {
            var elapsed = Date.now() - start;
            var progress = Math.min(100, (elapsed / duration) * 100);
            if (barFill) barFill.style.width = progress + '%';

            if (elapsed < duration) {
                var left = Math.ceil((duration - elapsed) / 1000);
                if (msg) {
                    if (barFill.classList.contains('verifying'))
                        msg.innerText = 'Verifying... ' + left + 's remaining';
                    else
                        msg.innerText = 'Prove you are human... ' + left + 's remaining';
                }
                requestAnimationFrame(frame);
            } else {
                if (barFill) barFill.style.width = '100%';
                if (callback) callback();
            }
        }
        requestAnimationFrame(frame);
    }

    /*
     * interceptor-config.js tells us if the server will wave the challenge
     * through at once for this visitor (a live lws-login session with the
     * grant this page needs): it asks the same question the server asks of
     * the submission.  Then submit it now, so a logged-in user does not sit
     * through the delays.
     *
     * Whatever the server said, only ever auto-submit once in a row: if an
     * auto-submission comes back to the challenge (eg, the session ended in
     * between), fall back to the normal delayed flow here instead of
     * submitting again and again.  Without sessionStorage to remember that
     * by, don't auto-submit at all.
     */
    var autoKey = 'lws_interceptor_auto:' + window.location.pathname;

    function autoSubmitAllowed() {
        try {
            var last = Number.parseInt(window.sessionStorage.getItem(autoKey) || '0', 10);

            window.sessionStorage.removeItem(autoKey);
            if (!Number.isNaN(last) && last && Date.now() - last < 60000)
                return false;
            window.sessionStorage.setItem(autoKey, String(Date.now()));

            return true;
        } catch (e) {
            return false;
        }
    }

    if (typeof lws_interceptor_session_live !== 'undefined' &&
        lws_interceptor_session_live === 1 && form && autoSubmitAllowed()) {
        if (msg) msg.innerText = 'Authenticated via login... bypassing...';
        setStatus('pressed');
        btn.disabled = true;
        if (barFill) barFill.style.width = '100%';
        form.action = window.location.pathname;
        form.submit();
        return;
    }

    // Stage 1: Pre-delay
    setStatus('pre');
    animateBar(pre_delay, function() {
        setStatus('ready');
        if (msg) msg.innerText = 'Ready to continue.';
        btn.style.display = 'block';
    });

    if (form) {
        form.addEventListener('submit', function(e) {
            // Prevent multiple submissions
            if (btn.disabled) return;

            btn.disabled = true;
            btn.style.display = 'none';
            setStatus('pressed');

            if (barFill) {
                barFill.classList.add('verifying');
                barFill.style.width = '0%';
            }

            // Stage 2: Post-submission delay
            animateBar(post_delay, function() {
                if (msg) msg.innerText = 'Redirecting...';
            });

            // We let the form submit normally, the server will hold the connection
            // for post_delay_ms anyway. The JS animation is just for UI.
            return true;
        });
    }
});
