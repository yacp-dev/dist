#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "costa::costa" for configuration "RelWithDebInfo"
set_property(TARGET costa::costa APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(costa::costa PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libcosta.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygcosta-2.dll"
  )

list(APPEND _cmake_import_check_targets costa::costa )
list(APPEND _cmake_import_check_files_for_costa::costa "${_IMPORT_PREFIX}/lib/libcosta.dll.a" "${_IMPORT_PREFIX}/bin/cygcosta-2.dll" )

# Import target "costa::costa_scalapack" for configuration "RelWithDebInfo"
set_property(TARGET costa::costa_scalapack APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(costa::costa_scalapack PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libcosta_scalapack.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygcosta_scalapack-2.dll"
  )

list(APPEND _cmake_import_check_targets costa::costa_scalapack )
list(APPEND _cmake_import_check_files_for_costa::costa_scalapack "${_IMPORT_PREFIX}/lib/libcosta_scalapack.dll.a" "${_IMPORT_PREFIX}/bin/cygcosta_scalapack-2.dll" )

# Import target "costa::costa_prefixed_scalapack" for configuration "RelWithDebInfo"
set_property(TARGET costa::costa_prefixed_scalapack APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(costa::costa_prefixed_scalapack PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libcosta_prefixed_scalapack.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygcosta_prefixed_scalapack-2.dll"
  )

list(APPEND _cmake_import_check_targets costa::costa_prefixed_scalapack )
list(APPEND _cmake_import_check_files_for_costa::costa_prefixed_scalapack "${_IMPORT_PREFIX}/lib/libcosta_prefixed_scalapack.dll.a" "${_IMPORT_PREFIX}/bin/cygcosta_prefixed_scalapack-2.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
