cmake_policy(PUSH) # Save project's policies
if(POLICY CMP0074)
  cmake_policy(SET CMP0074 NEW)
endif()
include(CMakeFindDependencyMacro)

# Bundled modules should be found first to prevent conflicts with similarly
# named modules in calling projects.
#
set(CMAKE_MODULE_PATH ${CMAKE_CURRENT_LIST_DIR} ${CMAKE_MODULE_PATH})

set(MKL_ROOT "")

set(MPI_DETERMINE_LIBRARY_VERSION TRUE)
set(COSTA_SCALAPACK "CUSTOM")

find_dependency(MPI)
find_dependency(OpenMP)

if (NOT COSTA_SCALAPACK STREQUAL "OFF")
  find_dependency(SCALAPACK)
endif ()

if ("OFF")
  find_dependency(semiprof)
endif ()

# Clean-up module path.
#
list(REMOVE_ITEM CMAKE_MODULE_PATH ${CMAKE_CURRENT_LIST_DIR})

include("${CMAKE_CURRENT_LIST_DIR}/costaTargets.cmake")
cmake_policy(POP) # Restore project's policies
