#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "libphonenumber::phonenumber-shared" for configuration "RelWithDebInfo"
set_property(TARGET libphonenumber::phonenumber-shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(libphonenumber::phonenumber-shared PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libphonenumber.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygphonenumber-9.dll"
  )

list(APPEND _cmake_import_check_targets libphonenumber::phonenumber-shared )
list(APPEND _cmake_import_check_files_for_libphonenumber::phonenumber-shared "${_IMPORT_PREFIX}/lib/libphonenumber.dll.a" "${_IMPORT_PREFIX}/bin/cygphonenumber-9.dll" )

# Import target "libphonenumber::geocoding-shared" for configuration "RelWithDebInfo"
set_property(TARGET libphonenumber::geocoding-shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(libphonenumber::geocoding-shared PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libgeocoding.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cyggeocoding-9.dll"
  )

list(APPEND _cmake_import_check_targets libphonenumber::geocoding-shared )
list(APPEND _cmake_import_check_files_for_libphonenumber::geocoding-shared "${_IMPORT_PREFIX}/lib/libgeocoding.dll.a" "${_IMPORT_PREFIX}/bin/cyggeocoding-9.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
