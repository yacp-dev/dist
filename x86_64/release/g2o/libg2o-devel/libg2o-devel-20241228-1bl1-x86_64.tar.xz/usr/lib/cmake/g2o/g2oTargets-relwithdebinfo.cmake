#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "g2o::freeglut_minimal" for configuration "RelWithDebInfo"
set_property(TARGET g2o::freeglut_minimal APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(g2o::freeglut_minimal PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libg2o_ext_freeglut_minimal.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygg2o_ext_freeglut_minimal-0.1.dll"
  )

list(APPEND _cmake_import_check_targets g2o::freeglut_minimal )
list(APPEND _cmake_import_check_files_for_g2o::freeglut_minimal "${_IMPORT_PREFIX}/lib/libg2o_ext_freeglut_minimal.dll.a" "${_IMPORT_PREFIX}/bin/cygg2o_ext_freeglut_minimal-0.1.dll" )

# Import target "g2o::stuff" for configuration "RelWithDebInfo"
set_property(TARGET g2o::stuff APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(g2o::stuff PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libg2o_stuff.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygg2o_stuff-0.1.dll"
  )

list(APPEND _cmake_import_check_targets g2o::stuff )
list(APPEND _cmake_import_check_files_for_g2o::stuff "${_IMPORT_PREFIX}/lib/libg2o_stuff.dll.a" "${_IMPORT_PREFIX}/bin/cygg2o_stuff-0.1.dll" )

# Import target "g2o::opengl_helper" for configuration "RelWithDebInfo"
set_property(TARGET g2o::opengl_helper APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(g2o::opengl_helper PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libg2o_opengl_helper.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygg2o_opengl_helper-0.1.dll"
  )

list(APPEND _cmake_import_check_targets g2o::opengl_helper )
list(APPEND _cmake_import_check_files_for_g2o::opengl_helper "${_IMPORT_PREFIX}/lib/libg2o_opengl_helper.dll.a" "${_IMPORT_PREFIX}/bin/cygg2o_opengl_helper-0.1.dll" )

# Import target "g2o::core" for configuration "RelWithDebInfo"
set_property(TARGET g2o::core APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(g2o::core PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libg2o_core.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygg2o_core-0.1.dll"
  )

list(APPEND _cmake_import_check_targets g2o::core )
list(APPEND _cmake_import_check_files_for_g2o::core "${_IMPORT_PREFIX}/lib/libg2o_core.dll.a" "${_IMPORT_PREFIX}/bin/cygg2o_core-0.1.dll" )

# Import target "g2o::g2o_cli_library" for configuration "RelWithDebInfo"
set_property(TARGET g2o::g2o_cli_library APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(g2o::g2o_cli_library PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libg2o_cli.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygg2o_cli-0.1.dll"
  )

list(APPEND _cmake_import_check_targets g2o::g2o_cli_library )
list(APPEND _cmake_import_check_files_for_g2o::g2o_cli_library "${_IMPORT_PREFIX}/lib/libg2o_cli.dll.a" "${_IMPORT_PREFIX}/bin/cygg2o_cli-0.1.dll" )

# Import target "g2o::g2o_simulator_library" for configuration "RelWithDebInfo"
set_property(TARGET g2o::g2o_simulator_library APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(g2o::g2o_simulator_library PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libg2o_simulator.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygg2o_simulator-0.1.dll"
  )

list(APPEND _cmake_import_check_targets g2o::g2o_simulator_library )
list(APPEND _cmake_import_check_files_for_g2o::g2o_simulator_library "${_IMPORT_PREFIX}/lib/libg2o_simulator.dll.a" "${_IMPORT_PREFIX}/bin/cygg2o_simulator-0.1.dll" )

# Import target "g2o::types_slam2d" for configuration "RelWithDebInfo"
set_property(TARGET g2o::types_slam2d APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(g2o::types_slam2d PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libg2o_types_slam2d.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygg2o_types_slam2d-0.1.dll"
  )

list(APPEND _cmake_import_check_targets g2o::types_slam2d )
list(APPEND _cmake_import_check_files_for_g2o::types_slam2d "${_IMPORT_PREFIX}/lib/libg2o_types_slam2d.dll.a" "${_IMPORT_PREFIX}/bin/cygg2o_types_slam2d-0.1.dll" )

# Import target "g2o::types_slam2d_addons" for configuration "RelWithDebInfo"
set_property(TARGET g2o::types_slam2d_addons APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(g2o::types_slam2d_addons PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libg2o_types_slam2d_addons.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygg2o_types_slam2d_addons-0.1.dll"
  )

list(APPEND _cmake_import_check_targets g2o::types_slam2d_addons )
list(APPEND _cmake_import_check_files_for_g2o::types_slam2d_addons "${_IMPORT_PREFIX}/lib/libg2o_types_slam2d_addons.dll.a" "${_IMPORT_PREFIX}/bin/cygg2o_types_slam2d_addons-0.1.dll" )

# Import target "g2o::types_data" for configuration "RelWithDebInfo"
set_property(TARGET g2o::types_data APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(g2o::types_data PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libg2o_types_data.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygg2o_types_data-0.1.dll"
  )

list(APPEND _cmake_import_check_targets g2o::types_data )
list(APPEND _cmake_import_check_files_for_g2o::types_data "${_IMPORT_PREFIX}/lib/libg2o_types_data.dll.a" "${_IMPORT_PREFIX}/bin/cygg2o_types_data-0.1.dll" )

# Import target "g2o::types_sclam2d" for configuration "RelWithDebInfo"
set_property(TARGET g2o::types_sclam2d APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(g2o::types_sclam2d PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libg2o_types_sclam2d.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygg2o_types_sclam2d-0.1.dll"
  )

list(APPEND _cmake_import_check_targets g2o::types_sclam2d )
list(APPEND _cmake_import_check_files_for_g2o::types_sclam2d "${_IMPORT_PREFIX}/lib/libg2o_types_sclam2d.dll.a" "${_IMPORT_PREFIX}/bin/cygg2o_types_sclam2d-0.1.dll" )

# Import target "g2o::types_slam3d" for configuration "RelWithDebInfo"
set_property(TARGET g2o::types_slam3d APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(g2o::types_slam3d PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libg2o_types_slam3d.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygg2o_types_slam3d-0.1.dll"
  )

list(APPEND _cmake_import_check_targets g2o::types_slam3d )
list(APPEND _cmake_import_check_files_for_g2o::types_slam3d "${_IMPORT_PREFIX}/lib/libg2o_types_slam3d.dll.a" "${_IMPORT_PREFIX}/bin/cygg2o_types_slam3d-0.1.dll" )

# Import target "g2o::types_slam3d_addons" for configuration "RelWithDebInfo"
set_property(TARGET g2o::types_slam3d_addons APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(g2o::types_slam3d_addons PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libg2o_types_slam3d_addons.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygg2o_types_slam3d_addons-0.1.dll"
  )

list(APPEND _cmake_import_check_targets g2o::types_slam3d_addons )
list(APPEND _cmake_import_check_files_for_g2o::types_slam3d_addons "${_IMPORT_PREFIX}/lib/libg2o_types_slam3d_addons.dll.a" "${_IMPORT_PREFIX}/bin/cygg2o_types_slam3d_addons-0.1.dll" )

# Import target "g2o::types_sba" for configuration "RelWithDebInfo"
set_property(TARGET g2o::types_sba APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(g2o::types_sba PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libg2o_types_sba.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygg2o_types_sba-0.1.dll"
  )

list(APPEND _cmake_import_check_targets g2o::types_sba )
list(APPEND _cmake_import_check_files_for_g2o::types_sba "${_IMPORT_PREFIX}/lib/libg2o_types_sba.dll.a" "${_IMPORT_PREFIX}/bin/cygg2o_types_sba-0.1.dll" )

# Import target "g2o::types_icp" for configuration "RelWithDebInfo"
set_property(TARGET g2o::types_icp APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(g2o::types_icp PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libg2o_types_icp.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygg2o_types_icp-0.1.dll"
  )

list(APPEND _cmake_import_check_targets g2o::types_icp )
list(APPEND _cmake_import_check_files_for_g2o::types_icp "${_IMPORT_PREFIX}/lib/libg2o_types_icp.dll.a" "${_IMPORT_PREFIX}/bin/cygg2o_types_icp-0.1.dll" )

# Import target "g2o::types_sim3" for configuration "RelWithDebInfo"
set_property(TARGET g2o::types_sim3 APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(g2o::types_sim3 PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libg2o_types_sim3.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygg2o_types_sim3-0.1.dll"
  )

list(APPEND _cmake_import_check_targets g2o::types_sim3 )
list(APPEND _cmake_import_check_files_for_g2o::types_sim3 "${_IMPORT_PREFIX}/lib/libg2o_types_sim3.dll.a" "${_IMPORT_PREFIX}/bin/cygg2o_types_sim3-0.1.dll" )

# Import target "g2o::solver_pcg" for configuration "RelWithDebInfo"
set_property(TARGET g2o::solver_pcg APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(g2o::solver_pcg PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libg2o_solver_pcg.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygg2o_solver_pcg-0.1.dll"
  )

list(APPEND _cmake_import_check_targets g2o::solver_pcg )
list(APPEND _cmake_import_check_files_for_g2o::solver_pcg "${_IMPORT_PREFIX}/lib/libg2o_solver_pcg.dll.a" "${_IMPORT_PREFIX}/bin/cygg2o_solver_pcg-0.1.dll" )

# Import target "g2o::solver_dense" for configuration "RelWithDebInfo"
set_property(TARGET g2o::solver_dense APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(g2o::solver_dense PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libg2o_solver_dense.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygg2o_solver_dense-0.1.dll"
  )

list(APPEND _cmake_import_check_targets g2o::solver_dense )
list(APPEND _cmake_import_check_files_for_g2o::solver_dense "${_IMPORT_PREFIX}/lib/libg2o_solver_dense.dll.a" "${_IMPORT_PREFIX}/bin/cygg2o_solver_dense-0.1.dll" )

# Import target "g2o::solver_slam2d_linear" for configuration "RelWithDebInfo"
set_property(TARGET g2o::solver_slam2d_linear APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(g2o::solver_slam2d_linear PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libg2o_solver_slam2d_linear.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygg2o_solver_slam2d_linear-0.1.dll"
  )

list(APPEND _cmake_import_check_targets g2o::solver_slam2d_linear )
list(APPEND _cmake_import_check_files_for_g2o::solver_slam2d_linear "${_IMPORT_PREFIX}/lib/libg2o_solver_slam2d_linear.dll.a" "${_IMPORT_PREFIX}/bin/cygg2o_solver_slam2d_linear-0.1.dll" )

# Import target "g2o::solver_structure_only" for configuration "RelWithDebInfo"
set_property(TARGET g2o::solver_structure_only APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(g2o::solver_structure_only PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libg2o_solver_structure_only.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygg2o_solver_structure_only-0.1.dll"
  )

list(APPEND _cmake_import_check_targets g2o::solver_structure_only )
list(APPEND _cmake_import_check_files_for_g2o::solver_structure_only "${_IMPORT_PREFIX}/lib/libg2o_solver_structure_only.dll.a" "${_IMPORT_PREFIX}/bin/cygg2o_solver_structure_only-0.1.dll" )

# Import target "g2o::solver_csparse" for configuration "RelWithDebInfo"
set_property(TARGET g2o::solver_csparse APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(g2o::solver_csparse PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libg2o_solver_csparse.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygg2o_solver_csparse-0.1.dll"
  )

list(APPEND _cmake_import_check_targets g2o::solver_csparse )
list(APPEND _cmake_import_check_files_for_g2o::solver_csparse "${_IMPORT_PREFIX}/lib/libg2o_solver_csparse.dll.a" "${_IMPORT_PREFIX}/bin/cygg2o_solver_csparse-0.1.dll" )

# Import target "g2o::csparse_extension" for configuration "RelWithDebInfo"
set_property(TARGET g2o::csparse_extension APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(g2o::csparse_extension PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libg2o_csparse_extension.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygg2o_csparse_extension-0.1.dll"
  )

list(APPEND _cmake_import_check_targets g2o::csparse_extension )
list(APPEND _cmake_import_check_files_for_g2o::csparse_extension "${_IMPORT_PREFIX}/lib/libg2o_csparse_extension.dll.a" "${_IMPORT_PREFIX}/bin/cygg2o_csparse_extension-0.1.dll" )

# Import target "g2o::solver_cholmod" for configuration "RelWithDebInfo"
set_property(TARGET g2o::solver_cholmod APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(g2o::solver_cholmod PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libg2o_solver_cholmod.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygg2o_solver_cholmod-0.1.dll"
  )

list(APPEND _cmake_import_check_targets g2o::solver_cholmod )
list(APPEND _cmake_import_check_files_for_g2o::solver_cholmod "${_IMPORT_PREFIX}/lib/libg2o_solver_cholmod.dll.a" "${_IMPORT_PREFIX}/bin/cygg2o_solver_cholmod-0.1.dll" )

# Import target "g2o::solver_eigen" for configuration "RelWithDebInfo"
set_property(TARGET g2o::solver_eigen APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(g2o::solver_eigen PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libg2o_solver_eigen.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygg2o_solver_eigen-0.1.dll"
  )

list(APPEND _cmake_import_check_targets g2o::solver_eigen )
list(APPEND _cmake_import_check_files_for_g2o::solver_eigen "${_IMPORT_PREFIX}/lib/libg2o_solver_eigen.dll.a" "${_IMPORT_PREFIX}/bin/cygg2o_solver_eigen-0.1.dll" )

# Import target "g2o::g2o_hierarchical_library" for configuration "RelWithDebInfo"
set_property(TARGET g2o::g2o_hierarchical_library APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(g2o::g2o_hierarchical_library PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libg2o_hierarchical.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygg2o_hierarchical-0.1.dll"
  )

list(APPEND _cmake_import_check_targets g2o::g2o_hierarchical_library )
list(APPEND _cmake_import_check_files_for_g2o::g2o_hierarchical_library "${_IMPORT_PREFIX}/lib/libg2o_hierarchical.dll.a" "${_IMPORT_PREFIX}/bin/cygg2o_hierarchical-0.1.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
