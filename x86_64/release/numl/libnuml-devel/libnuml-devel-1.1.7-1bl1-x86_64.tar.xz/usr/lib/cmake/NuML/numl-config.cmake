get_filename_component(LIBSBML_CMAKE_DIR "${CMAKE_CURRENT_LIST_FILE}" PATH)
include(CMakeFindDependencyMacro)

list(APPEND CMAKE_MODULE_PATH "/usr/share/cmake/Modules")

set(LIBSBML_LIBRARY_NAME sbml-static)
find_dependency(LIBSBML)

foreach (library )

    string(FIND "${library}" "::" index)

    if (${index} GREATER 0)
      # found dependent library
      string(SUBSTRING "${library}" 0 ${index} DEPENDENT_NAME)
      message(VERBOSE "Looking for dependent library: ${DEPENDENT_NAME}")
      find_dependency(${DEPENDENT_NAME})
    endif()

endforeach()

if(NOT TARGET numl)
    include("${LIBSBML_CMAKE_DIR}/numl-targets.cmake")
endif()

set(LIBNUML_LIBRARIES numl)
