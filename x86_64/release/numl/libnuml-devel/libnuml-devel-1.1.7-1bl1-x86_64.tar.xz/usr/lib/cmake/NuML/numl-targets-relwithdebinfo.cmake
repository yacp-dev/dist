#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "numl" for configuration "RelWithDebInfo"
set_property(TARGET numl APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(numl PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libnuml.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygnuml-1.dll"
  )

list(APPEND _cmake_import_check_targets numl )
list(APPEND _cmake_import_check_files_for_numl "${_IMPORT_PREFIX}/lib/libnuml.dll.a" "${_IMPORT_PREFIX}/bin/cygnuml-1.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
