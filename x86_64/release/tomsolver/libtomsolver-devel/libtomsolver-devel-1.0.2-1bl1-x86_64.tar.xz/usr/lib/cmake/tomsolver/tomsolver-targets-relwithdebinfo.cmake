#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "tomsolver::tomsolver" for configuration "RelWithDebInfo"
set_property(TARGET tomsolver::tomsolver APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(tomsolver::tomsolver PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libtomsolver.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygtomsolver-1.dll"
  )

list(APPEND _cmake_import_check_targets tomsolver::tomsolver )
list(APPEND _cmake_import_check_files_for_tomsolver::tomsolver "${_IMPORT_PREFIX}/lib/libtomsolver.dll.a" "${_IMPORT_PREFIX}/bin/cygtomsolver-1.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
