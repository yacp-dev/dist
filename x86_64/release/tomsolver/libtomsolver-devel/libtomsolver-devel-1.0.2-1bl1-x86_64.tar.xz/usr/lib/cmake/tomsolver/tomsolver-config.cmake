include(CMakeFindDependencyMacro)
include("${CMAKE_CURRENT_LIST_DIR}/tomsolver-targets.cmake")
