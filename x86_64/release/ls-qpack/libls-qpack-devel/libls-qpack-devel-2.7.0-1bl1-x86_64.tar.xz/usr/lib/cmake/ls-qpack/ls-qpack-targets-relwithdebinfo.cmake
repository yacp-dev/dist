#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "ls-qpack::ls-qpack" for configuration "RelWithDebInfo"
set_property(TARGET ls-qpack::ls-qpack APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(ls-qpack::ls-qpack PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libls-qpack.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygls-qpack-2.dll"
  )

list(APPEND _cmake_import_check_targets ls-qpack::ls-qpack )
list(APPEND _cmake_import_check_files_for_ls-qpack::ls-qpack "${_IMPORT_PREFIX}/lib/libls-qpack.dll.a" "${_IMPORT_PREFIX}/bin/cygls-qpack-2.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
