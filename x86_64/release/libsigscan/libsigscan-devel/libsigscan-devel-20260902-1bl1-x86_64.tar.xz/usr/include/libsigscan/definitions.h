/*
 * Definitions for libsigscan
 *
 * Copyright (C) 2014-2026, Joachim Metz <joachim.metz@gmail.com>
 *
 * Refer to AUTHORS for acknowledgements.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#if !defined( _LIBSIGSCAN_DEFINITIONS_H )
#define _LIBSIGSCAN_DEFINITIONS_H

#include <libsigscan/types.h>

#define LIBSIGSCAN_VERSION					20260902

/* The version string
 */
#define LIBSIGSCAN_VERSION_STRING				"20260902"

/* The access flags definitions
 * bit 1        set to 1 for read access
 * bit 2        set to 1 for write access
 * bit 3-8      not used
 */
enum LIBSIGSCAN_ACCESS_FLAGS
{
	LIBSIGSCAN_ACCESS_FLAG_READ				= 0x01,
/* Reserved: not supported yet */
	LIBSIGSCAN_ACCESS_FLAG_WRITE				= 0x02
};

/* The file access macros
 */
#define LIBSIGSCAN_OPEN_READ					( LIBSIGSCAN_ACCESS_FLAG_READ )
/* Reserved: not supported yet */
#define LIBSIGSCAN_OPEN_WRITE					( LIBSIGSCAN_ACCESS_FLAG_WRITE )
/* Reserved: not supported yet */
#define LIBSIGSCAN_OPEN_READ_WRITE				( LIBSIGSCAN_ACCESS_FLAG_READ | LIBSIGSCAN_ACCESS_FLAG_WRITE )

/* The signature flags
 */
enum LIBSIGSCAN_SIGNATURE_FLAGS
{
	LIBSIGSCAN_SIGNATURE_FLAG_NO_OFFSET			= 0x00000000,
	LIBSIGSCAN_SIGNATURE_FLAG_OFFSET_RELATIVE_FROM_START	= 0x00000001,
	LIBSIGSCAN_SIGNATURE_FLAG_OFFSET_RELATIVE_FROM_END	= 0x00000002
};

#endif /* !defined( _LIBSIGSCAN_DEFINITIONS_H ) */

