/*
 * Copyright (C) 2006-2026 Metallizer, Solarus - http://www.solarus-games.org
 *
 * Solarus is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Solarus is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef SOLARUS_LOW_PASS_AUDIO_FILTER_H
#define SOLARUS_LOW_PASS_AUDIO_FILTER_H

#include "solarus/audio/AudioFilter.h"

namespace Solarus {

class LowPassAudioFilter : public AudioFilter {
  public:
    LowPassAudioFilter(float gain = 1.0f, float gainhf = 1.0f);

    void set_params(float gain, float gainhf);
};

} // namespace Solarus

#endif
