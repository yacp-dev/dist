/*
 * Copyright (C) 2006-2026 Metallizer, Solarus - http://www.solarus-games.org
 *
 * Solarus is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Solarus is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef SOLARUS_ECHO_AUDIO_EFFECT_H
#define SOLARUS_ECHO_AUDIO_EFFECT_H

#include "solarus/audio/AudioEffect.h"

namespace Solarus {

enum class EchoPreset {
  CLOSE,
  HALL,
  CAVE,
  CANYON
};

template <>
struct SOLARUS_API EnumInfoTraits<EchoPreset> {
  static const std::string pretty_name;
  static const EnumInfo<EchoPreset>::names_type names;
};

class EchoAudioEffect: public AudioEffect {
  public:
    EchoAudioEffect(EchoPreset preset);

    void set_preset(EchoPreset preset);

  private:
    struct Props {
      float delay;
      float lrdelay;
      float damping;
      float feedback;
      float spread;
    };

    void apply_props(const Props& props);
    static Props preset_props(EchoPreset preset);
};

} // namespace Solarus

#endif
