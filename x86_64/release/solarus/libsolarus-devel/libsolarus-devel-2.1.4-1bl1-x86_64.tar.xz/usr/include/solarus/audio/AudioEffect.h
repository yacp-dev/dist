/*
 * Copyright (C) 2006-2026 Metallizer, Solarus - http://www.solarus-games.org
 *
 * Solarus is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Solarus is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef SOLARUS_AUDIO_EFFECT_H
#define SOLARUS_AUDIO_EFFECT_H

#include "solarus/audio/ALWrapper.h"
#include "solarus/core/Common.h"
#include "solarus/core/EnumInfo.h"

namespace Solarus {

/**
 * \brief Types of audio effects
 */
enum class AudioEffectId {
  LOW_PASS,
  HIGH_PASS,
  REVERB,
  ECHO,
  CHORUS,
  FLANGER,
};

template <>
struct SOLARUS_API EnumInfoTraits<AudioEffectId> {
  static const std::string pretty_name;
  static const EnumInfo<AudioEffectId>::names_type names;
};

class AudioEffect {
  public:
    AudioEffect();
    AudioEffect(AudioEffectId id);

    const ALuint& get_auxiliary_slot() const;

  protected:
    void create_slot();

    AudioEffectId id;                   /**< Identifier for this effect. */
    ALuint effect;                      /**< AL effect */
    ALuint auxiliary_slot;              /**< AL auxiliary slot */

};
    
} // namespace Solarus

#endif
