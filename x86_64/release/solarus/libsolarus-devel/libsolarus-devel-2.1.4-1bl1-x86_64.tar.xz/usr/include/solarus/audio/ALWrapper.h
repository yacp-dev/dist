/*
 * Copyright (C) 2006-2025 Metallizer, Solarus - http://www.solarus-games.org
 *
 * Solarus is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Solarus is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program. If not, see <http://www.gnu.org/licenses/>.
 */
#ifndef SOLARUS_AL_WRAPPER_H
#define SOLARUS_AL_WRAPPER_H

#include <AL/al.h>
#include <AL/alc.h>
#include <AL/alext.h>
#include <AL/efx.h>
#include <AL/efx-presets.h>
#include <string>

namespace Solarus {

class ALWrapper {
  public:
    // Init
    static void init_efx_system();

    // Buffers
    static ALenum generate_buffers(ALsizei n, ALuint *buffers, const std::string& file_name);
    static ALenum delete_buffers(ALsizei n, const ALuint *buffers, const std::string& file_name);
    static ALenum set_buffer_data(ALuint buffer, ALenum format, const ALvoid *data, ALsizei size, ALsizei samplerate, const std::string& file_name);
    static ALenum queue_source_buffers(ALuint source, ALsizei nb, const ALuint *buffers, const std::string& file_name);
    static ALenum unqueue_source_buffers(ALuint source, ALsizei nb, ALuint *buffers, const std::string& file_name);

    // Sources
    static ALenum generate_sources(ALsizei n, ALuint *sources, const std::string& file_name);
    static ALenum delete_sources(ALsizei n, const ALuint *sources, const std::string& file_name);
    static ALenum get_source_int(ALuint source, ALenum param, ALint *value, const std::string& file_name);
    static ALenum set_source_int(ALuint source, ALenum param, ALint value, const std::string& file_name);
    static ALenum set_source_float(ALuint source, ALenum param, ALfloat value, const std::string& file_name);
    static ALenum set_source_3ints(ALuint source, ALenum param, ALint i1, ALint i2, ALint i3, const std::string& file_name);
    static ALenum set_source_vector3(ALuint source, ALenum param, ALfloat x, ALfloat y, ALfloat z, const std::string& file_name);
    static ALenum set_listener_float(ALenum param, ALfloat value, const std::string& file_name);
    static ALenum play_source(ALuint source, const std::string& file_name);
    static ALenum pause_source(ALuint source, const std::string& file_name);
    static ALenum stop_source(ALuint source, const std::string& file_name);

    // Effects
    static ALenum generate_effect(ALsizei n, ALuint *effects, const std::string& context_name);
    static ALenum generate_effect_slots(ALsizei n, ALuint *slots, const std::string& context_name);
    static ALenum set_effect_int(ALuint effect, ALenum param, ALint value, const std::string& context_name);
    static ALenum set_effect_float(ALuint effect, ALenum param, ALfloat value, const std::string& context_name);
    static ALenum set_effect_slot_int(ALuint slot, ALenum param, ALint value, const std::string& context_name);

    // Filters
    static ALenum generate_filter(ALsizei n, ALuint *filters, const std::string& context_name);
    static ALenum set_filter_int(ALuint filter, ALenum param, ALint value, const std::string& context_name);
    static ALenum set_filter_float(ALuint filter, ALenum param, ALfloat value, const std::string& context_name);

  private:
    static void clean_errors();
    static ALenum check_for_errors(const std::string& message);
};

} // namespace Solarus

#endif
