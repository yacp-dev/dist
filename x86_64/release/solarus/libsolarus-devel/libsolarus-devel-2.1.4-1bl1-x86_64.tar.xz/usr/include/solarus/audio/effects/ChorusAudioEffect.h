/*
 * Copyright (C) 2006-2026 Metallizer, Solarus - http://www.solarus-games.org
 *
 * Solarus is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Solarus is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef SOLARUS_CHORUS_AUDIO_EFFECT_H
#define SOLARUS_CHORUS_AUDIO_EFFECT_H

#include "solarus/audio/AudioEffect.h"

namespace Solarus {

enum class ChorusPreset {
  ENSEMBLE,
  HEAVY,
  LIGHT,
  STANDARD,
  VIBRATO
};

template <>
struct SOLARUS_API EnumInfoTraits<ChorusPreset> {
  static const std::string pretty_name;
  static const EnumInfo<ChorusPreset>::names_type names;
};

class ChorusAudioEffect: public AudioEffect {
  public:
    ChorusAudioEffect(ChorusPreset preset);

    void set_preset(ChorusPreset preset);

  private:
    struct Props {
      float rate;
      float depth;
      float feedback;
      float delay;
      int   phase;
    };

    void apply_props(const Props& props);
    static Props preset_props(ChorusPreset preset);
};

} // namespace Solarus

#endif
