set(CMAKE_IMPORT_FILE_VERSION 1)

set(
  MULTICHARGE_INCLUDEDIRS
  "/usr/include"
  "/usr/include/multicharge/modules"
)
find_library(
  MULTICHARGE_LIBRARIES
  "multicharge"
  PATHS "/usr/lib"
  NO_DEFAULT_PATH
)
set(
  MULTICHARGE_DEPENDENCIES
  "$<$<BOOL:${MULTICHARGE_USE_MCTCLIB}>:mctc-lib::mctc-lib>"
  "$<$<BOOL:${MULTICHARGE_WITH_OpenMP}>:OpenMP::OpenMP_Fortran>"
  "LAPACK::LAPACK"
)

add_library(multicharge::multicharge-lib INTERFACE IMPORTED)
add_library(multicharge::multicharge ALIAS multicharge::multicharge-lib)
target_link_libraries(multicharge::multicharge-lib INTERFACE ${MULTICHARGE_LIBRARIES} ${MULTICHARGE_DEPENDENCIES})
target_include_directories(multicharge::multicharge-lib INTERFACE ${MULTICHARGE_INCLUDEDIRS})
