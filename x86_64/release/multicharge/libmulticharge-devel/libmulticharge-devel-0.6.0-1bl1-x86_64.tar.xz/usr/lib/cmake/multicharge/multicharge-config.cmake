

set(MULTICHARGE_WITH_OpenMP ON)
set(MULTICHARGE_WITH_ILP64 OFF)
set(MULTICHARGE_USE_MCTCLIB ON)

enable_language("Fortran")

if(NOT TARGET "multicharge::multicharge")
  include(CMakeFindDependencyMacro)
  list(APPEND CMAKE_MODULE_PATH "${CMAKE_CURRENT_LIST_DIR}")

  if(NOT TARGET "OpenMP::OpenMP_Fortran" AND MULTICHARGE_WITH_OpenMP)
    find_dependency("OpenMP")
  endif()

  if(NOT TARGET "LAPACK::LAPACK")
    find_dependency("LAPACK")
  endif()

  if(NOT TARGET "mctc-lib::mctc-lib" AND MULTICHARGE_USE_MCTCLIB)
    find_dependency("mctc-lib")
  endif()

  list(REMOVE_AT CMAKE_MODULE_PATH -1)
  include("${CMAKE_CURRENT_LIST_DIR}/multicharge-targets.cmake")
endif()
