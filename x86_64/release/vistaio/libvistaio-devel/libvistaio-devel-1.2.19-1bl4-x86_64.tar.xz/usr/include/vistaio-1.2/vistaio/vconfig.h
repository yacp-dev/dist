/*
 *  Copyright (c) Leipzig, Madrid 2004 - 2009
 *  Max-Planck-Institute for Human Cognitive and Brain Science	
 *  Max-Planck-Institute for Evolutionary Anthropology 
 *  BIT, ETSI Telecomunicacion, UPM
 *
 *  Permission to use, copy, modify, distribute, and sell this software and its
 *  documentation for any purpose is hereby granted without fee, provided that
 *  the above copyright notice appears in all copies and that both that
 *  copyright notice and this permission notice appear in supporting
 *  documentation. UBC makes no representations about the suitability of this
 *  software for any purpose. It is provided "as is" without express or
 *  implied warranty.
 *
 *  Author:  Marc Tittgemeyer, MPI for Human Cognitive and Brain Sciences
             Gert Wollny, UPM 
 *
 */

// $Id: vconfig.h.in 64 2004-03-05 14:41:18Z tittge $

/*! \brief Some general configuration file

\remark This is a generated file.  Please modify `configure.ac'
\file vconfig.h

*/

#ifndef __VCONFIG_H
#define __VCONFIG_H 1

#define VISTAIO_MAJOR_VERSION 1
#define VISTAIO_MINOR_VERSION 2
#define VISTAIO_MICRO_VERSION 19

#endif /* VCONFIG_H */
