#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "win32pe" for configuration "RelWithDebInfo"
set_property(TARGET win32pe APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(win32pe PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libwin32pe.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygwin32pe-0.dll"
  )

list(APPEND _cmake_import_check_targets win32pe )
list(APPEND _cmake_import_check_files_for_win32pe "${_IMPORT_PREFIX}/lib/libwin32pe.dll.a" "${_IMPORT_PREFIX}/bin/cygwin32pe-0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
