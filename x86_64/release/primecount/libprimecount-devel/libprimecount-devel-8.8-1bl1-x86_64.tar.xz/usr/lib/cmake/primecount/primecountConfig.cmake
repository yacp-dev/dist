# ====================================================================
# The primecount CMake configuration file
#
# Usage from an external project:
#     In your CMakeLists.txt, add these lines:
#
#     find_package(primecount REQUIRED)
#     target_link_libraries(your_program primecount::primecount)
#
#     To link against the static libprimecount use:
#
#     find_package(primecount REQUIRED static)
#     target_link_libraries(your_program primecount::primecount)
#
#     Using the command above, if the static libprimecount is not
#     available then the shared libprimecount is used as a fallback.
#
# ====================================================================


####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was primecountConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

# Use original install prefix when loaded through a "/usr move"
# cross-prefix symbolic link such as /lib -> /usr/lib.
get_filename_component(_realCurr "${CMAKE_CURRENT_LIST_DIR}" REALPATH)
get_filename_component(_realOrig "/usr/lib/cmake/primecount" REALPATH)
if(_realCurr STREQUAL _realOrig)
  set(PACKAGE_PREFIX_DIR "/usr")
endif()
unset(_realOrig)
unset(_realCurr)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

# Nothing to do if primecount is included as a subdirectory in
# another project that uses CMake as its build system.
if(TARGET primecount::primecount)
    return()
endif()

if(OFF AND ON)
    if(primecount_FIND_COMPONENTS)
        string(TOLOWER "${primecount_FIND_COMPONENTS}" LOWER_COMPONENTS)
        if(LOWER_COMPONENTS STREQUAL "static")
            set(primecount_STATIC TRUE)
        endif()
    endif()
elseif(OFF)
    set(primecount_STATIC TRUE)
endif()

include(CMakeFindDependencyMacro)
find_dependency(primesieve QUIET REQUIRED)

if(primecount_STATIC AND "ON")
    find_dependency(OpenMP QUIET)
endif()

if(primecount_STATIC)
    include("${CMAKE_CURRENT_LIST_DIR}/primecountStatic.cmake")
    add_library(primecount::primecount INTERFACE IMPORTED)
    set_target_properties(primecount::primecount PROPERTIES INTERFACE_LINK_LIBRARIES "primecount::libprimecount-static")
else()
    include("${CMAKE_CURRENT_LIST_DIR}/primecountShared.cmake")
    add_library(primecount::primecount INTERFACE IMPORTED)
    set_target_properties(primecount::primecount PROPERTIES INTERFACE_LINK_LIBRARIES "primecount::libprimecount")
endif()
