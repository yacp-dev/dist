#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "libjson-rpc-cpp::jsonrpccommon" for configuration "RelWithDebInfo"
set_property(TARGET libjson-rpc-cpp::jsonrpccommon APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(libjson-rpc-cpp::jsonrpccommon PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libjsonrpccpp-common.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygjsonrpccpp-common-1.dll"
  )

list(APPEND _cmake_import_check_targets libjson-rpc-cpp::jsonrpccommon )
list(APPEND _cmake_import_check_files_for_libjson-rpc-cpp::jsonrpccommon "${_IMPORT_PREFIX}/lib/libjsonrpccpp-common.dll.a" "${_IMPORT_PREFIX}/bin/cygjsonrpccpp-common-1.dll" )

# Import target "libjson-rpc-cpp::jsonrpcclient" for configuration "RelWithDebInfo"
set_property(TARGET libjson-rpc-cpp::jsonrpcclient APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(libjson-rpc-cpp::jsonrpcclient PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libjsonrpccpp-client.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygjsonrpccpp-client-1.dll"
  )

list(APPEND _cmake_import_check_targets libjson-rpc-cpp::jsonrpcclient )
list(APPEND _cmake_import_check_files_for_libjson-rpc-cpp::jsonrpcclient "${_IMPORT_PREFIX}/lib/libjsonrpccpp-client.dll.a" "${_IMPORT_PREFIX}/bin/cygjsonrpccpp-client-1.dll" )

# Import target "libjson-rpc-cpp::jsonrpcserver" for configuration "RelWithDebInfo"
set_property(TARGET libjson-rpc-cpp::jsonrpcserver APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(libjson-rpc-cpp::jsonrpcserver PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libjsonrpccpp-server.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygjsonrpccpp-server-1.dll"
  )

list(APPEND _cmake_import_check_targets libjson-rpc-cpp::jsonrpcserver )
list(APPEND _cmake_import_check_files_for_libjson-rpc-cpp::jsonrpcserver "${_IMPORT_PREFIX}/lib/libjsonrpccpp-server.dll.a" "${_IMPORT_PREFIX}/bin/cygjsonrpccpp-server-1.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
