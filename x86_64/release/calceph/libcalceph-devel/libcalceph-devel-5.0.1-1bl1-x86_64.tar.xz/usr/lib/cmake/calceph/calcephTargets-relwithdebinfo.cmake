#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "calceph" for configuration "RelWithDebInfo"
set_property(TARGET calceph APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(calceph PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libcalceph.dll.a"
  )

list(APPEND _cmake_import_check_targets calceph )
list(APPEND _cmake_import_check_files_for_calceph "${_IMPORT_PREFIX}/lib/libcalceph.dll.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
