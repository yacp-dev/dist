# Hacking

This document describes how to start hacking on the libjaylink project.
Make sure you read through the [README](README.md) file before continuing.


## Coding style

This project uses the Linux kernel coding style where appropiate, see
<https://www.kernel.org/doc/Documentation/CodingStyle> for details.

Amendments to the Linux kernel coding style:

 - Do not use goto statements.
 - Always declare variables at the beginng of a function.
 - Do not assign values to variables at declaration time.


## Contributions

The following ways can be used to submit a contribution to the libjaylink
project:

 - Send patches generated with `git format-patch`.
 - Push your changes to a public Git repository and send the URL where to pull
   them from.

In any case, send directly to <dev@zapb.de>.
Before submitting, please consider the following:

 - Every single patch must be compilable.
 - Your contribution must work on all operating systems supported by
   libjaylink.
 - Develop your contribution against the current Git master branch.
 - Check your contribution for memory leaks and similar errors by using
   *valgrind*.

### Clang Static Analyzer

To ensure the code quality of your patches, you should test libjaylink using
Clang's static code analyzer.
This can be done with the following commands:

```sh
meson setup build-scanbuild
ninja scan-build -C build-scanbuild
```

Do not forget to install the corresponding package (e.g., `clang-analyzer`) on
your system, otherwise the invocation will fail with an error message that the
`scan-build` target is not found.


## Bug reports

Send bug reports directly to <dev@zapb.de>.
Please try to include all of the following information in your report:

 - Instructions to reproduce the bug (e.g., command-line invocations)
 - Debug log output of libjaylink
 - Information about your environment:
   - Version of libjaylink
   - Debug hardware, including hardware and firmware version (e.g.,
     J-Link Ultra V4 compiled Sep  4 2015 18:12:49)
   - Operating system (e.g., Debian GNU/Linux 8.4)
 - Backtraces if the application using libjaylink is crashing.

If the bug report is for a regression, additionally include the information
above about the working version where appropiate.

Please develop and attach a patch that solves the reported bug, if possible.
See the guidelines for contributions above.


## Random notes

 - Always use `log_err()`, `log_warn()`, `log_info()` and `log_dbg()` to output
   messages. Never use `printf()` or similar functions directly.
