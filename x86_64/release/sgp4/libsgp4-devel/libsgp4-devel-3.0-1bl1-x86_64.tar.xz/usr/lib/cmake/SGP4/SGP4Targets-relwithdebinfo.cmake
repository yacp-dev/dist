#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "SGP4::sgp4" for configuration "RelWithDebInfo"
set_property(TARGET SGP4::sgp4 APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(SGP4::sgp4 PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libsgp4.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygsgp4-3.dll"
  )

list(APPEND _cmake_import_check_targets SGP4::sgp4 )
list(APPEND _cmake_import_check_files_for_SGP4::sgp4 "${_IMPORT_PREFIX}/lib/libsgp4.dll.a" "${_IMPORT_PREFIX}/bin/cygsgp4-3.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
