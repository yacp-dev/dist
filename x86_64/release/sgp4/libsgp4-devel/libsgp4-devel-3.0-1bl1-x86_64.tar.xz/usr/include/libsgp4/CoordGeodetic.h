/*
 * Copyright 2013 Daniel Warner <contact@danrw.com>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#pragma once

#include "Util.h"

#include <iomanip>
#include <sstream>
#include <string>

namespace libsgp4
{

/**
 * @brief Stores a geodetic location (latitude, longitude, altitude).
 *
 * Internally the values are stored in radians and kilometres.
 */
struct CoordGeodetic
{
public:
    /**
     * Default constructor
     */
    CoordGeodetic() = default;

    /**
     * Constructor
     * @param[in] lat the latitude (degrees by default)
     * @param[in] lon the longitude (degrees by default)
     * @param[in] alt the altitude in kilometers
     * @param[in] isRadians whether the latitude/longitude is in radians
     */
    CoordGeodetic(double lat, double lon, double alt, bool isRadians = false)
    {
        if (isRadians)
        {
            latitude = lat;
            longitude = lon;
        }
        else
        {
            latitude = Util::DegreesToRadians(lat);
            longitude = Util::DegreesToRadians(lon);
        }
        altitude = alt;
    }

    /**
     * Dump this object to a string
     * @returns string
     */
    std::string ToString() const
    {
        std::stringstream ss;
        ss << std::right << std::fixed << std::setprecision(3);
        ss << "Lat: " << std::setw(8) << Util::RadiansToDegrees(latitude);
        ss << ", Lon: " << std::setw(8) << Util::RadiansToDegrees(longitude);
        ss << ", Alt: " << std::setw(10) << altitude;
        return ss.str();
    }

    /** latitude in radians (-PI >= latitude < PI) */
    double latitude{};
    /** latitude in radians (-PI/2 >= latitude <= PI/2) */
    double longitude{};
    /** altitude in kilometers */
    double altitude{};
};

/**
 * Dump a Coordgeodetic to a stream
 * @param[in,out] strm stream to output to
 * @param[in] g the CoordGeodetic to print
 */
inline std::ostream& operator<<(std::ostream& strm, const CoordGeodetic& g)
{
    return strm << g.ToString();
}

} // namespace libsgp4
