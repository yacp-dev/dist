#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "qrcodegencpp::qrcodegencpp" for configuration "RelWithDebInfo"
set_property(TARGET qrcodegencpp::qrcodegencpp APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(qrcodegencpp::qrcodegencpp PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libqrcodegencpp.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygqrcodegencpp-1.dll"
  )

list(APPEND _cmake_import_check_targets qrcodegencpp::qrcodegencpp )
list(APPEND _cmake_import_check_files_for_qrcodegencpp::qrcodegencpp "${_IMPORT_PREFIX}/lib/libqrcodegencpp.dll.a" "${_IMPORT_PREFIX}/bin/cygqrcodegencpp-1.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
