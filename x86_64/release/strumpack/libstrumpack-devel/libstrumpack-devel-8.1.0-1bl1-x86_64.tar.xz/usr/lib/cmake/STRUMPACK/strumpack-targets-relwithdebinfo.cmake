#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "STRUMPACK::strumpack" for configuration "RelWithDebInfo"
set_property(TARGET STRUMPACK::strumpack APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(STRUMPACK::strumpack PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libstrumpack.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygstrumpack-8.1.dll"
  )

list(APPEND _cmake_import_check_targets STRUMPACK::strumpack )
list(APPEND _cmake_import_check_files_for_STRUMPACK::strumpack "${_IMPORT_PREFIX}/lib/libstrumpack.dll.a" "${_IMPORT_PREFIX}/bin/cygstrumpack-8.1.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
