#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Mbd::mbd" for configuration "RelWithDebInfo"
set_property(TARGET Mbd::mbd APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(Mbd::mbd PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libmbd.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygmbd-0.dll"
  )

list(APPEND _cmake_import_check_targets Mbd::mbd )
list(APPEND _cmake_import_check_files_for_Mbd::mbd "${_IMPORT_PREFIX}/lib/libmbd.dll.a" "${_IMPORT_PREFIX}/bin/cygmbd-0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
