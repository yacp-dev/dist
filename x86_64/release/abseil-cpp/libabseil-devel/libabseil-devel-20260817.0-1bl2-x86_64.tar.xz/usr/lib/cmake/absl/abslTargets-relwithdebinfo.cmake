#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "absl::base_cpu_detect" for configuration "RelWithDebInfo"
set_property(TARGET absl::base_cpu_detect APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::base_cpu_detect PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_base_cpu_detect.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_base_cpu_detect-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::base_cpu_detect )
list(APPEND _cmake_import_check_files_for_absl::base_cpu_detect "${_IMPORT_PREFIX}/lib/libabsl_base_cpu_detect.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_base_cpu_detect-2608.0.0.dll" )

# Import target "absl::hardening" for configuration "RelWithDebInfo"
set_property(TARGET absl::hardening APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::hardening PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_hardening.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_hardening-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::hardening )
list(APPEND _cmake_import_check_files_for_absl::hardening "${_IMPORT_PREFIX}/lib/libabsl_hardening.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_hardening-2608.0.0.dll" )

# Import target "absl::log_severity" for configuration "RelWithDebInfo"
set_property(TARGET absl::log_severity APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::log_severity PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_log_severity.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_log_severity-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::log_severity )
list(APPEND _cmake_import_check_files_for_absl::log_severity "${_IMPORT_PREFIX}/lib/libabsl_log_severity.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_log_severity-2608.0.0.dll" )

# Import target "absl::raw_logging_internal" for configuration "RelWithDebInfo"
set_property(TARGET absl::raw_logging_internal APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::raw_logging_internal PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_raw_logging_internal.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_raw_logging_internal-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::raw_logging_internal )
list(APPEND _cmake_import_check_files_for_absl::raw_logging_internal "${_IMPORT_PREFIX}/lib/libabsl_raw_logging_internal.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_raw_logging_internal-2608.0.0.dll" )

# Import target "absl::spinlock_wait" for configuration "RelWithDebInfo"
set_property(TARGET absl::spinlock_wait APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::spinlock_wait PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_spinlock_wait.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_spinlock_wait-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::spinlock_wait )
list(APPEND _cmake_import_check_files_for_absl::spinlock_wait "${_IMPORT_PREFIX}/lib/libabsl_spinlock_wait.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_spinlock_wait-2608.0.0.dll" )

# Import target "absl::malloc_internal" for configuration "RelWithDebInfo"
set_property(TARGET absl::malloc_internal APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::malloc_internal PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_malloc_internal.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_malloc_internal-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::malloc_internal )
list(APPEND _cmake_import_check_files_for_absl::malloc_internal "${_IMPORT_PREFIX}/lib/libabsl_malloc_internal.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_malloc_internal-2608.0.0.dll" )

# Import target "absl::base" for configuration "RelWithDebInfo"
set_property(TARGET absl::base APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::base PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_base.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_base-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::base )
list(APPEND _cmake_import_check_files_for_absl::base "${_IMPORT_PREFIX}/lib/libabsl_base.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_base-2608.0.0.dll" )

# Import target "absl::throw_delegate" for configuration "RelWithDebInfo"
set_property(TARGET absl::throw_delegate APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::throw_delegate PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_throw_delegate.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_throw_delegate-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::throw_delegate )
list(APPEND _cmake_import_check_files_for_absl::throw_delegate "${_IMPORT_PREFIX}/lib/libabsl_throw_delegate.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_throw_delegate-2608.0.0.dll" )

# Import target "absl::exception_safety_testing" for configuration "RelWithDebInfo"
set_property(TARGET absl::exception_safety_testing APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::exception_safety_testing PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_exception_safety_testing.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_exception_safety_testing-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::exception_safety_testing )
list(APPEND _cmake_import_check_files_for_absl::exception_safety_testing "${_IMPORT_PREFIX}/lib/libabsl_exception_safety_testing.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_exception_safety_testing-2608.0.0.dll" )

# Import target "absl::atomic_hook_test_helper" for configuration "RelWithDebInfo"
set_property(TARGET absl::atomic_hook_test_helper APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::atomic_hook_test_helper PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_atomic_hook_test_helper.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_atomic_hook_test_helper-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::atomic_hook_test_helper )
list(APPEND _cmake_import_check_files_for_absl::atomic_hook_test_helper "${_IMPORT_PREFIX}/lib/libabsl_atomic_hook_test_helper.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_atomic_hook_test_helper-2608.0.0.dll" )

# Import target "absl::spinlock_test_common" for configuration "RelWithDebInfo"
set_property(TARGET absl::spinlock_test_common APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::spinlock_test_common PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_spinlock_test_common.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_spinlock_test_common-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::spinlock_test_common )
list(APPEND _cmake_import_check_files_for_absl::spinlock_test_common "${_IMPORT_PREFIX}/lib/libabsl_spinlock_test_common.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_spinlock_test_common-2608.0.0.dll" )

# Import target "absl::scoped_set_env" for configuration "RelWithDebInfo"
set_property(TARGET absl::scoped_set_env APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::scoped_set_env PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_scoped_set_env.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_scoped_set_env-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::scoped_set_env )
list(APPEND _cmake_import_check_files_for_absl::scoped_set_env "${_IMPORT_PREFIX}/lib/libabsl_scoped_set_env.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_scoped_set_env-2608.0.0.dll" )

# Import target "absl::strerror" for configuration "RelWithDebInfo"
set_property(TARGET absl::strerror APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::strerror PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_strerror.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_strerror-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::strerror )
list(APPEND _cmake_import_check_files_for_absl::strerror "${_IMPORT_PREFIX}/lib/libabsl_strerror.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_strerror-2608.0.0.dll" )

# Import target "absl::poison" for configuration "RelWithDebInfo"
set_property(TARGET absl::poison APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::poison PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_poison.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_poison-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::poison )
list(APPEND _cmake_import_check_files_for_absl::poison "${_IMPORT_PREFIX}/lib/libabsl_poison.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_poison-2608.0.0.dll" )

# Import target "absl::tracing_internal" for configuration "RelWithDebInfo"
set_property(TARGET absl::tracing_internal APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::tracing_internal PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_tracing_internal.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_tracing_internal-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::tracing_internal )
list(APPEND _cmake_import_check_files_for_absl::tracing_internal "${_IMPORT_PREFIX}/lib/libabsl_tracing_internal.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_tracing_internal-2608.0.0.dll" )

# Import target "absl::test_instance_tracker" for configuration "RelWithDebInfo"
set_property(TARGET absl::test_instance_tracker APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::test_instance_tracker PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_test_instance_tracker.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_test_instance_tracker-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::test_instance_tracker )
list(APPEND _cmake_import_check_files_for_absl::test_instance_tracker "${_IMPORT_PREFIX}/lib/libabsl_test_instance_tracker.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_test_instance_tracker-2608.0.0.dll" )

# Import target "absl::hash_generator_testing" for configuration "RelWithDebInfo"
set_property(TARGET absl::hash_generator_testing APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::hash_generator_testing PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_hash_generator_testing.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_hash_generator_testing-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::hash_generator_testing )
list(APPEND _cmake_import_check_files_for_absl::hash_generator_testing "${_IMPORT_PREFIX}/lib/libabsl_hash_generator_testing.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_hash_generator_testing-2608.0.0.dll" )

# Import target "absl::hashtablez_sampler" for configuration "RelWithDebInfo"
set_property(TARGET absl::hashtablez_sampler APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::hashtablez_sampler PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_hashtablez_sampler.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_hashtablez_sampler-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::hashtablez_sampler )
list(APPEND _cmake_import_check_files_for_absl::hashtablez_sampler "${_IMPORT_PREFIX}/lib/libabsl_hashtablez_sampler.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_hashtablez_sampler-2608.0.0.dll" )

# Import target "absl::raw_hash_set" for configuration "RelWithDebInfo"
set_property(TARGET absl::raw_hash_set APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::raw_hash_set PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_raw_hash_set.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_raw_hash_set-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::raw_hash_set )
list(APPEND _cmake_import_check_files_for_absl::raw_hash_set "${_IMPORT_PREFIX}/lib/libabsl_raw_hash_set.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_raw_hash_set-2608.0.0.dll" )

# Import target "absl::crc_internal" for configuration "RelWithDebInfo"
set_property(TARGET absl::crc_internal APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::crc_internal PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_crc_internal.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_crc_internal-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::crc_internal )
list(APPEND _cmake_import_check_files_for_absl::crc_internal "${_IMPORT_PREFIX}/lib/libabsl_crc_internal.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_crc_internal-2608.0.0.dll" )

# Import target "absl::crc32c" for configuration "RelWithDebInfo"
set_property(TARGET absl::crc32c APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::crc32c PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_crc32c.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_crc32c-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::crc32c )
list(APPEND _cmake_import_check_files_for_absl::crc32c "${_IMPORT_PREFIX}/lib/libabsl_crc32c.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_crc32c-2608.0.0.dll" )

# Import target "absl::crc_cord_state" for configuration "RelWithDebInfo"
set_property(TARGET absl::crc_cord_state APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::crc_cord_state PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_crc_cord_state.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_crc_cord_state-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::crc_cord_state )
list(APPEND _cmake_import_check_files_for_absl::crc_cord_state "${_IMPORT_PREFIX}/lib/libabsl_crc_cord_state.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_crc_cord_state-2608.0.0.dll" )

# Import target "absl::stacktrace" for configuration "RelWithDebInfo"
set_property(TARGET absl::stacktrace APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::stacktrace PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_stacktrace.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_stacktrace-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::stacktrace )
list(APPEND _cmake_import_check_files_for_absl::stacktrace "${_IMPORT_PREFIX}/lib/libabsl_stacktrace.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_stacktrace-2608.0.0.dll" )

# Import target "absl::symbolize" for configuration "RelWithDebInfo"
set_property(TARGET absl::symbolize APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::symbolize PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_symbolize.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_symbolize-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::symbolize )
list(APPEND _cmake_import_check_files_for_absl::symbolize "${_IMPORT_PREFIX}/lib/libabsl_symbolize.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_symbolize-2608.0.0.dll" )

# Import target "absl::examine_stack" for configuration "RelWithDebInfo"
set_property(TARGET absl::examine_stack APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::examine_stack PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_examine_stack.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_examine_stack-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::examine_stack )
list(APPEND _cmake_import_check_files_for_absl::examine_stack "${_IMPORT_PREFIX}/lib/libabsl_examine_stack.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_examine_stack-2608.0.0.dll" )

# Import target "absl::failure_signal_handler" for configuration "RelWithDebInfo"
set_property(TARGET absl::failure_signal_handler APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::failure_signal_handler PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_failure_signal_handler.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_failure_signal_handler-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::failure_signal_handler )
list(APPEND _cmake_import_check_files_for_absl::failure_signal_handler "${_IMPORT_PREFIX}/lib/libabsl_failure_signal_handler.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_failure_signal_handler-2608.0.0.dll" )

# Import target "absl::debugging_internal" for configuration "RelWithDebInfo"
set_property(TARGET absl::debugging_internal APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::debugging_internal PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_debugging_internal.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_debugging_internal-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::debugging_internal )
list(APPEND _cmake_import_check_files_for_absl::debugging_internal "${_IMPORT_PREFIX}/lib/libabsl_debugging_internal.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_debugging_internal-2608.0.0.dll" )

# Import target "absl::demangle_internal" for configuration "RelWithDebInfo"
set_property(TARGET absl::demangle_internal APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::demangle_internal PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_demangle_internal.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_demangle_internal-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::demangle_internal )
list(APPEND _cmake_import_check_files_for_absl::demangle_internal "${_IMPORT_PREFIX}/lib/libabsl_demangle_internal.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_demangle_internal-2608.0.0.dll" )

# Import target "absl::decode_rust_punycode" for configuration "RelWithDebInfo"
set_property(TARGET absl::decode_rust_punycode APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::decode_rust_punycode PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_decode_rust_punycode.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_decode_rust_punycode-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::decode_rust_punycode )
list(APPEND _cmake_import_check_files_for_absl::decode_rust_punycode "${_IMPORT_PREFIX}/lib/libabsl_decode_rust_punycode.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_decode_rust_punycode-2608.0.0.dll" )

# Import target "absl::demangle_rust" for configuration "RelWithDebInfo"
set_property(TARGET absl::demangle_rust APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::demangle_rust PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_demangle_rust.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_demangle_rust-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::demangle_rust )
list(APPEND _cmake_import_check_files_for_absl::demangle_rust "${_IMPORT_PREFIX}/lib/libabsl_demangle_rust.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_demangle_rust-2608.0.0.dll" )

# Import target "absl::utf8_for_code_point" for configuration "RelWithDebInfo"
set_property(TARGET absl::utf8_for_code_point APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::utf8_for_code_point PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_utf8_for_code_point.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_utf8_for_code_point-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::utf8_for_code_point )
list(APPEND _cmake_import_check_files_for_absl::utf8_for_code_point "${_IMPORT_PREFIX}/lib/libabsl_utf8_for_code_point.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_utf8_for_code_point-2608.0.0.dll" )

# Import target "absl::leak_check" for configuration "RelWithDebInfo"
set_property(TARGET absl::leak_check APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::leak_check PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_leak_check.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_leak_check-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::leak_check )
list(APPEND _cmake_import_check_files_for_absl::leak_check "${_IMPORT_PREFIX}/lib/libabsl_leak_check.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_leak_check-2608.0.0.dll" )

# Import target "absl::stack_consumption" for configuration "RelWithDebInfo"
set_property(TARGET absl::stack_consumption APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::stack_consumption PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_stack_consumption.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_stack_consumption-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::stack_consumption )
list(APPEND _cmake_import_check_files_for_absl::stack_consumption "${_IMPORT_PREFIX}/lib/libabsl_stack_consumption.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_stack_consumption-2608.0.0.dll" )

# Import target "absl::flags_program_name" for configuration "RelWithDebInfo"
set_property(TARGET absl::flags_program_name APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::flags_program_name PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_flags_program_name.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_flags_program_name-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::flags_program_name )
list(APPEND _cmake_import_check_files_for_absl::flags_program_name "${_IMPORT_PREFIX}/lib/libabsl_flags_program_name.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_flags_program_name-2608.0.0.dll" )

# Import target "absl::flags_config" for configuration "RelWithDebInfo"
set_property(TARGET absl::flags_config APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::flags_config PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_flags_config.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_flags_config-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::flags_config )
list(APPEND _cmake_import_check_files_for_absl::flags_config "${_IMPORT_PREFIX}/lib/libabsl_flags_config.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_flags_config-2608.0.0.dll" )

# Import target "absl::flags_marshalling" for configuration "RelWithDebInfo"
set_property(TARGET absl::flags_marshalling APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::flags_marshalling PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_flags_marshalling.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_flags_marshalling-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::flags_marshalling )
list(APPEND _cmake_import_check_files_for_absl::flags_marshalling "${_IMPORT_PREFIX}/lib/libabsl_flags_marshalling.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_flags_marshalling-2608.0.0.dll" )

# Import target "absl::flags_commandlineflag_internal" for configuration "RelWithDebInfo"
set_property(TARGET absl::flags_commandlineflag_internal APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::flags_commandlineflag_internal PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_flags_commandlineflag_internal.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_flags_commandlineflag_internal-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::flags_commandlineflag_internal )
list(APPEND _cmake_import_check_files_for_absl::flags_commandlineflag_internal "${_IMPORT_PREFIX}/lib/libabsl_flags_commandlineflag_internal.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_flags_commandlineflag_internal-2608.0.0.dll" )

# Import target "absl::flags_commandlineflag" for configuration "RelWithDebInfo"
set_property(TARGET absl::flags_commandlineflag APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::flags_commandlineflag PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_flags_commandlineflag.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_flags_commandlineflag-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::flags_commandlineflag )
list(APPEND _cmake_import_check_files_for_absl::flags_commandlineflag "${_IMPORT_PREFIX}/lib/libabsl_flags_commandlineflag.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_flags_commandlineflag-2608.0.0.dll" )

# Import target "absl::flags_private_handle_accessor" for configuration "RelWithDebInfo"
set_property(TARGET absl::flags_private_handle_accessor APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::flags_private_handle_accessor PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_flags_private_handle_accessor.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_flags_private_handle_accessor-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::flags_private_handle_accessor )
list(APPEND _cmake_import_check_files_for_absl::flags_private_handle_accessor "${_IMPORT_PREFIX}/lib/libabsl_flags_private_handle_accessor.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_flags_private_handle_accessor-2608.0.0.dll" )

# Import target "absl::flags_reflection" for configuration "RelWithDebInfo"
set_property(TARGET absl::flags_reflection APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::flags_reflection PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_flags_reflection.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_flags_reflection-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::flags_reflection )
list(APPEND _cmake_import_check_files_for_absl::flags_reflection "${_IMPORT_PREFIX}/lib/libabsl_flags_reflection.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_flags_reflection-2608.0.0.dll" )

# Import target "absl::flags_internal" for configuration "RelWithDebInfo"
set_property(TARGET absl::flags_internal APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::flags_internal PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_flags_internal.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_flags_internal-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::flags_internal )
list(APPEND _cmake_import_check_files_for_absl::flags_internal "${_IMPORT_PREFIX}/lib/libabsl_flags_internal.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_flags_internal-2608.0.0.dll" )

# Import target "absl::flags_usage_internal" for configuration "RelWithDebInfo"
set_property(TARGET absl::flags_usage_internal APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::flags_usage_internal PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_flags_usage_internal.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_flags_usage_internal-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::flags_usage_internal )
list(APPEND _cmake_import_check_files_for_absl::flags_usage_internal "${_IMPORT_PREFIX}/lib/libabsl_flags_usage_internal.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_flags_usage_internal-2608.0.0.dll" )

# Import target "absl::flags_usage" for configuration "RelWithDebInfo"
set_property(TARGET absl::flags_usage APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::flags_usage PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_flags_usage.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_flags_usage-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::flags_usage )
list(APPEND _cmake_import_check_files_for_absl::flags_usage "${_IMPORT_PREFIX}/lib/libabsl_flags_usage.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_flags_usage-2608.0.0.dll" )

# Import target "absl::flags_parse" for configuration "RelWithDebInfo"
set_property(TARGET absl::flags_parse APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::flags_parse PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_flags_parse.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_flags_parse-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::flags_parse )
list(APPEND _cmake_import_check_files_for_absl::flags_parse "${_IMPORT_PREFIX}/lib/libabsl_flags_parse.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_flags_parse-2608.0.0.dll" )

# Import target "absl::hash" for configuration "RelWithDebInfo"
set_property(TARGET absl::hash APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::hash PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_hash.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_hash-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::hash )
list(APPEND _cmake_import_check_files_for_absl::hash "${_IMPORT_PREFIX}/lib/libabsl_hash.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_hash-2608.0.0.dll" )

# Import target "absl::city" for configuration "RelWithDebInfo"
set_property(TARGET absl::city APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::city PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_city.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_city-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::city )
list(APPEND _cmake_import_check_files_for_absl::city "${_IMPORT_PREFIX}/lib/libabsl_city.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_city-2608.0.0.dll" )

# Import target "absl::log_internal_check_op" for configuration "RelWithDebInfo"
set_property(TARGET absl::log_internal_check_op APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::log_internal_check_op PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_log_internal_check_op.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_log_internal_check_op-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::log_internal_check_op )
list(APPEND _cmake_import_check_files_for_absl::log_internal_check_op "${_IMPORT_PREFIX}/lib/libabsl_log_internal_check_op.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_log_internal_check_op-2608.0.0.dll" )

# Import target "absl::log_internal_conditions" for configuration "RelWithDebInfo"
set_property(TARGET absl::log_internal_conditions APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::log_internal_conditions PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_log_internal_conditions.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_log_internal_conditions-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::log_internal_conditions )
list(APPEND _cmake_import_check_files_for_absl::log_internal_conditions "${_IMPORT_PREFIX}/lib/libabsl_log_internal_conditions.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_log_internal_conditions-2608.0.0.dll" )

# Import target "absl::log_internal_format" for configuration "RelWithDebInfo"
set_property(TARGET absl::log_internal_format APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::log_internal_format PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_log_internal_format.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_log_internal_format-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::log_internal_format )
list(APPEND _cmake_import_check_files_for_absl::log_internal_format "${_IMPORT_PREFIX}/lib/libabsl_log_internal_format.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_log_internal_format-2608.0.0.dll" )

# Import target "absl::log_internal_globals" for configuration "RelWithDebInfo"
set_property(TARGET absl::log_internal_globals APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::log_internal_globals PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_log_internal_globals.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_log_internal_globals-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::log_internal_globals )
list(APPEND _cmake_import_check_files_for_absl::log_internal_globals "${_IMPORT_PREFIX}/lib/libabsl_log_internal_globals.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_log_internal_globals-2608.0.0.dll" )

# Import target "absl::log_internal_proto" for configuration "RelWithDebInfo"
set_property(TARGET absl::log_internal_proto APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::log_internal_proto PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_log_internal_proto.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_log_internal_proto-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::log_internal_proto )
list(APPEND _cmake_import_check_files_for_absl::log_internal_proto "${_IMPORT_PREFIX}/lib/libabsl_log_internal_proto.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_log_internal_proto-2608.0.0.dll" )

# Import target "absl::log_internal_message" for configuration "RelWithDebInfo"
set_property(TARGET absl::log_internal_message APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::log_internal_message PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_log_internal_message.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_log_internal_message-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::log_internal_message )
list(APPEND _cmake_import_check_files_for_absl::log_internal_message "${_IMPORT_PREFIX}/lib/libabsl_log_internal_message.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_log_internal_message-2608.0.0.dll" )

# Import target "absl::log_internal_log_sink_set" for configuration "RelWithDebInfo"
set_property(TARGET absl::log_internal_log_sink_set APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::log_internal_log_sink_set PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_log_internal_log_sink_set.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_log_internal_log_sink_set-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::log_internal_log_sink_set )
list(APPEND _cmake_import_check_files_for_absl::log_internal_log_sink_set "${_IMPORT_PREFIX}/lib/libabsl_log_internal_log_sink_set.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_log_internal_log_sink_set-2608.0.0.dll" )

# Import target "absl::log_internal_nullguard" for configuration "RelWithDebInfo"
set_property(TARGET absl::log_internal_nullguard APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::log_internal_nullguard PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_log_internal_nullguard.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_log_internal_nullguard-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::log_internal_nullguard )
list(APPEND _cmake_import_check_files_for_absl::log_internal_nullguard "${_IMPORT_PREFIX}/lib/libabsl_log_internal_nullguard.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_log_internal_nullguard-2608.0.0.dll" )

# Import target "absl::log_internal_test_actions" for configuration "RelWithDebInfo"
set_property(TARGET absl::log_internal_test_actions APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::log_internal_test_actions PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_log_internal_test_actions.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_log_internal_test_actions-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::log_internal_test_actions )
list(APPEND _cmake_import_check_files_for_absl::log_internal_test_actions "${_IMPORT_PREFIX}/lib/libabsl_log_internal_test_actions.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_log_internal_test_actions-2608.0.0.dll" )

# Import target "absl::log_internal_test_helpers" for configuration "RelWithDebInfo"
set_property(TARGET absl::log_internal_test_helpers APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::log_internal_test_helpers PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_log_internal_test_helpers.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_log_internal_test_helpers-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::log_internal_test_helpers )
list(APPEND _cmake_import_check_files_for_absl::log_internal_test_helpers "${_IMPORT_PREFIX}/lib/libabsl_log_internal_test_helpers.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_log_internal_test_helpers-2608.0.0.dll" )

# Import target "absl::log_internal_test_matchers" for configuration "RelWithDebInfo"
set_property(TARGET absl::log_internal_test_matchers APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::log_internal_test_matchers PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_log_internal_test_matchers.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_log_internal_test_matchers-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::log_internal_test_matchers )
list(APPEND _cmake_import_check_files_for_absl::log_internal_test_matchers "${_IMPORT_PREFIX}/lib/libabsl_log_internal_test_matchers.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_log_internal_test_matchers-2608.0.0.dll" )

# Import target "absl::die_if_null" for configuration "RelWithDebInfo"
set_property(TARGET absl::die_if_null APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::die_if_null PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_die_if_null.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_die_if_null-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::die_if_null )
list(APPEND _cmake_import_check_files_for_absl::die_if_null "${_IMPORT_PREFIX}/lib/libabsl_die_if_null.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_die_if_null-2608.0.0.dll" )

# Import target "absl::log_flags" for configuration "RelWithDebInfo"
set_property(TARGET absl::log_flags APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::log_flags PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_log_flags.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_log_flags-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::log_flags )
list(APPEND _cmake_import_check_files_for_absl::log_flags "${_IMPORT_PREFIX}/lib/libabsl_log_flags.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_log_flags-2608.0.0.dll" )

# Import target "absl::log_globals" for configuration "RelWithDebInfo"
set_property(TARGET absl::log_globals APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::log_globals PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_log_globals.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_log_globals-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::log_globals )
list(APPEND _cmake_import_check_files_for_absl::log_globals "${_IMPORT_PREFIX}/lib/libabsl_log_globals.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_log_globals-2608.0.0.dll" )

# Import target "absl::log_initialize" for configuration "RelWithDebInfo"
set_property(TARGET absl::log_initialize APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::log_initialize PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_log_initialize.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_log_initialize-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::log_initialize )
list(APPEND _cmake_import_check_files_for_absl::log_initialize "${_IMPORT_PREFIX}/lib/libabsl_log_initialize.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_log_initialize-2608.0.0.dll" )

# Import target "absl::log_entry" for configuration "RelWithDebInfo"
set_property(TARGET absl::log_entry APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::log_entry PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_log_entry.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_log_entry-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::log_entry )
list(APPEND _cmake_import_check_files_for_absl::log_entry "${_IMPORT_PREFIX}/lib/libabsl_log_entry.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_log_entry-2608.0.0.dll" )

# Import target "absl::log_sink" for configuration "RelWithDebInfo"
set_property(TARGET absl::log_sink APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::log_sink PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_log_sink.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_log_sink-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::log_sink )
list(APPEND _cmake_import_check_files_for_absl::log_sink "${_IMPORT_PREFIX}/lib/libabsl_log_sink.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_log_sink-2608.0.0.dll" )

# Import target "absl::scoped_mock_log" for configuration "RelWithDebInfo"
set_property(TARGET absl::scoped_mock_log APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::scoped_mock_log PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_scoped_mock_log.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_scoped_mock_log-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::scoped_mock_log )
list(APPEND _cmake_import_check_files_for_absl::scoped_mock_log "${_IMPORT_PREFIX}/lib/libabsl_scoped_mock_log.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_scoped_mock_log-2608.0.0.dll" )

# Import target "absl::log_internal_structured_proto" for configuration "RelWithDebInfo"
set_property(TARGET absl::log_internal_structured_proto APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::log_internal_structured_proto PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_log_internal_structured_proto.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_log_internal_structured_proto-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::log_internal_structured_proto )
list(APPEND _cmake_import_check_files_for_absl::log_internal_structured_proto "${_IMPORT_PREFIX}/lib/libabsl_log_internal_structured_proto.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_log_internal_structured_proto-2608.0.0.dll" )

# Import target "absl::vlog_config_internal" for configuration "RelWithDebInfo"
set_property(TARGET absl::vlog_config_internal APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::vlog_config_internal PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_vlog_config_internal.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_vlog_config_internal-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::vlog_config_internal )
list(APPEND _cmake_import_check_files_for_absl::vlog_config_internal "${_IMPORT_PREFIX}/lib/libabsl_vlog_config_internal.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_vlog_config_internal-2608.0.0.dll" )

# Import target "absl::log_internal_fnmatch" for configuration "RelWithDebInfo"
set_property(TARGET absl::log_internal_fnmatch APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::log_internal_fnmatch PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_log_internal_fnmatch.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_log_internal_fnmatch-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::log_internal_fnmatch )
list(APPEND _cmake_import_check_files_for_absl::log_internal_fnmatch "${_IMPORT_PREFIX}/lib/libabsl_log_internal_fnmatch.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_log_internal_fnmatch-2608.0.0.dll" )

# Import target "absl::int128" for configuration "RelWithDebInfo"
set_property(TARGET absl::int128 APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::int128 PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_int128.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_int128-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::int128 )
list(APPEND _cmake_import_check_files_for_absl::int128 "${_IMPORT_PREFIX}/lib/libabsl_int128.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_int128-2608.0.0.dll" )

# Import target "absl::exponential_biased" for configuration "RelWithDebInfo"
set_property(TARGET absl::exponential_biased APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::exponential_biased PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_exponential_biased.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_exponential_biased-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::exponential_biased )
list(APPEND _cmake_import_check_files_for_absl::exponential_biased "${_IMPORT_PREFIX}/lib/libabsl_exponential_biased.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_exponential_biased-2608.0.0.dll" )

# Import target "absl::periodic_sampler" for configuration "RelWithDebInfo"
set_property(TARGET absl::periodic_sampler APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::periodic_sampler PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_periodic_sampler.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_periodic_sampler-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::periodic_sampler )
list(APPEND _cmake_import_check_files_for_absl::periodic_sampler "${_IMPORT_PREFIX}/lib/libabsl_periodic_sampler.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_periodic_sampler-2608.0.0.dll" )

# Import target "absl::profile_builder" for configuration "RelWithDebInfo"
set_property(TARGET absl::profile_builder APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::profile_builder PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_profile_builder.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_profile_builder-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::profile_builder )
list(APPEND _cmake_import_check_files_for_absl::profile_builder "${_IMPORT_PREFIX}/lib/libabsl_profile_builder.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_profile_builder-2608.0.0.dll" )

# Import target "absl::hashtable_profiler" for configuration "RelWithDebInfo"
set_property(TARGET absl::hashtable_profiler APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::hashtable_profiler PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_hashtable_profiler.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_hashtable_profiler-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::hashtable_profiler )
list(APPEND _cmake_import_check_files_for_absl::hashtable_profiler "${_IMPORT_PREFIX}/lib/libabsl_hashtable_profiler.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_hashtable_profiler-2608.0.0.dll" )

# Import target "absl::random_distributions" for configuration "RelWithDebInfo"
set_property(TARGET absl::random_distributions APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::random_distributions PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_random_distributions.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_random_distributions-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::random_distributions )
list(APPEND _cmake_import_check_files_for_absl::random_distributions "${_IMPORT_PREFIX}/lib/libabsl_random_distributions.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_random_distributions-2608.0.0.dll" )

# Import target "absl::random_seed_gen_exception" for configuration "RelWithDebInfo"
set_property(TARGET absl::random_seed_gen_exception APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::random_seed_gen_exception PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_random_seed_gen_exception.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_random_seed_gen_exception-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::random_seed_gen_exception )
list(APPEND _cmake_import_check_files_for_absl::random_seed_gen_exception "${_IMPORT_PREFIX}/lib/libabsl_random_seed_gen_exception.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_random_seed_gen_exception-2608.0.0.dll" )

# Import target "absl::random_seed_sequences" for configuration "RelWithDebInfo"
set_property(TARGET absl::random_seed_sequences APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::random_seed_sequences PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_random_seed_sequences.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_random_seed_sequences-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::random_seed_sequences )
list(APPEND _cmake_import_check_files_for_absl::random_seed_sequences "${_IMPORT_PREFIX}/lib/libabsl_random_seed_sequences.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_random_seed_sequences-2608.0.0.dll" )

# Import target "absl::random_internal_seed_material" for configuration "RelWithDebInfo"
set_property(TARGET absl::random_internal_seed_material APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::random_internal_seed_material PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_random_internal_seed_material.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_random_internal_seed_material-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::random_internal_seed_material )
list(APPEND _cmake_import_check_files_for_absl::random_internal_seed_material "${_IMPORT_PREFIX}/lib/libabsl_random_internal_seed_material.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_random_internal_seed_material-2608.0.0.dll" )

# Import target "absl::random_internal_entropy_pool" for configuration "RelWithDebInfo"
set_property(TARGET absl::random_internal_entropy_pool APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::random_internal_entropy_pool PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_random_internal_entropy_pool.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_random_internal_entropy_pool-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::random_internal_entropy_pool )
list(APPEND _cmake_import_check_files_for_absl::random_internal_entropy_pool "${_IMPORT_PREFIX}/lib/libabsl_random_internal_entropy_pool.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_random_internal_entropy_pool-2608.0.0.dll" )

# Import target "absl::random_internal_platform" for configuration "RelWithDebInfo"
set_property(TARGET absl::random_internal_platform APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::random_internal_platform PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_random_internal_platform.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_random_internal_platform-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::random_internal_platform )
list(APPEND _cmake_import_check_files_for_absl::random_internal_platform "${_IMPORT_PREFIX}/lib/libabsl_random_internal_platform.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_random_internal_platform-2608.0.0.dll" )

# Import target "absl::random_internal_randen" for configuration "RelWithDebInfo"
set_property(TARGET absl::random_internal_randen APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::random_internal_randen PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_random_internal_randen.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_random_internal_randen-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::random_internal_randen )
list(APPEND _cmake_import_check_files_for_absl::random_internal_randen "${_IMPORT_PREFIX}/lib/libabsl_random_internal_randen.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_random_internal_randen-2608.0.0.dll" )

# Import target "absl::random_internal_randen_slow" for configuration "RelWithDebInfo"
set_property(TARGET absl::random_internal_randen_slow APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::random_internal_randen_slow PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_random_internal_randen_slow.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_random_internal_randen_slow-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::random_internal_randen_slow )
list(APPEND _cmake_import_check_files_for_absl::random_internal_randen_slow "${_IMPORT_PREFIX}/lib/libabsl_random_internal_randen_slow.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_random_internal_randen_slow-2608.0.0.dll" )

# Import target "absl::random_internal_randen_hwaes" for configuration "RelWithDebInfo"
set_property(TARGET absl::random_internal_randen_hwaes APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::random_internal_randen_hwaes PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_random_internal_randen_hwaes.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_random_internal_randen_hwaes-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::random_internal_randen_hwaes )
list(APPEND _cmake_import_check_files_for_absl::random_internal_randen_hwaes "${_IMPORT_PREFIX}/lib/libabsl_random_internal_randen_hwaes.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_random_internal_randen_hwaes-2608.0.0.dll" )

# Import target "absl::random_internal_randen_hwaes_impl" for configuration "RelWithDebInfo"
set_property(TARGET absl::random_internal_randen_hwaes_impl APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::random_internal_randen_hwaes_impl PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_random_internal_randen_hwaes_impl.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_random_internal_randen_hwaes_impl-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::random_internal_randen_hwaes_impl )
list(APPEND _cmake_import_check_files_for_absl::random_internal_randen_hwaes_impl "${_IMPORT_PREFIX}/lib/libabsl_random_internal_randen_hwaes_impl.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_random_internal_randen_hwaes_impl-2608.0.0.dll" )

# Import target "absl::random_internal_distribution_test_util" for configuration "RelWithDebInfo"
set_property(TARGET absl::random_internal_distribution_test_util APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::random_internal_distribution_test_util PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_random_internal_distribution_test_util.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_random_internal_distribution_test_util-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::random_internal_distribution_test_util )
list(APPEND _cmake_import_check_files_for_absl::random_internal_distribution_test_util "${_IMPORT_PREFIX}/lib/libabsl_random_internal_distribution_test_util.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_random_internal_distribution_test_util-2608.0.0.dll" )

# Import target "absl::status" for configuration "RelWithDebInfo"
set_property(TARGET absl::status APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::status PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_status.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_status-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::status )
list(APPEND _cmake_import_check_files_for_absl::status "${_IMPORT_PREFIX}/lib/libabsl_status.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_status-2608.0.0.dll" )

# Import target "absl::statusor" for configuration "RelWithDebInfo"
set_property(TARGET absl::statusor APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::statusor PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_statusor.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_statusor-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::statusor )
list(APPEND _cmake_import_check_files_for_absl::statusor "${_IMPORT_PREFIX}/lib/libabsl_statusor.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_statusor-2608.0.0.dll" )

# Import target "absl::status_builder" for configuration "RelWithDebInfo"
set_property(TARGET absl::status_builder APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::status_builder PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_status_builder.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_status_builder-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::status_builder )
list(APPEND _cmake_import_check_files_for_absl::status_builder "${_IMPORT_PREFIX}/lib/libabsl_status_builder.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_status_builder-2608.0.0.dll" )

# Import target "absl::status_matchers" for configuration "RelWithDebInfo"
set_property(TARGET absl::status_matchers APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::status_matchers PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_status_matchers.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_status_matchers-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::status_matchers )
list(APPEND _cmake_import_check_files_for_absl::status_matchers "${_IMPORT_PREFIX}/lib/libabsl_status_matchers.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_status_matchers-2608.0.0.dll" )

# Import target "absl::strings" for configuration "RelWithDebInfo"
set_property(TARGET absl::strings APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::strings PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_strings.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_strings-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::strings )
list(APPEND _cmake_import_check_files_for_absl::strings "${_IMPORT_PREFIX}/lib/libabsl_strings.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_strings-2608.0.0.dll" )

# Import target "absl::strings_internal" for configuration "RelWithDebInfo"
set_property(TARGET absl::strings_internal APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::strings_internal PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_strings_internal.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_strings_internal-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::strings_internal )
list(APPEND _cmake_import_check_files_for_absl::strings_internal "${_IMPORT_PREFIX}/lib/libabsl_strings_internal.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_strings_internal-2608.0.0.dll" )

# Import target "absl::str_format_internal" for configuration "RelWithDebInfo"
set_property(TARGET absl::str_format_internal APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::str_format_internal PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_str_format_internal.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_str_format_internal-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::str_format_internal )
list(APPEND _cmake_import_check_files_for_absl::str_format_internal "${_IMPORT_PREFIX}/lib/libabsl_str_format_internal.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_str_format_internal-2608.0.0.dll" )

# Import target "absl::pow10_helper" for configuration "RelWithDebInfo"
set_property(TARGET absl::pow10_helper APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::pow10_helper PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_pow10_helper.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_pow10_helper-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::pow10_helper )
list(APPEND _cmake_import_check_files_for_absl::pow10_helper "${_IMPORT_PREFIX}/lib/libabsl_pow10_helper.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_pow10_helper-2608.0.0.dll" )

# Import target "absl::cord_internal" for configuration "RelWithDebInfo"
set_property(TARGET absl::cord_internal APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::cord_internal PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_cord_internal.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_cord_internal-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::cord_internal )
list(APPEND _cmake_import_check_files_for_absl::cord_internal "${_IMPORT_PREFIX}/lib/libabsl_cord_internal.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_cord_internal-2608.0.0.dll" )

# Import target "absl::cordz_functions" for configuration "RelWithDebInfo"
set_property(TARGET absl::cordz_functions APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::cordz_functions PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_cordz_functions.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_cordz_functions-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::cordz_functions )
list(APPEND _cmake_import_check_files_for_absl::cordz_functions "${_IMPORT_PREFIX}/lib/libabsl_cordz_functions.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_cordz_functions-2608.0.0.dll" )

# Import target "absl::cordz_handle" for configuration "RelWithDebInfo"
set_property(TARGET absl::cordz_handle APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::cordz_handle PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_cordz_handle.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_cordz_handle-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::cordz_handle )
list(APPEND _cmake_import_check_files_for_absl::cordz_handle "${_IMPORT_PREFIX}/lib/libabsl_cordz_handle.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_cordz_handle-2608.0.0.dll" )

# Import target "absl::cordz_info" for configuration "RelWithDebInfo"
set_property(TARGET absl::cordz_info APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::cordz_info PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_cordz_info.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_cordz_info-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::cordz_info )
list(APPEND _cmake_import_check_files_for_absl::cordz_info "${_IMPORT_PREFIX}/lib/libabsl_cordz_info.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_cordz_info-2608.0.0.dll" )

# Import target "absl::cordz_sample_token" for configuration "RelWithDebInfo"
set_property(TARGET absl::cordz_sample_token APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::cordz_sample_token PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_cordz_sample_token.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_cordz_sample_token-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::cordz_sample_token )
list(APPEND _cmake_import_check_files_for_absl::cordz_sample_token "${_IMPORT_PREFIX}/lib/libabsl_cordz_sample_token.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_cordz_sample_token-2608.0.0.dll" )

# Import target "absl::cord" for configuration "RelWithDebInfo"
set_property(TARGET absl::cord APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::cord PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_cord.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_cord-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::cord )
list(APPEND _cmake_import_check_files_for_absl::cord "${_IMPORT_PREFIX}/lib/libabsl_cord.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_cord-2608.0.0.dll" )

# Import target "absl::generic_printer_internal" for configuration "RelWithDebInfo"
set_property(TARGET absl::generic_printer_internal APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::generic_printer_internal PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_generic_printer_internal.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_generic_printer_internal-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::generic_printer_internal )
list(APPEND _cmake_import_check_files_for_absl::generic_printer_internal "${_IMPORT_PREFIX}/lib/libabsl_generic_printer_internal.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_generic_printer_internal-2608.0.0.dll" )

# Import target "absl::graphcycles_internal" for configuration "RelWithDebInfo"
set_property(TARGET absl::graphcycles_internal APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::graphcycles_internal PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_graphcycles_internal.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_graphcycles_internal-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::graphcycles_internal )
list(APPEND _cmake_import_check_files_for_absl::graphcycles_internal "${_IMPORT_PREFIX}/lib/libabsl_graphcycles_internal.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_graphcycles_internal-2608.0.0.dll" )

# Import target "absl::kernel_timeout_internal" for configuration "RelWithDebInfo"
set_property(TARGET absl::kernel_timeout_internal APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::kernel_timeout_internal PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_kernel_timeout_internal.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_kernel_timeout_internal-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::kernel_timeout_internal )
list(APPEND _cmake_import_check_files_for_absl::kernel_timeout_internal "${_IMPORT_PREFIX}/lib/libabsl_kernel_timeout_internal.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_kernel_timeout_internal-2608.0.0.dll" )

# Import target "absl::synchronization" for configuration "RelWithDebInfo"
set_property(TARGET absl::synchronization APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::synchronization PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_synchronization.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_synchronization-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::synchronization )
list(APPEND _cmake_import_check_files_for_absl::synchronization "${_IMPORT_PREFIX}/lib/libabsl_synchronization.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_synchronization-2608.0.0.dll" )

# Import target "absl::per_thread_sem_test_common" for configuration "RelWithDebInfo"
set_property(TARGET absl::per_thread_sem_test_common APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::per_thread_sem_test_common PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_per_thread_sem_test_common.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_per_thread_sem_test_common-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::per_thread_sem_test_common )
list(APPEND _cmake_import_check_files_for_absl::per_thread_sem_test_common "${_IMPORT_PREFIX}/lib/libabsl_per_thread_sem_test_common.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_per_thread_sem_test_common-2608.0.0.dll" )

# Import target "absl::time" for configuration "RelWithDebInfo"
set_property(TARGET absl::time APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::time PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_time.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_time-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::time )
list(APPEND _cmake_import_check_files_for_absl::time "${_IMPORT_PREFIX}/lib/libabsl_time.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_time-2608.0.0.dll" )

# Import target "absl::civil_time" for configuration "RelWithDebInfo"
set_property(TARGET absl::civil_time APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::civil_time PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_civil_time.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_civil_time-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::civil_time )
list(APPEND _cmake_import_check_files_for_absl::civil_time "${_IMPORT_PREFIX}/lib/libabsl_civil_time.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_civil_time-2608.0.0.dll" )

# Import target "absl::time_zone" for configuration "RelWithDebInfo"
set_property(TARGET absl::time_zone APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::time_zone PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_time_zone.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_time_zone-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::time_zone )
list(APPEND _cmake_import_check_files_for_absl::time_zone "${_IMPORT_PREFIX}/lib/libabsl_time_zone.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_time_zone-2608.0.0.dll" )

# Import target "absl::time_internal_test_util" for configuration "RelWithDebInfo"
set_property(TARGET absl::time_internal_test_util APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::time_internal_test_util PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_time_internal_test_util.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_time_internal_test_util-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::time_internal_test_util )
list(APPEND _cmake_import_check_files_for_absl::time_internal_test_util "${_IMPORT_PREFIX}/lib/libabsl_time_internal_test_util.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_time_internal_test_util-2608.0.0.dll" )

# Import target "absl::clock_interface" for configuration "RelWithDebInfo"
set_property(TARGET absl::clock_interface APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::clock_interface PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_clock_interface.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_clock_interface-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::clock_interface )
list(APPEND _cmake_import_check_files_for_absl::clock_interface "${_IMPORT_PREFIX}/lib/libabsl_clock_interface.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_clock_interface-2608.0.0.dll" )

# Import target "absl::simulated_clock" for configuration "RelWithDebInfo"
set_property(TARGET absl::simulated_clock APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::simulated_clock PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_simulated_clock.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_simulated_clock-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::simulated_clock )
list(APPEND _cmake_import_check_files_for_absl::simulated_clock "${_IMPORT_PREFIX}/lib/libabsl_simulated_clock.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_simulated_clock-2608.0.0.dll" )

# Import target "absl::source_location" for configuration "RelWithDebInfo"
set_property(TARGET absl::source_location APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(absl::source_location PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libabsl_source_location.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygabsl_source_location-2608.0.0.dll"
  )

list(APPEND _cmake_import_check_targets absl::source_location )
list(APPEND _cmake_import_check_files_for_absl::source_location "${_IMPORT_PREFIX}/lib/libabsl_source_location.dll.a" "${_IMPORT_PREFIX}/bin/cygabsl_source_location-2608.0.0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
