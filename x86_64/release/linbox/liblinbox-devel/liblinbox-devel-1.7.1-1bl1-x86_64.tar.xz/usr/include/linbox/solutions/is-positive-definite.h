/* Copyright (C) 2010 LinBox
 *
 *
 * ========LICENCE========
 * This file is part of the library LinBox.
 *
  * LinBox is free software: you can redistribute it and/or modify
 * it under the terms of the  GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	 See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 * ========LICENCE========
 */

#ifndef __LINBOX_is_positive_definite_H
#define __LINBOX_is_positive_definite_H

#include "linbox/util/error.h"
#include "linbox/algorithms/matrix-hom.h"
#include "linbox/algorithms/signature.h"

namespace LinBox
{
	// for specialization with respect to the DomainCategory
	template< class Blackbox, class isPositiveDefiniteMethod, class DomainCategory>
	bool isPositiveDefinite (
				 const Blackbox        &A,
				 const DomainCategory  &tag,
				 const isPositiveDefiniteMethod  &M);

	/** Compute the isPositiveDefinite of A.
	 *
	 * The isPositiveDefinite of a linear operator A, represented as a
	 * black box, is computed over the ring or field of A.
	 *
	 * @param A Black box of which to compute the isPositiveDefinite
	 * @param M may be a Method::Auto (default), Method::Blackbox, Method::Elimination, or of other method type.
	 \ingroup isPositiveDefinites
	 */
	template <class Blackbox, class MyMethod>
	bool isPositiveDefinite (
				 const Blackbox                              &A,
				 const MyMethod                           &M)
	{
		return isPositiveDefinite( A, typename FieldTraits<typename Blackbox::Field>::categoryTag(), M);
	}

	// The isPositiveDefinite with default Method
	template<class Blackbox>
	bool isPositiveDefinite ( const Blackbox  &A)
	{
		return isPositiveDefinite(A,
					  Method::Auto());
	}

	// The isPositiveDefinite for ModularTag (is nonsense)
	template<class Blackbox, class MyMethod>
	bool isPositiveDefinite (
				 const Blackbox                            &A,
				 const RingCategories::ModularTag          &tag,
				 const MyMethod& M)
	{
		//commentator << "nonsense!!"
		throw (LinboxError("isPositiveDefinite: Integer matrix required"));
		return false;
	}

	// The isPositiveDefinite with Auto Method
	template<class Blackbox>
	bool isPositiveDefinite (
				 const Blackbox 			&A,
				 const RingCategories::IntegerTag          &tag,
				 const Method::Auto& M)
	{
		//! @bug should try a modular minpoly and decide on the degree of that...
		if (A.rowdim() != A.coldim())
		       	return false;
		//! @bug this crude size check can be refined
		if (A.coldim() > 7000)
		       	return isPositiveDefinite(A, tag, Method::Blackbox(M));
		else
		       	return isPositiveDefinite(A, tag, Method::Elimination(M));
	}

	// The isPositiveDefinite with Elimination Method
	template<class Blackbox>
	bool isPositiveDefinite (
				 const Blackbox                            &A,
				 const RingCategories::IntegerTag          &tag,
				 const Method::Elimination& M)
	{
		// this can be a hybrid of EliminationMinpoly and DenseElimination (which means use LU here)
		// It will be faster to do EliminationMinpoly when deg(m_A) is low.

		// right now it is just DenseElimination
		return isPositiveDefinite(A, tag, Method::DenseElimination(M));
	}

	// The isPositiveDefinite with BlackBox Method
	template<class Blackbox>
	bool isPositiveDefinite (
				 const Blackbox                      &A,
				 const RingCategories::IntegerTag    &tag,
				 const Method::Blackbox              &M)
	{
		return isPositiveDefinite(A, tag, Method::Wiedemann(M));
	}


	// The isPositiveDefinite with Wiedemann, finite field.
	template <class Blackbox>
	bool isPositiveDefinite (
				 const Blackbox                      &A,
				 const RingCategories::IntegerTag    &tag,
				 const Method::Wiedemann             &M)
	{
		// call Wiedemann code
		return Signature::isPosDef(A, Signature::Minpoly_Method() );
	}

	// the isPositiveDefinite with Blas.
	template <class Blackbox>
	bool isPositiveDefinite (
				 const Blackbox                      &A,
				 const RingCategories::IntegerTag    &tag,
				 const Method::DenseElimination       &M)
	{
		// call DenseElimination code
		BlasMatrix<typename Blackbox::Field> DA(A.field(), A.rowdim(), A.coldim());
		MatrixHom::map(DA, A); //! @bug why map (same field)? This is a copy.
		return Signature::isPosDef(DA, Signature::BLAS_LPM_Method() );
	}

	template <class Ring>
	bool isPositiveDefinite (
				 const BlasMatrix<Ring> &A,
				 const RingCategories::IntegerTag    &tag,
				 const Method::DenseElimination       &M)
	{
		// call DenseElimination code
		return Signature::isPosDef(A, Signature::BLAS_LPM_Method() );
	}


} // end of LinBox namespace

#endif // __LINBOX_is_positive_definite_H

// Local Variables:
// mode: C++
// tab-width: 4
// indent-tabs-mode: nil
// c-basic-offset: 4
// End:
// vim:sts=4:sw=4:ts=4:et:sr:cino=>s,f0,{0,g0,(0,\:0,t0,+0,=s
