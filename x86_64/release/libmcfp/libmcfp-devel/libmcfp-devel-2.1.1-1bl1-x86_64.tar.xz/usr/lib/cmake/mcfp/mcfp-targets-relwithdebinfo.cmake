#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "mcfp::mcfp" for configuration "RelWithDebInfo"
set_property(TARGET mcfp::mcfp APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(mcfp::mcfp PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libmcfp.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygmcfp-2.dll"
  )

list(APPEND _cmake_import_check_targets mcfp::mcfp )
list(APPEND _cmake_import_check_files_for_mcfp::mcfp "${_IMPORT_PREFIX}/lib/libmcfp.dll.a" "${_IMPORT_PREFIX}/bin/cygmcfp-2.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
