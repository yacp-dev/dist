/*
 * This project is licensed under the MIT license. For more information see the
 * LICENSE file.
 */
#pragma once

#include <stdint.h>

// -----------------------------------------------------------------------------

namespace maddy {

// -----------------------------------------------------------------------------

namespace types {

// clang-format off
/**
 * PARSER_TYPE
 *
 * Bitwise flags to turn on/off each parser
*/
enum PARSER_TYPE : uint32_t
{
  NONE                     = 0,

  BREAKLINE_PARSER         = 0b1,
  CHECKLIST_PARSER         = 0b10,
  CODE_BLOCK_PARSER        = 0b100,
  EMPHASIZED_PARSER        = 0b1000,
  HEADLINE_PARSER          = 0b10000,
  HORIZONTAL_LINE_PARSER   = 0b100000,
  HTML_PARSER              = 0b1000000,
  IMAGE_PARSER             = 0b10000000,
  INLINE_CODE_PARSER       = 0b100000000,
  ITALIC_PARSER            = 0b1000000000,
  LINK_PARSER              = 0b10000000000,
  ORDERED_LIST_PARSER      = 0b100000000000,
  PARAGRAPH_PARSER         = 0b1000000000000,
  QUOTE_PARSER             = 0b10000000000000,
  STRIKETHROUGH_PARSER     = 0b100000000000000,
  STRONG_PARSER            = 0b1000000000000000,
  TABLE_PARSER             = 0b10000000000000000,
  UNORDERED_LIST_PARSER    = 0b100000000000000000,
  LATEX_BLOCK_PARSER       = 0b1000000000000000000,

  // Not a parser of its own: gates maddy's own historical markdown dialect
  // wherever a parser supports both that and a more standard alternative
  // (currently just TableParser's `|table>` syntax vs. GFM pipe tables).
  MADDY_SPECIFIC_PARSER    = 0b10000000000000000000,

  DEFAULT                  = 0b10111111111110111111,
  ALL                      = 0b11111111111111111111,
};
// clang-format on

} // namespace types

/**
 * ParserConfig
 *
 * @class
 */
struct ParserConfig
{
  /**
   * en-/disable headline inline-parsing
   *
   * default: enabled
   */
  bool isHeadlineInlineParsingEnabled;

  /**
   * enabled parsers bitfield
   */
  uint32_t enabledParsers;

  ParserConfig()
    : isHeadlineInlineParsingEnabled(true)
    , enabledParsers(maddy::types::DEFAULT)
  {}
}; // class ParserConfig

// -----------------------------------------------------------------------------

} // namespace maddy
