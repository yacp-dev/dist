#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "TCI::tci" for configuration "RelWithDebInfo"
set_property(TARGET TCI::tci APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(TCI::tci PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libtci.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygtci-0.dll"
  )

list(APPEND _cmake_import_check_targets TCI::tci )
list(APPEND _cmake_import_check_files_for_TCI::tci "${_IMPORT_PREFIX}/lib/libtci.dll.a" "${_IMPORT_PREFIX}/bin/cygtci-0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
