/*
 * Library:   lmfit (Levenberg-Marquardt least squares fitting)
 *
 * File:      lmmin.h
 *
 * Contents:  Declarations for Levenberg-Marquardt minimization.
 *
 * Copyright: Joachim Wuttke, Forschungszentrum Juelich GmbH (2004-2018)
 *
 * License:   see ../COPYING (FreeBSD)
 *
 * Homepage:  https://jugit.fz-juelich.de/mlz/lmfit
 */

#ifndef LMMIN_H
#define LMMIN_H

#include "lmstruct.h"

__BEGIN_DECLS

/* Levenberg-Marquardt minimization, with error estimates. */
LM_DLL void lmmin3(
    const int n_par, double *const par, double *const parerr,
    double *const covar, const int scale_cov, const int m_dat,
    const double *const y, const void *const data,
    void (*const evaluate)(
        const double *const par, const int m_dat, const void *const data,
        double *const fvec, int *const userbreak),
    const lm_control_struct *const control, lm_status_struct *const status);
/*
 *   This routine contains the core algorithm of our library.
 *
 *   It minimizes the sum of the squares of m nonlinear functions
 *   in n variables by a modified Levenberg-Marquardt algorithm.
 *   The function evaluation is done by the user-provided routine 'evaluate'.
 *   The Jacobian is then calculated by a forward-difference approximation.
 *
 *   Parameters:
 *
 *      n_par is the number of variables (INPUT, positive integer).
 *
 *      par is the solution vector (INPUT/OUTPUT, array of length n).
 *        On input it must be set to an estimated solution.
 *        On output it yields the final estimate of the solution.
 *
 *      parerr (either NULL or OUTPUT array of length n)
 *        yields parameter uncertainties,
 *          parerr[j] = sqrt(covar[j*n+j]),
 *        in the convention selected by scale_cov.
 *
 *      covar (either NULL or OUTPUT array of length n*n)
 *        yields the parameter covariance matrix, computed from a
 *        finite-difference Jacobian J at the solution, in the convention
 *        selected by scale_cov.
 *
 *      scale_cov (INPUT) selects the convention, i.e. the assumption about
 *        the errors of the data relative to which the uncertainties are
 *        defined. There are two, and no default is defensible for both:
 *
 *        scale_cov==0, trusted sigma:
 *            covar = (J^T J)^-1
 *          Correct if the residuals returned by evaluate are already divided
 *          by the standard deviations of the data, as lmcurve3 does by
 *          dividing by dy. This is the convention of MINPACK's covar.f and
 *          of GSL's gsl_multifit_covar. Use it if you trust the error bars
 *          of your data.
 *
 *        scale_cov!=0, inferred sigma:
 *            covar = (J^T J)^-1 * s2,  where s2 = fnorm^2/(m-n)
 *          Correct if the scale of the data errors is unknown and is to be
 *          deduced from the residuals themselves, under the assumption that
 *          the model is correct. Here m-n is the number of degrees of
 *          freedom, and s2, reported as status->s2, is the reduced
 *          chi-squared if the residuals are weighted. This is what
 *          scipy.optimize.curve_fit does by default (absolute_sigma=False),
 *          and what gnuplot's fit and the summaries of R's nls report. Use
 *          it if you only trust the relative magnitudes of your error bars.
 *
 *        Since status->s2 is reported either way, a caller can convert:
 *          parerr[j] = sqrt(covar[j*n+j])                for trusted sigma,
 *          parerr[j] = sqrt(covar[j*n+j] * status->s2)   for inferred sigma.
 *
 *      m_dat is the number of functions to be minimized (INPUT, integer).
 *        It must fulfill m>=n.
 *
 *      y contains data to be fitted. Use a null pointer if there are no data.
 *
 *      data is a pointer that is ignored by lmmin; it is however forwarded
 *        to the user-supplied functions evaluate and printout.
 *        In a typical application, it contains experimental data to be fitted.
 *
 *      evaluate is a user-supplied function that calculates the m functions.
 *        Parameters:
 *          n, x, m, data as above.
 *          fvec is an array of length m; on OUTPUT, it must contain the
 *            m function values for the parameter vector x.
 *          userbreak is an integer pointer. When *userbreak is set to a
 *            nonzero value, lmmin will terminate.
 *
 *      control contains INPUT variables that control the fit algorithm,
 *        as declared and explained in lmstruct.h
 *
 *      status contains OUTPUT variables that inform about the fit result,
 *        as declared and explained in lmstruct.h
 *
 *   parerr and covar are set to zero if no error estimate can be obtained,
 *   which is the case if the sum of squares underflows, if evaluate fails
 *   during the finite differencing, or if the curvature matrix is singular.
 */

/* Simple API, without error estimates. Maintained, not obsolescent. */
LM_DLL void lmmin(
    const int n_par, double *const par, const int m_dat, const double *const y,
    const void *const data,
    void (*const evaluate)(
        const double *const par, const int m_dat, const void *const data,
        double *const fvec, int *const userbreak),
    const lm_control_struct *const control, lm_status_struct *const status);

/* OBSOLESCENT, may be withdrawn in lmfit 13; use lmmin3 instead.
 *
 * lmmin2 predates the distinction of the two conventions above, and mixes
 * them: it returns the raw inverse curvature matrix in covar, but scales
 * parerr by the residual variance,
 *     covar[j*n+k] = (J^T J)^-1[j][k]
 *     parerr[j]    = sqrt(covar[j*n+j] * status->s2)
 * so that parerr != sqrt(diag(covar)). Which of the two outputs is the one
 * you want therefore cannot be answered without knowing the sigma
 * convention of your residuals, and the pair as a whole is right under
 * neither. It is preserved unchanged, and no migration reproduces both
 * outputs at once: scale_cov=1 reproduces this parerr, scale_cov=0 this
 * covar. See lmmin2(3) for the full account.
 */
LM_DLL void lmmin2(
    const int n_par, double *const par, double *const parerr,
    double *const covar, const int m_dat, const double *const y,
    const void *const data,
    void (*const evaluate)(
        const double *const par, const int m_dat, const void *const data,
        double *const fvec, int *const userbreak),
    const lm_control_struct *const control, lm_status_struct *const status);

/* Refined calculation of Eucledian norm. */
LM_DLL double lm_enorm(const int, const double *const);
LM_DLL double lm_fnorm(const int, const double *const, const double *const);

/* Internal, exported for test/run_qr */
LM_DLL void lm_qrfac(
    const int m, const int n, double *const A, int *const Pivot,
    double *const Rdiag, double *const Acnorm, double *const W);

__END_DECLS
#endif /* LMMIN_H */
