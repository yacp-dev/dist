/*
 * Library:   lmfit (Levenberg-Marquardt least squares fitting)
 *
 * File:      lmcurve2.h
 *
 * Contents:  Declares lmcurve2(), a variant of lmcurve() that weighs
 *            data points y(t) with the inverse of the standard deviations dy.
 *
 * Copyright: Joachim Wuttke, Forschungszentrum Juelich GmbH (2004-2013)
 *
 * License:   see ../COPYING (FreeBSD)
 *
 * Homepage:  https://jugit.fz-juelich.de/mlz/lmfit
 */

#ifndef LMCURVETYD_H
#define LMCURVETYD_H

#include "lmstruct.h"

__BEGIN_DECLS

/* OBSOLESCENT, may be withdrawn in lmfit 13; use lmcurve3 instead.
 *
 * lmcurve2 predates the distinction of the two conventions for parameter
 * uncertainties that lmmin.h explains. It implements the first of them, and
 * offers no way to request the second:
 *     covar[j*n_par+k] = (J^T J)^-1[j][k]
 *     parerr[j]        = sqrt(covar[j*n_par+j])
 * which is correct if the dy are the standard deviations of the data, and
 * silently wrong if they are known only up to a common factor. Note also
 * that its parerr does not mean the same as lmmin2's, which carries an
 * additional factor sqrt(status->s2).
 *
 * The results are those of lmcurve3 with scale_cov=0, and are preserved
 * unchanged. See lmcurve2(3) for the full account.
 */
LM_DLL void lmcurve2(
    const int n_par, double* par, double* parerr, double* covar,
    const int m_dat, const double* t, const double* y, const double* dy,
    double (*f)(double t, const double* par),
    const lm_control_struct* control, lm_status_struct* status);

__END_DECLS
#endif /* LMCURVETYD_H */
