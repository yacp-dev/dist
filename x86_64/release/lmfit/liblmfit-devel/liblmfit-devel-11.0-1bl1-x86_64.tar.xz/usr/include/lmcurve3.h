/*
 * Library:   lmfit (Levenberg-Marquardt least squares fitting)
 *
 * File:      lmcurve3.h
 *
 * Contents:  Declares lmcurve3(), a variant of lmcurve() that weighs
 *            data points y(t) with the inverse of the standard deviations dy,
 *            and returns parameter uncertainties and the covariance matrix.
 *
 * Copyright: Joachim Wuttke, Forschungszentrum Juelich GmbH (2004-2026)
 *
 * License:   see ../COPYING (FreeBSD)
 *
 * Homepage:  https://jugit.fz-juelich.de/mlz/lmfit
 *
 * Note to programmers: Don't patch and fork, but copy and variate!
 *   If you need to compute residues differently, then please do not patch
 * this file, but copy it to a differently named file, and change lmcurve3()
 * into a differently named function declaration.
 */

#ifndef LMCURVE3_H
#define LMCURVE3_H

#include "lmstruct.h"

__BEGIN_DECLS

LM_DLL void lmcurve3(
    const int n_par, double* par, double* parerr, double* covar,
    const int scale_cov, const int m_dat, const double* t, const double* y,
    const double* dy, double (*f)(double t, const double* par),
    const lm_control_struct* control, lm_status_struct* status);
/*
 *   Fits the curve f(t;par) to the data (t,y,dy) by minimizing the sum of
 *   the squares of the residues (y[i]-f(t[i];par))/dy[i].
 *
 *   All arguments are forwarded to lmmin3, which is where parerr, covar,
 *   scale_cov, control and status are documented. In particular:
 *
 *     scale_cov==0 (trusted sigma) is the appropriate setting if the dy are
 *       the standard deviations of the data. Since the residues are divided
 *       by dy here, covar is then the inverse curvature matrix (J^T J)^-1
 *       as it stands, and parerr[j] = sqrt(covar[j*n_par+j]) the uncertainty
 *       of par[j] for the weighted model.
 *
 *     scale_cov!=0 (inferred sigma) is the appropriate setting if only the
 *       relative magnitudes of the dy are trusted; covar and parerr^2 are
 *       then multiplied by the reduced chi-squared status->s2.
 *
 *   Either way parerr[j] == sqrt(covar[j*n_par+j]).
 *
 *   Users must ensure that all dy[i] are positive.
 */

__END_DECLS
#endif /* LMCURVE3_H */
