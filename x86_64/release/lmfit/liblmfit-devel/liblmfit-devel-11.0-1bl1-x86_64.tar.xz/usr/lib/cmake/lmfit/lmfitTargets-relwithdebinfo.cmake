#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "lmfit::lmfit" for configuration "RelWithDebInfo"
set_property(TARGET lmfit::lmfit APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(lmfit::lmfit PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/liblmfit.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cyglmfit-11.dll"
  )

list(APPEND _cmake_import_check_targets lmfit::lmfit )
list(APPEND _cmake_import_check_files_for_lmfit::lmfit "${_IMPORT_PREFIX}/lib/liblmfit.dll.a" "${_IMPORT_PREFIX}/bin/cyglmfit-11.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
