/*******************************************************************************
* Copyright 2020 Intel Corporation
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*******************************************************************************/

/// @file
/// Threadpool Interoperability C++ Types

#ifndef ONEAPI_DNNL_DNNL_THREADPOOL_IFACE_HPP
#define ONEAPI_DNNL_DNNL_THREADPOOL_IFACE_HPP
// NOLINTBEGIN(readability-identifier-naming)

#include <cstdint>
#include <functional>
#include <memory>

namespace dnnl {

/// @addtogroup dnnl_api_cpp
/// @{

/// @addtogroup dnnl_api_cpp_interop
/// @{

/// @addtogroup dnnl_api_cpp_threadpool_interop
/// @{

namespace threadpool_interop {

/// Completion event interface for async threadpool work. oneDNN's verbose
/// profiler polls these to determine when deferred execution has finished
/// and to extract timing information.
struct threadpool_event_iface_t {
    virtual ~threadpool_event_iface_t() = default;
    /// Returns true if the associated work has completed.
    virtual bool is_complete() const = 0;
    /// Blocks until completion.
    virtual void wait() const = 0;
    /// Measured execution time in milliseconds. Valid only after completion.
    /// Should reflect wall-clock duration from when the first worker begins
    /// to when the last worker finishes. Use a compare-and-swap atomic
    /// operation to stamp the start time so only the first worker records
    /// the asynchronous completion callback once all workers have finished.
    virtual double exec_time_ms() const = 0;
};

/// Abstract threadpool interface. The users are expected to subclass this
/// interface and pass an object to the library during CPU stream creation or
/// directly in case of BLAS functions.
struct threadpool_iface {
    /// Returns the number of worker threads.
    virtual int get_num_threads() const = 0;

    /// Returns true if the calling thread belongs to this threadpool.
    virtual bool get_in_parallel() const = 0;

    /// Submits n instances of a closure for execution in parallel:
    ///
    /// for (int i = 0; i < n; i++) fn(i, n);
    ///
    virtual void parallel_for(int n, const std::function<void(int, int)> &fn)
            = 0;

    /// Returns threadpool behavior flags bit mask (see below).
    virtual uint64_t get_flags() const = 0;

    // Does nothing if SYNCHRONOUS, waits for all jobs for ASYNCHRONOUS
    virtual void wait() = 0;

    /// If set, parallel_for() returns immediately and oneDNN needs implement
    /// waiting for the submitted closures to finish execution on its own.
    static constexpr uint64_t ASYNCHRONOUS = 1;

    virtual ~threadpool_iface() = default;

    /// Returns a single completion event for the most recently submitted
    /// primitive dispatch, or nullptr if profiling is disabled or
    /// unsupported.
    ///
    /// Implementations should lazily create the event in parallel_for() and
    /// move it out here, registering an asynchronous completion callback to
    /// be called once all workers have finished. This ensures exec_time_ms()
    /// is valid when is_complete() returns `true`.
    virtual std::shared_ptr<threadpool_event_iface_t> get_event() {
        return nullptr;
    }
};

} // namespace threadpool_interop

/// @} dnnl_api_cpp_threadpool_interop

/// @} dnnl_api_cpp_interop

/// @} dnnl_api_cpp

} // namespace dnnl

// NOLINTEND(readability-identifier-naming)
#endif /* ONEAPI_DNNL_DNNL_THREADPOOL_IFACE_HPP */
