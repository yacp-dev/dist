#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "zlog::zlog" for configuration "RelWithDebInfo"
set_property(TARGET zlog::zlog APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(zlog::zlog PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libzlog.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygzlog-1.2.dll"
  )

list(APPEND _cmake_import_check_targets zlog::zlog )
list(APPEND _cmake_import_check_files_for_zlog::zlog "${_IMPORT_PREFIX}/lib/libzlog.dll.a" "${_IMPORT_PREFIX}/bin/cygzlog-1.2.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
