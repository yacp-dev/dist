/*
 * This file is a part of hildon
 *
 * Copyright (C) 2005, 2006, 2007 Nokia Corporation, all rights reserved.
 *
 * Contact: Michael Dominic Kostrzewa <michael.kostrzewa@nokia.com>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA
 *
 */

/**
 * SECTION:hildon-version
 * @short_description: Versioning utility macros
 *
 * Hildon offers a set of macros for checking the version of the library
 * an application was linked to.
 */

#ifndef                                         __HILDON_VERSION_H__
#define                                         __HILDON_VERSION_H__

/**
 * HILDON_MAJOR_VERSION:
 *
 * The major version of the Hildon library (1, if %HILDON_VERSION is 1.2.3)
 */
#define HILDON_MAJOR_VERSION				    (2)

/**
 * HILDON_MINOR_VERSION:
 *
 * The minor version of the Hildon library (2, if %HILDON_VERSION is 1.2.3)
 */
#define HILDON_MINOR_VERSION				    (2)

/**
 * HILDON_MICRO_VERSION:
 *
 * The micro version of the Hildon library (3, if %HILDON_VERSION is 1.2.3)
 */
#define HILDON_MICRO_VERSION				    (30)

/**
 * HILDON_VERSION:
 *
 * The full version of the Hildon library, like 1.2.3
 */
#define HILDON_VERSION                                      (2.2.30)

/**
 * HILDON_CHECK_VERSION:
 * @major: major version, like 1 in 1.2.3
 * @minor: minor version, like 2 in 1.2.3
 * @micro: micro version, like 3 in 1.2.3
 *
 * Evaluates to %TRUE if the version of the Hildon library is greater
 * than @major, @minor and @micro
 */
#define	HILDON_CHECK_VERSION(major,minor,micro)	\
    (HILDON_MAJOR_VERSION > (major) || \
     (HILDON_MAJOR_VERSION == (major) && HILDON_MINOR_VERSION > (minor)) || \
     (HILDON_MAJOR_VERSION == (major) && HILDON_MINOR_VERSION == (minor) && \
      HILDON_MICRO_VERSION >= (micro)))

#endif                                          /* __HILDON_VERSION_H__ */

