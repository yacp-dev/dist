#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Orcania::Orcania" for configuration "RelWithDebInfo"
set_property(TARGET Orcania::Orcania APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(Orcania::Orcania PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/liborcania.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygorcania-2.3.dll"
  )

list(APPEND _cmake_import_check_targets Orcania::Orcania )
list(APPEND _cmake_import_check_files_for_Orcania::Orcania "${_IMPORT_PREFIX}/lib/liborcania.dll.a" "${_IMPORT_PREFIX}/bin/cygorcania-2.3.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
