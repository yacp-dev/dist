//============================================================================
//  Copyright (c) Kitware, Inc.
//  All rights reserved.
//  See LICENSE.txt for details.
//  This software is distributed WITHOUT ANY WARRANTY; without even
//  the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
//  PURPOSE.  See the above copyright notice for more information.
//
//============================================================================

#ifndef fides_thirdparty_rapidjson_h
#define fides_thirdparty_rapidjson_h

#define FIDES_USE_EXTERNAL_RAPIDJSON 1

#if FIDES_USE_EXTERNAL_RAPIDJSON
#  define FIDES_RAPIDJSON(header) <header>
#else
#  define FIDES_RAPIDJSON(header) <fidesrapidjson/include/header>
#  define rapidjson fidesrapidjson
#endif

#endif
