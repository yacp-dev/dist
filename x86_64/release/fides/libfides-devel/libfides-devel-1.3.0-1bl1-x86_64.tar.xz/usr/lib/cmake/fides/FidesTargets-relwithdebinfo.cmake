#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "fides" for configuration "RelWithDebInfo"
set_property(TARGET fides APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(fides PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libfides.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygfides-1.dll"
  )

list(APPEND _cmake_import_check_targets fides )
list(APPEND _cmake_import_check_files_for_fides "${_IMPORT_PREFIX}/lib/libfides.dll.a" "${_IMPORT_PREFIX}/bin/cygfides-1.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
