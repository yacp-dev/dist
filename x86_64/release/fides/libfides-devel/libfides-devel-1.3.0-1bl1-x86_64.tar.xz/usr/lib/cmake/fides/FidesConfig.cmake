cmake_minimum_required(VERSION 3.9 FATAL_ERROR)


####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was Config.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

# Use original install prefix when loaded through a "/usr move"
# cross-prefix symbolic link such as /lib -> /usr/lib.
get_filename_component(_realCurr "${CMAKE_CURRENT_LIST_DIR}" REALPATH)
get_filename_component(_realOrig "/usr/lib/cmake/fides" REALPATH)
if(_realCurr STREQUAL _realOrig)
  set(PACKAGE_PREFIX_DIR "/usr")
endif()
unset(_realOrig)
unset(_realCurr)

####################################################################################

set(FIDES_VERSION_MAJOR "0")
set(FIDES_VERSION_MINOR "1")

# This is true when the package is still in the build directory (not installed)
if(CMAKE_CURRENT_LIST_DIR STREQUAL "/cygdrive/d/a/dist/dist/yacp/fides/fides-1.3.0-1bl1.x86_64/build")
  set(FIDES_PACKAGE_IN_BUILD TRUE)
endif()

if(FIDES_PACKAGE_IN_BUILD)
  # we can hint on where to find viskores as we are in the build directory
  set(Viskores_DIR "/usr/lib/cmake/viskores")
  set(ADIOS2_DIR "/usr/lib/cmake/adios2")
endif()

# lets see if we can cache the Viskores location
find_package(Viskores REQUIRED QUIET)

# lets see if we can cache the ADIOS2 location
find_package(ADIOS2 REQUIRED QUIET)

if(FIDES_PACKAGE_IN_BUILD)
  include ( "${CMAKE_CURRENT_LIST_DIR}/fides/FidesTargets.cmake" )
else()
  include ( "${CMAKE_CURRENT_LIST_DIR}/FidesTargets.cmake" )
endif()
