#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "OpenZL::openzl" for configuration "RelWithDebInfo"
set_property(TARGET OpenZL::openzl APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(OpenZL::openzl PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libopenzl.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygopenzl-0.dll"
  )

list(APPEND _cmake_import_check_targets OpenZL::openzl )
list(APPEND _cmake_import_check_files_for_OpenZL::openzl "${_IMPORT_PREFIX}/lib/libopenzl.dll.a" "${_IMPORT_PREFIX}/bin/cygopenzl-0.dll" )

# Import target "OpenZL::openzl_cpp" for configuration "RelWithDebInfo"
set_property(TARGET OpenZL::openzl_cpp APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(OpenZL::openzl_cpp PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libopenzl_cpp.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygopenzl_cpp-0.dll"
  )

list(APPEND _cmake_import_check_targets OpenZL::openzl_cpp )
list(APPEND _cmake_import_check_files_for_OpenZL::openzl_cpp "${_IMPORT_PREFIX}/lib/libopenzl_cpp.dll.a" "${_IMPORT_PREFIX}/bin/cygopenzl_cpp-0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
