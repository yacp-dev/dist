# Copyright (c) Meta Platforms, Inc. and affiliates.

# CMake configuration file for openzl
#
# This provides the OpenZL::openzl and OpenZL::openzl_cpp targets, which you
# can depend on by adding it to your target_link_libraries().
#
# It also defines the following variables, although using these directly is not
# necessary if you use the OpenZL::openzl or OpenZL::openzl_cpp target instead.
#  OPENZL_INCLUDE_DIR
#  OPENZL_LIBRARIES


####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was openzl-config.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

# Use original install prefix when loaded through a "/usr move"
# cross-prefix symbolic link such as /lib -> /usr/lib.
get_filename_component(_realCurr "${CMAKE_CURRENT_LIST_DIR}" REALPATH)
get_filename_component(_realOrig "/usr/lib/cmake/openzl" REALPATH)
if(_realCurr STREQUAL _realOrig)
  set(PACKAGE_PREFIX_DIR "/usr")
endif()
unset(_realOrig)
unset(_realCurr)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

include(CMakeFindDependencyMacro)

set_and_check(OPENZL_INCLUDE_DIR "${PACKAGE_PREFIX_DIR}/include")
set_and_check(OPENZL_CMAKE_DIR "${PACKAGE_PREFIX_DIR}/lib/cmake/openzl")

# find_dependency() ends up changing PACKAGE_PREFIX_DIR, so save
# openzl's prefix directory in the OPENZL_PREFIX_DIR variable
set(OPENZL_PREFIX_DIR "${PACKAGE_PREFIX_DIR}")

# Include the openzl-targets.cmake file, which is generated from our CMake rules
if (NOT TARGET OpenZL::openzl)
  include("${OPENZL_CMAKE_DIR}/openzl-targets.cmake")
endif()

# Set OPENZL_LIBRARIES from our OpenZL::openzl targets
set(OPENZL_LIBRARIES OpenZL::openzl)
if (TARGET OpenZL::openzl_cpp)
  set(OPENZL_LIBRARIES ${OPENZL_LIBRARIES} OpenZL::openzl_cpp)
endif()

if (NOT openzl_FIND_QUIETLY)
  message(STATUS "Found openzl: ${OPENZL_PREFIX_DIR}")
endif()
