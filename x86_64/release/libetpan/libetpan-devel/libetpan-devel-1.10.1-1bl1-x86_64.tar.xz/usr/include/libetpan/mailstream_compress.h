/*
 * libEtPan! -- a mail stuff library
 *
 * Copyright (C) 2001, 2013 - DINH Viet Hoa
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the libEtPan! project nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHORS AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

/*  Created by Ian Ragsdale on 3/8/13. */

#ifndef MAILSTREAM_COMPRESS_H
#define MAILSTREAM_COMPRESS_H

#define USE_DEFLATE 1

#include <libetpan/mailstream.h>

#ifdef __cplusplus
extern "C" {
#endif
    
extern mailstream_low_driver * mailstream_compress_driver;

struct mailstream_compress_context;

/* exported methods */
LIBETPAN_EXPORT
mailstream_low * mailstream_low_compress_open(mailstream_low * ms);

LIBETPAN_EXPORT
int mailstream_low_compress_wait_idle(mailstream_low * low,
                                      struct mailstream_cancel * idle,
                                      int max_idle_delay);

  /*
LIBETPAN_EXPORT
int mailstream_low_compress_setup_idle(mailstream_low * low);

LIBETPAN_EXPORT
int mailstream_low_compress_unsetup_idle(mailstream_low * low);

LIBETPAN_EXPORT
int mailstream_low_compress_interrupt_idle(mailstream_low * low);
*/
  
#ifdef __cplusplus
}
#endif
#endif
