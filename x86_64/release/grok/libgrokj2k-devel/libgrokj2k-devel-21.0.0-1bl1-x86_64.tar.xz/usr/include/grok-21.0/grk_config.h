/* Grok Version */
#define GRK_VERSION_MAJOR 21
#define GRK_VERSION_MINOR 0
#define GRK_VERSION_BUILD 0

/* Feature flags */
/* #undef GRK_ENABLE_LIBCURL */
#ifdef GRK_ENABLE_LIBCURL
#define GRK_HAS_LIBCURL 1
#endif
