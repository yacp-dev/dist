#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "GROK::grk_decompress" for configuration "RelWithDebInfo"
set_property(TARGET GROK::grk_decompress APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(GROK::grk_decompress PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/grk_decompress.exe"
  )

list(APPEND _cmake_import_check_targets GROK::grk_decompress )
list(APPEND _cmake_import_check_files_for_GROK::grk_decompress "${_IMPORT_PREFIX}/bin/grk_decompress.exe" )

# Import target "GROK::grk_compress" for configuration "RelWithDebInfo"
set_property(TARGET GROK::grk_compress APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(GROK::grk_compress PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/grk_compress.exe"
  )

list(APPEND _cmake_import_check_targets GROK::grk_compress )
list(APPEND _cmake_import_check_files_for_GROK::grk_compress "${_IMPORT_PREFIX}/bin/grk_compress.exe" )

# Import target "GROK::grk_dump" for configuration "RelWithDebInfo"
set_property(TARGET GROK::grk_dump APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(GROK::grk_dump PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/grk_dump.exe"
  )

list(APPEND _cmake_import_check_targets GROK::grk_dump )
list(APPEND _cmake_import_check_files_for_GROK::grk_dump "${_IMPORT_PREFIX}/bin/grk_dump.exe" )

# Import target "GROK::grk_transcode" for configuration "RelWithDebInfo"
set_property(TARGET GROK::grk_transcode APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(GROK::grk_transcode PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/grk_transcode.exe"
  )

list(APPEND _cmake_import_check_targets GROK::grk_transcode )
list(APPEND _cmake_import_check_files_for_GROK::grk_transcode "${_IMPORT_PREFIX}/bin/grk_transcode.exe" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
