#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "GROK::grokj2k" for configuration "RelWithDebInfo"
set_property(TARGET GROK::grokj2k APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(GROK::grokj2k PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libgrokj2k.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cyggrokj2k-2.dll"
  )

list(APPEND _cmake_import_check_targets GROK::grokj2k )
list(APPEND _cmake_import_check_files_for_GROK::grokj2k "${_IMPORT_PREFIX}/lib/libgrokj2k.dll.a" "${_IMPORT_PREFIX}/bin/cyggrokj2k-2.dll" )

# Import target "GROK::grokj2kcodec" for configuration "RelWithDebInfo"
set_property(TARGET GROK::grokj2kcodec APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(GROK::grokj2kcodec PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libgrokj2kcodec.dll.a"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELWITHDEBINFO "GROK::grokj2k"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cyggrokj2kcodec-2.dll"
  )

list(APPEND _cmake_import_check_targets GROK::grokj2kcodec )
list(APPEND _cmake_import_check_files_for_GROK::grokj2kcodec "${_IMPORT_PREFIX}/lib/libgrokj2kcodec.dll.a" "${_IMPORT_PREFIX}/bin/cyggrokj2kcodec-2.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
