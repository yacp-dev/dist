/* config/config.h.  Generated from config.h.in by configure.  */
/* config/config.h.in.  Generated from configure.ac by autoheader.  */


/******************************************************************************
*                                                                             *
* Copyright (c) 2007      -- Université de Antilles et de la Guyane           *
* Copyright (c) 2007-2008 -- Institut National de Recherche en Informatique   *
*                            et en Automatique                                *
* Copyright (c) 2008-2026 -- LIRMM/CNRS/UM                                    *
*                            (Laboratoire d'Informatique, de Robotique et de  *
*                            Microélectronique de Montpellier /               *
*                            Centre National de la Recherche Scientifique /   *
*                            Université de Montpellier)                       *
*                                                                             *
*  Auteurs/Authors: Alban MANCHERON  <alban.mancheron@lirmm.fr>               *
*                                                                             *
*  Programmeurs/Programmers:                                                  *
*                   Alban MANCHERON  <alban.mancheron@lirmm.fr>               *
*                                                                             *
*  -------------------------------------------------------------------------  *
*                                                                             *
* This File (which initially comes from StatiSTARS) is part of the C++        *
* ProgressBar library.                                                        *
*                                                                             *
* This library is free software; you can redistribute it and/or modify it     *
* under the terms of the GNU Library General Public License as published by   *
* the Free Software Foundation; either version 2 of the License, or (at your  *
* option) any later version.                                                  *
*                                                                             *
* This library is distributed in the hope that it will be useful, but WITHOUT *
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or       *
* FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Library General Public       *
* License for more details.                                                   *
*                                                                             *
* You should have received a copy of the GNU Library General Public License   *
* along with this library; if not, write:                                     *
*                                                                             *
*                    the Free Software Foundation, Inc.,                      *
*                    59 Temple Place - Suite 330,                             *
*                    Boston, MA  02111-1307, USA.                             *
*                                                                             *
******************************************************************************/

#ifndef __LIBPROGRESSBAR_CONFIG_H__
#define __LIBPROGRESSBAR_CONFIG_H__


/* Define to 1 if using 'alloca.c'. */
/* #undef C_ALLOCA */

/* Enables debug */
/* #undef DEBUG */

/* Define to 1 if you have 'alloca', as a function or macro. */
#define HAVE_ALLOCA 1

/* Define to 1 if <alloca.h> works. */
#define HAVE_ALLOCA_H 1

/* Define to 1 if you have the <dlfcn.h> header file. */
#define HAVE_DLFCN_H 1

/* Define to 1 if you have the <fcntl.h> header file. */
#define HAVE_FCNTL_H 1

/* Define to 1 if you have the 'gettimeofday' function. */
#define HAVE_GETTIMEOFDAY 1

/* Define to 1 if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* Define to 1 if you have the <memory.h> header file. */
#define HAVE_MEMORY_H 1

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if you have the <stdio.h> header file. */
#define HAVE_STDIO_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if you have the 'strtoul' function. */
#define HAVE_STRTOUL 1

/* Define to 1 if 'st_blocks' is a member of 'struct stat'. */
#define HAVE_STRUCT_STAT_ST_BLOCKS 1

/* Define to 1 if your 'struct stat' has 'st_blocks'. Deprecated, use
   'HAVE_STRUCT_STAT_ST_BLOCKS' instead. */
#define HAVE_ST_BLOCKS 1

/* Define to 1 if you have the <sys/param.h> header file. */
#define HAVE_SYS_PARAM_H 1

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/sysmacros.h> header file. */
#define HAVE_SYS_SYSMACROS_H 1

/* Define to 1 if you have the <sys/time.h> header file. */
#define HAVE_SYS_TIME_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define to 1 if you have the <time.h> header file. */
#define HAVE_TIME_H 1

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* Define to 1 if the system has the type '_Bool'. */
/* #undef HAVE__BOOL */

/* Libtool version string */
#define LIB_VERSION "2.29.1"

/* Define to the sub-directory where libtool stores uninstalled libraries. */
#define LT_OBJDIR ".libs/"

/* Define to 1 if 'major', 'minor', and 'makedev' are declared in <mkdev.h>.
   */
/* #undef MAJOR_IN_MKDEV */

/* Define to 1 if 'major', 'minor', and 'makedev' are declared in
   <sysmacros.h>. */
#define MAJOR_IN_SYSMACROS 1

/* Name of package */
#define PACKAGE "libProgressBar"

/* Defined by 'package_infos' */
#define PACKAGE_AUTHORS "Alban MANCHERON <alban.mancheron@lirmm.fr>"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "alban.mancheron@lirmm.fr"

/* Defined by 'package_infos' */
#define PACKAGE_COPYRIGHT_DATE "2008-2026"

/* Defined by 'package_infos' */
#define PACKAGE_FULL_DESCRIPTION "If you want to easily display progress bar and if you are a C++\nprogrammer, this library is for you!"

/* Defined by 'package_infos' */
#define PACKAGE_LICENSE "GNU GPL"

/* Define to the full name of this package. */
#define PACKAGE_NAME "libProgressBar"

/* Defined by 'package_infos' */
#define PACKAGE_SHORT_DESCRIPTION "C++ Library for displaying Progress Bar in an ANSI terminal"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "libProgressBar 2.2.3"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "libProgressBar"

/* Define to the home page for this package. */
#define PACKAGE_URL "https://gite.lirmm.fr/doccy/libprogressbar"

/* Define to the version of this package. */
#define PACKAGE_VERSION "2.2.3"

/* If using the C implementation of alloca, define if you know the
   direction of stack growth for your system; otherwise it will be
   automatically deduced at runtime.
	STACK_DIRECTION > 0 => grows toward higher addresses
	STACK_DIRECTION < 0 => grows toward lower addresses
	STACK_DIRECTION = 0 => direction of growth unknown */
/* #undef STACK_DIRECTION */

/* Define to 1 if all of the C89 standard headers exist (not just the ones
   required in a freestanding environment). This macro is provided for
   backward compatibility; new code need not use it. */
#define STDC_HEADERS 1

/* Define to 1 if your <sys/time.h> declares 'struct tm'. */
/* #undef TM_IN_SYS_TIME */

/* Version number of package */
#define VERSION "2.2.3"

/* Define for Solaris 2.5.1 so the uint8_t typedef from <sys/synch.h>,
   <pthread.h>, or <semaphore.h> is not used. If the typedef were allowed, the
   #define below would cause a syntax error. */
/* #undef _UINT8_T */

/* Define to empty if 'const' does not conform to ANSI C. */
/* #undef const */

/* Define to '__inline__' or '__inline' if that's what the C compiler
   calls it, or to nothing if 'inline' is not supported under any name.  */
#ifndef __cplusplus
/* #undef inline */
#endif

/* Define as 'unsigned int' if <stddef.h> doesn't define. */
/* #undef size_t */

/* Define to the type of an unsigned integer type of width exactly 8 bits if
   such a type exists and the standard includes do not define it. */
/* #undef uint8_t */


#endif

