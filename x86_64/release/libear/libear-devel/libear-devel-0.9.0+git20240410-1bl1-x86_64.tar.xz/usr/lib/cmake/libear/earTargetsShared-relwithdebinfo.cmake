#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "ear" for configuration "RelWithDebInfo"
set_property(TARGET ear APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(ear PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libear.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygear-0.dll"
  )

list(APPEND _cmake_import_check_targets ear )
list(APPEND _cmake_import_check_files_for_ear "${_IMPORT_PREFIX}/lib/libear.dll.a" "${_IMPORT_PREFIX}/bin/cygear-0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
