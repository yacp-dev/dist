include(CMakeFindDependencyMacro)


####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was earConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

# Use original install prefix when loaded through a "/usr move"
# cross-prefix symbolic link such as /lib -> /usr/lib.
get_filename_component(_realCurr "${CMAKE_CURRENT_LIST_DIR}" REALPATH)
get_filename_component(_realOrig "/usr/lib/cmake/libear" REALPATH)
if(_realCurr STREQUAL _realOrig)
  set(PACKAGE_PREFIX_DIR "/usr")
endif()
unset(_realOrig)
unset(_realCurr)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

set_and_check(libear_INCLUDE_DIRS "${PACKAGE_PREFIX_DIR}/include")
set_and_check(libear_LIBRARY_DIRS "${PACKAGE_PREFIX_DIR}/lib")

find_dependency(Boost 1.57)

if(${ear_USE_STATIC_LIBS})

  if(EXISTS "${CMAKE_CURRENT_LIST_DIR}/earTargetsStatic.cmake")
    include("${CMAKE_CURRENT_LIST_DIR}/earTargetsStatic.cmake")
  else()
    message(FATAL_ERROR "Could not find static version of libear.")
  endif()
elseif(${ear_USE_SHARED_LIBS})
  if(EXISTS "${CMAKE_CURRENT_LIST_DIR}/earTargetsShared.cmake")
    include("${CMAKE_CURRENT_LIST_DIR}/earTargetsShared.cmake")
  else()
    message(FATAL_ERROR "Could not find shared version of libear.")
  endif()
else()
  if(EXISTS "${CMAKE_CURRENT_LIST_DIR}/earTargetsShared.cmake")
    include("${CMAKE_CURRENT_LIST_DIR}/earTargetsShared.cmake")
  else()
    include("${CMAKE_CURRENT_LIST_DIR}/earTargetsStatic.cmake")
  endif()
endif()

check_required_components(ear)

get_target_property(ear_LOCATION_ONLY_FOR_DISPLAY ear LOCATION)
message(STATUS "Found ear library ${ear_VERSION}: ${ear_LOCATION_ONLY_FOR_DISPLAY}")
