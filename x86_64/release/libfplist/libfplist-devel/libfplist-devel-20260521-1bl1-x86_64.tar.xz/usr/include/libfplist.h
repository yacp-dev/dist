/*
 * Library to support the plist formats
 *
 * Copyright (C) 2016-2026, Joachim Metz <joachim.metz@gmail.com>
 *
 * Refer to AUTHORS for acknowledgements.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#if !defined( _LIBFPLIST_H )
#define _LIBFPLIST_H

#include <libfplist/definitions.h>
#include <libfplist/error.h>
#include <libfplist/extern.h>
#include <libfplist/features.h>
#include <libfplist/types.h>

#include <stdio.h>

#if defined( __cplusplus )
extern "C" {
#endif

/* -------------------------------------------------------------------------
 * Support functions
 * ------------------------------------------------------------------------- */

/* Returns the library version
 */
LIBFPLIST_EXTERN \
const char *libfplist_get_version(
             void );

/* -------------------------------------------------------------------------
 * Error functions
 * ------------------------------------------------------------------------- */

/* Frees an error
 */
LIBFPLIST_EXTERN \
void libfplist_error_free(
      libfplist_error_t **error );

/* Prints a descriptive string of the error to the stream
 * Returns the amount of printed characters if successful or -1 on error
 */
LIBFPLIST_EXTERN \
int libfplist_error_fprint(
     libfplist_error_t *error,
     FILE *stream );

/* Prints a descriptive string of the error to the string
 * The end-of-string character is not included in the return value
 * Returns the amount of printed characters if successful or -1 on error
 */
LIBFPLIST_EXTERN \
int libfplist_error_sprint(
     libfplist_error_t *error,
     char *string,
     size_t size );

/* Prints a backtrace of the error to the stream
 * Returns the amount of printed characters if successful or -1 on error
 */
LIBFPLIST_EXTERN \
int libfplist_error_backtrace_fprint(
     libfplist_error_t *error,
     FILE *stream );

/* Prints a backtrace of the error to the string
 * The end-of-string character is not included in the return value
 * Returns the amount of printed characters if successful or -1 on error
 */
LIBFPLIST_EXTERN \
int libfplist_error_backtrace_sprint(
     libfplist_error_t *error,
     char *string,
     size_t size );

/* -------------------------------------------------------------------------
 * Property list functions
 * ------------------------------------------------------------------------- */

/* Creates a property list
 * Make sure the value property_list is referencing, is set to NULL
 * Returns 1 if successful or -1 on error
 */
LIBFPLIST_EXTERN \
int libfplist_property_list_initialize(
     libfplist_property_list_t **property_list,
     libfplist_error_t **error );

/* Frees a property list
 * Returns 1 if successful or -1 on error
 */
LIBFPLIST_EXTERN \
int libfplist_property_list_free(
     libfplist_property_list_t **property_list,
     libfplist_error_t **error );

/* Copies the property list from the byte stream
 * Returns 1 if successful, 0 if not a valid property list or -1 on error
 */
LIBFPLIST_EXTERN \
int libfplist_property_list_copy_from_byte_stream(
     libfplist_property_list_t *property_list,
     const uint8_t *byte_stream,
     size_t byte_stream_size,
     libfplist_error_t **error );

/* Determines if the property list is XML with a plist root element
 * Returns 1 if true, 0 if not or -1 on error
 */
LIBFPLIST_EXTERN \
int libfplist_property_list_has_plist_root_element(
     libfplist_property_list_t *property_list,
     libfplist_error_t **error );

/* Retrieves the root property
 * Returns 1 if successful, 0 if not available or -1 on error
 */
LIBFPLIST_EXTERN \
int libfplist_property_list_get_root_property(
     libfplist_property_list_t *property_list,
     libfplist_property_t **property,
     libfplist_error_t **error );

/* -------------------------------------------------------------------------
 * Property functions
 * ------------------------------------------------------------------------- */

/* Frees a property
 * Returns 1 if successful or -1 on error
 */
LIBFPLIST_EXTERN \
int libfplist_property_free(
     libfplist_property_t **property,
     libfplist_error_t **error );

/* Retrieves the value type
 * Returns 1 if successful or -1 on error
 */
LIBFPLIST_EXTERN \
int libfplist_property_get_value_type(
     libfplist_property_t *property,
     int *value_type,
     libfplist_error_t **error );

/* Retrieves the value (binary) data size
 * Returns 1 if successful or -1 on error
 */
LIBFPLIST_EXTERN \
int libfplist_property_get_value_data_size(
     libfplist_property_t *property,
     size_t *data_size,
     libfplist_error_t **error );

/* Copies the value (binary) data
 * Returns 1 if successful or -1 on error
 */
LIBFPLIST_EXTERN \
int libfplist_property_get_value_data(
     libfplist_property_t *property,
     uint8_t *data,
     size_t data_size,
     libfplist_error_t **error );

/* Retrieves an integer value
 * Returns 1 if successful or -1 on error
 */
LIBFPLIST_EXTERN \
int libfplist_property_get_value_integer(
     libfplist_property_t *property,
     uint64_t *value_64bit,
     libfplist_error_t **error );

/* Retrieves a string value
 * Returns 1 if successful or -1 on error
 */
LIBFPLIST_EXTERN \
int libfplist_property_get_value_string(
     libfplist_property_t *property,
     uint8_t **string,
     size_t *string_size,
     libfplist_error_t **error );

/* Copies an UUID string value to a byte stream
 * Returns 1 if successful or -1 on error
 */
LIBFPLIST_EXTERN \
int libfplist_property_value_uuid_string_copy_to_byte_stream(
     libfplist_property_t *property,
     uint8_t *byte_stream,
     size_t byte_stream_size,
     libfplist_error_t **error );

/* Retrieves the number of array entries
 * Returns 1 if successful or -1 on error
 */
LIBFPLIST_EXTERN \
int libfplist_property_get_array_number_of_entries(
     libfplist_property_t *property,
     int *number_of_entries,
     libfplist_error_t **error );

/* Retrieves a specific array entry
 * Returns 1 if successful or -1 on error
 */
LIBFPLIST_EXTERN \
int libfplist_property_get_array_entry_by_index(
     libfplist_property_t *property,
     int array_entry_index,
     libfplist_property_t **array_entry,
     libfplist_error_t **error );

/* Retrieves the sub property for the specific UTF-8 encoded name
 * Returns 1 if successful, 0 if no such sub property or -1 on error
 */
LIBFPLIST_EXTERN \
int libfplist_property_get_sub_property_by_utf8_name(
     libfplist_property_t *property,
     const uint8_t *utf8_string,
     size_t utf8_string_length,
     libfplist_property_t **sub_property,
     libfplist_error_t **error );

#if defined( __cplusplus )
}
#endif

#endif /* !defined( _LIBFPLIST_H ) */

