#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Catch2::Catch2" for configuration "RelWithDebInfo"
set_property(TARGET Catch2::Catch2 APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(Catch2::Catch2 PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libCatch2.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygCatch2-3.16.1.dll"
  )

list(APPEND _cmake_import_check_targets Catch2::Catch2 )
list(APPEND _cmake_import_check_files_for_Catch2::Catch2 "${_IMPORT_PREFIX}/lib/libCatch2.dll.a" "${_IMPORT_PREFIX}/bin/cygCatch2-3.16.1.dll" )

# Import target "Catch2::Catch2WithMain" for configuration "RelWithDebInfo"
set_property(TARGET Catch2::Catch2WithMain APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(Catch2::Catch2WithMain PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libCatch2Main.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygCatch2Main-3.16.1.dll"
  )

list(APPEND _cmake_import_check_targets Catch2::Catch2WithMain )
list(APPEND _cmake_import_check_files_for_Catch2::Catch2WithMain "${_IMPORT_PREFIX}/lib/libCatch2Main.dll.a" "${_IMPORT_PREFIX}/bin/cygCatch2Main-3.16.1.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
