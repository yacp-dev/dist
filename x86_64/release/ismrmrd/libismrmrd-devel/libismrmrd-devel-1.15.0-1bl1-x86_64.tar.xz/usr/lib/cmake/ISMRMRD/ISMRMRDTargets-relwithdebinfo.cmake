#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "ISMRMRD::ISMRMRD" for configuration "RelWithDebInfo"
set_property(TARGET ISMRMRD::ISMRMRD APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(ISMRMRD::ISMRMRD PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libismrmrd.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygismrmrd-1.15.dll"
  )

list(APPEND _cmake_import_check_targets ISMRMRD::ISMRMRD )
list(APPEND _cmake_import_check_files_for_ISMRMRD::ISMRMRD "${_IMPORT_PREFIX}/lib/libismrmrd.dll.a" "${_IMPORT_PREFIX}/bin/cygismrmrd-1.15.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
