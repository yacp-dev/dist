#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "cpp-pinyin2::cpp-pinyin2" for configuration "RelWithDebInfo"
set_property(TARGET cpp-pinyin2::cpp-pinyin2 APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(cpp-pinyin2::cpp-pinyin2 PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libcpp-pinyin2.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygcpp-pinyin2-2.dll"
  )

list(APPEND _cmake_import_check_targets cpp-pinyin2::cpp-pinyin2 )
list(APPEND _cmake_import_check_files_for_cpp-pinyin2::cpp-pinyin2 "${_IMPORT_PREFIX}/lib/libcpp-pinyin2.dll.a" "${_IMPORT_PREFIX}/bin/cygcpp-pinyin2-2.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
