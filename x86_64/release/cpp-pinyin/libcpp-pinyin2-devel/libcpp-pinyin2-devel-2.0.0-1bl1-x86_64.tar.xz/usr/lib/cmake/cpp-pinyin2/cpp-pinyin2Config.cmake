
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was cpp-pinyin2Config.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

# Use original install prefix when loaded through a "/usr move"
# cross-prefix symbolic link such as /lib -> /usr/lib.
get_filename_component(_realCurr "${CMAKE_CURRENT_LIST_DIR}" REALPATH)
get_filename_component(_realOrig "/usr/lib/cmake/cpp-pinyin2" REALPATH)
if(_realCurr STREQUAL _realOrig)
  set(PACKAGE_PREFIX_DIR "/usr")
endif()
unset(_realOrig)
unset(_realCurr)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

####################################################################################

include("${CMAKE_CURRENT_LIST_DIR}/cpp-pinyin2Targets.cmake")

# Where the dictionaries were installed. The pkg-config file has always exported `dictdir=`
# (cpp-pinyin2.pc.in) and had no CMake counterpart until Q14: a `find_package` consumer could pick up
# the target and the headers and still have no supported way to find the data. Same path, computed
# the same way, so the two files cannot drift. `set_and_check` fails the consumer's configure if the
# directory is not there -- the point being that a missing dictionary must not look like an empty one.
set_and_check(CPP_PINYIN2_DICT_DIR "${PACKAGE_PREFIX_DIR}/share/cpp-pinyin2/dict")
