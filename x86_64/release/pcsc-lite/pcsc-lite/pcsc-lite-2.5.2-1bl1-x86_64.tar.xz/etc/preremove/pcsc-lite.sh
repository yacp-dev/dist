if [ -f /etc/default/pcscd ] && cmp -s /etc/defaults/etc/default/pcscd /etc/default/pcscd
then
    rm /etc/default/pcscd
fi

