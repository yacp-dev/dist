if [ ! -e /etc/default/pcscd ]
then
    /usr/bin/mkdir -p /etc/default
    /usr/bin/cp /etc/defaults/etc/default/pcscd /etc/default/pcscd
fi

