
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was unarr-config.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

# Use original install prefix when loaded through a "/usr move"
# cross-prefix symbolic link such as /lib -> /usr/lib.
get_filename_component(_realCurr "${CMAKE_CURRENT_LIST_DIR}" REALPATH)
get_filename_component(_realOrig "/usr/lib/cmake/unarr" REALPATH)
if(_realCurr STREQUAL _realOrig)
  set(PACKAGE_PREFIX_DIR "/usr")
endif()
unset(_realOrig)
unset(_realCurr)

####################################################################################

include(CMakeFindDependencyMacro)

set(UNARR_DEPENDS_BZip2 TRUE)
set(UNARR_DEPENDS_LibLZMA TRUE)
set(UNARR_DEPENDS_ZLIB TRUE)

if(UNARR_DEPENDS_BZip2)
  find_dependency(BZip2)
endif()

if(UNARR_DEPENDS_LibLZMA)
  find_dependency(LibLZMA)
endif()

if(UNARR_DEPENDS_ZLIB)
  find_dependency(ZLIB)
endif()

if (NOT TARGET unarr::unarr)
  include("${CMAKE_CURRENT_LIST_DIR}/unarr-targets.cmake")
endif()
