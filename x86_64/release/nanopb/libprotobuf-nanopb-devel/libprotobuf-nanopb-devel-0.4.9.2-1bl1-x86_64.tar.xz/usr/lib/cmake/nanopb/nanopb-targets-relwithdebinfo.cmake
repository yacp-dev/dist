#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "nanopb::protobuf-nanopb" for configuration "RelWithDebInfo"
set_property(TARGET nanopb::protobuf-nanopb APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(nanopb::protobuf-nanopb PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libprotobuf-nanopb.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygprotobuf-nanopb-0.dll"
  )

list(APPEND _cmake_import_check_targets nanopb::protobuf-nanopb )
list(APPEND _cmake_import_check_files_for_nanopb::protobuf-nanopb "${_IMPORT_PREFIX}/lib/libprotobuf-nanopb.dll.a" "${_IMPORT_PREFIX}/bin/cygprotobuf-nanopb-0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
