#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "dspkg-validator::dspkg-validator" for configuration "RelWithDebInfo"
set_property(TARGET dspkg-validator::dspkg-validator APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(dspkg-validator::dspkg-validator PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libdspkg-validator.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygdspkg-validator-0.dll"
  )

list(APPEND _cmake_import_check_targets dspkg-validator::dspkg-validator )
list(APPEND _cmake_import_check_files_for_dspkg-validator::dspkg-validator "${_IMPORT_PREFIX}/lib/libdspkg-validator.dll.a" "${_IMPORT_PREFIX}/bin/cygdspkg-validator-0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
