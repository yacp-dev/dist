#ifndef DSPKG_VALIDATOR_DSPKGVALIDATOR_H
#define DSPKG_VALIDATOR_DSPKGVALIDATOR_H

#include <dspkg-validator/DspkgGlobal.h>
#include <filesystem>
#include <unordered_map>

#include "Api/L1/Singer.h"
#include "Api/L1/Acoustic.h"
#include "Api/L1/Duration.h"
#include "Api/L1/Pitch.h"
#include "Api/L1/Variance.h"
#include "Api/L1/Vocoder.h"

namespace DspkgVal
{
    class DSPKG_VALIDATOR_EXPORT DspkgValidatorL1 {
    public:
        explicit DspkgValidatorL1(std::filesystem::path path);

    private:
        std::filesystem::path m_dspkgPath;
        std::unordered_map<std::string, Singer> m_singers{};

        Duration *m_duration{};
        Pitch *m_pitch{};
        Variance *m_variance{};
        Acoustic *m_acoustic{};
        Vocoder *m_vocoder{};
    };
} // DspkgValidatorL1

#endif //DSPKG_VALIDATOR_DSPKGVALIDATOR_H
