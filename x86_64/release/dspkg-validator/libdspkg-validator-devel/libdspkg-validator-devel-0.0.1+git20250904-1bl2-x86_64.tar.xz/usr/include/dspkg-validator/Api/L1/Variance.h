#ifndef DSPKG_VALIDATOR_VARIANCE_H
#define DSPKG_VALIDATOR_VARIANCE_H

#include <filesystem>
#include "BaseModule.h"

namespace DspkgVal
{
    class Variance : public BaseModule {
    public:
        explicit Variance(const std::filesystem::path &path);

        ~Variance();
    };
} // namespace DspkgVal

#endif // DSPKG_VALIDATOR_VARIANCE_H
