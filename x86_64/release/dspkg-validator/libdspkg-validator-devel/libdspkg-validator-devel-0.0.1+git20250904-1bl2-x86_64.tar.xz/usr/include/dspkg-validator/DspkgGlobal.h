#ifndef DSPKGGLOBAL_H
#define DSPKGGLOBAL_H

#ifdef _MSC_VER
#  define DSPKG_VALIDATOR_DECL_EXPORT __declspec(dllexport)
#  define DSPKG_VALIDATOR_DECL_IMPORT __declspec(dllimport)
#else
#  define DSPKG_VALIDATOR_DECL_EXPORT __attribute__((visibility("default")))
#  define DSPKG_VALIDATOR_DECL_IMPORT __attribute__((visibility("default")))
#endif

#ifndef DSPKG_VALIDATOR_EXPORT
#  ifdef DSPKG_VALIDATOR_STATIC
#    define DSPKG_VALIDATOR_EXPORT
#  else
#    ifdef DSPKG_VALIDATOR_LIBRARY
#      define DSPKG_VALIDATOR_EXPORT DSPKG_VALIDATOR_DECL_EXPORT
#    else
#      define DSPKG_VALIDATOR_EXPORT DSPKG_VALIDATOR_DECL_IMPORT
#    endif
#  endif
#endif

#endif //DSPKGGLOBAL_H
