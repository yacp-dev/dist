#ifndef DSPKG_VALIDATOR_PITCH_H
#define DSPKG_VALIDATOR_PITCH_H

#include <filesystem>
#include "BaseModule.h"

namespace DspkgVal
{
    class Pitch : public BaseModule {
    public:
        explicit Pitch(const std::filesystem::path &path);

        ~Pitch();
    };
} // namespace DspkgVal

#endif // DSPKG_VALIDATOR_PITCH_H
