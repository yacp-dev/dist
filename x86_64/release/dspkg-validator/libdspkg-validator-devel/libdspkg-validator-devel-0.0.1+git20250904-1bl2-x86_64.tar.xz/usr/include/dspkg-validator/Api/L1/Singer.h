#ifndef DSPKG_VALIDATOR_SINGER_H
#define DSPKG_VALIDATOR_SINGER_H

#include <filesystem>
#include <nlohmann/json.hpp>
#include <set>

namespace DspkgVal
{
    class Singer {
    public:
        explicit Singer(const std::filesystem::path &path);

        ~Singer();

        std::set<std::string> languages() const;

    private:
        std::filesystem::path m_path;

        std::string m_version;
        int m_level;
        nlohmann::json m_imports;
        nlohmann::json m_configuration;

        std::set<std::string> m_languages;
        std::set<std::string> m_support_singerIds;
    };
} // namespace DspkgVal

#endif // DSPKG_VALIDATOR_SINGER_H
