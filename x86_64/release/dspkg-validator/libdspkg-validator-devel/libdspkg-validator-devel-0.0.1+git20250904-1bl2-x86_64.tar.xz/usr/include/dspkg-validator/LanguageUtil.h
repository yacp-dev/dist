#ifndef DSPKG_VALIDATOR_LANGUAGEUTIL_H
#define DSPKG_VALIDATOR_LANGUAGEUTIL_H

#include <filesystem>
#include <set>
#include <vector>

namespace DspkgVal
{
    inline std::set<std::string> language_codes = {"cmn", "jpn", "eng", "yue"};

    class Phonemes {
    public:
        explicit Phonemes(const std::filesystem::path &phonemesPath);
        ~Phonemes();

        std::vector<std::string> phonemes() const;
        std::vector<std::string> languages() const;

    private:
        std::vector<std::string> m_phonemes;
        std::set<std::string> m_languages;
    };

    std::vector<std::string> loadLanguagesJson(const std::filesystem::path &path);
    std::set<std::string> getIntersection(const std::set<std::set<std::string>> &allImports);
} // namespace DspkgVal

#endif // DSPKG_VALIDATOR_LANGUAGEUTIL_H
