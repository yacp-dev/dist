#ifndef DSPKG_VALIDATOR_ACOUSTIC_H
#define DSPKG_VALIDATOR_ACOUSTIC_H

#include <filesystem>
#include "BaseModule.h"

namespace DspkgVal
{
    class Acoustic : public BaseModule {
    public:
        explicit Acoustic(const std::filesystem::path &path);

        ~Acoustic();
    };
} // namespace DspkgVal

#endif // DSPKG_VALIDATOR_ACOUSTIC_H
