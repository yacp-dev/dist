#ifndef DSPKG_VALIDATOR_DURATION_H
#define DSPKG_VALIDATOR_DURATION_H

#include <filesystem>
#include "BaseModule.h"

namespace DspkgVal
{
    class Duration : public BaseModule {
    public:
        explicit Duration(const std::filesystem::path &path);

        ~Duration();
    };
} // DspkgVal

#endif //DSPKG_VALIDATOR_DURATION_H
