#ifndef DSPKG_VALIDATOR_JSONUTIL_H
#define DSPKG_VALIDATOR_JSONUTIL_H

#include <filesystem>
#include <nlohmann/json.hpp>
#include <optional>

namespace DspkgVal
{
    nlohmann::json loadJsonFile(const std::filesystem::path &path);
} // namespace DspkgVal

#endif // DSPKG_VALIDATOR_JSONUTIL_H
