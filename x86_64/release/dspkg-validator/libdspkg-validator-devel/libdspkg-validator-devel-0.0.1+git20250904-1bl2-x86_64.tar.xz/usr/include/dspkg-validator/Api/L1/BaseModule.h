#ifndef DSPKG_VALIDATOR_BASEMODULE_H
#define DSPKG_VALIDATOR_BASEMODULE_H

#include <filesystem>
#include <nlohmann/json.hpp>
#include <set>

namespace DspkgVal
{
    class BaseModule {
    public:
        explicit BaseModule(const std::filesystem::path &path);

        ~BaseModule();

        std::set<std::string> languages();

    private:
        std::filesystem::path m_path;

        std::string m_version;
        int m_level;
        nlohmann::json m_schema;
        nlohmann::json m_configuration;

        std::vector<std::string> m_phonemes;
        std::vector<std::string> m_languages;
    };

} // namespace DspkgVal

#endif // DSPKG_VALIDATOR_BASEMODULE_H
