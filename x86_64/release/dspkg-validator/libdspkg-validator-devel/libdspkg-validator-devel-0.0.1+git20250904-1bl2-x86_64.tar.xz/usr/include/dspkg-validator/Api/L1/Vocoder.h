#ifndef DSPKG_VALIDATOR_VOCODER_H
#define DSPKG_VALIDATOR_VOCODER_H

#include <filesystem>
#include <nlohmann/json.hpp>

namespace DspkgVal
{
    class Vocoder {
    public:
        explicit Vocoder(const std::filesystem::path &path);

        ~Vocoder();

    private:
        std::string m_version;
        int m_level;
        nlohmann::json m_schema;
        nlohmann::json m_configuration;
    };
} // DspkgVal

#endif //DSPKG_VALIDATOR_VOCODER_H
