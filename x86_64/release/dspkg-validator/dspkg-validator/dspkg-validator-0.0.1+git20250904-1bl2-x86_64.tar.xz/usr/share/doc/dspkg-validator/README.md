# dspkg-validator

```
-DCMAKE_TOOLCHAIN_FILE=vcpkg\scripts\buildsystems\vcpkg.cmake
-DDSPKG_VALIDATOR_BUILD_TESTS=ON
```