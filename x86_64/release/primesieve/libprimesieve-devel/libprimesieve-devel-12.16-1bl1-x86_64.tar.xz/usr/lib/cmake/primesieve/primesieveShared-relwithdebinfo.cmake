#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "primesieve::libprimesieve" for configuration "RelWithDebInfo"
set_property(TARGET primesieve::libprimesieve APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(primesieve::libprimesieve PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libprimesieve.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygprimesieve-12.dll"
  )

list(APPEND _cmake_import_check_targets primesieve::libprimesieve )
list(APPEND _cmake_import_check_files_for_primesieve::libprimesieve "${_IMPORT_PREFIX}/lib/libprimesieve.dll.a" "${_IMPORT_PREFIX}/bin/cygprimesieve-12.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
