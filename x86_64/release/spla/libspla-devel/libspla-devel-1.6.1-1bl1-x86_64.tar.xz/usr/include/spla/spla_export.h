
#ifndef SPLA_EXPORT_H
#define SPLA_EXPORT_H

#ifdef SPLA_STATIC_DEFINE
#  define SPLA_EXPORT
#  define SPLA_NO_EXPORT
#else
#  ifndef SPLA_EXPORT
#    ifdef spla_EXPORTS
        /* We are building this library */
#      define SPLA_EXPORT __declspec(dllexport)
#    else
        /* We are using this library */
#      define SPLA_EXPORT __declspec(dllimport)
#    endif
#  endif

#  ifndef SPLA_NO_EXPORT
#    define SPLA_NO_EXPORT 
#  endif
#endif

#ifndef SPLA_DEPRECATED
#  define SPLA_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef SPLA_DEPRECATED_EXPORT
#  define SPLA_DEPRECATED_EXPORT SPLA_EXPORT SPLA_DEPRECATED
#endif

#ifndef SPLA_DEPRECATED_NO_EXPORT
#  define SPLA_DEPRECATED_NO_EXPORT SPLA_NO_EXPORT SPLA_DEPRECATED
#endif

/* NOLINTNEXTLINE(readability-avoid-unconditional-preprocessor-if) */
#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef SPLA_NO_DEPRECATED
#    define SPLA_NO_DEPRECATED
#  endif
#endif

#endif /* SPLA_EXPORT_H */
