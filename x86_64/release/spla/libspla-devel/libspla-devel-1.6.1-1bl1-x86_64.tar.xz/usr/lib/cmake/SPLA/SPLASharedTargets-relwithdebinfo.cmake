#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "SPLA::spla" for configuration "RelWithDebInfo"
set_property(TARGET SPLA::spla APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(SPLA::spla PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libspla.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygspla-1.dll"
  )

list(APPEND _cmake_import_check_targets SPLA::spla )
list(APPEND _cmake_import_check_files_for_SPLA::spla "${_IMPORT_PREFIX}/lib/libspla.dll.a" "${_IMPORT_PREFIX}/bin/cygspla-1.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
