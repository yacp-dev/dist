#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "CheMPS2::chemps2" for configuration "RelWithDebInfo"
set_property(TARGET CheMPS2::chemps2 APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(CheMPS2::chemps2 PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libchemps2.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygchemps2-3.dll"
  )

list(APPEND _cmake_import_check_targets CheMPS2::chemps2 )
list(APPEND _cmake_import_check_files_for_CheMPS2::chemps2 "${_IMPORT_PREFIX}/lib/libchemps2.dll.a" "${_IMPORT_PREFIX}/bin/cygchemps2-3.dll" )

# Import target "CheMPS2::chemps2-bin" for configuration "RelWithDebInfo"
set_property(TARGET CheMPS2::chemps2-bin APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(CheMPS2::chemps2-bin PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/chemps2.exe"
  )

list(APPEND _cmake_import_check_targets CheMPS2::chemps2-bin )
list(APPEND _cmake_import_check_files_for_CheMPS2::chemps2-bin "${_IMPORT_PREFIX}/bin/chemps2.exe" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
