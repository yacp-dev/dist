#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "kcp::kcp" for configuration "RelWithDebInfo"
set_property(TARGET kcp::kcp APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(kcp::kcp PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libkcp.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygkcp-2.dll"
  )

list(APPEND _cmake_import_check_targets kcp::kcp )
list(APPEND _cmake_import_check_files_for_kcp::kcp "${_IMPORT_PREFIX}/lib/libkcp.dll.a" "${_IMPORT_PREFIX}/bin/cygkcp-2.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
