/**********************************************************************************************************************
 *                                                                                                                    *
 *  D I A L S Y S . H                                                                                                 *
 *  =================                                                                                                 *
 *                                                                                                                    *
 *  Copyright (c) 2026                                                                                                *
 *                                                                                                                    *
 *  File dialsys.h is free software: you can redistribute it and/or modify it under the terms of the GNU General      *
 *  Public License as published by the Free Software Foundation, either version 3 of the License, or (at your         *
 *  option) any later version.                                                                                        *
 *                                                                                                                    *
 *  File dialsys.h is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the      *
 *  implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for  *
 *  more details.                                                                                                     *
 *                                                                                                                    *
 *  You should have received a copy of the GNU General Public License along with this program. If not, see:           *
 *  <http://www.gnu.org/licenses/>                                                                                    *
 *                                                                                                                    *
 **********************************************************************************************************************/
/**
 *  \file
 *  \brief Function and structures for the dial library.
 */
#ifndef INCLUDE_DIALSYS_H
#define INCLUDE_DIALSYS_H
 
#include <gtk/gtk.h>
#include <stdbool.h>

#define DIALSYS_VER "2.7"

/*----------------------------------------------------------------------------------------------------*
 * Prototypes for dial list store                                                                     *
 *----------------------------------------------------------------------------------------------------*/
void *queueCreate (void);
void  queueDelete (void *queueHandle);
void *queueGet (void *queueHandle);
void  queuePut (void *queueHandle, void *putData);
void  queuePutSort (void *queueHandle, void *putData, 
                        int(*Compare)(void *item1, void *item2));
void  queuePush (void *queueHandle, void *putData);
void *queueRead (void *queueHandle, int item);
void queueSetFreeData (void *queueHandle, unsigned long setData);
unsigned long queueGetFreeData (void *queueHandle);
unsigned long queueGetItemCount (void *queueHandle);

/*----------------------------------------------------------------------------------------------------*
 * Prototypes for dial config store                                                                   *
 *----------------------------------------------------------------------------------------------------*/
int configLoad (const char *configFile);
int configSave (const char *configFile);
void configFree ();
int configSetValue (const char *configName, char *configValue);
int configSetIntValue (const char *configName, int configValue);
int configSetBoolValue (const char *configName, bool configValue);
int configGetValue (const char *configName, char *value, int maxLen);
int configGetIntValue (const char *configName, int *configValue);
int configGetBoolValue (const char *configName, bool *configValue);

/*----------------------------------------------------------------------------------------------------*
 * Structure to store menu items                                                                      *
 *----------------------------------------------------------------------------------------------------*/
typedef struct _menuDesc
{
	char *menuName;
	void (*funcCallBack) (guint data);
	struct _menuDesc *subMenuDesc;
	unsigned long param;
	char *stockItem;
	unsigned int accelKey;
	unsigned char disable;
	unsigned char checkbox;
	unsigned char checked;
}
MENU_DESC;

/*----------------------------------------------------------------------------------------------------*
 * Prototypes for dial menu                                                                           *
 *----------------------------------------------------------------------------------------------------*/
GtkWidget *createMenu (MENU_DESC *subMenuDesc, GtkAccelGroup *accelGroup, int bar);

/*----------------------------------------------------------------------------------------------------*
 * Defines used by dial display                                                                       *
 *----------------------------------------------------------------------------------------------------*/
#define SCALE_1				300
#define SCALE_2				600
#define SCALE_3				900
#define SCALE_4				1200
#define MAX_FACES 			50
#define _(String) 			gettext (String)
#define __(String) 			(String)

/*----------------------------------------------------------------------------------------------------*
 * Structure to store display items                                                                   *
 *----------------------------------------------------------------------------------------------------*/
typedef struct _colourDetails
{
	char *shortName;
	char *longName;
	char defColour[62];
	GdkRGBA dialColour;
}
COLOUR_DETAILS;

typedef struct _handStyle
{
	int style;
	int length;
	int tail;
	int line;
	int fill;
	bool fillIn;
	bool gauge;
}
HAND_STYLE;

/*----------------------------------------------------------------------------------------------------*
 * Dial config                                                                                        *
 *----------------------------------------------------------------------------------------------------*/
typedef struct _dialConfig
{
	GtkWindow *mainWindow;
	GtkWidget *drawingArea;
	int dialSize;
	int dialWidth;
	int dialHeight;
	int markerType;
	int markerStep;
	int dialOpacity;
	int dialGradient;
	int startPoint;
	int markerScale;
	char *fontName;
	void(*UpdateFunc)(void); 
	void(*DialSave)(char *path);
	COLOUR_DETAILS *colourDetails;
}
DIAL_CONFIG;

/*----------------------------------------------------------------------------------------------------*
 * Prototypes for dial display                                                                        *
 *----------------------------------------------------------------------------------------------------*/
GtkWidget *dialInit 	(DIAL_CONFIG *dialConfig);
int dialCheckVersion	(char *version);
void dialDrawStart 		(cairo_t *cr, int posX, int posY);
void dialDrawFinish 	(void);

void dialDrawMinute		(int size, int len, int angle, int colour);
void dialDrawCircle		(int size, int colFill, int colOut);
void dialDrawSquare		(int size, int colFill, int colOut);
void dialHotCold		(int size, int colFill, int cold);
void dialDrawHand		(int angle, HAND_STYLE *handStyle);
void dialDrawMark		(int angle, int size, int colFill, int colOut, char *text);
void dialDrawText		(int posn, char *string1, int colour);
void dialDrawTextS		(int posn, char *string1, int colour, int scale);
void dialCircleGradient (int size, int colFill, int style);
void dialSquareGradient (int size, int colFill, int style);

void dialDrawMinuteX	(int posX, int posY, int size, int len, int angle, int colour);
void dialDrawCircleX	(int posX, int posY, int size, int colFill, int colOut);
void dialDrawSquareX	(int posX, int posY, int size, int colFill, int colOut);
void dialHotColdX		(int posX, int posY, int size, int colFill, int cold);
void dialDrawHandX		(int posX, int posY, int angle, HAND_STYLE *handStyle);
void dialDrawMarkX		(int posX, int posY, int angle, int size, int colFill, int colOut, char *text);
void dialDrawTextX		(int posX, int posY, char *string1, int colour, int scale);
void dialCircleGradientX (int posX, int posY, int size, int colFill, int style);
void dialSquareGradientX (int posX, int posY, int size, int colFill, int style);

void dialGetScreenSize	(int *width, int *height);
int dialSin 			(int number, int angle);
int dialCos 			(int number, int angle);
float dialGetFontSize 	(char *fontName);
void dialSetOpacity		();

void dialFontCallback 	(guint data);
void dialColourCallback	(guint data);
void dialFixFaceSize	(void);
void dialZoomCallback	(guint data);
void dialMarkerCallback	(guint data);
void dialStepCallback	(guint data);
void dialAddDelCallback	(guint data);
void dialSaveCallback	(guint data);
int dialCreateColours	();

#endif

