<!--
XSL HTML stylesheet driver file for DocBook XML documents using RefDB citations
and bibliographies.
$Id: docbk-refdb-html.xsl.in,v 1.11.2.3 2006/03/27 20:10:35 mhoenicka Exp $

markus@mhoenicka.de 011226

Copyright blurb
-->

<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:d="http://docbook.org/ns/docbook" xmlns:xl="http://www.w3.org/1999/xlink" version="1.0">

<!-- the original DocBook stylesheets for HTML -->
<xsl:import href="http://docbook.sourceforge.net/release/xsl-ns/current/html/docbook.xsl"/>

<!-- common variables -->
<xsl:import href="/usr/share/refdb/xsl/common-refdb/refdbvar.xsl"/>

<!-- common templates -->
<xsl:import href="/usr/share/refdb/xsl/docbk-refdb-xsl/docbk-lib/docbk-refdblib-ns.xsl"/>



<!-- overrides for bibliography elements -->
<!-- *********************************** -->

<!-- we pick only RefDB bibliographies -->
<xsl:template match="d:bibliography[@role='refdb']">
  <xsl:variable name="id"><xsl:call-template name="object.id"/></xsl:variable>

  <div id="{$id}" class="{name(.)}">
    <xsl:call-template name="bibliography.titlepage"/>
    <xsl:for-each select="d:bibliomixed">
      <p><xsl:apply-templates select="." mode="refdb"/></p>
    </xsl:for-each>
    <xsl:call-template name="process.footnotes"/>
  </div>
</xsl:template>

<!-- one bibliography entry. We process only the bibliography part
     and suppress the inline parts -->
<xsl:template match="d:bibliomixed" mode="refdb">
  <xsl:choose>
    <xsl:when test="@role='MULTIXREF'">
      <!-- do not render directly -->
    </xsl:when>
    <xsl:otherwise>
      <xsl:variable name="id">
        <xsl:call-template name="object.id"/>
      </xsl:variable>
      <div id="{$id}" class="{name(.)}">
        <xsl:apply-templates select="d:bibliomset[@role='bibliography']" mode="refdb"/>
      </div>
    </xsl:otherwise>
  </xsl:choose>
</xsl:template>

<!-- link needs special care as we want to create a hyperlink -->
<xsl:template match="d:link" mode="refdb">
  <xsl:variable name="reftype" select="ancestor::d:bibliomixed/@role"/>
  <xsl:variable name="target" select="@xl:href"/>
  <a href='{$target}'>
    <xsl:choose>
      <xsl:when test="$reftype='ABST'">
        <xsl:call-template name="refdb-literal">
          <xsl:with-param name="style" select="$ABSTURLSTYLE"/>
          <xsl:with-param name="string">
            <xsl:value-of select="."/>
          </xsl:with-param>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='ADVS'">
        <xsl:call-template name="refdb-literal">
          <xsl:with-param name="style" select="$ADVSURLSTYLE"/>
          <xsl:with-param name="string">
            <xsl:value-of select="."/>
          </xsl:with-param>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='ART'">
        <xsl:call-template name="refdb-literal">
          <xsl:with-param name="style" select="$ARTURLSTYLE"/>
          <xsl:with-param name="string">
            <xsl:value-of select="."/>
          </xsl:with-param>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='BILL'">
        <xsl:call-template name="refdb-literal">
          <xsl:with-param name="style" select="$BILLURLSTYLE"/>
          <xsl:with-param name="string">
            <xsl:value-of select="."/>
          </xsl:with-param>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='BOOK'">
        <xsl:call-template name="refdb-literal">
          <xsl:with-param name="style" select="$BOOKURLSTYLE"/>
          <xsl:with-param name="string">
            <xsl:value-of select="."/>
          </xsl:with-param>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='CASE'">
        <xsl:call-template name="refdb-literal">
          <xsl:with-param name="style" select="$CASEURLSTYLE"/>
          <xsl:with-param name="string">
            <xsl:value-of select="."/>
          </xsl:with-param>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='CHAP'">
        <xsl:call-template name="refdb-literal">
          <xsl:with-param name="style" select="$CHAPURLSTYLE"/>
          <xsl:with-param name="string">
            <xsl:value-of select="."/>
          </xsl:with-param>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='COMP'">
        <xsl:call-template name="refdb-literal">
          <xsl:with-param name="style" select="$COMPURLSTYLE"/>
          <xsl:with-param name="string">
            <xsl:value-of select="."/>
          </xsl:with-param>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='CONF'">
        <xsl:call-template name="refdb-literal">
          <xsl:with-param name="style" select="$CONFURLSTYLE"/>
          <xsl:with-param name="string">
            <xsl:value-of select="."/>
          </xsl:with-param>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='CTLG'">
        <xsl:call-template name="refdb-literal">
          <xsl:with-param name="style" select="$CTLGURLSTYLE"/>
          <xsl:with-param name="string">
            <xsl:value-of select="."/>
          </xsl:with-param>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='DATA'">
        <xsl:call-template name="refdb-literal">
          <xsl:with-param name="style" select="$DATAURLSTYLE"/>
          <xsl:with-param name="string">
            <xsl:value-of select="."/>
          </xsl:with-param>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='ELEC'">
        <xsl:call-template name="refdb-literal">
          <xsl:with-param name="style" select="$ELECURLSTYLE"/>
          <xsl:with-param name="string">
            <xsl:value-of select="."/>
          </xsl:with-param>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='GEN'">
        <xsl:call-template name="refdb-literal">
          <xsl:with-param name="style" select="$GENURLSTYLE"/>
          <xsl:with-param name="string">
            <xsl:value-of select="."/>
          </xsl:with-param>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='HEAR'">
        <xsl:call-template name="refdb-literal">
          <xsl:with-param name="style" select="$HEARURLSTYLE"/>
          <xsl:with-param name="string">
            <xsl:value-of select="."/>
          </xsl:with-param>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='ICOMM'">
        <xsl:call-template name="refdb-literal">
          <xsl:with-param name="style" select="$ICOMMURLSTYLE"/>
          <xsl:with-param name="string">
            <xsl:value-of select="."/>
          </xsl:with-param>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='INPR'">
        <xsl:call-template name="refdb-literal">
          <xsl:with-param name="style" select="$INPRURLSTYLE"/>
          <xsl:with-param name="string">
            <xsl:value-of select="."/>
          </xsl:with-param>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='JFULL'">
        <xsl:call-template name="refdb-literal">
          <xsl:with-param name="style" select="$JFULLURLSTYLE"/>
          <xsl:with-param name="string">
            <xsl:value-of select="."/>
          </xsl:with-param>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='JOUR'">
        <xsl:call-template name="refdb-literal">
          <xsl:with-param name="style" select="$JOURURLSTYLE"/>
          <xsl:with-param name="string">
            <xsl:value-of select="."/>
          </xsl:with-param>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='MAP'">
        <xsl:call-template name="refdb-literal">
          <xsl:with-param name="style" select="$MAPURLSTYLE"/>
          <xsl:with-param name="string">
            <xsl:value-of select="."/>
          </xsl:with-param>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='MGZN'">
        <xsl:call-template name="refdb-literal">
          <xsl:with-param name="style" select="$MGZNURLSTYLE"/>
          <xsl:with-param name="string">
            <xsl:value-of select="."/>
          </xsl:with-param>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='MPCT'">
        <xsl:call-template name="refdb-literal">
          <xsl:with-param name="style" select="$MPCTURLSTYLE"/>
          <xsl:with-param name="string">
            <xsl:value-of select="."/>
          </xsl:with-param>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='MUSIC'">
        <xsl:call-template name="refdb-literal">
          <xsl:with-param name="style" select="$MUSICURLSTYLE"/>
          <xsl:with-param name="string">
            <xsl:value-of select="."/>
          </xsl:with-param>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='NEWS'">
        <xsl:call-template name="refdb-literal">
          <xsl:with-param name="style" select="$NEWSURLSTYLE"/>
          <xsl:with-param name="string">
            <xsl:value-of select="."/>
          </xsl:with-param>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='PAMP'">
        <xsl:call-template name="refdb-literal">
          <xsl:with-param name="style" select="$PAMPURLSTYLE"/>
          <xsl:with-param name="string">
            <xsl:value-of select="."/>
          </xsl:with-param>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='PAT'">
        <xsl:call-template name="refdb-literal">
          <xsl:with-param name="style" select="$PATURLSTYLE"/>
          <xsl:with-param name="string">
            <xsl:value-of select="."/>
          </xsl:with-param>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='PCOMM'">
        <xsl:call-template name="refdb-literal">
          <xsl:with-param name="style" select="$PCOMMURLSTYLE"/>
          <xsl:with-param name="string">
            <xsl:value-of select="."/>
          </xsl:with-param>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='RPRT'">
        <xsl:call-template name="refdb-literal">
          <xsl:with-param name="style" select="$RPRTURLSTYLE"/>
          <xsl:with-param name="string">
            <xsl:value-of select="."/>
          </xsl:with-param>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='SER'">
        <xsl:call-template name="refdb-literal">
          <xsl:with-param name="style" select="$SERURLSTYLE"/>
          <xsl:with-param name="string">
            <xsl:value-of select="."/>
          </xsl:with-param>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='SLIDE'">
        <xsl:call-template name="refdb-literal">
          <xsl:with-param name="style" select="$SLIDEURLSTYLE"/>
          <xsl:with-param name="string">
            <xsl:value-of select="."/>
          </xsl:with-param>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='SOUND'">
        <xsl:call-template name="refdb-literal">
          <xsl:with-param name="style" select="$SOUNDURLSTYLE"/>
          <xsl:with-param name="string">
            <xsl:value-of select="."/>
          </xsl:with-param>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='STAT'">
        <xsl:call-template name="refdb-literal">
          <xsl:with-param name="style" select="$STATURLSTYLE"/>
          <xsl:with-param name="string">
            <xsl:value-of select="."/>
          </xsl:with-param>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='THES'">
        <xsl:call-template name="refdb-literal">
          <xsl:with-param name="style" select="$THESURLSTYLE"/>
          <xsl:with-param name="string">
            <xsl:value-of select="."/>
          </xsl:with-param>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='UNBILL'">
        <xsl:call-template name="refdb-literal">
          <xsl:with-param name="style" select="$UNBILLURLSTYLE"/>
          <xsl:with-param name="string">
            <xsl:value-of select="."/>
          </xsl:with-param>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='UNPB'">
        <xsl:call-template name="refdb-literal">
          <xsl:with-param name="style" select="$UNPBURLSTYLE"/>
          <xsl:with-param name="string">
            <xsl:value-of select="."/>
          </xsl:with-param>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='VIDEO'">
        <xsl:call-template name="refdb-literal">
          <xsl:with-param name="style" select="$VIDEOURLSTYLE"/>
          <xsl:with-param name="string">
            <xsl:value-of select="."/>
          </xsl:with-param>
        </xsl:call-template>
      </xsl:when>
    </xsl:choose>
  </a>
</xsl:template>

<!-- overrides for xref elements -->
<!-- *************************** -->

<!-- in-text citation elements. If it is a multiple citation, process
     only the MULTIXREF ptr element, otherwise process all -->
<xsl:template match="d:citation[@role='REFDB']">
  <xsl:choose>
    <xsl:when test="./d:xref[@role='MULTIXREF']">
      <xsl:apply-templates mode="refdb" select="./d:xref[@role='MULTIXREF']"/>
    </xsl:when>
    <xsl:otherwise>
      <xsl:apply-templates mode="refdb"/>
      </xsl:otherwise>
  </xsl:choose>
</xsl:template>

<!-- pull in the appropriate elements to create the link text -->
<xsl:template match="d:xref" mode="refdb">
  <xsl:choose>
    <xsl:when test="@role='MULTIXREF'">
      <xsl:variable name="multitarget" select="substring(following-sibling::d:xref/@linkend, 1, string-length(following-sibling::d:xref/@linkend) - 2)"/>
      <a href='#{$multitarget}'>
      <xsl:call-template name="refdb-literal">
        <xsl:with-param name="style" select="$INTEXTREFNUMBERSTYLE"/>
        <xsl:with-param name="string">
          <xsl:value-of select="id(@endterm)"/>
        </xsl:with-param>
      </xsl:call-template>
      </a>
    </xsl:when>
    <xsl:otherwise>
      <xsl:variable name="realtarget" select="substring(@linkend, 1, string-length(@linkend) - 2)"/>
      <xsl:variable name="ptrtype" select="id(@linkend)/@role"/>
      <a href='#{$realtarget}'>
        <xsl:choose>
          <xsl:when test="$ptrtype='intext'">
            <xsl:apply-templates mode="INTEXT" select="id(@linkend)"/>
          </xsl:when>
          <xsl:when test="$ptrtype='intextsq'">
            <xsl:apply-templates mode="INTEXT" select="id(@linkend)"/>
          </xsl:when>
          <xsl:when test="$ptrtype='authoronly'">
            <xsl:apply-templates mode="AUTHORONLY" select="id(@linkend)"/>
          </xsl:when>
          <xsl:when test="$ptrtype='authoronlysq'">
            <xsl:apply-templates mode="AUTHORONLY" select="id(@linkend)"/>
          </xsl:when>
          <xsl:when test="$ptrtype='yearonly'">
            <xsl:apply-templates mode="YEARONLY" select="id(@linkend)"/>
          </xsl:when>
        </xsl:choose>
      </a>
      </xsl:otherwise>
  </xsl:choose>
</xsl:template>


<!-- "library" templates -->
<!-- ******************* -->

<!-- process elements with wrapped-around formatting -->
<xsl:template name="refdb-process-inline">
  <xsl:param name="style"></xsl:param>
  <xsl:choose>
    <xsl:when test="$style='ULINE'">
      <u><xsl:apply-templates mode="refdb"/></u>
    </xsl:when>
    <xsl:when test="$style='ITULINE'">
      <i><u><xsl:apply-templates mode="refdb"/></u></i>
    </xsl:when>
    <xsl:when test="$style='BOLDULINE'">
      <b><u><xsl:apply-templates mode="refdb"/></u></b>
    </xsl:when>
    <xsl:when test="$style='BOLDITULINE'">
      <b><i><u><xsl:apply-templates mode="refdb"/></u></i></b>
    </xsl:when>
    <xsl:when test="$style='ITALIC'">
      <i><xsl:apply-templates mode="refdb"/></i>
    </xsl:when>
    <xsl:when test="$style='BOLDITALIC'">
      <b><i><xsl:apply-templates mode="refdb"/></i></b>
    </xsl:when>
    <xsl:when test="$style='BOLD'">
      <b><xsl:apply-templates mode="refdb"/></b>
    </xsl:when>
    <xsl:when test="$style='SUB'">
      <sub><xsl:apply-templates mode="refdb"/></sub>
    </xsl:when>
    <xsl:when test="$style='SUPER'">
      <sup><xsl:apply-templates mode="refdb"/></sup>
    </xsl:when>
    <xsl:otherwise>
      <xsl:apply-templates mode="refdb"/>
    </xsl:otherwise>
  </xsl:choose>
</xsl:template>

<!-- process string with wrapped-around formatting -->
<xsl:template name="refdb-literal">
  <xsl:param name="style"></xsl:param>
  <xsl:param name="string"></xsl:param>
  <xsl:if test="$style='ULINE' or $style='ITULINE' or $style='BOLDULINE' or $style='BOLDITULINE'">
    <xsl:text disable-output-escaping="yes">&lt;u&gt;</xsl:text>
  </xsl:if>
  <xsl:if test="$style='ITALIC' or $style='ITULINE' or $style='BOLDITALIC' or $style='BOLDITULINE'">
    <xsl:text disable-output-escaping="yes">&lt;i&gt;</xsl:text>
  </xsl:if>
  <xsl:if test="$style='BOLD' or $style='BOLDITALIC' or $style='BOLDULINE' or $style='BOLDITULINE'">
    <xsl:text disable-output-escaping="yes">&lt;b&gt;</xsl:text>
  </xsl:if>
  <xsl:if test="$style='SUB'">
    <xsl:text disable-output-escaping="yes">&lt;sub&gt;</xsl:text>
  </xsl:if>
  <xsl:if test="$style='SUPER'">
    <xsl:text disable-output-escaping="yes">&lt;sup&gt;</xsl:text>
  </xsl:if>
  <xsl:value-of select="$string"/>
  <xsl:if test="$style='SUPER'">
    <xsl:text disable-output-escaping="yes">&lt;/sup&gt;</xsl:text>
  </xsl:if>
  <xsl:if test="$style='SUB'">
    <xsl:text disable-output-escaping="yes">&lt;/sub&gt;</xsl:text>
  </xsl:if>
  <xsl:if test="$style='BOLD' or $style='BOLDITALIC' or $style='BOLDULINE' or $style='BOLDITULINE'">
    <xsl:text disable-output-escaping="yes">&lt;/b&gt;</xsl:text>
  </xsl:if>
  <xsl:if test="$style='ITALIC' or $style='ITULINE' or $style='BOLDITALIC' or $style='BOLDITULINE'">
    <xsl:text disable-output-escaping="yes">&lt;/i&gt;</xsl:text>
  </xsl:if>
  <xsl:if test="$style='ULINE' or $style='ITULINE' or $style='BOLDULINE' or $style='BOLDITULINE'">
    <xsl:text disable-output-escaping="yes">&lt;/u&gt;</xsl:text>
  </xsl:if>
</xsl:template>

</xsl:stylesheet>