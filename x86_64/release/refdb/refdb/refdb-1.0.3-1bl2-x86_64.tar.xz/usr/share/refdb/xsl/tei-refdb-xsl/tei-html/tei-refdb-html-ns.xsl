<!--
XSL HTML stylesheet driver file for TEI XML documents using RefDB citations
and bibliographies.

mhoenicka@users.sourceforge.net 2001-12-23

Copyright blurb
-->

<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:tei="http://www.tei-c.org/ns/1.0" version="1.0">

<!-- the original TEI stylesheets for HTML -->
<xsl:import href="http://www.tei-c.org/Stylesheets/p4/html/tei.xsl"/>

<!-- common variables -->
<xsl:import href="/usr/share/refdb/xsl/common-refdb/refdbvar.xsl"/>

<!-- common templates -->
<xsl:import href="/usr/share/refdb/xsl/tei-refdb-xsl/tei-lib/tei-refdblib-ns.xsl"/>

<!-- settings of some variables -->

<!-- <xsl:variable name="masterFile">index</xsl:variable> -->
<xsl:variable name="cssFile"></xsl:variable>

<!-- the following variable is used to make xsltproc write to stdout -->
<xsl:variable name="STDOUT">true</xsl:variable>
<xsl:variable name="alignNavigationPanel">center</xsl:variable>
<xsl:variable name="topNavigationPanel"></xsl:variable>
<xsl:variable name="bottomNavigationPanel">true</xsl:variable>
<xsl:variable name="institution">CustomizeMe:institution</xsl:variable>
<xsl:variable name="homeURL">CustomizeMe:homeURL</xsl:variable>
<xsl:variable name="homeWords">CustomizeMe:homeWords</xsl:variable>
<xsl:variable name="parentURL">CustomizeMe:parentURL</xsl:variable>
<xsl:variable name="parentWords">CustomizeMe:parentWords</xsl:variable>
<xsl:variable name="feedbackURL">CustomizeMe:feedbackURL</xsl:variable>
<xsl:variable name="feedbackWords">CustomizeMe:feedbackWords</xsl:variable>
<xsl:variable name="searchURL"></xsl:variable>
<xsl:variable name="searchWords"></xsl:variable>
<xsl:template name="logoPicture"></xsl:template>
<xsl:variable name="useIDs"></xsl:variable>
<xsl:template name="copyrightStatement">CustomizeMe:copyrightStatement</xsl:template>


<!-- overrides for bibliography elements -->
<!-- *********************************** -->

<!-- we pick only RefDB bibliographies -->
<xsl:template match="tei:listBibl[@rend='refdb']">
 <xsl:for-each select="tei:bibl">
  <p><xsl:apply-templates select="." mode="refdb"/></p>
 </xsl:for-each>
</xsl:template>

<!-- one bibliography entry. We process only the bibliography part
     and suppress the inline parts -->
<xsl:template match="tei:bibl" mode="refdb">
  <xsl:choose>
    <xsl:when test="@rend='multixref'">
      <!-- do not render directly -->
    </xsl:when>
    <xsl:otherwise>
      <a name="{@xml:id}"/>
      <xsl:apply-templates select="tei:seg[@type='bibliography']" mode="refdb"/>
    </xsl:otherwise>
  </xsl:choose>
</xsl:template>

<!-- ulink needs special care as we want to hyperlink -->
<xsl:template match="tei:seg[@type='ulink']" mode="refdb">
  <xsl:variable name="reftype" select="ancestor::tei:bibl/@rend"/>
  <xsl:variable name="target" select="."/>
  <a href='{$target}'>
  <xsl:choose>
    <xsl:when test="$reftype='ABST'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$ABSTURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='ADVS'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$ADVSURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='ART'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$ARTURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='BILL'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$BILLURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='BOOK'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$BOOKURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='CASE'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$CASEURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='CHAP'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$CHAPURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='COMP'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$COMPURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='CONF'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$CONFURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='CTLG'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$CTLGURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='DATA'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$DATAURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='ELEC'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$ELECURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='GEN'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$GENURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='HEAR'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$HEARURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='ICOMM'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$ICOMMURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='INPR'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$INPRURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='JFULL'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$JFULLURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='JOUR'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$JOURURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='MAP'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$MAPURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='MGZN'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$MGZNURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='MPCT'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$MPCTURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='MUSIC'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$MUSICURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='NEWS'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$NEWSURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='PAMP'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$PAMPURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='PAT'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$PATURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='PCOMM'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$PCOMMURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='RPRT'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$RPRTURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='SER'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$SERURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='SLIDE'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$SLIDEURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='SOUND'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$SOUNDURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='STAT'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$STATURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='THES'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$THESURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='UNBILL'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$UNBILLURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='UNPB'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$UNPBURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='VIDEO'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$VIDEOURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
  </xsl:choose>
  </a>
</xsl:template>


<!-- overrides for xref elements -->
<!-- *************************** -->

<!-- in-text citation elements. If it is a multiple citation, process
     only the MULTIXREF ptr element, otherwise process all -->
<xsl:template match="tei:seg[@type='REFDBCITATION']">
  <xsl:choose>
    <xsl:when test="./tei:ptr[@type='MULTIXREF']">
      <xsl:apply-templates mode="refdb" select="./tei:ptr[@type='MULTIXREF']"/>
    </xsl:when>
    <xsl:otherwise>
      <xsl:apply-templates mode="refdb"/>
      </xsl:otherwise>
  </xsl:choose>
</xsl:template>

<!-- pull in the appropriate elements to create the link text -->
<xsl:template match="tei:ptr" mode="refdb">
  <xsl:choose>
    <xsl:when test="@type='MULTIXREF'">
      <xsl:variable name="multitarget" select="substring(following-sibling::tei:ptr/@target, 1, string-length(following-sibling::tei:ptr/@target) - 2)"/>
      <a href='#{$multitarget}'>
      <xsl:call-template name="refdb-literal">
        <xsl:with-param name="style" select="$REFNUMBERSTYLE"/>
        <xsl:with-param name="string">
          <xsl:value-of select="id(@target)"/>
        </xsl:with-param>
      </xsl:call-template>
      </a>
    </xsl:when>
    <xsl:otherwise>
      <xsl:variable name="realtarget" select="substring(@target, 1, string-length(@target) - 2)"/>
      <xsl:variable name="ptrtype" select="id(@target)/@type"/>
      <a href='#{$realtarget}'>
        <xsl:choose>
          <xsl:when test="$ptrtype='intext'">
            <xsl:apply-templates mode="INTEXT" select="id(@target)"/>
          </xsl:when>
          <xsl:when test="$ptrtype='intextsq'">
            <xsl:apply-templates mode="INTEXTSQ" select="id(@target)"/>
          </xsl:when>
          <xsl:when test="$ptrtype='authoronly'">
            <xsl:apply-templates mode="AUTHORONLY" select="id(@target)"/>
          </xsl:when>
          <xsl:when test="$ptrtype='authoronlysq'">
            <xsl:apply-templates mode="AUTHORONLYSQ" select="id(@target)"/>
          </xsl:when>
          <xsl:when test="$ptrtype='yearonly'">
            <xsl:apply-templates mode="YEARONLY" select="id(@target)"/>
          </xsl:when>
        </xsl:choose>
      </a>
      </xsl:otherwise>
  </xsl:choose>
</xsl:template>


<!-- "library" templates -->
<!-- ******************* -->

<!-- process elements with wrapped-around formatting -->
<xsl:template name="refdb-process-inline">
  <xsl:param name="style"></xsl:param>
  <xsl:choose>
    <xsl:when test="$style='ULINE'">
      <u><xsl:apply-templates mode="refdb"/></u>
    </xsl:when>
    <xsl:when test="$style='ITULINE'">
      <i><u><xsl:apply-templates mode="refdb"/></u></i>
    </xsl:when>
    <xsl:when test="$style='BOLDULINE'">
      <b><u><xsl:apply-templates mode="refdb"/></u></b>
    </xsl:when>
    <xsl:when test="$style='BOLDITULINE'">
      <b><i><u><xsl:apply-templates mode="refdb"/></u></i></b>
    </xsl:when>
    <xsl:when test="$style='ITALIC'">
      <i><xsl:apply-templates mode="refdb"/></i>
    </xsl:when>
    <xsl:when test="$style='BOLDITALIC'">
      <b><i><xsl:apply-templates mode="refdb"/></i></b>
    </xsl:when>
    <xsl:when test="$style='BOLD'">
      <b><xsl:apply-templates mode="refdb"/></b>
    </xsl:when>
    <xsl:when test="$style='SUB'">
      <sub><xsl:apply-templates mode="refdb"/></sub>
    </xsl:when>
    <xsl:when test="$style='SUPER'">
      <sup><xsl:apply-templates mode="refdb"/></sup>
    </xsl:when>
    <xsl:otherwise>
      <xsl:apply-templates mode="refdb"/>
    </xsl:otherwise>
  </xsl:choose>
</xsl:template>

<!-- process string with wrapped-around formatting -->
<xsl:template name="refdb-literal">
  <xsl:param name="style"></xsl:param>
  <xsl:param name="string"></xsl:param>
  <xsl:if test="$style='ULINE' or $style='ITULINE' or $style='BOLDULINE' or $style='BOLDITULINE'">
    <xsl:text disable-output-escaping="yes">&lt;u&gt;</xsl:text>
  </xsl:if>
  <xsl:if test="$style='ITALIC' or $style='ITULINE' or $style='BOLDITALIC' or $style='BOLDITULINE'">
    <xsl:text disable-output-escaping="yes">&lt;i&gt;</xsl:text>
  </xsl:if>
  <xsl:if test="$style='BOLD' or $style='BOLDITALIC' or $style='BOLDULINE' or $style='BOLDITULINE'">
    <xsl:text disable-output-escaping="yes">&lt;b&gt;</xsl:text>
  </xsl:if>
  <xsl:if test="$style='SUB'">
    <xsl:text disable-output-escaping="yes">&lt;sub&gt;</xsl:text>
  </xsl:if>
  <xsl:if test="$style='SUPER'">
    <xsl:text disable-output-escaping="yes">&lt;sup&gt;</xsl:text>
  </xsl:if>
  <xsl:value-of select="$string"/>
  <xsl:if test="$style='SUPER'">
    <xsl:text disable-output-escaping="yes">&lt;/sup&gt;</xsl:text>
  </xsl:if>
  <xsl:if test="$style='SUB'">
    <xsl:text disable-output-escaping="yes">&lt;/sub&gt;</xsl:text>
  </xsl:if>
  <xsl:if test="$style='BOLD' or $style='BOLDITALIC' or $style='BOLDULINE' or $style='BOLDITULINE'">
    <xsl:text disable-output-escaping="yes">&lt;/b&gt;</xsl:text>
  </xsl:if>
  <xsl:if test="$style='ITALIC' or $style='ITULINE' or $style='BOLDITALIC' or $style='BOLDITULINE'">
    <xsl:text disable-output-escaping="yes">&lt;/i&gt;</xsl:text>
  </xsl:if>
  <xsl:if test="$style='ULINE' or $style='ITULINE' or $style='BOLDULINE' or $style='BOLDITULINE'">
    <xsl:text disable-output-escaping="yes">&lt;/u&gt;</xsl:text>
  </xsl:if>
</xsl:template>

</xsl:stylesheet>