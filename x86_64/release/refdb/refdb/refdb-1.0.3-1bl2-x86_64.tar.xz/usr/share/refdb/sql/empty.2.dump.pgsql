--
-- PostgreSQL database dump
--

SET client_encoding = 'UNICODE';
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pgsql
--

COMMENT ON SCHEMA public IS 'Standard public schema';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = true;

--
-- Name: t_author; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE t_author (
    author_id bigserial NOT NULL,
    author_name character varying(255) NOT NULL,
    author_lastname character varying(255),
    author_firstname character varying(255),
    author_middlename character varying(255),
    author_suffix character varying(255)
);


ALTER TABLE public.t_author OWNER TO root;

--
-- Name: t_author_author_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('t_author', 'author_id'), 1, false);


--
-- Name: t_keyword; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE t_keyword (
    keyword_id bigserial NOT NULL,
    keyword_name character varying(255) NOT NULL
);


ALTER TABLE public.t_keyword OWNER TO root;

--
-- Name: t_keyword_keyword_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('t_keyword', 'keyword_id'), 1, false);


--
-- Name: t_link; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE t_link (
    link_id bigserial NOT NULL,
    link_url text NOT NULL
);


ALTER TABLE public.t_link OWNER TO root;

--
-- Name: t_link_link_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('t_link', 'link_id'), 1, false);


--
-- Name: t_meta; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE t_meta (
    meta_app character varying(20),
    meta_type character varying(20),
    meta_version character varying(20),
    meta_dbversion smallint,
    meta_create_date timestamp without time zone,
    meta_modify_date timestamp without time zone
);


ALTER TABLE public.t_meta OWNER TO root;

--
-- Name: t_note; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE t_note (
    note_id bigserial NOT NULL,
    note_key character varying(255),
    note_title character varying(255),
    note_content text,
    note_content_type character varying(255),
    note_content_xmllang character varying(255),
    note_user_id bigint,
    note_date date,
    note_share smallint
);


ALTER TABLE public.t_note OWNER TO root;

--
-- Name: t_note_note_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('t_note', 'note_id'), 1, false);


--
-- Name: t_periodical; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE t_periodical (
    periodical_id bigserial NOT NULL,
    periodical_name character varying(255),
    periodical_abbrev character varying(255),
    periodical_custabbrev1 character varying(255),
    periodical_custabbrev2 character varying(255)
);


ALTER TABLE public.t_periodical OWNER TO root;

--
-- Name: t_periodical_periodical_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('t_periodical', 'periodical_id'), 1, false);


--
-- Name: t_refdb; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE t_refdb (
    refdb_id bigserial NOT NULL,
    refdb_citekey character varying(255),
    refdb_type character varying(6),
    refdb_pubyear smallint,
    refdb_secyear smallint,
    refdb_startpage character varying(255),
    refdb_endpage character varying(255),
    refdb_abstract text,
    refdb_title text,
    refdb_volume character varying(255),
    refdb_issue character varying(255),
    refdb_booktitle text,
    refdb_city character varying(255),
    refdb_publisher character varying(255),
    refdb_title_series text,
    refdb_address text,
    refdb_issn character varying(255),
    refdb_pyother_info character varying(255),
    refdb_secother_info character varying(255),
    refdb_periodical_id bigint,
    refdb_user1 character varying(255),
    refdb_user2 character varying(255),
    refdb_user3 character varying(255),
    refdb_user4 character varying(255),
    refdb_user5 character varying(255),
    refdb_misc1 character varying(255),
    refdb_misc2 character varying(255),
    refdb_misc3 character varying(255)
);


ALTER TABLE public.t_refdb OWNER TO root;

--
-- Name: t_refdb_refdb_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('t_refdb', 'refdb_id'), 1, false);


--
-- Name: t_user; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE t_user (
    user_id bigserial NOT NULL,
    user_name character varying(16) NOT NULL
);


ALTER TABLE public.t_user OWNER TO root;

--
-- Name: t_user_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('t_user', 'user_id'), 1, false);


--
-- Name: t_xauthor; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE t_xauthor (
    xauthor_id bigserial NOT NULL,
    author_id bigint NOT NULL,
    refdb_id bigint NOT NULL,
    xauthor_type smallint DEFAULT 1,
    xauthor_role character varying(64),
    xauthor_position integer
);


ALTER TABLE public.t_xauthor OWNER TO root;

--
-- Name: t_xauthor_xauthor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('t_xauthor', 'xauthor_id'), 1, false);


--
-- Name: t_xkeyword; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE t_xkeyword (
    xkeyword_id bigserial NOT NULL,
    keyword_id bigint NOT NULL,
    xkeyword_type character varying(11) DEFAULT 'REFERENCE'::character varying,
    xref_id bigint NOT NULL
);


ALTER TABLE public.t_xkeyword OWNER TO root;

--
-- Name: t_xkeyword_xkeyword_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('t_xkeyword', 'xkeyword_id'), 1, false);


--
-- Name: t_xlink; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE t_xlink (
    xlink_id bigserial NOT NULL,
    link_id bigint NOT NULL,
    xref_id bigint NOT NULL,
    xlink_type character varying(11) DEFAULT 'URL'::character varying,
    xlink_source character varying(11) DEFAULT 'REFERENCE'::character varying
);


ALTER TABLE public.t_xlink OWNER TO root;

--
-- Name: t_xlink_xlink_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('t_xlink', 'xlink_id'), 1, false);


--
-- Name: t_xnote; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE t_xnote (
    xnote_id bigserial NOT NULL,
    note_id bigint NOT NULL,
    xref_id bigint NOT NULL,
    xnote_type character varying(11) DEFAULT 'REFERENCE'::character varying
);


ALTER TABLE public.t_xnote OWNER TO root;

--
-- Name: t_xnote_xnote_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('t_xnote', 'xnote_id'), 1, false);


--
-- Name: t_xuser; Type: TABLE; Schema: public; Owner: root; Tablespace: 
--

CREATE TABLE t_xuser (
    xuser_id bigserial NOT NULL,
    user_id bigint NOT NULL,
    refdb_id bigint NOT NULL,
    xuser_reprint character varying(11) DEFAULT 'NOT IN FILE'::character varying,
    xuser_date date,
    xuser_avail character varying(255),
    xuser_notes text
);


ALTER TABLE public.t_xuser OWNER TO root;

--
-- Name: t_xuser_xuser_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('t_xuser', 'xuser_id'), 1, false);


--
-- Data for Name: t_author; Type: TABLE DATA; Schema: public; Owner: root
--

COPY t_author (author_id, author_name, author_lastname, author_firstname, author_middlename, author_suffix) FROM stdin;
\.


--
-- Data for Name: t_keyword; Type: TABLE DATA; Schema: public; Owner: root
--

COPY t_keyword (keyword_id, keyword_name) FROM stdin;
\.


--
-- Data for Name: t_link; Type: TABLE DATA; Schema: public; Owner: root
--

COPY t_link (link_id, link_url) FROM stdin;
\.


--
-- Data for Name: t_meta; Type: TABLE DATA; Schema: public; Owner: root
--

COPY t_meta (meta_app, meta_type, meta_version, meta_dbversion, meta_create_date, meta_modify_date) FROM stdin;
refdb	risx	1.0.3	2	CURRENT_TIMESTAMP	CURRENT_TIMESTAMP
\.


--
-- Data for Name: t_note; Type: TABLE DATA; Schema: public; Owner: root
--

COPY t_note (note_id, note_key, note_title, note_content, note_content_type, note_content_xmllang, note_user_id, note_date, note_share) FROM stdin;
\.


--
-- Data for Name: t_periodical; Type: TABLE DATA; Schema: public; Owner: root
--

COPY t_periodical (periodical_id, periodical_name, periodical_abbrev, periodical_custabbrev1, periodical_custabbrev2) FROM stdin;
\.


--
-- Data for Name: t_refdb; Type: TABLE DATA; Schema: public; Owner: root
--

COPY t_refdb (refdb_id, refdb_citekey, refdb_type, refdb_pubyear, refdb_secyear, refdb_startpage, refdb_endpage, refdb_abstract, refdb_title, refdb_volume, refdb_issue, refdb_booktitle, refdb_city, refdb_publisher, refdb_title_series, refdb_address, refdb_issn, refdb_pyother_info, refdb_secother_info, refdb_periodical_id, refdb_user1, refdb_user2, refdb_user3, refdb_user4, refdb_user5, refdb_misc1, refdb_misc2, refdb_misc3) FROM stdin;
\.


--
-- Data for Name: t_user; Type: TABLE DATA; Schema: public; Owner: root
--

COPY t_user (user_id, user_name) FROM stdin;
\.


--
-- Data for Name: t_xauthor; Type: TABLE DATA; Schema: public; Owner: root
--

COPY t_xauthor (xauthor_id, author_id, refdb_id, xauthor_type, xauthor_role, xauthor_position) FROM stdin;
\.


--
-- Data for Name: t_xkeyword; Type: TABLE DATA; Schema: public; Owner: root
--

COPY t_xkeyword (xkeyword_id, keyword_id, xkeyword_type, xref_id) FROM stdin;
\.


--
-- Data for Name: t_xlink; Type: TABLE DATA; Schema: public; Owner: root
--

COPY t_xlink (xlink_id, link_id, xref_id, xlink_type, xlink_source) FROM stdin;
\.


--
-- Data for Name: t_xnote; Type: TABLE DATA; Schema: public; Owner: root
--

COPY t_xnote (xnote_id, note_id, xref_id, xnote_type) FROM stdin;
\.


--
-- Data for Name: t_xuser; Type: TABLE DATA; Schema: public; Owner: root
--

COPY t_xuser (xuser_id, user_id, refdb_id, xuser_reprint, xuser_date, xuser_avail, xuser_notes) FROM stdin;
\.


--
-- Name: t_author_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY t_author
    ADD CONSTRAINT t_author_pkey PRIMARY KEY (author_id);


ALTER INDEX public.t_author_pkey OWNER TO root;

--
-- Name: t_keyword_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY t_keyword
    ADD CONSTRAINT t_keyword_pkey PRIMARY KEY (keyword_id);


ALTER INDEX public.t_keyword_pkey OWNER TO root;

--
-- Name: t_link_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY t_link
    ADD CONSTRAINT t_link_pkey PRIMARY KEY (link_id);


ALTER INDEX public.t_link_pkey OWNER TO root;

--
-- Name: t_note_note_key_key; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY t_note
    ADD CONSTRAINT t_note_note_key_key UNIQUE (note_key);


ALTER INDEX public.t_note_note_key_key OWNER TO root;

--
-- Name: t_note_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY t_note
    ADD CONSTRAINT t_note_pkey PRIMARY KEY (note_id);


ALTER INDEX public.t_note_pkey OWNER TO root;

--
-- Name: t_periodical_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY t_periodical
    ADD CONSTRAINT t_periodical_pkey PRIMARY KEY (periodical_id);


ALTER INDEX public.t_periodical_pkey OWNER TO root;

--
-- Name: t_refdb_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY t_refdb
    ADD CONSTRAINT t_refdb_pkey PRIMARY KEY (refdb_id);


ALTER INDEX public.t_refdb_pkey OWNER TO root;

--
-- Name: t_refdb_refdb_citekey_key; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY t_refdb
    ADD CONSTRAINT t_refdb_refdb_citekey_key UNIQUE (refdb_citekey);


ALTER INDEX public.t_refdb_refdb_citekey_key OWNER TO root;

--
-- Name: t_user_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY t_user
    ADD CONSTRAINT t_user_pkey PRIMARY KEY (user_id);


ALTER INDEX public.t_user_pkey OWNER TO root;

--
-- Name: t_xauthor_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY t_xauthor
    ADD CONSTRAINT t_xauthor_pkey PRIMARY KEY (xauthor_id);


ALTER INDEX public.t_xauthor_pkey OWNER TO root;

--
-- Name: t_xkeyword_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY t_xkeyword
    ADD CONSTRAINT t_xkeyword_pkey PRIMARY KEY (xkeyword_id);


ALTER INDEX public.t_xkeyword_pkey OWNER TO root;

--
-- Name: t_xlink_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY t_xlink
    ADD CONSTRAINT t_xlink_pkey PRIMARY KEY (xlink_id);


ALTER INDEX public.t_xlink_pkey OWNER TO root;

--
-- Name: t_xnote_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY t_xnote
    ADD CONSTRAINT t_xnote_pkey PRIMARY KEY (xnote_id);


ALTER INDEX public.t_xnote_pkey OWNER TO root;

--
-- Name: t_xuser_pkey; Type: CONSTRAINT; Schema: public; Owner: root; Tablespace: 
--

ALTER TABLE ONLY t_xuser
    ADD CONSTRAINT t_xuser_pkey PRIMARY KEY (xuser_id);


ALTER INDEX public.t_xuser_pkey OWNER TO root;

--
-- Name: i_author_name; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX i_author_name ON t_author USING btree (author_name);


ALTER INDEX public.i_author_name OWNER TO root;

--
-- Name: i_keyword_name; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX i_keyword_name ON t_keyword USING btree (keyword_name);


ALTER INDEX public.i_keyword_name OWNER TO root;

--
-- Name: i_link_url; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX i_link_url ON t_link USING btree (link_url);


ALTER INDEX public.i_link_url OWNER TO root;

--
-- Name: i_note_date; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX i_note_date ON t_note USING btree (note_date);


ALTER INDEX public.i_note_date OWNER TO root;

--
-- Name: i_note_note_user_id; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX i_note_note_user_id ON t_note USING btree (note_user_id);


ALTER INDEX public.i_note_note_user_id OWNER TO root;

--
-- Name: i_note_title; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX i_note_title ON t_note USING btree (note_title);


ALTER INDEX public.i_note_title OWNER TO root;

--
-- Name: i_periodical_abbrev; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX i_periodical_abbrev ON t_periodical USING btree (periodical_abbrev);


ALTER INDEX public.i_periodical_abbrev OWNER TO root;

--
-- Name: i_periodical_custabbrev1; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX i_periodical_custabbrev1 ON t_periodical USING btree (periodical_custabbrev1);


ALTER INDEX public.i_periodical_custabbrev1 OWNER TO root;

--
-- Name: i_periodical_custabbrev2; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX i_periodical_custabbrev2 ON t_periodical USING btree (periodical_custabbrev2);


ALTER INDEX public.i_periodical_custabbrev2 OWNER TO root;

--
-- Name: i_periodical_name; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX i_periodical_name ON t_periodical USING btree (periodical_name);


ALTER INDEX public.i_periodical_name OWNER TO root;

--
-- Name: i_pubyear; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX i_pubyear ON t_refdb USING btree (refdb_pubyear);


ALTER INDEX public.i_pubyear OWNER TO root;

--
-- Name: i_user_name; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX i_user_name ON t_user USING btree (user_name);


ALTER INDEX public.i_user_name OWNER TO root;

--
-- Name: i_xauthor_author_id; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX i_xauthor_author_id ON t_xauthor USING btree (author_id);


ALTER INDEX public.i_xauthor_author_id OWNER TO root;

--
-- Name: i_xauthor_refdb_id; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX i_xauthor_refdb_id ON t_xauthor USING btree (refdb_id);


ALTER INDEX public.i_xauthor_refdb_id OWNER TO root;

--
-- Name: i_xkeyword_keyword_id; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX i_xkeyword_keyword_id ON t_xkeyword USING btree (keyword_id);


ALTER INDEX public.i_xkeyword_keyword_id OWNER TO root;

--
-- Name: i_xkeyword_xref_id; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX i_xkeyword_xref_id ON t_xkeyword USING btree (xref_id);


ALTER INDEX public.i_xkeyword_xref_id OWNER TO root;

--
-- Name: i_xlink_link_id; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX i_xlink_link_id ON t_xlink USING btree (link_id);


ALTER INDEX public.i_xlink_link_id OWNER TO root;

--
-- Name: i_xlink_xlink_source; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX i_xlink_xlink_source ON t_xlink USING btree (xlink_source);


ALTER INDEX public.i_xlink_xlink_source OWNER TO root;

--
-- Name: i_xlink_xlink_type; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX i_xlink_xlink_type ON t_xlink USING btree (xlink_type);


ALTER INDEX public.i_xlink_xlink_type OWNER TO root;

--
-- Name: i_xlink_xref_id; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX i_xlink_xref_id ON t_xlink USING btree (xref_id);


ALTER INDEX public.i_xlink_xref_id OWNER TO root;

--
-- Name: i_xnote_note_id; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX i_xnote_note_id ON t_xnote USING btree (note_id);


ALTER INDEX public.i_xnote_note_id OWNER TO root;

--
-- Name: i_xnote_xnote_type; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX i_xnote_xnote_type ON t_xnote USING btree (xnote_type);


ALTER INDEX public.i_xnote_xnote_type OWNER TO root;

--
-- Name: i_xnote_xref_id; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX i_xnote_xref_id ON t_xnote USING btree (xref_id);


ALTER INDEX public.i_xnote_xref_id OWNER TO root;

--
-- Name: i_xuser_refdb_id; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX i_xuser_refdb_id ON t_xuser USING btree (refdb_id);


ALTER INDEX public.i_xuser_refdb_id OWNER TO root;

--
-- Name: i_xuser_user_id; Type: INDEX; Schema: public; Owner: root; Tablespace: 
--

CREATE INDEX i_xuser_user_id ON t_xuser USING btree (user_id);


ALTER INDEX public.i_xuser_user_id OWNER TO root;

--
-- Name: public; Type: ACL; Schema: -; Owner: pgsql
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM pgsql;
GRANT ALL ON SCHEMA public TO pgsql;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- Name: t_author; Type: ACL; Schema: public; Owner: root
--

REVOKE ALL ON TABLE t_author FROM PUBLIC;
REVOKE ALL ON TABLE t_author FROM root;
GRANT ALL ON TABLE t_author TO root;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE t_author TO GROUP emptyuser;


--
-- Name: t_author_author_id_seq; Type: ACL; Schema: public; Owner: root
--

REVOKE ALL ON TABLE t_author_author_id_seq FROM PUBLIC;
REVOKE ALL ON TABLE t_author_author_id_seq FROM root;
GRANT ALL ON TABLE t_author_author_id_seq TO root;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE t_author_author_id_seq TO GROUP emptyuser;


--
-- Name: t_keyword; Type: ACL; Schema: public; Owner: root
--

REVOKE ALL ON TABLE t_keyword FROM PUBLIC;
REVOKE ALL ON TABLE t_keyword FROM root;
GRANT ALL ON TABLE t_keyword TO root;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE t_keyword TO GROUP emptyuser;


--
-- Name: t_keyword_keyword_id_seq; Type: ACL; Schema: public; Owner: root
--

REVOKE ALL ON TABLE t_keyword_keyword_id_seq FROM PUBLIC;
REVOKE ALL ON TABLE t_keyword_keyword_id_seq FROM root;
GRANT ALL ON TABLE t_keyword_keyword_id_seq TO root;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE t_keyword_keyword_id_seq TO GROUP emptyuser;


--
-- Name: t_link; Type: ACL; Schema: public; Owner: root
--

REVOKE ALL ON TABLE t_link FROM PUBLIC;
REVOKE ALL ON TABLE t_link FROM root;
GRANT ALL ON TABLE t_link TO root;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE t_link TO GROUP emptyuser;


--
-- Name: t_link_link_id_seq; Type: ACL; Schema: public; Owner: root
--

REVOKE ALL ON TABLE t_link_link_id_seq FROM PUBLIC;
REVOKE ALL ON TABLE t_link_link_id_seq FROM root;
GRANT ALL ON TABLE t_link_link_id_seq TO root;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE t_link_link_id_seq TO GROUP emptyuser;


--
-- Name: t_meta; Type: ACL; Schema: public; Owner: root
--

REVOKE ALL ON TABLE t_meta FROM PUBLIC;
REVOKE ALL ON TABLE t_meta FROM root;
GRANT ALL ON TABLE t_meta TO root;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE t_meta TO GROUP emptyuser;


--
-- Name: t_note; Type: ACL; Schema: public; Owner: root
--

REVOKE ALL ON TABLE t_note FROM PUBLIC;
REVOKE ALL ON TABLE t_note FROM root;
GRANT ALL ON TABLE t_note TO root;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE t_note TO GROUP emptyuser;


--
-- Name: t_note_note_id_seq; Type: ACL; Schema: public; Owner: root
--

REVOKE ALL ON TABLE t_note_note_id_seq FROM PUBLIC;
REVOKE ALL ON TABLE t_note_note_id_seq FROM root;
GRANT ALL ON TABLE t_note_note_id_seq TO root;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE t_note_note_id_seq TO GROUP emptyuser;


--
-- Name: t_periodical; Type: ACL; Schema: public; Owner: root
--

REVOKE ALL ON TABLE t_periodical FROM PUBLIC;
REVOKE ALL ON TABLE t_periodical FROM root;
GRANT ALL ON TABLE t_periodical TO root;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE t_periodical TO GROUP emptyuser;


--
-- Name: t_periodical_periodical_id_seq; Type: ACL; Schema: public; Owner: root
--

REVOKE ALL ON TABLE t_periodical_periodical_id_seq FROM PUBLIC;
REVOKE ALL ON TABLE t_periodical_periodical_id_seq FROM root;
GRANT ALL ON TABLE t_periodical_periodical_id_seq TO root;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE t_periodical_periodical_id_seq TO GROUP emptyuser;


--
-- Name: t_refdb; Type: ACL; Schema: public; Owner: root
--

REVOKE ALL ON TABLE t_refdb FROM PUBLIC;
REVOKE ALL ON TABLE t_refdb FROM root;
GRANT ALL ON TABLE t_refdb TO root;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE t_refdb TO GROUP emptyuser;


--
-- Name: t_refdb_refdb_id_seq; Type: ACL; Schema: public; Owner: root
--

REVOKE ALL ON TABLE t_refdb_refdb_id_seq FROM PUBLIC;
REVOKE ALL ON TABLE t_refdb_refdb_id_seq FROM root;
GRANT ALL ON TABLE t_refdb_refdb_id_seq TO root;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE t_refdb_refdb_id_seq TO GROUP emptyuser;


--
-- Name: t_user; Type: ACL; Schema: public; Owner: root
--

REVOKE ALL ON TABLE t_user FROM PUBLIC;
REVOKE ALL ON TABLE t_user FROM root;
GRANT ALL ON TABLE t_user TO root;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE t_user TO GROUP emptyuser;


--
-- Name: t_user_user_id_seq; Type: ACL; Schema: public; Owner: root
--

REVOKE ALL ON TABLE t_user_user_id_seq FROM PUBLIC;
REVOKE ALL ON TABLE t_user_user_id_seq FROM root;
GRANT ALL ON TABLE t_user_user_id_seq TO root;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE t_user_user_id_seq TO GROUP emptyuser;


--
-- Name: t_xauthor; Type: ACL; Schema: public; Owner: root
--

REVOKE ALL ON TABLE t_xauthor FROM PUBLIC;
REVOKE ALL ON TABLE t_xauthor FROM root;
GRANT ALL ON TABLE t_xauthor TO root;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE t_xauthor TO GROUP emptyuser;


--
-- Name: t_xauthor_xauthor_id_seq; Type: ACL; Schema: public; Owner: root
--

REVOKE ALL ON TABLE t_xauthor_xauthor_id_seq FROM PUBLIC;
REVOKE ALL ON TABLE t_xauthor_xauthor_id_seq FROM root;
GRANT ALL ON TABLE t_xauthor_xauthor_id_seq TO root;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE t_xauthor_xauthor_id_seq TO GROUP emptyuser;


--
-- Name: t_xkeyword; Type: ACL; Schema: public; Owner: root
--

REVOKE ALL ON TABLE t_xkeyword FROM PUBLIC;
REVOKE ALL ON TABLE t_xkeyword FROM root;
GRANT ALL ON TABLE t_xkeyword TO root;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE t_xkeyword TO GROUP emptyuser;


--
-- Name: t_xkeyword_xkeyword_id_seq; Type: ACL; Schema: public; Owner: root
--

REVOKE ALL ON TABLE t_xkeyword_xkeyword_id_seq FROM PUBLIC;
REVOKE ALL ON TABLE t_xkeyword_xkeyword_id_seq FROM root;
GRANT ALL ON TABLE t_xkeyword_xkeyword_id_seq TO root;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE t_xkeyword_xkeyword_id_seq TO GROUP emptyuser;


--
-- Name: t_xlink; Type: ACL; Schema: public; Owner: root
--

REVOKE ALL ON TABLE t_xlink FROM PUBLIC;
REVOKE ALL ON TABLE t_xlink FROM root;
GRANT ALL ON TABLE t_xlink TO root;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE t_xlink TO GROUP emptyuser;


--
-- Name: t_xlink_xlink_id_seq; Type: ACL; Schema: public; Owner: root
--

REVOKE ALL ON TABLE t_xlink_xlink_id_seq FROM PUBLIC;
REVOKE ALL ON TABLE t_xlink_xlink_id_seq FROM root;
GRANT ALL ON TABLE t_xlink_xlink_id_seq TO root;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE t_xlink_xlink_id_seq TO GROUP emptyuser;


--
-- Name: t_xnote; Type: ACL; Schema: public; Owner: root
--

REVOKE ALL ON TABLE t_xnote FROM PUBLIC;
REVOKE ALL ON TABLE t_xnote FROM root;
GRANT ALL ON TABLE t_xnote TO root;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE t_xnote TO GROUP emptyuser;


--
-- Name: t_xnote_xnote_id_seq; Type: ACL; Schema: public; Owner: root
--

REVOKE ALL ON TABLE t_xnote_xnote_id_seq FROM PUBLIC;
REVOKE ALL ON TABLE t_xnote_xnote_id_seq FROM root;
GRANT ALL ON TABLE t_xnote_xnote_id_seq TO root;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE t_xnote_xnote_id_seq TO GROUP emptyuser;


--
-- Name: t_xuser; Type: ACL; Schema: public; Owner: root
--

REVOKE ALL ON TABLE t_xuser FROM PUBLIC;
REVOKE ALL ON TABLE t_xuser FROM root;
GRANT ALL ON TABLE t_xuser TO root;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE t_xuser TO GROUP emptyuser;


--
-- Name: t_xuser_xuser_id_seq; Type: ACL; Schema: public; Owner: root
--

REVOKE ALL ON TABLE t_xuser_xuser_id_seq FROM PUBLIC;
REVOKE ALL ON TABLE t_xuser_xuser_id_seq FROM root;
GRANT ALL ON TABLE t_xuser_xuser_id_seq TO root;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE t_xuser_xuser_id_seq TO GROUP emptyuser;


--
-- PostgreSQL database dump complete
--

