<!--
XSL FO stylesheet driver file for TEI XML documents using RefDB citations
and bibliographies.

mhoenicka@users.sourceforge.net 2001-12-23

Copyright blurb
-->

<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0" xmlns:fo="http://www.w3.org/1999/XSL/Format">

<!-- the original TEI stylesheets for FO -->
<xsl:import href="http://www.tei-c.org/Stylesheets/p4/fo/tei.xsl"/>

<!-- common variables -->
<xsl:import href="/usr/share/refdb/xsl/common-refdb/refdbvar.xsl"/>

<!-- common templates -->
<xsl:import href="/usr/share/refdb/xsl/tei-refdb-xsl/tei-lib/tei-refdblib.xsl"/>

<!-- attribute sets for later use -->
<xsl:attribute-set name="normal.para.spacing">
  <xsl:attribute name="text-indent">-<xsl:value-of select="$indentBibl"/></xsl:attribute>
  <xsl:attribute name="start-indent"><xsl:value-of select="$indentBibl"/></xsl:attribute>
</xsl:attribute-set>


<xsl:template match="listBibl[@rend='refdb']">
  <xsl:choose>
    <!-- is it in the back matter? -->
    <xsl:when test="ancestor::back">
      <fo:page-sequence>
        <fo:block>
          <xsl:call-template name="setupDiv0"/>
          <xsl:call-template name="addID"/>
          <xsl:value-of select="$biblioWords"/>
        </fo:block>
        <xsl:apply-templates/>
      </fo:page-sequence>
    </xsl:when>
    <xsl:otherwise>
      <xsl:apply-templates/>
    </xsl:otherwise>
  </xsl:choose>
</xsl:template>

<!-- try not to use mode with this element as this might interfere with its
     function as a link target -->
<xsl:template match="bibl">
  <fo:block xsl:use-attribute-sets="refdb.bibliomset">
    <xsl:call-template name="addID"/>
    <xsl:attribute name="space-before.optimum">
      <xsl:value-of select="$spaceBeforeBibl"/>
    </xsl:attribute>
    <xsl:attribute name="space-after.optimum">
      <xsl:value-of select="$spaceAfterBibl"/>
    </xsl:attribute>
    <xsl:choose>
      <xsl:when test="ancestor::listBibl/@rend = 'refdb'">
        <xsl:apply-templates select="seg[@type='bibliography']" mode="refdb"/>
      </xsl:when>
      <xsl:otherwise>
        <xsl:apply-templates/>
      </xsl:otherwise>
    </xsl:choose>
  </fo:block>
</xsl:template>


<!-- ulink needs special care as we want to hyperlink -->
<xsl:template match="biblScope[@type='ulink']" mode="refdb">
  <xsl:variable name="reftype" select="ancestor::bibl/@rend"/>
  <xsl:variable name="target" select="."/>
  <!-- the empty block forces the hyperlink into a new line. This
       is less intrusive than half-emtpy lines due to bad hyphenation
       even if the indentation is not correct. ToDo: fix indentation -->
  <fo:block/>
  <fo:basic-link external-destination='url({$target})'>
  <xsl:choose>
    <xsl:when test="$reftype='ABST'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$ABSTURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='ADVS'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$ADVSURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='ART'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$ARTURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='BILL'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$BILLURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='BOOK'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$BOOKURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='CASE'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$CASEURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='CHAP'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$CHAPURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='COMP'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$COMPURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='CONF'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$CONFURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='CTLG'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$CTLGURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='DATA'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$DATAURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='ELEC'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$ELECURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='GEN'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$GENURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='HEAR'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$HEARURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='ICOMM'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$ICOMMURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='INPR'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$INPRURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='JFULL'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$JFULLURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='JOUR'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$JOURURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='MAP'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$MAPURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='MGZN'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$MGZNURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='MPCT'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$MPCTURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='MUSIC'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$MUSICURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='NEWS'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$NEWSURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='PAMP'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$PAMPURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='PAT'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$PATURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='PCOMM'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$PCOMMURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='RPRT'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$RPRTURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='SER'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$SERURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='SLIDE'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$SLIDEURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='SOUND'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$SOUNDURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='STAT'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$STATURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='THES'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$THESURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='UNBILL'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$UNBILLURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='UNPB'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$UNPBURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
    <xsl:when test="$reftype='VIDEO'">
      <xsl:call-template name="refdb-process-inline">
        <xsl:with-param name="style" select="$VIDEOURLSTYLE"/>
      </xsl:call-template>
    </xsl:when>
  </xsl:choose>
  </fo:basic-link>
</xsl:template>


<!-- overrides for xref elements -->
<!-- *************************** -->

<!-- in-text citation elements. If it is a multiple citation, process
     only the MULTIXREF ptr element, otherwise process all -->
<xsl:template match="seg[@type='REFDBCITATION']">
  <xsl:choose>
    <xsl:when test="./ptr[@type='MULTIXREF']">
      <xsl:apply-templates mode="refdb" select="./ptr[@type='MULTIXREF']"/>
    </xsl:when>
    <xsl:otherwise>
      <xsl:apply-templates mode="refdb"/>
      </xsl:otherwise>
  </xsl:choose>
</xsl:template>

<!-- pull in the appropriate elements to create the link text -->
<xsl:template match="ptr" mode="refdb">
  <xsl:choose>
    <xsl:when test="@type='MULTIXREF'">
      <xsl:variable name="multitarget" select="substring(following-sibling::ptr/@target, 1, string-length(following-sibling::ptr/@target) - 2)"/>
      <fo:basic-link internal-destination='{$multitarget}'>
        <xsl:call-template name="refdb-literal">
          <xsl:with-param name="style" select="$REFNUMBERSTYLE"/>
          <xsl:with-param name="string">
            <xsl:value-of select="id(@target)"/>
          </xsl:with-param>
        </xsl:call-template>
      </fo:basic-link>
    </xsl:when>
    <xsl:otherwise>
      <xsl:variable name="realtarget" select="substring(@target, 1, string-length(@target) - 2)"/>
      <xsl:variable name="ptrtype" select="id(@target)/@type"/>
      <fo:basic-link internal-destination='{$realtarget}'>
        <xsl:choose>
          <xsl:when test="$ptrtype='intext'">
            <xsl:apply-templates mode="INTEXT" select="id(@target)"/>
          </xsl:when>
          <xsl:when test="$ptrtype='intextsq'">
            <xsl:apply-templates mode="INTEXTSQ" select="id(@target)"/>
          </xsl:when>
          <xsl:when test="$ptrtype='authoronly'">
            <xsl:apply-templates mode="AUTHORONLY" select="id(@target)"/>
          </xsl:when>
          <xsl:when test="$ptrtype='authoronlysq'">
            <xsl:apply-templates mode="AUTHORONLYSQ" select="id(@target)"/>
          </xsl:when>
          <xsl:when test="$ptrtype='yearonly'">
            <xsl:apply-templates mode="YEARONLY" select="id(@target)"/>
          </xsl:when>
        </xsl:choose>
      </fo:basic-link>
    </xsl:otherwise>
  </xsl:choose>
</xsl:template>

<!-- "library" templates -->
<!-- ******************* -->

<!-- process elements with wrapped-around inline element, if applicable -->
<xsl:template name="refdb-process-inline">
  <xsl:param name="style"></xsl:param>
  <xsl:choose>
    <xsl:when test="$style='ULINE'">
      <fo:inline text-decoration="underline">
        <xsl:apply-templates mode="refdb"/>
      </fo:inline>
    </xsl:when>
    <xsl:when test="$style='ITULINE'">
      <fo:inline text-decoration="underline" font-style="italic">
        <xsl:apply-templates mode="refdb"/>
      </fo:inline>
    </xsl:when>
    <xsl:when test="$style='BOLDULINE'">
      <fo:inline text-decoration="underline" font-weight="bold">
        <xsl:apply-templates mode="refdb"/>
      </fo:inline>
    </xsl:when>
    <xsl:when test="$style='BOLDITULINE'">
      <fo:inline text-decoration="underline" font-style="italic" font-weight="bold">
        <xsl:apply-templates mode="refdb"/>
      </fo:inline>
    </xsl:when>
    <xsl:when test="$style='BOLD'">
      <fo:inline font-weight="bold">
        <xsl:apply-templates mode="refdb"/>
      </fo:inline>
    </xsl:when>
    <xsl:when test="$style='ITALIC'">
      <fo:inline font-style="italic">
        <xsl:apply-templates mode="refdb"/>
      </fo:inline>
    </xsl:when>
    <xsl:when test="$style='SUB'">
      <fo:inline vertical-align="sub">
        <xsl:apply-templates mode="refdb"/>
      </fo:inline>
    </xsl:when>
    <xsl:when test="$style='SUPER'">
      <fo:inline vertical-align="super">
        <xsl:apply-templates mode="refdb"/>
      </fo:inline>
    </xsl:when>
    <xsl:otherwise>
        <xsl:apply-templates mode="refdb"/>
    </xsl:otherwise>
  </xsl:choose>
</xsl:template>

<!-- process string with wrapped-around inline element, if applicable -->
<xsl:template name="refdb-literal">
  <xsl:param name="style"></xsl:param>
  <xsl:param name="string"></xsl:param>
  <xsl:choose>
    <xsl:when test="$style='ULINE'">
      <fo:inline text-decoration="underline">
        <xsl:value-of select="$string"/>
      </fo:inline>
    </xsl:when>
    <xsl:when test="$style='ITULINE'">
      <fo:inline text-decoration="underline" font-style="italic">
        <xsl:value-of select="$string"/>
      </fo:inline>
    </xsl:when>
    <xsl:when test="$style='BOLDULINE'">
      <fo:inline text-decoration="underline" font-weight="bold">
        <xsl:value-of select="$string"/>
      </fo:inline>
    </xsl:when>
    <xsl:when test="$style='BOLDITULINE'">
      <fo:inline text-decoration="underline" font-style="italic" font-weight="bold">
        <xsl:value-of select="$string"/>
      </fo:inline>
    </xsl:when>
    <xsl:when test="$style='BOLD'">
      <fo:inline font-weight="bold">
        <xsl:value-of select="$string"/>
      </fo:inline>
    </xsl:when>
    <xsl:when test="$style='ITALIC'">
      <fo:inline font-style="italic">
        <xsl:value-of select="$string"/>
      </fo:inline>
    </xsl:when>
    <xsl:when test="$style='SUB'">
      <fo:inline vertical-align="sub">
        <xsl:value-of select="$string"/>
      </fo:inline>
    </xsl:when>
    <xsl:when test="$style='SUPER'">
      <fo:inline vertical-align="super">
        <xsl:value-of select="$string"/>
      </fo:inline>
    </xsl:when>
    <xsl:otherwise>
        <xsl:value-of select="$string"/>
    </xsl:otherwise>
  </xsl:choose>
</xsl:template>

</xsl:stylesheet>

