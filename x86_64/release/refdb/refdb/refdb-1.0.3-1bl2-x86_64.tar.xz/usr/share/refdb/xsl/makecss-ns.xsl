<?xml version="1.0" encoding="utf-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
                version="1.0">

  <xsl:output method="text" media-type="text/css"/>

  <!--
       This is a simplistic stylesheet to extract the bibliography formatting
       from a stylename.xsl file and write it to a css file. Invocation:
       xsltproc makecss.xsl stylename.xsl > stylename.css
  -->

  <xsl:template match="xsl:stylesheet">
    <xsl:apply-templates select="xsl:attribute-set"/>
  </xsl:template>

  <xsl:template match="xsl:attribute[@name='text-indent']">
div.d\:bibliomixed {text-indent: <xsl:value-of select="."/>;}
  </xsl:template>

  <xsl:template match="xsl:attribute[@name='start-indent']">
div.d\:bibliomixed {margin-left: <xsl:value-of select="."/>;}
  </xsl:template>

  <xsl:template match="xsl:attribute[@name='font-size']">
div.d\:bibliomixed {font-size: <xsl:value-of select="."/>;}
  </xsl:template>

  <xsl:template match="xsl:attribute[@name='font-size-adjust']">
divd\:.bibliomixed {font-size-adjust: <xsl:value-of select="."/>;}
  </xsl:template>

  <!-- suppress all attributes that we don't transcribe into css -->
  <xsl:template match="xsl:attribute"></xsl:template>

</xsl:stylesheet>
