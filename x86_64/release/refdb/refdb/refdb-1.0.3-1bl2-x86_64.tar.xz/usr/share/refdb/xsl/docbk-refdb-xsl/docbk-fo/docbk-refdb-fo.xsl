<!--
XSL FO stylesheet driver file for TEI XML documents using RefDB citations
and bibliographies.
$Id: docbk-refdb-fo.xsl.in,v 1.9.2.4 2006/03/27 20:10:35 mhoenicka Exp $

markus@mhoenicka.de 011226

Copyright blurb
-->

<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0" xmlns:fo="http://www.w3.org/1999/XSL/Format">

<!-- the original DocBook stylesheets for FO -->
<xsl:import href="http://docbook.sourceforge.net/release/xsl/current/fo/docbook.xsl"/>

<!-- common variables -->
<xsl:import href="/usr/share/refdb/xsl/common-refdb/refdbvar.xsl"/>

<!-- common templates -->
<xsl:import href="/usr/share/refdb/xsl/docbk-refdb-xsl/docbk-lib/docbk-refdblib.xsl"/>

<xsl:template match="bibliography[@role='refdb']">
  <xsl:variable name="id">
    <xsl:call-template name="object.id"/>
  </xsl:variable>

  <xsl:choose>
    <xsl:when test="not(parent::*) or parent::part or parent::book">
      <xsl:variable name="master-reference">
        <xsl:call-template name="select.pagemaster"/>
      </xsl:variable>

      <fo:page-sequence hyphenate="{$hyphenate}"
                        master-reference="{$master-reference}">
        <xsl:attribute name="language">
          <xsl:call-template name="l10n.language"/>
        </xsl:attribute>
        <xsl:attribute name="format">
          <xsl:call-template name="page.number.format"/>
        </xsl:attribute>
        <xsl:if test="$double.sided != 0">
          <xsl:attribute name="initial-page-number">auto-odd</xsl:attribute>
        </xsl:if>
        <xsl:attribute name="hyphenation-character">
          <xsl:call-template name="gentext">
            <xsl:with-param name="key" select="'hyphenation-character'"/>
          </xsl:call-template>
        </xsl:attribute>
        <xsl:attribute name="hyphenation-push-character-count">
          <xsl:call-template name="gentext">
            <xsl:with-param name="key" select="'hyphenation-push-character-count'"/>
          </xsl:call-template>
        </xsl:attribute>
        <xsl:attribute name="hyphenation-remain-character-count">
          <xsl:call-template name="gentext">
            <xsl:with-param name="key" select="'hyphenation-remain-character-count'"/>
          </xsl:call-template>
        </xsl:attribute>

        <xsl:apply-templates select="." mode="running.head.mode">
          <xsl:with-param name="master-reference" select="$master-reference"/>
        </xsl:apply-templates>
        <xsl:apply-templates select="." mode="running.foot.mode">
          <xsl:with-param name="master-reference" select="$master-reference"/>
        </xsl:apply-templates>

        <fo:flow flow-name="xsl-region-body">
          <fo:block id="{$id}">
            <xsl:call-template name="bibliography.titlepage"/>
          </fo:block>
          <xsl:apply-templates select="bibliomixed" mode="refdb"/>
          <!-- <xsl:apply-templates/> -->
        </fo:flow>
      </fo:page-sequence>
    </xsl:when>
    <xsl:otherwise>
      <fo:block id="{$id}"
                space-before.minimum="1em"
                space-before.optimum="1.5em"
                space-before.maximum="2em">
        <xsl:call-template name="bibliography.titlepage"/>
      </fo:block>
      <xsl:apply-templates select="bibliomixed" mode="refdb"/>
    </xsl:otherwise>
  </xsl:choose>
</xsl:template>


<xsl:template match="bibliomixed" mode="refdb">
  <xsl:choose>
    <xsl:when test="@role='MULTIXREF'">
      <!-- do not render directly -->
    </xsl:when>
    <xsl:otherwise>
      <xsl:variable name="id"><xsl:call-template name="object.id"/></xsl:variable>
      <fo:block id="{$id}" xsl:use-attribute-sets="refdb.bibliomset">
        <xsl:apply-templates select="bibliomset[@role='bibliography']" mode="refdb"/>
      </fo:block>
    </xsl:otherwise>
  </xsl:choose>
</xsl:template>

<!-- ulink needs special care as we want to create a hyperlink -->
<xsl:template match="ulink" mode="refdb">
  <xsl:variable name="reftype" select="ancestor::bibliomixed/@role"/>
  <xsl:variable name="target" select="@url"/>
  <!-- the empty block forces the hyperlink into a new line. This
       is less intrusive than half-emtpy lines due to bad hyphenation -->
  <fo:block/>
  <fo:basic-link external-destination='url({$target})'>
    <xsl:choose>
      <xsl:when test="$reftype='ABST'">
        <xsl:call-template name="refdb-process-inline">
          <xsl:with-param name="style" select="$ABSTURLSTYLE"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='ADVS'">
        <xsl:call-template name="refdb-process-inline">
          <xsl:with-param name="style" select="$ADVSURLSTYLE"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='ART'">
        <xsl:call-template name="refdb-process-inline">
          <xsl:with-param name="style" select="$ARTURLSTYLE"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='BILL'">
        <xsl:call-template name="refdb-process-inline">
          <xsl:with-param name="style" select="$BILLURLSTYLE"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='BOOK'">
        <xsl:call-template name="refdb-process-inline">
          <xsl:with-param name="style" select="$BOOKURLSTYLE"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='CASE'">
        <xsl:call-template name="refdb-process-inline">
          <xsl:with-param name="style" select="$CASEURLSTYLE"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='CHAP'">
        <xsl:call-template name="refdb-process-inline">
          <xsl:with-param name="style" select="$CHAPURLSTYLE"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='COMP'">
        <xsl:call-template name="refdb-process-inline">
          <xsl:with-param name="style" select="$COMPURLSTYLE"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='CONF'">
        <xsl:call-template name="refdb-process-inline">
          <xsl:with-param name="style" select="$CONFURLSTYLE"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='CTLG'">
        <xsl:call-template name="refdb-process-inline">
          <xsl:with-param name="style" select="$CTLGURLSTYLE"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='DATA'">
        <xsl:call-template name="refdb-process-inline">
          <xsl:with-param name="style" select="$DATAURLSTYLE"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='ELEC'">
        <xsl:call-template name="refdb-process-inline">
          <xsl:with-param name="style" select="$ELECURLSTYLE"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='GEN'">
        <xsl:call-template name="refdb-process-inline">
          <xsl:with-param name="style" select="$GENURLSTYLE"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='HEAR'">
        <xsl:call-template name="refdb-process-inline">
          <xsl:with-param name="style" select="$HEARURLSTYLE"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='ICOMM'">
        <xsl:call-template name="refdb-process-inline">
          <xsl:with-param name="style" select="$ICOMMURLSTYLE"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='INPR'">
        <xsl:call-template name="refdb-process-inline">
          <xsl:with-param name="style" select="$INPRURLSTYLE"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='JFULL'">
        <xsl:call-template name="refdb-process-inline">
          <xsl:with-param name="style" select="$JFULLURLSTYLE"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='JOUR'">
        <xsl:call-template name="refdb-process-inline">
          <xsl:with-param name="style" select="$JOURURLSTYLE"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='MAP'">
        <xsl:call-template name="refdb-process-inline">
          <xsl:with-param name="style" select="$MAPURLSTYLE"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='MGZN'">
        <xsl:call-template name="refdb-process-inline">
          <xsl:with-param name="style" select="$MGZNURLSTYLE"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='MPCT'">
        <xsl:call-template name="refdb-process-inline">
          <xsl:with-param name="style" select="$MPCTURLSTYLE"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='MUSIC'">
        <xsl:call-template name="refdb-process-inline">
          <xsl:with-param name="style" select="$MUSICURLSTYLE"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='NEWS'">
        <xsl:call-template name="refdb-process-inline">
          <xsl:with-param name="style" select="$NEWSURLSTYLE"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='PAMP'">
        <xsl:call-template name="refdb-process-inline">
          <xsl:with-param name="style" select="$PAMPURLSTYLE"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='PAT'">
        <xsl:call-template name="refdb-process-inline">
          <xsl:with-param name="style" select="$PATURLSTYLE"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='PCOMM'">
        <xsl:call-template name="refdb-process-inline">
          <xsl:with-param name="style" select="$PCOMMURLSTYLE"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='RPRT'">
        <xsl:call-template name="refdb-process-inline">
          <xsl:with-param name="style" select="$RPRTURLSTYLE"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='SER'">
        <xsl:call-template name="refdb-process-inline">
          <xsl:with-param name="style" select="$SERURLSTYLE"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='SLIDE'">
        <xsl:call-template name="refdb-process-inline">
          <xsl:with-param name="style" select="$SLIDEURLSTYLE"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='SOUND'">
        <xsl:call-template name="refdb-process-inline">
          <xsl:with-param name="style" select="$SOUNDURLSTYLE"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='STAT'">
        <xsl:call-template name="refdb-process-inline">
          <xsl:with-param name="style" select="$STATURLSTYLE"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='THES'">
        <xsl:call-template name="refdb-process-inline">
          <xsl:with-param name="style" select="$THESURLSTYLE"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='UNBILL'">
        <xsl:call-template name="refdb-process-inline">
          <xsl:with-param name="style" select="$UNBILLURLSTYLE"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='UNPB'">
        <xsl:call-template name="refdb-process-inline">
          <xsl:with-param name="style" select="$UNPBURLSTYLE"/>
        </xsl:call-template>
      </xsl:when>
      <xsl:when test="$reftype='VIDEO'">
        <xsl:call-template name="refdb-process-inline">
          <xsl:with-param name="style" select="$VIDEOURLSTYLE"/>
        </xsl:call-template>
      </xsl:when>
    </xsl:choose>
  </fo:basic-link>
</xsl:template>

<!-- overrides for xref elements -->
<!-- *************************** -->

<!-- in-text citation elements. If it is a multiple citation, process
     only the MULTIXREF ptr element, otherwise process all -->
<xsl:template match="citation[@role='REFDB']">
  <xsl:choose>
    <xsl:when test="./xref[@role='MULTIXREF']">
      <xsl:apply-templates mode="refdb" select="./xref[@role='MULTIXREF']"/>
    </xsl:when>
    <xsl:otherwise>
      <xsl:apply-templates mode="refdb"/>
      </xsl:otherwise>
  </xsl:choose>
</xsl:template>

<!-- pull in the appropriate elements to create the link text -->
<xsl:template match="xref" mode="refdb">
  <xsl:choose>
    <xsl:when test="@role='MULTIXREF'">
      <xsl:variable name="multitarget" select="substring(following-sibling::xref/@linkend, 1, string-length(following-sibling::xref/@linkend) - 2)"/>
      <fo:basic-link internal-destination='{$multitarget}'>
        <xsl:call-template name="refdb-literal">
          <xsl:with-param name="style" select="$INTEXTREFNUMBERSTYLE"/>
          <xsl:with-param name="string">
            <xsl:value-of select="id(@endterm)"/>
          </xsl:with-param>
        </xsl:call-template>
      </fo:basic-link>
    </xsl:when>
    <xsl:otherwise>
      <xsl:variable name="realtarget" select="substring(@linkend, 1, string-length(@linkend) - 2)"/>
      <xsl:variable name="ptrtype" select="id(@linkend)/@role"/>
      <fo:basic-link internal-destination='{$realtarget}'>
        <xsl:choose>
          <xsl:when test="$ptrtype='intext'">
            <xsl:apply-templates mode="INTEXT" select="id(@linkend)"/>
          </xsl:when>
          <xsl:when test="$ptrtype='intextsq'">
            <xsl:apply-templates mode="INTEXT" select="id(@linkend)"/>
          </xsl:when>
          <xsl:when test="$ptrtype='authoronly'">
            <xsl:apply-templates mode="AUTHORONLY" select="id(@linkend)"/>
          </xsl:when>
          <xsl:when test="$ptrtype='authoronlysq'">
            <xsl:apply-templates mode="AUTHORONLY" select="id(@linkend)"/>
          </xsl:when>
          <xsl:when test="$ptrtype='yearonly'">
            <xsl:apply-templates mode="YEARONLY" select="id(@linkend)"/>
          </xsl:when>
        </xsl:choose>
      </fo:basic-link>
    </xsl:otherwise>
  </xsl:choose>
</xsl:template>

<!-- "library" templates -->
<!-- ******************* -->

<!-- process elements with wrapped-around inline element, if applicable -->
<xsl:template name="refdb-process-inline">
  <xsl:param name="style"></xsl:param>
  <xsl:choose>
    <xsl:when test="$style='ULINE'">
      <fo:inline text-decoration="underline">
        <xsl:apply-templates mode="refdb"/>
      </fo:inline>
    </xsl:when>
    <xsl:when test="$style='ITULINE'">
      <fo:inline text-decoration="underline" font-style="italic">
        <xsl:apply-templates mode="refdb"/>
      </fo:inline>
    </xsl:when>
    <xsl:when test="$style='BOLDULINE'">
      <fo:inline text-decoration="underline" font-weight="bold">
        <xsl:apply-templates mode="refdb"/>
      </fo:inline>
    </xsl:when>
    <xsl:when test="$style='BOLDITULINE'">
      <fo:inline text-decoration="underline" font-style="italic" font-weight="bold">
        <xsl:apply-templates mode="refdb"/>
      </fo:inline>
    </xsl:when>
    <xsl:when test="$style='BOLD'">
      <fo:inline font-weight="bold">
        <xsl:apply-templates mode="refdb"/>
      </fo:inline>
    </xsl:when>
    <xsl:when test="$style='ITALIC'">
      <fo:inline font-style="italic">
        <xsl:apply-templates mode="refdb"/>
      </fo:inline>
    </xsl:when>
    <xsl:when test="$style='SUB'">
      <fo:inline vertical-align="sub">
        <xsl:apply-templates mode="refdb"/>
      </fo:inline>
    </xsl:when>
    <xsl:when test="$style='SUPER'">
      <fo:inline vertical-align="super">
        <xsl:apply-templates mode="refdb"/>
      </fo:inline>
    </xsl:when>
    <xsl:otherwise>
        <xsl:apply-templates mode="refdb"/>
    </xsl:otherwise>
  </xsl:choose>
</xsl:template>

<!-- process string with wrapped-around inline element, if applicable -->
<xsl:template name="refdb-literal">
  <xsl:param name="style"></xsl:param>
  <xsl:param name="string"></xsl:param>
  <xsl:choose>
    <xsl:when test="$style='ULINE'">
      <fo:inline text-decoration="underline">
        <xsl:value-of select="$string" disable-output-escaping="yes"/>
      </fo:inline>
    </xsl:when>
    <xsl:when test="$style='ITULINE'">
      <fo:inline text-decoration="underline" font-style="italic">
        <xsl:value-of select="$string" disable-output-escaping="yes"/>
      </fo:inline>
    </xsl:when>
    <xsl:when test="$style='BOLDULINE'">
      <fo:inline text-decoration="underline" font-weight="bold">
        <xsl:value-of select="$string" disable-output-escaping="yes"/>
      </fo:inline>
    </xsl:when>
    <xsl:when test="$style='BOLDITULINE'">
      <fo:inline text-decoration="underline" font-style="italic" font-weight="bold">
        <xsl:value-of select="$string" disable-output-escaping="yes"/>
      </fo:inline>
    </xsl:when>
    <xsl:when test="$style='BOLD'">
      <fo:inline font-weight="bold">
        <xsl:value-of select="$string" disable-output-escaping="yes"/>
      </fo:inline>
    </xsl:when>
    <xsl:when test="$style='ITALIC'">
      <fo:inline font-style="italic">
        <xsl:value-of select="$string" disable-output-escaping="yes"/>
      </fo:inline>
    </xsl:when>
    <xsl:when test="$style='SUB'">
      <fo:inline vertical-align="sub">
        <xsl:value-of select="$string" disable-output-escaping="yes"/>
      </fo:inline>
    </xsl:when>
    <xsl:when test="$style='SUPER'">
      <fo:inline vertical-align="super">
        <xsl:value-of select="$string" disable-output-escaping="yes"/>
      </fo:inline>
    </xsl:when>
    <xsl:otherwise>
        <xsl:value-of select="$string" disable-output-escaping="yes"/>
    </xsl:otherwise>
  </xsl:choose>
</xsl:template>

</xsl:stylesheet>

