#ifndef CURVE25519_DONNA_H
#define CURVE25519_DONNA_H
extern void curve25519_donna(unsigned char *output, const unsigned char *a,
                             const unsigned char *b);
#endif /* CURVE25519_DONNA_H */
