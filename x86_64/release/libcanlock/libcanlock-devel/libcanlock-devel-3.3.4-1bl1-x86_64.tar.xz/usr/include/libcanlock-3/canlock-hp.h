/*
 * SPDX-FileType: SOURCE
 * SPDX-FileCopyrightText: (c) 2021 Michael Baeuerle
 * SPDX-License-Identifier: ICU
 */

#ifndef _CANLOCK_HP_H
#define _CANLOCK_HP_H


/* ========================================================================== */
/* Include header files */

#include <stddef.h>  /* For size_t */


/* ========================================================================== */
/* Constants */

/* libcanlock API major version */
#define CL_API_MAJOR  3

/* libcanlock API minor version */
#define CL_API_MINOR  3


/* ========================================================================== */
/* New API (available since version 3.3.0) */

extern char *cl_hp_get_field(const char *data, size_t data_len,
                             const char *field);
extern char *cl_hp_unfold_field(const char *data, size_t *data_len);
extern char *cl_hp_parse_field(const char *data, size_t data_len);


#endif  /* _CANLOCK_HP_H */

/* EOF */
