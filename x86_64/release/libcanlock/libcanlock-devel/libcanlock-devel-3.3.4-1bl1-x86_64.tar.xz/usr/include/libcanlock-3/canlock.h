/*
 * SPDX-FileType: SOURCE
 * SPDX-FileCopyrightText: (c) 2018-2021 Michael Baeuerle
 * SPDX-FileCopyrightText: (c) 2017 Dennis Preiser
 * SPDX-FileCopyrightText: (c) 2003 G.J. Andruk
 * SPDX-License-Identifier: ICU
 */

#ifndef _CANLOCK_H
#define _CANLOCK_H


/* ========================================================================== */
/* Include header files */

#include <stddef.h>  /* For size_t */


/* ========================================================================== */
/* Constants */

/* libcanlock API major version */
#define CL_API_MAJOR  3

/* libcanlock API minor version */
#define CL_API_MINOR  3

/* libcanlock version 2 legacy API available if nonzero */
#define CL_API_V2  1

/* Supported hash algorithms for <scheme> according to RFC 8315 */
#define CL_INVALID  0
#define CL_SHA1     1         /* IANA registered name: "sha1" */
#define CL_SHA224   2         /* IANA registered name: "sha224" */
#define CL_SHA256   3         /* IANA registered name: "sha256" */
#define CL_SHA384   4         /* IANA registered name: "sha384" */
#define CL_SHA512   5         /* IANA registered name: "sha512" */


/* ========================================================================== */
/* Type definitions  */

typedef int cl_hash_version;


/* ========================================================================== */
/* New API (available since version 3.3.0) */

extern int cl_verify_multi(cl_hash_version *hash_list,
                           const char *key_list, const char *lock_list);


/* ========================================================================== */
/* New API (available since version 3.0.0) */

extern char *cl_get_key(cl_hash_version which_hash,
                        const unsigned char *secret, size_t seclen,
                        const unsigned char *message, size_t msglen);
extern char *cl_get_lock(cl_hash_version which_hash,
                         const unsigned char *secret, size_t seclen,
                         const unsigned char *message, size_t msglen);
extern int cl_split(char *input, char **klstring);
extern int cl_verify(cl_hash_version which_hash,
                     const char *key, const char *lock);
extern int cl_clear_secret(void *sec, size_t sec_size, size_t buf_size);


#if CL_API_V2
/* ========================================================================== */
/* Old API (Version 2b emulation) provided for backward compatibility */

extern char *lock_strip_alpha(char *key, char *type);
extern char *lock_strip(char *key, char *type);

/* Wrappers around new cl_(get_key|get_lock|verify) with hash set to SHA1 */
extern char *sha_key(const unsigned char *secret, size_t seclen,
                     const unsigned char *message, size_t msglen);
extern char *sha_lock(const unsigned char *secret, size_t seclen,
                      const unsigned char *message, size_t msglen);
extern int sha_verify(const char *key, const char *lock);
#endif  /* CL_API_V2 */


#endif  /* _CANLOCK_H */

/* EOF */
