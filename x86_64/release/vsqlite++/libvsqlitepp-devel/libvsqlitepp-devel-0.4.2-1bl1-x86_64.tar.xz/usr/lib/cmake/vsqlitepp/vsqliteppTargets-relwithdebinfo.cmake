#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "vsqlite::vsqlitepp" for configuration "RelWithDebInfo"
set_property(TARGET vsqlite::vsqlitepp APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(vsqlite::vsqlitepp PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libvsqlitepp.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygvsqlitepp-0.dll"
  )

list(APPEND _cmake_import_check_targets vsqlite::vsqlitepp )
list(APPEND _cmake_import_check_files_for_vsqlite::vsqlitepp "${_IMPORT_PREFIX}/lib/libvsqlitepp.dll.a" "${_IMPORT_PREFIX}/bin/cygvsqlitepp-0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
