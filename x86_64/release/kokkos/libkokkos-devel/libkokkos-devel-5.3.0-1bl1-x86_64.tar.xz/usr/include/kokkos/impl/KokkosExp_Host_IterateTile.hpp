// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// SPDX-FileCopyrightText: Copyright Contributors to the Kokkos project

#ifndef KOKKOS_HOST_EXP_ITERATE_TILE_HPP
#define KOKKOS_HOST_EXP_ITERATE_TILE_HPP

#include <Kokkos_Macros.hpp>
#if defined(KOKKOS_ENABLE_AGGRESSIVE_VECTORIZATION) && \
    defined(KOKKOS_ENABLE_PRAGMA_IVDEP) && !defined(__CUDA_ARCH__)
#define KOKKOS_MDRANGE_IVDEP
#endif

#ifdef KOKKOS_MDRANGE_IVDEP
#define KOKKOS_ENABLE_IVDEP_MDRANGE _Pragma("ivdep")
#else
#define KOKKOS_ENABLE_IVDEP_MDRANGE
#endif

#include <algorithm>

namespace Kokkos {
namespace Impl {

// parallel_reduce, non-tagged
// Reduction version
#define KOKKOS_IMPL_APPLY_REDUX(val, func, ...) func(__VA_ARGS__, val);

// LayoutRight
// d = 0 to start
#define KOKKOS_IMPL_LOOP_R_1_REDUX(val, func, type, m_offset, extent, d, ...) \
  KOKKOS_ENABLE_IVDEP_MDRANGE                                                 \
  for (type i0 = (type)0; i0 < static_cast<type>(extent[d]); ++i0) {          \
    KOKKOS_IMPL_APPLY_REDUX(val, func, __VA_ARGS__, i0 + m_offset[d])         \
  }

#define KOKKOS_IMPL_LOOP_R_2_REDUX(val, func, type, m_offset, extent, d, ...) \
  for (type i1 = (type)0; i1 < static_cast<type>(extent[d]); ++i1) {          \
    KOKKOS_IMPL_LOOP_R_1_REDUX(val, func, type, m_offset, extent, d + 1,      \
                               __VA_ARGS__, i1 + m_offset[d])                 \
  }

#define KOKKOS_IMPL_LOOP_R_3_REDUX(val, func, type, m_offset, extent, d, ...) \
  for (type i2 = (type)0; i2 < static_cast<type>(extent[d]); ++i2) {          \
    KOKKOS_IMPL_LOOP_R_2_REDUX(val, func, type, m_offset, extent, d + 1,      \
                               __VA_ARGS__, i2 + m_offset[d])                 \
  }

#define KOKKOS_IMPL_LOOP_R_4_REDUX(val, func, type, m_offset, extent, d, ...) \
  for (type i3 = (type)0; i3 < static_cast<type>(extent[d]); ++i3) {          \
    KOKKOS_IMPL_LOOP_R_3_REDUX(val, func, type, m_offset, extent, d + 1,      \
                               __VA_ARGS__, i3 + m_offset[d])                 \
  }

#define KOKKOS_IMPL_LOOP_R_5_REDUX(val, func, type, m_offset, extent, d, ...) \
  for (type i4 = (type)0; i4 < static_cast<type>(extent[d]); ++i4) {          \
    KOKKOS_IMPL_LOOP_R_4_REDUX(val, func, type, m_offset, extent, d + 1,      \
                               __VA_ARGS__, i4 + m_offset[d])                 \
  }

#define KOKKOS_IMPL_LOOP_R_6_REDUX(val, func, type, m_offset, extent, d, ...) \
  for (type i5 = (type)0; i5 < static_cast<type>(extent[d]); ++i5) {          \
    KOKKOS_IMPL_LOOP_R_5_REDUX(val, func, type, m_offset, extent, d + 1,      \
                               __VA_ARGS__, i5 + m_offset[d])                 \
  }

#define KOKKOS_IMPL_LOOP_R_7_REDUX(val, func, type, m_offset, extent, d, ...) \
  for (type i6 = (type)0; i6 < static_cast<type>(extent[d]); ++i6) {          \
    KOKKOS_IMPL_LOOP_R_6_REDUX(val, func, type, m_offset, extent, d + 1,      \
                               __VA_ARGS__, i6 + m_offset[d])                 \
  }

#define KOKKOS_IMPL_LOOP_R_8_REDUX(val, func, type, m_offset, extent, d, ...) \
  for (type i7 = (type)0; i7 < static_cast<type>(extent[d]); ++i7) {          \
    KOKKOS_IMPL_LOOP_R_7_REDUX(val, func, type, m_offset, extent, d + 1,      \
                               __VA_ARGS__, i7 + m_offset[d])                 \
  }

// LayoutLeft
// d = rank-1 to start
#define KOKKOS_IMPL_LOOP_L_1_REDUX(val, func, type, m_offset, extent, d, ...) \
  KOKKOS_ENABLE_IVDEP_MDRANGE                                                 \
  for (type i0 = (type)0; i0 < static_cast<type>(extent[d]); ++i0) {          \
    KOKKOS_IMPL_APPLY_REDUX(val, func, i0 + m_offset[d], __VA_ARGS__)         \
  }

#define KOKKOS_IMPL_LOOP_L_2_REDUX(val, func, type, m_offset, extent, d, ...) \
  for (type i1 = (type)0; i1 < static_cast<type>(extent[d]); ++i1) {          \
    KOKKOS_IMPL_LOOP_L_1_REDUX(val, func, type, m_offset, extent, d - 1,      \
                               i1 + m_offset[d], __VA_ARGS__)                 \
  }

#define KOKKOS_IMPL_LOOP_L_3_REDUX(val, func, type, m_offset, extent, d, ...) \
  for (type i2 = (type)0; i2 < static_cast<type>(extent[d]); ++i2) {          \
    KOKKOS_IMPL_LOOP_L_2_REDUX(val, func, type, m_offset, extent, d - 1,      \
                               i2 + m_offset[d], __VA_ARGS__)                 \
  }

#define KOKKOS_IMPL_LOOP_L_4_REDUX(val, func, type, m_offset, extent, d, ...) \
  for (type i3 = (type)0; i3 < static_cast<type>(extent[d]); ++i3) {          \
    KOKKOS_IMPL_LOOP_L_3_REDUX(val, func, type, m_offset, extent, d - 1,      \
                               i3 + m_offset[d], __VA_ARGS__)                 \
  }

#define KOKKOS_IMPL_LOOP_L_5_REDUX(val, func, type, m_offset, extent, d, ...) \
  for (type i4 = (type)0; i4 < static_cast<type>(extent[d]); ++i4) {          \
    KOKKOS_IMPL_LOOP_L_4_REDUX(val, func, type, m_offset, extent, d - 1,      \
                               i4 + m_offset[d], __VA_ARGS__)                 \
  }

#define KOKKOS_IMPL_LOOP_L_6_REDUX(val, func, type, m_offset, extent, d, ...) \
  for (type i5 = (type)0; i5 < static_cast<type>(extent[d]); ++i5) {          \
    KOKKOS_IMPL_LOOP_L_5_REDUX(val, func, type, m_offset, extent, d - 1,      \
                               i5 + m_offset[d], __VA_ARGS__)                 \
  }

#define KOKKOS_IMPL_LOOP_L_7_REDUX(val, func, type, m_offset, extent, d, ...) \
  for (type i6 = (type)0; i6 < static_cast<type>(extent[d]); ++i6) {          \
    KOKKOS_IMPL_LOOP_L_6_REDUX(val, func, type, m_offset, extent, d - 1,      \
                               i6 + m_offset[d], __VA_ARGS__)                 \
  }

#define KOKKOS_IMPL_LOOP_L_8_REDUX(val, func, type, m_offset, extent, d, ...) \
  for (type i7 = (type)0; i7 < static_cast<type>(extent[d]); ++i7) {          \
    KOKKOS_IMPL_LOOP_L_7_REDUX(val, func, type, m_offset, extent, d - 1,      \
                               i7 + m_offset[d], __VA_ARGS__)                 \
  }

// Left vs Right
#define KOKKOS_IMPL_LOOP_LAYOUT_1_REDUX(val, func, type, is_left, m_offset, \
                                        extent, rank)                       \
  KOKKOS_ENABLE_IVDEP_MDRANGE                                               \
  for (type i0 = (type)0; i0 < static_cast<type>(extent[0]); ++i0) {        \
    KOKKOS_IMPL_APPLY_REDUX(val, func, i0 + m_offset[0])                    \
  }

#define KOKKOS_IMPL_LOOP_LAYOUT_2_REDUX(val, func, type, is_left, m_offset,   \
                                        extent, rank)                         \
  if (is_left) {                                                              \
    for (type i1 = (type)0; i1 < static_cast<type>(extent[rank - 1]); ++i1) { \
      KOKKOS_IMPL_LOOP_L_1_REDUX(val, func, type, m_offset, extent, rank - 2, \
                                 i1 + m_offset[rank - 1])                     \
    }                                                                         \
  } else {                                                                    \
    for (type i1 = (type)0; i1 < static_cast<type>(extent[0]); ++i1) {        \
      KOKKOS_IMPL_LOOP_R_1_REDUX(val, func, type, m_offset, extent, 1,        \
                                 i1 + m_offset[0])                            \
    }                                                                         \
  }

#define KOKKOS_IMPL_LOOP_LAYOUT_3_REDUX(val, func, type, is_left, m_offset,   \
                                        extent, rank)                         \
  if (is_left) {                                                              \
    for (type i2 = (type)0; i2 < static_cast<type>(extent[rank - 1]); ++i2) { \
      KOKKOS_IMPL_LOOP_L_2_REDUX(val, func, type, m_offset, extent, rank - 2, \
                                 i2 + m_offset[rank - 1])                     \
    }                                                                         \
  } else {                                                                    \
    for (type i2 = (type)0; i2 < static_cast<type>(extent[0]); ++i2) {        \
      KOKKOS_IMPL_LOOP_R_2_REDUX(val, func, type, m_offset, extent, 1,        \
                                 i2 + m_offset[0])                            \
    }                                                                         \
  }

#define KOKKOS_IMPL_LOOP_LAYOUT_4_REDUX(val, func, type, is_left, m_offset,   \
                                        extent, rank)                         \
  if (is_left) {                                                              \
    for (type i3 = (type)0; i3 < static_cast<type>(extent[rank - 1]); ++i3) { \
      KOKKOS_IMPL_LOOP_L_3_REDUX(val, func, type, m_offset, extent, rank - 2, \
                                 i3 + m_offset[rank - 1])                     \
    }                                                                         \
  } else {                                                                    \
    for (type i3 = (type)0; i3 < static_cast<type>(extent[0]); ++i3) {        \
      KOKKOS_IMPL_LOOP_R_3_REDUX(val, func, type, m_offset, extent, 1,        \
                                 i3 + m_offset[0])                            \
    }                                                                         \
  }

#define KOKKOS_IMPL_LOOP_LAYOUT_5_REDUX(val, func, type, is_left, m_offset,   \
                                        extent, rank)                         \
  if (is_left) {                                                              \
    for (type i4 = (type)0; i4 < static_cast<type>(extent[rank - 1]); ++i4) { \
      KOKKOS_IMPL_LOOP_L_4_REDUX(val, func, type, m_offset, extent, rank - 2, \
                                 i4 + m_offset[rank - 1])                     \
    }                                                                         \
  } else {                                                                    \
    for (type i4 = (type)0; i4 < static_cast<type>(extent[0]); ++i4) {        \
      KOKKOS_IMPL_LOOP_R_4_REDUX(val, func, type, m_offset, extent, 1,        \
                                 i4 + m_offset[0])                            \
    }                                                                         \
  }

#define KOKKOS_IMPL_LOOP_LAYOUT_6_REDUX(val, func, type, is_left, m_offset,   \
                                        extent, rank)                         \
  if (is_left) {                                                              \
    for (type i5 = (type)0; i5 < static_cast<type>(extent[rank - 1]); ++i5) { \
      KOKKOS_IMPL_LOOP_L_5_REDUX(val, func, type, m_offset, extent, rank - 2, \
                                 i5 + m_offset[rank - 1])                     \
    }                                                                         \
  } else {                                                                    \
    for (type i5 = (type)0; i5 < static_cast<type>(extent[0]); ++i5) {        \
      KOKKOS_IMPL_LOOP_R_5_REDUX(val, func, type, m_offset, extent, 1,        \
                                 i5 + m_offset[0])                            \
    }                                                                         \
  }

#define KOKKOS_IMPL_LOOP_LAYOUT_7_REDUX(val, func, type, is_left, m_offset,   \
                                        extent, rank)                         \
  if (is_left) {                                                              \
    for (type i6 = (type)0; i6 < static_cast<type>(extent[rank - 1]); ++i6) { \
      KOKKOS_IMPL_LOOP_L_6_REDUX(val, func, type, m_offset, extent, rank - 2, \
                                 i6 + m_offset[rank - 1])                     \
    }                                                                         \
  } else {                                                                    \
    for (type i6 = (type)0; i6 < static_cast<type>(extent[0]); ++i6) {        \
      KOKKOS_IMPL_LOOP_R_6_REDUX(val, func, type, m_offset, extent, 1,        \
                                 i6 + m_offset[0])                            \
    }                                                                         \
  }

#define KOKKOS_IMPL_LOOP_LAYOUT_8_REDUX(val, func, type, is_left, m_offset,   \
                                        extent, rank)                         \
  if (is_left) {                                                              \
    for (type i7 = (type)0; i7 < static_cast<type>(extent[rank - 1]); ++i7) { \
      KOKKOS_IMPL_LOOP_L_7_REDUX(val, func, type, m_offset, extent, rank - 2, \
                                 i7 + m_offset[rank - 1])                     \
    }                                                                         \
  } else {                                                                    \
    for (type i7 = (type)0; i7 < static_cast<type>(extent[0]); ++i7) {        \
      KOKKOS_IMPL_LOOP_R_7_REDUX(val, func, type, m_offset, extent, 1,        \
                                 i7 + m_offset[0])                            \
    }                                                                         \
  }

// Partial vs Full Tile
#define KOKKOS_IMPL_TILE_LOOP_1_REDUX(val, func, type, is_left, cond,        \
                                      m_offset, extent_full, extent_partial, \
                                      rank)                                  \
  if (cond) {                                                                \
    KOKKOS_IMPL_LOOP_LAYOUT_1_REDUX(val, func, type, is_left, m_offset,      \
                                    extent_full, rank)                       \
  } else {                                                                   \
    KOKKOS_IMPL_LOOP_LAYOUT_1_REDUX(val, func, type, is_left, m_offset,      \
                                    extent_partial, rank)                    \
  }

#define KOKKOS_IMPL_TILE_LOOP_2_REDUX(val, func, type, is_left, cond,        \
                                      m_offset, extent_full, extent_partial, \
                                      rank)                                  \
  if (cond) {                                                                \
    KOKKOS_IMPL_LOOP_LAYOUT_2_REDUX(val, func, type, is_left, m_offset,      \
                                    extent_full, rank)                       \
  } else {                                                                   \
    KOKKOS_IMPL_LOOP_LAYOUT_2_REDUX(val, func, type, is_left, m_offset,      \
                                    extent_partial, rank)                    \
  }

#define KOKKOS_IMPL_TILE_LOOP_3_REDUX(val, func, type, is_left, cond,        \
                                      m_offset, extent_full, extent_partial, \
                                      rank)                                  \
  if (cond) {                                                                \
    KOKKOS_IMPL_LOOP_LAYOUT_3_REDUX(val, func, type, is_left, m_offset,      \
                                    extent_full, rank)                       \
  } else {                                                                   \
    KOKKOS_IMPL_LOOP_LAYOUT_3_REDUX(val, func, type, is_left, m_offset,      \
                                    extent_partial, rank)                    \
  }

#define KOKKOS_IMPL_TILE_LOOP_4_REDUX(val, func, type, is_left, cond,        \
                                      m_offset, extent_full, extent_partial, \
                                      rank)                                  \
  if (cond) {                                                                \
    KOKKOS_IMPL_LOOP_LAYOUT_4_REDUX(val, func, type, is_left, m_offset,      \
                                    extent_full, rank)                       \
  } else {                                                                   \
    KOKKOS_IMPL_LOOP_LAYOUT_4_REDUX(val, func, type, is_left, m_offset,      \
                                    extent_partial, rank)                    \
  }

#define KOKKOS_IMPL_TILE_LOOP_5_REDUX(val, func, type, is_left, cond,        \
                                      m_offset, extent_full, extent_partial, \
                                      rank)                                  \
  if (cond) {                                                                \
    KOKKOS_IMPL_LOOP_LAYOUT_5_REDUX(val, func, type, is_left, m_offset,      \
                                    extent_full, rank)                       \
  } else {                                                                   \
    KOKKOS_IMPL_LOOP_LAYOUT_5_REDUX(val, func, type, is_left, m_offset,      \
                                    extent_partial, rank)                    \
  }

#define KOKKOS_IMPL_TILE_LOOP_6_REDUX(val, func, type, is_left, cond,        \
                                      m_offset, extent_full, extent_partial, \
                                      rank)                                  \
  if (cond) {                                                                \
    KOKKOS_IMPL_LOOP_LAYOUT_6_REDUX(val, func, type, is_left, m_offset,      \
                                    extent_full, rank)                       \
  } else {                                                                   \
    KOKKOS_IMPL_LOOP_LAYOUT_6_REDUX(val, func, type, is_left, m_offset,      \
                                    extent_partial, rank)                    \
  }

#define KOKKOS_IMPL_TILE_LOOP_7_REDUX(val, func, type, is_left, cond,        \
                                      m_offset, extent_full, extent_partial, \
                                      rank)                                  \
  if (cond) {                                                                \
    KOKKOS_IMPL_LOOP_LAYOUT_7_REDUX(val, func, type, is_left, m_offset,      \
                                    extent_full, rank)                       \
  } else {                                                                   \
    KOKKOS_IMPL_LOOP_LAYOUT_7_REDUX(val, func, type, is_left, m_offset,      \
                                    extent_partial, rank)                    \
  }

#define KOKKOS_IMPL_TILE_LOOP_8_REDUX(val, func, type, is_left, cond,        \
                                      m_offset, extent_full, extent_partial, \
                                      rank)                                  \
  if (cond) {                                                                \
    KOKKOS_IMPL_LOOP_LAYOUT_8_REDUX(val, func, type, is_left, m_offset,      \
                                    extent_full, rank)                       \
  } else {                                                                   \
    KOKKOS_IMPL_LOOP_LAYOUT_8_REDUX(val, func, type, is_left, m_offset,      \
                                    extent_partial, rank)                    \
  }

// parallel_for macros: combine tagged and non-tagged

#define KOKKOS_IMPL_APPLY(tag, func, ...) \
  if constexpr (std::is_void_v<tag>)      \
    func(__VA_ARGS__);                    \
  else                                    \
    func(tag{}, __VA_ARGS__);

// LayoutRight
// d = 0 to start
#define KOKKOS_IMPL_LOOP_R_1(tag, func, type, m_offset, extent, d, ...) \
  KOKKOS_ENABLE_IVDEP_MDRANGE                                           \
  for (type i0 = (type)0; i0 < static_cast<type>(extent[d]); ++i0) {    \
    KOKKOS_IMPL_APPLY(tag, func, __VA_ARGS__, i0 + m_offset[d])         \
  }

#define KOKKOS_IMPL_LOOP_R_2(tag, func, type, m_offset, extent, d, ...) \
  for (type i1 = (type)0; i1 < static_cast<type>(extent[d]); ++i1) {    \
    KOKKOS_IMPL_LOOP_R_1(tag, func, type, m_offset, extent, d + 1,      \
                         __VA_ARGS__, i1 + m_offset[d])                 \
  }

#define KOKKOS_IMPL_LOOP_R_3(tag, func, type, m_offset, extent, d, ...) \
  for (type i2 = (type)0; i2 < static_cast<type>(extent[d]); ++i2) {    \
    KOKKOS_IMPL_LOOP_R_2(tag, func, type, m_offset, extent, d + 1,      \
                         __VA_ARGS__, i2 + m_offset[d])                 \
  }

#define KOKKOS_IMPL_LOOP_R_4(tag, func, type, m_offset, extent, d, ...) \
  for (type i3 = (type)0; i3 < static_cast<type>(extent[d]); ++i3) {    \
    KOKKOS_IMPL_LOOP_R_3(tag, func, type, m_offset, extent, d + 1,      \
                         __VA_ARGS__, i3 + m_offset[d])                 \
  }

#define KOKKOS_IMPL_LOOP_R_5(tag, func, type, m_offset, extent, d, ...) \
  for (type i4 = (type)0; i4 < static_cast<type>(extent[d]); ++i4) {    \
    KOKKOS_IMPL_LOOP_R_4(tag, func, type, m_offset, extent, d + 1,      \
                         __VA_ARGS__, i4 + m_offset[d])                 \
  }

#define KOKKOS_IMPL_LOOP_R_6(tag, func, type, m_offset, extent, d, ...) \
  for (type i5 = (type)0; i5 < static_cast<type>(extent[d]); ++i5) {    \
    KOKKOS_IMPL_LOOP_R_5(tag, func, type, m_offset, extent, d + 1,      \
                         __VA_ARGS__, i5 + m_offset[d])                 \
  }

#define KOKKOS_IMPL_LOOP_R_7(tag, func, type, m_offset, extent, d, ...) \
  for (type i6 = (type)0; i6 < static_cast<type>(extent[d]); ++i6) {    \
    KOKKOS_IMPL_LOOP_R_6(tag, func, type, m_offset, extent, d + 1,      \
                         __VA_ARGS__, i6 + m_offset[d])                 \
  }

#define KOKKOS_IMPL_LOOP_R_8(tag, func, type, m_offset, extent, d, ...) \
  for (type i7 = (type)0; i7 < static_cast<type>(extent[d]); ++i7) {    \
    KOKKOS_IMPL_LOOP_R_7(tag, func, type, m_offset, extent, d + 1,      \
                         __VA_ARGS__, i7 + m_offset[d])                 \
  }

// LayoutLeft
// d = rank-1 to start
#define KOKKOS_IMPL_LOOP_L_1(tag, func, type, m_offset, extent, d, ...) \
  KOKKOS_ENABLE_IVDEP_MDRANGE                                           \
  for (type i0 = (type)0; i0 < static_cast<type>(extent[d]); ++i0) {    \
    KOKKOS_IMPL_APPLY(tag, func, i0 + m_offset[d], __VA_ARGS__)         \
  }

#define KOKKOS_IMPL_LOOP_L_2(tag, func, type, m_offset, extent, d, ...) \
  for (type i1 = (type)0; i1 < static_cast<type>(extent[d]); ++i1) {    \
    KOKKOS_IMPL_LOOP_L_1(tag, func, type, m_offset, extent, d - 1,      \
                         i1 + m_offset[d], __VA_ARGS__)                 \
  }

#define KOKKOS_IMPL_LOOP_L_3(tag, func, type, m_offset, extent, d, ...) \
  for (type i2 = (type)0; i2 < static_cast<type>(extent[d]); ++i2) {    \
    KOKKOS_IMPL_LOOP_L_2(tag, func, type, m_offset, extent, d - 1,      \
                         i2 + m_offset[d], __VA_ARGS__)                 \
  }

#define KOKKOS_IMPL_LOOP_L_4(tag, func, type, m_offset, extent, d, ...) \
  for (type i3 = (type)0; i3 < static_cast<type>(extent[d]); ++i3) {    \
    KOKKOS_IMPL_LOOP_L_3(tag, func, type, m_offset, extent, d - 1,      \
                         i3 + m_offset[d], __VA_ARGS__)                 \
  }

#define KOKKOS_IMPL_LOOP_L_5(tag, func, type, m_offset, extent, d, ...) \
  for (type i4 = (type)0; i4 < static_cast<type>(extent[d]); ++i4) {    \
    KOKKOS_IMPL_LOOP_L_4(tag, func, type, m_offset, extent, d - 1,      \
                         i4 + m_offset[d], __VA_ARGS__)                 \
  }

#define KOKKOS_IMPL_LOOP_L_6(tag, func, type, m_offset, extent, d, ...) \
  for (type i5 = (type)0; i5 < static_cast<type>(extent[d]); ++i5) {    \
    KOKKOS_IMPL_LOOP_L_5(tag, func, type, m_offset, extent, d - 1,      \
                         i5 + m_offset[d], __VA_ARGS__)                 \
  }

#define KOKKOS_IMPL_LOOP_L_7(tag, func, type, m_offset, extent, d, ...) \
  for (type i6 = (type)0; i6 < static_cast<type>(extent[d]); ++i6) {    \
    KOKKOS_IMPL_LOOP_L_6(tag, func, type, m_offset, extent, d - 1,      \
                         i6 + m_offset[d], __VA_ARGS__)                 \
  }

#define KOKKOS_IMPL_LOOP_L_8(tag, func, type, m_offset, extent, d, ...) \
  for (type i7 = (type)0; i7 < static_cast<type>(extent[d]); ++i7) {    \
    KOKKOS_IMPL_LOOP_L_7(tag, func, type, m_offset, extent, d - 1,      \
                         i7 + m_offset[d], __VA_ARGS__)                 \
  }

// Left vs Right
// TODO: rank not necessary to pass through, can hardcode the values
#define KOKKOS_IMPL_LOOP_LAYOUT_1(tag, func, type, is_left, m_offset, extent, \
                                  rank)                                       \
  KOKKOS_ENABLE_IVDEP_MDRANGE                                                 \
  for (type i0 = (type)0; i0 < static_cast<type>(extent[0]); ++i0) {          \
    KOKKOS_IMPL_APPLY(tag, func, i0 + m_offset[0])                            \
  }

#define KOKKOS_IMPL_LOOP_LAYOUT_2(tag, func, type, is_left, m_offset, extent, \
                                  rank)                                       \
  if (is_left) {                                                              \
    for (type i1 = (type)0; i1 < static_cast<type>(extent[rank - 1]); ++i1) { \
      KOKKOS_IMPL_LOOP_L_1(tag, func, type, m_offset, extent, rank - 2,       \
                           i1 + m_offset[rank - 1])                           \
    }                                                                         \
  } else {                                                                    \
    for (type i1 = (type)0; i1 < static_cast<type>(extent[0]); ++i1) {        \
      KOKKOS_IMPL_LOOP_R_1(tag, func, type, m_offset, extent, 1,              \
                           i1 + m_offset[0])                                  \
    }                                                                         \
  }

#define KOKKOS_IMPL_LOOP_LAYOUT_3(tag, func, type, is_left, m_offset, extent, \
                                  rank)                                       \
  if (is_left) {                                                              \
    for (type i2 = (type)0; i2 < static_cast<type>(extent[rank - 1]); ++i2) { \
      KOKKOS_IMPL_LOOP_L_2(tag, func, type, m_offset, extent, rank - 2,       \
                           i2 + m_offset[rank - 1])                           \
    }                                                                         \
  } else {                                                                    \
    for (type i2 = (type)0; i2 < static_cast<type>(extent[0]); ++i2) {        \
      KOKKOS_IMPL_LOOP_R_2(tag, func, type, m_offset, extent, 1,              \
                           i2 + m_offset[0])                                  \
    }                                                                         \
  }

#define KOKKOS_IMPL_LOOP_LAYOUT_4(tag, func, type, is_left, m_offset, extent, \
                                  rank)                                       \
  if (is_left) {                                                              \
    for (type i3 = (type)0; i3 < static_cast<type>(extent[rank - 1]); ++i3) { \
      KOKKOS_IMPL_LOOP_L_3(tag, func, type, m_offset, extent, rank - 2,       \
                           i3 + m_offset[rank - 1])                           \
    }                                                                         \
  } else {                                                                    \
    for (type i3 = (type)0; i3 < static_cast<type>(extent[0]); ++i3) {        \
      KOKKOS_IMPL_LOOP_R_3(tag, func, type, m_offset, extent, 1,              \
                           i3 + m_offset[0])                                  \
    }                                                                         \
  }

#define KOKKOS_IMPL_LOOP_LAYOUT_5(tag, func, type, is_left, m_offset, extent, \
                                  rank)                                       \
  if (is_left) {                                                              \
    for (type i4 = (type)0; i4 < static_cast<type>(extent[rank - 1]); ++i4) { \
      KOKKOS_IMPL_LOOP_L_4(tag, func, type, m_offset, extent, rank - 2,       \
                           i4 + m_offset[rank - 1])                           \
    }                                                                         \
  } else {                                                                    \
    for (type i4 = (type)0; i4 < static_cast<type>(extent[0]); ++i4) {        \
      KOKKOS_IMPL_LOOP_R_4(tag, func, type, m_offset, extent, 1,              \
                           i4 + m_offset[0])                                  \
    }                                                                         \
  }

#define KOKKOS_IMPL_LOOP_LAYOUT_6(tag, func, type, is_left, m_offset, extent, \
                                  rank)                                       \
  if (is_left) {                                                              \
    for (type i5 = (type)0; i5 < static_cast<type>(extent[rank - 1]); ++i5) { \
      KOKKOS_IMPL_LOOP_L_5(tag, func, type, m_offset, extent, rank - 2,       \
                           i5 + m_offset[rank - 1])                           \
    }                                                                         \
  } else {                                                                    \
    for (type i5 = (type)0; i5 < static_cast<type>(extent[0]); ++i5) {        \
      KOKKOS_IMPL_LOOP_R_5(tag, func, type, m_offset, extent, 1,              \
                           i5 + m_offset[0])                                  \
    }                                                                         \
  }

#define KOKKOS_IMPL_LOOP_LAYOUT_7(tag, func, type, is_left, m_offset, extent, \
                                  rank)                                       \
  if (is_left) {                                                              \
    for (type i6 = (type)0; i6 < static_cast<type>(extent[rank - 1]); ++i6) { \
      KOKKOS_IMPL_LOOP_L_6(tag, func, type, m_offset, extent, rank - 2,       \
                           i6 + m_offset[rank - 1])                           \
    }                                                                         \
  } else {                                                                    \
    for (type i6 = (type)0; i6 < static_cast<type>(extent[0]); ++i6) {        \
      KOKKOS_IMPL_LOOP_R_6(tag, func, type, m_offset, extent, 1,              \
                           i6 + m_offset[0])                                  \
    }                                                                         \
  }

#define KOKKOS_IMPL_LOOP_LAYOUT_8(tag, func, type, is_left, m_offset, extent, \
                                  rank)                                       \
  if (is_left) {                                                              \
    for (type i7 = (type)0; i7 < static_cast<type>(extent[rank - 1]); ++i7) { \
      KOKKOS_IMPL_LOOP_L_7(tag, func, type, m_offset, extent, rank - 2,       \
                           i7 + m_offset[rank - 1])                           \
    }                                                                         \
  } else {                                                                    \
    for (type i7 = (type)0; i7 < static_cast<type>(extent[0]); ++i7) {        \
      KOKKOS_IMPL_LOOP_R_7(tag, func, type, m_offset, extent, 1,              \
                           i7 + m_offset[0])                                  \
    }                                                                         \
  }

// Partial vs Full Tile
#define KOKKOS_IMPL_TILE_LOOP_1(tag, func, type, is_left, cond, m_offset,      \
                                extent_full, extent_partial, rank)             \
  if (cond) {                                                                  \
    KOKKOS_IMPL_LOOP_LAYOUT_1(tag, func, type, is_left, m_offset, extent_full, \
                              rank)                                            \
  } else {                                                                     \
    KOKKOS_IMPL_LOOP_LAYOUT_1(tag, func, type, is_left, m_offset,              \
                              extent_partial, rank)                            \
  }

#define KOKKOS_IMPL_TILE_LOOP_2(tag, func, type, is_left, cond, m_offset,      \
                                extent_full, extent_partial, rank)             \
  if (cond) {                                                                  \
    KOKKOS_IMPL_LOOP_LAYOUT_2(tag, func, type, is_left, m_offset, extent_full, \
                              rank)                                            \
  } else {                                                                     \
    KOKKOS_IMPL_LOOP_LAYOUT_2(tag, func, type, is_left, m_offset,              \
                              extent_partial, rank)                            \
  }

#define KOKKOS_IMPL_TILE_LOOP_3(tag, func, type, is_left, cond, m_offset,      \
                                extent_full, extent_partial, rank)             \
  if (cond) {                                                                  \
    KOKKOS_IMPL_LOOP_LAYOUT_3(tag, func, type, is_left, m_offset, extent_full, \
                              rank)                                            \
  } else {                                                                     \
    KOKKOS_IMPL_LOOP_LAYOUT_3(tag, func, type, is_left, m_offset,              \
                              extent_partial, rank)                            \
  }

#define KOKKOS_IMPL_TILE_LOOP_4(tag, func, type, is_left, cond, m_offset,      \
                                extent_full, extent_partial, rank)             \
  if (cond) {                                                                  \
    KOKKOS_IMPL_LOOP_LAYOUT_4(tag, func, type, is_left, m_offset, extent_full, \
                              rank)                                            \
  } else {                                                                     \
    KOKKOS_IMPL_LOOP_LAYOUT_4(tag, func, type, is_left, m_offset,              \
                              extent_partial, rank)                            \
  }

#define KOKKOS_IMPL_TILE_LOOP_5(tag, func, type, is_left, cond, m_offset,      \
                                extent_full, extent_partial, rank)             \
  if (cond) {                                                                  \
    KOKKOS_IMPL_LOOP_LAYOUT_5(tag, func, type, is_left, m_offset, extent_full, \
                              rank)                                            \
  } else {                                                                     \
    KOKKOS_IMPL_LOOP_LAYOUT_5(tag, func, type, is_left, m_offset,              \
                              extent_partial, rank)                            \
  }

#define KOKKOS_IMPL_TILE_LOOP_6(tag, func, type, is_left, cond, m_offset,      \
                                extent_full, extent_partial, rank)             \
  if (cond) {                                                                  \
    KOKKOS_IMPL_LOOP_LAYOUT_6(tag, func, type, is_left, m_offset, extent_full, \
                              rank)                                            \
  } else {                                                                     \
    KOKKOS_IMPL_LOOP_LAYOUT_6(tag, func, type, is_left, m_offset,              \
                              extent_partial, rank)                            \
  }

#define KOKKOS_IMPL_TILE_LOOP_7(tag, func, type, is_left, cond, m_offset,      \
                                extent_full, extent_partial, rank)             \
  if (cond) {                                                                  \
    KOKKOS_IMPL_LOOP_LAYOUT_7(tag, func, type, is_left, m_offset, extent_full, \
                              rank)                                            \
  } else {                                                                     \
    KOKKOS_IMPL_LOOP_LAYOUT_7(tag, func, type, is_left, m_offset,              \
                              extent_partial, rank)                            \
  }

#define KOKKOS_IMPL_TILE_LOOP_8(tag, func, type, is_left, cond, m_offset,      \
                                extent_full, extent_partial, rank)             \
  if (cond) {                                                                  \
    KOKKOS_IMPL_LOOP_LAYOUT_8(tag, func, type, is_left, m_offset, extent_full, \
                              rank)                                            \
  } else {                                                                     \
    KOKKOS_IMPL_LOOP_LAYOUT_8(tag, func, type, is_left, m_offset,              \
                              extent_partial, rank)                            \
  }

// parallel_reduce, tagged
// Reduction version
#define KOKKOS_IMPL_TAGGED_APPLY_REDUX(val, tag, func, ...) \
  func(tag, __VA_ARGS__, val);

// LayoutRight
// d = 0 to start
#define KOKKOS_IMPL_TAGGED_LOOP_R_1_REDUX(val, tag, func, type, m_offset, \
                                          extent, d, ...)                 \
  KOKKOS_ENABLE_IVDEP_MDRANGE                                             \
  for (type i0 = (type)0; i0 < static_cast<type>(extent[d]); ++i0) {      \
    KOKKOS_IMPL_TAGGED_APPLY_REDUX(val, tag, func, __VA_ARGS__,           \
                                   i0 + m_offset[d])                      \
  }

#define KOKKOS_IMPL_TAGGED_LOOP_R_2_REDUX(val, tag, func, type, m_offset,     \
                                          extent, d, ...)                     \
  for (type i1 = (type)0; i1 < static_cast<type>(extent[d]); ++i1) {          \
    KOKKOS_IMPL_TAGGED_LOOP_R_1_REDUX(val, tag, func, type, m_offset, extent, \
                                      d + 1, __VA_ARGS__, i1 + m_offset[d])   \
  }

#define KOKKOS_IMPL_TAGGED_LOOP_R_3_REDUX(val, tag, func, type, m_offset,     \
                                          extent, d, ...)                     \
  for (type i2 = (type)0; i2 < static_cast<type>(extent[d]); ++i2) {          \
    KOKKOS_IMPL_TAGGED_LOOP_R_2_REDUX(val, tag, func, type, m_offset, extent, \
                                      d + 1, __VA_ARGS__, i2 + m_offset[d])   \
  }

#define KOKKOS_IMPL_TAGGED_LOOP_R_4_REDUX(val, tag, func, type, m_offset,     \
                                          extent, d, ...)                     \
  for (type i3 = (type)0; i3 < static_cast<type>(extent[d]); ++i3) {          \
    KOKKOS_IMPL_TAGGED_LOOP_R_3_REDUX(val, tag, func, type, m_offset, extent, \
                                      d + 1, __VA_ARGS__, i3 + m_offset[d])   \
  }

#define KOKKOS_IMPL_TAGGED_LOOP_R_5_REDUX(val, tag, func, type, m_offset,     \
                                          extent, d, ...)                     \
  for (type i4 = (type)0; i4 < static_cast<type>(extent[d]); ++i4) {          \
    KOKKOS_IMPL_TAGGED_LOOP_R_4_REDUX(val, tag, func, type, m_offset, extent, \
                                      d + 1, __VA_ARGS__, i4 + m_offset[d])   \
  }

#define KOKKOS_IMPL_TAGGED_LOOP_R_6_REDUX(val, tag, func, type, m_offset,     \
                                          extent, d, ...)                     \
  for (type i5 = (type)0; i5 < static_cast<type>(extent[d]); ++i5) {          \
    KOKKOS_IMPL_TAGGED_LOOP_R_5_REDUX(val, tag, func, type, m_offset, extent, \
                                      d + 1, __VA_ARGS__, i5 + m_offset[d])   \
  }

#define KOKKOS_IMPL_TAGGED_LOOP_R_7_REDUX(val, tag, func, type, m_offset,     \
                                          extent, d, ...)                     \
  for (type i6 = (type)0; i6 < static_cast<type>(extent[d]); ++i6) {          \
    KOKKOS_IMPL_TAGGED_LOOP_R_6_REDUX(val, tag, func, type, m_offset, extent, \
                                      d + 1, __VA_ARGS__, i6 + m_offset[d])   \
  }

#define KOKKOS_IMPL_TAGGED_LOOP_R_8_REDUX(val, tag, func, type, m_offset,     \
                                          extent, d, ...)                     \
  for (type i7 = (type)0; i7 < static_cast<type>(extent[d]); ++i7) {          \
    KOKKOS_IMPL_TAGGED_LOOP_R_7_REDUX(val, tag, func, type, m_offset, extent, \
                                      d + 1, __VA_ARGS__, i7 + m_offset[d])   \
  }

// LayoutLeft
// d = rank-1 to start
#define KOKKOS_IMPL_TAGGED_LOOP_L_1_REDUX(val, tag, func, type, m_offset, \
                                          extent, d, ...)                 \
  KOKKOS_ENABLE_IVDEP_MDRANGE                                             \
  for (type i0 = (type)0; i0 < static_cast<type>(extent[d]); ++i0) {      \
    KOKKOS_IMPL_TAGGED_APPLY_REDUX(val, tag, func, i0 + m_offset[d],      \
                                   __VA_ARGS__)                           \
  }

#define KOKKOS_IMPL_TAGGED_LOOP_L_2_REDUX(val, tag, func, type, m_offset,     \
                                          extent, d, ...)                     \
  for (type i1 = (type)0; i1 < static_cast<type>(extent[d]); ++i1) {          \
    KOKKOS_IMPL_TAGGED_LOOP_L_1_REDUX(val, tag, func, type, m_offset, extent, \
                                      d - 1, i1 + m_offset[d], __VA_ARGS__)   \
  }

#define KOKKOS_IMPL_TAGGED_LOOP_L_3_REDUX(val, tag, func, type, m_offset,     \
                                          extent, d, ...)                     \
  for (type i2 = (type)0; i2 < static_cast<type>(extent[d]); ++i2) {          \
    KOKKOS_IMPL_TAGGED_LOOP_L_2_REDUX(val, tag, func, type, m_offset, extent, \
                                      d - 1, i2 + m_offset[d], __VA_ARGS__)   \
  }

#define KOKKOS_IMPL_TAGGED_LOOP_L_4_REDUX(val, tag, func, type, m_offset,     \
                                          extent, d, ...)                     \
  for (type i3 = (type)0; i3 < static_cast<type>(extent[d]); ++i3) {          \
    KOKKOS_IMPL_TAGGED_LOOP_L_3_REDUX(val, tag, func, type, m_offset, extent, \
                                      d - 1, i3 + m_offset[d], __VA_ARGS__)   \
  }

#define KOKKOS_IMPL_TAGGED_LOOP_L_5_REDUX(val, tag, func, type, m_offset,     \
                                          extent, d, ...)                     \
  for (type i4 = (type)0; i4 < static_cast<type>(extent[d]); ++i4) {          \
    KOKKOS_IMPL_TAGGED_LOOP_L_4_REDUX(val, tag, func, type, m_offset, extent, \
                                      d - 1, i4 + m_offset[d], __VA_ARGS__)   \
  }

#define KOKKOS_IMPL_TAGGED_LOOP_L_6_REDUX(val, tag, func, type, m_offset,     \
                                          extent, d, ...)                     \
  for (type i5 = (type)0; i5 < static_cast<type>(extent[d]); ++i5) {          \
    KOKKOS_IMPL_TAGGED_LOOP_L_5_REDUX(val, tag, func, type, m_offset, extent, \
                                      d - 1, i5 + m_offset[d], __VA_ARGS__)   \
  }

#define KOKKOS_IMPL_TAGGED_LOOP_L_7_REDUX(val, tag, func, type, m_offset,     \
                                          extent, d, ...)                     \
  for (type i6 = (type)0; i6 < static_cast<type>(extent[d]); ++i6) {          \
    KOKKOS_IMPL_TAGGED_LOOP_L_6_REDUX(val, tag, func, type, m_offset, extent, \
                                      d - 1, i6 + m_offset[d], __VA_ARGS__)   \
  }

#define KOKKOS_IMPL_TAGGED_LOOP_L_8_REDUX(val, tag, func, type, m_offset,     \
                                          extent, d, ...)                     \
  for (type i7 = (type)0; i7 < static_cast<type>(extent[d]); ++i7) {          \
    KOKKOS_IMPL_TAGGED_LOOP_L_7_REDUX(val, tag, func, type, m_offset, extent, \
                                      d - 1, i7 + m_offset[d], __VA_ARGS__)   \
  }

// Left vs Right
#define KOKKOS_IMPL_TAGGED_LOOP_LAYOUT_1_REDUX(val, tag, func, type, is_left, \
                                               m_offset, extent, rank)        \
  KOKKOS_ENABLE_IVDEP_MDRANGE                                                 \
  for (type i0 = (type)0; i0 < static_cast<type>(extent[0]); ++i0) {          \
    KOKKOS_IMPL_TAGGED_APPLY_REDUX(val, tag, func, i0 + m_offset[0])          \
  }

#define KOKKOS_IMPL_TAGGED_LOOP_LAYOUT_2_REDUX(val, tag, func, type, is_left, \
                                               m_offset, extent, rank)        \
  if (is_left) {                                                              \
    for (type i1 = (type)0; i1 < static_cast<type>(extent[rank - 1]); ++i1) { \
      KOKKOS_IMPL_TAGGED_LOOP_L_1_REDUX(val, tag, func, type, m_offset,       \
                                        extent, rank - 2,                     \
                                        i1 + m_offset[rank - 1])              \
    }                                                                         \
  } else {                                                                    \
    for (type i1 = (type)0; i1 < static_cast<type>(extent[0]); ++i1) {        \
      KOKKOS_IMPL_TAGGED_LOOP_R_1_REDUX(val, tag, func, type, m_offset,       \
                                        extent, 1, i1 + m_offset[0])          \
    }                                                                         \
  }

#define KOKKOS_IMPL_TAGGED_LOOP_LAYOUT_3_REDUX(val, tag, func, type, is_left, \
                                               m_offset, extent, rank)        \
  if (is_left) {                                                              \
    for (type i2 = (type)0; i2 < static_cast<type>(extent[rank - 1]); ++i2) { \
      KOKKOS_IMPL_TAGGED_LOOP_L_2_REDUX(val, tag, func, type, m_offset,       \
                                        extent, rank - 2,                     \
                                        i2 + m_offset[rank - 1])              \
    }                                                                         \
  } else {                                                                    \
    for (type i2 = (type)0; i2 < static_cast<type>(extent[0]); ++i2) {        \
      KOKKOS_IMPL_TAGGED_LOOP_R_2_REDUX(val, tag, func, type, m_offset,       \
                                        extent, 1, i2 + m_offset[0])          \
    }                                                                         \
  }

#define KOKKOS_IMPL_TAGGED_LOOP_LAYOUT_4_REDUX(val, tag, func, type, is_left, \
                                               m_offset, extent, rank)        \
  if (is_left) {                                                              \
    for (type i3 = (type)0; i3 < static_cast<type>(extent[rank - 1]); ++i3) { \
      KOKKOS_IMPL_TAGGED_LOOP_L_3_REDUX(val, tag, func, type, m_offset,       \
                                        extent, rank - 2,                     \
                                        i3 + m_offset[rank - 1])              \
    }                                                                         \
  } else {                                                                    \
    for (type i3 = (type)0; i3 < static_cast<type>(extent[0]); ++i3) {        \
      KOKKOS_IMPL_TAGGED_LOOP_R_3_REDUX(val, tag, func, type, m_offset,       \
                                        extent, 1, i3 + m_offset[0])          \
    }                                                                         \
  }

#define KOKKOS_IMPL_TAGGED_LOOP_LAYOUT_5_REDUX(val, tag, func, type, is_left, \
                                               m_offset, extent, rank)        \
  if (is_left) {                                                              \
    for (type i4 = (type)0; i4 < static_cast<type>(extent[rank - 1]); ++i4) { \
      KOKKOS_IMPL_TAGGED_LOOP_L_4_REDUX(val, tag, func, type, m_offset,       \
                                        extent, rank - 2,                     \
                                        i4 + m_offset[rank - 1])              \
    }                                                                         \
  } else {                                                                    \
    for (type i4 = (type)0; i4 < static_cast<type>(extent[0]); ++i4) {        \
      KOKKOS_IMPL_TAGGED_LOOP_R_4_REDUX(val, tag, func, type, m_offset,       \
                                        extent, 1, i4 + m_offset[0])          \
    }                                                                         \
  }

#define KOKKOS_IMPL_TAGGED_LOOP_LAYOUT_6_REDUX(val, tag, func, type, is_left, \
                                               m_offset, extent, rank)        \
  if (is_left) {                                                              \
    for (type i5 = (type)0; i5 < static_cast<type>(extent[rank - 1]); ++i5) { \
      KOKKOS_IMPL_TAGGED_LOOP_L_5_REDUX(val, tag, func, type, m_offset,       \
                                        extent, rank - 2,                     \
                                        i5 + m_offset[rank - 1])              \
    }                                                                         \
  } else {                                                                    \
    for (type i5 = (type)0; i5 < static_cast<type>(extent[0]); ++i5) {        \
      KOKKOS_IMPL_TAGGED_LOOP_R_5_REDUX(val, tag, func, type, m_offset,       \
                                        extent, 1, i5 + m_offset[0])          \
    }                                                                         \
  }

#define KOKKOS_IMPL_TAGGED_LOOP_LAYOUT_7_REDUX(val, tag, func, type, is_left, \
                                               m_offset, extent, rank)        \
  if (is_left) {                                                              \
    for (type i6 = (type)0; i6 < static_cast<type>(extent[rank - 1]); ++i6) { \
      KOKKOS_IMPL_TAGGED_LOOP_L_6_REDUX(val, tag, func, type, m_offset,       \
                                        extent, rank - 2,                     \
                                        i6 + m_offset[rank - 1])              \
    }                                                                         \
  } else {                                                                    \
    for (type i6 = (type)0; i6 < static_cast<type>(extent[0]); ++i6) {        \
      KOKKOS_IMPL_TAGGED_LOOP_R_6_REDUX(val, tag, func, type, m_offset,       \
                                        extent, 1, i6 + m_offset[0])          \
    }                                                                         \
  }

#define KOKKOS_IMPL_TAGGED_LOOP_LAYOUT_8_REDUX(val, tag, func, type, is_left, \
                                               m_offset, extent, rank)        \
  if (is_left) {                                                              \
    for (type i7 = (type)0; i7 < static_cast<type>(extent[rank - 1]); ++i7) { \
      KOKKOS_IMPL_TAGGED_LOOP_L_7_REDUX(val, tag, func, type, m_offset,       \
                                        extent, rank - 2,                     \
                                        i7 + m_offset[rank - 1])              \
    }                                                                         \
  } else {                                                                    \
    for (type i7 = (type)0; i7 < static_cast<type>(extent[0]); ++i7) {        \
      KOKKOS_IMPL_TAGGED_LOOP_R_7_REDUX(val, tag, func, type, m_offset,       \
                                        extent, 1, i7 + m_offset[0])          \
    }                                                                         \
  }

// Partial vs Full Tile
#define KOKKOS_IMPL_TAGGED_TILE_LOOP_1_REDUX(val, tag, func, type, is_left, \
                                             cond, m_offset, extent_full,   \
                                             extent_partial, rank)          \
  if (cond) {                                                               \
    KOKKOS_IMPL_TAGGED_LOOP_LAYOUT_1_REDUX(val, tag, func, type, is_left,   \
                                           m_offset, extent_full, rank)     \
  } else {                                                                  \
    KOKKOS_IMPL_TAGGED_LOOP_LAYOUT_1_REDUX(val, tag, func, type, is_left,   \
                                           m_offset, extent_partial, rank)  \
  }

#define KOKKOS_IMPL_TAGGED_TILE_LOOP_2_REDUX(val, tag, func, type, is_left, \
                                             cond, m_offset, extent_full,   \
                                             extent_partial, rank)          \
  if (cond) {                                                               \
    KOKKOS_IMPL_TAGGED_LOOP_LAYOUT_2_REDUX(val, tag, func, type, is_left,   \
                                           m_offset, extent_full, rank)     \
  } else {                                                                  \
    KOKKOS_IMPL_TAGGED_LOOP_LAYOUT_2_REDUX(val, tag, func, type, is_left,   \
                                           m_offset, extent_partial, rank)  \
  }

#define KOKKOS_IMPL_TAGGED_TILE_LOOP_3_REDUX(val, tag, func, type, is_left, \
                                             cond, m_offset, extent_full,   \
                                             extent_partial, rank)          \
  if (cond) {                                                               \
    KOKKOS_IMPL_TAGGED_LOOP_LAYOUT_3_REDUX(val, tag, func, type, is_left,   \
                                           m_offset, extent_full, rank)     \
  } else {                                                                  \
    KOKKOS_IMPL_TAGGED_LOOP_LAYOUT_3_REDUX(val, tag, func, type, is_left,   \
                                           m_offset, extent_partial, rank)  \
  }

#define KOKKOS_IMPL_TAGGED_TILE_LOOP_4_REDUX(val, tag, func, type, is_left, \
                                             cond, m_offset, extent_full,   \
                                             extent_partial, rank)          \
  if (cond) {                                                               \
    KOKKOS_IMPL_TAGGED_LOOP_LAYOUT_4_REDUX(val, tag, func, type, is_left,   \
                                           m_offset, extent_full, rank)     \
  } else {                                                                  \
    KOKKOS_IMPL_TAGGED_LOOP_LAYOUT_4_REDUX(val, tag, func, type, is_left,   \
                                           m_offset, extent_partial, rank)  \
  }

#define KOKKOS_IMPL_TAGGED_TILE_LOOP_5_REDUX(val, tag, func, type, is_left, \
                                             cond, m_offset, extent_full,   \
                                             extent_partial, rank)          \
  if (cond) {                                                               \
    KOKKOS_IMPL_TAGGED_LOOP_LAYOUT_5_REDUX(val, tag, func, type, is_left,   \
                                           m_offset, extent_full, rank)     \
  } else {                                                                  \
    KOKKOS_IMPL_TAGGED_LOOP_LAYOUT_5_REDUX(val, tag, func, type, is_left,   \
                                           m_offset, extent_partial, rank)  \
  }

#define KOKKOS_IMPL_TAGGED_TILE_LOOP_6_REDUX(val, tag, func, type, is_left, \
                                             cond, m_offset, extent_full,   \
                                             extent_partial, rank)          \
  if (cond) {                                                               \
    KOKKOS_IMPL_TAGGED_LOOP_LAYOUT_6_REDUX(val, tag, func, type, is_left,   \
                                           m_offset, extent_full, rank)     \
  } else {                                                                  \
    KOKKOS_IMPL_TAGGED_LOOP_LAYOUT_6_REDUX(val, tag, func, type, is_left,   \
                                           m_offset, extent_partial, rank)  \
  }

#define KOKKOS_IMPL_TAGGED_TILE_LOOP_7_REDUX(val, tag, func, type, is_left, \
                                             cond, m_offset, extent_full,   \
                                             extent_partial, rank)          \
  if (cond) {                                                               \
    KOKKOS_IMPL_TAGGED_LOOP_LAYOUT_7_REDUX(val, tag, func, type, is_left,   \
                                           m_offset, extent_full, rank)     \
  } else {                                                                  \
    KOKKOS_IMPL_TAGGED_LOOP_LAYOUT_7_REDUX(val, tag, func, type, is_left,   \
                                           m_offset, extent_partial, rank)  \
  }

#define KOKKOS_IMPL_TAGGED_TILE_LOOP_8_REDUX(val, tag, func, type, is_left, \
                                             cond, m_offset, extent_full,   \
                                             extent_partial, rank)          \
  if (cond) {                                                               \
    KOKKOS_IMPL_TAGGED_LOOP_LAYOUT_8_REDUX(val, tag, func, type, is_left,   \
                                           m_offset, extent_full, rank)     \
  } else {                                                                  \
    KOKKOS_IMPL_TAGGED_LOOP_LAYOUT_8_REDUX(val, tag, func, type, is_left,   \
                                           m_offset, extent_partial, rank)  \
  }

// end tagged macros

// Structs for calling loops
template <int Rank, bool IsLeft, typename IType, typename Tagged>
struct Tile_Loop_Type;

template <bool IsLeft, typename IType, typename Tagged>
struct Tile_Loop_Type<1, IsLeft, IType, Tagged> {
  template <typename Func, typename Offset, typename ExtentA, typename ExtentB>
  static void apply(Func const& func, bool cond, Offset const& offset,
                    ExtentA const& a, ExtentB const& b) {
    KOKKOS_IMPL_TILE_LOOP_1(Tagged, func, IType, IsLeft, cond, offset, a, b, 1);
  }

  template <typename ValType, typename Func, typename Offset, typename ExtentA,
            typename ExtentB>
    requires(std::is_void_v<Tagged>)
  static void apply(ValType& value, Func const& func, bool cond,
                    Offset const& offset, ExtentA const& a, ExtentB const& b) {
    KOKKOS_IMPL_TILE_LOOP_1_REDUX(value, func, IType, IsLeft, cond, offset, a,
                                  b, 1);
  }

  template <typename ValType, typename Func, typename Offset, typename ExtentA,
            typename ExtentB>
    requires(!std::is_void_v<Tagged>)
  static void apply(ValType& value, Func const& func, bool cond,
                    Offset const& offset, ExtentA const& a, ExtentB const& b) {
    KOKKOS_IMPL_TAGGED_TILE_LOOP_1_REDUX(value, Tagged(), func, IType, IsLeft,
                                         cond, offset, a, b, 1);
  }
};

template <bool IsLeft, typename IType, typename Tagged>
struct Tile_Loop_Type<2, IsLeft, IType, Tagged> {
  template <typename Func, typename Offset, typename ExtentA, typename ExtentB>
  static void apply(Func const& func, bool cond, Offset const& offset,
                    ExtentA const& a, ExtentB const& b) {
    KOKKOS_IMPL_TILE_LOOP_2(Tagged, func, IType, IsLeft, cond, offset, a, b, 2);
  }

  template <typename ValType, typename Func, typename Offset, typename ExtentA,
            typename ExtentB>
    requires(std::is_void_v<Tagged>)
  static void apply(ValType& value, Func const& func, bool cond,
                    Offset const& offset, ExtentA const& a, ExtentB const& b) {
    KOKKOS_IMPL_TILE_LOOP_2_REDUX(value, func, IType, IsLeft, cond, offset, a,
                                  b, 2);
  }

  template <typename ValType, typename Func, typename Offset, typename ExtentA,
            typename ExtentB>
    requires(!std::is_void_v<Tagged>)
  static void apply(ValType& value, Func const& func, bool cond,
                    Offset const& offset, ExtentA const& a, ExtentB const& b) {
    KOKKOS_IMPL_TAGGED_TILE_LOOP_2_REDUX(value, Tagged(), func, IType, IsLeft,
                                         cond, offset, a, b, 2);
  }
};

template <bool IsLeft, typename IType, typename Tagged>
struct Tile_Loop_Type<3, IsLeft, IType, Tagged> {
  template <typename Func, typename Offset, typename ExtentA, typename ExtentB>
  static void apply(Func const& func, bool cond, Offset const& offset,
                    ExtentA const& a, ExtentB const& b) {
    KOKKOS_IMPL_TILE_LOOP_3(Tagged, func, IType, IsLeft, cond, offset, a, b, 3);
  }

  template <typename ValType, typename Func, typename Offset, typename ExtentA,
            typename ExtentB>
    requires(std::is_void_v<Tagged>)
  static void apply(ValType& value, Func const& func, bool cond,
                    Offset const& offset, ExtentA const& a, ExtentB const& b) {
    KOKKOS_IMPL_TILE_LOOP_3_REDUX(value, func, IType, IsLeft, cond, offset, a,
                                  b, 3);
  }

  template <typename ValType, typename Func, typename Offset, typename ExtentA,
            typename ExtentB>
    requires(!std::is_void_v<Tagged>)
  static void apply(ValType& value, Func const& func, bool cond,
                    Offset const& offset, ExtentA const& a, ExtentB const& b) {
    KOKKOS_IMPL_TAGGED_TILE_LOOP_3_REDUX(value, Tagged(), func, IType, IsLeft,
                                         cond, offset, a, b, 3);
  }
};

template <bool IsLeft, typename IType, typename Tagged>
struct Tile_Loop_Type<4, IsLeft, IType, Tagged> {
  template <typename Func, typename Offset, typename ExtentA, typename ExtentB>
  static void apply(Func const& func, bool cond, Offset const& offset,
                    ExtentA const& a, ExtentB const& b) {
    KOKKOS_IMPL_TILE_LOOP_4(Tagged, func, IType, IsLeft, cond, offset, a, b, 4);
  }

  template <typename ValType, typename Func, typename Offset, typename ExtentA,
            typename ExtentB>
    requires(std::is_void_v<Tagged>)
  static void apply(ValType& value, Func const& func, bool cond,
                    Offset const& offset, ExtentA const& a, ExtentB const& b) {
    KOKKOS_IMPL_TILE_LOOP_4_REDUX(value, func, IType, IsLeft, cond, offset, a,
                                  b, 4);
  }

  template <typename ValType, typename Func, typename Offset, typename ExtentA,
            typename ExtentB>
    requires(!std::is_void_v<Tagged>)
  static void apply(ValType& value, Func const& func, bool cond,
                    Offset const& offset, ExtentA const& a, ExtentB const& b) {
    KOKKOS_IMPL_TAGGED_TILE_LOOP_4_REDUX(value, Tagged(), func, IType, IsLeft,
                                         cond, offset, a, b, 4);
  }
};

template <bool IsLeft, typename IType, typename Tagged>
struct Tile_Loop_Type<5, IsLeft, IType, Tagged> {
  template <typename Func, typename Offset, typename ExtentA, typename ExtentB>
  static void apply(Func const& func, bool cond, Offset const& offset,
                    ExtentA const& a, ExtentB const& b) {
    KOKKOS_IMPL_TILE_LOOP_5(Tagged, func, IType, IsLeft, cond, offset, a, b, 5);
  }

  template <typename ValType, typename Func, typename Offset, typename ExtentA,
            typename ExtentB>
    requires(std::is_void_v<Tagged>)
  static void apply(ValType& value, Func const& func, bool cond,
                    Offset const& offset, ExtentA const& a, ExtentB const& b) {
    KOKKOS_IMPL_TILE_LOOP_5_REDUX(value, func, IType, IsLeft, cond, offset, a,
                                  b, 5);
  }

  template <typename ValType, typename Func, typename Offset, typename ExtentA,
            typename ExtentB>
    requires(!std::is_void_v<Tagged>)
  static void apply(ValType& value, Func const& func, bool cond,
                    Offset const& offset, ExtentA const& a, ExtentB const& b) {
    KOKKOS_IMPL_TAGGED_TILE_LOOP_5_REDUX(value, Tagged(), func, IType, IsLeft,
                                         cond, offset, a, b, 5);
  }
};

template <bool IsLeft, typename IType, typename Tagged>
struct Tile_Loop_Type<6, IsLeft, IType, Tagged> {
  template <typename Func, typename Offset, typename ExtentA, typename ExtentB>
  static void apply(Func const& func, bool cond, Offset const& offset,
                    ExtentA const& a, ExtentB const& b) {
    KOKKOS_IMPL_TILE_LOOP_6(Tagged, func, IType, IsLeft, cond, offset, a, b, 6);
  }

  template <typename ValType, typename Func, typename Offset, typename ExtentA,
            typename ExtentB>
    requires(std::is_void_v<Tagged>)
  static void apply(ValType& value, Func const& func, bool cond,
                    Offset const& offset, ExtentA const& a, ExtentB const& b) {
    KOKKOS_IMPL_TILE_LOOP_6_REDUX(value, func, IType, IsLeft, cond, offset, a,
                                  b, 6);
  }

  template <typename ValType, typename Func, typename Offset, typename ExtentA,
            typename ExtentB>
    requires(!std::is_void_v<Tagged>)
  static void apply(ValType& value, Func const& func, bool cond,
                    Offset const& offset, ExtentA const& a, ExtentB const& b) {
    KOKKOS_IMPL_TAGGED_TILE_LOOP_6_REDUX(value, Tagged(), func, IType, IsLeft,
                                         cond, offset, a, b, 6);
  }
};

template <bool IsLeft, typename IType, typename Tagged>
struct Tile_Loop_Type<7, IsLeft, IType, Tagged> {
  template <typename Func, typename Offset, typename ExtentA, typename ExtentB>
  static void apply(Func const& func, bool cond, Offset const& offset,
                    ExtentA const& a, ExtentB const& b) {
    KOKKOS_IMPL_TILE_LOOP_7(Tagged, func, IType, IsLeft, cond, offset, a, b, 7);
  }

  template <typename ValType, typename Func, typename Offset, typename ExtentA,
            typename ExtentB>
    requires(std::is_void_v<Tagged>)
  static void apply(ValType& value, Func const& func, bool cond,
                    Offset const& offset, ExtentA const& a, ExtentB const& b) {
    KOKKOS_IMPL_TILE_LOOP_7_REDUX(value, func, IType, IsLeft, cond, offset, a,
                                  b, 7);
  }

  template <typename ValType, typename Func, typename Offset, typename ExtentA,
            typename ExtentB>
    requires(!std::is_void_v<Tagged>)
  static void apply(ValType& value, Func const& func, bool cond,
                    Offset const& offset, ExtentA const& a, ExtentB const& b) {
    KOKKOS_IMPL_TAGGED_TILE_LOOP_7_REDUX(value, Tagged(), func, IType, IsLeft,
                                         cond, offset, a, b, 7);
  }
};

template <bool IsLeft, typename IType, typename Tagged>
struct Tile_Loop_Type<8, IsLeft, IType, Tagged> {
  template <typename Func, typename Offset, typename ExtentA, typename ExtentB>
  static void apply(Func const& func, bool cond, Offset const& offset,
                    ExtentA const& a, ExtentB const& b) {
    KOKKOS_IMPL_TILE_LOOP_8(Tagged, func, IType, IsLeft, cond, offset, a, b, 8);
  }

  template <typename ValType, typename Func, typename Offset, typename ExtentA,
            typename ExtentB>
    requires(std::is_void_v<Tagged>)
  static void apply(ValType& value, Func const& func, bool cond,
                    Offset const& offset, ExtentA const& a, ExtentB const& b) {
    KOKKOS_IMPL_TILE_LOOP_8_REDUX(value, func, IType, IsLeft, cond, offset, a,
                                  b, 8);
  }

  template <typename ValType, typename Func, typename Offset, typename ExtentA,
            typename ExtentB>
    requires(!std::is_void_v<Tagged>)
  static void apply(ValType& value, Func const& func, bool cond,
                    Offset const& offset, ExtentA const& a, ExtentB const& b) {
    KOKKOS_IMPL_TAGGED_TILE_LOOP_8_REDUX(value, Tagged(), func, IType, IsLeft,
                                         cond, offset, a, b, 8);
  }
};

// end Structs for calling loops

template <typename RP, typename Functor, typename Tag, typename ReferenceType>
struct HostIterateTile {
  using index_type = typename RP::index_type;
  using point_type = typename RP::point_type;
  using tile_type  = typename RP::tile_type;

  inline HostIterateTile(RP const& rp, Functor const& func)
      : m_lower(rp.lower()),
        m_upper(rp.upper()),
        m_tile(rp.tile_size()),
        m_tile_end(rp.impl_tile_end()),
        m_func(func) {}

  // ParallelFor
  template <typename IType>
  inline void operator()(IType tile_idx) const {
    point_type m_offset;
    point_type m_tiledims;

    if constexpr (RP::outer_direction == Iterate::Left) {
      for (int i = 0; i < RP::rank; ++i) {
        m_offset[i] = (tile_idx % m_tile_end[i]) * m_tile[i] + m_lower[i];
        tile_idx /= m_tile_end[i];
      }
    } else {
      for (int i = RP::rank - 1; i >= 0; --i) {
        m_offset[i] = (tile_idx % m_tile_end[i]) * m_tile[i] + m_lower[i];
        tile_idx /= m_tile_end[i];
      }
    }

    // Check if offset+tiledim in bounds - if not, replace tile dims with the
    // partial tile dims
    const bool full_tile = check_iteration_bounds(m_tiledims, m_offset);

    Tile_Loop_Type<RP::rank, (RP::inner_direction == Iterate::Left), index_type,
                   Tag>::apply(m_func, full_tile, m_offset, m_tile, m_tiledims);
  }

  template <typename... Args>
  void apply(Args&&... args) const {
    static_assert(sizeof...(Args) == RP::rank);
    if constexpr (std::is_void_v<Tag>)
      m_func(args...);
    else
      m_func(Tag{}, args...);
  }

  inline bool check_iteration_bounds(point_type& partial_tile,
                                     const point_type& offset) const {
    bool is_full_tile = true;

    for (int i = 0; i < RP::rank; ++i) {
      if ((offset[i] + m_tile[i]) <= m_upper[i]) {
        partial_tile[i] = m_tile[i];
      } else {
        is_full_tile = false;
        partial_tile[i] =
            m_upper[i] - offset[i];  // remaining elements in dimension i
      }
    }

    return is_full_tile;
  }  // end check bounds

  // ParallelReduce

  // Even when using a requires class for prohibiting the ReferenceType to be
  // void in the call operator below, we still get a compiler error saying:
  //   error: argument may not have 'void' type
  // Hence, just use a different type in that case to make the compiler happy.
  using valid_reference_type =
      std::conditional_t<std::is_void_v<ReferenceType>, int, ReferenceType>;

  template <typename IType>
    requires(!std::is_void_v<ReferenceType>)
  inline void operator()(IType tile_idx, valid_reference_type val) const {
    point_type m_offset;
    point_type m_tiledims;

    if constexpr (RP::outer_direction == Iterate::Left) {
      for (int i = 0; i < RP::rank; ++i) {
        m_offset[i] = (tile_idx % m_tile_end[i]) * m_tile[i] + m_lower[i];
        tile_idx /= m_tile_end[i];
      }
    } else {
      for (int i = RP::rank - 1; i >= 0; --i) {
        m_offset[i] = (tile_idx % m_tile_end[i]) * m_tile[i] + m_lower[i];
        tile_idx /= m_tile_end[i];
      }
    }

    // Check if offset+tiledim in bounds - if not, replace tile dims with the
    // partial tile dims
    const bool full_tile = check_iteration_bounds(m_tiledims, m_offset);

    Tile_Loop_Type<RP::rank, (RP::inner_direction == Iterate::Left), index_type,
                   Tag>::apply(val, m_func.get_functor(), full_tile, m_offset,
                               m_tile, m_tiledims);
  }

  point_type const m_lower;
  point_type const m_upper;
  tile_type const m_tile;
  point_type const m_tile_end;
  Functor const m_func;
};

// ------------------------------------------------------------------ //

#undef KOKKOS_IMPL_APPLY
#undef KOKKOS_IMPL_LOOP_R_1
#undef KOKKOS_IMPL_LOOP_R_2
#undef KOKKOS_IMPL_LOOP_R_3
#undef KOKKOS_IMPL_LOOP_R_4
#undef KOKKOS_IMPL_LOOP_R_5
#undef KOKKOS_IMPL_LOOP_R_6
#undef KOKKOS_IMPL_LOOP_R_7
#undef KOKKOS_IMPL_LOOP_R_8
#undef KOKKOS_IMPL_LOOP_L_1
#undef KOKKOS_IMPL_LOOP_L_2
#undef KOKKOS_IMPL_LOOP_L_3
#undef KOKKOS_IMPL_LOOP_L_4
#undef KOKKOS_IMPL_LOOP_L_5
#undef KOKKOS_IMPL_LOOP_L_6
#undef KOKKOS_IMPL_LOOP_L_7
#undef KOKKOS_IMPL_LOOP_L_8
#undef KOKKOS_IMPL_LOOP_LAYOUT_1
#undef KOKKOS_IMPL_LOOP_LAYOUT_2
#undef KOKKOS_IMPL_LOOP_LAYOUT_3
#undef KOKKOS_IMPL_LOOP_LAYOUT_4
#undef KOKKOS_IMPL_LOOP_LAYOUT_5
#undef KOKKOS_IMPL_LOOP_LAYOUT_6
#undef KOKKOS_IMPL_LOOP_LAYOUT_7
#undef KOKKOS_IMPL_LOOP_LAYOUT_8
#undef KOKKOS_IMPL_TILE_LOOP_1
#undef KOKKOS_IMPL_TILE_LOOP_2
#undef KOKKOS_IMPL_TILE_LOOP_3
#undef KOKKOS_IMPL_TILE_LOOP_4
#undef KOKKOS_IMPL_TILE_LOOP_5
#undef KOKKOS_IMPL_TILE_LOOP_6
#undef KOKKOS_IMPL_TILE_LOOP_7
#undef KOKKOS_IMPL_TILE_LOOP_8
#undef KOKKOS_IMPL_APPLY_REDUX
#undef KOKKOS_IMPL_LOOP_R_1_REDUX
#undef KOKKOS_IMPL_LOOP_R_2_REDUX
#undef KOKKOS_IMPL_LOOP_R_3_REDUX
#undef KOKKOS_IMPL_LOOP_R_4_REDUX
#undef KOKKOS_IMPL_LOOP_R_5_REDUX
#undef KOKKOS_IMPL_LOOP_R_6_REDUX
#undef KOKKOS_IMPL_LOOP_R_7_REDUX
#undef KOKKOS_IMPL_LOOP_R_8_REDUX
#undef KOKKOS_IMPL_LOOP_L_1_REDUX
#undef KOKKOS_IMPL_LOOP_L_2_REDUX
#undef KOKKOS_IMPL_LOOP_L_3_REDUX
#undef KOKKOS_IMPL_LOOP_L_4_REDUX
#undef KOKKOS_IMPL_LOOP_L_5_REDUX
#undef KOKKOS_IMPL_LOOP_L_6_REDUX
#undef KOKKOS_IMPL_LOOP_L_7_REDUX
#undef KOKKOS_IMPL_LOOP_L_8_REDUX
#undef KOKKOS_IMPL_LOOP_LAYOUT_1_REDUX
#undef KOKKOS_IMPL_LOOP_LAYOUT_2_REDUX
#undef KOKKOS_IMPL_LOOP_LAYOUT_3_REDUX
#undef KOKKOS_IMPL_LOOP_LAYOUT_4_REDUX
#undef KOKKOS_IMPL_LOOP_LAYOUT_5_REDUX
#undef KOKKOS_IMPL_LOOP_LAYOUT_6_REDUX
#undef KOKKOS_IMPL_LOOP_LAYOUT_7_REDUX
#undef KOKKOS_IMPL_LOOP_LAYOUT_8_REDUX
#undef KOKKOS_IMPL_TILE_LOOP_1_REDUX
#undef KOKKOS_IMPL_TILE_LOOP_2_REDUX
#undef KOKKOS_IMPL_TILE_LOOP_3_REDUX
#undef KOKKOS_IMPL_TILE_LOOP_4_REDUX
#undef KOKKOS_IMPL_TILE_LOOP_5_REDUX
#undef KOKKOS_IMPL_TILE_LOOP_6_REDUX
#undef KOKKOS_IMPL_TILE_LOOP_7_REDUX
#undef KOKKOS_IMPL_TILE_LOOP_8_REDUX
#undef KOKKOS_IMPL_TAGGED_APPLY_REDUX
#undef KOKKOS_IMPL_TAGGED_LOOP_R_1_REDUX
#undef KOKKOS_IMPL_TAGGED_LOOP_R_2_REDUX
#undef KOKKOS_IMPL_TAGGED_LOOP_R_3_REDUX
#undef KOKKOS_IMPL_TAGGED_LOOP_R_4_REDUX
#undef KOKKOS_IMPL_TAGGED_LOOP_R_5_REDUX
#undef KOKKOS_IMPL_TAGGED_LOOP_R_6_REDUX
#undef KOKKOS_IMPL_TAGGED_LOOP_R_7_REDUX
#undef KOKKOS_IMPL_TAGGED_LOOP_R_8_REDUX
#undef KOKKOS_IMPL_TAGGED_LOOP_L_1_REDUX
#undef KOKKOS_IMPL_TAGGED_LOOP_L_2_REDUX
#undef KOKKOS_IMPL_TAGGED_LOOP_L_3_REDUX
#undef KOKKOS_IMPL_TAGGED_LOOP_L_4_REDUX
#undef KOKKOS_IMPL_TAGGED_LOOP_L_5_REDUX
#undef KOKKOS_IMPL_TAGGED_LOOP_L_6_REDUX
#undef KOKKOS_IMPL_TAGGED_LOOP_L_7_REDUX
#undef KOKKOS_IMPL_TAGGED_LOOP_L_8_REDUX
#undef KOKKOS_IMPL_TAGGED_LOOP_LAYOUT_1_REDUX
#undef KOKKOS_IMPL_TAGGED_LOOP_LAYOUT_2_REDUX
#undef KOKKOS_IMPL_TAGGED_LOOP_LAYOUT_3_REDUX
#undef KOKKOS_IMPL_TAGGED_LOOP_LAYOUT_4_REDUX
#undef KOKKOS_IMPL_TAGGED_LOOP_LAYOUT_5_REDUX
#undef KOKKOS_IMPL_TAGGED_LOOP_LAYOUT_6_REDUX
#undef KOKKOS_IMPL_TAGGED_LOOP_LAYOUT_7_REDUX
#undef KOKKOS_IMPL_TAGGED_LOOP_LAYOUT_8_REDUX
#undef KOKKOS_IMPL_TAGGED_TILE_LOOP_1_REDUX
#undef KOKKOS_IMPL_TAGGED_TILE_LOOP_2_REDUX
#undef KOKKOS_IMPL_TAGGED_TILE_LOOP_3_REDUX
#undef KOKKOS_IMPL_TAGGED_TILE_LOOP_4_REDUX
#undef KOKKOS_IMPL_TAGGED_TILE_LOOP_5_REDUX
#undef KOKKOS_IMPL_TAGGED_TILE_LOOP_6_REDUX
#undef KOKKOS_IMPL_TAGGED_TILE_LOOP_7_REDUX
#undef KOKKOS_IMPL_TAGGED_TILE_LOOP_8_REDUX

}  // namespace Impl
}  // namespace Kokkos

#endif
