// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// SPDX-FileCopyrightText: Copyright Contributors to the Kokkos project

#ifndef KOKKOS_IMPL_PUBLIC_INCLUDE
#include <Kokkos_Macros.hpp>
static_assert(false,
              "Including non-public Kokkos header files is not allowed.");
#endif
#ifndef KOKKOS_OPENMP_HPP
#define KOKKOS_OPENMP_HPP

#include <Kokkos_Macros.hpp>
#if defined(KOKKOS_ENABLE_OPENMP)

#include <Kokkos_Core_fwd.hpp>

#include <Kokkos_HostSpace.hpp>
#include <Kokkos_ScratchSpace.hpp>
#include <Kokkos_Parallel.hpp>
#include <Kokkos_Layout.hpp>
#include <impl/Kokkos_CheckUsage.hpp>
#include <impl/Kokkos_HostSharedPtr.hpp>
#include <impl/Kokkos_Profiling_Interface.hpp>
#include <impl/Kokkos_InitializationSettings.hpp>

#include <omp.h>

#include <cstddef>
#include <iosfwd>
#include <vector>

/*--------------------------------------------------------------------------*/

namespace Kokkos {

namespace Impl {
class OpenMPInternal;
}  // namespace Impl

/// \class OpenMP
/// \brief Kokkos device for multicore processors in the host memory space.
class OpenMP {
 public:
  //! Tag this class as a kokkos execution space
  using execution_space = OpenMP;

  using memory_space = HostSpace;

  //! This execution space preferred device_type
  using device_type          = Kokkos::Device<execution_space, memory_space>;
  using array_layout         = LayoutRight;
  using size_type            = memory_space::size_type;
  using index_type           = memory_space::index_type;
  using scratch_memory_space = ScratchMemorySpace<OpenMP>;

  KOKKOS_DEFAULTED_FUNCTION OpenMP(const OpenMP&) = default;
  KOKKOS_FUNCTION OpenMP(OpenMP&& other) noexcept
      : OpenMP(static_cast<const OpenMP&>(other)) {}
  KOKKOS_DEFAULTED_FUNCTION OpenMP& operator=(const OpenMP&) = default;
  KOKKOS_FUNCTION OpenMP& operator=(OpenMP&& other) noexcept {
    return *this = static_cast<const OpenMP&>(other);
  }
  // Must be __host__ __device__ for the implicitly defined
  // ~RangePolicy<ExecSpace>(); see the comment on ~Cuda() in
  // Cuda/Kokkos_Cuda.hpp.
  KOKKOS_FUNCTION ~OpenMP() {
    KOKKOS_IF_ON_HOST(
        (Impl::check_execution_space_destructor_precondition(name());))
  }

  OpenMP();

  explicit OpenMP(int pool_size);

  /// \brief Print configuration information to the given output stream.
  void print_configuration(std::ostream& os, bool verbose = false) const;

  /// \brief Wait until all dispatched functors complete on the given instance
  ///
  ///  This is a no-op on OpenMP
  static void impl_static_fence(std::string const& name);

  void fence(std::string const& name =
                 "Kokkos::OpenMP::fence: Unnamed Instance Fence") const;

  int concurrency() const;

  static void impl_initialize(InitializationSettings const&);

  /// \brief Free any resources being consumed by the default execution space
  static void impl_finalize();

  int impl_thread_pool_size() const noexcept;

  int impl_thread_pool_size(int depth) const;

  /** \brief  The rank of the executing thread in this thread pool */
  inline static int impl_thread_pool_rank() noexcept;

  // use UniqueToken
  static int impl_max_hardware_threads() noexcept;

  // use UniqueToken
  KOKKOS_INLINE_FUNCTION
  static int impl_hardware_thread_id() noexcept;

  static int impl_get_current_max_threads() noexcept;

  Impl::OpenMPInternal* impl_internal_space_instance() const {
    return m_space_instance.get();
  }

  static constexpr const char* name() noexcept { return "OpenMP"; }
  uint32_t impl_instance_id() const noexcept { return 1; }

 private:
  friend bool operator==(OpenMP const& lhs, OpenMP const& rhs) {
    return lhs.impl_internal_space_instance() ==
           rhs.impl_internal_space_instance();
  }
  friend bool operator!=(OpenMP const& lhs, OpenMP const& rhs) {
    return !(lhs == rhs);
  }
  Kokkos::Impl::HostSharedPtr<Impl::OpenMPInternal> m_space_instance;
};

inline int OpenMP::impl_thread_pool_rank() noexcept {
  KOKKOS_IF_ON_HOST((return omp_get_thread_num();))

  KOKKOS_IF_ON_DEVICE((return -1;))
  KOKKOS_IMPL_UNREACHABLE();
}

inline int OpenMP::impl_thread_pool_size(int depth) const {
  return depth < 2 ? impl_thread_pool_size() : 1;
}

KOKKOS_INLINE_FUNCTION
int OpenMP::impl_hardware_thread_id() noexcept {
  KOKKOS_IF_ON_HOST((return omp_get_thread_num();))

  KOKKOS_IF_ON_DEVICE((return -1;))
  KOKKOS_IMPL_UNREACHABLE();
}

namespace Tools {
namespace Experimental {
template <>
struct DeviceTypeTraits<OpenMP> {
  static constexpr DeviceType id = DeviceType::OpenMP;
  static int device_id(const OpenMP&) { return 0; }
};
}  // namespace Experimental
}  // namespace Tools
}  // namespace Kokkos

/*--------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------*/

namespace Kokkos {
namespace Impl {

template <>
struct MemorySpaceAccess<Kokkos::OpenMP::memory_space,
                         Kokkos::OpenMP::scratch_memory_space> {
  enum : bool { assignable = false };
  enum : bool { accessible = true };
};

}  // namespace Impl
}  // namespace Kokkos

/*--------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------*/

#include <OpenMP/Kokkos_OpenMP_Instance.hpp>
#include <OpenMP/Kokkos_OpenMP_Team.hpp>

#include <KokkosExp_MDRangePolicy.hpp>
/*--------------------------------------------------------------------------*/

#endif /* #if defined( KOKKOS_ENABLE_OPENMP ) && defined( _OPENMP ) */
#endif /* #ifndef KOKKOS_OPENMP_HPP */
