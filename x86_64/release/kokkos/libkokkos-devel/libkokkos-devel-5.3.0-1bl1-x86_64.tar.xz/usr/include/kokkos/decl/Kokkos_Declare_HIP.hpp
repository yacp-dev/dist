// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// SPDX-FileCopyrightText: Copyright Contributors to the Kokkos project

#ifndef KOKKOS_DECLARE_HIP_HPP
#define KOKKOS_DECLARE_HIP_HPP

#if defined(KOKKOS_ENABLE_HIP)
#include <HIP/Kokkos_HIP.hpp>
#include <HIP/Kokkos_HIP_Space.hpp>
#include <HIP/Kokkos_HIP_DeepCopy.hpp>
#include <HIP/Kokkos_HIP_Instance.hpp>
#include <HIP/Kokkos_HIP_MDRangePolicy.hpp>
#include <HIP/Kokkos_HIP_ParallelFor_Range.hpp>
#include <HIP/Kokkos_HIP_ParallelFor_MDRange.hpp>
#include <HIP/Kokkos_HIP_ParallelFor_Team.hpp>
#include <HIP/Kokkos_HIP_ParallelReduce_Range.hpp>
#include <HIP/Kokkos_HIP_ParallelReduce_MDRange.hpp>
#include <HIP/Kokkos_HIP_ParallelReduce_Team.hpp>
#include <HIP/Kokkos_HIP_ParallelScan_Range.hpp>
#include <HIP/Kokkos_HIP_UniqueToken.hpp>
#include <HIP/Kokkos_HIP_ZeroMemset.hpp>

#ifdef KOKKOS_ENABLE_DEPRECATED_CODE_5
namespace Kokkos {
namespace Experimental {
using HIPSpace KOKKOS_DEPRECATED_WITH_COMMENT("Use Kokkos::HIPSpace instead!") =
    ::Kokkos::HIPSpace;
using HIPHostPinnedSpace KOKKOS_DEPRECATED_WITH_COMMENT(
    "Use Kokkos::HIPHostPinnedSpace instead!") = ::Kokkos::HIPHostPinnedSpace;
using HIPManagedSpace KOKKOS_DEPRECATED_WITH_COMMENT(
    "Use Kokkos::HIPManagedSpace instead!") = ::Kokkos::HIPManagedSpace;
using HIP KOKKOS_DEPRECATED_WITH_COMMENT("Use Kokkos::HIP instead!") =
    ::Kokkos::HIP;
}  // namespace Experimental
}  // namespace Kokkos
#endif
#endif

#endif
