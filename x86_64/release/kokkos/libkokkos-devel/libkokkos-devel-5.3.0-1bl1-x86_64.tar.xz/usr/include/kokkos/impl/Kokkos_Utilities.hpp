// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// SPDX-FileCopyrightText: Copyright Contributors to the Kokkos project

#ifndef KOKKOS_CORE_IMPL_UTILITIES_HPP
#define KOKKOS_CORE_IMPL_UTILITIES_HPP

#include <Kokkos_Macros.hpp>
#include <cstdint>
#include <type_traits>
#include <initializer_list>  // in-order comma operator fold emulation
#include <utility>           // integer_sequence and friends

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

namespace Kokkos {
namespace Impl {

// same as std::integral_constant but with __host__ __device__ annotations on
// the implicit conversion function and the call operator
template <class T, T v>
struct integral_constant {
  using value_type         = T;
  using type               = integral_constant<T, v>;
  static constexpr T value = v;
  KOKKOS_FUNCTION constexpr operator value_type() const noexcept {
    return value;
  }
  KOKKOS_FUNCTION constexpr value_type operator()() const noexcept {
    return value;
  }
};

//==============================================================================

template <typename... Is>
struct always_true : std::true_type {};

// type-dependent expression that is always false intended for use in
// static_assert to check "we should never get there"
template <typename... Deps>
struct always_false : std::false_type {};

//==============================================================================

// same as C++23 std::to_underlying but with __host__ __device__ annotations
template <typename E>
KOKKOS_FUNCTION constexpr std::underlying_type_t<E> to_underlying(
    E e) noexcept {
  return static_cast<std::underlying_type_t<E>>(e);
}

#if defined(__cpp_lib_forward_like)
// since C++23
using std::forward_like;
#else
// The implementation is taken from section 4 of P2445R1, see
// https://www.open-std.org/jtc1/sc22/wg21/docs/papers/2022/p2445r1.pdf.
namespace ForwardLikeHelper {
template <typename T, typename U>
using override_ref_t = std::conditional_t<std::is_rvalue_reference_v<T>,
                                          std::remove_reference_t<U> &&, U &>;

template <typename T, typename U>
using copy_const_t =
    std::conditional_t<std::is_const_v<std::remove_reference_t<T>>, U const, U>;

template <typename T, typename U>
using forward_like_t =
    override_ref_t<T &&, copy_const_t<T, std::remove_reference_t<U>>>;
}  // namespace ForwardLikeHelper

template <typename T>
[[nodiscard]] constexpr auto forward_like(auto &&x) noexcept
    -> ForwardLikeHelper::forward_like_t<T, decltype(x)> {
  return static_cast<ForwardLikeHelper::forward_like_t<T, decltype(x)>>(x);
}
#endif

#if defined(__cpp_lib_is_scoped_enum)
// since C++23
using std::is_scoped_enum;
using std::is_scoped_enum_v;
#else
template <typename E, bool = std::is_enum_v<E>>
struct is_scoped_enum_impl : std::false_type {};

template <typename E>
struct is_scoped_enum_impl<E, true>
    : std::bool_constant<!std::is_convertible_v<E, std::underlying_type_t<E>>> {
};

template <typename E>
struct is_scoped_enum : is_scoped_enum_impl<E>::type {};

template <typename E>
inline constexpr bool is_scoped_enum_v = is_scoped_enum<E>::value;
#endif

//==============================================================================
// <editor-fold desc="is_specialization_of"> {{{1

template <class Type, template <class...> class Template, class Enable = void>
struct is_specialization_of : std::false_type {};

template <template <class...> class Template, class... Args>
struct is_specialization_of<Template<Args...>, Template> : std::true_type {};

template <typename T, template <typename...> class U>
inline constexpr bool is_specialization_of_v =
    is_specialization_of<T, U>::value;

// </editor-fold> end is_specialization_of }}}1
//==============================================================================

//==============================================================================
// <editor-fold desc="type_list"> {{{1

// An intentionally uninstantiateable type_list for metaprogramming purposes
template <class...>
struct type_list;

//------------------------------------------------------------------------------
// <editor-fold desc="type_list_remove_first"> {{{2

// Currently linear complexity; if we use this a lot, maybe make it better?

template <class Entry, class InList, class OutList>
struct _type_list_remove_first_impl;

template <class Entry, class T, class... Ts, class... OutTs>
struct _type_list_remove_first_impl<Entry, type_list<T, Ts...>,
                                    type_list<OutTs...>>
    : _type_list_remove_first_impl<Entry, type_list<Ts...>,
                                   type_list<OutTs..., T>> {};

template <class Entry, class... Ts, class... OutTs>
struct _type_list_remove_first_impl<Entry, type_list<Entry, Ts...>,
                                    type_list<OutTs...>>
    : _type_list_remove_first_impl<Entry, type_list<>,
                                   type_list<OutTs..., Ts...>> {};

template <class Entry, class... OutTs>
struct _type_list_remove_first_impl<Entry, type_list<>, type_list<OutTs...>>
    : std::type_identity<type_list<OutTs...>> {};

template <class Entry, class List>
struct type_list_remove_first
    : _type_list_remove_first_impl<Entry, List, type_list<>> {};

// </editor-fold> end type_list_remove_first }}}2
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// <editor-fold desc="type_list_any"> {{{2

template <template <class> class UnaryPred, class List>
struct type_list_any;

template <template <class> class UnaryPred, class... Ts>
struct type_list_any<UnaryPred, type_list<Ts...>>
    : std::bool_constant<(UnaryPred<Ts>::value || ...)> {};

template <template <class> class UnaryPred, class... Ts>
constexpr bool type_list_any_v = type_list_any<UnaryPred, Ts...>::value;

// </editor-fold> end type_list_any }}}2
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// <editor-fold desc="concat_type_list"> {{{2
//  concat_type_list combines types in multiple type_lists

// forward declaration
template <typename... T>
struct concat_type_list;

// alias
template <typename... T>
using concat_type_list_t = typename concat_type_list<T...>::type;

// final instantiation
template <typename... T>
struct concat_type_list<type_list<T...>> {
  using type = type_list<T...>;
};

// combine consecutive type_lists
template <typename... T, typename... U, typename... Tail>
struct concat_type_list<type_list<T...>, type_list<U...>, Tail...> {
  using type = concat_type_list_t<type_list<T..., U...>, Tail...>;
};
// </editor-fold> end concat_type_list }}}2
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// <editor-fold desc="filter_type_list"> {{{2
//  filter_type_list generates type-list of types which satisfy
//  PredicateT<T>::value == ValueT

template <template <typename> class PredicateT, typename TypeListT,
          bool ValueT = true>
struct filter_type_list;

template <template <typename> class PredicateT, typename... T, bool ValueT>
  requires(sizeof...(T) > 0)
struct filter_type_list<PredicateT, type_list<T...>, ValueT> {
  using type =
      concat_type_list_t<std::conditional_t<PredicateT<T>::value == ValueT,
                                            type_list<T>, type_list<>>...>;
};

template <template <typename> class PredicateT, bool ValueT>
struct filter_type_list<PredicateT, type_list<>, ValueT> {
  using type = type_list<>;
};

template <template <typename> class PredicateT, typename T, bool ValueT = true>
using filter_type_list_t =
    typename filter_type_list<PredicateT, T, ValueT>::type;

// </editor-fold> end filter_type_list }}}2
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// <editor-fold desc="type_list_contains"> {{{2
//  type_list_contains checks if a type is contained in the list.
template <typename, typename...>
struct type_list_contains;

template <typename U, typename... Ts>
struct type_list_contains<U, type_list<Ts...>>
    : std::disjunction<std::is_same<U, Ts>...> {};

template <typename U, typename... Ts>
constexpr bool type_list_contains_v = type_list_contains<U, Ts...>::value;
// </editor-fold> end type_list_contains }}}2
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// <editor-fold desc="type_list_size"> {{{2
//  type_list_size returns the size of a type list.
template <typename>
struct type_list_size;

template <typename... Ts>
struct type_list_size<type_list<Ts...>>
    : std::integral_constant<std::size_t, sizeof...(Ts)> {};

template <typename T>
constexpr std::size_t type_list_size_v = type_list_size<T>::value;
// </editor-fold> end type_list_size }}}2
//------------------------------------------------------------------------------

// </editor-fold> end type_list }}}1
//==============================================================================

//==============================================================================
// The weird !sizeof(F*) to express false is to make the
// expression dependent on the type of F, and thus only applicable
// at instantiation and not first-pass semantic analysis of the
// template definition.
template <typename T>
constexpr bool dependent_false_v = !sizeof(T*);
//==============================================================================

}  // namespace Impl
}  // namespace Kokkos

#endif  // KOKKOS_CORE_IMPL_UTILITIES_HPP
