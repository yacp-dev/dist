// Copyright (c) 2009-2010 Volvox Development Team
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
//
// Author: Konstantin Lepa <konstantin.lepa@gmail.com>

#ifndef VOLVOX_VXLOG_LOGGER_H_
#define VOLVOX_VXLOG_LOGGER_H_

#include <tr1/memory>
#include "vxlog/level.h"
#include "vxlog/outputter-holder.h"
#include "vxlog/format-string.h"
#include "vxlog/logger-macros.h"

#define VXLOG_DEFINE_MODULE(mod, modname) \
  struct mod { static const char * name() { return modname; } }

namespace vxlog {

template<typename ModuleT>
class Logger {
 public:
  VXLOG_INTERNAL_DEFINE_LEVEL(Fatal, vxlog::Level::kFatal)
  VXLOG_INTERNAL_DEFINE_LEVEL(Error, vxlog::Level::kError)
  VXLOG_INTERNAL_DEFINE_LEVEL(Warn,  vxlog::Level::kWarn)
  VXLOG_INTERNAL_DEFINE_LEVEL(Info,  vxlog::Level::kInfo)
  VXLOG_INTERNAL_DEFINE_LEVEL(Debug, vxlog::Level::kDebug)

  template<typename OutputterT>
  static void BindOutputter(Level::Type level,
                            std::tr1::shared_ptr<OutputterT> outputter) {
    OutputterHolder<ModuleT, Level::kDebug>::Reset();
    OutputterHolder<ModuleT, Level::kInfo>::Reset();
    OutputterHolder<ModuleT, Level::kWarn>::Reset();
    OutputterHolder<ModuleT, Level::kError>::Reset();
    OutputterHolder<ModuleT, Level::kFatal>::Reset();

    SharedOutputterPtr tmp(outputter);

    switch (level) {
      case Level::kDebug:
        OutputterHolder<ModuleT, Level::kDebug>::set_outputter(tmp);
      case Level::kInfo:
        OutputterHolder<ModuleT, Level::kInfo>::set_outputter(tmp);
      case Level::kWarn:
        OutputterHolder<ModuleT, Level::kWarn>::set_outputter(tmp);
      case Level::kError:
        OutputterHolder<ModuleT, Level::kError>::set_outputter(tmp);
      case Level::kFatal:
        OutputterHolder<ModuleT, Level::kFatal>::set_outputter(tmp);
      case Level::kNone:
      default:
        break;
    }
  }

};

}  // namespace vxlog

#endif  // VOLVOX_VXLOG_LOGGER_H_

