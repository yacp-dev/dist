// Copyright (c) 2009-2010 Volvox Development Team
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
//
// Author: Konstantin Lepa <konstantin.lepa@gmail.com>

#ifndef VOLVOX_VXLOG_LOG_MACROS_H_
#define VOLVOX_VXLOG_LOG_MACROS_H_

#define VXLOG_INTERNAL_TMPL_P_1  typename T1
#define VXLOG_INTERNAL_TMPL_P_2  VXLOG_INTERNAL_TMPL_P_1,  typename T2
#define VXLOG_INTERNAL_TMPL_P_3  VXLOG_INTERNAL_TMPL_P_2,  typename T3
#define VXLOG_INTERNAL_TMPL_P_4  VXLOG_INTERNAL_TMPL_P_3,  typename T4
#define VXLOG_INTERNAL_TMPL_P_5  VXLOG_INTERNAL_TMPL_P_4,  typename T5
#define VXLOG_INTERNAL_TMPL_P_6  VXLOG_INTERNAL_TMPL_P_5,  typename T6
#define VXLOG_INTERNAL_TMPL_P_7  VXLOG_INTERNAL_TMPL_P_6,  typename T7
#define VXLOG_INTERNAL_TMPL_P_8  VXLOG_INTERNAL_TMPL_P_7,  typename T8
#define VXLOG_INTERNAL_TMPL_P_9  VXLOG_INTERNAL_TMPL_P_8,  typename T9
#define VXLOG_INTERNAL_TMPL_P_10 VXLOG_INTERNAL_TMPL_P_9,  typename T10
#define VXLOG_INTERNAL_TMPL_P_11 VXLOG_INTERNAL_TMPL_P_10, typename T11
#define VXLOG_INTERNAL_TMPL_P_12 VXLOG_INTERNAL_TMPL_P_11, typename T12
#define VXLOG_INTERNAL_TMPL_P_13 VXLOG_INTERNAL_TMPL_P_12, typename T13
#define VXLOG_INTERNAL_TMPL_P_14 VXLOG_INTERNAL_TMPL_P_13, typename T14
#define VXLOG_INTERNAL_TMPL_P_15 VXLOG_INTERNAL_TMPL_P_14, typename T15

#define VXLOG_INTERNAL_FUNC_P_1  const T1  &t1
#define VXLOG_INTERNAL_FUNC_P_2  VXLOG_INTERNAL_FUNC_P_1,  const T2  &t2
#define VXLOG_INTERNAL_FUNC_P_3  VXLOG_INTERNAL_FUNC_P_2,  const T3  &t3
#define VXLOG_INTERNAL_FUNC_P_4  VXLOG_INTERNAL_FUNC_P_3,  const T4  &t4
#define VXLOG_INTERNAL_FUNC_P_5  VXLOG_INTERNAL_FUNC_P_4,  const T5  &t5
#define VXLOG_INTERNAL_FUNC_P_6  VXLOG_INTERNAL_FUNC_P_5,  const T6  &t6
#define VXLOG_INTERNAL_FUNC_P_7  VXLOG_INTERNAL_FUNC_P_6,  const T7  &t7
#define VXLOG_INTERNAL_FUNC_P_8  VXLOG_INTERNAL_FUNC_P_7,  const T8  &t8
#define VXLOG_INTERNAL_FUNC_P_9  VXLOG_INTERNAL_FUNC_P_8,  const T9  &t9
#define VXLOG_INTERNAL_FUNC_P_10 VXLOG_INTERNAL_FUNC_P_9,  const T10 &t10
#define VXLOG_INTERNAL_FUNC_P_11 VXLOG_INTERNAL_FUNC_P_10, const T11 &t11
#define VXLOG_INTERNAL_FUNC_P_12 VXLOG_INTERNAL_FUNC_P_11, const T12 &t12
#define VXLOG_INTERNAL_FUNC_P_13 VXLOG_INTERNAL_FUNC_P_12, const T13 &t13
#define VXLOG_INTERNAL_FUNC_P_14 VXLOG_INTERNAL_FUNC_P_13, const T14 &t14
#define VXLOG_INTERNAL_FUNC_P_15 VXLOG_INTERNAL_FUNC_P_14, const T15 &t15

#define VXLOG_INTERNAL_REPLACE_1  fs.Replace(t1)
#define VXLOG_INTERNAL_REPLACE_2  VXLOG_INTERNAL_REPLACE_1  && fs.Replace(t2)
#define VXLOG_INTERNAL_REPLACE_3  VXLOG_INTERNAL_REPLACE_2  && fs.Replace(t3)
#define VXLOG_INTERNAL_REPLACE_4  VXLOG_INTERNAL_REPLACE_3  && fs.Replace(t4)
#define VXLOG_INTERNAL_REPLACE_5  VXLOG_INTERNAL_REPLACE_4  && fs.Replace(t5)
#define VXLOG_INTERNAL_REPLACE_6  VXLOG_INTERNAL_REPLACE_5  && fs.Replace(t6)
#define VXLOG_INTERNAL_REPLACE_7  VXLOG_INTERNAL_REPLACE_6  && fs.Replace(t7)
#define VXLOG_INTERNAL_REPLACE_8  VXLOG_INTERNAL_REPLACE_7  && fs.Replace(t8)
#define VXLOG_INTERNAL_REPLACE_9  VXLOG_INTERNAL_REPLACE_8  && fs.Replace(t9)
#define VXLOG_INTERNAL_REPLACE_10 VXLOG_INTERNAL_REPLACE_9  && fs.Replace(t10)
#define VXLOG_INTERNAL_REPLACE_11 VXLOG_INTERNAL_REPLACE_10 && fs.Replace(t11)
#define VXLOG_INTERNAL_REPLACE_12 VXLOG_INTERNAL_REPLACE_11 && fs.Replace(t12)
#define VXLOG_INTERNAL_REPLACE_13 VXLOG_INTERNAL_REPLACE_12 && fs.Replace(t13)
#define VXLOG_INTERNAL_REPLACE_14 VXLOG_INTERNAL_REPLACE_13 && fs.Replace(t14)
#define VXLOG_INTERNAL_REPLACE_15 VXLOG_INTERNAL_REPLACE_14 && fs.Replace(t15)

#define VXLOG_INTERNAL_LEVEL_0(level_func, level)                       \
  static void level_func(const char *fmt) {                             \
    typedef vxlog::OutputterHolder<ModuleT, level> OutputterHolder;     \
    if (OutputterHolder::has_empty_outputter()) return;                 \
                                                                        \
    OutputterHolder::Print(fmt);                                        \
  }

#define VXLOG_INTERNAL_LEVEL_P(level_func, level, amount)               \
  template<VXLOG_INTERNAL_TMPL_P_ ## amount>                            \
  static void level_func(const char *fmt,                               \
                  VXLOG_INTERNAL_FUNC_P_ ## amount) {                   \
    typedef vxlog::OutputterHolder<ModuleT, level> OutputterHolder;     \
    if (OutputterHolder::has_empty_outputter()) return;                 \
                                                                        \
    vxlog::FormatString fs;                                             \
    fs.Init(fmt);                                                       \
    VXLOG_INTERNAL_REPLACE_ ## amount;                                  \
                                                                        \
    OutputterHolder::Print(fs.GetResult());                             \
  }

#define VXLOG_INTERNAL_DEFINE_LEVEL(level_func, level)  \
  VXLOG_INTERNAL_LEVEL_0(level_func, level)             \
  VXLOG_INTERNAL_LEVEL_P(level_func, level, 1)          \
  VXLOG_INTERNAL_LEVEL_P(level_func, level, 2)          \
  VXLOG_INTERNAL_LEVEL_P(level_func, level, 3)          \
  VXLOG_INTERNAL_LEVEL_P(level_func, level, 4)          \
  VXLOG_INTERNAL_LEVEL_P(level_func, level, 5)          \
  VXLOG_INTERNAL_LEVEL_P(level_func, level, 6)          \
  VXLOG_INTERNAL_LEVEL_P(level_func, level, 7)          \
  VXLOG_INTERNAL_LEVEL_P(level_func, level, 8)          \
  VXLOG_INTERNAL_LEVEL_P(level_func, level, 9)          \
  VXLOG_INTERNAL_LEVEL_P(level_func, level, 10)         \
  VXLOG_INTERNAL_LEVEL_P(level_func, level, 11)         \
  VXLOG_INTERNAL_LEVEL_P(level_func, level, 12)         \
  VXLOG_INTERNAL_LEVEL_P(level_func, level, 13)         \
  VXLOG_INTERNAL_LEVEL_P(level_func, level, 14)         \
  VXLOG_INTERNAL_LEVEL_P(level_func, level, 15)

#endif   // VOLVOX_VXLOG_LOG_MACROS_H_
