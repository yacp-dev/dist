// Copyright (c) 2009-2010 Volvox Development Team
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
//
// Author: Konstantin Lepa <konstantin.lepa@gmail.com>

#ifndef VOLVOX_VXLOG_FILE_OUTPUTTER_H_
#define VOLVOX_VXLOG_FILE_OUTPUTTER_H_

#include <stdio.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <fcntl.h>
#include <limits.h>
#include <string>
#include <stdexcept>
#include "vxlog/outputter-interface.h"
#include "vxlog/macros.h"

namespace vxlog {

class FileOutputter : public OutputterInterface {
 public:
  FileOutputter(const std::string &filename, bool appended, mode_t perm) :
      fd_(-1),
      flags_(O_WRONLY | O_CREAT | O_SYNC),
      appended_(appended),
      permissions_(perm),
      filename_(filename) {
    flags_ |= (appended_) ? O_APPEND : O_TRUNC;
    fd_ = open(filename_.c_str(), flags_, permissions_);

    if (fd_ == -1) {
      std::string msg =
          "Failed to open the " + filename_ + " file: " + strerror(errno);
      throw std::runtime_error(msg);
    }
  }

  ~FileOutputter() { close(fd_); }

  void Print(Level::Type level, const char *modname, const char *str);
  void Flush() { fsync(fd_); }

  void Reopen() {
    if (close(fd_) == -1) {
      std::string msg =
          "Failed to close the " + filename_ + " file: " + strerror(errno);
      throw std::runtime_error(msg);
    }
    fd_ = open(filename_.c_str(), flags_, permissions_);
    if (fd_ == -1) {
      std::string msg =
          "Failed to open the " + filename_ + " file: " + strerror(errno);
      throw std::runtime_error(msg);
    }
  }

 private:
  static const char *const kLevelNames[Level::kSummary];

  int  fd_;
  int  flags_;
  bool appended_;

  mode_t      permissions_;
  std::string filename_;

  VXLOG_DISALLOW_COPY_AND_ASSIGN(FileOutputter);
};

typedef std::tr1::shared_ptr<FileOutputter> FileOutputterPtr;

}  // namespace vxlog

#endif  // VOLVOX_VXLOG_FILE_OUTPUTTER_H_

