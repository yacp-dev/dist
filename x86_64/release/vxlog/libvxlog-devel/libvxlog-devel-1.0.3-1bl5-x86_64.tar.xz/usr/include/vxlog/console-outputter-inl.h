// Copyright (c) 2009-2010 Volvox Development Team
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
//
// Author: Konstantin Lepa <konstantin.lepa@gmail.com>

#ifndef VOLVOX_VXLOG_CONSOLE_OUTPUTTER_INL_H_
#define VOLVOX_VXLOG_CONSOLE_OUTPUTTER_INL_H_

#include <assert.h>
#include <stdio.h>
#include <limits.h>
#include <unistd.h>

namespace vxlog {

inline
void ConsoleOutputter::Print(Level::Type level,
                             const char *modname, const char *str) {
  const int kMaxSize = PIPE_BUF - 1;
  char buf[kMaxSize] = { '\0' };

  ssize_t written = snprintf(buf, kMaxSize, "%s <%s> %s",
                             kLevelNames[level], modname, str);
  buf[written] = '\n';
  written = write(STDERR_FILENO, buf, written + 1);
  assert(written != -1);
}

}  // namespace vxlog

#endif  // VOLVOX_VXLOG_CONSOLE_OUTPUTTER_INL_H_

