// Copyright (c) 2009-2010 Volvox Development Team
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
//
// Author: Konstantin Lepa <konstantin.lepa@gmail.com>

#ifndef VOLVOX_VXLOG_OUTPUTTER_HOLDER_H_
#define VOLVOX_VXLOG_OUTPUTTER_HOLDER_H_

#include "vxlog/level.h"
#include "vxlog/outputter-interface.h"
#include "vxlog/console-outputter.h"

namespace vxlog {

template<typename ModuleT, Level::Type level>
class OutputterHolder {
 public:
  static void Print(const char *str) {
    outputter_->Print(level, ModuleT::name(), str);
  }

  static void set_outputter(SharedOutputterPtr outputter) {
    outputter_ = outputter;
  }

  static void Reset() { outputter_ = SharedOutputterPtr(); }

  static bool has_empty_outputter() {
    return outputter_ == SharedOutputterPtr();
  }

 private:
  static SharedOutputterPtr outputter_;
};

template<typename ModuleT, Level::Type level>
SharedOutputterPtr OutputterHolder<ModuleT, level>::outputter_ =
    SharedOutputterPtr(new ConsoleOutputter());

}  // namespace vxlog

#endif  // VOLVOX_VXLOG_OUTPUTTER_HOLDER_H_

