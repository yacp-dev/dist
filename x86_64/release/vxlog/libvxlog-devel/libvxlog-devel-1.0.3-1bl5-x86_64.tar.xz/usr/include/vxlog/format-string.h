// Copyright (c) 2009-2010 Volvox Development Team
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
//
// Author: Konstantin Lepa <konstantin.lepa@gmail.com>

#ifndef VOLVOX_VXLOG_FORMAT_STRING_H_
#define VOLVOX_VXLOG_FORMAT_STRING_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <algorithm>
#include <string>
#include "vxlog/macros.h"
#include "vxlog/type-to-string.h"

namespace vxlog {

// Expands place holders ("%_") into variables
class FormatString {
 public:
  static const size_t kMaxBuf = PIPE_BUF - 100;

  FormatString() : s_idx_(0), d_idx_(0) {}

  bool Replace(const char *value) {
    return ReplaceHolder(value);
  }

  bool Replace(char *value) {
    return ReplaceHolder(value);
  }

  bool Replace(const std::string &value) {
    return ReplaceHolder(value.c_str());
  }

  bool Replace(char value) {
    char str[2] = { '\0' };
    str[0] = value;
    return ReplaceHolder(str);
  }

  template<typename T>
  bool Replace(const T &value) {
    char buf[TypeStringSize<T>::kValue] = { '\0' };

    if (TypeToString(value, buf, TypeStringSize<T>::kValue)) {
      return ReplaceHolder(buf);
    }
    return false;
  }

  void Init(const char *fmt_string) {
    const size_t len = std::min(strlen(fmt_string) + 1, kMaxBuf);
    ::strncpy(src_, fmt_string, len);
    src_[len - 1] = '\0';
    s_idx_ = d_idx_ = 0;
  }

  const char * GetResult() {
    const size_t len = std::min(strlen(src_ + s_idx_) + 1, kMaxBuf - d_idx_);
    if (src_[s_idx_] != '\0') ::strncpy(dst_ + d_idx_, src_ + s_idx_, len);
    dst_[d_idx_ + len - 1] = '\0';
    return dst_;
  }

 private:
  bool NextHolder() {
    for (; src_[s_idx_] != '\0' && d_idx_ < kMaxBuf - 1; ++s_idx_, ++d_idx_) {
      if (src_[s_idx_] == '%' && src_[s_idx_ + 1] == '_') {
        s_idx_ += 2;
        return true;
      }
      dst_[d_idx_] = src_[s_idx_];
    }
    return false;
  }

  bool ReplaceHolder(const char *value) {
    if (!NextHolder()) return false;

    const size_t len = std::min(strlen(value) + 1, kMaxBuf - d_idx_);
    ::strncpy(dst_ + d_idx_, value, len);
    d_idx_ += len - 1;
    dst_[d_idx_] = '\0';
    return true;
  }

  char src_[kMaxBuf];
  char dst_[kMaxBuf];
  uint32_t s_idx_;
  uint32_t d_idx_;

  VXLOG_DISALLOW_COPY_AND_ASSIGN(FormatString);
};

}  // namespace vxlog

#endif  // VOLVOX_VXLOG_FORMAT_STRING_H_

