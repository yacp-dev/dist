// Copyright (c) 2009-2010 Volvox Development Team
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
//
// Author: Konstantin Lepa <konstantin.lepa@gmail.com>

#ifndef VOLVOX_VXLOG_TYPE_TO_STRING_H_
#define VOLVOX_VXLOG_TYPE_TO_STRING_H_

#define __STDC_FORMAT_MACROS

#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <limits>
#include <string>

namespace vxlog {

template<typename T>
struct TypeStringSize {
 public:
  static const size_t kValue = std::numeric_limits<T>::digits10
        + 1   // for '\0'
        + 1   // for a sign
        + 1;  // just in case
};

template<typename T>
struct TypeStringSize<T *> {
 public:
  static const size_t kValue = std::numeric_limits<uint64_t>::digits10
      + 1   // for '\0'
      + 2;  // for "0x" pointer prefix
};

template<>
struct TypeStringSize<bool> {
 public:
  static const size_t kValue = 5 // for max(strlen("true"), strlen("false")
      + 1;  // for '\0'
};

template<bool>
class SignChecker {
 public:
  template<typename T>
  static bool NumberToString(const T &value, char *str, size_t len) {
    int res = snprintf(str, len, "%"PRId64, static_cast<int64_t>(value));
    if ((res < 0) || (static_cast<size_t>(res) == len)) return false;
    return true;
  }
};

template<>
class SignChecker<false> {
 public:
  template<typename T>
  static bool NumberToString(const T &value, char *str, size_t len) {
    int res = snprintf(str, len, "%"PRIu64, static_cast<uint64_t>(value));
    if ((res < 0) || (static_cast<size_t>(res) == len)) return false;
    return true;
  }
};

template<typename T>
class PtrChecker {
 public:
  static bool NumberToString(const T &value, char *str, size_t len) {
    typedef SignChecker<std::numeric_limits<T>::is_signed> SignChecker;
    return SignChecker::NumberToString(value, str, len);
  }
};

template<typename T>
class PtrChecker<T *> {
 public:
  static bool NumberToString(const T *value, char *str, size_t len) {
    int res = snprintf(str, len, "%p", reinterpret_cast<const void *>(value));
    if ((res < 0) || (static_cast<size_t>(res) == len)) { return false; }
    return true;
  }
};

template<typename T>
bool TypeToString(const T &value, char *str, size_t len) {
  return PtrChecker<T>::NumberToString(value, str, len);
}

template<>
bool TypeToString<double>(const double &value, char *str, size_t len);

template<>
bool TypeToString<bool>(const bool &value, char *str, size_t len);

}  // namespace vxlog

#endif  // VOLVOX_VXLOG_TYPE_TO_STRING_H_

