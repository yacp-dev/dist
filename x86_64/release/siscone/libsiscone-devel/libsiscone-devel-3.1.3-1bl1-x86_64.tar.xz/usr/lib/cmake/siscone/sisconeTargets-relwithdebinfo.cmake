#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "siscone::siscone" for configuration "RelWithDebInfo"
set_property(TARGET siscone::siscone APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(siscone::siscone PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libsiscone.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygsiscone-0.dll"
  )

list(APPEND _cmake_import_check_targets siscone::siscone )
list(APPEND _cmake_import_check_files_for_siscone::siscone "${_IMPORT_PREFIX}/lib/libsiscone.dll.a" "${_IMPORT_PREFIX}/bin/cygsiscone-0.dll" )

# Import target "siscone::siscone_spherical" for configuration "RelWithDebInfo"
set_property(TARGET siscone::siscone_spherical APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(siscone::siscone_spherical PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libsiscone_spherical.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygsiscone_spherical-0.dll"
  )

list(APPEND _cmake_import_check_targets siscone::siscone_spherical )
list(APPEND _cmake_import_check_files_for_siscone::siscone_spherical "${_IMPORT_PREFIX}/lib/libsiscone_spherical.dll.a" "${_IMPORT_PREFIX}/bin/cygsiscone_spherical-0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
