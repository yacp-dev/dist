#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "reproc++" for configuration "RelWithDebInfo"
set_property(TARGET reproc++ APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(reproc++ PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libreproc++.dll.a"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELWITHDEBINFO "reproc"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygreproc++-14.dll"
  )

list(APPEND _cmake_import_check_targets reproc++ )
list(APPEND _cmake_import_check_files_for_reproc++ "${_IMPORT_PREFIX}/lib/libreproc++.dll.a" "${_IMPORT_PREFIX}/bin/cygreproc++-14.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
