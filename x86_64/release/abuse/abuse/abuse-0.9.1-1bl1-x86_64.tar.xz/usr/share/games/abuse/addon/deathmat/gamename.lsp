(setq gamename "EvilWumpus")
