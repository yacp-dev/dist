#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Wt::DboPostgres" for configuration "RelWithDebInfo"
set_property(TARGET Wt::DboPostgres APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(Wt::DboPostgres PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libwtdbopostgres.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygwtdbopostgres-4.dll"
  )

list(APPEND _cmake_import_check_targets Wt::DboPostgres )
list(APPEND _cmake_import_check_files_for_Wt::DboPostgres "${_IMPORT_PREFIX}/lib/libwtdbopostgres.dll.a" "${_IMPORT_PREFIX}/bin/cygwtdbopostgres-4.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
