#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Wt::DboMySQL" for configuration "RelWithDebInfo"
set_property(TARGET Wt::DboMySQL APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(Wt::DboMySQL PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libwtdbomysql.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygwtdbomysql-4.dll"
  )

list(APPEND _cmake_import_check_targets Wt::DboMySQL )
list(APPEND _cmake_import_check_files_for_Wt::DboMySQL "${_IMPORT_PREFIX}/lib/libwtdbomysql.dll.a" "${_IMPORT_PREFIX}/bin/cygwtdbomysql-4.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
