if [ -f /etc/wt/wt_config.xml ] && cmp -s /etc/defaults/etc/wt/wt_config.xml /etc/wt/wt_config.xml
then
    rm /etc/wt/wt_config.xml
fi

