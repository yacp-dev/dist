if [ ! -e /etc/wt/wt_config.xml ]
then
    /usr/bin/mkdir -p /etc/wt
    /usr/bin/cp /etc/defaults/etc/wt/wt_config.xml /etc/wt/wt_config.xml
fi

