# **_`libloc`_** - IP Address Location

[Home](https://www.ipfire.org/location)

`libloc` is a library for fast and efficient IP address location.

It offers:

- **The Fastest Lookups**: O(1) lookup time for IP addresses using a binary tree structure.
- **Low Memory Footprint**: The database is packed in a very efficient format.
- **Security**: Integrated signature verification for data integrity.
- **Maintainability**: Automatic updates.
- **Standalone**: No external dependencies, easy to integrate.

`libloc` is ideal for:

- Firewalls
- Intrusion Prevention/Detection Systems (IPS/IDS)
- Web Applications
- Network Management Tools

The publicly available daily updated database stores information about:

- The entire IPv6 and IPv4 Internet
- Autonomous System Information including names
- Country Codes, Names and Continent Codes

## Command Line

`libloc` comes with a command line tool which makes it easy to test the library or
integrate it into your shell scripts. location(8) knows a couple of commands to retrieve
country or Autonomous System of an IP address and can generate lists of networks to be
imported into other software.

`location (8)` is versatile and very easy to use.

## Language Bindings

`libloc` itself is written in C. There are bindings for the following languages available:

- Python 3
- Lua
- Perl

`libloc` comes with native Python bindings which are used by its main command-line tool
location. They are the most advanced bindings as they support reading from the database
as well as writing to it.

## Packages

Packages for Debian are being built for every change and are available from
<https://repo.ipfire.org/debian/libloc/>. There are two repositories:

- `stable` only has releases
- `master` has what is in the master branch of the Git repository

They have packages for all architectures of each release of Debian that we are
able to build for:

| Release  | Architectures                                               |
|----------|-------------------------------------------------------------|
| sid      | amd64, arm64, armhf, i386, loong64, ppc64el, riscv64, s390x |
| forky    | amd64, arm64, armhf, i386, loong64, ppc64el, riscv64, s390x |
| trixie   | amd64, arm64, armel, armhf, i386, ppc64el, riscv64, s390x   |
| bookworm | amd64, arm64, armhf, i386, ppc64el                          |

To use one of them, download the key:

    curl -o /usr/share/keyrings/libloc.asc \
        https://repo.ipfire.org/debian/libloc/stable/E4D20FA6FAA108D54ABDFC6541836ADF9D5E2AD9.asc

And create `/etc/apt/sources.list.d/libloc.list`:

    deb [signed-by=/usr/share/keyrings/libloc.asc] https://repo.ipfire.org/debian/libloc/stable trixie main

Packages for Arch Linux (x86_64) are available from
<https://repo.ipfire.org/archlinux/libloc/>, with the same two repositories.
They are split in the same way as the packages in Arch Linux, which they replace.
To use one of them, import and trust the key:

    curl -O https://repo.ipfire.org/archlinux/libloc/stable/04366A42320C4376B1C77B1711FE8DB66A724099.asc
    pacman-key --add 04366A42320C4376B1C77B1711FE8DB66A724099.asc
    pacman-key --lsign-key 04366A42320C4376B1C77B1711FE8DB66A724099

And add this to `/etc/pacman.conf`, above the other repositories:

    [libloc]
    Server = https://repo.ipfire.org/archlinux/libloc/stable/$arch

RPM packages (x86_64) are available for Fedora, for RHEL and its clones, and for
openSUSE, with the same two repositories, and a directory for each release in them:

| Distribution           | Repository                                              |
|------------------------|---------------------------------------------------------|
| Fedora 45              | <https://repo.ipfire.org/fedora/libloc/stable/45/>      |
| Fedora 44              | <https://repo.ipfire.org/fedora/libloc/stable/44/>      |
| RHEL 10 and its clones | <https://repo.ipfire.org/el/libloc/stable/10/>          |
| RHEL 9 and its clones  | <https://repo.ipfire.org/el/libloc/stable/9/>           |
| openSUSE Tumbleweed    | <https://repo.ipfire.org/opensuse/libloc/stable/tumbleweed/> |
| openSUSE Leap 16.0     | <https://repo.ipfire.org/opensuse/libloc/stable/16.0/>  |

They are split in the same way as the packages in Fedora, which they replace.
Fedora, RHEL and openSUSE each have their own key, which is in every directory.
To use them on Fedora, create `/etc/yum.repos.d/libloc.repo` (and replace
`fedora` with `el` on RHEL):

    [libloc]
    name=libloc
    baseurl=https://repo.ipfire.org/fedora/libloc/stable/$releasever/
    gpgcheck=1
    repo_gpgcheck=1
    gpgkey=https://repo.ipfire.org/fedora/libloc/stable/$releasever/RPM-GPG-KEY-libloc

On openSUSE Tumbleweed, import the key and add the repository:

    rpm --import https://repo.ipfire.org/opensuse/libloc/stable/tumbleweed/RPM-GPG-KEY-libloc
    zypper addrepo --gpgcheck-strict https://repo.ipfire.org/opensuse/libloc/stable/tumbleweed/ libloc

On openSUSE Leap, zypper replaces `$releasever` (which is why it is in single quotes):

    rpm --import https://repo.ipfire.org/opensuse/libloc/stable/16.0/RPM-GPG-KEY-libloc
    zypper addrepo --gpgcheck-strict 'https://repo.ipfire.org/opensuse/libloc/stable/$releasever/' libloc

## Building

To build `libloc` from the Git repository you will need a C compiler, `autoconf`,
`automake`, `libtool`, `pkg-config`, `intltool` (and `autopoint` from gettext), and
the development files for OpenSSL, Python 3, Lua and Perl. `asciidoc` and `xsltproc`
are required for the man pages, `luaunit` for the tests of the Lua module, and
the development files of systemd if the database should be updated by a timer
instead of a cron job.

On Debian, that is:

    apt-get install build-essential autoconf automake autopoint intltool libtool \
        pkg-config asciidoc xsltproc docbook-xsl liblua5.4-dev libperl-dev \
        libpython3-dev libssl-dev libsystemd-dev lua-unit

Then run:

    ./autogen.sh
    ./configure --prefix=/usr
    make
    make check
    make install

`./configure --help` lists everything that can be switched on and off. The bindings
for Lua and Perl and the man pages can be disabled with `--disable-lua`,
`--disable-perl` and `--disable-man-pages`.

### Testing

`make check` runs the test suite for the library and all bindings. On top of that:

- `./configure --enable-asan --enable-ubsan` builds everything with the address and
  undefined behavior sanitizers, which make `make check` fail on invalid memory
  accesses, leaks and undefined behavior.
- `make check-valgrind` runs the tests that are written in C in valgrind.
- `CC=clang ./configure --enable-asan --enable-fuzzing` builds the fuzzers, which are
  being run by `make fuzz` (for `FUZZ_TIME` seconds each, 60 by default). Anything
  that makes them fail is stored in `tests/fuzz/crashes`.
- `./configure --enable-coverage` builds everything with `--coverage`, so that
  `lcov` can create a report after the tests have been run.
- `make distcheck` checks that the tarball has everything it needs and that it
  can be built outside of the source tree.
