#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "VowpalWabbit::vw_active_interactor_bin" for configuration "RelWithDebInfo"
set_property(TARGET VowpalWabbit::vw_active_interactor_bin APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(VowpalWabbit::vw_active_interactor_bin PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/active_interactor.exe"
  )

list(APPEND _cmake_import_check_targets VowpalWabbit::vw_active_interactor_bin )
list(APPEND _cmake_import_check_files_for_VowpalWabbit::vw_active_interactor_bin "${_IMPORT_PREFIX}/bin/active_interactor.exe" )

# Import target "VowpalWabbit::vw_cli_bin" for configuration "RelWithDebInfo"
set_property(TARGET VowpalWabbit::vw_cli_bin APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(VowpalWabbit::vw_cli_bin PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/vw.exe"
  )

list(APPEND _cmake_import_check_targets VowpalWabbit::vw_cli_bin )
list(APPEND _cmake_import_check_files_for_VowpalWabbit::vw_cli_bin "${_IMPORT_PREFIX}/bin/vw.exe" )

# Import target "VowpalWabbit::vw_allreduce" for configuration "RelWithDebInfo"
set_property(TARGET VowpalWabbit::vw_allreduce APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(VowpalWabbit::vw_allreduce PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELWITHDEBINFO "CXX"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libvw_allreduce.a"
  )

list(APPEND _cmake_import_check_targets VowpalWabbit::vw_allreduce )
list(APPEND _cmake_import_check_files_for_VowpalWabbit::vw_allreduce "${_IMPORT_PREFIX}/lib/libvw_allreduce.a" )

# Import target "VowpalWabbit::vw_c_wrapper" for configuration "RelWithDebInfo"
set_property(TARGET VowpalWabbit::vw_c_wrapper APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(VowpalWabbit::vw_c_wrapper PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libvw_c_wrapper.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygvw_c_wrapper.dll"
  )

list(APPEND _cmake_import_check_targets VowpalWabbit::vw_c_wrapper )
list(APPEND _cmake_import_check_files_for_VowpalWabbit::vw_c_wrapper "${_IMPORT_PREFIX}/lib/libvw_c_wrapper.dll.a" "${_IMPORT_PREFIX}/bin/cygvw_c_wrapper.dll" )

# Import target "VowpalWabbit::vw_cache_parser" for configuration "RelWithDebInfo"
set_property(TARGET VowpalWabbit::vw_cache_parser APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(VowpalWabbit::vw_cache_parser PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELWITHDEBINFO "CXX"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libvw_cache_parser.a"
  )

list(APPEND _cmake_import_check_targets VowpalWabbit::vw_cache_parser )
list(APPEND _cmake_import_check_files_for_VowpalWabbit::vw_cache_parser "${_IMPORT_PREFIX}/lib/libvw_cache_parser.a" )

# Import target "VowpalWabbit::vw_config" for configuration "RelWithDebInfo"
set_property(TARGET VowpalWabbit::vw_config APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(VowpalWabbit::vw_config PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELWITHDEBINFO "CXX"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libvw_config.a"
  )

list(APPEND _cmake_import_check_targets VowpalWabbit::vw_config )
list(APPEND _cmake_import_check_files_for_VowpalWabbit::vw_config "${_IMPORT_PREFIX}/lib/libvw_config.a" )

# Import target "VowpalWabbit::vw_core" for configuration "RelWithDebInfo"
set_property(TARGET VowpalWabbit::vw_core APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(VowpalWabbit::vw_core PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELWITHDEBINFO "CXX"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libvw_core.a"
  )

list(APPEND _cmake_import_check_targets VowpalWabbit::vw_core )
list(APPEND _cmake_import_check_files_for_VowpalWabbit::vw_core "${_IMPORT_PREFIX}/lib/libvw_core.a" )

# Import target "VowpalWabbit::vw_io" for configuration "RelWithDebInfo"
set_property(TARGET VowpalWabbit::vw_io APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(VowpalWabbit::vw_io PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELWITHDEBINFO "CXX"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libvw_io.a"
  )

list(APPEND _cmake_import_check_targets VowpalWabbit::vw_io )
list(APPEND _cmake_import_check_files_for_VowpalWabbit::vw_io "${_IMPORT_PREFIX}/lib/libvw_io.a" )

# Import target "VowpalWabbit::vw_json_parser" for configuration "RelWithDebInfo"
set_property(TARGET VowpalWabbit::vw_json_parser APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(VowpalWabbit::vw_json_parser PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELWITHDEBINFO "CXX"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libvw_json_parser.a"
  )

list(APPEND _cmake_import_check_targets VowpalWabbit::vw_json_parser )
list(APPEND _cmake_import_check_files_for_VowpalWabbit::vw_json_parser "${_IMPORT_PREFIX}/lib/libvw_json_parser.a" )

# Import target "VowpalWabbit::vw_spanning_tree_bin" for configuration "RelWithDebInfo"
set_property(TARGET VowpalWabbit::vw_spanning_tree_bin APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(VowpalWabbit::vw_spanning_tree_bin PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/spanning_tree.exe"
  )

list(APPEND _cmake_import_check_targets VowpalWabbit::vw_spanning_tree_bin )
list(APPEND _cmake_import_check_files_for_VowpalWabbit::vw_spanning_tree_bin "${_IMPORT_PREFIX}/bin/spanning_tree.exe" )

# Import target "VowpalWabbit::vw_spanning_tree" for configuration "RelWithDebInfo"
set_property(TARGET VowpalWabbit::vw_spanning_tree APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(VowpalWabbit::vw_spanning_tree PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELWITHDEBINFO "CXX"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libvw_spanning_tree.a"
  )

list(APPEND _cmake_import_check_targets VowpalWabbit::vw_spanning_tree )
list(APPEND _cmake_import_check_files_for_VowpalWabbit::vw_spanning_tree "${_IMPORT_PREFIX}/lib/libvw_spanning_tree.a" )

# Import target "VowpalWabbit::vw_text_parser" for configuration "RelWithDebInfo"
set_property(TARGET VowpalWabbit::vw_text_parser APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(VowpalWabbit::vw_text_parser PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELWITHDEBINFO "CXX"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libvw_text_parser.a"
  )

list(APPEND _cmake_import_check_targets VowpalWabbit::vw_text_parser )
list(APPEND _cmake_import_check_files_for_VowpalWabbit::vw_text_parser "${_IMPORT_PREFIX}/lib/libvw_text_parser.a" )

# Import target "VowpalWabbit::vw_fb_parser" for configuration "RelWithDebInfo"
set_property(TARGET VowpalWabbit::vw_fb_parser APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(VowpalWabbit::vw_fb_parser PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELWITHDEBINFO "CXX"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libvw_fb_parser.a"
  )

list(APPEND _cmake_import_check_targets VowpalWabbit::vw_fb_parser )
list(APPEND _cmake_import_check_files_for_VowpalWabbit::vw_fb_parser "${_IMPORT_PREFIX}/lib/libvw_fb_parser.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
