#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "SCOTCH::ptscotchparmetisv3" for configuration "RelWithDebInfo"
set_property(TARGET SCOTCH::ptscotchparmetisv3 APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(SCOTCH::ptscotchparmetisv3 PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libptscotchparmetisv3.dll.a"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELWITHDEBINFO "SCOTCH::scotch;SCOTCH::ptscotch;SCOTCH::ptscotcherr"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygptscotchparmetisv3-7.0.dll"
  )

list(APPEND _cmake_import_check_targets SCOTCH::ptscotchparmetisv3 )
list(APPEND _cmake_import_check_files_for_SCOTCH::ptscotchparmetisv3 "${_IMPORT_PREFIX}/lib/libptscotchparmetisv3.dll.a" "${_IMPORT_PREFIX}/bin/cygptscotchparmetisv3-7.0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
