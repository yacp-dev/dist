#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "SCOTCH::ptscotcherr" for configuration "RelWithDebInfo"
set_property(TARGET SCOTCH::ptscotcherr APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(SCOTCH::ptscotcherr PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libptscotcherr.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygptscotcherr-7.0.dll"
  )

list(APPEND _cmake_import_check_targets SCOTCH::ptscotcherr )
list(APPEND _cmake_import_check_files_for_SCOTCH::ptscotcherr "${_IMPORT_PREFIX}/lib/libptscotcherr.dll.a" "${_IMPORT_PREFIX}/bin/cygptscotcherr-7.0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
