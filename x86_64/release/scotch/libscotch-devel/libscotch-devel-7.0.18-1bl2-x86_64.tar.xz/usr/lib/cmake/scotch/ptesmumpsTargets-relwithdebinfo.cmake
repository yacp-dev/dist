#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "SCOTCH::ptesmumps" for configuration "RelWithDebInfo"
set_property(TARGET SCOTCH::ptesmumps APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(SCOTCH::ptesmumps PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libptesmumps.dll.a"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELWITHDEBINFO "SCOTCH::ptscotch;SCOTCH::ptscotcherr"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygptesmumps-7.0.dll"
  )

list(APPEND _cmake_import_check_targets SCOTCH::ptesmumps )
list(APPEND _cmake_import_check_files_for_SCOTCH::ptesmumps "${_IMPORT_PREFIX}/lib/libptesmumps.dll.a" "${_IMPORT_PREFIX}/bin/cygptesmumps-7.0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
