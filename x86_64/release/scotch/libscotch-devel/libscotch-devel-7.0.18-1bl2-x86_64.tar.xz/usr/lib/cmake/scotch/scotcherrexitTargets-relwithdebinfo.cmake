#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "SCOTCH::scotcherrexit" for configuration "RelWithDebInfo"
set_property(TARGET SCOTCH::scotcherrexit APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(SCOTCH::scotcherrexit PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libscotcherrexit.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygscotcherrexit-7.0.dll"
  )

list(APPEND _cmake_import_check_targets SCOTCH::scotcherrexit )
list(APPEND _cmake_import_check_files_for_SCOTCH::scotcherrexit "${_IMPORT_PREFIX}/lib/libscotcherrexit.dll.a" "${_IMPORT_PREFIX}/bin/cygscotcherrexit-7.0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
