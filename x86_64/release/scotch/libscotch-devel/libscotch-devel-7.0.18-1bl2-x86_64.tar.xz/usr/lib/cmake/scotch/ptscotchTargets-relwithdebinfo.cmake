#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "SCOTCH::ptscotch" for configuration "RelWithDebInfo"
set_property(TARGET SCOTCH::ptscotch APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(SCOTCH::ptscotch PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libptscotch.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygptscotch-7.0.dll"
  )

list(APPEND _cmake_import_check_targets SCOTCH::ptscotch )
list(APPEND _cmake_import_check_files_for_SCOTCH::ptscotch "${_IMPORT_PREFIX}/lib/libptscotch.dll.a" "${_IMPORT_PREFIX}/bin/cygptscotch-7.0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
