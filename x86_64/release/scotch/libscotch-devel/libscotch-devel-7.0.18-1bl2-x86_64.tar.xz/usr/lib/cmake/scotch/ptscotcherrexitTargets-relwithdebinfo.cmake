#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "SCOTCH::ptscotcherrexit" for configuration "RelWithDebInfo"
set_property(TARGET SCOTCH::ptscotcherrexit APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(SCOTCH::ptscotcherrexit PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libptscotcherrexit.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygptscotcherrexit-7.0.dll"
  )

list(APPEND _cmake_import_check_targets SCOTCH::ptscotcherrexit )
list(APPEND _cmake_import_check_files_for_SCOTCH::ptscotcherrexit "${_IMPORT_PREFIX}/lib/libptscotcherrexit.dll.a" "${_IMPORT_PREFIX}/bin/cygptscotcherrexit-7.0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
