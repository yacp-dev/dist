#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "SCOTCH::scotchmetisv3" for configuration "RelWithDebInfo"
set_property(TARGET SCOTCH::scotchmetisv3 APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(SCOTCH::scotchmetisv3 PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libscotchmetisv3.dll.a"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELWITHDEBINFO "SCOTCH::scotch;SCOTCH::scotcherr"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygscotchmetisv3-7.0.dll"
  )

list(APPEND _cmake_import_check_targets SCOTCH::scotchmetisv3 )
list(APPEND _cmake_import_check_files_for_SCOTCH::scotchmetisv3 "${_IMPORT_PREFIX}/lib/libscotchmetisv3.dll.a" "${_IMPORT_PREFIX}/bin/cygscotchmetisv3-7.0.dll" )

# Import target "SCOTCH::scotchmetisv5" for configuration "RelWithDebInfo"
set_property(TARGET SCOTCH::scotchmetisv5 APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(SCOTCH::scotchmetisv5 PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libscotchmetisv5.dll.a"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELWITHDEBINFO "SCOTCH::scotch;SCOTCH::scotcherr"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygscotchmetisv5-7.0.dll"
  )

list(APPEND _cmake_import_check_targets SCOTCH::scotchmetisv5 )
list(APPEND _cmake_import_check_files_for_SCOTCH::scotchmetisv5 "${_IMPORT_PREFIX}/lib/libscotchmetisv5.dll.a" "${_IMPORT_PREFIX}/bin/cygscotchmetisv5-7.0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
