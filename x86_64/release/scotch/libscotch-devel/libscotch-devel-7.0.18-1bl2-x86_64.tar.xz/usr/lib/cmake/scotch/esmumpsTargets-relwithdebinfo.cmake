#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "SCOTCH::esmumps" for configuration "RelWithDebInfo"
set_property(TARGET SCOTCH::esmumps APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(SCOTCH::esmumps PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libesmumps.dll.a"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELWITHDEBINFO "SCOTCH::scotch;SCOTCH::scotcherr"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygesmumps-7.0.dll"
  )

list(APPEND _cmake_import_check_targets SCOTCH::esmumps )
list(APPEND _cmake_import_check_files_for_SCOTCH::esmumps "${_IMPORT_PREFIX}/lib/libesmumps.dll.a" "${_IMPORT_PREFIX}/bin/cygesmumps-7.0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
