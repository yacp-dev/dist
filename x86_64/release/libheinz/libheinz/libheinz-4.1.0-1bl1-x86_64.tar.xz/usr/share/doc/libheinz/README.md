# libheinz

Header-only C++ base library of Heinz Maier-Leibnitz Zentrum.

Generic utilities for use in several products of the
[Scientific Computing Group](computing.mlz-garching.de).

Contents:
- [Complex.h](inc/heinz/Complex.h). Defines `complex_t`, and a few elementary functions.
- [Vectors3D.h](inc/heinz/Vectors3D.h). Templated 3D vectors, and abbreviations `I3`, `R3`, `C3`.
- [Rotations3D.h](inc/heinz/Rotations3D.h). SO3 rotations, internally parameterized by quaternions.
