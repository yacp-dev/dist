#ifndef ESTK_H
#define ESTK_H
#include <stdlib.h>
#include <SDL2/SDL_mixer.h>

#include <GL/gl.h>
#include <SDL2/SDL_opengles2.h>

#define ESTK_VERSION "6.1.0-dev"

typedef unsigned int esGLuint;

// Common {{{
//=============================================================================

typedef enum {
	ES_FAIL=0,
	ES_OK=1,
} esErr;

typedef enum {
	ES_FALSE = 0,
	ES_TRUE = 1,
} esBool;

typedef enum {
	ES_DATA_FLOAT,
	ES_DATA_INT,
	ES_DATA_UINT,
	ES_DATA_SHORT,
	ES_DATA_USHORT,
	ES_DATA_BYTE,
	ES_DATA_UBYTE,
} esDataType;

void _esCheckGlError();
#define esCheckGlError() _esCheckGlError(__FILE__, __LINE__)
//#define esCheckGlError()

void *esFileAlloc(const char *file_name);

// }}}
// Math {{{
//=============================================================================

// Vectors
typedef struct { float x, y; } esVec2f;
typedef struct { float x, y, z; } esVec3f;

// Matrices
typedef struct {
	float mat[3*3];
} esMat3f;

typedef struct {
	float mat[4*4];
} esMat4f;

esVec3f esMat3f_MulVec3f(const esMat3f *m, esVec3f v);

// Quaternions
typedef struct {
	float x, y, z, w;
} esQuatf;

esQuatf esQuatf_normalize(esQuatf q);
esQuatf esQuatf_mul(esQuatf q0, esQuatf q1);
esQuatf esQuatf_local(esQuatf q, float angle);
void esQuatf_matrix(esMat3f *dst, esQuatf q);

// }}}
// Logging {{{
//=============================================================================

typedef enum {
	ES_INFO, // Information
	ES_WARN, // Warning
	ES_ERRO, // Error
	ES_DEBU, // Debug
} esLogClass;

typedef void (*esLogMessage) (esLogClass class, const char *message);

void esLogCallback(esLogMessage callback);
void esLog(int class, const char *fmt, ...);
#define esLogVersion() esLog(ES_INFO, "libestk Version " ESTK_VERSION)
#define esLogUnimplemented() esLog(ES_DEBU, "Unimplemented %s:%d", __FILE__, __LINE__)

// }}}
// Game loop {{{
//=============================================================================

void esGame_init(const char *wmTitle, int screen_width, int screen_height);
void esGame_quit(void);
void esGame_glSwap(void);
void esGame_loop(void (*frame)(float t), void (*exit)(), int frame_rate);
void esGame_loopQuit(void);
void esGame_registerKey(int sdlkey, void (*callback)(int key, int down));
void esGame_registerMouse(void (*callback) (int button, int down,
			int x, int y, int dx, int dy));
void esGame_captureMouse(int on);
void esGame_windowSize(int *w, int *h);
void esGame_setViewport(void);
void esGame_delay(unsigned int timeMs);

// }}}
// Shader {{{
//=============================================================================

typedef int esUniform;
#define UNIFORMS_MAX 10
#define SHADERS_MAX 10

typedef enum {
	ES_SHADER_VERT,
	ES_SHADER_FRAG,
} esShaderType;

typedef struct {
	esGLuint glProgram;
	esUniform uniforms[UNIFORMS_MAX];
	esGLuint glShaders[SHADERS_MAX];
	int shaderCount;
} esShader;

typedef struct {
	int location;
	const char *name;
} esShaderAttrib;

//#define ES_SHADER_SOURCE(src) "#version 130\n" #src
#define ES_SHADER_SOURCE(src) "#version 100\n" #src

void esShader_reset(esShader *shader);
esErr esShader_loadFile(esShader *shader,
		esShaderType type, const char *fileName);
esErr esShader_loadText(esShader *shader,
		esShaderType type, const char *source);
esErr esShader_compile(esShader *shader,
		const esShaderAttrib *attribs, int attribCount);
esErr esShader_dualFile(esShader *shader,
		const char *vertFile, const char *fragFile,
		const esShaderAttrib *attribs, int attribCount);
esErr esShader_dualText(esShader *shader,
		const char *vertSource, const char *fragSource,
		const esShaderAttrib *attribs, int attribCount);
void esShader_use(const esShader *shader);
void esShader_free(esShader *shader);
esGLuint esShader_uniformRegister(esShader *shader,
		esUniform reg, const char *name);
esErr esShader_uniformGl(esShader *shader, esUniform reg);

// }}}
// Geometry {{{
//=============================================================================

#define ES_GEOBUFS_MAX 8

typedef enum {
	ES_GEOBUF_STATIC,
	ES_GEOBUF_DYNAMIC,
	ES_GEOBUF_STREAM,
} esGeoBufType;

typedef struct {
	esDataType dataType;
	esGLuint glBuf;
} esGeoBuf;

void esGeoBuf_create(esGeoBuf *buf);
void esGeoBuf_array(esGeoBuf *buf,
		const void *data, size_t size, esGeoBufType type);
void esGeoBuf_arraySub(esGeoBuf *buf,
		const void *data, size_t size, int bufOffset);
void esGeoBuf_element(esGeoBuf *buf,
		const void *data, size_t size, esGeoBufType type);
void esGeoBuf_free(esGeoBuf *buf);

typedef struct {
	int bufCount;

	struct {
		esGeoBuf *geobuf;
		esDataType datatype;
		int elements;
		size_t offset, stride;
		esBool normalized;
	} buf[ES_GEOBUFS_MAX];
} esGeo;

void esGeo_reset(esGeo *geo, int bufCount);
void esGeo_point(esGeo *geo, int id, esGeoBuf *geobuf,
		esDataType datatype, int elements,
		size_t offset, size_t stride, esBool normalized);
void esGeo_renderArray(const esGeo *geo, int vertices);
void esGeo_renderElements(const esGeo *geo, const esGeoBuf *indices,
		esDataType dataType, int vertexCount);

// }}}
// Projection {{{
//=============================================================================

void esProj_identity(esMat4f *mat);
void esProj_ortho(esMat4f *mat, float x0, float y0, float x1, float y1);
void esProj_perspective(
		esMat4f *mat, float fov, float screenratio, float near, float far,
		esVec3f eye, esVec3f at, esVec3f up);

// }}}
// Texture {{{
//=============================================================================
#define ES_OPT_IMAGE

typedef enum {
	ES_TEX_NONE,
	ES_TEX_LINEAR,
} esTextureMipmap;

typedef struct {
	int w, h;
	esGLuint gltexture;
} esTexture;

esErr esTexture_createRaw(esTexture *tex, unsigned channelCount,
		unsigned width, unsigned height, esDataType dataType, const void *ptr,
		esTextureMipmap mipMapMin, esTextureMipmap mipMapMag);
#ifdef ES_OPT_IMAGE
esErr esTexture_load(esTexture *tex, const char *file_name,
		esTextureMipmap mipMapMin, esTextureMipmap mipMapMag);
#endif
esErr esTexture_createColor(esTexture *tex, unsigned width, unsigned height,
		esTextureMipmap mipMapMin, esTextureMipmap mipMapMag);
void esTexture_use(esTexture *tex);
void esTexture_useWithId(unsigned textureNumber, esTexture *tex);
void esTexture_free(esTexture *tex);

// }}}
// Multiple render targets {{{
//=============================================================================

#define ES_FRAMEBUFFER_MAX_TEXTURES 8

typedef struct {
	unsigned textureCount, width, height;
	esGLuint frameBuffer, depthBuffer;
	esGLuint renderTextures[ES_FRAMEBUFFER_MAX_TEXTURES];
} esMultiRender;

esErr esMultiRender_create(esMultiRender *mr,
		unsigned width, unsigned height,
		esTextureMipmap mipMapMin, esTextureMipmap mipMapMag,
		unsigned textureCount, ...);
void esMultiRender_destroy(esMultiRender *mr);
void esMultiRender_bind(esMultiRender *mr);
void esMultiRender_unBind(void);
void esMultiRender_bindTexture(esMultiRender *mr, unsigned textureId);
void esMultiRender_bindTextureWithId(esMultiRender *mr, unsigned textureId,
		unsigned openGlTextureId);
void esMultiRender_bindAllTextures(esMultiRender *mr);


// }}}
// Audio {{{
//=============================================================================
#define ES_OPT_AUDIO
#ifdef ES_OPT_AUDIO

typedef struct {
	Mix_Chunk *chunk;
} esSound;

esErr esSound_create(esSound *sn, const char *file_name);
void esSound_free(esSound *sn);
void esSound_play(esSound *sn);

typedef struct {
	Mix_Music *music;
} esMusic;

esErr esMusic_create(esMusic *mu, const char *file_name);
void esMusic_free(esMusic *mu);
void esMusic_play(esMusic *mu);
void esMusic_halt(void);
#endif

//=============================================================================
// }}}

#endif

