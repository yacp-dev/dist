#ifdef __cplusplus
extern "C" {
#endif

#define FLATCC_VERSION_TEXT "0.6.4"
#define FLATCC_VERSION_MAJOR 0
#define FLATCC_VERSION_MINOR 6
#define FLATCC_VERSION_PATCH 4
/* 1 or 0 */
#define FLATCC_VERSION_RELEASED 1

#ifdef __cplusplus
}
#endif
