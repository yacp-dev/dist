#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Ginkgo::ginkgo_device" for configuration "RelWithDebInfo"
set_property(TARGET Ginkgo::ginkgo_device APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(Ginkgo::ginkgo_device PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libginkgo_device.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygginkgo_device-1.11.0.dll"
  )

list(APPEND _cmake_import_check_targets Ginkgo::ginkgo_device )
list(APPEND _cmake_import_check_files_for_Ginkgo::ginkgo_device "${_IMPORT_PREFIX}/lib/libginkgo_device.dll.a" "${_IMPORT_PREFIX}/bin/cygginkgo_device-1.11.0.dll" )

# Import target "Ginkgo::ginkgo_reference" for configuration "RelWithDebInfo"
set_property(TARGET Ginkgo::ginkgo_reference APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(Ginkgo::ginkgo_reference PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libginkgo_reference.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygginkgo_reference-1.11.0.dll"
  )

list(APPEND _cmake_import_check_targets Ginkgo::ginkgo_reference )
list(APPEND _cmake_import_check_files_for_Ginkgo::ginkgo_reference "${_IMPORT_PREFIX}/lib/libginkgo_reference.dll.a" "${_IMPORT_PREFIX}/bin/cygginkgo_reference-1.11.0.dll" )

# Import target "Ginkgo::ginkgo_omp" for configuration "RelWithDebInfo"
set_property(TARGET Ginkgo::ginkgo_omp APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(Ginkgo::ginkgo_omp PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libginkgo_omp.dll.a"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELWITHDEBINFO "Ginkgo::ginkgo_cuda;Ginkgo::ginkgo_hip;Ginkgo::ginkgo_dpcpp"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygginkgo_omp-1.11.0.dll"
  )

list(APPEND _cmake_import_check_targets Ginkgo::ginkgo_omp )
list(APPEND _cmake_import_check_files_for_Ginkgo::ginkgo_omp "${_IMPORT_PREFIX}/lib/libginkgo_omp.dll.a" "${_IMPORT_PREFIX}/bin/cygginkgo_omp-1.11.0.dll" )

# Import target "Ginkgo::ginkgo_cuda" for configuration "RelWithDebInfo"
set_property(TARGET Ginkgo::ginkgo_cuda APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(Ginkgo::ginkgo_cuda PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libginkgo_cuda.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygginkgo_cuda-1.11.0.dll"
  )

list(APPEND _cmake_import_check_targets Ginkgo::ginkgo_cuda )
list(APPEND _cmake_import_check_files_for_Ginkgo::ginkgo_cuda "${_IMPORT_PREFIX}/lib/libginkgo_cuda.dll.a" "${_IMPORT_PREFIX}/bin/cygginkgo_cuda-1.11.0.dll" )

# Import target "Ginkgo::ginkgo_dpcpp" for configuration "RelWithDebInfo"
set_property(TARGET Ginkgo::ginkgo_dpcpp APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(Ginkgo::ginkgo_dpcpp PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libginkgo_dpcpp.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygginkgo_dpcpp-1.11.0.dll"
  )

list(APPEND _cmake_import_check_targets Ginkgo::ginkgo_dpcpp )
list(APPEND _cmake_import_check_files_for_Ginkgo::ginkgo_dpcpp "${_IMPORT_PREFIX}/lib/libginkgo_dpcpp.dll.a" "${_IMPORT_PREFIX}/bin/cygginkgo_dpcpp-1.11.0.dll" )

# Import target "Ginkgo::ginkgo_hip" for configuration "RelWithDebInfo"
set_property(TARGET Ginkgo::ginkgo_hip APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(Ginkgo::ginkgo_hip PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libginkgo_hip.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygginkgo_hip-1.11.0.dll"
  )

list(APPEND _cmake_import_check_targets Ginkgo::ginkgo_hip )
list(APPEND _cmake_import_check_files_for_Ginkgo::ginkgo_hip "${_IMPORT_PREFIX}/lib/libginkgo_hip.dll.a" "${_IMPORT_PREFIX}/bin/cygginkgo_hip-1.11.0.dll" )

# Import target "Ginkgo::ginkgo" for configuration "RelWithDebInfo"
set_property(TARGET Ginkgo::ginkgo APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(Ginkgo::ginkgo PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libginkgo.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygginkgo-1.11.0.dll"
  )

list(APPEND _cmake_import_check_targets Ginkgo::ginkgo )
list(APPEND _cmake_import_check_files_for_Ginkgo::ginkgo "${_IMPORT_PREFIX}/lib/libginkgo.dll.a" "${_IMPORT_PREFIX}/bin/cygginkgo-1.11.0.dll" )

# Import target "Ginkgo::ginkgo_core" for configuration "RelWithDebInfo"
set_property(TARGET Ginkgo::ginkgo_core APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(Ginkgo::ginkgo_core PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libginkgo_core.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygginkgo_core-1.11.0.dll"
  )

list(APPEND _cmake_import_check_targets Ginkgo::ginkgo_core )
list(APPEND _cmake_import_check_files_for_Ginkgo::ginkgo_core "${_IMPORT_PREFIX}/lib/libginkgo_core.dll.a" "${_IMPORT_PREFIX}/bin/cygginkgo_core-1.11.0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
