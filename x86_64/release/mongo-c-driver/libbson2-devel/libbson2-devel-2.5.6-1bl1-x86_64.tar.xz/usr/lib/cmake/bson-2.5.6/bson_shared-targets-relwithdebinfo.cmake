#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "bson::shared" for configuration "RelWithDebInfo"
set_property(TARGET bson::shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(bson::shared PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libbson2.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygbson2-2.dll"
  )

list(APPEND _cmake_import_check_targets bson::shared )
list(APPEND _cmake_import_check_files_for_bson::shared "${_IMPORT_PREFIX}/lib/libbson2.dll.a" "${_IMPORT_PREFIX}/bin/cygbson2-2.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
