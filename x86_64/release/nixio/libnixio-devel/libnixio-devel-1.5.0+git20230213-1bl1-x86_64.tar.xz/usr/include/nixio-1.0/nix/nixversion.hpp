// the configured options and settings for NIX

namespace nix {
    #define VERSION_MAJOR 1
    #define VERSION_MINOR 5
    #define VERSION_PATCH 0
}
