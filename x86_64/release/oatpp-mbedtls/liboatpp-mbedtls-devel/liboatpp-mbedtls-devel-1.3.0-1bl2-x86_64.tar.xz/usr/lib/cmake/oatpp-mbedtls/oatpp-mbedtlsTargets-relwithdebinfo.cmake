#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "oatpp::oatpp-mbedtls" for configuration "RelWithDebInfo"
set_property(TARGET oatpp::oatpp-mbedtls APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(oatpp::oatpp-mbedtls PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/liboatpp-mbedtls.dll.a"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELWITHDEBINFO "oatpp::oatpp;oatpp::oatpp-test"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygoatpp-mbedtls-1.dll"
  )

list(APPEND _cmake_import_check_targets oatpp::oatpp-mbedtls )
list(APPEND _cmake_import_check_files_for_oatpp::oatpp-mbedtls "${_IMPORT_PREFIX}/lib/liboatpp-mbedtls.dll.a" "${_IMPORT_PREFIX}/bin/cygoatpp-mbedtls-1.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
