if [ ! -e /etc/tty-colorscheme/tty-colorscheme.conf ]
then
    /usr/bin/mkdir -p /etc/tty-colorscheme
    /usr/bin/cp /etc/defaults/etc/tty-colorscheme/tty-colorscheme.conf /etc/tty-colorscheme/tty-colorscheme.conf
fi

