if [ -f /etc/tty-colorscheme/tty-colorscheme.conf ] && cmp -s /etc/defaults/etc/tty-colorscheme/tty-colorscheme.conf /etc/tty-colorscheme/tty-colorscheme.conf
then
    rm /etc/tty-colorscheme/tty-colorscheme.conf
fi

