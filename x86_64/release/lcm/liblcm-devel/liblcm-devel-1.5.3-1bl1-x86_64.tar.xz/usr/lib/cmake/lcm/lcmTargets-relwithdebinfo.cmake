#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "lcm" for configuration "RelWithDebInfo"
set_property(TARGET lcm APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(lcm PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/liblcm.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cyglcm-1.dll"
  )

list(APPEND _cmake_import_check_targets lcm )
list(APPEND _cmake_import_check_files_for_lcm "${_IMPORT_PREFIX}/lib/liblcm.dll.a" "${_IMPORT_PREFIX}/bin/cyglcm-1.dll" )

# Import target "lcm-gen" for configuration "RelWithDebInfo"
set_property(TARGET lcm-gen APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(lcm-gen PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/lcm-gen.exe"
  )

list(APPEND _cmake_import_check_targets lcm-gen )
list(APPEND _cmake_import_check_files_for_lcm-gen "${_IMPORT_PREFIX}/bin/lcm-gen.exe" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
