set(LCM_VERSION 1.5.3)
set(LCM_NAMESPACE "")
set(LCM_USE_FILE ${CMAKE_CURRENT_LIST_DIR}/lcmUtilities.cmake)


include(${CMAKE_CURRENT_LIST_DIR}/lcmTargets.cmake)

