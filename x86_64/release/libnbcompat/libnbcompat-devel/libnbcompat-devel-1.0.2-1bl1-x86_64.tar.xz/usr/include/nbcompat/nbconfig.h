/* nbcompat/nbconfig.h.  Generated from nbconfig.h.in by configure.  */
/* nbcompat/nbconfig.h.in.  Generated from configure.ac by autoheader.  */


#ifndef _NBCOMPAT_NBCONFIG_H
#define _NBCOMPAT_NBCONFIG_H


/* Define if building universal (internal helper macro) */
/* #undef AC_APPLE_UNIVERSAL_BUILD */

/* Define to 1 if the `pread' function is broken. */
/* #undef BROKEN_PREAD */

/* Define to 1 if the `pwrite' function is broken. */
/* #undef BROKEN_PWRITE */

/* Define to 1 if the 'getpgrp' function requires zero arguments. */
#define GETPGRP_VOID 1

/* Define to 1 if you have the <alloca.h> header file. */
#define LIBNBCOMPAT_HAVE_ALLOCA_H 1

/* Define to 1 if you have the <assert.h> header file. */
#define LIBNBCOMPAT_HAVE_ASSERT_H 1

/* Define to 1 if you have the <bsd/libutil.h> header file. */
/* #undef LIBNBCOMPAT_HAVE_BSD_LIBUTIL_H */

/* Define to 1 if you have the <ctype.h> header file. */
#define LIBNBCOMPAT_HAVE_CTYPE_H 1

/* Define to 1 if you have the declaration of 'asprintf(char **, const char *,
   ...)', and to 0 if you don't. */
#define LIBNBCOMPAT_HAVE_DECL_ASPRINTF 1

/* Define to 1 if you have the declaration of 'endgrent', and to 0 if you
   don't. */
#define LIBNBCOMPAT_HAVE_DECL_ENDGRENT 0

/* Define to 1 if you have the declaration of 'endpwent', and to 0 if you
   don't. */
#define LIBNBCOMPAT_HAVE_DECL_ENDPWENT 0

/* Define to 1 if you have the declaration of 'isblank(int)', and to 0 if you
   don't. */
#define LIBNBCOMPAT_HAVE_DECL_ISBLANK 1

/* Define to 1 if you have the declaration of 'optarg', and to 0 if you don't.
   */
#define LIBNBCOMPAT_HAVE_DECL_OPTARG 1

/* Define to 1 if you have the declaration of 'optind', and to 0 if you don't.
   */
#define LIBNBCOMPAT_HAVE_DECL_OPTIND 1

/* Define to 1 if you have the declaration of 'optreset', and to 0 if you
   don't. */
#define LIBNBCOMPAT_HAVE_DECL_OPTRESET 1

/* Define to 1 if you have the declaration of 'setpassent', and to 0 if you
   don't. */
#define LIBNBCOMPAT_HAVE_DECL_SETPASSENT 0

/* Define to 1 if you have the declaration of 'snprintf(char *, size_t, const
   char *, ...)', and to 0 if you don't. */
#define LIBNBCOMPAT_HAVE_DECL_SNPRINTF 1

/* Define to 1 if you have the declaration of 'strdup(const char *)', and to 0
   if you don't. */
#define LIBNBCOMPAT_HAVE_DECL_STRDUP 1

/* Define to 1 if you have the declaration of 'strerror_r', and to 0 if you
   don't. */
#define LIBNBCOMPAT_HAVE_DECL_STRERROR_R 1

/* Define to 1 if you have the <dirent.h> header file. */
#define LIBNBCOMPAT_HAVE_DIRENT_H 1

/* Define if dirfd is either a function or a macro. */
#define LIBNBCOMPAT_HAVE_DIRFD 1

/* Define to 1 if 'dd_fd' is a member of 'DIR'. */
/* #undef LIBNBCOMPAT_HAVE_DIR_DD_FD */

/* Define to 1 if you have the <dlfcn.h> header file. */
#define LIBNBCOMPAT_HAVE_DLFCN_H 1

/* Define to 1 if you have the <endian.h> header file. */
#define LIBNBCOMPAT_HAVE_ENDIAN_H 1

/* Define to 1 if you have the 'err' function. */
#define LIBNBCOMPAT_HAVE_ERR 1

/* Define to 1 if you have the <errno.h> header file. */
#define LIBNBCOMPAT_HAVE_ERRNO_H 1

/* Define to 1 if you have the <err.h> header file. */
#define LIBNBCOMPAT_HAVE_ERR_H 1

/* Define to 1 if you have the <fcntl.h> header file. */
#define LIBNBCOMPAT_HAVE_FCNTL_H 1

/* Define to 1 if you have the 'fgetln' function. */
/* #undef LIBNBCOMPAT_HAVE_FGETLN */

/* Define to 1 if you have the 'fnmatch' function. */
#define LIBNBCOMPAT_HAVE_FNMATCH 1

/* Define to 1 if you have the <fnmatch.h> header file. */
#define LIBNBCOMPAT_HAVE_FNMATCH_H 1

/* Define to 1 if you have the 'fork' function. */
#define LIBNBCOMPAT_HAVE_FORK 1

/* Define to 1 if you have the 'fparseln' function. */
/* #undef LIBNBCOMPAT_HAVE_FPARSELN */

/* Define to 1 if the system has the type 'fsid_t'. */
/* #undef LIBNBCOMPAT_HAVE_FSID_T */

/* Define to 1 if you have the <fts.h> header file. */
#define LIBNBCOMPAT_HAVE_FTS_H 1

/* Define to 1 if you have the 'gai_strerror' function. */
#define LIBNBCOMPAT_HAVE_GAI_STRERROR 1

/* Define to 1 if you have the 'getaddrinfo' function. */
#define LIBNBCOMPAT_HAVE_GETADDRINFO 1

/* Define to 1 if you have the 'getdelim' function. */
#define LIBNBCOMPAT_HAVE_GETDELIM 1

/* Define to 1 if you have the 'getenv' function. */
#define LIBNBCOMPAT_HAVE_GETENV 1

/* Define to 1 if you have the 'getline' function. */
#define LIBNBCOMPAT_HAVE_GETLINE 1

/* Define to 1 if you have the 'getmode' function. */
#define LIBNBCOMPAT_HAVE_GETMODE 1

/* Define to 1 if you have the 'getnameinfo' function. */
#define LIBNBCOMPAT_HAVE_GETNAMEINFO 1

/* Define to 1 if you have the <getopt.h> header file. */
#define LIBNBCOMPAT_HAVE_GETOPT_H 1

/* Define to 1 if you have the 'getpassphrase' function. */
/* #undef LIBNBCOMPAT_HAVE_GETPASSPHRASE */

/* Define to 1 if you have the 'getpgrp' function. */
#define LIBNBCOMPAT_HAVE_GETPGRP 1

/* Define to 1 if you have the 'gid_from_group' function. */
/* #undef LIBNBCOMPAT_HAVE_GID_FROM_GROUP */

/* Define to 1 if you have the <glob.h> header file. */
#define LIBNBCOMPAT_HAVE_GLOB_H 1

/* Define to 1 if you have the 'group_from_gid' function. */
/* #undef LIBNBCOMPAT_HAVE_GROUP_FROM_GID */

/* Define to 1 if you have the <grp.h> header file. */
#define LIBNBCOMPAT_HAVE_GRP_H 1

/* Define to 1 if you have the <inttypes.h> header file. */
#define LIBNBCOMPAT_HAVE_INTTYPES_H 1

/* Define to 1 if you have the 'issetugid' function. */
#define LIBNBCOMPAT_HAVE_ISSETUGID 1

/* Define to 1 if you have the 'lchflags' function. */
/* #undef LIBNBCOMPAT_HAVE_LCHFLAGS */

/* Define to 1 if you have the 'lchmod' function. */
/* #undef LIBNBCOMPAT_HAVE_LCHMOD */

/* Define to 1 if you have the 'lchown' function. */
#define LIBNBCOMPAT_HAVE_LCHOWN 1

/* Define to 1 if you have the 'nsl' library (-lnsl). */
/* #undef LIBNBCOMPAT_HAVE_LIBNSL */

/* Define to 1 if you have the 'util' library (-lutil). */
/* #undef LIBNBCOMPAT_HAVE_LIBUTIL */

/* Define to 1 if you have the <libutil.h> header file. */
/* #undef LIBNBCOMPAT_HAVE_LIBUTIL_H */

/* Define to 1 if you have the <limits.h> header file. */
#define LIBNBCOMPAT_HAVE_LIMITS_H 1

/* Define to 1 if the system has the type 'long double'. */
#define LIBNBCOMPAT_HAVE_LONG_DOUBLE 1

/* Define to 1 if the system has the type 'long long'. */
#define LIBNBCOMPAT_HAVE_LONG_LONG 1

/* Define to 1 if you have the 'lutimes' function. */
#define LIBNBCOMPAT_HAVE_LUTIMES 1

/* Define to 1 if you have the <machine/endian.h> header file. */
#define LIBNBCOMPAT_HAVE_MACHINE_ENDIAN_H 1

/* Define to 1 if you have the <md5.h> header file. */
/* #undef LIBNBCOMPAT_HAVE_MD5_H */

/* Define to 1 if you have the <minix/config.h> header file. */
/* #undef LIBNBCOMPAT_HAVE_MINIX_CONFIG_H */

/* Define to 1 if you have the 'mkdtemp' function. */
#define LIBNBCOMPAT_HAVE_MKDTEMP 1

/* Define to 1 if you have the 'mkstemp' function. */
#define LIBNBCOMPAT_HAVE_MKSTEMP 1

/* Define to 1 if the `fts_*' functions are built into the library. */
/* #undef LIBNBCOMPAT_HAVE_NBCOMPAT_FTS */

/* Define to 1 if the `glob' function is built into the library. */
#define LIBNBCOMPAT_HAVE_NBCOMPAT_GLOB 1

/* Define to 1 if the `MD5*' functions are built into the library. */
#define LIBNBCOMPAT_HAVE_NBCOMPAT_MD5 1

/* Define to 1 if the `MD5Init' function is built into the library. */
/* #undef LIBNBCOMPAT_HAVE_NBCOMPAT_MD5INIT */

/* Define to 1 if the `poll' function is built into the library. */
/* #undef LIBNBCOMPAT_HAVE_NBCOMPAT_POLL */

/* Define to 1 if the `queue' macros are supplied by the library. */
#define LIBNBCOMPAT_HAVE_NBCOMPAT_QUEUE 1

/* Define to 1 if the `regex' functions are built into the library. */
/* #undef LIBNBCOMPAT_HAVE_NBCOMPAT_REGEX */

/* Define to 1 if the `RMD160*' functions are built into the library. */
#define LIBNBCOMPAT_HAVE_NBCOMPAT_RMD160 1

/* Define to 1 if the `SHA1*' functions are built into the library. */
#define LIBNBCOMPAT_HAVE_NBCOMPAT_SHA1 1

/* Define to 1 if the `SHA2*' functions are built into the library. */
#define LIBNBCOMPAT_HAVE_NBCOMPAT_SHA2 1

/* Define to 1 if the `vis' function is built into the library. */
#define LIBNBCOMPAT_HAVE_NBCOMPAT_VIS 1

/* Define to 1 if you have the <ndir.h> header file. */
/* #undef LIBNBCOMPAT_HAVE_NDIR_H */

/* Define to 1 if you have the <netdb.h> header file. */
#define LIBNBCOMPAT_HAVE_NETDB_H 1

/* Define to 1 if you have the <paths.h> header file. */
#define LIBNBCOMPAT_HAVE_PATHS_H 1

/* Define to 1 if you have the <poll.h> header file. */
#define LIBNBCOMPAT_HAVE_POLL_H 1

/* Define to 1 if *printf() uses %qd to print `long long' (otherwise uses
   %lld). */
/* #undef LIBNBCOMPAT_HAVE_PRINTF_QD */

/* Define to 1 if you have the 'pwcache_groupdb' function. */
/* #undef LIBNBCOMPAT_HAVE_PWCACHE_GROUPDB */

/* Define to 1 if you have the 'pwcache_userdb' function. */
/* #undef LIBNBCOMPAT_HAVE_PWCACHE_USERDB */

/* Define to 1 if you have the <pwd.h> header file. */
#define LIBNBCOMPAT_HAVE_PWD_H 1

/* Define to 1 if you have the <regex.h> header file. */
#define LIBNBCOMPAT_HAVE_REGEX_H 1

/* Define to 1 if you have the <rmd160.h> header file. */
/* #undef LIBNBCOMPAT_HAVE_RMD160_H */

/* Define to 1 if you have the 'select' function. */
#define LIBNBCOMPAT_HAVE_SELECT 1

/* Define to 1 if you have the 'setenv' function. */
#define LIBNBCOMPAT_HAVE_SETENV 1

/* Define to 1 if you have the 'setgroupent' function. */
/* #undef LIBNBCOMPAT_HAVE_SETGROUPENT */

/* Define to 1 if you have the 'setlocale' function. */
#define LIBNBCOMPAT_HAVE_SETLOCALE 1

/* Define to 1 if you have the 'setmode' function. */
/* #undef LIBNBCOMPAT_HAVE_SETMODE */

/* Define to 1 if you have the 'setpassent' function. */
#define LIBNBCOMPAT_HAVE_SETPASSENT 1

/* Define to 1 if you have the 'setprogname' function. */
#define LIBNBCOMPAT_HAVE_SETPROGNAME 1

/* Define to 1 if you have the <sha1.h> header file. */
/* #undef LIBNBCOMPAT_HAVE_SHA1_H */

/* Define to 1 if you have the <sha2.h> header file. */
/* #undef LIBNBCOMPAT_HAVE_SHA2_H */

/* Define to 1 if you have the 'shquote' function. */
/* #undef LIBNBCOMPAT_HAVE_SHQUOTE */

/* Define to 1 if you have the <signal.h> header file. */
#define LIBNBCOMPAT_HAVE_SIGNAL_H 1

/* Define to 1 if the system has the type 'socklen_t'. */
#define LIBNBCOMPAT_HAVE_SOCKLEN_T 1

/* Define to 1 if you have the 'statvfs' function. */
#define LIBNBCOMPAT_HAVE_STATVFS 1

/* Define to 1 if you have the <stdarg.h> header file. */
#define LIBNBCOMPAT_HAVE_STDARG_H 1

/* Define to 1 if stdbool.h conforms to C99. */
#define LIBNBCOMPAT_HAVE_STDBOOL_H 1

/* Define to 1 if you have the <stddef.h> header file. */
#define LIBNBCOMPAT_HAVE_STDDEF_H 1

/* Define to 1 if you have the <stdint.h> header file. */
#define LIBNBCOMPAT_HAVE_STDINT_H 1

/* Define to 1 if you have the <stdio.h> header file. */
#define LIBNBCOMPAT_HAVE_STDIO_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define LIBNBCOMPAT_HAVE_STDLIB_H 1

/* Define to 1 if you have the 'strerror' function. */
#define LIBNBCOMPAT_HAVE_STRERROR 1

/* Define if you have 'strerror_r'. */
#define LIBNBCOMPAT_HAVE_STRERROR_R 1

/* Define to 1 if you have the <strings.h> header file. */
#define LIBNBCOMPAT_HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define LIBNBCOMPAT_HAVE_STRING_H 1

/* Define to 1 if you have the 'strlcat' function. */
#define LIBNBCOMPAT_HAVE_STRLCAT 1

/* Define to 1 if you have the 'strlcpy' function. */
#define LIBNBCOMPAT_HAVE_STRLCPY 1

/* Define to 1 if you have the 'strmode' function. */
/* #undef LIBNBCOMPAT_HAVE_STRMODE */

/* Define to 1 if you have the 'strnlen' function. */
#define LIBNBCOMPAT_HAVE_STRNLEN 1

/* Define to 1 if you have the 'strsep' function. */
#define LIBNBCOMPAT_HAVE_STRSEP 1

/* Define to 1 if you have the 'strsvis' function. */
/* #undef LIBNBCOMPAT_HAVE_STRSVIS */

/* Define to 1 if you have the 'strtoll' function. */
#define LIBNBCOMPAT_HAVE_STRTOLL 1

/* Define to 1 if the system has the type 'struct addrinfo'. */
#define LIBNBCOMPAT_HAVE_STRUCT_ADDRINFO 1

/* Define to 1 if 'd_namlen' is a member of 'struct dirent'. */
/* #undef LIBNBCOMPAT_HAVE_STRUCT_DIRENT_D_NAMLEN */

/* Define to 1 if the system has the type 'struct in6_addr'. */
#define LIBNBCOMPAT_HAVE_STRUCT_IN6_ADDR 1

/* Define to 1 if the system has the type 'struct option'. */
#define LIBNBCOMPAT_HAVE_STRUCT_OPTION 1

/* Define to 1 if the system has the type 'struct sockaddr_in6'. */
#define LIBNBCOMPAT_HAVE_STRUCT_SOCKADDR_IN6 1

/* Define to 1 if the system has the type 'struct sockaddr_storage'. */
#define LIBNBCOMPAT_HAVE_STRUCT_SOCKADDR_STORAGE 1

/* Define to 1 if 'f_flags' is a member of 'struct statfs'. */
/* #undef LIBNBCOMPAT_HAVE_STRUCT_STATFS_F_FLAGS */

/* Define to 1 if 'f_fsize' is a member of 'struct statfs'. */
/* #undef LIBNBCOMPAT_HAVE_STRUCT_STATFS_F_FSIZE */

/* Define to 1 if 'f_iosize' is a member of 'struct statfs'. */
/* #undef LIBNBCOMPAT_HAVE_STRUCT_STATFS_F_IOSIZE */

/* Define to 1 if you have the 'strunvis' function. */
/* #undef LIBNBCOMPAT_HAVE_STRUNVIS */

/* Define to 1 if you have the 'strvis' function. */
/* #undef LIBNBCOMPAT_HAVE_STRVIS */

/* Define to 1 if you have the 'svis' function. */
/* #undef LIBNBCOMPAT_HAVE_SVIS */

/* Define to 1 if you have the <sysexits.h> header file. */
#define LIBNBCOMPAT_HAVE_SYSEXITS_H 1

/* Define to 1 if you have the <sys/byteorder.h> header file. */
/* #undef LIBNBCOMPAT_HAVE_SYS_BYTEORDER_H */

/* Define to 1 if you have the <sys/cdefs.h> header file. */
#define LIBNBCOMPAT_HAVE_SYS_CDEFS_H 1

/* Define to 1 if you have the <sys/dir.h> header file. */
#define LIBNBCOMPAT_HAVE_SYS_DIR_H 1

/* Define to 1 if you have the <sys/endian.h> header file. */
#define LIBNBCOMPAT_HAVE_SYS_ENDIAN_H 1

/* Define to 1 if you have the <sys/file.h> header file. */
#define LIBNBCOMPAT_HAVE_SYS_FILE_H 1

/* Define to 1 if you have the <sys/mkdev.h> header file. */
/* #undef LIBNBCOMPAT_HAVE_SYS_MKDEV_H */

/* Define to 1 if you have the <sys/mman.h> header file. */
#define LIBNBCOMPAT_HAVE_SYS_MMAN_H 1

/* Define to 1 if you have the <sys/mount.h> header file. */
#define LIBNBCOMPAT_HAVE_SYS_MOUNT_H 1

/* Define to 1 if you have the <sys/ndir.h> header file. */
/* #undef LIBNBCOMPAT_HAVE_SYS_NDIR_H */

/* Define to 1 if you have the <sys/param.h> header file. */
#define LIBNBCOMPAT_HAVE_SYS_PARAM_H 1

/* Define to 1 if you have the <sys/poll.h> header file. */
#define LIBNBCOMPAT_HAVE_SYS_POLL_H 1

/* Define to 1 if you have the <sys/queue.h> header file. */
#define LIBNBCOMPAT_HAVE_SYS_QUEUE_H 1

/* Define to 1 if you have the <sys/socket.h> header file. */
#define LIBNBCOMPAT_HAVE_SYS_SOCKET_H 1

/* Define to 1 if you have the <sys/statfs.h> header file. */
#define LIBNBCOMPAT_HAVE_SYS_STATFS_H 1

/* Define to 1 if you have the <sys/statvfs.h> header file. */
#define LIBNBCOMPAT_HAVE_SYS_STATVFS_H 1

/* Define to 1 if you have the <sys/stat.h> header file. */
#define LIBNBCOMPAT_HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/time.h> header file. */
#define LIBNBCOMPAT_HAVE_SYS_TIME_H 1

/* Define to 1 if you have the <sys/ttycom.h> header file. */
/* #undef LIBNBCOMPAT_HAVE_SYS_TTYCOM_H */

/* Define to 1 if you have the <sys/types.h> header file. */
#define LIBNBCOMPAT_HAVE_SYS_TYPES_H 1

/* Define to 1 if you have the <sys/uio.h> header file. */
#define LIBNBCOMPAT_HAVE_SYS_UIO_H 1

/* Define to 1 if you have the <sys/vfs.h> header file. */
#define LIBNBCOMPAT_HAVE_SYS_VFS_H 1

/* Define to 1 if you have the <termcap.h> header file. */
/* #undef LIBNBCOMPAT_HAVE_TERMCAP_H */

/* Define to 1 if you have the <time.h> header file. */
#define LIBNBCOMPAT_HAVE_TIME_H 1

/* Define to 1 if you have the <tzfile.h> header file. */
#define LIBNBCOMPAT_HAVE_TZFILE_H 1

/* Define to 1 if you have the 'uid_from_user' function. */
/* #undef LIBNBCOMPAT_HAVE_UID_FROM_USER */

/* Define to 1 if the system has the type 'uintptr_t'. */
#define LIBNBCOMPAT_HAVE_UINTPTR_T 1

/* Define to 1 if you have the <unistd.h> header file. */
#define LIBNBCOMPAT_HAVE_UNISTD_H 1

/* Define to 1 if you have the 'unsetenv' function. */
#define LIBNBCOMPAT_HAVE_UNSETENV 1

/* Define to 1 if you have the 'unvis' function. */
/* #undef LIBNBCOMPAT_HAVE_UNVIS */

/* Define to 1 if you have the 'user_from_uid' function. */
/* #undef LIBNBCOMPAT_HAVE_USER_FROM_UID */

/* Define to 1 if you have the 'usleep' function. */
#define LIBNBCOMPAT_HAVE_USLEEP 1

/* Define to 1 if you have the <util.h> header file. */
/* #undef LIBNBCOMPAT_HAVE_UTIL_H */

/* Define to 1 if you have the 'utimes' function. */
#define LIBNBCOMPAT_HAVE_UTIMES 1

/* Define to 1 if you have the <utime.h> header file. */
#define LIBNBCOMPAT_HAVE_UTIME_H 1

/* Define to 1 if the `va_copy' function is supported. */
#define LIBNBCOMPAT_HAVE_VA_COPY 1

/* Define to 1 if you have the 'vfork' function. */
#define LIBNBCOMPAT_HAVE_VFORK 1

/* Define to 1 if you have the <vfork.h> header file. */
/* #undef LIBNBCOMPAT_HAVE_VFORK_H */

/* Define to 1 if you have the 'vis' function. */
/* #undef LIBNBCOMPAT_HAVE_VIS */

/* Define to 1 if you have the <vis.h> header file. */
/* #undef LIBNBCOMPAT_HAVE_VIS_H */

/* Define to 1 if you have the 'warn' function. */
#define LIBNBCOMPAT_HAVE_WARN 1

/* Define to 1 if you have the <wchar.h> header file. */
#define LIBNBCOMPAT_HAVE_WCHAR_H 1

/* Define to 1 if 'fork' works. */
#define LIBNBCOMPAT_HAVE_WORKING_FORK 1

/* Define to 1 if `long long' is supported and sizeof(off_t) >= 8. */
/* #undef LIBNBCOMPAT_HAVE_WORKING_LONG_LONG */

/* Define to 1 if 'vfork' works. */
#define LIBNBCOMPAT_HAVE_WORKING_VFORK 1

/* Define to 1 if the system has the type '_Bool'. */
#define LIBNBCOMPAT_HAVE__BOOL 1

/* define if your compiler has __attribute__ */
#define LIBNBCOMPAT_HAVE___ATTRIBUTE__ 1

/* Define to 1 if the `__builtin_va_copy' function is supported. */
#define LIBNBCOMPAT_HAVE___BUILTIN_VA_COPY 1

/* Define the major version number. */
#define LIBNBCOMPAT_VERSION_MAJOR 1

/* Define the minor version number. */
#define LIBNBCOMPAT_VERSION_MINOR 0

/* Define the patch version number. */
#define LIBNBCOMPAT_VERSION_PATCH 2

/* Define the version string. */
#define LIBNBCOMPAT_VERSION_STRING "1.0.2"

/* Define to the sub-directory where libtool stores uninstalled libraries. */
#define LT_OBJDIR ".libs/"

/* Name of package */

/* Define to the address where bug reports for this package should be sent. */

/* Define to the full name of this package. */

/* Define to the full name and version of this package. */

/* Define to the one symbol short name of this package. */

/* Define to the home page for this package. */

/* Define to the version of this package. */

/* The size of 'off_t', as computed by sizeof. */
#define SIZEOF_OFF_T 8

/* Define to 1 if all of the C89 standard headers exist (not just the ones
   required in a freestanding environment). This macro is provided for
   backward compatibility; new code need not use it. */
#define STDC_HEADERS 1

/* Define to 1 if strerror_r returns char *. */
#define STRERROR_R_CHAR_P 1

/* Define to 1 if you can safely include both <sys/time.h> and <time.h>. This
   macro is obsolete. */
#define TIME_WITH_SYS_TIME 1

/* Enable extensions on AIX, Interix, z/OS.  */
#ifndef _ALL_SOURCE
# define _ALL_SOURCE 1
#endif
/* Enable extensions on Cosmopolitan Libc. */
#ifndef _COSMO_SOURCE
# define _COSMO_SOURCE 1
#endif
/* Enable general extensions on macOS.  */
#ifndef _DARWIN_C_SOURCE
# define _DARWIN_C_SOURCE 1
#endif
/* Enable general extensions on Solaris.  */
#ifndef __EXTENSIONS__
# define __EXTENSIONS__ 1
#endif
/* Enable GNU extensions on systems that have them.  */
#ifndef _GNU_SOURCE
# define _GNU_SOURCE 1
#endif
/* Enable X/Open compliant socket functions that do not require linking
   with -lxnet on HP-UX 11.11.  */
#ifndef _HPUX_ALT_XOPEN_SOCKET_API
# define _HPUX_ALT_XOPEN_SOCKET_API 1
#endif
/* Identify the host operating system as Minix.
   This macro does not affect the system headers' behavior.
   A future release of Autoconf may stop defining this macro.  */
#ifndef _MINIX
/* # undef _MINIX */
#endif
/* Enable general extensions on NetBSD.
   Enable NetBSD compatibility extensions on Minix.  */
#ifndef _NETBSD_SOURCE
# define _NETBSD_SOURCE 1
#endif
/* Enable OpenBSD compatibility extensions on NetBSD.
   Oddly enough, this does nothing on OpenBSD.  */
#ifndef _OPENBSD_SOURCE
# define _OPENBSD_SOURCE 1
#endif
/* Define to 1 if needed for POSIX-compatible behavior.  */
#ifndef _POSIX_SOURCE
/* # undef _POSIX_SOURCE */
#endif
/* Define to 2 if needed for POSIX-compatible behavior.  */
#ifndef _POSIX_1_SOURCE
/* # undef _POSIX_1_SOURCE */
#endif
/* Enable POSIX-compatible threading on Solaris.  */
#ifndef _POSIX_PTHREAD_SEMANTICS
# define _POSIX_PTHREAD_SEMANTICS 1
#endif
/* Enable extensions specified by ISO/IEC TS 18661-5:2014.  */
#ifndef __STDC_WANT_IEC_60559_ATTRIBS_EXT__
# define __STDC_WANT_IEC_60559_ATTRIBS_EXT__ 1
#endif
/* Enable extensions specified by ISO/IEC TS 18661-1:2014.  */
#ifndef __STDC_WANT_IEC_60559_BFP_EXT__
# define __STDC_WANT_IEC_60559_BFP_EXT__ 1
#endif
/* Enable extensions specified by ISO/IEC TS 18661-2:2015.  */
#ifndef __STDC_WANT_IEC_60559_DFP_EXT__
# define __STDC_WANT_IEC_60559_DFP_EXT__ 1
#endif
/* Enable extensions specified by C23 Annex F.  */
#ifndef __STDC_WANT_IEC_60559_EXT__
# define __STDC_WANT_IEC_60559_EXT__ 1
#endif
/* Enable extensions specified by ISO/IEC TS 18661-4:2015.  */
#ifndef __STDC_WANT_IEC_60559_FUNCS_EXT__
# define __STDC_WANT_IEC_60559_FUNCS_EXT__ 1
#endif
/* Enable extensions specified by C23 Annex H and ISO/IEC TS 18661-3:2015.  */
#ifndef __STDC_WANT_IEC_60559_TYPES_EXT__
# define __STDC_WANT_IEC_60559_TYPES_EXT__ 1
#endif
/* Enable extensions specified by ISO/IEC TR 24731-2:2010.  */
#ifndef __STDC_WANT_LIB_EXT2__
# define __STDC_WANT_LIB_EXT2__ 1
#endif
/* Enable extensions specified by ISO/IEC 24747:2009.  */
#ifndef __STDC_WANT_MATH_SPEC_FUNCS__
# define __STDC_WANT_MATH_SPEC_FUNCS__ 1
#endif
/* Enable extensions on HP NonStop.  */
#ifndef _TANDEM_SOURCE
# define _TANDEM_SOURCE 1
#endif
/* Enable X/Open extensions.  Define to 500 only if necessary
   to make mbstate_t available.  */
#ifndef _XOPEN_SOURCE
/* # undef _XOPEN_SOURCE */
#endif


/* Version number of package */

/* Define WORDS_BIGENDIAN to 1 if your processor stores words with the most
   significant byte first (like Motorola and SPARC, unlike Intel). */
#if defined AC_APPLE_UNIVERSAL_BUILD
# if defined __BIG_ENDIAN__
#  define WORDS_BIGENDIAN 1
# endif
#else
# ifndef WORDS_BIGENDIAN
/* #  undef WORDS_BIGENDIAN */
# endif
#endif

/* Define for Solaris 2.5.1 so the uint32_t typedef from <sys/synch.h>,
   <pthread.h>, or <semaphore.h> is not used. If the typedef were allowed, the
   #define below would cause a syntax error. */
/* #undef _UINT32_T */

/* Define for Solaris 2.5.1 so the uint64_t typedef from <sys/synch.h>,
   <pthread.h>, or <semaphore.h> is not used. If the typedef were allowed, the
   #define below would cause a syntax error. */
/* #undef _UINT64_T */

/* Define for Solaris 2.5.1 so the uint8_t typedef from <sys/synch.h>,
   <pthread.h>, or <semaphore.h> is not used. If the typedef were allowed, the
   #define below would cause a syntax error. */
/* #undef _UINT8_T */

/* Define to the type of a signed integer type of width exactly 16 bits if
   such a type exists and the standard includes do not define it. */
/* #undef int16_t */

/* Define to the type of a signed integer type of width exactly 32 bits if
   such a type exists and the standard includes do not define it. */
/* #undef int32_t */

/* Define to the type of a signed integer type of width exactly 64 bits if
   such a type exists and the standard includes do not define it. */
/* #undef int64_t */

/* Define to the type of a signed integer type of width exactly 8 bits if such
   a type exists and the standard includes do not define it. */
/* #undef int8_t */

/* Define as a signed integer type capable of holding a process identifier. */
/* #undef pid_t */

/* Define as 'unsigned int' if <stddef.h> doesn't define. */
/* #undef size_t */

/* Define to the type of an unsigned integer type of width exactly 16 bits if
   such a type exists and the standard includes do not define it. */
/* #undef uint16_t */

/* Define to the type of an unsigned integer type of width exactly 32 bits if
   such a type exists and the standard includes do not define it. */
/* #undef uint32_t */

/* Define to the type of an unsigned integer type of width exactly 64 bits if
   such a type exists and the standard includes do not define it. */
/* #undef uint64_t */

/* Define to the type of an unsigned integer type of width exactly 8 bits if
   such a type exists and the standard includes do not define it. */
/* #undef uint8_t */

/* Define to the type of an unsigned integer type wide enough to hold a
   pointer, if such a type exists, and if the system does not define it. */
/* #undef uintptr_t */

/* Define as 'fork' if 'vfork' does not work. */
/* #undef vfork */


/* NBCOMPAT template section follows. */

#ifndef LIBNBCOMPAT_HAVE___ATTRIBUTE__
# define __attribute__(x)
#endif

#endif /* <nbcompat/nbconfig.h> included */

