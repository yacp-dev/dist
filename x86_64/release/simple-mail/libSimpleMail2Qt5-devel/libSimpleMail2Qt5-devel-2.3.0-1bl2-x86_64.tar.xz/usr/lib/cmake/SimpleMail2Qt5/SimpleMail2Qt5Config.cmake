# - Config information for SimpleMail
# This file defines:
#
#  SimpleMailQt5_INCLUDE_DIR - the SimpleMail include directory
#  SimpleMailQt5_LIBRARY - Link these to use SimpleMail

SET(prefix "/usr")
SET(exec_prefix "/usr")
SET(SimpleMail2Qt5_FOUND "TRUE")
    
include("${CMAKE_CURRENT_LIST_DIR}/SimpleMail2Qt5Targets.cmake")
