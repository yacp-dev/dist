/*
 * Copyright (C) 2004, 2005 Jean-Yves Lefort
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of Jean-Yves Lefort nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 * CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 * TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef _TRANSLATE_UTIL_H
#define _TRANSLATE_UTIL_H

#include <glib.h>
#include <time.h>

G_BEGIN_DECLS

gboolean	 translate_ascii_strcase_equal	(gconstpointer	 s1,
						 gconstpointer	 s2);
unsigned int	 translate_ascii_strcase_hash	(gconstpointer	 key);

char		*translate_ascii_strcasestr	(const char	*big,
						 const char	*little);
char		*translate_ascii_strcasestr_len	(const char	*big,
						 unsigned int	 big_len,
						 const char	*little);

int		 translate_ascii_strcasecoll	(const char	*s1,
						 const char	*s2);
int		 translate_utf8_strcasecoll	(const char	*s1,
						 const char	*s2);

int		 translate_utf8_strcmp		(const char	*s1,
						 const char	*s2);
int		 translate_utf8_strcasecmp	(const char	*s1,
						 const char	*s2);

char		*translate_utf8_strpbrk		(const char	*p,
						 gssize		 len,
						 const char	*charset);
char		*translate_utf8_strrpbrk	(const char	*p,
						 gssize		 len,
						 const char	*charset);

time_t		 translate_time			(void);

char		*translate_sgml_ref_expand	(const char	*str);

G_END_DECLS

#endif /* _TRANSLATE_UTIL_H */
