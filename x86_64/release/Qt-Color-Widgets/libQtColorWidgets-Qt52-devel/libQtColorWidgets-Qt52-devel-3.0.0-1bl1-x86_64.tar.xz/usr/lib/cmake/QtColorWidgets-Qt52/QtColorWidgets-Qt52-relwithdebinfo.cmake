#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "QtColorWidgets-Qt52" for configuration "RelWithDebInfo"
set_property(TARGET QtColorWidgets-Qt52 APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(QtColorWidgets-Qt52 PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libQtColorWidgets-Qt52.dll.a"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELWITHDEBINFO "Qt5::Widgets"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygQtColorWidgets-Qt52-2.dll"
  )

list(APPEND _cmake_import_check_targets QtColorWidgets-Qt52 )
list(APPEND _cmake_import_check_files_for_QtColorWidgets-Qt52 "${_IMPORT_PREFIX}/lib/libQtColorWidgets-Qt52.dll.a" "${_IMPORT_PREFIX}/bin/cygQtColorWidgets-Qt52-2.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
