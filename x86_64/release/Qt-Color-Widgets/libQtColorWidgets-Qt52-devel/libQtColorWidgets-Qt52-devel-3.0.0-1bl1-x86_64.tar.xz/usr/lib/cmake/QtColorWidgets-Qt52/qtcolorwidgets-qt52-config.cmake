# SPDX-FileCopyrightText: 2013-2023 Mattia Basaglia <dev@dragon.best>
# SPDX-License-Identifier: BSD-2-Clause
include("${CMAKE_CURRENT_LIST_DIR}/qtcolorwidgets-qt52-targets.cmake")
