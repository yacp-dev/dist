#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "mzn" for configuration "RelWithDebInfo"
set_property(TARGET mzn APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(mzn PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libmzn.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygmzn-2.dll"
  )

list(APPEND _cmake_import_check_targets mzn )
list(APPEND _cmake_import_check_files_for_mzn "${_IMPORT_PREFIX}/lib/libmzn.dll.a" "${_IMPORT_PREFIX}/bin/cygmzn-2.dll" )

# Import target "minizinc" for configuration "RelWithDebInfo"
set_property(TARGET minizinc APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(minizinc PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/minizinc.exe"
  )

list(APPEND _cmake_import_check_targets minizinc )
list(APPEND _cmake_import_check_files_for_minizinc "${_IMPORT_PREFIX}/bin/minizinc.exe" )

# Import target "mzn2doc" for configuration "RelWithDebInfo"
set_property(TARGET mzn2doc APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(mzn2doc PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/mzn2doc.exe"
  )

list(APPEND _cmake_import_check_targets mzn2doc )
list(APPEND _cmake_import_check_files_for_mzn2doc "${_IMPORT_PREFIX}/bin/mzn2doc.exe" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
