include "bin_packing_load.mzn";

/**  @group globals.packing
  Returns the load of each bin resulting from packing each item \p i with
  weight \a weight[\p i] into \a bin[\p i], where the load is defined as
  the sum of the weight of the items in each bin.

  Assumptions:

  - forall \p i, \a weight[\p i] >=0
*/
function array [$$B] of var int: bin_packing_load(
  array [$$I] of var $$B: bin,
  array [$$I] of int: weight,
) :: promise_total =
  assert(
    index_set(bin) == index_set(weight),
    "bin_packing_load: the bin and weight arrays must have identical index sets",
    if length(bin) > 0 then
      let {
        array [dom_bounds_array(bin)] of var 0..sum(weight): load :: is_defined_var;
        constraint
          bin_packing_load(index2int(load), index2int(enum2int(bin)), index2int(weight))
            :: defines_var(load);
      } in load
    endif,
  );

/**  @group globals.packing
  Returns the load of each bin resulting from packing each item \p i with
  weight \a weight[\p i] into \a bin[\p i], where the load is defined as
  the sum of the weight of the items in each bin. An item may not be put into any bin,
  in which case \a bin[\p i] is absent.

  Assumptions:

  - forall \p i, \a weight[\p i] >=0
*/
function array [$$B] of var int: bin_packing_load(
  array [$$I] of var opt $$B: bin,
  array [$$I] of int: weight,
) :: promise_total =
  assert(
    index_set(bin) == index_set(weight),
    "bin_packing_load: the bin and weight arrays must have identical index sets",
    if length(bin) > 0 then
      let {
        array [dom_bounds_array(bin)] of var 0..sum(weight): load :: is_defined_var;
        constraint
          bin_packing_load(index2int(load), index2int(enum2int(bin)), index2int(weight))
            :: defines_var(load);
      } in load
    endif,
  );
