predicate fzn_bin_packing_load(
  array [int] of var int: load,
  array [int] of var int: bin,
  array [int] of int: weight,
) =
  sum(load) = sum(weight) /\
    forall (i in index_set(bin)) (
      min(index_set(load)) <= bin[i] /\ bin[i] <= max(index_set(load))
    ) /\
    forall (b in index_set(load)) (load[b] = sum (i in index_set(bin)) (weight[i] * (bin[i] = b)));

%-----------------------------------------------------------------------------%
