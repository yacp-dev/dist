include "bin_packing_load_fn.mzn";

include "fzn_bin_packing_load.mzn";
include "fzn_bin_packing_load_opt.mzn";
include "fzn_bin_packing_load_reif.mzn";

predicate fzn_bin_packing_load(
  array [int] of var int: load,
  array [int] of var int: bin,
  array [int] of int: weight,
);
predicate fzn_bin_packing_load_opt(
  array [int] of var int: load,
  array [int] of var opt int: bin,
  array [int] of int: weight,
);

/**  @group globals.packing
  Requires that each item \p i with weight \a weight[\p i], be put into \a bin[\p i] such
  that the sum of the weight of the items in each bin \p b is equal to
  \a load[\p b].

  Assumptions:

  - forall \p i, \a weight[\p i] >=0

*/
predicate bin_packing_load(
  array [$$B] of var int: load,
  array [$$I] of var $$B: bin,
  array [$$I] of int: weight,
) =
  assert(
    index_set(bin) == index_set(weight),
    "bin_packing_load: the bin and weight arrays must have identical index sets",
    assert(
      length(weight) == 0 \/ lb_array(weight) >= 0,
      "bin_packing_load: the weight must be non-negative",
      fzn_bin_packing_load(index2int(load), index2int(enum2int(bin)), index2int(weight)),
    ),
  );

/**  @group globals.packing
  Requires that each item \p i with weight \a weight[\p i], be put into \a bin[\p i] such
  that the sum of the weight of the items in each bin \p b is equal to
  \a load[\p b]. An item may not be put into any bin, in which case \a bin[\p i] is
  absent.

  Assumptions:

  - forall \p i, \a weight[\p i] >=0

*/
predicate bin_packing_load(
  array [$$B] of var int: load,
  array [$$I] of var opt $$B: bin,
  array [$$I] of int: weight,
) =
  assert(
    index_set(bin) == index_set(weight),
    "bin_packing_load: the bin and weight arrays must have identical index sets",
    assert(
      length(weight) == 0 \/ lb_array(weight) >= 0,
      "bin_packing_load: the weight must be non-negative",
      fzn_bin_packing_load_opt(index2int(load), index2int(enum2int(bin)), index2int(weight)),
    ),
  );
