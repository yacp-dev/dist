#!/bin/sh
# $Id: nonroot.sh,v 1.7 2004/08/09 14:41:14 yamajun Exp $
#
# nonroot.sh -- Add permission to usb device file for run ifp by non-root user

# uid check
if [ ! `id -u` = 0 ]; then
    echo "You are not root.  Cannot run this script."
    exit
fi

case `uname` in
Linux)
    if [ -d /etc/udev/rules.d ]; then

	if [ -f /etc/udev/rules.d/90-iriver.rules ]; then
	    echo "/etc/udev/rules.d/90-iriver.rules already changed."
	    echo "Please modify yourself for your system."
	    exit

	else
	    cat >> /etc/udev/rules.d/90-iriver.rules << EOF
# UDEV rules for iRiver(Astell&Kern) devices
#
# This file must be placed at:
#   /etc/udev/rules.d/90-iriver.rules
#
ACTION!="add", GOTO="iriver_rules_end"

# iFP-100
SUBSYSTEMS=="usb", ATTRS{idVendor}=="4102", ATTRS{idProduct}=="1001", MODE="0666"
# iFP-300
SUBSYSTEMS=="usb", ATTRS{idVendor}=="4102", ATTRS{idProduct}=="1003", MODE="0666"
# iFP-500
SUBSYSTEMS=="usb", ATTRS{idVendor}=="4102", ATTRS{idProduct}=="1005", MODE="0666"
# iFP-700
SUBSYSTEMS=="usb", ATTRS{idVendor}=="4102", ATTRS{idProduct}=="1007", MODE="0666"
# iFP-800
SUBSYSTEMS=="usb", ATTRS{idVendor}=="4102", ATTRS{idProduct}=="1008", MODE="0666"
# iFP-900
SUBSYSTEMS=="usb", ATTRS{idVendor}=="4102", ATTRS{idProduct}=="1009", MODE="0666"
# iFP-1000(?)
SUBSYSTEMS=="usb", ATTRS{idVendor}=="4102", ATTRS{idProduct}=="100a", MODE="0666"
SUBSYSTEMS=="usb", ATTRS{idVendor}=="4102", ATTRS{idProduct}=="1010", MODE="0666"
# T10(?)
SUBSYSTEMS=="usb", ATTRS{idVendor}=="4102", ATTRS{idProduct}=="1011", MODE="0666"
SUBSYSTEMS=="usb", ATTRS{idVendor}=="4102", ATTRS{idProduct}=="1113", MODE="0666"
SUBSYSTEMS=="usb", ATTRS{idVendor}=="4102", ATTRS{idProduct}=="1117", MODE="0666"


LABEL="iriver_rules_end"

EOF
	    echo "/etc/udev/rules.d/90-iriver.rules changed."

	    udevadm control --reload
	fi

    elif [ -d /etc/hotplug ]; then

	# cite from giriver README.

	# if group "ifp" exist, groupadd exit with error message.
	/usr/sbin/groupadd ifp
	echo
	echo "****************************************************************"
	echo "Please add iFP users to group \"ifp\"."
	echo "****************************************************************"
	echo

	if egrep -q '^ifpdev[[:blank:]]' /etc/hotplug/usb.usermap; then
	    echo "/etc/hotplug/usb.usermap already changed."
	    echo "Please modify yourself for your system."
	    exit

	else
	    cat >> /etc/hotplug/usb.usermap << EOF

# for iRiver iFP MP3 player(iFP 1xx series - N10)
ifpdev 0x0003 0x4102 0x1001 0x0000 0x0000 0x00 0x00 0x00 0x00 0x00 0x00 0x00000000
ifpdev 0x0003 0x4102 0x1003 0x0000 0x0000 0x00 0x00 0x00 0x00 0x00 0x00 0x00000000
ifpdev 0x0003 0x4102 0x1005 0x0000 0x0000 0x00 0x00 0x00 0x00 0x00 0x00 0x00000000
ifpdev 0x0003 0x4102 0x1007 0x0000 0x0000 0x00 0x00 0x00 0x00 0x00 0x00 0x00000000
ifpdev 0x0003 0x4102 0x1008 0x0000 0x0000 0x00 0x00 0x00 0x00 0x00 0x00 0x00000000
ifpdev 0x0003 0x4102 0x1009 0x0000 0x0000 0x00 0x00 0x00 0x00 0x00 0x00 0x00000000
ifpdev 0x0003 0x4102 0x1010 0x0000 0x0000 0x00 0x00 0x00 0x00 0x00 0x00 0x00000000
ifpdev 0x0003 0x4102 0x1011 0x0000 0x0000 0x00 0x00 0x00 0x00 0x00 0x00 0x00000000

EOF
	    echo "/etc/hotplug/usb.usermap changed."
	fi

	if [ ! -d /etc/hotplug/usb ]; then
	    mkdir /etc/hotplug/usb
	fi
	if [ ! -x /etc/hotplug/usb/ifpdev ]; then
	    echo "/etc/hotplug/usb/ifpdev added"; \
	    cat > /etc/hotplug/usb/ifpdev << EOF
#!/bin/sh
# /etc/hotplug/usb/ifpdev

chgrp ifp \$DEVICE
chmod g+rw \$DEVICE
EOF
	    chmod 755 /etc/hotplug/usb/ifpdev
	fi

    else
	echo "This script need udev or hotplugging support."
	exit
    fi
    ;;

FreeBSD)
    if [ -f /etc/defaults/devfs.rules ]; then
	# for after FreeBSD 5.2-RELEASE.
	if egrep -q 'vendor.+0x4102' /etc/devd/iriver-ifp.conf; then
	    echo "****************************************************************"
	    echo "/etc/devd/iriver-ifp.conf already created."
	    echo "Please modify yourself for your system."

	else
	    echo "create /etc/devd/iriver-ifp.conf";
	    cat >> /etc/devd/iriver-ifp.conf << EOF
# iRiver(known as Astell & Kern) iFP devices
notify 100 {
	match "system"		"USB";
	match "subsystem"	"INTERFACE";
	match "type"		"ATTACH";
	match "cdev"		"ugen[0-9].[0-9]";
	match "vendor"		"0x4102";
	match "product" "(0x1001|0x1003|0x1005|0x1007|0x1008|0x1009|0x100a|0x1010|0x1011|0x1013|0x1017)";
	action "chown -L root:operator /dev/\$cdev && chmod -L 660 /dev/\$cdev";
};

EOF
	    service devd restart
	fi
		
    else
	# for 4.*
	chmod g+rw /dev/usb* /dev/ugen*
    fi

    echo
    echo "****************************************************************"
    echo "Please add iFP users to group \"operator\"."
    echo "****************************************************************"
    echo
    ;;

NetBSD)
    chmod g+rw /dev/usb* /dev/ugen*

    echo
    echo "****************************************************************"
    echo "Please add iFP users to group \"wheel\"."
    echo "****************************************************************"
    echo
    ;;

Darwin)
    # Mac OS X
    echo "No need to configuration for run ifp by non-root user on Mac OS X"
    ;;

*)
    echo "Sorry, this script did not support your OS."
    ;;
esac

