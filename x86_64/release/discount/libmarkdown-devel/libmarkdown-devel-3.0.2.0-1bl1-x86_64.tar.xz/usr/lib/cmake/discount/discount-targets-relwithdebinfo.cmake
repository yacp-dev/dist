#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "discount::libmarkdown" for configuration "RelWithDebInfo"
set_property(TARGET discount::libmarkdown APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(discount::libmarkdown PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libmarkdown.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygmarkdown-3.dll"
  )

list(APPEND _cmake_import_check_targets discount::libmarkdown )
list(APPEND _cmake_import_check_files_for_discount::libmarkdown "${_IMPORT_PREFIX}/lib/libmarkdown.dll.a" "${_IMPORT_PREFIX}/bin/cygmarkdown-3.dll" )

# Import target "discount::markdown" for configuration "RelWithDebInfo"
set_property(TARGET discount::markdown APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(discount::markdown PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/markdown.exe"
  )

list(APPEND _cmake_import_check_targets discount::markdown )
list(APPEND _cmake_import_check_files_for_discount::markdown "${_IMPORT_PREFIX}/bin/markdown.exe" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
