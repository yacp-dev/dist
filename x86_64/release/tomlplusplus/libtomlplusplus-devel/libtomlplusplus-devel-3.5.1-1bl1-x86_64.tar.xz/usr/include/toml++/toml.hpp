//# This file is a part of toml++ and is subject to the the terms of the MIT license.
//# Copyright (c) Mark Gillard <mark.gillard@outlook.com.au>
//# See https://github.com/marzer/tomlplusplus/blob/master/LICENSE for the full license text.
// SPDX-License-Identifier: MIT
#ifndef TOMLPLUSPLUS_HPP
#define TOMLPLUSPLUS_HPP

#define INCLUDE_TOMLPLUSPLUS_H // old guard name used pre-v3
#define TOMLPLUSPLUS_H		   // guard name used in the legacy toml.h

#include "impl/preprocessor.hpp"

TOML_PUSH_WARNINGS;
TOML_DISABLE_SPAM_WARNINGS;
TOML_DISABLE_SUGGEST_ATTR_WARNINGS;
#if !TOML_PEDANTIC
TOML_DISABLE_SWITCH_WARNINGS;
TOML_DISABLE_ARITHMETIC_WARNINGS;
TOML_DISABLE_ANALYSIS_WARNINGS;
#endif

// misc warning false-positives
TOML_DISABLE_MSVC_WARNING(5031); // #pragma warning(pop): likely mismatch
#if TOML_SHARED_LIB
TOML_DISABLE_MSVC_WARNING(4251); // dll exports for std lib types
#endif
TOML_DISABLE_CLANG_WARNING("-Wheader-hygiene");
TOML_DISABLE_CLANG_WARNING("-Wdocumentation");
TOML_DISABLE_CLANG_WARNING("-Wdocumentation-unknown-command");
TOML_DISABLE_CLANG_WARNING("-Wc++20-extensions");
#if TOML_CLANG == 13
TOML_DISABLE_CLANG_WARNING("-Wreserved-identifier");
#endif

// IWYU pragma: begin_exports
#include "impl/std_new.hpp"
#include "impl/std_string.hpp"
#include "impl/std_optional.hpp"
#include "impl/forward_declarations.hpp"
#include "impl/print_to_stream.hpp"
#include "impl/source_region.hpp"
#include "impl/date_time.hpp"
#include "impl/at_path.hpp"
#include "impl/path.hpp"
#include "impl/node.hpp"
#include "impl/node_view.hpp"
#include "impl/value.hpp"
#include "impl/make_node.hpp"
#include "impl/array.hpp"
#include "impl/key.hpp"
#include "impl/table.hpp"
#include "impl/unicode.hpp"
#include "impl/parse_error.hpp"
#include "impl/parse_result.hpp"
#include "impl/parser.hpp"
#include "impl/formatter.hpp"
#include "impl/toml_formatter.hpp"
#include "impl/json_formatter.hpp"
#include "impl/yaml_formatter.hpp"
// IWYU pragma: end_exports

#if TOML_IMPLEMENTATION

#include "impl/std_string.inl"
#include "impl/print_to_stream.inl"
#include "impl/node.inl"
#include "impl/at_path.inl"
#include "impl/path.inl"
#include "impl/array.inl"
#include "impl/table.inl"
#include "impl/unicode.inl"
#include "impl/parser.inl"
#include "impl/formatter.inl"
#include "impl/toml_formatter.inl"
#include "impl/json_formatter.inl"
#include "impl/yaml_formatter.inl"

#endif // TOML_IMPLEMENTATION

TOML_POP_WARNINGS;

// macro hygiene
#if TOML_UNDEF_MACROS
#undef TOML_ABI_NAMESPACE_BOOL
#undef TOML_ABI_NAMESPACE_END
#undef TOML_ABI_NAMESPACE_START
#undef TOML_ABI_NAMESPACES
#undef TOML_ABSTRACT_INTERFACE
#undef TOML_ALWAYS_INLINE
#undef TOML_ANON_NAMESPACE
#undef TOML_ANON_NAMESPACE_END
#undef TOML_ANON_NAMESPACE_START
#undef TOML_ARCH_AMD64
#undef TOML_ARCH_ARM
#undef TOML_ARCH_ARM32
#undef TOML_ARCH_ARM64
#undef TOML_ARCH_BITNESS
#undef TOML_ARCH_ITANIUM
#undef TOML_ARCH_X64
#undef TOML_ARCH_X86
#undef TOML_ASSERT
#undef TOML_ASSERT_ASSUME
#undef TOML_ASSUME
#undef TOML_ASYMMETRICAL_EQUALITY_OPS
#undef TOML_ATTR
#undef TOML_CLANG
#undef TOML_CLOSED_ENUM
#undef TOML_CLOSED_FLAGS_ENUM
#undef TOML_COMPILER_HAS_EXCEPTIONS
#undef TOML_COMPILER_HAS_RTTI
#undef TOML_CONST
#undef TOML_CONST_GETTER
#undef TOML_CONST_INLINE_GETTER
#undef TOML_CONSTRAINED_TEMPLATE
#undef TOML_CPP
#undef TOML_DECLSPEC
#undef TOML_DELETE_DEFAULTS
#undef TOML_DISABLE_ANALYSIS_WARNINGS
#undef TOML_DISABLE_ARITHMETIC_WARNINGS
#undef TOML_DISABLE_CLANG_WARNING
#undef TOML_DISABLE_CODE_ANALYSIS_WARNINGS
#undef TOML_DISABLE_GCC_WARNING
#undef TOML_DISABLE_MSVC_WARNING
#undef TOML_DISABLE_SPAM_WARNINGS
#undef TOML_DISABLE_SUGGEST_ATTR_WARNINGS
#undef TOML_DISABLE_SWITCH_WARNINGS
#undef TOML_DISABLE_WARNINGS
#undef TOML_DOXYGEN
#undef TOML_EMPTY_BASES
#undef TOML_ENABLE_IF
#undef TOML_ENABLE_WARNINGS
#undef TOML_EVAL_BOOL_0
#undef TOML_EVAL_BOOL_1
#undef TOML_EXPORTED_CONSTANT
#undef TOML_EXTERNAL_LINKAGE
#undef TOML_FLAGS_ENUM
#undef TOML_FLOAT128
#undef TOML_GCC
#undef TOML_GCC_LIKE
#undef TOML_HAS_ATTR
#undef TOML_HAS_BUILTIN
#undef TOML_HAS_CHAR8
#undef TOML_HAS_CPP_ATTR
#undef TOML_HAS_CUSTOM_OPTIONAL_TYPE
#undef TOML_HAS_FEATURE
#undef TOML_HAS_FLOAT_CHARCONV
#undef TOML_HAS_INCLUDE
#undef TOML_HAS_SSE2
#undef TOML_HIDDEN_CONSTRAINT
#undef TOML_ICC
#undef TOML_ICC_CL
#undef TOML_IMPL_NAMESPACE_END
#undef TOML_IMPL_NAMESPACE_START
#undef TOML_IMPLEMENTATION
#undef TOML_INCLUDE_WINDOWS_H
#undef TOML_INLINE_GETTER
#undef TOML_INT128
#undef TOML_INTELLISENSE
#undef TOML_INTERNAL_LINKAGE
#undef TOML_LANG_AT_LEAST
#undef TOML_LANG_EFFECTIVE_VERSION
#undef TOML_LANG_HIGHER_THAN
#undef TOML_LANG_UNRELEASED
#undef TOML_LAUNDER
#undef TOML_LIFETIME_HOOKS
#undef TOML_LIKELY
#undef TOML_LIKELY_CASE
#undef TOML_LINUX
#undef TOML_MAKE_FLAGS
#undef TOML_MAKE_FLAGS_1
#undef TOML_MAKE_FLAGS_2
#undef TOML_MAKE_STRING
#undef TOML_MAKE_STRING_1
#undef TOML_MAKE_VERSION
#undef TOML_MSVC
#undef TOML_MSVC_LIKE
#undef TOML_NAMESPACE
#undef TOML_NEVER_INLINE
#undef TOML_NODISCARD
#undef TOML_NODISCARD_CTOR
#undef TOML_NOEXCEPT_AS
#undef TOML_NVCC
#undef TOML_OPEN_ENUM
#undef TOML_OPEN_FLAGS_ENUM
#undef TOML_PARSER_TYPENAME
#undef TOML_PEDANTIC
#undef TOML_POP_WARNINGS
#undef TOML_PRAGMA_CLANG
#undef TOML_PRAGMA_GCC
#undef TOML_PRAGMA_MSVC
#undef TOML_PURE
#undef TOML_PURE_GETTER
#undef TOML_PURE_INLINE_GETTER
#undef TOML_PUSH_WARNINGS
#undef TOML_REQUIRES
#undef TOML_RETURN_BOOL_FROM_FOR_EACH_BROKEN
#undef TOML_RETURN_BOOL_FROM_FOR_EACH_BROKEN_MESSAGE
#undef TOML_SA_LIST_BEG
#undef TOML_SA_LIST_END
#undef TOML_SA_LIST_NEW
#undef TOML_SA_LIST_NXT
#undef TOML_SA_LIST_SEP
#undef TOML_SA_NATIVE_VALUE_TYPE_LIST
#undef TOML_SA_NEWLINE
#undef TOML_SA_NODE_TYPE_LIST
#undef TOML_SA_UNWRAPPED_NODE_TYPE_LIST
#undef TOML_SA_VALUE_EXACT_FUNC_MESSAGE
#undef TOML_SA_VALUE_FUNC_MESSAGE
#undef TOML_SA_VALUE_MESSAGE_CHRONO_LOSSLESS
#undef TOML_SA_VALUE_MESSAGE_CHRONO_LOSSY
#undef TOML_SA_VALUE_MESSAGE_CONST_CHAR8
#undef TOML_SA_VALUE_MESSAGE_LOSSLESS
#undef TOML_SA_VALUE_MESSAGE_LOSSY
#undef TOML_SA_VALUE_MESSAGE_STRING_LIKE
#undef TOML_SA_VALUE_MESSAGE_U8STRING
#undef TOML_SA_VALUE_MESSAGE_U8STRING_VIEW
#undef TOML_SA_VALUE_MESSAGE_VIEW
#undef TOML_SA_VALUE_MESSAGE_WSTRING
#undef TOML_SIMPLE_STATIC_ASSERT_MESSAGES
#undef TOML_TRIVIAL_ABI
#undef TOML_UINT128
#undef TOML_UNIX
#undef TOML_UNLIKELY
#undef TOML_UNLIKELY_CASE
#undef TOML_UNREACHABLE
#undef TOML_UNUSED
#undef TOML_WINDOWS
#endif

#endif // TOMLPLUSPLUS_HPP
