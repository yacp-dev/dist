#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "libversion::libversion" for configuration "RelWithDebInfo"
set_property(TARGET libversion::libversion APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(libversion::libversion PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libversion.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygversion-1.dll"
  )

list(APPEND _cmake_import_check_targets libversion::libversion )
list(APPEND _cmake_import_check_files_for_libversion::libversion "${_IMPORT_PREFIX}/lib/libversion.dll.a" "${_IMPORT_PREFIX}/bin/cygversion-1.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
