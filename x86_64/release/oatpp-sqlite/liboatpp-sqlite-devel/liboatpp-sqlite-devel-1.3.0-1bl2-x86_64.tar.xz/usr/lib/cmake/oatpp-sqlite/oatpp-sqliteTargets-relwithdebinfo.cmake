#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "oatpp::oatpp-sqlite" for configuration "RelWithDebInfo"
set_property(TARGET oatpp::oatpp-sqlite APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(oatpp::oatpp-sqlite PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/liboatpp-sqlite.dll.a"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELWITHDEBINFO "oatpp::oatpp;oatpp::oatpp-test"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygoatpp-sqlite-1.dll"
  )

list(APPEND _cmake_import_check_targets oatpp::oatpp-sqlite )
list(APPEND _cmake_import_check_files_for_oatpp::oatpp-sqlite "${_IMPORT_PREFIX}/lib/liboatpp-sqlite.dll.a" "${_IMPORT_PREFIX}/bin/cygoatpp-sqlite-1.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
