/**************************************************************************
 FreeSockets - Portable C++ classes for IP(sockets) applications. (v0.3)
 Copyright (C) 2000-2001 Rafael Guterres Jeffman
               2002-2003 Al Riddoch <alriddoch@zepler.org>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

**************************************************************************/

/**
 * This software package has been extensively modified by members of the
 * Worldforge Project. See the file ChangeLog for details.
 *
 * $Id$
 *
 */
#ifndef RGJ_FREE_SOCKET_CONFIG_H_
#define RGJ_FREE_SOCKET_CONFIG_H_

#include <unistd.h>
#include <sys/time.h>

#if 0
  // No windows headers required yet.
#endif
#if 1
  #include <sys/socket.h>
  #include <netinet/in.h>
#endif

typedef socklen_t SOCKLEN;
typedef int SOCKET_TYPE;

#define SOCKET_BLOCK_ERROR EINPROGRESS

#endif // RGJ_FREE_SOCKET_CONFIG_H_
