#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Zopfli::libzopfli" for configuration "RelWithDebInfo"
set_property(TARGET Zopfli::libzopfli APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(Zopfli::libzopfli PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libzopfli.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygzopfli-1.dll"
  )

list(APPEND _cmake_import_check_targets Zopfli::libzopfli )
list(APPEND _cmake_import_check_files_for_Zopfli::libzopfli "${_IMPORT_PREFIX}/lib/libzopfli.dll.a" "${_IMPORT_PREFIX}/bin/cygzopfli-1.dll" )

# Import target "Zopfli::libzopflipng" for configuration "RelWithDebInfo"
set_property(TARGET Zopfli::libzopflipng APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(Zopfli::libzopflipng PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libzopflipng.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygzopflipng-1.dll"
  )

list(APPEND _cmake_import_check_targets Zopfli::libzopflipng )
list(APPEND _cmake_import_check_files_for_Zopfli::libzopflipng "${_IMPORT_PREFIX}/lib/libzopflipng.dll.a" "${_IMPORT_PREFIX}/bin/cygzopflipng-1.dll" )

# Import target "Zopfli::zopfli" for configuration "RelWithDebInfo"
set_property(TARGET Zopfli::zopfli APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(Zopfli::zopfli PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/zopfli.exe"
  )

list(APPEND _cmake_import_check_targets Zopfli::zopfli )
list(APPEND _cmake_import_check_files_for_Zopfli::zopfli "${_IMPORT_PREFIX}/bin/zopfli.exe" )

# Import target "Zopfli::zopflipng" for configuration "RelWithDebInfo"
set_property(TARGET Zopfli::zopflipng APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(Zopfli::zopflipng PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/zopflipng.exe"
  )

list(APPEND _cmake_import_check_targets Zopfli::zopflipng )
list(APPEND _cmake_import_check_files_for_Zopfli::zopflipng "${_IMPORT_PREFIX}/bin/zopflipng.exe" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
