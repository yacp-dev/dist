/*  Copyright (C) CZ.NIC, z.s.p.o. and contributors
 *  SPDX-License-Identifier: GPL-2.0-or-later
 *  For more information, see <https://www.knot-dns.cz/>
 */

#pragma once

#define KNOT_VERSION_MAJOR 3
#define KNOT_VERSION_MINOR 6
#define KNOT_VERSION_PATCH 0x02

#define KNOT_VERSION_HEX ((KNOT_VERSION_MAJOR << 16) | \
                          (KNOT_VERSION_MINOR <<  8) | \
                          (KNOT_VERSION_PATCH))
