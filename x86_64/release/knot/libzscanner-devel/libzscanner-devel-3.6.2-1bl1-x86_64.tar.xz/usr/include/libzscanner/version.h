/*  Copyright (C) CZ.NIC, z.s.p.o. and contributors
 *  SPDX-License-Identifier: GPL-2.0-or-later
 *  For more information, see <https://www.knot-dns.cz/>
 */

#pragma once

#define ZSCANNER_VERSION_MAJOR 3
#define ZSCANNER_VERSION_MINOR 6
#define ZSCANNER_VERSION_PATCH 0x02

#define ZSCANNER_VERSION_HEX ((ZSCANNER_VERSION_MAJOR << 16) | \
                              (ZSCANNER_VERSION_MINOR <<  8) | \
                              (ZSCANNER_VERSION_PATCH))
