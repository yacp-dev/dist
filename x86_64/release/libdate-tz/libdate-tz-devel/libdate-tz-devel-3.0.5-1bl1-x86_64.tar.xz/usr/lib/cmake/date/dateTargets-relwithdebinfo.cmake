#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "date::date-tz" for configuration "RelWithDebInfo"
set_property(TARGET date::date-tz APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(date::date-tz PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libdate-tz.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygdate-tz-3.dll"
  )

list(APPEND _cmake_import_check_targets date::date-tz )
list(APPEND _cmake_import_check_files_for_date::date-tz "${_IMPORT_PREFIX}/lib/libdate-tz.dll.a" "${_IMPORT_PREFIX}/bin/cygdate-tz-3.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
