#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "caffe" for configuration "RelWithDebInfo"
set_property(TARGET caffe APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(caffe PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libcaffe.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygcaffe-1.0.0.dll"
  )

list(APPEND _cmake_import_check_targets caffe )
list(APPEND _cmake_import_check_files_for_caffe "${_IMPORT_PREFIX}/lib/libcaffe.dll.a" "${_IMPORT_PREFIX}/bin/cygcaffe-1.0.0.dll" )

# Import target "proto" for configuration "RelWithDebInfo"
set_property(TARGET proto APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(proto PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libcaffeproto.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygcaffeproto-1.0.0.dll"
  )

list(APPEND _cmake_import_check_targets proto )
list(APPEND _cmake_import_check_files_for_proto "${_IMPORT_PREFIX}/lib/libcaffeproto.dll.a" "${_IMPORT_PREFIX}/bin/cygcaffeproto-1.0.0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
