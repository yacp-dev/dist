#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "cnats::nats" for configuration "RelWithDebInfo"
set_property(TARGET cnats::nats APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(cnats::nats PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libnats.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygnats-3.15.dll"
  )

list(APPEND _cmake_import_check_targets cnats::nats )
list(APPEND _cmake_import_check_files_for_cnats::nats "${_IMPORT_PREFIX}/lib/libnats.dll.a" "${_IMPORT_PREFIX}/bin/cygnats-3.15.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
