#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "WDC::libwdc" for configuration "RelWithDebInfo"
set_property(TARGET WDC::libwdc APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(WDC::libwdc PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libwdc.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygwdc-1.dll"
  )

list(APPEND _cmake_import_check_targets WDC::libwdc )
list(APPEND _cmake_import_check_files_for_WDC::libwdc "${_IMPORT_PREFIX}/lib/libwdc.dll.a" "${_IMPORT_PREFIX}/bin/cygwdc-1.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
