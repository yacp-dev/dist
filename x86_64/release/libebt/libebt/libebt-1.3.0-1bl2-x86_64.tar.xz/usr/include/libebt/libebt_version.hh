/* vim: set sw=4 sts=4 et foldmethod=syntax : */


/// Include guard.
#ifndef HAVE_THE_LIBEBT_LIBEBT_VERSION_HH
#define HAVE_THE_LIBEBT_LIBEBT_VERSION_HH 1

/** \file
 * Defines constants giving the libebt version number.
 */

/// The major version (eg 0.4.1 -> 0)
#define LIBEBT_VERSION_MAJOR 1

/// The minor version (eg 0.4.1 -> 4)
#define LIBEBT_VERSION_MINOR 3

/// The micro version (eg 0.4.1 -> 1)
#define LIBEBT_VERSION_MICRO 0

/// The version, two digits per part (eg 1.3.5 -> 10305)
#define LIBEBT_VERSION ((100 * 100 * LIBEBT_VERSION_MAJOR) \
        + (100 * LIBEBT_VERSION_MINOR) + LIBEBT_VERSION_MICRO)

#endif
