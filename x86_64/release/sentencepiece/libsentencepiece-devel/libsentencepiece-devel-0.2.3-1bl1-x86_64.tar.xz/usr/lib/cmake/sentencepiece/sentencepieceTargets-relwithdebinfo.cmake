#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "sentencepiece::sentencepiece" for configuration "RelWithDebInfo"
set_property(TARGET sentencepiece::sentencepiece APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(sentencepiece::sentencepiece PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libsentencepiece.dll.a"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELWITHDEBINFO "absl::status;absl::statusor;absl::status_builder;absl::strings;absl::flags_parse;absl::log_initialize;absl::synchronization;absl::time"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygsentencepiece-0.dll"
  )

list(APPEND _cmake_import_check_targets sentencepiece::sentencepiece )
list(APPEND _cmake_import_check_files_for_sentencepiece::sentencepiece "${_IMPORT_PREFIX}/lib/libsentencepiece.dll.a" "${_IMPORT_PREFIX}/bin/cygsentencepiece-0.dll" )

# Import target "sentencepiece::sentencepiece_train" for configuration "RelWithDebInfo"
set_property(TARGET sentencepiece::sentencepiece_train APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(sentencepiece::sentencepiece_train PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libsentencepiece_train.dll.a"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELWITHDEBINFO "absl::status;absl::statusor;absl::status_builder;absl::strings;absl::flags_parse;absl::log_initialize;absl::synchronization;absl::time;sentencepiece::sentencepiece"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygsentencepiece_train-0.dll"
  )

list(APPEND _cmake_import_check_targets sentencepiece::sentencepiece_train )
list(APPEND _cmake_import_check_files_for_sentencepiece::sentencepiece_train "${_IMPORT_PREFIX}/lib/libsentencepiece_train.dll.a" "${_IMPORT_PREFIX}/bin/cygsentencepiece_train-0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
