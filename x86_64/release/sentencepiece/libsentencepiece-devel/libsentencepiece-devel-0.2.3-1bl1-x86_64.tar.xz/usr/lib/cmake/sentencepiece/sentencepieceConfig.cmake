# sentencepieceConfig.cmake
# Config file for the sentencepiece package
# It defines the following targets:
#   sentencepiece::sentencepiece
#   sentencepiece::sentencepiece_train
#   sentencepiece::sentencepiece-static (if static build is enabled)
#   sentencepiece::sentencepiece_train-static (if static build is enabled)


####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was sentencepieceConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

# Use original install prefix when loaded through a "/usr move"
# cross-prefix symbolic link such as /lib -> /usr/lib.
get_filename_component(_realCurr "${CMAKE_CURRENT_LIST_DIR}" REALPATH)
get_filename_component(_realOrig "/usr/lib/cmake/sentencepiece" REALPATH)
if(_realCurr STREQUAL _realOrig)
  set(PACKAGE_PREFIX_DIR "/usr")
endif()
unset(_realOrig)
unset(_realCurr)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

include(CMakeFindDependencyMacro)

find_dependency(Threads)

if ("package" STREQUAL "package")
  find_dependency(Protobuf)
endif()

if ("package" STREQUAL "package")
  find_dependency(absl)
endif()

if ("OFF" AND "")
  find_dependency(ICU 4.4 COMPONENTS i18n data uc)
endif()

include("${CMAKE_CURRENT_LIST_DIR}/sentencepieceTargets.cmake")

check_required_components(sentencepiece)
