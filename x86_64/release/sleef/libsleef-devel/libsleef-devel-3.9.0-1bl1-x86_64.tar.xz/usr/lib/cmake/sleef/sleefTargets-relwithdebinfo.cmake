#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "sleef::sleefscalar" for configuration "RelWithDebInfo"
set_property(TARGET sleef::sleefscalar APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(sleef::sleefscalar PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libsleefscalar.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygsleefscalar-3.dll"
  )

list(APPEND _cmake_import_check_targets sleef::sleefscalar )
list(APPEND _cmake_import_check_files_for_sleef::sleefscalar "${_IMPORT_PREFIX}/lib/libsleefscalar.dll.a" "${_IMPORT_PREFIX}/bin/cygsleefscalar-3.dll" )

# Import target "sleef::sleef" for configuration "RelWithDebInfo"
set_property(TARGET sleef::sleef APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(sleef::sleef PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libsleef.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygsleef-3.dll"
  )

list(APPEND _cmake_import_check_targets sleef::sleef )
list(APPEND _cmake_import_check_files_for_sleef::sleef "${_IMPORT_PREFIX}/lib/libsleef.dll.a" "${_IMPORT_PREFIX}/bin/cygsleef-3.dll" )

# Import target "sleef::sleefdft" for configuration "RelWithDebInfo"
set_property(TARGET sleef::sleefdft APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(sleef::sleefdft PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libsleefdft.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygsleefdft-3.dll"
  )

list(APPEND _cmake_import_check_targets sleef::sleefdft )
list(APPEND _cmake_import_check_files_for_sleef::sleefdft "${_IMPORT_PREFIX}/lib/libsleefdft.dll.a" "${_IMPORT_PREFIX}/bin/cygsleefdft-3.dll" )

# Import target "sleef::sleefquad" for configuration "RelWithDebInfo"
set_property(TARGET sleef::sleefquad APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(sleef::sleefquad PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libsleefquad.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygsleefquad-3.dll"
  )

list(APPEND _cmake_import_check_targets sleef::sleefquad )
list(APPEND _cmake_import_check_files_for_sleef::sleefquad "${_IMPORT_PREFIX}/lib/libsleefquad.dll.a" "${_IMPORT_PREFIX}/bin/cygsleefquad-3.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
