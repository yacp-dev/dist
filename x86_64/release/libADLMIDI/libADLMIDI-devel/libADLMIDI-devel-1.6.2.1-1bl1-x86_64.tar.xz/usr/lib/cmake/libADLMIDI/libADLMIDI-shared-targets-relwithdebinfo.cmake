#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "libADLMIDI::ADLMIDI_shared" for configuration "RelWithDebInfo"
set_property(TARGET libADLMIDI::ADLMIDI_shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(libADLMIDI::ADLMIDI_shared PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libADLMIDI.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygADLMIDI-1.dll"
  )

list(APPEND _cmake_import_check_targets libADLMIDI::ADLMIDI_shared )
list(APPEND _cmake_import_check_files_for_libADLMIDI::ADLMIDI_shared "${_IMPORT_PREFIX}/lib/libADLMIDI.dll.a" "${_IMPORT_PREFIX}/bin/cygADLMIDI-1.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
