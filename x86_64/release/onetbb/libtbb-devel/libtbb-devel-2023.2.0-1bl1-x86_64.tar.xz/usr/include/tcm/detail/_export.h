/*
   Copyright (c) 2023 Intel Corporation
   Copyright (c) 2026 UXL Foundation Contributors

   SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
*/

#ifndef __TCM_EXPORT_HEADER
#define __TCM_EXPORT_HEADER

#if defined(_WIN32) || defined(_WIN64) || defined(__CYGWIN__)
  #if defined(tcm_EXPORTS)
    #define __TCM_EXPORT __declspec(dllexport)
  #else
    #define __TCM_EXPORT __declspec(dllimport)
  #endif
#else
  #define __TCM_EXPORT __attribute__((visibility("default")))
#endif

#endif // __EXPORT_HEADER
