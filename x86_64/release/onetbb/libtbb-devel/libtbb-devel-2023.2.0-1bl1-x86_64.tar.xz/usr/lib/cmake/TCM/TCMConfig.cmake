include(${CMAKE_CURRENT_LIST_DIR}/TCMTargets.cmake)
