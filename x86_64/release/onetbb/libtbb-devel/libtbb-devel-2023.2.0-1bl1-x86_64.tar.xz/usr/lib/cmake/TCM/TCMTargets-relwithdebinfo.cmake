#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "TCM::tcm" for configuration "RelWithDebInfo"
set_property(TARGET TCM::tcm APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(TCM::tcm PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libtcm.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygtcm-1.dll"
  )

list(APPEND _cmake_import_check_targets TCM::tcm )
list(APPEND _cmake_import_check_files_for_TCM::tcm "${_IMPORT_PREFIX}/lib/libtcm.dll.a" "${_IMPORT_PREFIX}/bin/cygtcm-1.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
