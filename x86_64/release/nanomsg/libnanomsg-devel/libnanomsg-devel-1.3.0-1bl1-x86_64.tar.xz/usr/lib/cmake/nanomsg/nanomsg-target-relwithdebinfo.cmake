#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "nanomsg" for configuration "RelWithDebInfo"
set_property(TARGET nanomsg APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(nanomsg PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libnanomsg.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygnanomsg-7.dll"
  )

list(APPEND _cmake_import_check_targets nanomsg )
list(APPEND _cmake_import_check_files_for_nanomsg "${_IMPORT_PREFIX}/lib/libnanomsg.dll.a" "${_IMPORT_PREFIX}/bin/cygnanomsg-7.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
