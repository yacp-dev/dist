/* include/xmi_config.h.  Generated from xmi_config.h.in by configure.  */
/*
Copyright (C) 2010-2019 Tom Schoonjans and Laszlo Vincze

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef XMI_MSIM_CONFIG_H
#define XMI_MSIM_CONFIG_H

#define XMI_MSIM_HAVE_EASYRNG /**/
/* #undef XMI_MSIM_HAVE_FGSL10 */
/* #undef XMI_MSIM_HAVE_FGSL11 */

#define XMI_MSIM_HAVE_LIBSOUP /**/

/* #undef XMI_MSIM_HAVE_GUI */

/* #undef XMI_MSIM_HAVE_JSONGLIB */

/* #undef XMI_MSIM_MAC_INTEGRATION */

#define XMI_MSIM_HAVE_GOOGLE_ANALYTICS /**/

/* #undef XMI_MSIM_HAVE_OPENMPI */

/* #undef XMI_MSIM_HAVE_METAL */

#define XMI_MSIM_HAVE_OPENCL /**/

#endif
