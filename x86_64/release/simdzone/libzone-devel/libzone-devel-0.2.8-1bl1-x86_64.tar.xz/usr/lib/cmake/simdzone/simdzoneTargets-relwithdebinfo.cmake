#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "simdzone::zone" for configuration "RelWithDebInfo"
set_property(TARGET simdzone::zone APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(simdzone::zone PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libzone.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygzone-0.dll"
  )

list(APPEND _cmake_import_check_targets simdzone::zone )
list(APPEND _cmake_import_check_files_for_simdzone::zone "${_IMPORT_PREFIX}/lib/libzone.dll.a" "${_IMPORT_PREFIX}/bin/cygzone-0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
