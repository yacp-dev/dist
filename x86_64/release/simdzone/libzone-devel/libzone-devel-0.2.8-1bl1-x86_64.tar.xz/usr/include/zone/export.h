
#ifndef ZONE_EXPORT_H
#define ZONE_EXPORT_H

#ifdef ZONE_STATIC_DEFINE
#  define ZONE_EXPORT
#  define ZONE_NO_EXPORT
#else
#  ifndef ZONE_EXPORT
#    ifdef zone_EXPORTS
        /* We are building this library */
#      define ZONE_EXPORT __declspec(dllexport)
#    else
        /* We are using this library */
#      define ZONE_EXPORT __declspec(dllimport)
#    endif
#  endif

#  ifndef ZONE_NO_EXPORT
#    define ZONE_NO_EXPORT 
#  endif
#endif

#ifndef ZONE_DEPRECATED
#  define ZONE_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef ZONE_DEPRECATED_EXPORT
#  define ZONE_DEPRECATED_EXPORT ZONE_EXPORT ZONE_DEPRECATED
#endif

#ifndef ZONE_DEPRECATED_NO_EXPORT
#  define ZONE_DEPRECATED_NO_EXPORT ZONE_NO_EXPORT ZONE_DEPRECATED
#endif

/* NOLINTNEXTLINE(readability-avoid-unconditional-preprocessor-if) */
#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef ZONE_NO_DEPRECATED
#    define ZONE_NO_DEPRECATED
#  endif
#endif

#endif /* ZONE_EXPORT_H */
