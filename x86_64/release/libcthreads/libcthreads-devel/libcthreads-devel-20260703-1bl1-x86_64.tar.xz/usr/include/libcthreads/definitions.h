/*
 * Definitions for libcthreads
 *
 * Copyright (C) 2012-2026, Joachim Metz <joachim.metz@gmail.com>
 *
 * Refer to AUTHORS for acknowledgements.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#if !defined( _LIBCTHREADS_DEFINITIONS_H )
#define _LIBCTHREADS_DEFINITIONS_H

#include <libcthreads/types.h>

#define LIBCTHREADS_VERSION			20260703

/* The libcthreads version string
 */
#define LIBCTHREADS_VERSION_STRING		"20260703"

/* The comparison function definitions
 */
enum LIBCTHREADS_COMPARE_DEFINITIONS
{
	/* The first value is less than the second value
	 */
        LIBCTHREADS_COMPARE_LESS,

	/* The first and second values are equal
	 */
        LIBCTHREADS_COMPARE_EQUAL,

	/* The first value is greater than the second value
	 */
        LIBCTHREADS_COMPARE_GREATER
};

/* The sort flag definitions
 */
enum LIBCTHREADS_SORT_FLAGS
{
	/* Allow duplicate values
	 */
	LIBCTHREADS_SORT_FLAG_NON_UNIQUE_VALUES	= 0x00,

	/* Only allow unique values, no duplicates
	 */
	LIBCTHREADS_SORT_FLAG_UNIQUE_VALUES	= 0x01
};

#endif /* !defined( _LIBCTHREADS_DEFINITIONS_H ) */

