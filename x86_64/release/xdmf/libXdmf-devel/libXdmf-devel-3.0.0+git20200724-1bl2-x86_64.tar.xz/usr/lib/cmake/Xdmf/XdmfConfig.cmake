#
#	XdmfConfig.cmake
#


set(XDMF_ARGC		"1")
set(XDMF_ARGV		"Xdmf")
set(XDMF_ARGV0		"Xdmf")
set(XDMF_BUILDNAME		"CYGWIN-g++.exe")
set(XDMF_BUILD_NAME_SYSTEM_NAME		"CYGWIN")
set(XDMF_BUILD_SHARED		"1")
set(XDMF_BUILD_SHARED_LIBS		"ON")
set(XDMF_BUILD_TESTING		"ON")
set(XDMF_Boost_DIR		"Boost_DIR-NOTFOUND")
set(XDMF_Boost_INCLUDE_DIR		"/usr/include")
set(XDMF_CMAKE_ADDR2LINE		"/usr/bin/addr2line.exe")
set(XDMF_CMAKE_AR		"/usr/bin/ar.exe")
set(XDMF_CMAKE_AR		"/usr/bin/ar.exe")
set(XDMF_CMAKE_ARCHIVE_OUTPUT_DIRECTORY		"/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/build/lib")
set(XDMF_CMAKE_AUTOGEN_ORIGIN_DEPENDS		"ON")
set(XDMF_CMAKE_AUTOMOC_COMPILER_PREDEFINES		"ON")
set(XDMF_CMAKE_AUTOMOC_MACRO_NAMES		"Q_OBJECT;Q_GADGET;Q_NAMESPACE;Q_NAMESPACE_EXPORT")
set(XDMF_CMAKE_AUTOMOC_PATH_PREFIX		"OFF")
set(XDMF_CMAKE_BASE_NAME		"g++")
set(XDMF_CMAKE_BINARY_DIR		"/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/build")
set(XDMF_CMAKE_BINARY_DIR		"/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/build")
set(XDMF_CMAKE_BUILD_TOOL		"/usr/bin/ninja.exe")
set(XDMF_CMAKE_BUILD_TYPE		"RelWithDebInfo")
set(XDMF_CMAKE_C11_COMPILE_FEATURES		"c_std_11;c_static_assert")
set(XDMF_CMAKE_C11_EXTENSION_COMPILE_OPTION		"-std=gnu11")
set(XDMF_CMAKE_C11_STANDARD_COMPILE_OPTION		"-std=c11")
set(XDMF_CMAKE_C11_STANDARD__HAS_FULL_SUPPORT		"ON")
set(XDMF_CMAKE_C17_COMPILE_FEATURES		"c_std_17")
set(XDMF_CMAKE_C17_EXTENSION_COMPILE_OPTION		"-std=gnu17")
set(XDMF_CMAKE_C17_STANDARD_COMPILE_OPTION		"-std=c17")
set(XDMF_CMAKE_C23_COMPILE_FEATURES		"c_std_23")
set(XDMF_CMAKE_C23_EXTENSION_COMPILE_OPTION		"-std=gnu2x")
set(XDMF_CMAKE_C23_STANDARD_COMPILE_OPTION		"-std=c2x")
set(XDMF_CMAKE_C90_COMPILE_FEATURES		"c_std_90;c_function_prototypes")
set(XDMF_CMAKE_C90_EXTENSION_COMPILE_OPTION		"-std=gnu90")
set(XDMF_CMAKE_C90_STANDARD_COMPILE_OPTION		"-std=c90")
set(XDMF_CMAKE_C90_STANDARD__HAS_FULL_SUPPORT		"ON")
set(XDMF_CMAKE_C99_COMPILE_FEATURES		"c_std_99;c_restrict;c_variadic_macros")
set(XDMF_CMAKE_C99_EXTENSION_COMPILE_OPTION		"-std=gnu99")
set(XDMF_CMAKE_C99_STANDARD_COMPILE_OPTION		"-std=c99")
set(XDMF_CMAKE_C99_STANDARD__HAS_FULL_SUPPORT		"ON")
set(XDMF_CMAKE_CFG_INTDIR		".")
set(XDMF_CMAKE_COMMAND		"/usr/bin/cmake.exe")
set(XDMF_CMAKE_COMPILER_IS_GNUCC		"1")
set(XDMF_CMAKE_COMPILER_IS_GNUCXX		"1")
set(XDMF_CMAKE_CPACK_COMMAND		"/usr/bin/cpack.exe")
set(XDMF_CMAKE_CROSSCOMPILING		"FALSE")
set(XDMF_CMAKE_CTEST_COMMAND		"/usr/bin/ctest.exe")
set(XDMF_CMAKE_CURRENT_BINARY_DIR		"/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/build")
set(XDMF_CMAKE_CURRENT_FUNCTION		"xdmf_create_config_file")
set(XDMF_CMAKE_CURRENT_FUNCTION_LIST_DIR		"/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf/CMake")
set(XDMF_CMAKE_CURRENT_FUNCTION_LIST_FILE		"/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf/CMake/XdmfFunctions.cmake")
set(XDMF_CMAKE_CURRENT_FUNCTION_LIST_LINE		"1")
set(XDMF_CMAKE_CURRENT_LIST_DIR		"/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf")
set(XDMF_CMAKE_CURRENT_LIST_FILE		"/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf/CMakeLists.txt")
set(XDMF_CMAKE_CURRENT_SOURCE_DIR		"/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf")
set(XDMF_CMAKE_CXX11_COMPILE_FEATURES		"cxx_std_11;cxx_alias_templates;cxx_alignas;cxx_alignof;cxx_attributes;cxx_auto_type;cxx_constexpr;cxx_decltype;cxx_decltype_incomplete_return_types;cxx_default_function_template_args;cxx_defaulted_functions;cxx_defaulted_move_initializers;cxx_delegating_constructors;cxx_deleted_functions;cxx_enum_forward_declarations;cxx_explicit_conversions;cxx_extended_friend_declarations;cxx_extern_templates;cxx_final;cxx_func_identifier;cxx_generalized_initializers;cxx_inheriting_constructors;cxx_inline_namespaces;cxx_lambdas;cxx_local_type_template_args;cxx_long_long_type;cxx_noexcept;cxx_nonstatic_member_init;cxx_nullptr;cxx_override;cxx_range_for;cxx_raw_string_literals;cxx_reference_qualified_functions;cxx_right_angle_brackets;cxx_rvalue_references;cxx_sizeof_member;cxx_static_assert;cxx_strong_enums;cxx_thread_local;cxx_trailing_return_types;cxx_unicode_literals;cxx_uniform_initialization;cxx_unrestricted_unions;cxx_user_literals;cxx_variadic_macros;cxx_variadic_templates")
set(XDMF_CMAKE_CXX11_EXTENSION_COMPILE_OPTION		"-std=gnu++11")
set(XDMF_CMAKE_CXX11_STANDARD_COMPILE_OPTION		"-std=c++11")
set(XDMF_CMAKE_CXX11_STANDARD__HAS_FULL_SUPPORT		"ON")
set(XDMF_CMAKE_CXX14_COMPILE_FEATURES		"cxx_std_14;cxx_aggregate_default_initializers;cxx_attribute_deprecated;cxx_binary_literals;cxx_contextual_conversions;cxx_decltype_auto;cxx_digit_separators;cxx_generic_lambdas;cxx_lambda_init_captures;cxx_relaxed_constexpr;cxx_return_type_deduction;cxx_variable_templates")
set(XDMF_CMAKE_CXX14_EXTENSION_COMPILE_OPTION		"-std=gnu++14")
set(XDMF_CMAKE_CXX14_STANDARD_COMPILE_OPTION		"-std=c++14")
set(XDMF_CMAKE_CXX14_STANDARD__HAS_FULL_SUPPORT		"ON")
set(XDMF_CMAKE_CXX17_COMPILE_FEATURES		"cxx_std_17")
set(XDMF_CMAKE_CXX17_EXTENSION_COMPILE_OPTION		"-std=gnu++17")
set(XDMF_CMAKE_CXX17_STANDARD_COMPILE_OPTION		"-std=c++17")
set(XDMF_CMAKE_CXX20_COMPILE_FEATURES		"cxx_std_20")
set(XDMF_CMAKE_CXX20_EXTENSION_COMPILE_OPTION		"-std=gnu++20")
set(XDMF_CMAKE_CXX20_STANDARD_COMPILE_OPTION		"-std=c++20")
set(XDMF_CMAKE_CXX23_COMPILE_FEATURES		"cxx_std_23")
set(XDMF_CMAKE_CXX23_EXTENSION_COMPILE_OPTION		"-std=gnu++23")
set(XDMF_CMAKE_CXX23_STANDARD_COMPILE_OPTION		"-std=c++23")
set(XDMF_CMAKE_CXX26_COMPILE_FEATURES		"cxx_std_26")
set(XDMF_CMAKE_CXX26_EXTENSION_COMPILE_OPTION		"-std=gnu++26")
set(XDMF_CMAKE_CXX26_STANDARD_COMPILE_OPTION		"-std=c++26")
set(XDMF_CMAKE_CXX98_COMPILE_FEATURES		"cxx_std_98;cxx_template_template_parameters")
set(XDMF_CMAKE_CXX98_EXTENSION_COMPILE_OPTION		"-std=gnu++98")
set(XDMF_CMAKE_CXX98_STANDARD_COMPILE_OPTION		"-std=c++98")
set(XDMF_CMAKE_CXX98_STANDARD__HAS_FULL_SUPPORT		"ON")
set(XDMF_CMAKE_CXX_ABI_COMPILED		"TRUE")
set(XDMF_CMAKE_CXX_ARCHIVE_APPEND		"<CMAKE_AR> q <TARGET> <LINK_FLAGS> <OBJECTS>")
set(XDMF_CMAKE_CXX_ARCHIVE_APPEND_IPO		""/usr/bin/gcc-ar.exe" q <TARGET> <LINK_FLAGS> <OBJECTS>")
set(XDMF_CMAKE_CXX_ARCHIVE_CREATE		"<CMAKE_AR> qc <TARGET> <LINK_FLAGS> <OBJECTS>")
set(XDMF_CMAKE_CXX_ARCHIVE_CREATE_IPO		""/usr/bin/gcc-ar.exe" qc <TARGET> <LINK_FLAGS> <OBJECTS>")
set(XDMF_CMAKE_CXX_ARCHIVE_FINISH		"<CMAKE_RANLIB> <TARGET>")
set(XDMF_CMAKE_CXX_ARCHIVE_FINISH_IPO		""/usr/bin/gcc-ranlib.exe" <TARGET>")
set(XDMF_CMAKE_CXX_BYTE_ORDER		"LITTLE_ENDIAN")
set(XDMF_CMAKE_CXX_COMPILER		"/usr/bin/g++.exe")
set(XDMF_CMAKE_CXX_COMPILER		"/usr/bin/g++.exe")
set(XDMF_CMAKE_CXX_COMPILER_AR		"/usr/bin/gcc-ar.exe")
set(XDMF_CMAKE_CXX_COMPILER_AR		"/usr/bin/gcc-ar.exe")
set(XDMF_CMAKE_CXX_COMPILER_ARCHITECTURE_ID		"x86_64")
set(XDMF_CMAKE_CXX_COMPILER_ENV_VAR		"CXX")
set(XDMF_CMAKE_CXX_COMPILER_EXCLUDE		"CC;aCC;xlC")
set(XDMF_CMAKE_CXX_COMPILER_FRONTEND_VARIANT		"GNU")
set(XDMF_CMAKE_CXX_COMPILER_ID		"GNU")
set(XDMF_CMAKE_CXX_COMPILER_ID_PLATFORM_CONTENT		"#define STRINGIFY_HELPER(X) #X
#define STRINGIFY(X) STRINGIFY_HELPER(X)

/* Identify known platforms by name.  */
#if defined(__linux) || defined(__linux__) || defined(linux)
# define PLATFORM_ID "Linux"

#elif defined(__MSYS__)
# define PLATFORM_ID "MSYS"

#elif defined(__CYGWIN__)
# define PLATFORM_ID "Cygwin"

#elif defined(__MINGW32__)
# define PLATFORM_ID "MinGW"

#elif defined(__APPLE__)
# define PLATFORM_ID "Darwin"

#elif defined(_WIN32) || defined(__WIN32__) || defined(WIN32)
# define PLATFORM_ID "Windows"

#elif defined(__FreeBSD__) || defined(__FreeBSD)
# define PLATFORM_ID "FreeBSD"

#elif defined(__NetBSD__) || defined(__NetBSD)
# define PLATFORM_ID "NetBSD"

#elif defined(__OpenBSD__) || defined(__OPENBSD)
# define PLATFORM_ID "OpenBSD"

#elif defined(__sun) || defined(sun)
# define PLATFORM_ID "SunOS"

#elif defined(_AIX) || defined(__AIX) || defined(__AIX__) || defined(__aix) || defined(__aix__)
# define PLATFORM_ID "AIX"

#elif defined(__hpux) || defined(__hpux__)
# define PLATFORM_ID "HP-UX"

#elif defined(__HAIKU__)
# define PLATFORM_ID "Haiku"

#elif defined(__BeOS) || defined(__BEOS__) || defined(_BEOS)
# define PLATFORM_ID "BeOS"

#elif defined(__QNX__) || defined(__QNXNTO__)
# define PLATFORM_ID "QNX"

#elif defined(__tru64) || defined(_tru64) || defined(__TRU64__)
# define PLATFORM_ID "Tru64"

#elif defined(__riscos) || defined(__riscos__)
# define PLATFORM_ID "RISCos"

#elif defined(__sinix) || defined(__sinix__) || defined(__SINIX__)
# define PLATFORM_ID "SINIX"

#elif defined(__UNIX_SV__)
# define PLATFORM_ID "UNIX_SV"

#elif defined(__bsdos__)
# define PLATFORM_ID "BSDOS"

#elif defined(_MPRAS) || defined(MPRAS)
# define PLATFORM_ID "MP-RAS"

#elif defined(__osf) || defined(__osf__)
# define PLATFORM_ID "OSF1"

#elif defined(_SCO_SV) || defined(SCO_SV) || defined(sco_sv)
# define PLATFORM_ID "SCO_SV"

#elif defined(__ultrix) || defined(__ultrix__) || defined(_ULTRIX)
# define PLATFORM_ID "ULTRIX"

#elif defined(__XENIX__) || defined(_XENIX) || defined(XENIX)
# define PLATFORM_ID "Xenix"

#elif defined(__WATCOMC__)
# if defined(__LINUX__)
#  define PLATFORM_ID "Linux"

# elif defined(__DOS__)
#  define PLATFORM_ID "DOS"

# elif defined(__OS2__)
#  define PLATFORM_ID "OS2"

# elif defined(__WINDOWS__)
#  define PLATFORM_ID "Windows3x"

# elif defined(__VXWORKS__)
#  define PLATFORM_ID "VxWorks"

# else /* unknown platform */
#  define PLATFORM_ID
# endif

#elif defined(__INTEGRITY)
# if defined(INT_178B)
#  define PLATFORM_ID "Integrity178"

# else /* regular Integrity */
#  define PLATFORM_ID "Integrity"
# endif

# elif defined(_ADI_COMPILER)
#  define PLATFORM_ID "ADSP"

#else /* unknown platform */
# define PLATFORM_ID

#endif

/* For windows compilers MSVC and Intel we can determine
   the architecture of the compiler being used.  This is because
   the compilers do not have flags that can change the architecture,
   but rather depend on which compiler is being used
*/
#if defined(_WIN32) && defined(_MSC_VER)
# if defined(_M_IA64)
#  define ARCHITECTURE_ID "IA64"

# elif defined(_M_ARM64EC)
#  define ARCHITECTURE_ID "ARM64EC"

# elif defined(_M_X64) || defined(_M_AMD64)
#  define ARCHITECTURE_ID "x64"

# elif defined(_M_IX86)
#  define ARCHITECTURE_ID "X86"

# elif defined(_M_ARM64)
#  define ARCHITECTURE_ID "ARM64"

# elif defined(_M_ARM)
#  if _M_ARM == 4
#   define ARCHITECTURE_ID "ARMV4I"
#  elif _M_ARM == 5
#   define ARCHITECTURE_ID "ARMV5I"
#  else
#   define ARCHITECTURE_ID "ARMV" STRINGIFY(_M_ARM)
#  endif

# elif defined(_M_MIPS)
#  define ARCHITECTURE_ID "MIPS"

# elif defined(_M_SH)
#  define ARCHITECTURE_ID "SHx"

# else /* unknown architecture */
#  define ARCHITECTURE_ID ""
# endif

#elif defined(__WATCOMC__)
# if defined(_M_I86)
#  define ARCHITECTURE_ID "I86"

# elif defined(_M_IX86)
#  define ARCHITECTURE_ID "X86"

# else /* unknown architecture */
#  define ARCHITECTURE_ID ""
# endif

#elif defined(__IAR_SYSTEMS_ICC__) || defined(__IAR_SYSTEMS_ICC)
# if defined(__ICCARM__)
#  define ARCHITECTURE_ID "ARM"

# elif defined(__ICCRX__)
#  define ARCHITECTURE_ID "RX"

# elif defined(__ICCRH850__)
#  define ARCHITECTURE_ID "RH850"

# elif defined(__ICCRL78__)
#  define ARCHITECTURE_ID "RL78"

# elif defined(__ICCRISCV__)
#  define ARCHITECTURE_ID "RISCV"

# elif defined(__ICCAVR__)
#  define ARCHITECTURE_ID "AVR"

# elif defined(__ICC430__)
#  define ARCHITECTURE_ID "MSP430"

# elif defined(__ICCV850__)
#  define ARCHITECTURE_ID "V850"

# elif defined(__ICC8051__)
#  define ARCHITECTURE_ID "8051"

# elif defined(__ICCSTM8__)
#  define ARCHITECTURE_ID "STM8"

# else /* unknown architecture */
#  define ARCHITECTURE_ID ""
# endif

#elif defined(__ghs__)
# if defined(__PPC64__)
#  define ARCHITECTURE_ID "PPC64"

# elif defined(__ppc__)
#  define ARCHITECTURE_ID "PPC"

# elif defined(__ARM__)
#  define ARCHITECTURE_ID "ARM"

# elif defined(__x86_64__)
#  define ARCHITECTURE_ID "x64"

# elif defined(__i386__)
#  define ARCHITECTURE_ID "X86"

# else /* unknown architecture */
#  define ARCHITECTURE_ID ""
# endif

#elif defined(__clang__) && defined(__ti__)
# if defined(__ARM_ARCH)
#  define ARCHITECTURE_ID "ARM"

# else /* unknown architecture */
#  define ARCHITECTURE_ID ""
# endif

#elif defined(__TI_COMPILER_VERSION__)
# if defined(__TI_ARM__)
#  define ARCHITECTURE_ID "ARM"

# elif defined(__MSP430__)
#  define ARCHITECTURE_ID "MSP430"

# elif defined(__TMS320C28XX__)
#  define ARCHITECTURE_ID "TMS320C28x"

# elif defined(__TMS320C6X__) || defined(_TMS320C6X)
#  define ARCHITECTURE_ID "TMS320C6x"

# else /* unknown architecture */
#  define ARCHITECTURE_ID ""
# endif

# elif defined(__ADSPSHARC__)
#  define ARCHITECTURE_ID "SHARC"

# elif defined(__ADSPBLACKFIN__)
#  define ARCHITECTURE_ID "Blackfin"

#elif defined(__TASKING__)

# if defined(__CTC__) || defined(__CPTC__)
#  define ARCHITECTURE_ID "TriCore"

# elif defined(__CMCS__)
#  define ARCHITECTURE_ID "MCS"

# elif defined(__CARM__) || defined(__CPARM__)
#  define ARCHITECTURE_ID "ARM"

# elif defined(__CARC__)
#  define ARCHITECTURE_ID "ARC"

# elif defined(__C51__)
#  define ARCHITECTURE_ID "8051"

# elif defined(__CPCP__)
#  define ARCHITECTURE_ID "PCP"

# else
#  define ARCHITECTURE_ID ""
# endif

#elif defined(__RENESAS__)
# if defined(__CCRX__)
#  define ARCHITECTURE_ID "RX"

# elif defined(__CCRL__)
#  define ARCHITECTURE_ID "RL78"

# elif defined(__CCRH__)
#  define ARCHITECTURE_ID "RH850"

# else
#  define ARCHITECTURE_ID ""
# endif

#else
#  define ARCHITECTURE_ID
#endif

/* Convert integer to decimal digit literals.  */
#define DEC(n)                   \\
  ('0' + (((n) / 10000000)%10)), \\
  ('0' + (((n) / 1000000)%10)),  \\
  ('0' + (((n) / 100000)%10)),   \\
  ('0' + (((n) / 10000)%10)),    \\
  ('0' + (((n) / 1000)%10)),     \\
  ('0' + (((n) / 100)%10)),      \\
  ('0' + (((n) / 10)%10)),       \\
  ('0' +  ((n) % 10))

/* Convert integer to hex digit literals.  */
#define HEX(n)             \\
  ('0' + ((n)>>28 & 0xF)), \\
  ('0' + ((n)>>24 & 0xF)), \\
  ('0' + ((n)>>20 & 0xF)), \\
  ('0' + ((n)>>16 & 0xF)), \\
  ('0' + ((n)>>12 & 0xF)), \\
  ('0' + ((n)>>8  & 0xF)), \\
  ('0' + ((n)>>4  & 0xF)), \\
  ('0' + ((n)     & 0xF))

/* Construct a string literal encoding the version number. */
#ifdef COMPILER_VERSION
char const* info_version = "INFO" ":" "compiler_version[" COMPILER_VERSION "]";

/* Construct a string literal encoding the version number components. */
#elif defined(COMPILER_VERSION_MAJOR)
char const info_version[] = {
  'I', 'N', 'F', 'O', ':',
  'c','o','m','p','i','l','e','r','_','v','e','r','s','i','o','n','[',
  COMPILER_VERSION_MAJOR,
# ifdef COMPILER_VERSION_MINOR
  '.', COMPILER_VERSION_MINOR,
#  ifdef COMPILER_VERSION_PATCH
   '.', COMPILER_VERSION_PATCH,
#   ifdef COMPILER_VERSION_TWEAK
    '.', COMPILER_VERSION_TWEAK,
#   endif
#  endif
# endif
  ']','\\0'};
#endif

/* Construct a string literal encoding the internal version number. */
#ifdef COMPILER_VERSION_INTERNAL
char const info_version_internal[] = {
  'I', 'N', 'F', 'O', ':',
  'c','o','m','p','i','l','e','r','_','v','e','r','s','i','o','n','_',
  'i','n','t','e','r','n','a','l','[',
  COMPILER_VERSION_INTERNAL,']','\\0'};
#elif defined(COMPILER_VERSION_INTERNAL_STR)
char const* info_version_internal = "INFO" ":" "compiler_version_internal[" COMPILER_VERSION_INTERNAL_STR "]";
#endif

/* Construct a string literal encoding the version number components. */
#ifdef SIMULATE_VERSION_MAJOR
char const info_simulate_version[] = {
  'I', 'N', 'F', 'O', ':',
  's','i','m','u','l','a','t','e','_','v','e','r','s','i','o','n','[',
  SIMULATE_VERSION_MAJOR,
# ifdef SIMULATE_VERSION_MINOR
  '.', SIMULATE_VERSION_MINOR,
#  ifdef SIMULATE_VERSION_PATCH
   '.', SIMULATE_VERSION_PATCH,
#   ifdef SIMULATE_VERSION_TWEAK
    '.', SIMULATE_VERSION_TWEAK,
#   endif
#  endif
# endif
  ']','\\0'};
#endif

/* Construct the string literal in pieces to prevent the source from
   getting matched.  Store it in a pointer rather than an array
   because some compilers will just produce instructions to fill the
   array rather than assigning a pointer to a static array.  */
char const* info_platform = "INFO" ":" "platform[" PLATFORM_ID "]";
char const* info_arch = "INFO" ":" "arch[" ARCHITECTURE_ID "]";
")
set(XDMF_CMAKE_CXX_COMPILER_ID_RUN		"1")
set(XDMF_CMAKE_CXX_COMPILER_ID_TEST_FLAGS		"-c;--c++;--ec++;--target=arm-arm-none-eabi -mcpu=cortex-m3;-c -I__does_not_exist__")
set(XDMF_CMAKE_CXX_COMPILER_ID_TOOL_MATCH_INDEX		"2")
set(XDMF_CMAKE_CXX_COMPILER_ID_TOOL_MATCH_REGEX		"
Ld[^
]*(
[ 	]+[^
]*)*
[ 	]+([^ 	
]+)[^
]*-o[^
]*CompilerIdCXX/(\\./)?(CompilerIdCXX.(framework|xctest|build/[^ 	
]+)/)?CompilerIdCXX[ 	
\\"]")
set(XDMF_CMAKE_CXX_COMPILER_ID_VENDORS		"IAR")
set(XDMF_CMAKE_CXX_COMPILER_ID_VENDOR_REGEX_IAR		"IAR .+ Compiler")
set(XDMF_CMAKE_CXX_COMPILER_IMPORT_STD_ERROR_MESSAGE		"Experimental `import std` support not enabled when detecting toolchain; it must be set before `CXX` is enabled (usually a `project()` call)")
set(XDMF_CMAKE_CXX_COMPILER_LINKER		"/usr/lib/gcc/x86_64-pc-cygwin/14/../../../../x86_64-pc-cygwin/bin/ld")
set(XDMF_CMAKE_CXX_COMPILER_LINKER_ARCHITECTURE_FLAGS		"-m;i386pep")
set(XDMF_CMAKE_CXX_COMPILER_LINKER_FRONTEND_VARIANT		"GNU")
set(XDMF_CMAKE_CXX_COMPILER_LINKER_ID		"GNU")
set(XDMF_CMAKE_CXX_COMPILER_LINKER_VERSION		"2.47.20260726")
set(XDMF_CMAKE_CXX_COMPILER_LOADED		"1")
set(XDMF_CMAKE_CXX_COMPILER_NAMES		"c++")
set(XDMF_CMAKE_CXX_COMPILER_PREDEFINES_COMMAND		"/usr/bin/g++.exe;-w;-dM;-E;/usr/share/cmake-4.4.5/Modules/CMakeCXXCompilerABI.cpp")
set(XDMF_CMAKE_CXX_COMPILER_PRODUCED_FILES		"a.exe")
set(XDMF_CMAKE_CXX_COMPILER_RANLIB		"/usr/bin/gcc-ranlib.exe")
set(XDMF_CMAKE_CXX_COMPILER_RANLIB		"/usr/bin/gcc-ranlib.exe")
set(XDMF_CMAKE_CXX_COMPILER_VERSION		"14.4.0")
set(XDMF_CMAKE_CXX_COMPILER_WORKS		"TRUE")
set(XDMF_CMAKE_CXX_COMPILE_FEATURES		"cxx_std_98;cxx_template_template_parameters;cxx_std_11;cxx_alias_templates;cxx_alignas;cxx_alignof;cxx_attributes;cxx_auto_type;cxx_constexpr;cxx_decltype;cxx_decltype_incomplete_return_types;cxx_default_function_template_args;cxx_defaulted_functions;cxx_defaulted_move_initializers;cxx_delegating_constructors;cxx_deleted_functions;cxx_enum_forward_declarations;cxx_explicit_conversions;cxx_extended_friend_declarations;cxx_extern_templates;cxx_final;cxx_func_identifier;cxx_generalized_initializers;cxx_inheriting_constructors;cxx_inline_namespaces;cxx_lambdas;cxx_local_type_template_args;cxx_long_long_type;cxx_noexcept;cxx_nonstatic_member_init;cxx_nullptr;cxx_override;cxx_range_for;cxx_raw_string_literals;cxx_reference_qualified_functions;cxx_right_angle_brackets;cxx_rvalue_references;cxx_sizeof_member;cxx_static_assert;cxx_strong_enums;cxx_thread_local;cxx_trailing_return_types;cxx_unicode_literals;cxx_uniform_initialization;cxx_unrestricted_unions;cxx_user_literals;cxx_variadic_macros;cxx_variadic_templates;cxx_std_14;cxx_aggregate_default_initializers;cxx_attribute_deprecated;cxx_binary_literals;cxx_contextual_conversions;cxx_decltype_auto;cxx_digit_separators;cxx_generic_lambdas;cxx_lambda_init_captures;cxx_relaxed_constexpr;cxx_return_type_deduction;cxx_variable_templates;cxx_std_17;cxx_std_20;cxx_std_23;cxx_std_26")
set(XDMF_CMAKE_CXX_COMPILE_OBJECT		"<CMAKE_CXX_COMPILER> <DEFINES> <INCLUDES> <FLAGS> -o <OBJECT> -c <SOURCE>")
set(XDMF_CMAKE_CXX_COMPILE_OPTIONS_COLOR_DIAGNOSTICS		"-fdiagnostics-color=always")
set(XDMF_CMAKE_CXX_COMPILE_OPTIONS_COLOR_DIAGNOSTICS_OFF		"-fno-diagnostics-color")
set(XDMF_CMAKE_CXX_COMPILE_OPTIONS_CREATE_PCH		"-x;c++-header;-include;<PCH_HEADER>")
set(XDMF_CMAKE_CXX_COMPILE_OPTIONS_EXPLICIT_LANGUAGE		"-x;c++")
set(XDMF_CMAKE_CXX_COMPILE_OPTIONS_INVALID_PCH		"-Winvalid-pch")
set(XDMF_CMAKE_CXX_COMPILE_OPTIONS_IPO		"-flto=auto;-fno-fat-lto-objects")
set(XDMF_CMAKE_CXX_COMPILE_OPTIONS_SYSROOT		"--sysroot=")
set(XDMF_CMAKE_CXX_COMPILE_OPTIONS_USE_PCH		"-include;<PCH_HEADER>")
set(XDMF_CMAKE_CXX_COMPILE_OPTIONS_VISIBILITY		"-fvisibility=")
set(XDMF_CMAKE_CXX_COMPILE_OPTIONS_VISIBILITY_INLINES_HIDDEN		"-fvisibility-inlines-hidden")
set(XDMF_CMAKE_CXX_COMPILE_OPTIONS_WARNING_AS_ERROR		"-Werror")
set(XDMF_CMAKE_CXX_CREATE_ASSEMBLY_SOURCE		"<CMAKE_CXX_COMPILER> <DEFINES> <INCLUDES> <FLAGS> -S <SOURCE> -o <ASSEMBLY_SOURCE>")
set(XDMF_CMAKE_CXX_CREATE_PREPROCESSED_SOURCE		"<CMAKE_CXX_COMPILER> <DEFINES> <INCLUDES> <FLAGS> -E <SOURCE> > <PREPROCESSED_SOURCE>")
set(XDMF_CMAKE_CXX_CREATE_SHARED_LIBRARY		"<CMAKE_CXX_COMPILER> <LANGUAGE_COMPILE_FLAGS> <CMAKE_SHARED_LIBRARY_CXX_FLAGS> <LINK_FLAGS> -o <TARGET> -Wl,--out-implib,<TARGET_IMPLIB> -Wl,--major-image-version,<TARGET_VERSION_MAJOR>,--minor-image-version,<TARGET_VERSION_MINOR> <OBJECTS> <LINK_LIBRARIES>")
set(XDMF_CMAKE_CXX_CREATE_SHARED_MODULE		"<CMAKE_CXX_COMPILER> <LANGUAGE_COMPILE_FLAGS> <CMAKE_SHARED_MODULE_CXX_FLAGS> <LINK_FLAGS> -o <TARGET> -Wl,--major-image-version,<TARGET_VERSION_MAJOR>,--minor-image-version,<TARGET_VERSION_MINOR> <OBJECTS> <LINK_LIBRARIES>")
set(XDMF_CMAKE_CXX_CREATE_WIN32_EXE		"-mwindows")
set(XDMF_CMAKE_CXX_EXTENSIONS_COMPUTED_DEFAULT		"ON")
set(XDMF_CMAKE_CXX_EXTENSIONS_DEFAULT		"ON")
set(XDMF_CMAKE_CXX_FLAGS		"-ggdb -O2 -pipe -Wall -Werror=format-security -Wp,-D_FORTIFY_SOURCE=3 -fstack-protector-strong --param=ssp-buffer-size=4 -fdiagnostics-color -Werror=return-type -ffile-prefix-map=/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/build=/usr/src/debug/xdmf-3.0.0+git20200724-1bl2 -ffile-prefix-map=/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf=/usr/src/debug/xdmf-3.0.0+git20200724-1bl2")
set(XDMF_CMAKE_CXX_FLAGS_DEBUG		"-g")
set(XDMF_CMAKE_CXX_FLAGS_DEBUG_INIT		" -g")
set(XDMF_CMAKE_CXX_FLAGS_INIT		"-ggdb -O2 -pipe -Wall -Werror=format-security -Wp,-D_FORTIFY_SOURCE=3 -fstack-protector-strong --param=ssp-buffer-size=4 -fdiagnostics-color -Werror=return-type -ffile-prefix-map=/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/build=/usr/src/debug/xdmf-3.0.0+git20200724-1bl2 -ffile-prefix-map=/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf=/usr/src/debug/xdmf-3.0.0+git20200724-1bl2  ")
set(XDMF_CMAKE_CXX_FLAGS_MINSIZEREL		"-Os -DNDEBUG")
set(XDMF_CMAKE_CXX_FLAGS_MINSIZEREL_INIT		" -Os -DNDEBUG")
set(XDMF_CMAKE_CXX_FLAGS_RELEASE		"-O3 -DNDEBUG")
set(XDMF_CMAKE_CXX_FLAGS_RELEASE_INIT		" -O3 -DNDEBUG")
set(XDMF_CMAKE_CXX_FLAGS_RELWITHDEBINFO		"-O2 -g -DNDEBUG")
set(XDMF_CMAKE_CXX_FLAGS_RELWITHDEBINFO_INIT		" -O2 -g -DNDEBUG")
set(XDMF_CMAKE_CXX_IGNORE_EXTENSIONS		"inl;h;hpp;HPP;H;o;O;obj;OBJ;def;DEF;rc;RC")
set(XDMF_CMAKE_CXX_IMPLICIT_INCLUDE_DIRECTORIES		"/usr/lib/gcc/x86_64-pc-cygwin/14/include/c++;/usr/lib/gcc/x86_64-pc-cygwin/14/include/c++/x86_64-pc-cygwin;/usr/lib/gcc/x86_64-pc-cygwin/14/include/c++/backward;/usr/lib/gcc/x86_64-pc-cygwin/14/include;/usr/include;/usr/include/w32api")
set(XDMF_CMAKE_CXX_IMPLICIT_LINK_DIRECTORIES		"/usr/lib/gcc/x86_64-pc-cygwin/14;/usr/x86_64-pc-cygwin/lib;/usr/lib")
set(XDMF_CMAKE_CXX_IMPLICIT_LINK_LIBRARIES		"stdc++;gcc_s;gcc;intl;iconv;cygwin;advapi32;shell32;user32;kernel32;gcc_s;gcc")
set(XDMF_CMAKE_CXX_INFORMATION_LOADED		"1")
set(XDMF_CMAKE_CXX_LINKER_DEPFILE_FLAGS		"LINKER:--dependency-file=<DEP_FILE>")
set(XDMF_CMAKE_CXX_LINKER_DEPFILE_FORMAT		"gcc")
set(XDMF_CMAKE_CXX_LINKER_DEPFILE_SUPPORTED		"FALSE")
set(XDMF_CMAKE_CXX_LINKER_INFORMATION_LOADED		"1")
set(XDMF_CMAKE_CXX_LINKER_PREFERENCE		"30")
set(XDMF_CMAKE_CXX_LINKER_PREFERENCE_PROPAGATES		"1")
set(XDMF_CMAKE_CXX_LINKER_PUSHPOP_STATE_SUPPORTED		"TRUE")
set(XDMF_CMAKE_CXX_LINKER_WRAPPER_FLAG		"-Wl,")
set(XDMF_CMAKE_CXX_LINKER_WRAPPER_FLAG_SEP		",")
set(XDMF_CMAKE_CXX_LINK_DEPENDS_USE_LINKER		"FALSE")
set(XDMF_CMAKE_CXX_LINK_EXECUTABLE		"<CMAKE_CXX_COMPILER> <FLAGS> <LINK_FLAGS> <OBJECTS> -o <TARGET> -Wl,--out-implib,<TARGET_IMPLIB> -Wl,--major-image-version,<TARGET_VERSION_MAJOR>,--minor-image-version,<TARGET_VERSION_MINOR> <LINK_LIBRARIES>")
set(XDMF_CMAKE_CXX_LINK_LIBRARY_USING_WHOLE_ARCHIVE		"LINKER:--push-state,--whole-archive;<LINK_ITEM>;LINKER:--pop-state")
set(XDMF_CMAKE_CXX_LINK_LIBRARY_USING_WHOLE_ARCHIVE_SUPPORTED		"TRUE")
set(XDMF_CMAKE_CXX_LINK_LIBRARY_WHOLE_ARCHIVE_ATTRIBUTES		"LIBRARY_TYPE=STATIC;DEDUPLICATION=YES;OVERRIDE=DEFAULT")
set(XDMF_CMAKE_CXX_LINK_MODE		"DRIVER")
set(XDMF_CMAKE_CXX_LINK_OPTIONS_WARNING_AS_ERROR		"LINKER:--fatal-warnings")
set(XDMF_CMAKE_CXX_MODULE_BMI_ONLY_FLAG		"-fmodule-only")
set(XDMF_CMAKE_CXX_MODULE_MAP_FLAG		"-fmodules-ts -fmodule-mapper=<MODULE_MAP_FILE> -MD -fdeps-format=p1689r5 -x c++")
set(XDMF_CMAKE_CXX_MODULE_MAP_FORMAT		"gcc")
set(XDMF_CMAKE_CXX_OUTPUT_EXTENSION		".o")
set(XDMF_CMAKE_CXX_PLATFORM_ID		"Cygwin")
set(XDMF_CMAKE_CXX_PLATFORM_LINKER_ID		"GNU")
set(XDMF_CMAKE_CXX_SCANDEP_SOURCE		"<CMAKE_CXX_COMPILER> <DEFINES> <INCLUDES> <FLAGS> -E -x c++ <SOURCE> -MT <DYNDEP_FILE> -MD -MF <DEP_FILE> -fmodules-ts -fdeps-file=<DYNDEP_FILE> -fdeps-target=<OBJECT> -fdeps-format=p1689r5 -o <PREPROCESSED_SOURCE>")
set(XDMF_CMAKE_CXX_SIZEOF_DATA_PTR		"8")
set(XDMF_CMAKE_CXX_SOURCE_FILE_EXTENSIONS		"C;M;c++;cc;cpp;cxx;mm;mpp;CPP;ixx;cppm;ccm;cxxm;c++m")
set(XDMF_CMAKE_CXX_STANDARD_COMPUTED_DEFAULT		"17")
set(XDMF_CMAKE_CXX_STANDARD_DEFAULT		"17")
set(XDMF_CMAKE_CXX_STANDARD_LATEST		"26")
set(XDMF_CMAKE_CXX_STANDARD_LIBRARY		"libstdc++")
set(XDMF_CMAKE_CXX_USE_LINKER_INFORMATION		"TRUE")
set(XDMF_CMAKE_CXX_VERBOSE_FLAG		"-v")
set(XDMF_CMAKE_CXX_VERBOSE_LINK_FLAG		"-Wl,-v")
set(XDMF_CMAKE_C_ABI_COMPILED		"TRUE")
set(XDMF_CMAKE_C_ARCHIVE_APPEND		"<CMAKE_AR> q <TARGET> <LINK_FLAGS> <OBJECTS>")
set(XDMF_CMAKE_C_ARCHIVE_APPEND_IPO		""/usr/bin/gcc-ar.exe" q <TARGET> <LINK_FLAGS> <OBJECTS>")
set(XDMF_CMAKE_C_ARCHIVE_CREATE		"<CMAKE_AR> qc <TARGET> <LINK_FLAGS> <OBJECTS>")
set(XDMF_CMAKE_C_ARCHIVE_CREATE_IPO		""/usr/bin/gcc-ar.exe" qc <TARGET> <LINK_FLAGS> <OBJECTS>")
set(XDMF_CMAKE_C_ARCHIVE_FINISH		"<CMAKE_RANLIB> <TARGET>")
set(XDMF_CMAKE_C_ARCHIVE_FINISH_IPO		""/usr/bin/gcc-ranlib.exe" <TARGET>")
set(XDMF_CMAKE_C_BYTE_ORDER		"LITTLE_ENDIAN")
set(XDMF_CMAKE_C_COMPILER		"/usr/bin/gcc.exe")
set(XDMF_CMAKE_C_COMPILER		"/usr/bin/gcc.exe")
set(XDMF_CMAKE_C_COMPILER_AR		"/usr/bin/gcc-ar.exe")
set(XDMF_CMAKE_C_COMPILER_AR		"/usr/bin/gcc-ar.exe")
set(XDMF_CMAKE_C_COMPILER_ARCHITECTURE_ID		"x86_64")
set(XDMF_CMAKE_C_COMPILER_ENV_VAR		"CC")
set(XDMF_CMAKE_C_COMPILER_FRONTEND_VARIANT		"GNU")
set(XDMF_CMAKE_C_COMPILER_ID		"GNU")
set(XDMF_CMAKE_C_COMPILER_ID_PLATFORM_CONTENT		"#define STRINGIFY_HELPER(X) #X
#define STRINGIFY(X) STRINGIFY_HELPER(X)

/* Identify known platforms by name.  */
#if defined(__linux) || defined(__linux__) || defined(linux)
# define PLATFORM_ID "Linux"

#elif defined(__MSYS__)
# define PLATFORM_ID "MSYS"

#elif defined(__CYGWIN__)
# define PLATFORM_ID "Cygwin"

#elif defined(__MINGW32__)
# define PLATFORM_ID "MinGW"

#elif defined(__APPLE__)
# define PLATFORM_ID "Darwin"

#elif defined(_WIN32) || defined(__WIN32__) || defined(WIN32)
# define PLATFORM_ID "Windows"

#elif defined(__FreeBSD__) || defined(__FreeBSD)
# define PLATFORM_ID "FreeBSD"

#elif defined(__NetBSD__) || defined(__NetBSD)
# define PLATFORM_ID "NetBSD"

#elif defined(__OpenBSD__) || defined(__OPENBSD)
# define PLATFORM_ID "OpenBSD"

#elif defined(__sun) || defined(sun)
# define PLATFORM_ID "SunOS"

#elif defined(_AIX) || defined(__AIX) || defined(__AIX__) || defined(__aix) || defined(__aix__)
# define PLATFORM_ID "AIX"

#elif defined(__hpux) || defined(__hpux__)
# define PLATFORM_ID "HP-UX"

#elif defined(__HAIKU__)
# define PLATFORM_ID "Haiku"

#elif defined(__BeOS) || defined(__BEOS__) || defined(_BEOS)
# define PLATFORM_ID "BeOS"

#elif defined(__QNX__) || defined(__QNXNTO__)
# define PLATFORM_ID "QNX"

#elif defined(__tru64) || defined(_tru64) || defined(__TRU64__)
# define PLATFORM_ID "Tru64"

#elif defined(__riscos) || defined(__riscos__)
# define PLATFORM_ID "RISCos"

#elif defined(__sinix) || defined(__sinix__) || defined(__SINIX__)
# define PLATFORM_ID "SINIX"

#elif defined(__UNIX_SV__)
# define PLATFORM_ID "UNIX_SV"

#elif defined(__bsdos__)
# define PLATFORM_ID "BSDOS"

#elif defined(_MPRAS) || defined(MPRAS)
# define PLATFORM_ID "MP-RAS"

#elif defined(__osf) || defined(__osf__)
# define PLATFORM_ID "OSF1"

#elif defined(_SCO_SV) || defined(SCO_SV) || defined(sco_sv)
# define PLATFORM_ID "SCO_SV"

#elif defined(__ultrix) || defined(__ultrix__) || defined(_ULTRIX)
# define PLATFORM_ID "ULTRIX"

#elif defined(__XENIX__) || defined(_XENIX) || defined(XENIX)
# define PLATFORM_ID "Xenix"

#elif defined(__WATCOMC__)
# if defined(__LINUX__)
#  define PLATFORM_ID "Linux"

# elif defined(__DOS__)
#  define PLATFORM_ID "DOS"

# elif defined(__OS2__)
#  define PLATFORM_ID "OS2"

# elif defined(__WINDOWS__)
#  define PLATFORM_ID "Windows3x"

# elif defined(__VXWORKS__)
#  define PLATFORM_ID "VxWorks"

# else /* unknown platform */
#  define PLATFORM_ID
# endif

#elif defined(__INTEGRITY)
# if defined(INT_178B)
#  define PLATFORM_ID "Integrity178"

# else /* regular Integrity */
#  define PLATFORM_ID "Integrity"
# endif

# elif defined(_ADI_COMPILER)
#  define PLATFORM_ID "ADSP"

#else /* unknown platform */
# define PLATFORM_ID

#endif

/* For windows compilers MSVC and Intel we can determine
   the architecture of the compiler being used.  This is because
   the compilers do not have flags that can change the architecture,
   but rather depend on which compiler is being used
*/
#if defined(_WIN32) && defined(_MSC_VER)
# if defined(_M_IA64)
#  define ARCHITECTURE_ID "IA64"

# elif defined(_M_ARM64EC)
#  define ARCHITECTURE_ID "ARM64EC"

# elif defined(_M_X64) || defined(_M_AMD64)
#  define ARCHITECTURE_ID "x64"

# elif defined(_M_IX86)
#  define ARCHITECTURE_ID "X86"

# elif defined(_M_ARM64)
#  define ARCHITECTURE_ID "ARM64"

# elif defined(_M_ARM)
#  if _M_ARM == 4
#   define ARCHITECTURE_ID "ARMV4I"
#  elif _M_ARM == 5
#   define ARCHITECTURE_ID "ARMV5I"
#  else
#   define ARCHITECTURE_ID "ARMV" STRINGIFY(_M_ARM)
#  endif

# elif defined(_M_MIPS)
#  define ARCHITECTURE_ID "MIPS"

# elif defined(_M_SH)
#  define ARCHITECTURE_ID "SHx"

# else /* unknown architecture */
#  define ARCHITECTURE_ID ""
# endif

#elif defined(__WATCOMC__)
# if defined(_M_I86)
#  define ARCHITECTURE_ID "I86"

# elif defined(_M_IX86)
#  define ARCHITECTURE_ID "X86"

# else /* unknown architecture */
#  define ARCHITECTURE_ID ""
# endif

#elif defined(__IAR_SYSTEMS_ICC__) || defined(__IAR_SYSTEMS_ICC)
# if defined(__ICCARM__)
#  define ARCHITECTURE_ID "ARM"

# elif defined(__ICCRX__)
#  define ARCHITECTURE_ID "RX"

# elif defined(__ICCRH850__)
#  define ARCHITECTURE_ID "RH850"

# elif defined(__ICCRL78__)
#  define ARCHITECTURE_ID "RL78"

# elif defined(__ICCRISCV__)
#  define ARCHITECTURE_ID "RISCV"

# elif defined(__ICCAVR__)
#  define ARCHITECTURE_ID "AVR"

# elif defined(__ICC430__)
#  define ARCHITECTURE_ID "MSP430"

# elif defined(__ICCV850__)
#  define ARCHITECTURE_ID "V850"

# elif defined(__ICC8051__)
#  define ARCHITECTURE_ID "8051"

# elif defined(__ICCSTM8__)
#  define ARCHITECTURE_ID "STM8"

# else /* unknown architecture */
#  define ARCHITECTURE_ID ""
# endif

#elif defined(__ghs__)
# if defined(__PPC64__)
#  define ARCHITECTURE_ID "PPC64"

# elif defined(__ppc__)
#  define ARCHITECTURE_ID "PPC"

# elif defined(__ARM__)
#  define ARCHITECTURE_ID "ARM"

# elif defined(__x86_64__)
#  define ARCHITECTURE_ID "x64"

# elif defined(__i386__)
#  define ARCHITECTURE_ID "X86"

# else /* unknown architecture */
#  define ARCHITECTURE_ID ""
# endif

#elif defined(__clang__) && defined(__ti__)
# if defined(__ARM_ARCH)
#  define ARCHITECTURE_ID "ARM"

# else /* unknown architecture */
#  define ARCHITECTURE_ID ""
# endif

#elif defined(__TI_COMPILER_VERSION__)
# if defined(__TI_ARM__)
#  define ARCHITECTURE_ID "ARM"

# elif defined(__MSP430__)
#  define ARCHITECTURE_ID "MSP430"

# elif defined(__TMS320C28XX__)
#  define ARCHITECTURE_ID "TMS320C28x"

# elif defined(__TMS320C6X__) || defined(_TMS320C6X)
#  define ARCHITECTURE_ID "TMS320C6x"

# else /* unknown architecture */
#  define ARCHITECTURE_ID ""
# endif

# elif defined(__ADSPSHARC__)
#  define ARCHITECTURE_ID "SHARC"

# elif defined(__ADSPBLACKFIN__)
#  define ARCHITECTURE_ID "Blackfin"

#elif defined(__TASKING__)

# if defined(__CTC__) || defined(__CPTC__)
#  define ARCHITECTURE_ID "TriCore"

# elif defined(__CMCS__)
#  define ARCHITECTURE_ID "MCS"

# elif defined(__CARM__) || defined(__CPARM__)
#  define ARCHITECTURE_ID "ARM"

# elif defined(__CARC__)
#  define ARCHITECTURE_ID "ARC"

# elif defined(__C51__)
#  define ARCHITECTURE_ID "8051"

# elif defined(__CPCP__)
#  define ARCHITECTURE_ID "PCP"

# else
#  define ARCHITECTURE_ID ""
# endif

#elif defined(__RENESAS__)
# if defined(__CCRX__)
#  define ARCHITECTURE_ID "RX"

# elif defined(__CCRL__)
#  define ARCHITECTURE_ID "RL78"

# elif defined(__CCRH__)
#  define ARCHITECTURE_ID "RH850"

# else
#  define ARCHITECTURE_ID ""
# endif

#else
#  define ARCHITECTURE_ID
#endif

/* Convert integer to decimal digit literals.  */
#define DEC(n)                   \\
  ('0' + (((n) / 10000000)%10)), \\
  ('0' + (((n) / 1000000)%10)),  \\
  ('0' + (((n) / 100000)%10)),   \\
  ('0' + (((n) / 10000)%10)),    \\
  ('0' + (((n) / 1000)%10)),     \\
  ('0' + (((n) / 100)%10)),      \\
  ('0' + (((n) / 10)%10)),       \\
  ('0' +  ((n) % 10))

/* Convert integer to hex digit literals.  */
#define HEX(n)             \\
  ('0' + ((n)>>28 & 0xF)), \\
  ('0' + ((n)>>24 & 0xF)), \\
  ('0' + ((n)>>20 & 0xF)), \\
  ('0' + ((n)>>16 & 0xF)), \\
  ('0' + ((n)>>12 & 0xF)), \\
  ('0' + ((n)>>8  & 0xF)), \\
  ('0' + ((n)>>4  & 0xF)), \\
  ('0' + ((n)     & 0xF))

/* Construct a string literal encoding the version number. */
#ifdef COMPILER_VERSION
char const* info_version = "INFO" ":" "compiler_version[" COMPILER_VERSION "]";

/* Construct a string literal encoding the version number components. */
#elif defined(COMPILER_VERSION_MAJOR)
char const info_version[] = {
  'I', 'N', 'F', 'O', ':',
  'c','o','m','p','i','l','e','r','_','v','e','r','s','i','o','n','[',
  COMPILER_VERSION_MAJOR,
# ifdef COMPILER_VERSION_MINOR
  '.', COMPILER_VERSION_MINOR,
#  ifdef COMPILER_VERSION_PATCH
   '.', COMPILER_VERSION_PATCH,
#   ifdef COMPILER_VERSION_TWEAK
    '.', COMPILER_VERSION_TWEAK,
#   endif
#  endif
# endif
  ']','\\0'};
#endif

/* Construct a string literal encoding the internal version number. */
#ifdef COMPILER_VERSION_INTERNAL
char const info_version_internal[] = {
  'I', 'N', 'F', 'O', ':',
  'c','o','m','p','i','l','e','r','_','v','e','r','s','i','o','n','_',
  'i','n','t','e','r','n','a','l','[',
  COMPILER_VERSION_INTERNAL,']','\\0'};
#elif defined(COMPILER_VERSION_INTERNAL_STR)
char const* info_version_internal = "INFO" ":" "compiler_version_internal[" COMPILER_VERSION_INTERNAL_STR "]";
#endif

/* Construct a string literal encoding the version number components. */
#ifdef SIMULATE_VERSION_MAJOR
char const info_simulate_version[] = {
  'I', 'N', 'F', 'O', ':',
  's','i','m','u','l','a','t','e','_','v','e','r','s','i','o','n','[',
  SIMULATE_VERSION_MAJOR,
# ifdef SIMULATE_VERSION_MINOR
  '.', SIMULATE_VERSION_MINOR,
#  ifdef SIMULATE_VERSION_PATCH
   '.', SIMULATE_VERSION_PATCH,
#   ifdef SIMULATE_VERSION_TWEAK
    '.', SIMULATE_VERSION_TWEAK,
#   endif
#  endif
# endif
  ']','\\0'};
#endif

/* Construct the string literal in pieces to prevent the source from
   getting matched.  Store it in a pointer rather than an array
   because some compilers will just produce instructions to fill the
   array rather than assigning a pointer to a static array.  */
char const* info_platform = "INFO" ":" "platform[" PLATFORM_ID "]";
char const* info_arch = "INFO" ":" "arch[" ARCHITECTURE_ID "]";
")
set(XDMF_CMAKE_C_COMPILER_ID_RUN		"1")
set(XDMF_CMAKE_C_COMPILER_ID_TEST_FLAGS		"-c;-Aa;-D__CLASSIC_C__;--target=arm-arm-none-eabi -mcpu=cortex-m3;-c -I__does_not_exist__")
set(XDMF_CMAKE_C_COMPILER_ID_TOOL_MATCH_INDEX		"2")
set(XDMF_CMAKE_C_COMPILER_ID_TOOL_MATCH_REGEX		"
Ld[^
]*(
[ 	]+[^
]*)*
[ 	]+([^ 	
]+)[^
]*-o[^
]*CompilerIdC/(\\./)?(CompilerIdC.(framework|xctest|build/[^ 	
]+)/)?CompilerIdC[ 	
\\"]")
set(XDMF_CMAKE_C_COMPILER_ID_VENDORS		"IAR")
set(XDMF_CMAKE_C_COMPILER_ID_VENDOR_REGEX_IAR		"IAR .+ Compiler")
set(XDMF_CMAKE_C_COMPILER_LINKER		"/usr/lib/gcc/x86_64-pc-cygwin/14/../../../../x86_64-pc-cygwin/bin/ld")
set(XDMF_CMAKE_C_COMPILER_LINKER_ARCHITECTURE_FLAGS		"-m;i386pep")
set(XDMF_CMAKE_C_COMPILER_LINKER_FRONTEND_VARIANT		"GNU")
set(XDMF_CMAKE_C_COMPILER_LINKER_ID		"GNU")
set(XDMF_CMAKE_C_COMPILER_LINKER_VERSION		"2.47.20260726")
set(XDMF_CMAKE_C_COMPILER_LOADED		"1")
set(XDMF_CMAKE_C_COMPILER_NAMES		"cc")
set(XDMF_CMAKE_C_COMPILER_PRODUCED_FILES		"a.exe")
set(XDMF_CMAKE_C_COMPILER_RANLIB		"/usr/bin/gcc-ranlib.exe")
set(XDMF_CMAKE_C_COMPILER_RANLIB		"/usr/bin/gcc-ranlib.exe")
set(XDMF_CMAKE_C_COMPILER_VERSION		"14.4.0")
set(XDMF_CMAKE_C_COMPILER_WORKS		"TRUE")
set(XDMF_CMAKE_C_COMPILE_FEATURES		"c_std_90;c_function_prototypes;c_std_99;c_restrict;c_variadic_macros;c_std_11;c_static_assert;c_std_17;c_std_23")
set(XDMF_CMAKE_C_COMPILE_OBJECT		"<CMAKE_C_COMPILER> <DEFINES> <INCLUDES> <FLAGS> -o <OBJECT> -c <SOURCE>")
set(XDMF_CMAKE_C_COMPILE_OPTIONS_COLOR_DIAGNOSTICS		"-fdiagnostics-color=always")
set(XDMF_CMAKE_C_COMPILE_OPTIONS_COLOR_DIAGNOSTICS_OFF		"-fno-diagnostics-color")
set(XDMF_CMAKE_C_COMPILE_OPTIONS_CREATE_PCH		"-x;c-header;-include;<PCH_HEADER>")
set(XDMF_CMAKE_C_COMPILE_OPTIONS_EXPLICIT_LANGUAGE		"-x;c")
set(XDMF_CMAKE_C_COMPILE_OPTIONS_INVALID_PCH		"-Winvalid-pch")
set(XDMF_CMAKE_C_COMPILE_OPTIONS_IPO		"-flto=auto;-fno-fat-lto-objects")
set(XDMF_CMAKE_C_COMPILE_OPTIONS_SYSROOT		"--sysroot=")
set(XDMF_CMAKE_C_COMPILE_OPTIONS_USE_PCH		"-include;<PCH_HEADER>")
set(XDMF_CMAKE_C_COMPILE_OPTIONS_VISIBILITY		"-fvisibility=")
set(XDMF_CMAKE_C_COMPILE_OPTIONS_WARNING_AS_ERROR		"-Werror")
set(XDMF_CMAKE_C_CREATE_ASSEMBLY_SOURCE		"<CMAKE_C_COMPILER> <DEFINES> <INCLUDES> <FLAGS> -S <SOURCE> -o <ASSEMBLY_SOURCE>")
set(XDMF_CMAKE_C_CREATE_PREPROCESSED_SOURCE		"<CMAKE_C_COMPILER> <DEFINES> <INCLUDES> <FLAGS> -E <SOURCE> > <PREPROCESSED_SOURCE>")
set(XDMF_CMAKE_C_CREATE_SHARED_LIBRARY		"<CMAKE_C_COMPILER> <LANGUAGE_COMPILE_FLAGS> <CMAKE_SHARED_LIBRARY_C_FLAGS> <LINK_FLAGS> -o <TARGET> -Wl,--out-implib,<TARGET_IMPLIB> -Wl,--major-image-version,<TARGET_VERSION_MAJOR>,--minor-image-version,<TARGET_VERSION_MINOR> <OBJECTS> <LINK_LIBRARIES>")
set(XDMF_CMAKE_C_CREATE_SHARED_MODULE		"<CMAKE_C_COMPILER> <LANGUAGE_COMPILE_FLAGS> <CMAKE_SHARED_MODULE_C_FLAGS> <LINK_FLAGS> -o <TARGET> -Wl,--major-image-version,<TARGET_VERSION_MAJOR>,--minor-image-version,<TARGET_VERSION_MINOR> <OBJECTS> <LINK_LIBRARIES>")
set(XDMF_CMAKE_C_CREATE_WIN32_EXE		"-mwindows")
set(XDMF_CMAKE_C_EXTENSIONS_COMPUTED_DEFAULT		"ON")
set(XDMF_CMAKE_C_EXTENSIONS_DEFAULT		"ON")
set(XDMF_CMAKE_C_FLAGS		"-ggdb -O2 -pipe -Wall -Werror=format-security -Wp,-D_FORTIFY_SOURCE=3 -fstack-protector-strong --param=ssp-buffer-size=4 -fdiagnostics-color -ffile-prefix-map=/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/build=/usr/src/debug/xdmf-3.0.0+git20200724-1bl2 -ffile-prefix-map=/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf=/usr/src/debug/xdmf-3.0.0+git20200724-1bl2")
set(XDMF_CMAKE_C_FLAGS_DEBUG		"-g")
set(XDMF_CMAKE_C_FLAGS_DEBUG_INIT		" -g")
set(XDMF_CMAKE_C_FLAGS_INIT		"-ggdb -O2 -pipe -Wall -Werror=format-security -Wp,-D_FORTIFY_SOURCE=3 -fstack-protector-strong --param=ssp-buffer-size=4 -fdiagnostics-color -ffile-prefix-map=/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/build=/usr/src/debug/xdmf-3.0.0+git20200724-1bl2 -ffile-prefix-map=/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf=/usr/src/debug/xdmf-3.0.0+git20200724-1bl2  ")
set(XDMF_CMAKE_C_FLAGS_MINSIZEREL		"-Os -DNDEBUG")
set(XDMF_CMAKE_C_FLAGS_MINSIZEREL_INIT		" -Os -DNDEBUG")
set(XDMF_CMAKE_C_FLAGS_RELEASE		"-O3 -DNDEBUG")
set(XDMF_CMAKE_C_FLAGS_RELEASE_INIT		" -O3 -DNDEBUG")
set(XDMF_CMAKE_C_FLAGS_RELWITHDEBINFO		"-O2 -g -DNDEBUG")
set(XDMF_CMAKE_C_FLAGS_RELWITHDEBINFO_INIT		" -O2 -g -DNDEBUG")
set(XDMF_CMAKE_C_IGNORE_EXTENSIONS		"h;H;o;O;obj;OBJ;def;DEF;rc;RC")
set(XDMF_CMAKE_C_IMPLICIT_INCLUDE_DIRECTORIES		"/usr/lib/gcc/x86_64-pc-cygwin/14/include;/usr/include;/usr/include/w32api")
set(XDMF_CMAKE_C_IMPLICIT_LINK_DIRECTORIES		"/usr/lib/gcc/x86_64-pc-cygwin/14;/usr/x86_64-pc-cygwin/lib;/usr/lib")
set(XDMF_CMAKE_C_IMPLICIT_LINK_LIBRARIES		"gcc_s;gcc;intl;iconv;cygwin;advapi32;shell32;user32;kernel32;gcc_s;gcc")
set(XDMF_CMAKE_C_INFORMATION_LOADED		"1")
set(XDMF_CMAKE_C_LINKER_DEPFILE_FLAGS		"LINKER:--dependency-file=<DEP_FILE>")
set(XDMF_CMAKE_C_LINKER_DEPFILE_FORMAT		"gcc")
set(XDMF_CMAKE_C_LINKER_DEPFILE_SUPPORTED		"FALSE")
set(XDMF_CMAKE_C_LINKER_INFORMATION_LOADED		"1")
set(XDMF_CMAKE_C_LINKER_PREFERENCE		"10")
set(XDMF_CMAKE_C_LINKER_PUSHPOP_STATE_SUPPORTED		"TRUE")
set(XDMF_CMAKE_C_LINKER_WRAPPER_FLAG		"-Wl,")
set(XDMF_CMAKE_C_LINKER_WRAPPER_FLAG_SEP		",")
set(XDMF_CMAKE_C_LINK_DEPENDS_USE_LINKER		"FALSE")
set(XDMF_CMAKE_C_LINK_EXECUTABLE		"<CMAKE_C_COMPILER> <FLAGS> <LINK_FLAGS> <OBJECTS> -o <TARGET> -Wl,--out-implib,<TARGET_IMPLIB> -Wl,--major-image-version,<TARGET_VERSION_MAJOR>,--minor-image-version,<TARGET_VERSION_MINOR> <LINK_LIBRARIES>")
set(XDMF_CMAKE_C_LINK_LIBRARY_USING_WHOLE_ARCHIVE		"LINKER:--push-state,--whole-archive;<LINK_ITEM>;LINKER:--pop-state")
set(XDMF_CMAKE_C_LINK_LIBRARY_USING_WHOLE_ARCHIVE_SUPPORTED		"TRUE")
set(XDMF_CMAKE_C_LINK_LIBRARY_WHOLE_ARCHIVE_ATTRIBUTES		"LIBRARY_TYPE=STATIC;DEDUPLICATION=YES;OVERRIDE=DEFAULT")
set(XDMF_CMAKE_C_LINK_MODE		"DRIVER")
set(XDMF_CMAKE_C_LINK_OPTIONS_WARNING_AS_ERROR		"LINKER:--fatal-warnings")
set(XDMF_CMAKE_C_OUTPUT_EXTENSION		".o")
set(XDMF_CMAKE_C_PLATFORM_ID		"Cygwin")
set(XDMF_CMAKE_C_PLATFORM_LINKER_ID		"GNU")
set(XDMF_CMAKE_C_SIZEOF_DATA_PTR		"8")
set(XDMF_CMAKE_C_SOURCE_FILE_EXTENSIONS		"c;m")
set(XDMF_CMAKE_C_STANDARD_COMPUTED_DEFAULT		"17")
set(XDMF_CMAKE_C_STANDARD_DEFAULT		"17")
set(XDMF_CMAKE_C_STANDARD_LATEST		"23")
set(XDMF_CMAKE_C_USE_LINKER_INFORMATION		"TRUE")
set(XDMF_CMAKE_C_VERBOSE_FLAG		"-v")
set(XDMF_CMAKE_C_VERBOSE_LINK_FLAG		"-Wl,-v")
set(XDMF_CMAKE_DEPFILE_FLAGS_C		"-MD -MT <DEP_TARGET> -MF <DEP_FILE>")
set(XDMF_CMAKE_DEPFILE_FLAGS_CXX		"-MD -MT <DEP_TARGET> -MF <DEP_FILE>")
set(XDMF_CMAKE_DIAGNOSTIC_INIT		"CMD_AUTHOR=IGNORE;CMD_DEPRECATED=IGNORE;CMD_EXPERIMENTAL=IGNORE;CMD_INSTALL_ABSOLUTE_DESTINATION=IGNORE;CMD_POLICY=IGNORE;CMD_UNINITIALIZED=IGNORE;CMD_UNUSED_CLI=WARN")
set(XDMF_CMAKE_DLLTOOL		"/usr/bin/dlltool.exe")
set(XDMF_CMAKE_DL_LIBS		"dl")
set(XDMF_CMAKE_EFFECTIVE_SYSTEM_NAME		"CYGWIN")
set(XDMF_CMAKE_ERROR_DEPRECATED		"OFF")
set(XDMF_CMAKE_EXECUTABLE_FORMAT		"Unknown")
set(XDMF_CMAKE_EXECUTABLE_SUFFIX		".exe")
set(XDMF_CMAKE_EXE_EXPORTS_CXX_FLAG		"-Wl,--export-all-symbols")
set(XDMF_CMAKE_EXE_EXPORTS_C_FLAG		"-Wl,--export-all-symbols")
set(XDMF_CMAKE_EXE_LINKER_FLAGS_INIT		" -Wl,--enable-auto-import  ")
set(XDMF_CMAKE_EXE_LINK_DYNAMIC_CXX_FLAGS		"-Wl,-Bdynamic")
set(XDMF_CMAKE_EXE_LINK_DYNAMIC_C_FLAGS		"-Wl,-Bdynamic")
set(XDMF_CMAKE_EXE_LINK_STATIC_CXX_FLAGS		"-Wl,-Bstatic")
set(XDMF_CMAKE_EXE_LINK_STATIC_C_FLAGS		"-Wl,-Bstatic")
set(XDMF_CMAKE_FILES_DIRECTORY		"/CMakeFiles")
set(XDMF_CMAKE_FIND_LIBRARY_PREFIXES		"lib")
set(XDMF_CMAKE_FIND_LIBRARY_SUFFIXES		".dll.a;.a")
set(XDMF_CMAKE_FIND_PACKAGE_REDIRECTS_DIR		"/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/build/CMakeFiles/pkgRedirects")
set(XDMF_CMAKE_Fortran_FLAGS		"-ggdb -O2 -pipe -Wall -Werror=format-security -Wp,-D_FORTIFY_SOURCE=3 -fstack-protector-strong --param=ssp-buffer-size=4 -fdiagnostics-color -ffile-prefix-map=/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/build=/usr/src/debug/xdmf-3.0.0+git20200724-1bl2 -ffile-prefix-map=/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf=/usr/src/debug/xdmf-3.0.0+git20200724-1bl2")
set(XDMF_CMAKE_GENERATOR		"Ninja")
set(XDMF_CMAKE_GENERATOR_RC		"windres")
set(XDMF_CMAKE_GNULD_IMAGE_VERSION		"-Wl,--major-image-version,<TARGET_VERSION_MAJOR>,--minor-image-version,<TARGET_VERSION_MINOR>")
set(XDMF_CMAKE_HAVE_LIBC_PTHREAD		"1")
set(XDMF_CMAKE_HOME_DIRECTORY		"/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf")
set(XDMF_CMAKE_HOST_PATH		"/usr/bin")
set(XDMF_CMAKE_HOST_SYSTEM		"CYGWIN-3.6.12-1.x86_64")
set(XDMF_CMAKE_HOST_SYSTEM_NAME		"CYGWIN")
set(XDMF_CMAKE_HOST_SYSTEM_PROCESSOR		"x86_64")
set(XDMF_CMAKE_HOST_SYSTEM_VERSION		"3.6.12-1.x86_64")
set(XDMF_CMAKE_HOST_UNIX		"1")
set(XDMF_CMAKE_IMPORT_LIBRARY_PREFIX		"lib")
set(XDMF_CMAKE_IMPORT_LIBRARY_SUFFIX		".dll.a")
set(XDMF_CMAKE_INCLUDE_FLAG_C		"-I")
set(XDMF_CMAKE_INCLUDE_FLAG_CXX		"-I")
set(XDMF_CMAKE_INCLUDE_FLAG_RC		"-I ")
set(XDMF_CMAKE_INCLUDE_SYSTEM_FLAG_C		"-isystem ")
set(XDMF_CMAKE_INCLUDE_SYSTEM_FLAG_CXX		"-isystem ")
set(XDMF_CMAKE_INSTALL_BINDIR		"bin")
set(XDMF_CMAKE_INSTALL_DATADIR		"share")
set(XDMF_CMAKE_INSTALL_DATADIR		"share")
set(XDMF_CMAKE_INSTALL_DATAROOTDIR		"share")
set(XDMF_CMAKE_INSTALL_DEFAULT_COMPONENT_NAME		"Unspecified")
set(XDMF_CMAKE_INSTALL_DOCDIR		"share/doc/Xdmf")
set(XDMF_CMAKE_INSTALL_DOCDIR		"share/doc/Xdmf")
set(XDMF_CMAKE_INSTALL_FULL_BINDIR		"/usr/bin")
set(XDMF_CMAKE_INSTALL_FULL_DATADIR		"/usr/share")
set(XDMF_CMAKE_INSTALL_FULL_DATAROOTDIR		"/usr/share")
set(XDMF_CMAKE_INSTALL_FULL_DOCDIR		"/usr/share/doc/Xdmf")
set(XDMF_CMAKE_INSTALL_FULL_INCLUDEDIR		"/usr/include")
set(XDMF_CMAKE_INSTALL_FULL_INFODIR		"/usr/share/info")
set(XDMF_CMAKE_INSTALL_FULL_LIBDIR		"/usr/lib")
set(XDMF_CMAKE_INSTALL_FULL_LIBEXECDIR		"/usr/libexec")
set(XDMF_CMAKE_INSTALL_FULL_LOCALEDIR		"/usr/share/locale")
set(XDMF_CMAKE_INSTALL_FULL_LOCALSTATEDIR		"/var")
set(XDMF_CMAKE_INSTALL_FULL_MANDIR		"/usr/share/man")
set(XDMF_CMAKE_INSTALL_FULL_OLDINCLUDEDIR		"/usr/include")
set(XDMF_CMAKE_INSTALL_FULL_RUNSTATEDIR		"/var/run")
set(XDMF_CMAKE_INSTALL_FULL_SBINDIR		"/usr/sbin")
set(XDMF_CMAKE_INSTALL_FULL_SHAREDSTATEDIR		"/usr/com")
set(XDMF_CMAKE_INSTALL_FULL_SYSCONFDIR		"/etc")
set(XDMF_CMAKE_INSTALL_INCLUDEDIR		"include")
set(XDMF_CMAKE_INSTALL_INFODIR		"share/info")
set(XDMF_CMAKE_INSTALL_INFODIR		"share/info")
set(XDMF_CMAKE_INSTALL_LIBDIR		"lib")
set(XDMF_CMAKE_INSTALL_LIBEXECDIR		"libexec")
set(XDMF_CMAKE_INSTALL_LOCALEDIR		"share/locale")
set(XDMF_CMAKE_INSTALL_LOCALEDIR		"share/locale")
set(XDMF_CMAKE_INSTALL_LOCALSTATEDIR		"var")
set(XDMF_CMAKE_INSTALL_MANDIR		"share/man")
set(XDMF_CMAKE_INSTALL_MANDIR		"share/man")
set(XDMF_CMAKE_INSTALL_OLDINCLUDEDIR		"/usr/include")
set(XDMF_CMAKE_INSTALL_PREFIX		"/usr")
set(XDMF_CMAKE_INSTALL_RUNSTATEDIR		"var/run")
set(XDMF_CMAKE_INSTALL_RUNSTATEDIR		"var/run")
set(XDMF_CMAKE_INSTALL_SBINDIR		"sbin")
set(XDMF_CMAKE_INSTALL_SHAREDSTATEDIR		"com")
set(XDMF_CMAKE_INSTALL_SYSCONFDIR		"etc")
set(XDMF_CMAKE_LEGACY_CYGWIN_WIN32		"0")
set(XDMF_CMAKE_LIBRARY_OUTPUT_DIRECTORY		"/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/build/lib")
set(XDMF_CMAKE_LIBRARY_PATH_FLAG		"-L")
set(XDMF_CMAKE_LINKER		"/usr/bin/ld.exe")
set(XDMF_CMAKE_LINKER		"/usr/bin/ld.exe")
set(XDMF_CMAKE_LINKER_PUSHPOP_STATE_SUPPORTED		"TRUE")
set(XDMF_CMAKE_LINK_LIBRARY_FLAG		"-l")
set(XDMF_CMAKE_LINK_LIBRARY_USING_DEFAULT_SUPPORTED		"TRUE")
set(XDMF_CMAKE_LINK_LIBRARY_USING_WHOLE_ARCHIVE		"LINKER:--push-state,--whole-archive;<LINK_ITEM>;LINKER:--pop-state")
set(XDMF_CMAKE_LINK_LIBRARY_USING_WHOLE_ARCHIVE_SUPPORTED		"TRUE")
set(XDMF_CMAKE_LINK_LIBRARY_WHOLE_ARCHIVE_ATTRIBUTES		"LIBRARY_TYPE=STATIC;DEDUPLICATION=YES;OVERRIDE=DEFAULT")
set(XDMF_CMAKE_LIST_FILE_NAME		"CMakeLists.txt")
set(XDMF_CMAKE_MAJOR_VERSION		"4")
set(XDMF_CMAKE_MAKE_PROGRAM		"/usr/bin/ninja.exe")
set(XDMF_CMAKE_MATCH_COUNT		"0")
set(XDMF_CMAKE_MINIMUM_REQUIRED_VERSION		"2.8.5")
set(XDMF_CMAKE_MINOR_VERSION		"4")
set(XDMF_CMAKE_MODULE_EXISTS		"1")
set(XDMF_CMAKE_MODULE_LINKER_FLAGS_INIT		"  ")
set(XDMF_CMAKE_MODULE_PATH		"/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf/CMake;/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf/CMake/VersionSuite;/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf/CMake/TestingSuite")
set(XDMF_CMAKE_NM		"/usr/bin/nm.exe")
set(XDMF_CMAKE_OBJCOPY		"/usr/bin/objcopy.exe")
set(XDMF_CMAKE_OBJDUMP		"/usr/bin/objdump.exe")
set(XDMF_CMAKE_PARENT_LIST_FILE		"/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf/CMakeLists.txt")
set(XDMF_CMAKE_PATCH_VERSION		"5")
set(XDMF_CMAKE_PCH_EXTENSION		".gch")
set(XDMF_CMAKE_PCH_PROLOGUE		"#pragma GCC system_header")
set(XDMF_CMAKE_PLATFORM_IMPLICIT_LINK_DIRECTORIES		"/lib;/lib32;/lib64;/usr/lib;/usr/lib32;/usr/lib64")
set(XDMF_CMAKE_PLATFORM_INFO_DIR		"/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/build/CMakeFiles/4.4.5")
set(XDMF_CMAKE_PLATFORM_INFO_INITIALIZED		"1")
set(XDMF_CMAKE_POLICY_VERSION_MINIMUM		"3.5")
set(XDMF_CMAKE_PROJECT_NAME		"Xdmf")
set(XDMF_CMAKE_RANLIB		"/usr/bin/ranlib.exe")
set(XDMF_CMAKE_RANLIB		"/usr/bin/ranlib.exe")
set(XDMF_CMAKE_RC_COMPILER		"/usr/bin/windres.exe")
set(XDMF_CMAKE_RC_COMPILER		"/usr/bin/windres.exe")
set(XDMF_CMAKE_RC_COMPILER_ENV_VAR		"RC")
set(XDMF_CMAKE_RC_COMPILER_INIT		"windres")
set(XDMF_CMAKE_RC_COMPILER_LOADED		"1")
set(XDMF_CMAKE_RC_COMPILER_WORKS		"1")
set(XDMF_CMAKE_RC_COMPILE_OBJECT		"<CMAKE_RC_COMPILER> -O coff <DEFINES> <INCLUDES> <FLAGS> <SOURCE> <OBJECT>")
set(XDMF_CMAKE_RC_FLAGS_INIT		" ")
set(XDMF_CMAKE_RC_FLAG_REGEX		"^[-/](D|I)")
set(XDMF_CMAKE_RC_INFORMATION_LOADED		"1")
set(XDMF_CMAKE_RC_OUTPUT_EXTENSION		".obj")
set(XDMF_CMAKE_RC_SOURCE_FILE_EXTENSIONS		"rc;RC")
set(XDMF_CMAKE_RC_USE_LINKER_INFORMATION		"FALSE")
set(XDMF_CMAKE_READELF		"/usr/bin/readelf.exe")
set(XDMF_CMAKE_ROOT		"/usr/share/cmake-4.4.5")
set(XDMF_CMAKE_RUNTIME_OUTPUT_DIRECTORY		"/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/build/bin")
set(XDMF_CMAKE_SHARED_LIBRARY_CREATE_CXX_FLAGS		"-shared -Wl,--enable-auto-import")
set(XDMF_CMAKE_SHARED_LIBRARY_CREATE_C_FLAGS		"-shared -Wl,--enable-auto-import")
set(XDMF_CMAKE_SHARED_LIBRARY_LINK_DYNAMIC_CXX_FLAGS		"-Wl,-Bdynamic")
set(XDMF_CMAKE_SHARED_LIBRARY_LINK_DYNAMIC_C_FLAGS		"-Wl,-Bdynamic")
set(XDMF_CMAKE_SHARED_LIBRARY_LINK_STATIC_CXX_FLAGS		"-Wl,-Bstatic")
set(XDMF_CMAKE_SHARED_LIBRARY_LINK_STATIC_C_FLAGS		"-Wl,-Bstatic")
set(XDMF_CMAKE_SHARED_LIBRARY_NAME_WITH_VERSION		"1")
set(XDMF_CMAKE_SHARED_LIBRARY_PREFIX		"cyg")
set(XDMF_CMAKE_SHARED_LIBRARY_SUFFIX		".dll")
set(XDMF_CMAKE_SHARED_LINKER_FLAGS_INIT		"  ")
set(XDMF_CMAKE_SHARED_MODULE_CREATE_CXX_FLAGS		"-shared -Wl,--enable-auto-import")
set(XDMF_CMAKE_SHARED_MODULE_CREATE_C_FLAGS		"-shared -Wl,--enable-auto-import")
set(XDMF_CMAKE_SHARED_MODULE_LINK_DYNAMIC_CXX_FLAGS		"-Wl,-Bdynamic")
set(XDMF_CMAKE_SHARED_MODULE_LINK_DYNAMIC_C_FLAGS		"-Wl,-Bdynamic")
set(XDMF_CMAKE_SHARED_MODULE_LINK_STATIC_CXX_FLAGS		"-Wl,-Bstatic")
set(XDMF_CMAKE_SHARED_MODULE_LINK_STATIC_C_FLAGS		"-Wl,-Bstatic")
set(XDMF_CMAKE_SHARED_MODULE_PREFIX		"cyg")
set(XDMF_CMAKE_SHARED_MODULE_SUFFIX		".dll")
set(XDMF_CMAKE_SIZEOF_VOID_P		"8")
set(XDMF_CMAKE_SKIP_INSTALL_RPATH		"NO")
set(XDMF_CMAKE_SKIP_RPATH		"NO")
set(XDMF_CMAKE_SOURCE_DIR		"/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf")
set(XDMF_CMAKE_STATIC_LIBRARY_PREFIX		"lib")
set(XDMF_CMAKE_STATIC_LIBRARY_SUFFIX		".a")
set(XDMF_CMAKE_STRIP		"/usr/bin/strip.exe")
set(XDMF_CMAKE_SYSTEM		"CYGWIN-3.6.12-1.x86_64")
set(XDMF_CMAKE_SYSTEM_AND_RC_COMPILER_INFO_FILE		"/usr/share/cmake-4.4.5/Modules/Platform/CYGWIN-windres.cmake")
set(XDMF_CMAKE_SYSTEM_INCLUDE_PATH		"/usr/include/X11;/usr/include/w32api")
set(XDMF_CMAKE_SYSTEM_INFO_FILE		"Platform/CYGWIN")
set(XDMF_CMAKE_SYSTEM_LIBRARY_PATH		"/usr/lib/X11;/usr/lib/w32api")
set(XDMF_CMAKE_SYSTEM_LOADED		"1")
set(XDMF_CMAKE_SYSTEM_NAME		"CYGWIN")
set(XDMF_CMAKE_SYSTEM_PREFIX_PATH		"/usr/local;/usr;/;/usr;/usr;/usr/X11R6;/usr/pkg;/opt")
set(XDMF_CMAKE_SYSTEM_PROCESSOR		"x86_64")
set(XDMF_CMAKE_SYSTEM_SPECIFIC_INFORMATION_LOADED		"1")
set(XDMF_CMAKE_SYSTEM_SPECIFIC_INITIALIZE_LOADED		"1")
set(XDMF_CMAKE_SYSTEM_VERSION		"3.6.12-1.x86_64")
set(XDMF_CMAKE_TAPI		"CMAKE_TAPI-NOTFOUND")
set(XDMF_CMAKE_TAPI		"CMAKE_TAPI-NOTFOUND")
set(XDMF_CMAKE_TESTING_ENABLED		"1")
set(XDMF_CMAKE_TWEAK_VERSION		"0")
set(XDMF_CMAKE_UNAME		"/usr/bin/uname.exe")
set(XDMF_CMAKE_VERBOSE_MAKEFILE		"FALSE")
set(XDMF_CMAKE_VERSION		"4.4.5")
set(XDMF_CMAKE_WARN_DEPRECATED		"OFF")
set(XDMF_COMPILER_BASENAME		"g++.exe")
set(XDMF_COMPRESS_SUBMISSION		"ON")
set(XDMF_COVERAGE_COMMAND		"/usr/bin/gcov.exe")
set(XDMF_COVERAGE_EXTRA_FLAGS		"-l")
set(XDMF_CTEST_CURL_OPTIONS		"CURLOPT_SSL_VERIFYPEER_OFF;CURLOPT_SSL_VERIFYHOST_OFF")
set(XDMF_CTEST_DROP_LOCATION		"/submit.php?project=XDMF")
set(XDMF_CTEST_DROP_METHOD		"https")
set(XDMF_CTEST_DROP_SITE		"open.cdash.org")
set(XDMF_CTEST_DROP_SITE_CDASH		"True")
set(XDMF_CTEST_NIGHTLY_START_TIME		"00:00:00 EDT")
set(XDMF_CTEST_PROJECT_NAME		"XDMF")
set(XDMF_CTEST_SUBMIT_RETRY_COUNT		"3")
set(XDMF_CTEST_SUBMIT_RETRY_DELAY		"5")
set(XDMF_CYGWIN		"1")
set(XDMF_DART_COMPILER		"/usr/bin/g++.exe")
set(XDMF_DART_COMPILER_NAME		"g++.exe")
set(XDMF_DART_NAME_COMPONENT		"NAME")
set(XDMF_DART_TESTING_TIMEOUT		"1500")
set(XDMF_DEFAULT_CTEST_CONFIGURATION_TYPE		"Release")
set(XDMF_DEF_INSTALL_CMAKE_DIR		"lib/cmake/Xdmf")
set(XDMF_DROP_LOCATION		"/submit.php?project=XDMF")
set(XDMF_DROP_METHOD		"https")
set(XDMF_DROP_SITE		"open.cdash.org")
set(XDMF_FIND_PACKAGE_MESSAGE_DETAILS_Boost		"[/usr/include][ ][v1.66.0()]")
set(XDMF_FIND_PACKAGE_MESSAGE_DETAILS_HDF5		"[hdf5-shared][/usr/include][ ][v2.2.0()]")
set(XDMF_FIND_PACKAGE_MESSAGE_DETAILS_LibXml2		"[/usr/lib/libxml2.dll.a][/usr/include/libxml2][v2.13.9()]")
set(XDMF_FIND_PACKAGE_MESSAGE_DETAILS_TIFF		"[/usr/lib/cmake/tiff][ ][v4.7.2()]")
set(XDMF_HDF5_DIFF_EXECUTABLE		"/usr/bin/h5diff.exe")
set(XDMF_HDF5_DIR		"/usr/lib/cmake/hdf5")
set(XDMF_LIBXML2_INCLUDE_DIR		"/usr/include/libxml2")
set(XDMF_LIBXML2_LIBRARY		"/usr/lib/libxml2.dll.a")
set(XDMF_LIBXML2_XMLLINT_EXECUTABLE		"LIBXML2_XMLLINT_EXECUTABLE-NOTFOUND")
set(XDMF_MAKECOMMAND		"/usr/bin/cmake.exe --build . --config "${CTEST_CONFIGURATION_TYPE}"")
set(XDMF_MAKECOMMAND_DEFAULT_VALUE		"/usr/bin/cmake.exe --build . --config "${CTEST_CONFIGURATION_TYPE}"")
set(XDMF_MEMORYCHECK_COMMAND		"MEMORYCHECK_COMMAND-NOTFOUND")
set(XDMF_NIGHTLY_START_TIME		"00:00:00 EDT")
set(XDMF_PC_LIBXML_CFLAGS		"-I/usr/include/libxml2;-I/usr/include")
set(XDMF_PC_LIBXML_FOUND		"1")
set(XDMF_PC_LIBXML_INCLUDEDIR		"/usr/include")
set(XDMF_PC_LIBXML_INCLUDE_DIRS		"/usr/include/libxml2;/usr/include")
set(XDMF_PC_LIBXML_LDFLAGS		"-L/usr/lib;-lxml2")
set(XDMF_PC_LIBXML_LIBDIR		"/usr/lib")
set(XDMF_PC_LIBXML_LIBRARIES		"xml2")
set(XDMF_PC_LIBXML_LIBRARY_DIRS		"/usr/lib")
set(XDMF_PC_LIBXML_MODULE_NAME		"libxml-2.0")
set(XDMF_PC_LIBXML_PREFIX		"/usr")
set(XDMF_PC_LIBXML_STATIC_CFLAGS		"-I/usr/include/libxml2;-I/usr/include;-DLZMA_API_STATIC")
set(XDMF_PC_LIBXML_STATIC_CFLAGS_OTHER		"-DLZMA_API_STATIC")
set(XDMF_PC_LIBXML_STATIC_INCLUDE_DIRS		"/usr/include/libxml2;/usr/include")
set(XDMF_PC_LIBXML_STATIC_LDFLAGS		"-L/usr/lib;-lxml2;-lz;-llzma;-pthread;-lpthread")
set(XDMF_PC_LIBXML_STATIC_LDFLAGS_OTHER		"-pthread")
set(XDMF_PC_LIBXML_STATIC_LIBRARIES		"xml2;z;lzma;pthread")
set(XDMF_PC_LIBXML_STATIC_LIBRARY_DIRS		"/usr/lib")
set(XDMF_PC_LIBXML_VERSION		"2.13.9")
set(XDMF_PKG_CONFIG_EXECUTABLE		"/usr/bin/pkg-config")
set(XDMF_PROJECT_BINARY_DIR		"/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/build")
set(XDMF_PROJECT_IS_TOP_LEVEL		"ON")
set(XDMF_PROJECT_NAME		"Xdmf")
set(XDMF_PROJECT_SOURCE_DIR		"/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf")
set(XDMF_RUN_CONFIGURE		"ON")
set(XDMF_SITE		"runnervmbpeip")
set(XDMF_SUBMIT_URL		"https://open.cdash.org/submit.php?project=XDMF")
set(XDMF_TESTING_SUITE_DIR		"/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf/CMake")
set(XDMF_TIFF_FOUND		"TRUE")
set(XDMF_TIFF_INCLUDE_DIR		"/usr/include")
set(XDMF_TIFF_INCLUDE_DIRS		"/usr/include")
set(XDMF_TIFF_LIBRARIES		"/usr/lib/libtiff.dll.a")
set(XDMF_TIFF_VERSION		"4.7.2")
set(XDMF_TIFF_VERSION_STRING		"4.7.2")
set(XDMF_Tiff_CONFIG		"/usr/lib/cmake/tiff/tiff-config.cmake")
set(XDMF_Tiff_CONSIDERED_CONFIGS		"/usr/lib/cmake/tiff/tiff-config.cmake")
set(XDMF_Tiff_CONSIDERED_VERSIONS		"4.7.2")
set(XDMF_Tiff_DIR		"/usr/lib/cmake/tiff")
set(XDMF_Tiff_FOUND		"1")
set(XDMF_Tiff_VERSION		"4.7.2")
set(XDMF_Tiff_VERSION_COUNT		"3")
set(XDMF_Tiff_VERSION_MAJOR		"4")
set(XDMF_Tiff_VERSION_MINOR		"7")
set(XDMF_Tiff_VERSION_PATCH		"2")
set(XDMF_Tiff_VERSION_TWEAK		"0")
set(XDMF_UNIX		"1")
set(XDMF_VERSION_CONTROL_AUTOUPDATE		"OFF")
set(XDMF_BUILD_CORE_ONLY		"OFF")
set(XDMF_BUILD_DOCUMENTATION		"OFF")
set(XDMF_BUILD_DSM		"OFF")
set(XDMF_BUILD_EXODUS_IO		"OFF")
set(XDMF_BUILD_FORTRAN		"OFF")
set(XDMF_BUILD_PARTITIONER		"OFF")
set(XDMF_BUILD_TESTING		"ON")
set(XDMF_BUILD_UTILS		"ON")
set(XDMF_DIR		"/usr")
set(XDMF_INCLUDE_DIRS		"/usr/include")
set(XDMF_LIBNAME		"Xdmf")
set(XDMF_MAJOR_VERSION		"3")
set(XDMF_MINOR_VERSION		"0")
set(XDMF_PATCH_VERSION		"0")
set(XDMF_VERSION		"3.0.0")
set(XDMF_WRAP_JAVA		"OFF")
set(XDMF_WRAP_PYTHON		"OFF")
set(XDMF_XdmfCoreSources		"core/XdmfArray;core/XdmfArrayReference;core/XdmfArrayType;core/XdmfBinaryController;core/XdmfCoreItemFactory;core/XdmfCoreReader;core/XdmfError;core/XdmfFunction;core/XdmfHDF5Controller;core/XdmfHDF5Writer;core/XdmfHeavyDataController;core/XdmfHeavyDataDescription;core/XdmfHeavyDataWriter;core/XdmfInformation;core/XdmfItem;core/XdmfItemProperty;core/XdmfPlaceholder;core/XdmfSparseMatrix;core/XdmfSubset;core/XdmfSystemUtils;core/XdmfTIFFController;/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/build/core/XdmfVersion;core/XdmfVisitor;core/XdmfWriter")
set(XDMF_XdmfCore_BINARY_DIR		"/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/build/core")
set(XDMF_XdmfCore_INCLUDE_DIRS		"/usr/include;/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf/core;/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/build/core;/usr/include;/usr/include/libxml2")
set(XDMF_XdmfCore_IS_TOP_LEVEL		"OFF")
set(XDMF_XdmfCore_LIB_DEPENDS		"general;hdf5-shared;general;/usr/lib/libxml2.dll.a;general;/usr/lib/libtiff.dll.a;")
set(XDMF_XdmfCore_SOURCE_DIR		"/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf/core")
set(XDMF_XdmfHeaders		"/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/build/XdmfConfig.hpp;/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf/Xdmf.hpp;/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf/Xdmf.i;/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf/XdmfAggregate.hpp;/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf/XdmfAttribute.hpp;/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf/XdmfAttributeCenter.hpp;/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf/XdmfAttributeType.hpp;/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf/XdmfCurvilinearGrid.hpp;/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf/XdmfDomain.hpp;/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf/XdmfGeometry.hpp;/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf/XdmfGeometryType.hpp;/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf/XdmfGraph.hpp;/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf/XdmfGrid.hpp;/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf/XdmfGridCollection.hpp;/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf/XdmfGridCollectionType.hpp;/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf/XdmfGridController.hpp;/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf/XdmfGridTemplate.hpp;/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf/XdmfItemFactory.hpp;/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf/XdmfMap.hpp;/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf/XdmfReader.hpp;/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf/XdmfRectilinearGrid.hpp;/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf/XdmfRegularGrid.hpp;/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf/XdmfSet.hpp;/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf/XdmfSetType.hpp;/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf/XdmfTemplate.hpp;/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf/XdmfTime.hpp;/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf/XdmfTopology.hpp;/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf/XdmfTopologyType.hpp;/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf/XdmfUnstructuredGrid.hpp")
set(XDMF_XdmfSources		"XdmfAggregate;XdmfAttribute;XdmfAttributeCenter;XdmfAttributeType;XdmfCurvilinearGrid;XdmfDomain;XdmfGeometry;XdmfGeometryType;XdmfGraph;XdmfGrid;XdmfGridCollection;XdmfGridCollectionType;XdmfGridController;XdmfGridTemplate;XdmfItemFactory;XdmfMap;XdmfReader;XdmfRectilinearGrid;XdmfRegularGrid;XdmfSet;XdmfSetType;XdmfTemplate;XdmfTime;XdmfTopology;XdmfTopologyType;XdmfUnstructuredGrid")
set(XDMF_XdmfUtils_LIB_DEPENDS		"general;Xdmf;")
set(XDMF_Xdmf_BINARY_DIR		"/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/build")
set(XDMF_Xdmf_IS_TOP_LEVEL		"ON")
set(XDMF_Xdmf_LIB_DEPENDS		"general;XdmfCore;")
set(XDMF_Xdmf_SOURCE_DIR		"/cygdrive/d/a/dist/dist/yacp/xdmf/xdmf-3.0.0+git20200724-1bl2.x86_64/src/xdmf")
set(XDMF_ZLIB_INCLUDE_DIR		"/usr/include")
set(XDMF_ZLIB_LIBRARY_DEBUG		"ZLIB_LIBRARY_DEBUG-NOTFOUND")
set(XDMF_ZLIB_LIBRARY_RELEASE		"/usr/lib/libz.dll.a")
set(XDMF__Boost_INCLUDE_DIR_LAST		"/usr/include")
set(XDMF__Boost_NAMESPACE_LAST		"boost")
set(XDMF__Boost_USE_MULTITHREADED_LAST		"TRUE")
set(XDMF__CMAKE_CUDA_IMPLICIT_INCLUDE_DIRECTORIES_INIT		"/usr/include")
set(XDMF__CMAKE_CXX_IMPLICIT_INCLUDE_DIRECTORIES_INIT		"/usr/include")
set(XDMF__CMAKE_CXX_IPO_MAY_BE_SUPPORTED_BY_COMPILER		"YES")
set(XDMF__CMAKE_CXX_IPO_SUPPORTED_BY_CMAKE		"YES")
set(XDMF__CMAKE_CXX_PIE_MAY_BE_SUPPORTED_BY_LINKER		"NO")
set(XDMF__CMAKE_C_IMPLICIT_INCLUDE_DIRECTORIES_INIT		"/usr/include")
set(XDMF__CMAKE_C_IPO_MAY_BE_SUPPORTED_BY_COMPILER		"YES")
set(XDMF__CMAKE_C_IPO_SUPPORTED_BY_CMAKE		"YES")
set(XDMF__CMAKE_C_PIE_MAY_BE_SUPPORTED_BY_LINKER		"NO")
set(XDMF__CMAKE_INSTALL_DIR		"/usr")
set(XDMF__CMAKE_RC_COMPILER_NAME_WE		"windres")
set(XDMF__CMAKE_SYSTEM_PREFIX_PATH_INSTALL_PREFIX_COUNT		"3")
set(XDMF__CMAKE_SYSTEM_PREFIX_PATH_INSTALL_PREFIX_VALUE		"/usr")
set(XDMF__CMAKE_SYSTEM_PREFIX_PATH_STAGING_PREFIX_COUNT		"0")
set(XDMF__CMAKE_TOOLCHAIN_LOCATION		"/usr/bin")
set(XDMF__CMAKE_USER_CXX_COMPILER_PATH		"/usr/bin")
set(XDMF__CMAKE_USER_C_COMPILER_PATH		"/usr/bin")
set(XDMF__FUNCTION_ARGNC		"0")
set(XDMF__GNUInstallDirs_LAST_CMAKE_INSTALL_PREFIX		"/usr")
set(XDMF__INCLUDED_FILE		"/usr/share/cmake-4.4.5/Modules/Platform/Linker/CYGWIN-GNU-CXX.cmake")
set(XDMF__INCLUDED_SYSTEM_INFO_FILE		"/usr/share/cmake-4.4.5/Modules/Platform/CYGWIN.cmake")
set(XDMF__IN_TC		"0")
set(XDMF___COMPILER_CMAKE_COMMON_COMPILER_MACROS		"1")
set(XDMF___COMPILER_GNU		"1")
set(XDMF___CYGWIN_COMPILER_GNU		"1")
set(XDMF___INCGUARD_4d707ac018791b1d630fd7c27b9ccd63__		"ON")
set(XDMF___INCGUARD_5fd9ffab3cb6dd807659a6f5e67a7a39__		"ON")
set(XDMF___INCGUARD_b6ce16bfb373575b3112c2b9ee6bca25__		"ON")
set(XDMF___UNIX_PATHS_INCLUDED		"1")
set(XDMF___gcc_hints		"/usr/bin")
set(XDMF___lto_flags		"-flto=auto;-fno-fat-lto-objects")
set(XDMF___pch_header_C		"c-header")
set(XDMF___pch_header_CXX		"c++-header")
set(XDMF___pch_header_OBJC		"objective-c-header")
set(XDMF___pch_header_OBJCXX		"objective-c++-header")
set(XDMF___pkg_config_arguments_PC_LIBXML		"QUIET;libxml-2.0")
set(XDMF___pkg_config_checked_PC_LIBXML		"1")
set(XDMF___version_x		"14")
set(XDMF___version_x_y		"14.4")
set(XDMF__isMultiConfig		"0")
set(XDMF__uname_result		"0")
set(XDMF_libaec_DIR		"/usr/lib/cmake/libaec")
set(XDMF_name		"Xdmf")
set(XDMF_pkgcfg_lib_PC_LIBXML_xml2		"/usr/lib/libxml2.dll.a")
set(XDMF_prefix_result		"/usr/lib")
set(XDMF_val		"0")
