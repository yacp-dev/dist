/*
 *  Mathlib : A C Library of Special Functions
 *  Copyright (C) 1998 Ross Ihaka
 *  Copyright (C) 2000-6 The R Core Team
 *  Copyright (C) 2015-2025 Martyn Plummer
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, a copy is available at
 *  https://www.R-project.org/Licenses/
 *
 *  DESCRIPTION
 *
 *    The density function of the Weibull distribution using the BUGS
 *    parameterization, i.e. x^shape has exponential distribution with
 *    mean 1/rate.
 */

#include "nmath.h"
#include "dpq.h"

double dweibull2(double x, double shape, double rate, int give_log)
{
    double tmp1, tmp2;
#ifdef IEEE_754
    if (ISNAN(x) || ISNAN(shape) || ISNAN(rate))
	return x + shape + rate;
#endif
    if (shape <= 0 || rate <= 0) ML_WARN_return_NAN;

    if (x < 0) return R_D__0;
    if (!R_FINITE(x)) return R_D__0;
    /* need to handle x == 0 separately */
    if(x == 0 && shape < 1) return ML_POSINF;
    tmp1 = rate * pow(x, shape - 1);
    tmp2 = tmp1 * x;
    /* These are incorrect if tmp1 == 0 */
    return  give_log ?
	-tmp2 + log(shape * tmp1) :
	shape * tmp1 * exp(-tmp2);
}
