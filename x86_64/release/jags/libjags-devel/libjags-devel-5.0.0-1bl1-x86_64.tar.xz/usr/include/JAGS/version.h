#ifndef JAGS_VERSION_H_
#define JAGS_VERSION_H_

#define JAGS_MAJOR 5
#define JAGS_MINOR 0
#define JAGS_PATCH 0

extern "C" {
   char const * jags_version();
}

#endif /* JAGS_VERSION_H_ */
