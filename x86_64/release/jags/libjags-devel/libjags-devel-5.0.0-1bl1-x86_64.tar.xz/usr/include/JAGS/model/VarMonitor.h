#ifndef VAR_MONITOR_H_
#define VAR_MONITOR_H_

#include <model/Monitor.h>

#include <vector>

#if defined(_S)
#undef _S
#endif

namespace jags {

    /**
     * @short Stores running variance of a given stat
     */
    class VarMonitor : public Monitor {
	std::vector<std::vector<double>> _S, _SS, _W, _WW;
	std::vector<bool> _missing;
    public:
	VarMonitor(std::vector<Node const *> const &nodes,
		   MonitorStat *stat);
	void update(unsigned int chain) override;
	std::vector<double> value(unsigned int chain) const override;
	bool poolChains() const override;
	bool poolIterations() const override;
    };

}

#endif /* VAR_MONITOR_H_ */
