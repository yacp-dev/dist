//          Copyright Carl Philipp Reh 2009 - 2021.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#ifndef FCPPT_CAST_DYNAMIC_CROSS_FUN_FWD_HPP_INCLUDED
#define FCPPT_CAST_DYNAMIC_CROSS_FUN_FWD_HPP_INCLUDED

namespace fcppt::cast
{

struct dynamic_cross_fun;

}

#endif
