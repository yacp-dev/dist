//          Copyright Carl Philipp Reh 2009 - 2021.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#ifndef FCPPT_CONTAINER_GET_OR_INSERT_RESULT_HPP_INCLUDED
#define FCPPT_CONTAINER_GET_OR_INSERT_RESULT_HPP_INCLUDED

#include <fcppt/container/get_or_insert_result_decl.hpp> // IWYU pragma: export
#include <fcppt/container/get_or_insert_result_fwd.hpp> // IWYU pragma: keep
#include <fcppt/container/get_or_insert_result_impl.hpp> // IWYU pragma: keep

#endif
