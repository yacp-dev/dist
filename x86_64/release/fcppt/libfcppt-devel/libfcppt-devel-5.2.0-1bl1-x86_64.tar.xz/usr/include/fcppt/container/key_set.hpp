//          Copyright Carl Philipp Reh 2009 - 2021.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#ifndef FCPPT_CONTAINER_KEY_SET_HPP_INCLUDED
#define FCPPT_CONTAINER_KEY_SET_HPP_INCLUDED

#include <fcppt/algorithm/map.hpp>

namespace fcppt::container
{
/**
\brief Creates a set of keys from a map.

\ingroup fcpptcontainer

Inserts every key from \a _map into the resulting set.

\tparam Map A map-like container.

\tparam Set A set-like container.
*/
template <typename Set, typename Map>
inline Set key_set(Map const &_map)
{
  return fcppt::algorithm::map<Set>(
      _map, [](Map::const_reference _item) { return _item.first; });
}

}

#endif
