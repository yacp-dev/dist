
#ifndef FCPPT_DETAIL_SYMBOL_HPP_INCLUDED
#define FCPPT_DETAIL_SYMBOL_HPP_INCLUDED

#ifdef FCPPT_STATIC_LINK
#	define FCPPT_DETAIL_SYMBOL
#elifdef fcppt_core_EXPORTS
#	include <fcppt/symbol/export.hpp>
#	define FCPPT_DETAIL_SYMBOL FCPPT_SYMBOL_EXPORT
#else
#	include <fcppt/symbol/import.hpp>
#	define FCPPT_DETAIL_SYMBOL FCPPT_SYMBOL_IMPORT
#endif

#endif
