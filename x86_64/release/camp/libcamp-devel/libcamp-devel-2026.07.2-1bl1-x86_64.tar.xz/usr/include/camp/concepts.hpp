//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
// Copyright (c) Lawrence Livermore National Security, LLC and other
// Camp Project Developers. See top-level LICENSE and COPYRIGHT
// files for dates and other details. No copyright assignment is required
// to contribute to Camp.
//
// SPDX-License-Identifier: (BSD-3-Clause)
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

#ifndef CAMP_CONCEPTS_HPP
#define CAMP_CONCEPTS_HPP

#include <concepts>
#include <iterator>
#include <type_traits>

#include "camp/helpers.hpp"
#include "camp/list.hpp"
#include "camp/number.hpp"
#include "camp/type_traits/is_same.hpp"

namespace camp
{

namespace concepts
{

  namespace metalib
  {
    using camp::is_same;

    /// negation metafunction of a value type
    template <typename T>
    struct negate_t : num<!T::value> {
    };

    /// all_of metafunction of a value type list -- all must be "true"
    template <bool... Bs>
    struct all_of : metalib::is_same<list<t, num<Bs>...>, list<num<Bs>..., t>> {
    };

    /// none_of metafunction of a value type list -- all must be "false"
    template <bool... Bs>
    struct none_of
        : metalib::is_same<idx_seq<false, Bs...>, idx_seq<Bs..., false>> {
    };

    /// any_of metafunction of a value type list -- at least one must be "true""
    template <bool... Bs>
    struct any_of : negate_t<none_of<Bs...>> {
    };

    /// all_of metafunction of a bool list -- all must be "true"
    template <typename... Bs>
    struct all_of_t : all_of<Bs::value...> {
    };

    /// none_of metafunction of a bool list -- all must be "false"
    template <typename... Bs>
    struct none_of_t : none_of<Bs::value...> {
    };

    /// any_of metafunction of a bool list -- at least one must be "true""
    template <typename... Bs>
    struct any_of_t : any_of<Bs::value...> {
    };

  }  // end namespace metalib

}  // end namespace concepts
}  // end namespace camp

namespace camp
{
namespace concepts
{

  namespace detail
  {

    template <class...>
    struct TL {
    };

    template <class...>
    struct voider {
      using type = void;
    };

    template <class Default,
              class /* always void*/,
              template <class...> class Concept,
              class TArgs>
    struct detector {
      using value_t = false_type;
      using type = Default;
    };

    template <class Default, template <class...> class Concept, class... Args>
    struct detector<Default,
                    typename voider<Concept<Args...>>::type,
                    Concept,
                    TL<Args...>> {
      using value_t = true_type;
      using type = Concept<Args...>;
    };

    template <template <class...> class Concept, class TArgs>
    using is_detected = detector<void, void, Concept, TArgs>;

    template <template <class...> class Concept, class TArgs>
    using detected = typename is_detected<Concept, TArgs>::value_t;


    template <typename Ret, typename T>
    Ret returns(T const &) noexcept;

  }  // end namespace detail

  template <typename T>
  using negate = metalib::negate_t<T>;

  /// metafunction for use within decltype expression to validate return type is
  /// convertible to given type
  template <typename T, typename U>
  constexpr auto convertible_to(U &&u) noexcept
      -> decltype(detail::returns<camp::true_type>(static_cast<T>((U &&)u)));

  /// metafunction for use within decltype expression to validate type of
  /// expression
  template <typename T, typename U>
  constexpr auto has_type(U &&) noexcept -> metalib::is_same<T, U>;

  template <typename BoolLike>
  constexpr auto is(BoolLike) noexcept
      -> camp::if_<BoolLike, camp::true_type, camp::false_type>;

  template <typename BoolLike>
  constexpr auto is_not(BoolLike) noexcept
      -> camp::if_c<!BoolLike::value, camp::true_type, camp::false_type>;

  /// metaprogramming concept for SFINAE checking of aggregating concepts
  template <typename... Args>
  struct all_of : metalib::all_of_t<Args...> {
  };

  /// metaprogramming concept for SFINAE checking of aggregating concepts
  template <typename... Args>
  struct none_of : metalib::none_of_t<Args...> {
  };

  /// metaprogramming concept for SFINAE checking of aggregating concepts
  template <typename... Args>
  struct any_of : metalib::any_of_t<Args...> {
  };

  /// SFINAE multiple type traits
  template <typename... Args>
  using enable_if = typename std::enable_if<all_of<Args...>::value, void>::type;

  template <typename T, typename... Args>
  using enable_if_t = typename std::enable_if<all_of<Args...>::value, T>::type;

  /// SFINAE concept checking
  template <template <class...> class Op, class... Args>
  struct requires_ : detail::detected<Op, detail::TL<Args...>> {
  };

  /// Matches types that satisfy `std::swappable`.
  template <typename T>
  concept Swappable = std::swappable<T>;

  /// Matches types that support `lhs < rhs`.
  template <typename T>
  concept LessThanComparable = requires(T arg) {
    { arg < arg } -> std::convertible_to<bool>;
  };

  /// Matches types that support `lhs > rhs`.
  template <typename T>
  concept GreaterThanComparable = requires(T arg) {
    { arg > arg } -> std::convertible_to<bool>;
  };

  /// Matches types that support `lhs <= rhs`.
  template <typename T>
  concept LessEqualComparable = requires(T arg) {
    { arg <= arg } -> std::convertible_to<bool>;
  };

  /// Matches types that support `lhs >= rhs`.
  template <typename T>
  concept GreaterEqualComparable = requires(T arg) {
    { arg >= arg } -> std::convertible_to<bool>;
  };

  /// Matches types that support `lhs == rhs`.
  template <typename T>
  concept EqualityComparable = requires(T arg) {
    { arg == arg } -> std::convertible_to<bool>;
  };

  /// Matches two types that can be ordered and equality-compared with each other.
  template <typename T, typename U>
  concept ComparableTo = requires(T lhs, U rhs) {
    { lhs < rhs } -> std::convertible_to<bool>;
    { rhs < lhs } -> std::convertible_to<bool>;
    { lhs <= rhs } -> std::convertible_to<bool>;
    { rhs <= lhs } -> std::convertible_to<bool>;
    { lhs > rhs } -> std::convertible_to<bool>;
    { rhs > lhs } -> std::convertible_to<bool>;
    { lhs >= rhs } -> std::convertible_to<bool>;
    { rhs >= lhs } -> std::convertible_to<bool>;
    { lhs == rhs } -> std::convertible_to<bool>;
    { rhs == lhs } -> std::convertible_to<bool>;
    { lhs != rhs } -> std::convertible_to<bool>;
    { rhs != lhs } -> std::convertible_to<bool>;
  };

  /// Matches a type that is comparable with itself.
  template <typename T>
  concept Comparable = ComparableTo<T, T>;

  /// Matches floating-point types.
  template <typename T>
  concept FloatingPoint = std::floating_point<T>;

  /// Matches integral types.
  template <typename T>
  concept Integral = std::integral<T>;

  /// Matches arithmetic types.
  template <typename T>
  concept Arithmetic = std::is_arithmetic_v<T>;

  /// Matches signed integral types.
  template <typename T>
  concept Signed = std::signed_integral<T>;

  /// Matches unsigned integral types.
  template <typename T>
  concept Unsigned = std::unsigned_integral<T>;

  // Note: std::weakly_incrementable is the closest C++ concept to Iterator, but
  // differs in two important ways.  (1) std::weakly_incrementable requires and
  // iterator be post-incrementable (arg_ref++) (2) std::weakly_incrementable
  // does not requires not Integral
  /// Matches dereferenceable, pre-incrementable non-integral iterator types.
  template <typename T>
  concept Iterator = !Integral<T> && requires(T arg, T &arg_ref) {
    *arg;
    { ++arg_ref } -> std::same_as<T &>;
  };

  /// Matches iterators that satisfy `Iterator` and support post-increment.
  template <typename T>
  concept ForwardIterator = Iterator<T> && requires(T &arg) {
    arg++;
    *arg++;
  };

  /// Matches iterators that satisfy `ForwardIterator` and support decrement.
  template <typename T>
  concept BidirectionalIterator = ForwardIterator<T> && requires(T &arg) {
    { --arg } -> std::same_as<T &>;
    { arg-- } -> std::convertible_to<T const &>;
    *arg--;
  };

  /// Matches iterators that satisfy bidirectional traversal and random access.
  template <typename T>
  concept RandomAccessIterator =
      BidirectionalIterator<T> && Comparable<T>
      && requires(T arg, T &arg_ref, diff_from<T> increment) {
           // Reference increment requirements
           { arg_ref += increment } -> std::same_as<T &>;
           { arg_ref -= increment } -> std::same_as<T &>;
           // Value increment requirements
           { arg + increment } -> std::same_as<T>;
           { increment + arg } -> std::same_as<T>;
           { arg - increment } -> std::same_as<T>;
           // random access index operator
           arg[increment];
         };

  template <typename T>
  concept HasBeginEnd = std::ranges::range<T>;

  /// Matches ranges whose iterator type satisfies `Iterator`.
  template <typename T>
  concept Range = HasBeginEnd<T> && Iterator<iterator_from<T>>;

  /// Matches ranges whose iterator type satisfies `ForwardIterator`.
  template <typename T>
  concept ForwardRange = HasBeginEnd<T> && ForwardIterator<iterator_from<T>>;

  /// Matches ranges whose iterator type satisfies `BidirectionalIterator`.
  template <typename T>
  concept BidirectionalRange =
      HasBeginEnd<T> && BidirectionalIterator<iterator_from<T>>;

  /// Matches ranges whose iterator type satisfies `RandomAccessIterator`.
  template <typename T>
  concept RandomAccessRange =
      HasBeginEnd<T> && RandomAccessIterator<iterator_from<T>>;

}  // end namespace concepts

namespace type_traits
{
  /// Boolean type trait wrapper for `camp::concepts::Iterator`.
  template <class T>
  struct is_iterator : std::bool_constant<camp::concepts::Iterator<T>> {
  };

  /// Convenience variable template for `is_iterator<T>::value`.
  template <class T>
  inline constexpr bool is_iterator_v = is_iterator<T>::value;

  /// Boolean type trait wrapper for `camp::concepts::ForwardIterator`.
  template <class T>
  struct is_forward_iterator
      : std::bool_constant<camp::concepts::ForwardIterator<T>> {
  };

  /// Convenience variable template for `is_forward_iterator<T>::value`.
  template <class T>
  inline constexpr bool is_forward_iterator_v = is_forward_iterator<T>::value;

  /// Boolean type trait wrapper for `camp::concepts::BidirectionalIterator`.
  template <class T>
  struct is_bidirectional_iterator
      : std::bool_constant<camp::concepts::BidirectionalIterator<T>> {
  };

  /// Convenience variable template for `is_bidirectional_iterator<T>::value`.
  template <class T>
  inline constexpr bool is_bidirectional_iterator_v =
      is_bidirectional_iterator<T>::value;

  /// Boolean type trait wrapper for `camp::concepts::RandomAccessIterator`.
  template <class T>
  struct is_random_access_iterator
      : std::bool_constant<camp::concepts::RandomAccessIterator<T>> {
  };

  /// Convenience variable template for `is_random_access_iterator<T>::value`.
  template <class T>
  inline constexpr bool is_random_access_iterator_v =
      is_random_access_iterator<T>::value;

  /// Boolean type trait wrapper for `camp::concepts::Range`.
  template <class T>
  struct is_range : std::bool_constant<camp::concepts::Range<T>> {
  };

  /// Convenience variable template for `is_range<T>::value`.
  template <class T>
  inline constexpr bool is_range_v = is_range<T>::value;

  /// Boolean type trait wrapper for `camp::concepts::ForwardRange`.
  template <class T>
  struct is_forward_range
      : std::bool_constant<camp::concepts::ForwardRange<T>> {
  };

  /// Convenience variable template for `is_forward_range<T>::value`.
  template <class T>
  inline constexpr bool is_forward_range_v = is_forward_range<T>::value;

  /// Boolean type trait wrapper for `camp::concepts::BidirectionalRange`.
  template <class T>
  struct is_bidirectional_range
      : std::bool_constant<camp::concepts::BidirectionalRange<T>> {
  };

  /// Convenience variable template for `is_bidirectional_range<T>::value`.
  template <class T>
  inline constexpr bool is_bidirectional_range_v =
      is_bidirectional_range<T>::value;

  /// Boolean type trait wrapper for `camp::concepts::RandomAccessRange`.
  template <class T>
  struct is_random_access_range
      : std::bool_constant<camp::concepts::RandomAccessRange<T>> {
  };

  /// Convenience variable template for `is_random_access_range<T>::value`.
  template <class T>
  inline constexpr bool is_random_access_range_v =
      is_random_access_range<T>::value;

  /// Boolean type trait wrapper for `camp::concepts::Comparable`.
  template <class T>
  struct is_comparable : std::bool_constant<camp::concepts::Comparable<T>> {
  };

  /// Convenience variable template for `is_comparable<T>::value`.
  template <class T>
  inline constexpr bool is_comparable_v = is_comparable<T>::value;

  /// Boolean type trait wrapper for `camp::concepts::Arithmetic`.
  template <class T>
  struct is_arithmetic : std::bool_constant<camp::concepts::Arithmetic<T>> {
  };

  /// Convenience variable template for `is_arithmetic<T>::value`.
  template <class T>
  inline constexpr bool is_arithmetic_v = is_arithmetic<T>::value;

  /// Boolean type trait wrapper for `camp::concepts::FloatingPoint`.
  template <class T>
  struct is_floating_point
      : std::bool_constant<camp::concepts::FloatingPoint<T>> {
  };

  /// Convenience variable template for `is_floating_point<T>::value`.
  template <class T>
  inline constexpr bool is_floating_point_v = is_floating_point<T>::value;

  /// Boolean type trait wrapper for `camp::concepts::Integral`.
  template <class T>
  struct is_integral : std::bool_constant<camp::concepts::Integral<T>> {
  };

  /// Convenience variable template for `is_integral<T>::value`.
  template <class T>
  inline constexpr bool is_integral_v = is_integral<T>::value;

  /// Boolean type trait wrapper for `camp::concepts::Signed`.
  template <class T>
  struct is_signed : std::bool_constant<camp::concepts::Signed<T>> {
  };

  /// Convenience variable template for `is_signed<T>::value`.
  template <class T>
  inline constexpr bool is_signed_v = is_signed<T>::value;

  /// Boolean type trait wrapper for `camp::concepts::Unsigned`.
  template <class T>
  struct is_unsigned : std::bool_constant<camp::concepts::Unsigned<T>> {
  };

  /// Convenience variable template for `is_unsigned<T>::value`.
  template <class T>
  inline constexpr bool is_unsigned_v = is_unsigned<T>::value;

  /// Boolean type trait wrapper for `camp::concepts::ComparableTo`.
  template <class T, class U>
  struct is_comparable_to
      : std::bool_constant<camp::concepts::ComparableTo<T, U>> {
  };

  /// Convenience variable template for `is_comparable_to<T, U>::value`.
  template <class T, class U>
  inline constexpr bool is_comparable_to_v = is_comparable_to<T, U>::value;

  /// Dereferenced value type from `begin(T)`.
  template <typename T>
  using IterableValue = decltype(*begin(camp::val<T>()));

  /// Dereferenced value type from an iterator-like type `T`.
  template <typename T>
  using IteratorValue = decltype(*camp::val<T>());

  namespace detail
  {

    /// \cond
    template <typename, template <typename...> class, typename...>
    struct IsSpecialized : camp::false_type {
    };

    template <template <typename...> class Template, typename... T>
    struct IsSpecialized<typename concepts::detail::voider<
                             decltype(camp::val<Template<T...>>())>::type,
                         Template,
                         T...> : camp::true_type {
    };

    template <template <class...> class,
              template <class...> class,
              bool,
              class...>
    struct SpecializationOf : camp::false_type {
    };

    template <template <class...> class Expected,
              template <class...> class Actual,
              class... Args>
    struct SpecializationOf<Expected, Actual, true, Args...>
        : camp::concepts::metalib::is_same<Expected<Args...>, Actual<Args...>> {
    };

    /// \endcond

  }  // end namespace detail


  /// Detects whether `Outer<Args...>` is a valid specialization.
  template <template <class...> class Outer, class... Args>
  using IsSpecialized = detail::IsSpecialized<void, Outer, Args...>;

  /// Checks whether a type is a specialization of the given class template.
  template <template <class...> class, typename T>
  struct SpecializationOf : camp::false_type {
  };

  template <template <class...> class Expected,
            template <class...> class Actual,
            class... Args>
  struct SpecializationOf<Expected, Actual<Args...>>
      : detail::SpecializationOf<Expected,
                                 Actual,
                                 IsSpecialized<Expected, Args...>::value,
                                 Args...> {
  };

}  // end namespace type_traits

namespace resources
{
  inline namespace v1
  {

    template <typename T>
    struct is_concrete_event_impl : std::false_type {
    };

    template <typename T>
    struct is_concrete_event
        : is_concrete_event_impl<typename std::remove_cvref_t<T>> {
    };

    /// Convenience variable template for `is_concrete_event<T>::value`.
    template <typename T>
    inline constexpr bool is_concrete_event_v = is_concrete_event<T>::value;

    template <typename T>
    struct is_concrete_resource_impl : std::false_type {
    };

    template <typename T>
    struct is_concrete_resource
        : is_concrete_resource_impl<typename std::remove_cvref_t<T>> {
    };

    /// Convenience variable template for `is_concrete_resource<T>::value`.
    template <typename T>
    inline constexpr bool is_concrete_resource_v =
        is_concrete_resource<T>::value;

  }  // namespace v1
}  // namespace resources

namespace concepts
{

  /// Matches concrete event types recognized by Camp's resource system.
  template <typename T>
  concept ConcreteEvent = ::camp::resources::is_concrete_event_v<T>;

  /// Matches concrete resource types recognized by Camp's resource system.
  template <typename T>
  concept ConcreteResource = ::camp::resources::is_concrete_resource_v<T>;

}  // namespace concepts

}  // namespace camp

#endif /* CAMP_CONCEPTS_HPP */
