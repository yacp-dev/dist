//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
// Copyright (c) Lawrence Livermore National Security, LLC and other
// Camp Project Developers. See top-level LICENSE and COPYRIGHT
// files for dates and other details. No copyright assignment is required
// to contribute to Camp.
//
// SPDX-License-Identifier: (BSD-3-Clause)
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

#ifndef CAMP_CONFIG_HPP
#define CAMP_CONFIG_HPP

// Define CAMP_CONFIG_OVERRIDE to change this on a per-file basis
#if !defined(CAMP_CONFIG_OVERRIDE)
/* #undef CAMP_ENABLE_OPENMP */
/* #undef CAMP_ENABLE_TARGET_OPENMP */
/* #undef CAMP_ENABLE_CUDA */
/* #undef CAMP_ENABLE_HIP */
/* #undef CAMP_ENABLE_SYCL */
/* #undef CAMP_WIN_STATIC_BUILD */
#endif

#define CAMP_VERSION_MAJOR 2026
#define CAMP_VERSION_MINOR 7
#define CAMP_VERSION_PATCH 2

#define CAMP_VERSION                                           \
  (CAMP_VERSION_MAJOR * 1000000) + (CAMP_VERSION_MINOR * 1000) \
      + (CAMP_VERSION_PATCH)

#if (defined(_WIN32) || defined(_WIN64)) && !defined(CAMP_WIN_STATIC_BUILD)
#ifdef CAMP_DLL_EXPORTS
#define CAMP_DLL_EXPORT __declspec(dllexport)
#else
#define CAMP_DLL_EXPORT __declspec(dllimport)
#endif
#else
#define CAMP_DLL_EXPORT
#endif

#if defined(CAMP_USE_PLATFORM_DEFAULT_STREAM)
#error \
    "Manually defining CAMP_USE_PLATFORM_DEFAULT_STREAM is not allowed because of the potential for ODR violations. CAMP supports a CMake configuration option that should be used instead."
#endif

#define CAMP_USE_PLATFORM_DEFAULT_STREAM 0

#endif
