#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "camp" for configuration "RelWithDebInfo"
set_property(TARGET camp APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(camp PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libcamp.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygcamp-0.dll"
  )

list(APPEND _cmake_import_check_targets camp )
list(APPEND _cmake_import_check_files_for_camp "${_IMPORT_PREFIX}/lib/libcamp.dll.a" "${_IMPORT_PREFIX}/bin/cygcamp-0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
