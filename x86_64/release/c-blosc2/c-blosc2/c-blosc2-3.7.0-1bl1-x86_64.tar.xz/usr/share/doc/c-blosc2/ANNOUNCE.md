# Announcing C-Blosc2 3.7.0
A fast, compressed, and persistent binary data store library for C.

## What is new?

We have put considerable love in speeding up compression and decompression,
specially for SIMD instructions in existing filters.  We also improved the
handling of special-value and lazy chunks and did some fixes too.

- Faster SIMD shuffle and bitshuffle, with fused SHUFFLE+BYTEDELTA enabled
  by default.
- New BloscLZ 2.6.0 improves matching on periodic data and adds decoder fast
  paths on ARM64 and AMD64. Bundled LZ4 reuses worker compression state.
- The new `blosc2_set_prefilter_full_write()` lets prefilters that write every
  output byte skip zero-initialization.
- Chunk decoding validates special-value buffer sizes and resizes worker
  scratch buffers when element widths grow.

For more info, see the release notes in:

https://github.com/Blosc/c-blosc2/blob/main/RELEASE_NOTES.md

## What is it?

Blosc2 is a high-performance data container optimized for binary data.
Blosc2 is the next generation of Blosc, an
[award-winning library](https://www.blosc.org/posts/prize-push-Blosc2)
that has been around for more than a decade.

Blosc2 expands the capabilities of Blosc by providing a higher level
container that is able to store many chunks on it (hence the super-chunk name).
It supports storing data on both memory and disk using the same API.
Also, it adds more compressors and filters.

## Download sources

The github repository is over here:

https://github.com/Blosc/c-blosc2

Blosc is distributed using the BSD license, see LICENSE.txt
for details.

## Mailing list

There is an official Blosc mailing list at:

blosc@googlegroups.com
https://groups.google.com/g/blosc


Enjoy Data!
- The Blosc Development Team
