/*********************************************************************
  Blosc - Blocked Shuffling and Compression Library

  Copyright (c) 2021  Blosc Development Team <blosc@blosc.org>
  https://blosc.org
  License: BSD 3-Clause (see LICENSE.txt)

  See LICENSE.txt for details about copyright and rights to use.
**********************************************************************/

#include "frame.h"
#include "blosc2.h"

#include <inttypes.h>
#include <limits.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>


/* If C11 is supported, use it's built-in aligned allocation. */
#if __STDC_VERSION__ >= 201112L
#include <stdalign.h>
#endif


static char* sframe_make_index_path(const char* urlpath) {
  size_t path_len = strlen(urlpath);
  size_t suffix_len = strlen("/chunks.b2frame");
  if (path_len > SIZE_MAX - suffix_len - 1) {
    BLOSC_TRACE_ERROR("Index path length overflows size limits");
    return NULL;
  }

  char* index_path = malloc(path_len + suffix_len + 1);
  if (index_path == NULL) {
    return NULL;
  }

  int written = snprintf(index_path, path_len + suffix_len + 1, "%s/chunks.b2frame", urlpath);
  if (written < 0 || (size_t)written >= path_len + suffix_len + 1) {
    BLOSC_TRACE_ERROR("Error building index path");
    free(index_path);
    return NULL;
  }

  return index_path;
}


static char* sframe_make_chunk_path(const char* urlpath, int64_t nchunk) {
  if (nchunk < 0 || (uint64_t)nchunk > UINT32_MAX) {
    BLOSC_TRACE_ERROR("Chunk index (%" PRId64 ") is out of range for sframe filenames", nchunk);
    return NULL;
  }

  size_t path_len = strlen(urlpath);
  size_t suffix_len = strlen("/.chunk");
  size_t chunk_hex_len = 8;
  if (path_len > SIZE_MAX - suffix_len - chunk_hex_len - 1) {
    BLOSC_TRACE_ERROR("Chunk path length overflows size limits");
    return NULL;
  }

  size_t total_len = path_len + suffix_len + chunk_hex_len + 1;
  char* chunk_path = malloc(total_len);
  if (chunk_path == NULL) {
    return NULL;
  }

  int written = snprintf(chunk_path, total_len, "%s/%08" PRIX32 ".chunk", urlpath, (uint32_t)nchunk);
  if (written < 0 || (size_t)written >= total_len) {
    BLOSC_TRACE_ERROR("Error building chunk path for chunk index (%" PRId64 ")", nchunk);
    free(chunk_path);
    return NULL;
  }

  return chunk_path;
}


/* Open sparse frame index chunk */
void* sframe_open_index(const char* urlpath, const char* mode, const blosc2_io *io) {
  void* fp = NULL;
  char* index_path = sframe_make_index_path(urlpath);
  if (index_path) {
    blosc2_io_cb *io_cb = blosc2_get_io_cb(io->id);
    if (io_cb == NULL) {
      BLOSC_TRACE_ERROR("Error getting the input/output API");
      free(index_path);
      return NULL;
    }
    fp = io_cb->open(index_path, mode, io->params);
    if (fp == NULL)
      BLOSC_TRACE_ERROR("Error creating index path in: %s", index_path);
    free(index_path);
  }
  return fp;
}

/* Open directory/nchunk.chunk with 8 zeros of padding */
void* sframe_open_chunk(const char* urlpath, int64_t nchunk, const char* mode, const blosc2_io *io) {
  void* fp = NULL;
  char* chunk_path = sframe_make_chunk_path(urlpath, nchunk);
  if (chunk_path) {
    blosc2_io_cb *io_cb = blosc2_get_io_cb(io->id);
    if (io_cb == NULL) {
      BLOSC_TRACE_ERROR("Error getting the input/output API");
      free(chunk_path);
      return NULL;
    }
    fp = io_cb->open(chunk_path, mode, io->params);
    if (fp == NULL)
      BLOSC_TRACE_ERROR("Error opening chunk path in: %s", chunk_path);
    free(chunk_path);
  }
  return fp;
}

/* Append an existing chunk into a sparse frame. */
void* sframe_create_chunk(blosc2_frame_s* frame, uint8_t* chunk, int64_t nchunk, int64_t cbytes) {
  void* fpc = sframe_open_chunk(frame->urlpath, nchunk, "wb", frame->schunk->storage->io);
  if (fpc == NULL) {
    BLOSC_TRACE_ERROR("Cannot open the chunkfile.");
    return NULL;
  }
  blosc2_io_cb *io_cb = blosc2_get_io_cb(frame->schunk->storage->io->id);
  if (io_cb == NULL) {
    BLOSC_TRACE_ERROR("Error getting the input/output API");
    return NULL;
  }
  int64_t io_pos = 0;
  int64_t wbytes = io_cb->write(chunk, 1, cbytes, io_pos, fpc);
  io_cb->close(fpc);
  if (wbytes != cbytes) {
    BLOSC_TRACE_ERROR("Cannot write the full chunk.");
    return NULL;
  }

  return frame;
}

/* Delete or evict a chunk from a sparse frame. */
int sframe_delete_chunk(const char *urlpath, int64_t nchunk, const blosc2_io *io) {
  char* chunk_path = sframe_make_chunk_path(urlpath, nchunk);
  if (chunk_path == NULL) {
    return BLOSC2_ERROR_FILE_REMOVE;
  }

  uint8_t io_id = (io != NULL) ? io->id : BLOSC2_IO_FILESYSTEM;

  if (io_id == BLOSC2_IO_FILESYSTEM || io_id == BLOSC2_IO_FILESYSTEM_MMAP) {
    int rc = remove(chunk_path);
    if (rc != 0) {
      if (errno == ENOENT) {
        /* Chunk file does not exist on disk; already evicted or absent */
        free(chunk_path);
        return BLOSC2_ERROR_SUCCESS;
      }
      BLOSC_TRACE_ERROR("Cannot remove chunk file %s (error: %s)", chunk_path, strerror(errno));
      free(chunk_path);
      return BLOSC2_ERROR_FILE_REMOVE;
    }
    free(chunk_path);
    return BLOSC2_ERROR_SUCCESS;
  }

  /* Non-standard / custom I/O backend: use its callbacks exclusively. */
  blosc2_io_cb *io_cb = blosc2_get_io_cb(io_id);
  if (io_cb == NULL) {
    BLOSC_TRACE_ERROR("Error getting the input/output API");
    free(chunk_path);
    return BLOSC2_ERROR_FILE_REMOVE;
  }

  void *params = (io != NULL) ? io->params : NULL;
  void *fp = io_cb->open(chunk_path, "wb", params);
  if (fp == NULL) {
    /* If open failed because chunk file does not exist, consider it already evicted. */
    if (errno == ENOENT) {
      free(chunk_path);
      return BLOSC2_ERROR_SUCCESS;
    }
    BLOSC_TRACE_ERROR("Cannot open chunk %" PRId64 " for eviction via custom I/O backend (id %d)",
                      nchunk, (int)io_id);
    free(chunk_path);
    return BLOSC2_ERROR_FILE_OPEN;
  }

  if (io_cb->truncate != NULL) {
    int rc_trunc = io_cb->truncate(fp, 0);
    if (rc_trunc != 0) {
      BLOSC_TRACE_ERROR("Cannot truncate chunk %" PRId64 " in custom I/O backend (id %d, error %d)",
                        nchunk, (int)io_id, rc_trunc);
      io_cb->close(fp);
      free(chunk_path);
      return BLOSC2_ERROR_FILE_TRUNCATE;
    }
  }

  int rc_close = io_cb->close(fp);
  if (rc_close != 0) {
    BLOSC_TRACE_ERROR("Cannot close chunk %" PRId64 " after eviction in custom I/O backend (id %d, error %d)",
                      nchunk, (int)io_id, rc_close);
    free(chunk_path);
    return BLOSC2_ERROR_FILE_REMOVE;
  }

  free(chunk_path);
  return BLOSC2_ERROR_SUCCESS;
}

/* Get chunk from sparse frame. */
int32_t sframe_get_chunk(blosc2_frame_s* frame, int64_t nchunk, uint8_t** chunk, bool* needs_free){
  void *fpc = sframe_open_chunk(frame->urlpath, nchunk, "rb", frame->schunk->storage->io);
  if(fpc == NULL){
    BLOSC_TRACE_ERROR("Cannot open the chunkfile.");
    return BLOSC2_ERROR_FILE_OPEN;
  }

  blosc2_io_cb *io_cb = blosc2_get_io_cb(frame->schunk->storage->io->id);
  if (io_cb == NULL) {
    BLOSC_TRACE_ERROR("Error getting the input/output API");
    return BLOSC2_ERROR_PLUGIN_IO;
  }

  int64_t chunk_cbytes = io_cb->size(fpc);
  if (chunk_cbytes < BLOSC_MIN_HEADER_LENGTH) {
    // A valid chunk file always starts with a Blosc header; a smaller (e.g. empty)
    // file means the on-disk state changed under us (another handle replaced this
    // chunk) or the file is corrupted.  Fail the same way as frame_get_lazychunk().
    BLOSC_TRACE_ERROR("Chunkfile is too small to contain a valid chunk.");
    io_cb->close(fpc);
    return BLOSC2_ERROR_FILE_READ;
  }

  if (io_cb->is_allocation_necessary) {
    *chunk = malloc((size_t)chunk_cbytes);
    *needs_free = true;
  }
  else {
    *needs_free = false;
  }

  int64_t io_pos = 0;
  int64_t rbytes = io_cb->read((void**)chunk, 1, chunk_cbytes, io_pos, fpc);
  io_cb->close(fpc);
  if (rbytes != chunk_cbytes) {
    BLOSC_TRACE_ERROR("Cannot read the chunk out of the chunkfile.");
    return BLOSC2_ERROR_FILE_READ;
  }

  return (int32_t)chunk_cbytes;
}
