#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "NIFTI::znz" for configuration "RelWithDebInfo"
set_property(TARGET NIFTI::znz APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(NIFTI::znz PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libznz.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygznz-3.dll"
  )

list(APPEND _cmake_import_check_targets NIFTI::znz )
list(APPEND _cmake_import_check_files_for_NIFTI::znz "${_IMPORT_PREFIX}/lib/libznz.dll.a" "${_IMPORT_PREFIX}/bin/cygznz-3.dll" )

# Import target "NIFTI::niftiio" for configuration "RelWithDebInfo"
set_property(TARGET NIFTI::niftiio APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(NIFTI::niftiio PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libniftiio.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygniftiio-2.dll"
  )

list(APPEND _cmake_import_check_targets NIFTI::niftiio )
list(APPEND _cmake_import_check_files_for_NIFTI::niftiio "${_IMPORT_PREFIX}/lib/libniftiio.dll.a" "${_IMPORT_PREFIX}/bin/cygniftiio-2.dll" )

# Import target "NIFTI::nifti1_tool" for configuration "RelWithDebInfo"
set_property(TARGET NIFTI::nifti1_tool APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(NIFTI::nifti1_tool PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/nifti1_tool.exe"
  )

list(APPEND _cmake_import_check_targets NIFTI::nifti1_tool )
list(APPEND _cmake_import_check_files_for_NIFTI::nifti1_tool "${_IMPORT_PREFIX}/bin/nifti1_tool.exe" )

# Import target "NIFTI::nifticdf" for configuration "RelWithDebInfo"
set_property(TARGET NIFTI::nifticdf APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(NIFTI::nifticdf PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libnifticdf.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygnifticdf-2.dll"
  )

list(APPEND _cmake_import_check_targets NIFTI::nifticdf )
list(APPEND _cmake_import_check_files_for_NIFTI::nifticdf "${_IMPORT_PREFIX}/lib/libnifticdf.dll.a" "${_IMPORT_PREFIX}/bin/cygnifticdf-2.dll" )

# Import target "NIFTI::nifti_stats" for configuration "RelWithDebInfo"
set_property(TARGET NIFTI::nifti_stats APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(NIFTI::nifti_stats PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/nifti_stats.exe"
  )

list(APPEND _cmake_import_check_targets NIFTI::nifti_stats )
list(APPEND _cmake_import_check_files_for_NIFTI::nifti_stats "${_IMPORT_PREFIX}/bin/nifti_stats.exe" )

# Import target "NIFTI::nifti2" for configuration "RelWithDebInfo"
set_property(TARGET NIFTI::nifti2 APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(NIFTI::nifti2 PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libnifti2.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygnifti2-2.dll"
  )

list(APPEND _cmake_import_check_targets NIFTI::nifti2 )
list(APPEND _cmake_import_check_files_for_NIFTI::nifti2 "${_IMPORT_PREFIX}/lib/libnifti2.dll.a" "${_IMPORT_PREFIX}/bin/cygnifti2-2.dll" )

# Import target "NIFTI::nifti_tool" for configuration "RelWithDebInfo"
set_property(TARGET NIFTI::nifti_tool APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(NIFTI::nifti_tool PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/nifti_tool.exe"
  )

list(APPEND _cmake_import_check_targets NIFTI::nifti_tool )
list(APPEND _cmake_import_check_files_for_NIFTI::nifti_tool "${_IMPORT_PREFIX}/bin/nifti_tool.exe" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
