

if(NOT TARGET "toml-f::toml-f")
  include("${CMAKE_CURRENT_LIST_DIR}/toml-f-targets.cmake")
endif()
