set(CMAKE_IMPORT_FILE_VERSION 1)

set(
  TOMLF_INCLUDEDIRS
  "/usr/include"
  "/usr/include/toml-f/modules"
)
find_library(
  TOMLF_LIBRARIES
  "toml-f"
  PATHS "/usr/lib"
  NO_DEFAULT_PATH
)

add_library(toml-f::toml-f-lib INTERFACE IMPORTED)
add_library(toml-f::toml-f ALIAS toml-f::toml-f-lib)
target_link_libraries(toml-f::toml-f-lib INTERFACE ${TOMLF_LIBRARIES})
target_include_directories(toml-f::toml-f-lib INTERFACE ${TOMLF_INCLUDEDIRS})
