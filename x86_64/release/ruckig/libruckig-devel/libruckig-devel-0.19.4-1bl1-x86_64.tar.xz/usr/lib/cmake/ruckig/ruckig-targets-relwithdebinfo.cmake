#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "ruckig::ruckig" for configuration "RelWithDebInfo"
set_property(TARGET ruckig::ruckig APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(ruckig::ruckig PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libruckig.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygruckig-0.dll"
  )

list(APPEND _cmake_import_check_targets ruckig::ruckig )
list(APPEND _cmake_import_check_files_for_ruckig::ruckig "${_IMPORT_PREFIX}/lib/libruckig.dll.a" "${_IMPORT_PREFIX}/bin/cygruckig-0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
