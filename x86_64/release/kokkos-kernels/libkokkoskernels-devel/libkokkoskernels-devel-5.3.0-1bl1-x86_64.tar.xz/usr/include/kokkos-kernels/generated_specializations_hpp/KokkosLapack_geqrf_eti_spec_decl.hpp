// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// SPDX-FileCopyrightText: Copyright Contributors to the Kokkos project

#ifndef KOKKOSLAPACK_GEQRF_ETI_SPEC_DECL_HPP_
#define KOKKOSLAPACK_GEQRF_ETI_SPEC_DECL_HPP_
namespace KokkosLapack {
namespace Impl {
KOKKOSLAPACK_GEQRF_ETI_SPEC_DECL(double,Kokkos::LayoutLeft,Kokkos::Serial,Kokkos::HostSpace)
  } // IMPL
} // namespace KokkosLapack
#endif
