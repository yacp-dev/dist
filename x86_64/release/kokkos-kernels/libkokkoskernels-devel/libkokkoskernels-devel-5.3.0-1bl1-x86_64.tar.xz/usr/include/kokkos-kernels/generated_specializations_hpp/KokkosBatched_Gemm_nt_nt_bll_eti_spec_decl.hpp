// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// SPDX-FileCopyrightText: Copyright Contributors to the Kokkos project

#ifndef KOKKOSBATCHED_GEMM_NT_NT_BLL_ETI_SPEC_DECL_HPP_
#define KOKKOSBATCHED_GEMM_NT_NT_BLL_ETI_SPEC_DECL_HPP_
namespace KokkosBatched {
namespace Impl {
using KokkosBlas::Trans;

  } //IMPL 
} //Kokkos
#endif
