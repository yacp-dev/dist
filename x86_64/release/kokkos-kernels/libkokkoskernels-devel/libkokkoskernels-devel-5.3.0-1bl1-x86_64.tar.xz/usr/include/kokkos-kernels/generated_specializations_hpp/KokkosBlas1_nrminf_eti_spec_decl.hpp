// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// SPDX-FileCopyrightText: Copyright Contributors to the Kokkos project

#ifndef KOKKOSBLAS1_NRMINF_ETI_SPEC_DECL_HPP_
#define KOKKOSBLAS1_NRMINF_ETI_SPEC_DECL_HPP_
namespace KokkosBlas {
namespace Impl {
KOKKOSBLAS1_NRMINF_ETI_SPEC_DECL(double,Kokkos::LayoutLeft,Kokkos::Serial)
  } //IMPL 
} //Kokkos
#endif
