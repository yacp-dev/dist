// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// SPDX-FileCopyrightText: Copyright Contributors to the Kokkos project

#ifndef KOKKOSBLAS3_TRMM_ETI_SPEC_AVAIL_HPP_
#define KOKKOSBLAS3_TRMM_ETI_SPEC_AVAIL_HPP_
namespace KokkosBlas {
namespace Impl {

KOKKOSBLAS3_TRMM_ETI_SPEC_AVAIL(double,Kokkos::LayoutLeft,Kokkos::Serial)

} // Impl
} // KokkosBlas
#endif // KOKKOSBLAS3_TRMM_ETI_SPEC_AVAIL_HPP_
