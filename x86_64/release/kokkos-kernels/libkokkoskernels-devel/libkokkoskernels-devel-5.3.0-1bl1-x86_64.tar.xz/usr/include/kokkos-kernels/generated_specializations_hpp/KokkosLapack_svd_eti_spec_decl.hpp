// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// SPDX-FileCopyrightText: Copyright Contributors to the Kokkos project

#ifndef KOKKOSLAPACK_SVD_ETI_SPEC_DECL_HPP_
#define KOKKOSLAPACK_SVD_ETI_SPEC_DECL_HPP_
namespace KokkosLapack {
namespace Impl {
KOKKOSLAPACK_SVD_ETI_SPEC_DECL(double,Kokkos::LayoutLeft,Kokkos::Serial,Kokkos::HostSpace)
  } //IMPL 
} //Kokkos
#endif
