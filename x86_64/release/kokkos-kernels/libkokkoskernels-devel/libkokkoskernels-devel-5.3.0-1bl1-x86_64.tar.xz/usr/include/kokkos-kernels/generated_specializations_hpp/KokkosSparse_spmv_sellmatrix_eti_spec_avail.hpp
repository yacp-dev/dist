// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// SPDX-FileCopyrightText: Copyright Contributors to the Kokkos project

#ifndef KOKKOSSPARSE_SPMV_SELLMATRIX_ETI_SPEC_AVAIL_HPP_
#define KOKKOSSPARSE_SPMV_SELLMATRIX_ETI_SPEC_AVAIL_HPP_
namespace KokkosSparse {
namespace Impl {
KOKKOSSPARSE_SPMV_SELLMATRIX_ETI_SPEC_AVAIL(double,int,int,Kokkos::LayoutLeft,Kokkos::Serial,Kokkos::HostSpace)
}  // Impl 
}  // KokkosSparse
#endif  // KOKKOSSPARSE_SPMV_SELLMATRIX_ETI_SPEC_AVAIL_HPP_
