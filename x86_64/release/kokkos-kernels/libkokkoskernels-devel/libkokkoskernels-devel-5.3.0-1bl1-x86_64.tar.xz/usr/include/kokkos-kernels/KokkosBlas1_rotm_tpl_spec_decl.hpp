// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// SPDX-FileCopyrightText: Copyright Contributors to the Kokkos project

#ifndef KOKKOSBLAS1_ROTM_TPL_SPEC_DECL_HPP_
#define KOKKOSBLAS1_ROTM_TPL_SPEC_DECL_HPP_

namespace KokkosBlas {
namespace Impl {

namespace {
template <class Scalar>
inline void rotm_print_specialization() {
#ifdef KOKKOSKERNELS_ENABLE_CHECK_SPECIALIZATION
  printf("KokkosBlas1::rotm<> TPL Blas specialization for < %s >\n", typeid(Scalar).name());
#endif
}
}  // namespace
}  // namespace Impl
}  // namespace KokkosBlas

// Generic Host side BLAS (could be MKL or whatever)
#if defined(KOKKOSKERNELS_ENABLE_TPL_BLAS)
#include "KokkosBlas_Host_tpl.hpp"

namespace KokkosBlas {
namespace Impl {

#define KOKKOSBLAS1_ROTM_TPL_SPEC_DECL_BLAS(SCALAR, LAYOUT)                                                       \
  template <typename ExecSpace, bool ETI_SPEC_AVAIL>                                                              \
    requires(std::is_same_v<typename ExecSpace::memory_space, Kokkos::HostSpace>)                                 \
  struct Rotm<ExecSpace, Kokkos::View<SCALAR*, LAYOUT, ExecSpace, Kokkos::MemoryTraits<Kokkos::Unmanaged>>,       \
              Kokkos::View<const SCALAR[5], LAYOUT, ExecSpace, Kokkos::MemoryTraits<Kokkos::Unmanaged>>, true,    \
              ETI_SPEC_AVAIL> {                                                                                   \
    using VectorView = Kokkos::View<SCALAR*, LAYOUT, ExecSpace, Kokkos::MemoryTraits<Kokkos::Unmanaged>>;         \
    using ParamView  = Kokkos::View<const SCALAR[5], LAYOUT, ExecSpace, Kokkos::MemoryTraits<Kokkos::Unmanaged>>; \
    static void rotm(ExecSpace const& /* space */, VectorView& X, VectorView& Y, ParamView& param) {              \
      Kokkos::Profiling::pushRegion("KokkosBlas::rotm[TPL_BLAS,SCALAR]");                                         \
      HostBlas<SCALAR>::rotm(X.extent(0), X.data(), 1, Y.data(), 1, param.data());                                \
      Kokkos::Profiling::popRegion();                                                                             \
    }                                                                                                             \
  };

KOKKOSBLAS1_ROTM_TPL_SPEC_DECL_BLAS(double, Kokkos::LayoutLeft)
KOKKOSBLAS1_ROTM_TPL_SPEC_DECL_BLAS(double, Kokkos::LayoutRight)
KOKKOSBLAS1_ROTM_TPL_SPEC_DECL_BLAS(float, Kokkos::LayoutLeft)
KOKKOSBLAS1_ROTM_TPL_SPEC_DECL_BLAS(float, Kokkos::LayoutRight)

}  // namespace Impl
}  // namespace KokkosBlas

#endif  // KOKKOSKERNELS_ENABLE_TPL_BLAS

// cuBLAS
#ifdef KOKKOSKERNELS_ENABLE_TPL_CUBLAS
#include <KokkosBlas_tpl_spec.hpp>

namespace KokkosBlas {
namespace Impl {

#define KOKKOSBLAS1_DROTM_TPL_SPEC_DECL_CUBLAS(LAYOUT)                                                               \
  template <bool ETI_SPEC_AVAIL>                                                                                     \
  struct Rotm<Kokkos::Cuda, Kokkos::View<double*, LAYOUT, Kokkos::Cuda, Kokkos::MemoryTraits<Kokkos::Unmanaged>>,    \
              Kokkos::View<const double[5], LAYOUT, Kokkos::Cuda, Kokkos::MemoryTraits<Kokkos::Unmanaged>>, true,    \
              ETI_SPEC_AVAIL> {                                                                                      \
    using VectorView = Kokkos::View<double*, LAYOUT, Kokkos::Cuda, Kokkos::MemoryTraits<Kokkos::Unmanaged>>;         \
    using ParamView  = Kokkos::View<const double[5], LAYOUT, Kokkos::Cuda, Kokkos::MemoryTraits<Kokkos::Unmanaged>>; \
                                                                                                                     \
    static void rotm(Kokkos::Cuda const& space, VectorView const& X, VectorView const& Y, ParamView const& param) {  \
      Kokkos::Profiling::pushRegion("KokkosBlas::rotm[TPL_CUBLAS,double]");                                          \
      rotm_print_specialization<double>();                                                                           \
      KokkosBlas::Impl::CudaBlasSingleton& s = KokkosBlas::Impl::CudaBlasSingleton::singleton();                     \
      KOKKOSBLAS_IMPL_CUBLAS_SAFE_CALL(cublasSetStream(s.handle, space.cuda_stream()));                              \
      cublasPointerMode_t pointer_mode;                                                                              \
      KOKKOSBLAS_IMPL_CUBLAS_SAFE_CALL(cublasGetPointerMode(s.handle, &pointer_mode));                               \
      KOKKOSBLAS_IMPL_CUBLAS_SAFE_CALL(cublasSetPointerMode(s.handle, CUBLAS_POINTER_MODE_DEVICE));                  \
      KOKKOSBLAS_IMPL_CUBLAS_SAFE_CALL(cublasDrotm(s.handle, X.extent(0), X.data(), 1, Y.data(), 1, param.data()));  \
      KOKKOSBLAS_IMPL_CUBLAS_SAFE_CALL(cublasSetPointerMode(s.handle, pointer_mode));                                \
      Kokkos::Profiling::popRegion();                                                                                \
    }                                                                                                                \
  };

KOKKOSBLAS1_DROTM_TPL_SPEC_DECL_CUBLAS(Kokkos::LayoutLeft)
KOKKOSBLAS1_DROTM_TPL_SPEC_DECL_CUBLAS(Kokkos::LayoutRight)

#define KOKKOSBLAS1_SROTM_TPL_SPEC_DECL_CUBLAS(LAYOUT)                                                              \
  template <bool ETI_SPEC_AVAIL>                                                                                    \
  struct Rotm<Kokkos::Cuda, Kokkos::View<float*, LAYOUT, Kokkos::Cuda, Kokkos::MemoryTraits<Kokkos::Unmanaged>>,    \
              Kokkos::View<const float[5], LAYOUT, Kokkos::Cuda, Kokkos::MemoryTraits<Kokkos::Unmanaged>>, true,    \
              ETI_SPEC_AVAIL> {                                                                                     \
    using VectorView = Kokkos::View<float*, LAYOUT, Kokkos::Cuda, Kokkos::MemoryTraits<Kokkos::Unmanaged>>;         \
    using ParamView  = Kokkos::View<const float[5], LAYOUT, Kokkos::Cuda, Kokkos::MemoryTraits<Kokkos::Unmanaged>>; \
                                                                                                                    \
    static void rotm(Kokkos::Cuda const& space, VectorView const& X, VectorView const& Y, ParamView const& param) { \
      Kokkos::Profiling::pushRegion("KokkosBlas::rotm[TPL_CUBLAS,float]");                                          \
      rotm_print_specialization<float>();                                                                           \
      KokkosBlas::Impl::CudaBlasSingleton& s = KokkosBlas::Impl::CudaBlasSingleton::singleton();                    \
      KOKKOSBLAS_IMPL_CUBLAS_SAFE_CALL(cublasSetStream(s.handle, space.cuda_stream()));                             \
      cublasPointerMode_t pointer_mode;                                                                             \
      KOKKOSBLAS_IMPL_CUBLAS_SAFE_CALL(cublasGetPointerMode(s.handle, &pointer_mode));                              \
      KOKKOSBLAS_IMPL_CUBLAS_SAFE_CALL(cublasSetPointerMode(s.handle, CUBLAS_POINTER_MODE_DEVICE));                 \
      KOKKOSBLAS_IMPL_CUBLAS_SAFE_CALL(cublasSrotm(s.handle, X.extent(0), X.data(), 1, Y.data(), 1, param.data())); \
      KOKKOSBLAS_IMPL_CUBLAS_SAFE_CALL(cublasSetPointerMode(s.handle, pointer_mode));                               \
      Kokkos::Profiling::popRegion();                                                                               \
    }                                                                                                               \
  };

KOKKOSBLAS1_SROTM_TPL_SPEC_DECL_CUBLAS(Kokkos::LayoutLeft)
KOKKOSBLAS1_SROTM_TPL_SPEC_DECL_CUBLAS(Kokkos::LayoutRight)

}  // namespace Impl
}  // namespace KokkosBlas

#endif

// rocBLAS
#ifdef KOKKOSKERNELS_ENABLE_TPL_ROCBLAS
#include <KokkosBlas_tpl_spec.hpp>

namespace KokkosBlas {
namespace Impl {

#define KOKKOSBLAS1_DROTM_TPL_SPEC_DECL_ROCBLAS(LAYOUT)                                                             \
  template <bool ETI_SPEC_AVAIL>                                                                                    \
  struct Rotm<Kokkos::HIP, Kokkos::View<double*, LAYOUT, Kokkos::HIP, Kokkos::MemoryTraits<Kokkos::Unmanaged>>,     \
              Kokkos::View<const double[5], LAYOUT, Kokkos::HIP, Kokkos::MemoryTraits<Kokkos::Unmanaged>>, true,    \
              ETI_SPEC_AVAIL> {                                                                                     \
    using VectorView = Kokkos::View<double*, LAYOUT, Kokkos::HIP, Kokkos::MemoryTraits<Kokkos::Unmanaged>>;         \
    using PView      = Kokkos::View<const double[5], LAYOUT, Kokkos::HIP, Kokkos::MemoryTraits<Kokkos::Unmanaged>>; \
                                                                                                                    \
    static void rotm(Kokkos::HIP const& space, VectorView const& X, VectorView const& Y, PView const& param) {      \
      Kokkos::Profiling::pushRegion("KokkosBlas::rotm[TPL_ROCBLAS,double]");                                        \
      rotm_print_specialization<double>();                                                                          \
      KokkosBlas::Impl::RocBlasSingleton& s = KokkosBlas::Impl::RocBlasSingleton::singleton();                      \
      KOKKOSBLAS_IMPL_ROCBLAS_SAFE_CALL(rocblas_set_stream(s.handle, space.hip_stream()));                          \
      rocblas_pointer_mode pointer_mode;                                                                            \
      KOKKOSBLAS_IMPL_ROCBLAS_SAFE_CALL(rocblas_get_pointer_mode(s.handle, &pointer_mode));                         \
      KOKKOSBLAS_IMPL_ROCBLAS_SAFE_CALL(rocblas_set_pointer_mode(s.handle, rocblas_pointer_mode_device));           \
      KOKKOSBLAS_IMPL_ROCBLAS_SAFE_CALL(                                                                            \
          rocblas_drotm(s.handle, static_cast<int>(X.extent(0)), X.data(), 1, Y.data(), 1, param.data()));          \
      KOKKOSBLAS_IMPL_ROCBLAS_SAFE_CALL(rocblas_set_pointer_mode(s.handle, pointer_mode));                          \
      Kokkos::Profiling::popRegion();                                                                               \
    }                                                                                                               \
  };

KOKKOSBLAS1_DROTM_TPL_SPEC_DECL_ROCBLAS(Kokkos::LayoutLeft)
KOKKOSBLAS1_DROTM_TPL_SPEC_DECL_ROCBLAS(Kokkos::LayoutRight)

#define KOKKOSBLAS1_SROTM_TPL_SPEC_DECL_ROCBLAS(LAYOUT)                                                            \
  template <bool ETI_SPEC_AVAIL>                                                                                   \
  struct Rotm<Kokkos::HIP, Kokkos::View<float*, LAYOUT, Kokkos::HIP, Kokkos::MemoryTraits<Kokkos::Unmanaged>>,     \
              Kokkos::View<const float[5], LAYOUT, Kokkos::HIP, Kokkos::MemoryTraits<Kokkos::Unmanaged>>, true,    \
              ETI_SPEC_AVAIL> {                                                                                    \
    using VectorView = Kokkos::View<float*, LAYOUT, Kokkos::HIP, Kokkos::MemoryTraits<Kokkos::Unmanaged>>;         \
    using PView      = Kokkos::View<const float[5], LAYOUT, Kokkos::HIP, Kokkos::MemoryTraits<Kokkos::Unmanaged>>; \
                                                                                                                   \
    static void rotm(Kokkos::HIP const& space, VectorView const& X, VectorView const& Y, PView const& param) {     \
      Kokkos::Profiling::pushRegion("KokkosBlas::rotm[TPL_ROCBLAS,float]");                                        \
      rotm_print_specialization<float>();                                                                          \
      KokkosBlas::Impl::RocBlasSingleton& s = KokkosBlas::Impl::RocBlasSingleton::singleton();                     \
      KOKKOSBLAS_IMPL_ROCBLAS_SAFE_CALL(rocblas_set_stream(s.handle, space.hip_stream()));                         \
      rocblas_pointer_mode pointer_mode;                                                                           \
      KOKKOSBLAS_IMPL_ROCBLAS_SAFE_CALL(rocblas_get_pointer_mode(s.handle, &pointer_mode));                        \
      KOKKOSBLAS_IMPL_ROCBLAS_SAFE_CALL(rocblas_set_pointer_mode(s.handle, rocblas_pointer_mode_device));          \
      KOKKOSBLAS_IMPL_ROCBLAS_SAFE_CALL(                                                                           \
          rocblas_srotm(s.handle, static_cast<int>(X.extent(0)), X.data(), 1, Y.data(), 1, param.data()));         \
      KOKKOSBLAS_IMPL_ROCBLAS_SAFE_CALL(rocblas_set_pointer_mode(s.handle, pointer_mode));                         \
      Kokkos::Profiling::popRegion();                                                                              \
    }                                                                                                              \
  };

KOKKOSBLAS1_SROTM_TPL_SPEC_DECL_ROCBLAS(Kokkos::LayoutLeft)
KOKKOSBLAS1_SROTM_TPL_SPEC_DECL_ROCBLAS(Kokkos::LayoutRight)

}  // namespace Impl
}  // namespace KokkosBlas

#endif

#endif
