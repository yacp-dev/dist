// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// SPDX-FileCopyrightText: Copyright Contributors to the Kokkos project
#ifndef KOKKOSBLAS1_SWAP_ETI_SPEC_AVAIL_HPP_
#define KOKKOSBLAS1_SWAP_ETI_SPEC_AVAIL_HPP_

namespace KokkosBlas {
namespace Impl {
KOKKOSBLAS1_SWAP_ETI_SPEC_AVAIL(double,Kokkos::LayoutLeft,Kokkos::Serial)
  } //IMPL 
} //Kokkos
#endif
