// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// SPDX-FileCopyrightText: Copyright Contributors to the Kokkos project

#ifndef KOKKOSBLAS3_GEMM_ETI_SPEC_AVAIL_HPP_
#define KOKKOSBLAS3_GEMM_ETI_SPEC_AVAIL_HPP_
namespace KokkosBlas {
namespace Impl {
KOKKOSBLAS3_GEMM_ETI_SPEC_AVAIL(double,Kokkos::LayoutLeft,Kokkos::Serial)
  } //IMPL 
} //Kokkos
#endif
