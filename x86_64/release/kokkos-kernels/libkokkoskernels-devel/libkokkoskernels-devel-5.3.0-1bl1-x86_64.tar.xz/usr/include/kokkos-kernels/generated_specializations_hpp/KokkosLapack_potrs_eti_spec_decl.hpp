// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// SPDX-FileCopyrightText: Copyright Contributors to the Kokkos project

#ifndef KOKKOSLAPACK_POTRS_ETI_SPEC_DECL_HPP_
#define KOKKOSLAPACK_POTRS_ETI_SPEC_DECL_HPP_
namespace KokkosLapack {
namespace Impl {
KOKKOSLAPACK_POTRS_ETI_SPEC_DECL(double,Kokkos::LayoutLeft,Kokkos::Serial,Kokkos::HostSpace)
} // namespace Impl
} // namespace KokkosLapack
#endif
