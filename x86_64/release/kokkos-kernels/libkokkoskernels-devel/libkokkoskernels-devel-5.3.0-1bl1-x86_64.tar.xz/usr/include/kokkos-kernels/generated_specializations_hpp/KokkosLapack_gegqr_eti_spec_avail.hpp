// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// SPDX-FileCopyrightText: Copyright Contributors to the Kokkos project

#ifndef KOKKOSLAPACK_GEGQR_ETI_SPEC_AVAIL_HPP_
#define KOKKOSLAPACK_GEGQR_ETI_SPEC_AVAIL_HPP_
namespace KokkosLapack {
namespace Impl {
KOKKOSLAPACK_GEGQR_ETI_SPEC_AVAIL(double,Kokkos::LayoutLeft,Kokkos::Serial,Kokkos::HostSpace)
  }  // namespace Impl
}  // namespace KokkosLapack
#endif
