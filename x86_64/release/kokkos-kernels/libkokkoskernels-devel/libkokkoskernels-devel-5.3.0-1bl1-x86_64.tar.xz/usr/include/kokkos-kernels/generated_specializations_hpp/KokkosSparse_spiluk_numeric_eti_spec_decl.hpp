// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// SPDX-FileCopyrightText: Copyright Contributors to the Kokkos project

#ifndef KOKKOSSPARSE_SPILUK_NUMERIC_ETI_SPEC_DECL_HPP_
#define KOKKOSSPARSE_SPILUK_NUMERIC_ETI_SPEC_DECL_HPP_
namespace KokkosSparse {
namespace Impl {

KOKKOSSPARSE_SPILUK_NUMERIC_ETI_SPEC_DECL(double,int,int,Kokkos::LayoutLeft,Kokkos::Serial,Kokkos::HostSpace)

} // Impl
} // KokkosSparse
#endif // KOKKOSSPARSE_SPILUK_NUMERIC_ETI_SPEC_DECL_HPP_
