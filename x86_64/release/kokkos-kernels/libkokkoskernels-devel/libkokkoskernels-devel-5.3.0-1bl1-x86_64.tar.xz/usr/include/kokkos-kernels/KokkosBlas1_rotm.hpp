// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// SPDX-FileCopyrightText: Copyright Contributors to the Kokkos project

#ifndef KOKKOSBLAS1_ROTM_HPP_
#define KOKKOSBLAS1_ROTM_HPP_

#include <Kokkos_Core.hpp>
#include <KokkosBlas1_rotm_spec.hpp>
#include <KokkosKernels_helpers.hpp>

namespace KokkosBlas {

/// \brief Applies modified Givens rotation coefficients to vectors x and y.
///
/// \tparam execution_space the execution space where the kernel will be
///         executed, it can be used to specify a stream too.
/// \tparam VectorView a rank1 view type that hold non const data
/// \tparam ParamView a rank1 view of static extent [5] type that
///         holds const data
///
/// \param space [in] execution space used for parallel loops in this kernel
/// \param X [in/out] First vector to be rotated with param coefficients
/// \param Y [in/out] Second vector to be rotated with param coefficients
/// \param param [in] rotation parameters produced by rotmg
///
template <class execution_space, class VectorView, class ParamView>
void rotm(execution_space const& space, VectorView const& X, VectorView const& Y, ParamView const& param) {
  static_assert(Kokkos::is_execution_space<execution_space>::value,
                "rotm: execution_space template parameter is not a Kokkos "
                "execution space.");
  static_assert(VectorView::rank == 1, "rotm: VectorView template parameter needs to be a rank 1 view");
  static_assert(ParamView::rank == 1, "rotm: ParamView template parameter needs to be a rank 1 view");
  static_assert(Kokkos::SpaceAccessibility<execution_space, typename VectorView::memory_space>::accessible,
                "rotm: VectorView template parameter memory space needs to be accessible "
                "from execution_space template parameter");
  static_assert(Kokkos::SpaceAccessibility<execution_space, typename ParamView::memory_space>::accessible,
                "rotm: ScalarView template parameter memory space needs to be accessible "
                "from execution_space template parameter");
  static_assert(std::is_same<typename VectorView::non_const_value_type, typename VectorView::value_type>::value,
                "rotm: VectorView template parameter needs to store non-const values");
  static_assert(!KokkosKernels::ArithTraits<typename VectorView::value_type>::is_complex,
                "rotm: VectorView template parameter cannot use complex value_type");
  static_assert(!KokkosKernels::ArithTraits<typename ParamView::value_type>::is_complex,
                "rotm: ParamView template parameter cannot use complex value_type");

  using VectorView_Internal = Kokkos::View<typename VectorView::non_const_value_type*,
                                           typename KokkosKernels::Impl::GetUnifiedLayout<VectorView>::array_layout,
                                           execution_space, Kokkos::MemoryTraits<Kokkos::Unmanaged>>;

  using ParamView_Internal = Kokkos::View<typename ParamView::const_value_type[5],
                                          typename KokkosKernels::Impl::GetUnifiedLayout<ParamView>::array_layout,
                                          execution_space, Kokkos::MemoryTraits<Kokkos::Unmanaged>>;

  VectorView_Internal X_internal    = KokkosKernels::Impl::unificationCast<VectorView_Internal>(X);
  VectorView_Internal Y_internal    = KokkosKernels::Impl::unificationCast<VectorView_Internal>(Y);
  ParamView_Internal param_internal = KokkosKernels::Impl::unificationCast<ParamView_Internal>(param);

  Kokkos::Profiling::pushRegion("KokkosBlas::rotm");
  Impl::Rotm<execution_space, VectorView_Internal, ParamView_Internal>::rotm(space, X_internal, Y_internal,
                                                                             param_internal);
  Kokkos::Profiling::popRegion();
}

template <class VectorView, class ParamView>
void rotm(VectorView const& X, VectorView const& Y, ParamView const& param) {
  const typename VectorView::execution_space space = typename VectorView::execution_space();
  rotm(space, X, Y, param);
}

}  // namespace KokkosBlas

#endif  // KOKKOSBLAS1_ROTM_HPP_
