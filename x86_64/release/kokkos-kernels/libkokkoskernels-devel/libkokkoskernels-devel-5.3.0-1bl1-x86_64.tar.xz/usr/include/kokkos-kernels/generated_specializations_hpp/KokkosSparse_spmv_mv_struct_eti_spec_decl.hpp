// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// SPDX-FileCopyrightText: Copyright Contributors to the Kokkos project

#ifndef KOKKOSSPARSE_SPMV_MV_STRUCT_ETI_SPEC_DECL_HPP_
#define KOKKOSSPARSE_SPMV_MV_STRUCT_ETI_SPEC_DECL_HPP_
namespace KokkosSparse {
namespace Impl {
KOKKOSSPARSE_SPMV_MV_STRUCT_ETI_SPEC_DECL(double,int,int,Kokkos::LayoutLeft,Kokkos::Serial,Kokkos::HostSpace)
  } //IMPL 
} //Kokkos
#endif
