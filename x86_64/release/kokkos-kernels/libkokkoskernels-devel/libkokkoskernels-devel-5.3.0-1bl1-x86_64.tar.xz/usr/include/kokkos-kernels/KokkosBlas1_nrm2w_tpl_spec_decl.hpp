// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// SPDX-FileCopyrightText: Copyright Contributors to the Kokkos project

#ifndef KOKKOSBLAS1_NRM2W_TPL_SPEC_DECL_HPP_
#define KOKKOSBLAS1_NRM2W_TPL_SPEC_DECL_HPP_

namespace KokkosBlas {
namespace Impl {}
}  // namespace KokkosBlas

#endif
