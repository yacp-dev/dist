// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// SPDX-FileCopyrightText: Copyright Contributors to the Kokkos project

#ifndef KOKKOSBLAS2_SYR2_ETI_SPEC_DECL_HPP_
#define KOKKOSBLAS2_SYR2_ETI_SPEC_DECL_HPP_

namespace KokkosBlas {
namespace Impl {
KOKKOSBLAS2_SYR2_ETI_SPEC_DECL(double,Kokkos::LayoutLeft,Kokkos::Serial)
} //IMPL 
} //Kokkos
#endif
