// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// SPDX-FileCopyrightText: Copyright Contributors to the Kokkos project

#ifndef KOKKOSBATCHED_GEMM_NT_T_BLR_ETI_SPEC_AVAIL_HPP_
#define KOKKOSBATCHED_GEMM_NT_T_BLR_ETI_SPEC_AVAIL_HPP_
namespace KokkosBatched {
namespace Impl {
using KokkosBlas::Trans;
KOKKOSBATCHED_GEMM_NT_T_BLR_ETI_SPEC_AVAIL(double,Kokkos::LayoutLeft,Kokkos::Serial,Kokkos::HostSpace)
  } //IMPL 
} //Kokkos
#endif
