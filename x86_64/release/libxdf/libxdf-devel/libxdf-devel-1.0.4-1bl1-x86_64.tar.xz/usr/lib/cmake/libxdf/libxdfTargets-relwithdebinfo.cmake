#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "XDF::xdf" for configuration "RelWithDebInfo"
set_property(TARGET XDF::xdf APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(XDF::xdf PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libxdf.dll.a"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELWITHDEBINFO "pugixml"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygxdf-0.dll"
  )

list(APPEND _cmake_import_check_targets XDF::xdf )
list(APPEND _cmake_import_check_files_for_XDF::xdf "${_IMPORT_PREFIX}/lib/libxdf.dll.a" "${_IMPORT_PREFIX}/bin/cygxdf-0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
