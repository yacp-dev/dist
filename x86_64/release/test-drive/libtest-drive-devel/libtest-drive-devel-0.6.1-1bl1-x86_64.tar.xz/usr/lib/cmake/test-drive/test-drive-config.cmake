

set("TESTDRIVE_WITH_QP" ON)
set("TESTDRIVE_WITH_XDP" ON)
set("TESTDRIVE_WITH_IEEE_IS_NAN" ON)

enable_language("Fortran")

if(NOT TARGET "test-drive::test-drive")
  include("${CMAKE_CURRENT_LIST_DIR}/test-drive-targets.cmake")
endif()
