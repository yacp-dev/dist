set(CMAKE_IMPORT_FILE_VERSION 1)

set(
  TESTDRIVE_INCLUDEDIRS
  "/usr/include"
  "/usr/include/test-drive/modules"
)
find_library(
  TESTDRIVE_LIBRARIES
  "test-drive"
  PATHS "/usr/lib"
  NO_DEFAULT_PATH
)

add_library(test-drive::test-drive-lib INTERFACE IMPORTED)
add_library(test-drive::test-drive ALIAS test-drive::test-drive-lib)
target_link_libraries(test-drive::test-drive-lib INTERFACE ${TESTDRIVE_LIBRARIES})
target_include_directories(test-drive::test-drive-lib INTERFACE ${TESTDRIVE_INCLUDEDIRS})