if [ ! -v CYGWIN_START_MENU_SUFFIX ]
then
  case $(uname -s) in *-WOW*) CYGWIN_START_MENU_SUFFIX=" (32-bit)" ;; esac
fi
/bin/rm -f "$(/usr/bin/cygpath $CYGWINFORALL -P)/Cygwin-X${CYGWIN_START_MENU_SUFFIX}/E16-GNOME2.lnk"
/bin/rm -f "$(/usr/bin/cygpath $CYGWINFORALL -P)/Cygwin-X${CYGWIN_START_MENU_SUFFIX}/E16-GNOME3.lnk"
/bin/rm -f "$(/usr/bin/cygpath $CYGWINFORALL -P)/Cygwin-X${CYGWIN_START_MENU_SUFFIX}/E16-KDE.lnk"
/bin/rm -f "$(/usr/bin/cygpath $CYGWINFORALL -P)/Cygwin-X${CYGWIN_START_MENU_SUFFIX}/E16.lnk"
/bin/rmdir --ignore-fail-on-non-empty "$(/usr/bin/cygpath $CYGWINFORALL -P)/Cygwin-X${CYGWIN_START_MENU_SUFFIX}"
if [ ! -v CYGWIN_START_MENU_SUFFIX ]
then
  case $(uname -s) in *-WOW*) CYGWIN_START_MENU_SUFFIX=" (32-bit)" ;; esac
fi
/bin/rm -f "$(/usr/bin/cygpath $CYGWINFORALL -P)/Cygwin-X${CYGWIN_START_MENU_SUFFIX}/E16-GNOME2.lnk"
/bin/rm -f "$(/usr/bin/cygpath $CYGWINFORALL -P)/Cygwin-X${CYGWIN_START_MENU_SUFFIX}/E16-GNOME3.lnk"
/bin/rm -f "$(/usr/bin/cygpath $CYGWINFORALL -P)/Cygwin-X${CYGWIN_START_MENU_SUFFIX}/E16-KDE.lnk"
/bin/rm -f "$(/usr/bin/cygpath $CYGWINFORALL -P)/Cygwin-X${CYGWIN_START_MENU_SUFFIX}/E16.lnk"
/bin/rmdir --ignore-fail-on-non-empty "$(/usr/bin/cygpath $CYGWINFORALL -P)/Cygwin-X${CYGWIN_START_MENU_SUFFIX}"
