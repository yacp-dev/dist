if [ ! -v CYGWIN_START_MENU_SUFFIX ]
then
  case $(uname -s) in *-WOW*) CYGWIN_START_MENU_SUFFIX=" (32-bit)" ;; esac
fi

case ${CYGWIN_SETUP_OPTIONS} in
  *no-startmenu*)
  ;;
  *)
  /usr/bin/mkdir -p "$(/usr/bin/cygpath $CYGWINFORALL -P)/Cygwin-X${CYGWIN_START_MENU_SUFFIX}"
  /usr/bin/mkshortcut $CYGWINFORALL -P -w / -i /usr/bin/XWin.exe -n "Cygwin-X${CYGWIN_START_MENU_SUFFIX}/E16-GNOME2" -a "--quote /usr/bin/bash.exe -l -c \"cd; XSESSION_ICON=/usr/share/e16/icons/e16.png exec /usr/bin/startx /etc/X11/xinit/Xsession e16-gnome2-session\"" /usr/bin/run.exe
  /usr/bin/mkshortcut $CYGWINFORALL -P -w / -i /usr/bin/XWin.exe -n "Cygwin-X${CYGWIN_START_MENU_SUFFIX}/E16-GNOME3" -a "--quote /usr/bin/bash.exe -l -c \"cd; XSESSION_ICON= exec /usr/bin/startx /etc/X11/xinit/Xsession e16-gnome3-session\"" /usr/bin/run.exe
  /usr/bin/mkshortcut $CYGWINFORALL -P -w / -i /usr/bin/XWin.exe -n "Cygwin-X${CYGWIN_START_MENU_SUFFIX}/E16-KDE" -a "--quote /usr/bin/bash.exe -l -c \"cd; XSESSION_ICON=/usr/share/e16/icons/e16.png exec /usr/bin/startx /etc/X11/xinit/Xsession e16-kde-session\"" /usr/bin/run.exe
  /usr/bin/mkshortcut $CYGWINFORALL -P -w / -i /usr/bin/XWin.exe -n "Cygwin-X${CYGWIN_START_MENU_SUFFIX}/E16" -a "--quote /usr/bin/bash.exe -l -c \"cd; XSESSION_ICON=/usr/share/e16/icons/e16.png exec /usr/bin/startx /etc/X11/xinit/Xsession e16-session\"" /usr/bin/run.exe
  ;;
esac
if [ ! -v CYGWIN_START_MENU_SUFFIX ]
then
  case $(uname -s) in *-WOW*) CYGWIN_START_MENU_SUFFIX=" (32-bit)" ;; esac
fi

case ${CYGWIN_SETUP_OPTIONS} in
  *no-startmenu*)
  ;;
  *)
  /usr/bin/mkdir -p "$(/usr/bin/cygpath $CYGWINFORALL -P)/Cygwin-X${CYGWIN_START_MENU_SUFFIX}"
  /usr/bin/mkshortcut $CYGWINFORALL -P -w / -i /usr/bin/XWin.exe -n "Cygwin-X${CYGWIN_START_MENU_SUFFIX}/E16-GNOME2" -a "--quote /usr/bin/bash.exe -l -c \"cd; XSESSION_ICON=/usr/share/e16/icons/e16.png exec /usr/bin/startx /etc/X11/xinit/Xsession e16-gnome2-session\"" /usr/bin/run.exe
  /usr/bin/mkshortcut $CYGWINFORALL -P -w / -i /usr/bin/XWin.exe -n "Cygwin-X${CYGWIN_START_MENU_SUFFIX}/E16-GNOME3" -a "--quote /usr/bin/bash.exe -l -c \"cd; XSESSION_ICON= exec /usr/bin/startx /etc/X11/xinit/Xsession e16-gnome3-session\"" /usr/bin/run.exe
  /usr/bin/mkshortcut $CYGWINFORALL -P -w / -i /usr/bin/XWin.exe -n "Cygwin-X${CYGWIN_START_MENU_SUFFIX}/E16-KDE" -a "--quote /usr/bin/bash.exe -l -c \"cd; XSESSION_ICON=/usr/share/e16/icons/e16.png exec /usr/bin/startx /etc/X11/xinit/Xsession e16-kde-session\"" /usr/bin/run.exe
  /usr/bin/mkshortcut $CYGWINFORALL -P -w / -i /usr/bin/XWin.exe -n "Cygwin-X${CYGWIN_START_MENU_SUFFIX}/E16" -a "--quote /usr/bin/bash.exe -l -c \"cd; XSESSION_ICON=/usr/share/e16/icons/e16.png exec /usr/bin/startx /etc/X11/xinit/Xsession e16-session\"" /usr/bin/run.exe
  ;;
esac
