#! /bin/sh
export DESKTOP_SESSION=e16-gnome3-session;
export XDG_SESSION_DESKTOP=e16-gnome3-session;

exec gnome-session --session=e16-gnome
