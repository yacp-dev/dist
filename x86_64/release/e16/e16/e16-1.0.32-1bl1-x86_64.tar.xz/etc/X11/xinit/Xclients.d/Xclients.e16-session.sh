#! /bin/sh
export DESKTOP_SESSION=e16-session;
export XDG_SESSION_DESKTOP=e16-session;

exec /usr/share/e16/misc/starte16
