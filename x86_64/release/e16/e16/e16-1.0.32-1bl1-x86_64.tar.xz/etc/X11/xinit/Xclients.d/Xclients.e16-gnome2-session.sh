#! /bin/sh
export DESKTOP_SESSION=e16-gnome2-session;
export XDG_SESSION_DESKTOP=e16-gnome2-session;

exec /usr/share/e16/misc/starte16-gnome
