#! /bin/sh
export DESKTOP_SESSION=e16-kde-session;
export XDG_SESSION_DESKTOP=e16-kde-session;

exec /usr/share/e16/misc/starte16-kde
