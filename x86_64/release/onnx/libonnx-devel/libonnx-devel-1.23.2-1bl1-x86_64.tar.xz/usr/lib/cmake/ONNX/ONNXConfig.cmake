# - Config file for the ONNX package
# It defines ONNX targets for other cmake libraries to use.

# library version information
set(ONNX_VERSION "1.23.2")

if(NOT ON)
  find_package(Protobuf REQUIRED CONFIG)
endif()

# import targets
include ("${CMAKE_CURRENT_LIST_DIR}/ONNXTargets.cmake")
