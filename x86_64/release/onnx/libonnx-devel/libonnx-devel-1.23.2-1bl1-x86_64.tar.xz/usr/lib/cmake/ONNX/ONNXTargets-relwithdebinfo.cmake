#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "ONNX::onnx" for configuration "RelWithDebInfo"
set_property(TARGET ONNX::onnx APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(ONNX::onnx PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libonnx.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygonnx-1.dll"
  )

list(APPEND _cmake_import_check_targets ONNX::onnx )
list(APPEND _cmake_import_check_files_for_ONNX::onnx "${_IMPORT_PREFIX}/lib/libonnx.dll.a" "${_IMPORT_PREFIX}/bin/cygonnx-1.dll" )

# Import target "ONNX::onnx_proto" for configuration "RelWithDebInfo"
set_property(TARGET ONNX::onnx_proto APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(ONNX::onnx_proto PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libonnx_proto.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygonnx_proto-1.dll"
  )

list(APPEND _cmake_import_check_targets ONNX::onnx_proto )
list(APPEND _cmake_import_check_files_for_ONNX::onnx_proto "${_IMPORT_PREFIX}/lib/libonnx_proto.dll.a" "${_IMPORT_PREFIX}/bin/cygonnx_proto-1.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
