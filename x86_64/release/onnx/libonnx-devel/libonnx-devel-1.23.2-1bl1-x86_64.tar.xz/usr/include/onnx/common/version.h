// Copyright (c) ONNX Project Contributors
//
// SPDX-License-Identifier: Apache-2.0

// Auto-generated from version.h.in by CMake. Do not edit version.h directly.

#pragma once

#define ONNX_VERSION_MAJOR 1
#define ONNX_VERSION_MINOR 23
#define ONNX_VERSION_PATCH 2
#define ONNX_VERSION_STRING "1.23.2"

namespace ONNX_NAMESPACE {

// Represents the current ONNX version string for this build.
// This may be a development or release-candidate version, not necessarily the most recent release.
constexpr const char* LAST_RELEASE_VERSION = ONNX_VERSION_STRING;

} // namespace ONNX_NAMESPACE
