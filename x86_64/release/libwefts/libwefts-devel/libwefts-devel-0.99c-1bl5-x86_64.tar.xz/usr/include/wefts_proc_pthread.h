/*
   wefts_coffee_pthread.h
   Cooperative file functions enlarged environment - process management.

   $Id: wefts_proc_pthread.h,v 1.1 2004/03/28 08:28:10 jonnymind Exp $
---------------------------------------------
   Begin      : 2003-08-15 16:30
   Author     : Giancarlo Niccolai

   Last modified because:

*/

/**************************************************************************
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU Library General Public License as       *
*   published by the Free Software Foundation; either version 2.1 of the  *
*   License, or (at your option) any later version.                       *
***************************************************************************/


#ifndef WT_PROC_PTHREAD_H
#define WT_PROC_PTHREAD_H

#include <pthread.h>
#include <wefts_coffee_base.h>

namespace Wefts
{

/** Representation of subprocesses on the platform.
   This class encapsulates threadsafe subprocess handling on the current platform.
   It provides support to spawn a child of the process, access its stdin, stdout and
   stderr file handle, test it's status and eventually
   wait for its termination.
   
   The encapsulation is made so that the child process can be referenced to the thread
   that spawned it; if the father thread is cancelled, so the child process is.
*/

class OSProcessPthread: public OSProcessBase
{
   pthread_mutex_t m_mutex;
   pid_t m_pid;
   
   int m_childIn, m_childOut, m_childErr;
   bool m_sinkIn, m_sinkOut, m_sinkErr;
   
   void detachUnlocked();
   
   static int parametrize( char *dese, const char *src );
   static char ** argvize( char *dest, int size );
public:
   
   OSProcessPthread();
   ~OSProcessPthread();
   
   virtual bool running();
   virtual bool wait( const double seconds=-1.0 );   
   virtual bool start( const std::string process, bool useShell=false, bool usePath=true );
   virtual bool stop();
   virtual bool getProcessValue( int &retvalue ) const;
   virtual file_size_t getProcessId() const;   
   virtual int write( const void *data, const int size, const double seconds=-1.0 );
   virtual int read( void *data, const int size, const double seconds=-1.0 );
   virtual int readStdErr( void *data, const int size, const double seconds=-1.0 );   
   virtual void mergeStdErr();
   virtual void detach();
   
   virtual void sinkInput();
   virtual void sinkOutput();
   virtual void sinkError();
   
   virtual bool closeRead(); 
   virtual bool closeWrite();
   virtual bool closeStdErr();
   virtual void handleCleanup( int code, void *caller=0 );
};

typedef OSProcessPthread Process;

}
#endif

/* end of wefts_proc_pthread.h */
