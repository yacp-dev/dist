/*
   wefts_semaphore.h
   Semaphore object header file.

   $Id: wefts_semaphore.h,v 1.5 2004/03/28 21:45:40 jonnymind Exp $
---------------------------------------
   Begin      : Mon, 08 Mar 2004 21:52:32 +0100
   Author     : Giancarlo Niccolai

   Last modified because:
   Implementing OS independent base threading
*/

/**************************************************************************
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU Library General Public License as       *
*   published by the Free Software Foundation; either version 2.1 of the  *
*   License, or (at your option) any later version.                       *
***************************************************************************/

#ifndef WT_SEMAPHORE_H
#define WT_SEMAPHORE_H

#include <wefts_fastcond.h>

namespace Wefts {

/** Semaphore semantic.

   \ingroup adv_sync

   Semaphores are counters for resources shared between threads. 
   The basic operations on semaphores are: increment the counter 
   atomically, and wait until the counter is non-zero and decrement 
   it atomically. 
   
   Wefts semaphores have some added ability with respect of posix
   version: timed waits are allowed, and an internal count of waiters
   is held.
   
   Wait (both timed and infinite) is considered a cancellation point.
   A cleanup routine will be called and the thread will be termianted
   if a cancellation request is issued while the thread is waiting
   for the semaphore to become available.
      
*/

class Semaphore: public CleanupHandler
{
private:
   int m_count;
   int m_waiting;
   FastCondition m_cond;
   
public:
   /** Initializes the semaphore.
      The initial count value is 1 by default. This will make the first
      wait request on the semaphore to suceed and the second one to be blocked,
      thus making the semaphore acting effectively as a non-reentrant mutex.
      
      Use a different initialization value if the semaphore is a counter for
      a shared resource that may be assigned to a given amount of threads
      before to block other requests. In particular, 0 may be used to prevent
      the first wait request to proceed, providing a shared resource count that
      can be risen by other threads as resources becomes available. With initial
      count equal to 0, the semaphore acts similarily to a condition variable.
      
      @param initial_count amount of wait() calls allowed before the calling
             thread is blocked.
   */
   Semaphore( int initial_count = 1 )
   {
      m_count = initial_count;
      m_waiting = 0;
   }
   
   /** Gets the current value of the semaphore.
      Notice that unless the caller can guarantee that no other thread may 
      change this value in the meanwhile, the returned value is meaningless,
      as it may change before the thread has the chance to evalute it.
      \return current semaphore value.
   */
   
   inline int value() { return m_count; }
   
   /** Gets the current amount of threads waiting for this resource.
      Notice that unless the caller can guarantee that no other thread may 
      change this value in the meanwhile, the returned value is meaningless,
      as it may change before the thread has the chance to evalute it.
      \return threads that are currently waiting for the resource to become 
         available.
   */
   inline int waiters() { return m_waiting; }
   
   /** Increments the semaphore count.
      This is done by a thread when it wants to state that it is not holding
      the shared resource anymore.
      
      If the count reaches 1 or above and there are waiting threads, a signal is
      issued to wake them.
      
      If the current thread is responible for more than one shared resource 
      accounted by the semaphore, it can call post() with a number greater
      than one, representing the amount of shared resources released.
      
      \param amount Quantity by which the semaphore is risen.
   */
   inline void post(int amount=1) {
      m_cond.lock();
      m_count+=amount;
      // todo: would be greatly optimized if signal would not do a broadcast.
      if ( m_waiting > 0 ) 
      {
         if ( m_count == 1 )
            m_cond.signalOne();
         else if ( m_count > 1 )
            m_cond.signal();
      }
      m_cond.unlock();
   }
   
   /** Wait endlessy until the resource is available.
      This means, until the count becomes 1.
      
      If the current thread is canceled during wait, then the cleanup
      handler passed as a parameter is called.
      
      By default, the cleanup action of this class unlocks the internal
      mutex and removes itself from the count of waiting threads.
      
      If another cleanup routine is used, Semaphore::handleCleanup() must
      be anyway called at its end, to ensure that waiting list is correctly 
      updated.
      
      Anyhow, application level threads should use Thread::pushCleanup(); this
      method is meant only to hook subclasses or provide specialized
      semaphores.
      
      @param handler the object that will take care of cleaning the mutex wait.
      @param position a value to determine alternative actions in the cleanup routine.
   */
   void wait(CleanupHandler *handler = 0, int position = 0);
      
   /** Wait until the resource is available, with a given timeout.
      
      This means, until the count becomes 1. If seconds is set to 0, 
      it exits almost immediately, but tryWait() should be used instead:
      the test is faster and lighter, and tryWait is NOT a cancellation
      point (while wait is).
      
      \see wait(CleanupHandler *, int) for cancellation issues
      
      @param seconds wait in seconds before exiting.
      @param handler the object that will take care of cleaning the mutex wait.
      @param position a value to determine alternative actions in the cleanup routine.
      @return true if sucessful, false if timeout expired.
   */
   bool wait( double seconds, CleanupHandler *handler = 0, int position = 0 );
   
   /** Test if the resource is free, and if it is, it decrements resource count.
      As tryWait() does a fast check on the semaphore, it is not considered a
      cancellation point; the count of waiting threads is not changed and if the
      resource cannot be acquired, it returns immediately.
      
      @return true if the resource has been acquired, false otherwise.
   */
   bool tryWait()
   {
      bool ret;
      m_cond.lock();
      if ( m_count > 0 ) { 
         m_count --;
         ret = true;
      }
      else
         ret = false;
      m_cond.unlock();
      
      return ret;
   }
      
   virtual void handleCleanup( int code, void *caller=0 );  
};

}
#endif
/* end of wefts_semaphore.h */
