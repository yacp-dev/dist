/*
   wefts_coffee_unix.h
   Unix implementation for cooperative file functions enlarged enviroment

   $Id: wefts_coffee_unix.h,v 1.6 2004/03/17 11:52:19 jonnymind Exp $
---------------------------------------------
   Begin      : 2003-08-15 16:30
   Author     : Giancarlo Niccolai

   Last modified because:

*/

/**************************************************************************
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU Library General Public License as       *
*   published by the Free Software Foundation; either version 2.1 of the  *
*   License, or (at your option) any later version.                       *
***************************************************************************/


#ifndef WT_COFFEE_UNIX_H
#define WT_COFFEE_UNIX_H

#include <wefts_coffee_base.h>

#include <sys/select.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>


namespace Wefts {

    
/** \addtogroup oscoffee
@{
*/

/** OS COFFEE Unix implementation.

   This class implements Cooperative File Functions under unix enviroments.
   
   Unix is usually very cooperative towards threading, and this means that
   calls inside this class are usually very simple inline calls to unix
   system calls.
   
   You can access this class with the typedef OSFileFunc.
   
   \see \ref howto_oscoffee
*/
class OSFileFuncUnix : public OSFileFuncBase
{
protected:
   /* Unix file descriptor to the open field */
   int m_fd;

#ifndef HAVE_PSELECT
   int pselect(int n, fd_set *r, fd_set *w, fd_set *e, struct timespec * ti, void * mask)
   {
       struct timeval to;

       to.tv_sec  = ti->tv_sec;
       to.tv_usec = ti->tv_nsec / 1000;
       return select(n, r, w, e, &to);
   }
#endif // ifndef HAVE_PSELECT

   bool waitForWrite()
   {
      if ( m_timeout < 0 ) return true;
      fd_set set;
      struct timespec timeout;

      FD_ZERO( &set );
      FD_SET( m_fd, &set);
      timeout.tv_sec = static_cast<long>(m_timeout);
      timeout.tv_nsec = static_cast<long>(
         (m_timeout - static_cast<long>(m_timeout)) *1000000000);
      pselect(m_fd + 1, NULL, &set, NULL, &timeout, NULL);

      return FD_ISSET( m_fd, &set );
   }


   bool waitForRead()
   {
      if ( m_timeout < 0 ) return true;
      fd_set set;
      struct timespec timeout;

      FD_ZERO( &set );
      FD_SET( m_fd, &set);
      timeout.tv_sec = static_cast<long>(m_timeout);
      timeout.tv_nsec = static_cast<long>(
         (m_timeout - static_cast<long>(m_timeout)) *1000000000);
      pselect(m_fd + 1, &set, NULL, NULL, &timeout, NULL);

      return FD_ISSET( m_fd, &set );
   }


public:
   OSFileFuncUnix( void *descriptor = 0) :
         OSFileFuncBase()
   {
      if ( descriptor != 0 )
         setDescriptor( descriptor );
   }

   virtual CffStatus open(
      std::string filespec,             // the file name
      OpenMode openMode = OM_RO,        // open mode
      LockMode lockMode = LM_SHARED   // the file lock mode
      );

   virtual CffStatus create(
      std::string filespec,               // the file name
      CreateMode cMode = CM_ARCHIVE,            // system atrribute
      LockMode lockMode = LM_EXCLUSIVE  // the file lock mode
      );


   /** To get the descriptor, pass a pointer to an integer where
      the descriptor will be placed.
   */
   inline virtual void getDescriptor( void *data ) const
   {
      *static_cast<int *>(data) = m_fd;
   }

   /** To set the descriptor, pass a pointer to the integer.
   */
   inline virtual void setDescriptor( void *data )
   {
      m_fd = *static_cast<int *>(data);
   }

   virtual file_size_t read( void *buffer, const file_size_t len );
   virtual file_size_t write( void *buffer, const file_size_t len );
   virtual file_size_t seek(
      const file_size_t position,
      const SeekWhence swFrom= SW_FROM_BEGIN
      );
   virtual CffStatus close();

   inline virtual void setStdIn() { m_fd = 0; }
   inline virtual void setStdOut(){ m_fd = 1; }
   inline virtual void setStdErr(){ m_fd = 2; }

};

/** Definition that hooks unix in your application */
typedef OSFileFuncUnix OSFileFunc;

/*@}*/
} // namespace

#endif

/* end of wefts_coffee_unix.h */
