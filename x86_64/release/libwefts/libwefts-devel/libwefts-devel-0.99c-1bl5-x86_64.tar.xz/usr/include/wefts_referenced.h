/*
   wefts_referenced.h
   Reference counter base class.

   $Id: wefts_referenced.h,v 1.4 2004/03/28 21:45:40 jonnymind Exp $
---------------------------------------------
   Begin      : 2003-08-04 20:15
   Author     : Giancarlo Niccolai

   Last modified because:

*/

/**************************************************************************
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU Library General Public License as       *
*   published by the Free Software Foundation; either version 2.1 of the  *
*   License, or (at your option) any later version.                       *
***************************************************************************/

#ifndef WT_REFERENCED_H
#define WT_REFERENCED_H

#include <wefts_rwmutex.h>
#ifndef NO_ASSERTIONS
#include <cassert>
#endif


namespace Wefts {

/** Shared object between threads implementing reference count and self-cancellation.

   \ingroup adv_sync

   Many times, complex multithread programs need to produce a dynamically
   allocated object that is then shared among many user threads. This
   object must then be available until the last thread needing it is done with it.

   The most simple way to achieve this is to provide a threadsafe reference
   count that can be incremented or decremented. When the last user having
   a reference on the object releases it, the destructor is called.

   This object is derived from a read/write mutex, so the users can access the
   mutex in read/only mode (which is most common when you are distributing
   an object to many user threads.

   \note The read/write mutex is not reentrant.
*/

class Referenced: public RWMutex
{

private:
   /** Count of users referencing the object */
   int m_count;
   /** True if last reference should delete itself */
   bool m_disposeable;

protected:
   /** Creates the referenced object with an initial count of users.
      The count of current users can never be less than 1; it can be
      more if the creating process has a hint of the objects that are
      already waiting for this reference to be created.
      The disposeable parameter should be given and set to false if this
      object is not dinamically created, but is statically held somewhere
      int the creator's stack. In this case, the object won't be destroyed
      even when the reference count reaches 0, as it will be destroyed during
      owner's stack frame unwinding.

      @param count users ready to use this data at creation
      @param dispose true to have it deleted when reference count
         reaches zero, false if this obhect is statically allocated.
   */
   Referenced( int count = 1, bool dispose = true ):
      RWMutex()
   {
      #ifndef NO_ASSERTIONS
      assert ( count > 0 );
      #endif
      m_count = count > 1 ? count : 1;
      m_disposeable = dispose;
   }

   /** The destructor may be called only by this class */
   virtual ~Referenced() {}

public:

   /** Increments the reference count of the varaible.
      Be careful not to cause race conditions so that you try to
      increment the reference of an object that is now being destroyed.
   */
   void incRef() {
      lockWrite();
         if (m_count > 0 ) // if m_count == 0 we are going to be destroyed now.
            m_count++;
      unlock();
   }

   /** Decrements reference count.
      If count reaches zero, the object is destroyed.
      Be careful not to cause race conditions so that you try to
      increment the reference of an object that is now being destroyed.
   */
   void decRef() {
      bool destroy = false;
      lockWrite();
      if ( m_disposeable && m_count > 0 ) m_count--;
      if ( m_count <= 0 ) destroy = true;
      unlock();
      // now, an incref could arrive here, but it would be an error,
      // a race caused by misusing this object.
      // An assert here should do, but I don't know if asserting in this
      // lib would be appreciated by users; anyhow, the user will get a
      // segfault after incref.
      if ( destroy ) delete this;
   }

   /** Returns the reference count of an object.
      To be sure that the count of this object is still valid after this
      call, the caller must surround this call with a lock. Normally a
      read lock will be enough, but if the caller is going to reference
      this object more, with an incRefUnlocked, then a call inside
      a writeLock() is needed:
      \code
         MyReferenced *ref = new MyReferenced();

         // Reading the value correctly
         //
         ref->readLock();
         if ( ref->references() < 10 )
            std::cout << "There are currently " << ref->references << std::endl;
         ref->unlock();

         // Writing correctly
         //
         ref->writeLock();
         // ...we know there are several threads waiting for us...
         while( ref->references() < 10 )
            ref->incRefUnlocked();
         ref->unlock();
      \code

      \note There isn't a decRefUnlocked method as it could cause
         program crashes if the count reaches 0 before unlocking.
   */
   int references() { return m_count; }

   /** Increments the reference of the object without using the write locking.
      This is meant to be used ONLY in code blocks where this object is already
      write locked. See the references() method for an example.
   */
   void incRefUnlocked() { m_count++; }

   /** Set Reference count to given amount.
      This is meant to be used ONLY in code blocks where this object is already
      write locked. See the references() method for an example.
      \note setting a reference count lower than 1 will cause an assertion
      fault.
      @param count the new reference count
   */
   void setRefUnlocked( int count )
   {
      #ifndef NO_ASSERTIONS
      assert( count > 0 );
      #endif
      m_count = count;
   }

};

}

#endif
/* end of wefts_referenced.h */
