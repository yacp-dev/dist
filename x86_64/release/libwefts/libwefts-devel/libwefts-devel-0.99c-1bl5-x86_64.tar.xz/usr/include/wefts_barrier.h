/*
   wefts_barrier.h
   Execution barrier for wefts.

   $Id: wefts_barrier.h,v 1.4 2004/03/28 21:45:40 jonnymind Exp $
---------------------------------------------
   Begin      : 2003-08-03 17:50
   Author     : Giancarlo Niccolai

   Last modified because:

*/

/**************************************************************************
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU Library General Public License as       *
*   published by the Free Software Foundation; either version 2.1 of the  *
*   License, or (at your option) any later version.                       *
***************************************************************************/


#ifndef WT_BARRIER_H
#define WT_BARRIER_H

#include <wefts_fastcond.h>


namespace Wefts {

/** Programmable fence object.

   \ingroup adv_sync

   A Barrier is a synchronization object that blocks calling threads until
   a certain amount of them has been blocked, or until another thread
   releases them.
   This construct is useful in process made by steps where a given amount
   of threads has to complete their processing before continuing to the
   next phase.
   Also, the construct is useful when there is a "blocking condition"
   that must be solved by another thread before processing can continue.
   Then the controlling thread can rise a barrier, and lower it temporarily
   or definitively when the blocking condition is solved.
*/

class Barrier {
private:
   volatile unsigned int m_treshold;
   volatile unsigned int m_subscribed;
   FastCondition m_cond;   // should be auto-magically initialized and removed
   volatile bool m_release;
   volatile bool m_open;

public:
   /** Creates a barrier with a given treshold.
      The barrier is initially created with gate closed (blocking threads),
      and with a given treshold.
      If treshold is == 0, then all the threads must be released with
      the release() method, or opening the barrier.
      @param treshold 0 or the count of threads that are blocked before release.
      @param open true to disable the barrier, false to have it operational
   */
   Barrier( unsigned int treshold=0, bool open = false );

   /** Waits for treshold to have reach a certain count.
      When a number of threads equal to m_treshold have called
      this method, all the waiting threads are released. */
   void wait();

   /** Returns the count of subscribing threads */
   inline unsigned int waiting() { return m_subscribed; }

   /** Returns the current treshold count */
   inline unsigned int treshold() { return m_treshold; }

   /** Return true if the barrier is blocking the threads, or false if
       the barrier is currently open. */
   inline bool blocking() { return !m_open; }

   /** Changes the current treshold count.
      If the new treshold value is lower than the currently held threads,
      then the threads are immediately released, unless the value
      passed is 0.*/
   void treshold( unsigned int th );

   /** Release all currently blocked threads.
      If the barrier is currently open, this call is ignored. If the barrier
      is currently closed, only the threads that are waiting in the moment of
      the call are released; the status of the barrier is not changed */
   void release();

   /** Opens the barrier.
      Opens the barrier, releasing all the currently held threads AND
      allowing all the threads to pass the barrier without blocking from
      now on */
   void open();

   /** Closes the barrier.
      All the threads willing to enter the barrier will now be blocked. */
   void close();

};

}

#endif
/* end of wefts_barrier.h */
