/*
   wefts_specific.h
   Thread Specific Data object template

   $Id: wefts_specific.h,v 1.6 2004/03/28 21:45:40 jonnymind Exp $
---------------------------------------------
   Begin      : 2003-08-15 06:05
   Author     : Giancarlo Niccolai

   Last modified because:

*/

/**************************************************************************
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU Library General Public License as       *
*   published by the Free Software Foundation; either version 2.1 of the  *
*   License, or (at your option) any later version.                       *
***************************************************************************/

#ifndef WT_SPECIFIC_H
#define WT_SPECIFIC_H

#include <wefts_os.h>

namespace Wefts {

/** Implements a very fast thread specific data.

   \ingroup utilities

   This class abstracts the access to thread specific data encapsulated
   it in the semantics of a pointer. Laid down simply, you have here a
   pointer that will point to a different thing in different threads.

   Usage is pretty simple; declare a template of the data type you
   need, and you have an object that acts with the semantics of a
   pointer to that type:

   \code
      ...
      ThreadPtr<int> status;
      int data;

      status = &data;
      *status = 2; // --> data == 2!
      status == &data; //--> TRUE!

      // have a way to send a status reference (or pointer, if you like)
      // to all the threads, i.e.
      MyThread mt1( status );
      MyThread mt2( status );
      MyThread mt3( status );

      mt1.start();
      mt2.start();
      mt3.start();
      ...
   \endcode

   In the run() method of our threads you will assign the status to different
   object pointers; you will be able to use the same status reference, and the
   object that it is pointing will be different in each thread.

   When a ThreadPtr is not initialized, it holds the value 0. Trying to
   access it using the <b>*</b> operator will throw a InvalidError.

   Once the pointer is created (i.e. statically declared in one module,
   or allocated dynamically), a ThreadPtr should never be deleted; you
   should consider it as a "cargo" that may hold various things you may
   need, that once you ask for, stays until the end of the program.

   Support for deleting this object is provided, but if you do so, you
   must make sure that there isn't any thread referencing anymore to this
   ThreadPtr, AND that all the data stored in the various threads is
   already cleaned. In fact, it is impossible for the thread that delete this
   object to access, and so, to clean the data stored by other threads.

   The same is true also for derived classes or classes using this pointer.

   A simple implementation can be using this ThreadPtr class as a member of
   a class derived from Referenced; you would then have an object that could
   hold some data common to all threads (and that you can guard with Referenced
   lock() calls), and some other data that is different in each thread:
   \code
      class SmartRef: public Referenced
      {
         MyThing *common;
         ThreadPtr<MyThing> specific;
         ...
      };
   \endcode

   Anyway, you have still to take care to manually delete  the specific data.
*/

template< typename _T >
class ThreadPtr
{
private:
   /** Low level thread specific accessor */
   OSSpecificData m_specific;

protected:
   /** Dereference the internal pointer to obtain the object reference.
      If the internal pointer is null, that is, if the pointer has not yet
      been set, an InvalidError is thrown.
   */
   _T &deref() throw( InvalidError )
   {
      void *dt = m_specific.data();
      if ( dt == 0 ) throw InvalidError();
      return *static_cast<_T *>(dt);
   }

public:
   ThreadPtr() {}
   ThreadPtr( _T *data ) { set(data); }
   ThreadPtr( ThreadPtr<_T> &src ) { set( src ); }

   /** Gets the pointer that is stored in this object */
   _T *get() const { return static_cast<_T *>( m_specific.data() ); }

   /** Copies another pointer into this one.
      Both of the pointers may be invalid (holding a null) when called.
   */
   ThreadPtr<_T > &set( ThreadPtr<_T > &src ){
      m_specific.data( static_cast< void *>(src.m_specific.data()));
      return *this;
   }

   /** Set the data pointed by this thread.
      The parameter may also be 0; this will reset this object to the
      invalid state.
   */
   _T *set( _T *data ) {
      m_specific.data( static_cast< const void *>(data));
      return data;
   }

   /** Verifies if two ThreadPtr objects are equal.
      Returns true only if the specifics are holding the SAME pointer. To
      see if two objects held in a ThreadPtr are equal, use the usual
      <i>*ptra == *ptrb</i> syntax.
   */
   bool equal( const ThreadPtr<_T > &src ) const {
      return equal( src.m_specific.data() );
   }

   /** Verifies if a ThreadPtr is holding a certain data (in this thread).
      Works also if the parameter is 0, returning true if the object is
      initialized. So, <i>thptr == 0</i> is a valid way to determine if the
      object is in an invalid state.
   */
   bool equal( const _T *data) const { return (m_specific.data() == data); }

   _T &operator*() { return deref(); }
   ThreadPtr<_T > &operator=( ThreadPtr<_T > &src ) { return set( src ); }
   _T *operator=( _T *data ) { return set(data); }

   bool operator ==( const ThreadPtr<_T > &src ) const {return equal( src );}
   bool operator ==( const _T *data ) const { return equal(data); }

   bool operator !=( const ThreadPtr<_T > &src ) const { return ! equal( src ); }
   bool operator !=( const _T *data ) const { return !equal(data); }
};

} // namespace
#endif

/* end of wefts_specific.h */
