/*
   wefts_error.h
   Error classes - for trhow statements.

   $Id: wefts_error.h,v 1.6 2004/03/28 21:45:40 jonnymind Exp $
---------------------------------------------
   Begin      : 2003-08-15 17:13
   Author     : Giancarlo Niccolai

   Last modified because:

*/

/**************************************************************************
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU Library General Public License as       *
*   published by the Free Software Foundation; either version 2.1 of the  *
*   License, or (at your option) any later version.                       *
***************************************************************************/


#ifndef WT_ERROR_H
#define WT_ERROR_H

#include <string>
#include <iostream>

/** \file
   Definitions of throwable Wefts errors.
   Unexpected situations may throw an error in Wefts; error classes
   are provided to carry the most possible descriptvie data about the
   error, thus not disregarding performance issues.
*/

namespace Wefts {

/** \addtogroup errors
@{
*/

/** Generic error class
   This is meant to be overloaded by specific error classes below.
*/
class Error
{
private:
   int m_osCode;
   std::string m_descr;

public:
   /** Create the error.
   \param code OS dependant code (if available)
   \param descr a description of the error that can be human readable.
   */
   Error( int code=0, std::string descr="Generic low-level error" );

   /** Return a numeric OS-dependant code.
      This can be useful for debugging application running in a given
      environment
   */
   int osCode() const { return m_osCode; }

   /** Returns a descriptive string about what the error is. */
   virtual const std::string &description() const { return m_descr; }

   /** Returns the name of the class. */
   virtual const std::string className() const { return "Wefts::Error"; }

   /** Serializes the error.
      Use this operator to display what kind of error has happened
   */
   friend std::ostream& operator<<( std::ostream &stream, Error &err );
};


/** Error risen when the thread tries to join a detached thread. */
class NotJoinableError: public Error
{
public:
   /** Create the error.
   \param code OS dependant code (if available)
   \param descr a description of the error that can be human readable.
   */
   NotJoinableError( int code=0, std::string descr = "Can't join target thread" );

   /** Returns the name of the class. */
   virtual const std::string className() const { return "Wefts::NotJoinableError"; }

};

/** Error risen if an object is in an invalid state while being used. */
class InvalidError: public Error
{
public:
   /** Create the error
   \param code OS dependant code (if available)
   \param descr a description of the error that can be human readable.
   */
   InvalidError( int code=0, std::string descr="Using an object in an invalid state" );
   
   /** Returns the name of the class. */
   virtual const std::string className() const { return "Wefts::InvalidError"; }

};

/** Error risen when there is an object can't be initialized. */
class InitError: public Error
{
public:
   /** Create the error.
   \param code OS dependant code (if available)
   \param descr a description of the error that can be human readable.
   */
   InitError( int code=0, std::string descr="Object cannot be initialized" );

   /** Returns the name of the class. */
   virtual const std::string className() const { return "Wefts::InitError"; }

};

/** Error risen when is not possible to start other threads anymore. */
class StartError: public Error
{
public:
   /** Create the error
   \param code OS dependant code (if available)
   \param descr a description of the error that can be human readable.
   */
   StartError( int code=0, std::string descr="Can't start OS thread" );

   /** Returns the name of the class. */
   virtual const std::string className() const { return "Wefts::StartError"; }

};

/**
@}
*/

}

#endif

/* end of wefts_error.h */
