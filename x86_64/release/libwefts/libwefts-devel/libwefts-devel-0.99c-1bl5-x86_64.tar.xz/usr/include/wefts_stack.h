/*
   wefts_stack.h
   Waitable template FIFO structure.

   $Id: wefts_stack.h,v 1.3 2004/03/28 21:45:40 jonnymind Exp $
---------------------------------------------
   Begin      : 2003-08-03 17:50
   Author     : Giancarlo Niccolai

   Last modified because:

*/

/**************************************************************************
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU Library General Public License as       *
*   published by the Free Software Foundation; either version 2.1 of the  *
*   License, or (at your option) any later version.                       *
***************************************************************************/


#ifndef WT_STACK_H
#define WT_STACK_H

#include <wefts_fastcond.h>
#include <list>

namespace Wefts {

/** Waitable template LIFO structure.

   \ingroup adv_sync

   A Stack, in Wefts++ context, is an Last-in first-out synchronization
   object, where one or more thread are
   posting data, and one or more thread are waiting for data to become
   available to process it. The last data posted will be retreived by
   the first thread coming in search for data.

   Stack is a fast and clean way to pass arbitrary data in a 1:1 scheme
   from a producer to a consumer (or from a master to a worker) even if
   there are more producer/masters and consumer/workers running at the same
   time.

   Stacks have not any scheduling poicies; the first thread that is able
   to wake up will take the first element available.

   By default, stacks have infinite size. You can set a maximum length
   and in that case, a thread willing to post a new data will be blocked
   until the stack becomes free again, or will immediately return an
   error (depending on user preferences).

   \note It is illegal to destroy a Stack while there are threads waiting.
*/

template <class T>

class Stack {
private:
   void p_waitForFree() {
      while ( m_list.size() >= m_maxLen )
         m_cond.wait();
   }

   void p_waitForFull() {
      while ( m_list.size() == 0 )
         m_cond.wait();
   }

protected:
   FastCondition m_cond;
   unsigned long m_maxLen;
   std::list<T> m_list;

public:
   /** Creates a stack.
      If the parameter is zero, the stack will have infinite length; if
      it is not zero, push() method will block or return immediately
      false when the maximum length is reached.
      \param maxLen maximum length of the stack or 0.
   */
   Stack( unsigned int maxLen = 0) {
      m_maxLen = maxLen;
   }

   /** Pushes data in the stack.

      Stacks are LIFO, that is Last in, First out. The last element
      you push will be served first to the waiters.

      \param elem the data to be pushed in the Stack
      \param wait true to wait in case the stack is full, false to
         return immediately
      \return true if operation suceeded, false if stack is full and
         \e wait parameter is false
   */
   bool push( T elem, const bool wait=false)
   {
      m_cond.lock();
      if ( m_maxLen > 0 && m_list.size() >= m_maxLen )
      {
         if ( wait ) {
            // this is for compilers that canno expand loops inline
            p_waitForFree();
         }
         else {
            m_cond.unlock();
            return false;
         }
      }
      m_list.push_back( elem );
      m_cond.signal();
      m_cond.unlock();
      return true;
   }

   /** Pops data from the stack.

      Stacks are LIFO, that is Last in, First out. The last element
      you push will be served first to the waiters.

      Note that the default behavior of pop() is to wait until there
      is some data to be placed in the parameter, but you can also
      set wait parameter to false to have an immediate return in case
      of the stack being empty in that moment.

      A blocking pop() is a cancellation point; be sure you have a proper
      cleanup scheme set up before to call a blocking pop.

      \param elem an element that will receive the popped value.
      \param wait if false, returns immediately if the stack is empty.
      \return true if operation suceeded, false if stack is full and
         \e wait parameter is false
   */

   bool pop( T &elem, const bool wait=true)
   {
      m_cond.lock();
      if ( m_list.size() == 0 )
      {
         if ( wait ) {
            // this is for compilers that canno expand loops inline
            p_waitForFull();
         }
         else {
            m_cond.unlock();
            return false;
         }
      }
      elem = m_list.back();
      m_list.pop_back();
      m_cond.signal();
      m_cond.unlock();
      return true;
   }

};

}

#endif
/* end of wefts_stack.h */
