/*
   wefts_cond.h
   Abstract class implementing a condition variable.

   $Id: wefts_cond.h,v 1.14 2004/03/28 21:45:40 jonnymind Exp $
----------------------------------------------
   Begin      : 2003-08-02 00:10
   Author     : Giancarlo Niccolai

   Last modified because:
   Implementing OS independent base threading
*/

/**************************************************************************
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU Library General Public License as       *
*   published by the Free Software Foundation; either version 2.1 of the  *
*   License, or (at your option) any later version.                       *
***************************************************************************/

#ifndef WT_COND_H
#define WT_COND_H

#include <wefts_mutex.h>
#include <wefts_cleancond.h>

namespace Wefts {

/** Class implementing a condition variable.

   \ingroup conditions

   This condition class is meant to be overloaded by classes using
   specific mutex types. To use it, you have to create your own
   class using a combination of this class plus a fast or a
   reentrant mutex. This is implemented in the wtFastCondition and
   wtRCondition classes.

   Subclassess must set m_my_mutex to a valid Wefts::Mutex pointer (or any
   subclass of that).

   All condition classes are implemented via inline calls to maximize execution
   speed; also, their metods are extremely small.
*/
class Condition
{
protected:
   /** Internal condition variable */
   OSCondition m_cond;
   /** Internal mutex.
      Subclasses are invited to set this mutex to an initialized specific kind
      of mutex at creation.
   */
   Mutex *m_my_mutex;


public:
   /** Initializes the internal data of the condition.
      Initialization of m_my_mutex member is left to subclasses. */
   Condition( Mutex *mtx=0 )
   { 
      m_my_mutex = mtx; 
   }
    
   ~Condition() {}

   /** Waits for the condition to be active.
      This method waits forever or until stopped by an external event (signal).

      Be sure to 1) don't stop a thread while waiting on a condition, 2)
      disable cancellation around a wait() or 3) set up a cancellation sequence
      (\ref howto_cleanup_conds).

      @returns true if condition is signaled, false on error.
   */
   virtual inline bool wait( CleanupHandler *cup = 0, int pos = 0 ) {
      CleanupItem clup( cup, pos, this );
      return m_cond.wait( m_my_mutex->m_mutex, clup );
   }

   /** Set the mutex used by this condition.
      Usually, this is used by subclasses, dervied both by conditionts and
      mutexes to set themselves as mutexes. It may also be used in 1:N
      mutexing schemes, where a single mutex (protecting a wide dataset)
      must be used by more than one condition (each willing to test part of that
      dataset).
   */
   void setMutex( Mutex *mtx) { m_my_mutex = mtx; }
   /* Returns the mutex used by this condition. */
   Mutex *getMutex() { return m_my_mutex; }

   /** Waits for the condition to be active up to a certain time.
      This method works as wait() but returns (with nonzero value) if a certain
      time has elapsed.

      If you call this function, you have to specify the amount of seconds
      and second fractions (expressed in nanoseconds) you want to wait for a
      single event to be risen. Granularity of the system greatly depends on
      underlying OS and process priviledges.

      Be sure to 1) don't stop a thread while waiting on a condition, 2)
      disable cancellation around a wait() or 3) set up a cancellation sequence
      (\ref howto_cleanup_conds).

      @param seconds integer count of seconds to wait for.
      @param nanoseconds integer count of nanoseconds to wait for
         (maximum is 999,999,999).
      @param cup the cleanup handler that superintends cancellation cleanup sequence.
      @param pos an extra parameter for the cleanup handler, by which the handler may know
             what to do (if its gets called by multiple "positions" in the source code).
      @return true if condition is signaled, false on error.
   */
   virtual inline bool wait( long seconds, long nanoseconds, CleanupHandler *cup = 0, int pos = 0)
   {
      CleanupItem clup( cup, pos, this );
      return m_cond.timedWait( m_my_mutex->m_mutex, seconds, nanoseconds, clup );
   }


   /** Waits for the condition to be active for a certain time.
      Works as wait( long seconds, long nanoseconds), but the wait time can
      be expressed as a real number, 1.0 meaning a second.

      Be sure to 1) don't stop a thread while waiting on a condition, 2)
       disable cancellation around a wait() or 3) set up a cancellation sequence
      (\ref howto_cleanup_conds).

      @param cup the cleanup handler that superintends cancellation cleanup sequence.
      @param pos an extra parameter for the cleanup handler, by which the handler may know
             what to do (if its gets called by multiple "positions" in the source code).
      @param seconds time to wait for (seconds and fraction of seconds expressed as decimal part)
      @return true if condition is signaled, false otherwise.
   */
   inline bool wait( double seconds, CleanupHandler *cup = 0, int pos = 0 )
   {
      return wait( long( seconds ),
         long( (seconds - long(seconds)) *1000000000l), cup, pos );
   }

   /** Signals the condition, waking all waiting threads.
      When a condition is signaled all the waiting threads are given a chance to go.
   */
   virtual inline void signal() { m_cond.signal(); }
   
   /** Signals the condition, waking one thread.
      When a condition is signaled with this method, only one of the wating threads are awaken.
      This is only useful in situation where it can be prooved that 
         -# a random thread among the waiting ones will surely find its condition test changed and
         -# only one thread would be able to proceed, blocking all the others.
      In this situation, waking all the threads just to have one able to proceed is clearly a waste.
      Applications will rarely need to use this method, as this pre-requisites can rarely be guaranteed. One
      example is Wefts++ implementation of semaphores, where, by design, only one thread can
      proceed when a former semaphore owning thread releases the semaphore just once.
   */
   virtual inline void signalOne() { m_cond.signalOne(); }

};

}

#endif
/* end of wefts_cond.h */
