/*
   wefts_coffee_win.h
   Windows implementation for cooperative file functions enlarged enviroment

   $Id: wefts_coffee_win.h,v 1.6 2004/03/28 21:45:40 jonnymind Exp $
---------------------------------------------
   Begin      : 2003-08-15 16:30
   Author     : Giancarlo Niccolai

   Last modified because:

*/

/**************************************************************************
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU Library General Public License as       *
*   published by the Free Software Foundation; either version 2.1 of the  *
*   License, or (at your option) any later version.                       *
***************************************************************************/

#ifndef WT_COFFEE_WIN_H
#define WT_COFFEE_WIN_H

// From MSDN, required macro to compile QueueUserAPC
#ifndef _WIN32_WINNT 
#define _WIN32_WINNT 0x0400 
#endif
#include <windows.h>

// Some versions of VC are missing this defines
#ifndef ULONG_PTR
	typedef unsigned long ULONG_PTR;
#endif

#ifndef INVALID_SET_FILE_POINTER
	#define INVALID_SET_FILE_POINTER ((DWORD)-1) 
#endif

#ifdef _MSC_VER
	#pragma warning ( disable:4355 )
#endif


#include <wefts_coffee_base.h>
#include <wefts_os_windows.h>

namespace Wefts {

/** \addtogroup oscoffee
@{
*/


/** Implements COFFEE file specific extensions for MS-Windows.

This class is able to understand if the underlying system is capable to do
asynchronous file or network operations via OVERLAPPED files; this is possible
only with Windows 2000 or later, and only if the target file is not a memory-based
character file (that is, a CONSOLE).

If the asynchronous file operations are available, they are used to cleanly 
cleanup the thread in case of cancellation. If they are not available, two actions
may be taken: if cancellation is not allowed in the underlying windows specific
OSTAIL, the a blocking read is performed. If cancellation is allowed, then a 
new thread is started, and the calling thread puts itself in wait for the I/O thread
to terminate. The new thread is created with minimal resources available, and 
it hasn't any data to be cleaned.

In case of cancellation requests arriving while waiting for I/O thread to terminate,
the target thread is canceled with TerminateThread(). This is sayed to be an unsafe
method (From MSDN), but chances are for the system not allocating resources to be
cleaned; this means that this cancellation scheme \e should be safe, but since internal
documentation of ReadFile or WriteFile functions is not available, we cannot be
certain.

Anyhow, whenever possible (i.e. whenever it is demonstrable that the I/O call may
return data or error in a reasonable time), turn off cancellation BEFORE calling
entering read or write methods.

Instead of instantiating OSFileFuncWin, use the typedef OSFileFunc, that is turned
into the correct class depending on the host system.

\see \ref howto_oscoffee

*/

class OSFileFuncWin : public OSFileFuncBase
{
protected:
   /* Unix file descriptor to the open field */
   HANDLE m_handle;
   HANDLE m_evtComplete;
   
   LARGE_INTEGER m_liSize;
   LARGE_INTEGER m_liPos;
   
   file_size_t internal_rw( void *buffer, const file_size_t len, bool rw, bool bFile );
   bool m_bOvlFiles;

public:
   OSFileFuncWin( void *descriptor = 0 );

   ~OSFileFuncWin() { CloseHandle( m_evtComplete ); }
   
   virtual CffStatus open(
      std::string filespec,             // the file name
      OpenMode openMode = OM_RO,        // open mode
      LockMode lockMode = LM_SHARED   // the file lock mode
      );

   virtual CffStatus create(
      std::string filespec,               // the file name
      CreateMode cMode = CM_ARCHIVE,            // system atrribute
      LockMode lockMode = LM_EXCLUSIVE  // the file lock mode
      );


   /** To get the descriptor, pass a pointer to an integer where
      the descriptor will be placed.
   */
   inline virtual void getDescriptor( void *data ) const
   {
      *static_cast<HANDLE *>(data) = m_handle;
   }

   /** To set the descriptor, pass a pointer to the integer.
   */
   inline virtual void setDescriptor( void *data )
   {
      m_handle = *static_cast<HANDLE *>(data);
   }

   virtual file_size_t read( void *buffer, const file_size_t len ) {
      return OSFileFuncWin::internal_rw( buffer, len, true, true );
   }

   virtual file_size_t write( void *buffer, const file_size_t len )
   {
      return OSFileFuncWin::internal_rw( buffer, len, false, true );
   }
   
   virtual file_size_t seek(
      const file_size_t position,
      const SeekWhence swFrom= SW_FROM_BEGIN
      );
   
   virtual CffStatus close();

   /** Use STDIN as the handle of this FileFunc object */
   inline virtual void setStdIn() { 
      m_handle = GetStdHandle( STD_INPUT_HANDLE ); 
      // Consoles are unoverlayable also in XP
      if ( GetFileType( m_handle ) == FILE_TYPE_CHAR )
         m_bOvlFiles = false;
   }
      
   /** Use STDOUT as the handle of this FileFunc object */
   inline virtual void setStdOut(){ 
      m_handle = GetStdHandle( STD_OUTPUT_HANDLE ); 
     // Consoles are unoverlayable also in XP
      if ( GetFileType( m_handle ) == FILE_TYPE_CHAR )
         m_bOvlFiles = false;
   }

   /** Use STDERR as the handle of this FileFunc object */
   inline virtual void setStdErr(){ 
      m_handle = GetStdHandle( STD_ERROR_HANDLE );
      // Consoles are unoverlayable also in XP
      if ( GetFileType( m_handle ) == FILE_TYPE_CHAR )
         m_bOvlFiles = false;
   }
};

/** Definition that hooks COFFEE in your application. */
typedef OSFileFuncWin OSFileFunc;

/*@}*/
} // namespace

#endif

/* end of wefts_coffee_unix.h */
