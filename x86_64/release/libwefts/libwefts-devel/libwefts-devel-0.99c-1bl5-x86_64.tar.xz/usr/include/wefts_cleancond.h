/*
   wefts_cleancond.h
   Standard cleanup for conditions.

   $Id: wefts_cleancond.h,v 1.2 2004/03/28 21:45:40 jonnymind Exp $
---------------------------------------------
   Begin      : Mon, 08 Mar 2004 17:48:42 +0100
   Author     : Giancarlo Niccolai

   Last modified because:

*/

/**************************************************************************
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU Library General Public License as       *
*   published by the Free Software Foundation; either version 2.1 of the  *
*   License, or (at your option) any later version.                       *
***************************************************************************/

#ifndef WT_CLEANCOND_H
#define WT_CLEANCOND_H
#include <wefts_cleanup.h>
#include <wefts_cond.h>

namespace Wefts {

/** Basic condition cleanup.
   This simple class is used to simplify cleanup needs of basic conditions.
   If a condition wait is interrupted by a cancellation request, the mutex
   associated with the condition is acquired before the thread is canceled.
   A cleanup action must be taken in order to release it.
   
   This class is provided to prevent application programmers to write
   repetitive extra-simple cleanup routine just in case there's no other
   thing to do except release the mutex in case of condition wait
   cancellation.
   
\see \ref howto_cleanup
*/

class CondCleanup: public CleanupHandler
{
public:
   /** Constructior; does effectively nothing. */
   CondCleanup() {}
   
   /** Cleanup handler for simple condition waits.
      This method just releases the mutex of the condition passed in the
      caller parameter.
      This will work only on Condition classes and derived.
      \param code ignored
      \param caller FastCond item (or subclass) to be unlocked.
   */
   virtual void handleCleanup( int code, void *caller=0 );
};

extern CondCleanup BasicConditionCleanup;

}

#endif
/* end of wefts_cleancond.h */
