/*
   wefts_fastcond.h
   Fast mutex + condition structure wrapper.

   $Id: wefts_fastcond.h,v 1.5 2003/08/16 13:23:58 jonnymind Exp $
----------------------------------------------
   Begin      : 2003-08-02 00:10
   Author     : Giancarlo Niccolai

   Last modified because:

*/

/**************************************************************************
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU Library General Public License as       *
*   published by the Free Software Foundation; either version 2.1 of the  *
*   License, or (at your option) any later version.                       *
***************************************************************************/

#ifndef WT_FASTCOND_H
#define WT_FASTCOND_H

#include <wefts_cond.h>


namespace Wefts {
/** Fast mutex + condition structure wrapper.

   \ingroup conditions

   All condition classes are implemented via inline calls to maximize execution
   speed; also, their metods are extremely small.
*/
class FastCondition: public Condition, public Mutex
{
public:
   /** Initializes the internal data of the condition */
   FastCondition(): Condition( this ), Mutex() {}
};

}

#endif
/* end of wefts_fastcond.h */
