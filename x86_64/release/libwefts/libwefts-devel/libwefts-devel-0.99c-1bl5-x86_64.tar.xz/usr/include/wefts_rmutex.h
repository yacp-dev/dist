/*
   wefts_rmutex.h
   Reentrant Mutex object header file.

   $Id: wefts_rmutex.h,v 1.8 2004/03/28 21:45:40 jonnymind Exp $
----------------------------------------------
   Begin      : 2003-08-02 20:58
   Author     : Giancarlo Niccolai

   Last modified because:

*/

/**************************************************************************
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU Library General Public License as       *
*   published by the Free Software Foundation; either version 2.1 of the  *
*   License, or (at your option) any later version.                       *
***************************************************************************/

#ifndef WT_RMUTEX_H
#define WT_RMUTEX_H

#include <wefts_mutex.h>

namespace Wefts {

/** This is a reentrant mutex with spinlock.

   \ingroup mutexes
   
   This mutex ensures that a calling thread can lock and unlock the mutex
   an equal amount of times without being blocked. This allows to wrap
   functions that are doing a lock on a mutex around outer functions that
   must extend the lock in a wider area, or use the mutex in a recursive
   function.

   \note All mutex classes are implemented via inline calls to maximize execution
   speed; also, their methods are extremely small.
*/
class RMutex: public Mutex {
private:
   OSThread m_owner;
   volatile int m_lockCount;

public:
   /** Initializes the internal data of the mutex */
   RMutex(): Mutex() { m_lockCount = 0;}

   /** Locks the mutex.
      If the calling thread is already owning the lock, the function
      will return immediately. Anyhow, it is necessary to call the
      unlock() metod exactly the same amount of times that lock() has
      been called to ensure proper mutex releasing.
   */
   virtual inline void lock()
   {
      if ( m_owner.same() ) m_lockCount++;
      else {
         Mutex::lock();
         m_owner.setCurrent();
         m_lockCount = 1;
      }
   }
   
   /** Tries to lock the mutex.
      Tries to lock the mutex, and immediately returns.
      
      If the mutex is free, the method locks it and returns true. If the mutex is 
      locked by another thread, the method returns false.
      
      If the mutex is already held by the current thread, the mutex lock count is rise,
      and the method returns true.
      
      \return true if successful false if unsuccessful.
   */
   virtual inline bool trylock() 
   {
      if ( m_owner.same() ) {
         m_lockCount++;
         return true;
      }
      else {
         if ( Mutex::trylock() ) {
            m_owner.setCurrent();
            m_lockCount = 1;
            return true;
         }
      }
      return false;
   }

   /** Unlocks the mutex.
      Releases the lock held by the calling thread. If the calling thread
      is not the rightful owner of the lock, the request is ignored and
      the call returns immediately.
   */
   virtual inline void unlock()
   {
      if ( m_owner.same() ) {
         m_lockCount--;
         if ( ! m_lockCount ) {
            m_owner.invalidate();
            Mutex::unlock();
         }
      }
   }
};

}
#endif
/* end of wefts_rmutex.h */
