/*
   wefts_coffee_base.h
   Abstract base class for cooperative file functions enlarged environment

   $Id: wefts_coffee_base.h,v 1.6 2004/04/01 04:30:17 jonnymind Exp $
---------------------------------------------
   Begin      : 2003-08-15 16:30
   Author     : Giancarlo Niccolai

   Last modified because:

*/

/**************************************************************************
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU Library General Public License as       *
*   published by the Free Software Foundation; either version 2.1 of the  *
*   License, or (at your option) any later version.                       *
***************************************************************************/


#ifndef WT_COFFEE_BASE_H
#define WT_COFFEE_BASE_H

#include <wefts_cleanup.h>
#include <string>

/** \file
   Abstract base class for cooperative file functions enlarged environment;
   to be overloaded by OS dependent implementations.

   This file contains a set of definitions and abstract base class that must
   be implemented by specific OS layers.
   At a first look, it may seem superfluous, as it would be enough to include
   the correct header for the given implementation, but this file is here
   for two reasons: first of all, to document the layer only once, so to
   have a main reference guide, and secondly to provide a template that forces
   OS layer implementors to respect Wefts base COFFEE.

   See \ref oscoffee for a description, and \ref howto_oscoffee for usage.
*/

namespace Wefts {

/** \addtogroup oscoffee
@{
*/

/** The longest integer available on the platform */
#if defined(_MSC_VER) || defined(__BORLANDC__) 
typedef unsigned __int64 file_size_t;
#else
typedef long long file_size_t;
#endif

/** Basic locking schemes used by various systems at open time. */
typedef enum {
   /* The file should not be locked */
   LM_SHARED,
   /* The file should not be locked against writes, but read may occur */
   LM_SHARED_RO,
   /* The file should not be locked against both reads & writes */
   LM_EXCLUSIVE,
} LockMode;


/** Basic open modes used by various systems. */
typedef enum {
   /** To open the file in read-only mode */
   OM_RO,
   /** To open the file in write-only mode */
   OM_WO,
   /** To open the file in read-write mode */
   OM_RW,
   /** To open the file in write-only mode.
      The file is truncated it at beginning if it is not empty.
      A file open with this flag should not be read nor seeked;
      the unterlying system may or may not support it. */
   OM_TRUNC_WO,
   /** To open the file in read-write mode.
      The file is truncated it at beginning if it is not empty.
      A file open with this flag should not be read nor seeked;
      the unterlying system may or may not support it. */
   OM_TRUNC_RW,
   /** To open for write-only and position the file pointer at bottom. */
   OM_APPEND_WO,
   /** To open for read-write and position the file pointer at bottom. */
   OM_APPEND_RW
} OpenMode;

/** Creation modes.
   This creation modes are meant to be as portable as possible, and to
   be just an "indication" for the underlying OS operation on how to
   create a file. Applications that need a greater control over file
   creation attribute, and that not need to coordinate file creation
   with Wefts++, may create the file and then pass the descriptor to
   the OSFileFunc class they wish to use. Refer to the os-specific
   OSFileFunc documentation to know what kind of OS-Level file descriptor
   are accepted.

   Also, refer to os-specific implementation documentation to know how
   this reuqest are interpreted and passed to the underlying system.

   \note Also if the creation modes mimics the names of known filesystem
   attributes, they do not necessarily map directly to the attribute they
   refer to; also they cannot be mixed with an bitwise OR operator.
*/

typedef enum {
   /** Create as a standard archive */
   CM_ARCHIVE,
   /** Create as system-relevant file */
   CM_SYSTEM,
   /** Create a file meant to be executed.
      Implementations will behave so that OM_SYSTEM is considered a
      subset of OM_EXECUTABLE capabilites given to the file. That is,
      a file created with OM_EXECUTABLE should have all the characteristics
      of a OM_SYSTEM file, where applicable.
   */
   CM_EXECUTABLE,
   /** Creates a file meant to be used only by the creator. */
   CM_PRIVATE,
   /** Creates a file meant to be used or executed only by the creator. */
   CM_PRIVATE_EX
} CreateMode;


/** Cooperative File Functions Status.

   Cooperative file functions retunrs this os-independent high level
   status code to inform the caller about the status of the operation,
   and give the caller the ability to take corrective actions indipendently
   from operating system error codes.

   Theoretically, this would leave operating system error codes only to be
   used for logging/reporting to use reasons, but if the application still
   needs to know why the underlying system reported a failure, the OS
   specific error can be accessed with i.e. OSFileFuncBase::OSerrorCode();
   it can be directly used if the application is not meant to be portable,
   or it's meaning can be decoded in #ifthef OS_TYPE sections, or by
   subclasses implementing this semantic.
*/
typedef enum {
   /** Operation completed. */
   CFF_DONE,
   /** Operation cannot be completed immediately...
      ...but up to date everything is fine. */
   CFF_WAITING,
   /** Timed out.
      There is no phisical error (up to date), but a requested timeout
      has expired.

      As CffStatus is an ordered enum, CFF_WAITING acts as a separator
      between errors and success (also partial) reports; every CffStatus
      greater than CFF_WAITING is an error, while any status equal
      or below CFF_WAITING is a success (or partial success).
      */
   CFF_TIMEDOUT,

   /** Soft error.
      There is an error that is catalogued as "soft": usually,
      this means that operation
      failed temporarily (i.e. failed to acquire an exclusive lock on
      an existing file). */
   CFF_SOFTERROR,

   /** Hard error.
      There is an error that is catalogued as "hard": the operation
      failed hopelessy. */
   CFF_HARDERROR,

   /** Program's error.
      The program is misbehaving, i.e. passing invalid parameters, or
      invalid file names, or any other thing that should have not happened.

      Usually, this should rise an exception, but we don't as the
      error may be caused with the cooperation of the user. In example,
      if the user enters a \e unexisting filename that the program tires to
      open, the error returned will be CFF_HARDERROR, but if she enters an
      \e invalid filename, the error will be CFF_PROGERROR. Anyhow,
      the program may use this information to feedback the user, so it
      is not advisable to break the program flow with an exception.

      Subclasses of the OS specific COFFEE implementation may rise an
      exception instead of returning this error in some situation, if
      they wants to.
      */
   CFF_PROGERROR
}CffStatus;

/** Position indicators for file seeks. */
typedef enum {
   /** Seek from beginning of file */
   SW_FROM_BEGIN=0,
   /** Seek from current position of file */
   SW_FROM_CUR=1,
   /** Seek from current position of file (synonim of SW_FROM_CUR) */
   SW_FROM_CURENT=1,
   /** Seek from end of file */
   SW_FROM_END=2
} SeekWhence;

/** Abstracts an OS specific file fucntion set.

   This class provides basic cooperative file access; cooperative file
   access means that the os specific implementation will have to take
   care of messages that wefts sends to them to i.e. interrupt operations
   and eventually terminate calling thread, doing a cleanup function.

   The class implementations must be made so that their data is fungible
   also to standard non-cooperative functions that are present in the
   system.

   This class and subclasses methods are not required to be locked.
   Underlying OS operations are generally thread safe, and this would make
   locking of this class methods generally an overkill; the risk of
   concurrent access to the method of this class must be minimized with
   correct programming techniques (i.e. accessing to an object only
   within a thread) or with outher mutex encapsulation (i.e. deriving
   a class both from this one and from a mutex of some kind).

   \see \ref howto_oscoffee
*/

class OSFileFuncBase {
protected:
   /** Initializes the internal data of the FileFunction.
      This constructor forces subclassess to accept an OS
      dependant descriptor that may be open with other
      functions outside the OS-COFFEE model. Refer to specific
      OS-COFFEE implementation to know what kind of descriptor
      they can accept.

      Accepting the descriptor is done via acall to the
      setDescriptior() pure virtual method.
   */
   OSFileFuncBase() {
      m_timeout = -1.0;
      m_osError = 0;
      m_status = CFF_DONE;
   }

   double m_timeout;
   CffStatus m_status;
   int m_osError;

public:
   /** Creates a file.
      The file may be opened with a locking sckeme, if the underlying
      provides it, and may be triggered with a given timeout.

      The open-lock parameter is provided because some systems may not
      allow to lock the file after the open step (the lock politic must
      be chosen at open time). The timeout is provided because the file
      may be located on a network disk, or a COFFEE implementation may
      use a network protocol as underlying layer. It is theoretically
      possible to provide a COFFEE for FTP.

      Anyhow, a reasonable timeout may also protect against program
      deadlocks due to local filesystem failure on systems that do
      not provide a prompt error diagniostic.

      File can be opened for reading, for writing, can be open
      truncated or in append mode (see OpenMode). Text-to-binary
      translation is not provided: data is read as is on all systems.

      By default, the timeout is not set; to set a given timeout,
      use the setTimeout() method.

      \note Please note that you can use OS system dependant routine
      to open the file descriptor, and then setup the

      @param filespec the file name
      @param openMode the file open mode
      @param lockMode wether the file may be accessed by other processes
         willing to open it or not.
      \return a Cff Status indicating success or failure (see CffStatus)
   */

   virtual inline CffStatus open(
      std::string filespec,             // the file name
      OpenMode openMode = OM_RO,        // open mode
      LockMode lockMode = LM_SHARED   // the file lock mode
      ) = 0;

   /** Creates the file.

      The create-lock parameter is provided because some systems may not
      allow to lock the file after the create step (the lock politic must
      be chosen at open time). The timeout is provided because the file
      may be located on a network disk, or a COFFEE implementation may
      use a network protocol as underlying layer. It is theoretically
      possible to provide a COFFEE for FTP.

      Anyhow, a reasonable timeout may also protect against program
      deadlocks due to local filesystem failure on systems that do
      not provide a prompt error diagniostic.

      File is always created with read-write access from the creator,
      and it can be locked against concurrent access from other
      processes.

      By default, the timeout is not set; to set a given timeout,
      use the setTimeout() method.

      \note Please note that you can use OS system dependant routine
      to open the file descriptor, and then setup the

      @param filespec the file name
      @param cMode the file open mode
      @param lockMode wether the file may be accessed by other processes
         willing to open it or not.
      \return a Cff Status indicating success or failure (see CffStatus)
   */
   virtual inline CffStatus create(
      std::string filespec,               // the file name
      CreateMode cMode = CM_ARCHIVE,      // system atrribute
      LockMode lockMode = LM_EXCLUSIVE  // the file lock mode
      ) = 0;

   /** Get the descriptor OS value.
      This function can be hooked by OS specific implementation to
      copy the descriptor value in the address passed as parameter.

      This allows to extract the handle, descriptor or structure of
      that represents the file from this class and use non-cooperative
      functions (or os-level function that provide native cooperation
      with the OSTAIL).
      \param data a pointer to the memory area that will receive the OS native
             file descriptor.
      \see oslevel
   */
   inline virtual void getDescriptor( void *data ) const = 0;

   /** Set the descriptor OS value.
      This function can be hooked by OS specific implementation to
      copy the descriptor value from the address passed as parameter.

      The implementations must just discard the previous value of the
      internal descriptor, and applications must take care to retreive
      it before destriong it with getDescriptor and correctly dispose
      it following the OS requirements.

      \param data a pointer to the memory area that will receive the OS native
             file descriptor.
   */
   inline virtual void setDescriptor( void *data ) = 0;


   /** Get the status returned by the last operation. */
   inline CffStatus status() const { return m_status; }

   /** Set the internal status.
      Generally, applications should not use this.
      @param st the new status 
   */
   inline void status(const CffStatus st ) { m_status = st ; }

   /** Get OS dependant error code caused by the last operation.
      Implementations must \b not use shorthands as returing directly
      the OS error, as it may have changed before the thread has a
      chance to call this function. Even if the OS error is thread
      specific at OS level, the thread may do other operations before
      calling this function, or it mai send this object to another thread
      that is responsible to retreive the error that has been found.
   */
   inline int osError() const { return m_osError; }

   /** Set the OS dependant error.
      Generally, applications should not use this.
   */
   inline void osError( const int osError ) { m_osError = osError; }


   /** Get the standard operation timeout. */
   inline double timeout() const { return m_timeout; }

   /** Set the standard operation timeout.
      Timeout can be also set to 0.0 (never block) or less than zero
      (block forever).

      Methods clearTimeout() and dontBlock() are inline provided for
      candy grammar.
      
      @param to the timeout in seconds (with fractional part 
         as fraction of seconds).
   */
   inline void timeout( const double to ) { m_timeout = to; }

   /* Clears the timeout.
     All the operations on this class will be blocking.
   */
   inline void clearTimeout() { timeout( -1.0 ); }

   /* Set all operations on this class to be non-blocking.
     Functions will return immediately if the operation cannot be
     compelted without any wait.
   */
   inline void dontBlock() { timeout( 0.0 ); }

   /** Read data from the underlying file.
      Application should not rely on osError() if the function retunrs
      a vaild number.

      file_size_t is the longest integer type provided by the
      platform.

      \param buffer memory area where to load the data
      \param len amount of byte to be read on the memory data
      \return the amount of byte read from the file, 0 on end of file
         and -1 on error. On error status() and osError() will return
         proper values.
   */
   virtual file_size_t read( void *buffer, const file_size_t len ) = 0;

   /** Write data to the underlying file.
   
      Application should not rely on osError() if the function retunrs
      a vaild number.

      file_size_t is the longest integer type provided by the
      platform.

      \param buffer memory area where from which to write
      \param len amount of byte to be written from the memory data
      \return the amount of bytes written to the file, 0 if the
         timeout has elapsed and -1 on error.
         On error status() and osError() will return proper values.
   */
   virtual file_size_t write( void *buffer, const file_size_t len ) = 0;

   /** Change the position in the file.
      Must return current position after change, so that
      seek( 0, SW_FROM_END ) return the current file length
      (that is one past last byte).

      \return current position after seek or -1 on error
   */
   virtual file_size_t seek(
      const file_size_t position,
      const SeekWhence swFrom= SW_FROM_BEGIN
      ) = 0;

   /** Closes a file. */
   virtual CffStatus close()=0;

   /** Set this file to stdin.
      This method is to be overloaded by subclasses so that following operations
      on this OSFileFunc are applied to the standard input file.
   */ 
   inline virtual void setStdIn() = 0;
   
   /** Set this file to stdout.
      This method is to be overloaded by subclasses so that following operations
      on this OSFileFunc are applied to the standard output file.
   */ 
   inline virtual void setStdOut() = 0;
   
   /** Set this file to stderr.
      This method is to be overloaded by subclasses so that following operations
      on this OSFileFunc are applied to the standard error file.
   */ 
   inline virtual void setStdErr() = 0;

};

/** Representation of subprocesses on the platform.
   This class encapsulates threadsafe subprocess handling on the current platform.
   It provides support to spawn a child of the process, access its stdin, stdout and
   stderr file handle, test it's status and eventually
   wait for its termination.
   
   The encapsulation is made so that the child process can be referenced to the thread
   that spawned it; if the father thread is cancelled, so the child process is cancelled too. 
   
   For this
   reason, the subprocess should be handled only by the calling thread, but it's possible
   for threads to exchange ownership among them with the takeOwnership() method. This
   removes the cancellation cleanup routine from the previous thread and adds it to the
   one that called takeOwnership.
   
   \note This class is designed to work in tight cooperation with the Thread class; using
   it outside a Thread::run() started with Thread::start(), or any method called from that,
   has undefined results. Of course, also derived class and non-method functions called by
   Thread::run() can use OSProcessBase class.
   
*/
class OSProcessBase: public CleanupHandler
{
private:
   void internal_init()
   {
      m_started = false;
      m_ended = false;
      m_mergeStdErr = false;
      m_retval = -1;
      m_osError = 0;
      m_detached = false;
   }

protected:
   /** Search for the child process to be spawned in the path. */
   int m_osError;
   bool m_started;
   bool m_ended;
   bool m_mergeStdErr;
   int m_retval;
   bool m_detached;
   /** Initializes the process object.*/
   OSProcessBase()
      :CleanupHandler()
   {
      internal_init();
   }
   
public:
   
   /** Return true if the child process is currently running. 
      False is returned both if the process is not yet started or is already terminated.
   */
   virtual bool running()=0;
   
   /** Wait for the process to finish.
      This is a cancellation point; if the thread is cancelled while waiting in this function,
      the subprocess is destroyed. Disable cancellation before entering if you don't want this
      behavior.
      In example, a thread run() code slice where the cancellation of subprocess on thread 
      cancllation is not wanted may look like this:
      \code
         while( proc.running() )
         {
            Sleep( 1.0 );
            disableCancel();
            proc.wait(0);
            enableCancel();
         }
      \code
      In this way, the thread may still be cancelled but the child process will survive.
      
      When the function returns true, the application can check for getProcessValue;
      
      \param seconds maximum wait time; if 0 doesn't wait, if < 0 it waits forever.
      \return false on error or if timedout, true on success.
   */
   virtual bool wait( const double seconds=-1.0 )=0;
   
   /** Starts the subprocess.
      If an error occurs, the method returns false and osError() method can be
      used to determine what happend.
      
      The calling thread may also chose to 
      
      \param process The process name, including command line parameters.
      \param useShell set to true to start the process using the shell interface.
      \param usePath if true (default) searches the process in the PATH environment.
      \return true if the process is started, false on error
   */
   virtual bool start( const std::string process, bool useShell=false, bool usePath=true )=0;
   
   /** Stop the subprocess.
      If running, the subprocess is terminated; if not running this function returns false.
      This function is not a cancellation point.
      \return true if the process is stopped, false on error (most likely the process cannot be started).
   */
   virtual bool stop()=0;
   
   /** Get the return value of the process.
      \param retvalue an integer where to store the return value of the process.
      \return true if a process value is available ( process terminated ), false otherwise.�
   */
   virtual bool getProcessValue( int &retvalue ) const=0;
   
   /** Return system dependend error occured on last operation. */
   int osError() const { return m_osError; }

   /** Return OS dependent process id.
      This function can be called to retreive the system id and do system specific operations on that;
      i.e. UNIX systems supports signals, while Windows systems supports process accounting informations
      (different ones based on Windows version). If some of this advanced features are needed by the 
      application, it can use this method to retreive the low level process ID and work directly on that.
      
      Of course, doing this unsafely (i.e. calling directly waitpid) will strip the application from
      the ability to use Wefts Independence layers (that means, do this at your own risk).
      
      This function will return an impossible id if the process is not opened or is already closed
      (-1).
      
      \note As this function is meant to be system-dependant you can safely cast the returned value to 
            some systemwise ID type, i.e. ULONG or pid_t.
      
      \return system process ID or -1.
   */
   virtual file_size_t getProcessId() const =0;   
   
   /** Write to child standard input. 
      This is a cancellation point; if the thread is cancelled in this call, the child is killed too.
      A timeout in seconds may also be given.
      On error, osError() will return the OS dependent error value.
      \return amount if bytes written, -1 on error.
      \param data the data do send
      \param size the amount of data to send
      \seconds timeout before function return; 0 doesn't wait, < 0 returns immediately.
   */
   virtual int write( const void *data, const int size, const double seconds=-1.0 )=0;
   
   /** Read from child standard output.
      This is a cancellation point; if the thread is cancelled in this call, the child is killed too.
      
      \note the output stream and the error stream may be merged with mergeStdErr() method. 
         This may be useful for those applications that are not willing to wait differently
         from the two streams.
         
      A timeout in seconds may also be given.
      On error, osError() will return the OS dependent error value.
      \param data the data do send
      \param size the amount of data to send
      \seconds timeout before function return; 0 doesn't wait, < 0 returns immediately.
      \return amount if bytes written, -1 on error.
   */
   virtual int read( void *data, const int size, const double seconds=-1.0 )=0;
   
   /** Read from child standard error.
      This is a cancellation point; if the thread is cancelled in this call, the child is killed too.
      
      Remember that if the child writes on standard error, the father MUST periodically read it,
      or the child writes will block it waiting for father to read.
      
      \note the output stream and the error stream may be merged with mergeStdErr() method. 
         This may be useful for those applications that are not willing to wait differently
         from the two streams.
         
      A timeout in seconds may also be given.
      On error, osError() will return the OS dependent error value.
      \param data the data do send
      \param size the amount of data to send
      \seconds timeout before function return; 0 doesn't wait, < 0 returns immediately.
      \return amount if bytes written, -1 on error.
   */
   virtual int readStdErr( void *data, const int size, const double seconds=-1.0 )=0;
   
   /** Merge data incoming from Standard Output and Standard error child process streams.
      Sometimes it is desiderable to have both the error stream and the standard output stream readable
      in only one call. After calling this method, read() will return both data coming from stdout and
      stderr of the child process, while readStdErr() will always return -1 (without setting osError).
      
      The method can be called both before and after the child process is started.
   */
   virtual void mergeStdErr()=0;
   
   /** Detaches the process.
      Instead of listening for the sub process to terminate, the thread may detach it. If it does so,
      the child process is not tied anymore to the calling thread; on child termination, its system
      resources are cleaned (a low-level thread is started and puts itself in wait for the child).
      If the calling process terminates, the child process continues it execution, but if the
      parent is killed, the child may or may not remain active, depending on the OS implementation.
      
   */
   virtual void detach()=0;
   
   /** Tells that this process object won't read standard input.
      For this reason, child standard input must be ignored.
   */
   virtual void sinkInput() = 0;
   /** Tells that this process object won't read standard input.
      For this reason, child standard output must be ignored.
   */
   virtual void sinkOutput() = 0;
   /** Tells that this process object won't read standard input.
      For this reason, child standard error must be ignored.
   */
   virtual void sinkError() = 0;

   virtual bool closeRead()=0;
   virtual bool closeWrite()=0;
   virtual bool closeStdErr()=0;
   
   virtual void handleCleanup( int code, void *caller=0 ) = 0;
};

/*@}*/
} // namespace

#endif

/* end of wefts_coffee_base.h */
