/*
   wefts_sleep.h
   Utility function to delay the threads

   $Id: wefts_sleep.h,v 1.4 2003/12/14 09:07:55 jonnymind Exp $
---------------------------------------------
   Begin      : 2003-08-03 03:56
   Author     : Giancarlo Niccolai

   Last modified because:

*/

/**************************************************************************
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU Library General Public License as       *
*   published by the Free Software Foundation; either version 2.1 of the  *
*   License, or (at your option) any later version.                       *
***************************************************************************/

#ifndef WT_SLEEP_H
#define WT_SLEEP_H

namespace Wefts {

/** Sleeps a certain amount of time.

   \ingroup utilities

   Sleeps for a given amount of seconds (that may be also 0), and of nanoseconds
   (up to 999,999,999, almost one second).
   The process calling this function will be awaken as soon as possible as the
   time is elapsed; this could also result in a noticeable delay.
   Also, it is possible that the process is awaken before the wait is elapsed;
   this may happen if a signal is issued to the process that is currently helding
   waiting threads.

   @param seconds the wait time in whole seconds (may be 0)
   @param nanoseconds wait time in nanoseconds ( up to one second).
   @return true if wait has elapsed without interruption, false otherwise.
*/
inline bool Sleep( long seconds, long nanoseconds )
{
   return OSSleep( seconds, nanoseconds );
}

/** Sleeps a certain amount of time.

   \ingroup utilities

   Sleeps for a given amount of seconds (1.0 meaning one second, 0.5 half second
   and so on).
   The process calling this function will be awaken as soon as possible as the
   time is elapsed; this could also result in a noticeable delay.
   Also, it is possible that the process is awaken before the wait is elapsed;
   this may happen if a signal is issued to the process that is currently helding
   waiting threads.

   \note Even if you use the command <b>using namespace Wefts</b>, this function
      won't clash with MS-Windows API Sleep(), as their prototype are different.
      Just remember that if you want to invoke Wefts::Sleep(), you have
      to use double parameter, that is dotted numbers as 1.0, never 1.


   @param seconds the wait time in seconds and second fractions.
   @return true if wait has elapsed without interruption, false otherwise.
*/
inline bool Sleep( double seconds )
{
   return Sleep( long( seconds ),
      long( (seconds - long(seconds)) *1000000000l) );
}

}

#endif
/* end of wefts_sleep.h */
