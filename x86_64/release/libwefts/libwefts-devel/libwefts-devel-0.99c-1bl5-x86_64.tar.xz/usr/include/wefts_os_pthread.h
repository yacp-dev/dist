/*
   wefts_os_pthread.h
   Includes all the system dependant libraries for unix.

   $Id: wefts_os_pthread.h,v 1.15 2004/03/28 21:45:40 jonnymind Exp $
---------------------------------------------
   Begin      : 2003-08-03 17:50
   Author     : Giancarlo Niccolai

   Last modified because:
   Implementing two-conditions read-write mutexes

*/

/**************************************************************************
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU Library General Public License as       *
*   published by the Free Software Foundation; either version 2.1 of the  *
*   License, or (at your option) any later version.                       *
***************************************************************************/


#ifndef WT_OS_PTHREAD_H
#define WT_OS_PTHREAD_H

#include <wefts_cleanup.h>
#include <wefts_os_base.h>
#include <wefts_error.h>

#ifdef __extern_c
extern "C" {
#endif

#include <pthread.h>
#include <sys/time.h>

#ifdef __extern_c
}
#endif

/** \file
   Pthread implementation of OS Thread Abstraction Layer
See \ref howto_oslevel for a description.
*/

namespace Wefts {

/** \addtogroup oslevel
@{
*/

/** This function is used internally by pthread module to safely guard the
   condition on async cancellation.
*/
void wefts_pthread_cond_guard( void *param );
void wefts_pthread_cond_reset( void *param );

class OSMutexPthread: public OSMutexBase {
protected:
   pthread_mutex_t  m_mutex;

   friend class OSConditionPthread;
public:
   OSMutexPthread() throw( InitError )
      : OSMutexBase()
   {
      int res = pthread_mutex_init( &m_mutex, NULL );
      if ( res != 0 ) throw InitError( res );
   }

   ~OSMutexPthread() { pthread_mutex_destroy( &m_mutex ); }

   virtual inline void lock() { pthread_mutex_lock( &m_mutex); }

   virtual inline bool trylock() { return (pthread_mutex_trylock( &m_mutex) == 0); }

   /** Unlocks the mutex. */
   virtual inline void unlock() { pthread_mutex_unlock( &m_mutex ); }
};

/** This class implement an os-dependant condition.
   This is basically a wrapper for pthread.
*/

class OSConditionPthread: public OSConditionBase {
private:
   pthread_cond_t m_cond;

public:
   OSConditionPthread() throw( InitError )
      : OSConditionBase()
   {
      int res = pthread_cond_init( &m_cond, NULL );
      if ( res != 0 ) throw InitError( res );
   }

   ~OSConditionPthread() { pthread_cond_destroy( &m_cond ); }

   void signal() { pthread_cond_broadcast( &m_cond ); }
   void signalOne() { pthread_cond_signal( &m_cond ); }

   /** Waiting for a condition (giving off an already held mutex */
   bool wait( OSMutexBase &mtx, CleanupItem &guard ) {
      int res;
      OSMutexPthread *posmux = static_cast<OSMutexPthread *>( &mtx );
      if ( guard.handler != 0 ) {
         pthread_cleanup_push( wefts_pthread_cond_guard, &guard );
         res = (pthread_cond_wait( &m_cond, &( posmux->m_mutex ) ) == 0);
         pthread_cleanup_pop( 0 );
      }
      else
         res = (pthread_cond_wait( &m_cond, &( posmux->m_mutex ) ) == 0);
      return res;
   }

   /** Timed wait */
   bool timedWait( OSMutexBase &mtx, long seconds, long nanoseconds,
         CleanupItem &guard  ) {
      int res;
      struct timeval now;
      struct timespec timeout;
      OSMutexPthread *posmux = static_cast<OSMutexPthread *>( &mtx );

      gettimeofday(&now, NULL);
      timeout.tv_sec = now.tv_sec + seconds;
      timeout.tv_nsec = now.tv_usec * 1000 + nanoseconds;

      if ( guard.handler != 0 ) {
         pthread_cleanup_push( wefts_pthread_cond_guard, &guard );
         res = ( pthread_cond_timedwait( &m_cond, &( posmux->m_mutex ), &timeout ) == 0);
         pthread_cleanup_pop( 0 );
      }
      else
         res = ( pthread_cond_timedwait( &m_cond, &( posmux->m_mutex ), &timeout ) == 0);

      return res;
   }

};

/** Wraps Posix threads.
\see \ref howto_oslevel
*/
class OSThreadPthread: public OSThreadBase {
private:
   /** posix thread id */
   pthread_t m_thid;
   /** true if this thread is considered valid */
   bool m_valid;
   
public:
   OSThreadPthread(): OSThreadBase() { invalidate(); }
   OSThreadPthread( bool val ): OSThreadBase( val ) {  setCurrent(); }

   virtual bool priority( OSPriority prio_class, int boost = 0);
      
   bool start( void *(*func)(void *), void *data ) {
      return (pthread_create( &m_thid, 0, func, data ) == 0);
   }  

   bool stop() { return (pthread_cancel( m_thid ) == 0); }

   void *join() throw( NotJoinableError ) 
   {
      void *ret;
      int retval = pthread_join( m_thid, &ret );
      if ( retval != 0 ) throw NotJoinableError( retval );
      return ret;
   }

   int enableCancel()
   {
      int old_state;
      if ( pthread_setcancelstate( PTHREAD_CANCEL_ENABLE , &old_state ) == 0)
         return old_state;
      return -1; // currently does not matter if this is not correct.
   }

   int disableCancel() 
   {
      int old_state;
      if ( pthread_setcancelstate( PTHREAD_CANCEL_DISABLE , &old_state ) == 0)
         return old_state;
      return -1; // currently does not matter if this is not correct.
   }

   bool setCancelState( int state ) {
      return (pthread_setcancelstate( state , 0 ) == 0);
   }

   virtual inline void *osRun( void * (*runner)(void *), void *data, void (*cleaner)(void *))
   {
      // initially, set return value to 0
      ThreadAndReturn thret = { data, 0 };
      pthread_cleanup_push( cleaner, &thret );
      thret.runReturn = runner( data );
      pthread_cleanup_pop( 1 );
      return thret.runReturn;
   }


   void testCancel() { pthread_testcancel(); }
   void setCancelDeferred(){pthread_setcanceltype( PTHREAD_CANCEL_DEFERRED, 0 );}
   void detach() { pthread_detach( m_thid ); }
   void exit( void *data ) { pthread_exit( data ); }

   bool same() const {
      return (m_valid && pthread_equal( pthread_self(), m_thid ));
   }

   bool equal( const OSThreadBase &th ) const {
      const OSThreadPthread *other = static_cast<const OSThreadPthread *>( &th );
      return (m_valid && other->m_valid &&
            pthread_equal( other->m_thid, m_thid ) );
   }

   virtual bool setCurrent() { m_thid = pthread_self(); m_valid=true; return true; }

   virtual void invalidate() { m_valid = false; }
};

/** Wrapper class for pthread specific data access (tsd/tls) */
class OSSpecificDataPthread: public OSSpecificDataBase
{
private:
   pthread_key_t  m_data;

public:
   /** Prepares the internal data.
      \todo add an exception rising on failure
   */
   OSSpecificDataPthread() throw( InitError )
      :OSSpecificDataBase()
   {
      int res = pthread_key_create( &m_data, 0 );
      if ( res != 0 ) throw InitError( res );
   }

   /** Destroys the internal data.
      In a well designed application this should make no
      sense at all, but anyway we provide it.
   */
   ~OSSpecificDataPthread() { pthread_key_delete( m_data ); }

   void *data() const { return pthread_getspecific( m_data ); }

   void data(const void *dt) { pthread_setspecific( m_data, dt ); }
};

/** Function to execute the thread RUN procedure guarded by OS cleanup */


typedef OSSpecificDataPthread OSSpecificData;
typedef OSThreadPthread OSThread;
typedef OSConditionPthread OSCondition;
typedef OSMutexPthread OSMutex;

/*@}*/
} // namespace

#endif

/* end of wefts_os_pthread.h */
