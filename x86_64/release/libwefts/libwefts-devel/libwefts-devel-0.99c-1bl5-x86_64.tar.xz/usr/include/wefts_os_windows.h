/*
   wefts_os_widnows.h
   MS-Windows specific header file

   $Id: wefts_os_windows.h,v 1.15 2004/03/28 21:45:40 jonnymind Exp $
---------------------------------------
   Begin      : 2003-10-15 16.50
   Author     : Giancarlo Niccolai

   Last modified because:
   
*/

/**************************************************************************
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU Library General Public License as       *
*   published by the Free Software Foundation; either version 2.1 of the  *
*   License, or (at your option) any later version.                       *
***************************************************************************/

#ifndef WT_OS_WINDOWS_H
#define WT_OS_WINDOWS_H

/* To allow compilation of TryEnterCriticalSection */
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0400
#endif

#ifdef _MSC_VER
#pragma warning ( disable:4355 )
#endif

#include <wefts_cleanup.h>
#include <wefts_os_base.h>
#include <wefts_error.h>


#ifdef __extern_c
extern "C" {
#endif

#include <windows.h>

#ifdef __extern_c
}
#endif

/** \file
   Windows implementation of OS Thread Abstraction Layer
See \ref howto_oslevel for a description.
*/

namespace Wefts {

extern DWORD s_tlsThreadObj;

extern void (* s_cleanerPointer)(void *);

/** Windows implementation of mutex.
   Windows mutexes are currently implemented through a Windows CRITICAL_SECTION.
   For this reason, win95, win98 and winME calls to tryLock() will fail (always
   return false).
   Also, as reentracy is not requested by OSTAIL model, rentrant lock ability
   of CRITICAL_SECTION is a waste of time.
   
   \todo Use very low level Interlocked exchange to create a better mutex.
*/
class OSMutexWindows: public OSMutexBase 
{
   bool m_canTryLock;
protected:
   CRITICAL_SECTION  m_sect;

   friend class OSConditionWindows;
public:
   OSMutexWindows() throw( InitError );
   
   ~OSMutexWindows() 
   { 
      DeleteCriticalSection( &m_sect );
   }

   virtual inline void lock() { EnterCriticalSection( &m_sect ); }

   virtual inline bool trylock() { 
      if( m_canTryLock )
         return TryEnterCriticalSection( &m_sect ) == TRUE; 
      else
         return false;
   }

   /** Unlocks the mutex. */
   virtual inline void unlock() { LeaveCriticalSection( &m_sect ); }
};

#if 0
class OSMutexWindows: public OSMutexBase {
protected:
   CRITICAL_SECTION  m_sema;

   friend class OSConditionWindows;
public:
   OSMutexWindows() throw( InitError )
      : OSMutexBase()
   {
      InitializeCriticalSection(&m_sema);
      //if ( m_sema == NULL ) throw InitError( GetLastError() );
   }

   ~OSMutexWindows() 
   { 
      DeleteCriticalSection( &m_sema );
   }

   virtual inline void lock() { EnterCriticalSection( &m_sema); }

   virtual inline bool trylock() { 
      OSVERSIONINFO osVer;
      osVer.dwOSVersionInfoSize = sizeof( osVer );

      if( GetVersionEx( &osVer ) && 
            ( osVer.dwPlatformId == VER_PLATFORM_WIN32_NT || osVer.dwMajorVersion >= 5 )
         return TryEnterCriticalSection( &m_sema); 
      else
         return false;
   }

   /** Unlocks the mutex. */
   virtual inline void unlock() { LeaveCriticalSection(&m_sema); }
};
#endif

/** This class implement an os-dependant condition.
   Calls Windows dependant thread
*/

class OSConditionWindows: public OSConditionBase {
private:
   HANDLE semBlockLock;
   HANDLE semBlockQueue;
   CRITICAL_SECTION mtxUnblockLock;
   int nWaitersGone;
   int nWaitersBlocked;
   int nWaitersToUnblock;

public:
   OSConditionWindows() throw( InitError );
   ~OSConditionWindows(); 

   void signal();
   void signalOne();
   
   /** Waiting for a condition (giving off an already held mutex) */
   bool wait( OSMutexBase &mtx, CleanupItem &guard ); 

   /** Timed wait */
   bool timedWait( OSMutexBase &mtx, long seconds, long nanoseconds,
         CleanupItem &guard  );
};

/** Wraps Windows threads.
\see \ref howto_oslevel
*/
class OSThreadWindows: public OSThreadBase {
private:
   /** windows thread id */
   DWORD m_thid;
   
   /** Windows thread handle */
   HANDLE m_hth;
   
   /** true if this thread is considered valid */
   bool m_valid;

   /** cancellation control */
   HANDLE m_evtCancel;

   /** Used to reset cancel event after a section where cancellation is disabled.
       disableCancel will set this to true if the event that commands the thread
       to be canceled was set. Then if enableCancel is issued, the event is set
       again if it was set before. */
   bool m_wasCanceled;
      
   /** Kind cancellation control */ 
   bool m_canCancel;
   
   /** Pointer to thread raw cleanup function.
      This function is usually defined in wefts_thread.c and has the duty to
      call the high-level thread layer.
   */    
   void (*m_rawCleanup)(void *);
   
   /** Pointer to thread raw cleanup data.
      This pointer holds generally a pointer to a Wefts::Thread or subclass,
      and is initializated in osRun() by functions in wefts_thread.c
   */    
   void *m_rawCleanData;
   
   friend class OSConditionWindows;
   friend class OSFileFuncWin;
   friend bool OSSleep( long nSeconds, long nNanoseconds );
public:
   OSThreadWindows();
   OSThreadWindows( bool val ): OSThreadBase( val ) {  setCurrent(); }
   ~OSThreadWindows();

   /** Sets WinAPI priority level and boost.
      Windows api sets thread priority class based on a differential
      status with respect to the process standard priority. This function
      supposes that the process is started with "normal" priority schedule,
      and then it sets the priority class of threads based on this
      assumption.
      
      Wefts users should \b not change the process default priority,
      but they should use Thread::priority() instead.
      
      In the specific: prio_class is set as the base thread priority value;
      boost adds or subtracts some point from the base class. Also, boost
      is set as Windows dynamic priority boost if it's in range 1..3;
      if it's higher than 3, dynamic priority boost is set to 3.
      
      \see OSThreadBase::priority() for more details on Wefts abstract
           priority system.
      \param prio_class Wefts priority class that the thread should run in.
      \param boost extra boost with respect to abstract priority class.
      \return true on success, false on failure.
   */
   virtual bool priority( OSPriority prio_class, int boost = 0);
   
   bool start( void *(*func)(void *), void *data );
   bool stop();
   void *join() throw( NotJoinableError );
   
   /** We support only deferred emulated cancellation */
   int enableCancel();
   
   /** We support only deferred emulated cancellation */
   int disableCancel();
      
   inline bool setCancelState( int state ) 
   {
      m_canCancel = (state != 0);
      return true;
   }
   
   virtual void *osRun( void * (*func)(void *), void *data, void (*cleanup)(void *) );
   
   void testCancel();
   
   /** Always in emulated deferred mode */
   inline void setCancelDeferred() {};
   
   inline void detach() {}
   
   void exit( void *data );
   
   inline bool same() const {
      return (m_valid && m_thid == GetCurrentThreadId());
   }

   bool equal( const OSThreadBase &th ) const {
      const OSThreadWindows *other =static_cast<const OSThreadWindows *>( &th );
      return ( m_valid && other->m_valid && other->m_thid == m_thid );
   }

   virtual bool setCurrent();
   virtual void invalidate();
};

#include <stdio.h>

/** Wrapper class for thread specific data access (tsd/tls) */
class OSSpecificDataWindows: public OSSpecificDataBase
{
private:
   DWORD  m_data;

public:
   /** Prepares the internal data.
      \todo add an exception rising on failure
   */
   OSSpecificDataWindows() throw( InitError );

   /** Destroys the internal data.
      In a well designed application this should make no
      sense at all, but anyway we provide it.
   */
   ~OSSpecificDataWindows() 
   { 
      if (  m_data != TLS_OUT_OF_INDEXES )
         TlsFree( m_data ); 
   }

   void *data() const { return TlsGetValue( m_data ); }
   void data(const void *dt) { 
      void *dt1 = const_cast<void *>(dt);
      TlsSetValue( m_data, dt1); 
   }
};

typedef OSSpecificDataWindows OSSpecificData;
typedef OSThreadWindows OSThread;
typedef OSConditionWindows OSCondition;
typedef OSMutexWindows OSMutex;

} // namespace

#endif
