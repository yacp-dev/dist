/*
   wefts_rcond.h
   Reentrant mutex + condition structure wrapper.

   $Id: wefts_rcond.h,v 1.6 2004/03/28 21:45:40 jonnymind Exp $
----------------------------------------------
   Begin      : 2003-08-02 00:10
   Author     : Giancarlo Niccolai

   Last modified because:

*/

/**************************************************************************
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU Library General Public License as       *
*   published by the Free Software Foundation; either version 2.1 of the  *
*   License, or (at your option) any later version.                       *
***************************************************************************/

#ifndef WT_RCOND_H
#define WT_RCOND_H

#include <wefts_cond.h>
#include <wefts_rmutex.h>


namespace Wefts {
/** Reentrant mutex + condition structure wrapper.

   \ingroup conditions

   All condition classes are implemented via inline calls to maximize execution
   speed; also, their methods are extremely small.
*/
class RCondition: public Condition, public RMutex
{
public:
   /** Initializes the internal data of the condition */
   RCondition(): Condition( this ), RMutex() {}
};

}

#endif
/* end of wefts_rcond.h */
