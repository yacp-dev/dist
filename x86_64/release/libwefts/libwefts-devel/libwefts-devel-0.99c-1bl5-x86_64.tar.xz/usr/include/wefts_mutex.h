/*
   wefts_mutex.h
   Mutex object header file.

   $Id: wefts_mutex.h,v 1.8 2004/03/28 21:45:40 jonnymind Exp $
---------------------------------------
   Begin      : 2003-08-02 23:31
   Author     : Giancarlo Niccolai

   Last modified because:
   Implementing OS independent base threading
*/

/**************************************************************************
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU Library General Public License as       *
*   published by the Free Software Foundation; either version 2.1 of the  *
*   License, or (at your option) any later version.                       *
***************************************************************************/

#ifndef WT_MUTEX_H
#define WT_MUTEX_H

#include <wefts_os.h>

namespace Wefts {

/** Implements a very fast, non reentrant mutex.

   \ingroup mutexes
   
   This is the fastest and smallest possible mutex. To be used when
   implementing the condition/mutex raw scheme or when a very small
   section of not interruptable code is to be protected.

   All mutex classes are implemented via inline calls to maximize execution
   speed; also, their methods are extremely small.
 */

class Mutex {
protected:
   OSMutex   m_mutex;

   friend class Condition;
public:
   /** Initializes the internal data of the mutex */
   Mutex(){}

   /** Destroys the mutex.
      Only call this when the mutex is fully unlocked:
      destroying a locked mutex has undefined result. */
   ~Mutex(){}

   /** Locks the mutex.
      If the calling thread is already owning the lock, the function
      will block producing an unavoidable and not interruptable deadlock.
   */
   virtual inline void lock() { m_mutex.lock(); }

   /** Try to lock the mutex.
      If any thread is currently holding the mutex, the function returns
      immediately false, while if it is not locked, the mutex is locked
      and the function returns true.
   */
   virtual inline bool trylock() { return m_mutex.trylock(); }

   /** Unlocks the mutex.
      This method does not checks if the calling thread is the rightful
      owner of the mutex; unlocking a mutex from a thread that has not
      locked it has an undefined outcome.
      */
   virtual inline void unlock() { m_mutex.unlock(); }

};

}
#endif
/* end of wefts_mutex.h */
