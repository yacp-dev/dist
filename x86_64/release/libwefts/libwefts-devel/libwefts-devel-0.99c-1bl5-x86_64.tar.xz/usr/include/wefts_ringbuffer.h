/*
   wefts_ringbuffer.h
   Ringbuffer sync object

   $Id: wefts_ringbuffer.h,v 1.4 2004/03/28 21:45:40 jonnymind Exp $
---------------------------------------------
   Begin      : 2003-08-16 21:25
   Author     : Giancarlo Niccolai

   Last modified because:

*/

/**************************************************************************
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU Library General Public License as       *
*   published by the Free Software Foundation; either version 2.1 of the  *
*   License, or (at your option) any later version.                       *
***************************************************************************/

#ifndef WT_RINGBUFFER_H
#define WT_RINGBUFFER_H

#include <wefts_mutex.h>
#include <wefts_cond.h>
#include <wefts_cleanup.h>
#include <iostream>

namespace Wefts {

/** Ring buffer synchronization object

   \ingroup adv_sync

   A synchronized ring buffer is an object that allows safe communications
   between a set of producers (threads providing data)
   and a set of consumers (threads willing to receive the data provided).

   A ring buffer is made of a finite number of
   cells, allocated in a buffer that can be read or written from the
   first to the last element; when an element is read,
   the read-pointer is moved one step forward; when an element is written,
   a write pointer is moved forward. When one of this pointers reach the
   last element, it is moved to the first element again. The buffer is full
   if the write pointer makes a full loop and reaches the cell pointed by the
   read pointer, and is empty if the read pointer precedes the write pointer
   by one position.

   Readers and writers are continuously changing the status of the buffer,
   so that it is absolutely necessary to handle all the data relative to
   the pointer with just one mutex: a read MUST NOT HAPPEN while a write
   is done and vice-versa; also two contemporary reads or writes must be
   forbidden. But here we have two kind of threads, interested in two
   different kind of events (or predicates). If the buffer is empty,
   the readers must wait for it being filled again before to proceed,
   while if the ring is full, the writers must wait for it having some
   free position again.

   The order in which readers can access the data in the buffer is random
   and depends from the moment they are awaken by the OS.

   Ring buffers can be used in various ways. One way is just to make sure that
   data needed to be processed is sent to the available processors as fast
   as one of them is ready, and that none of the produced data is lost.

   Another typical use is to allow the "plug in" of new producers when requests
   peaks at some moment of the process, or to plug in new consumers
   if the system has a temporary abundance of CPU.

   Also, maintaining constant the number of consumers and producers, ring buffers
   acts as a cushion allowing to have consumers with very different processing
   time without blocking the throughput of requests.

   Another use is to check the performance of producers and consumers; providing
   a ringbuffer that has at least an amount of cell greater or equal to the
   double of the readers, it is possible to write algorithms that try to maintain
   the "fill" level of the ring buffer around a given percentage; in any moment,
   the amount of requests left to process is an indicator of the efficiency
   of the process, so a process having a nearly empty ring buffer may want to
   "relax" its reading rhythm, so to free more CPU for the system without loosing
   promptness in processing, while a process having a nearly filled ring buffer
   may want to speed up its operations, or slow down process acceptance.

   A ring buffer that stays filled for a too long time can be detected to
   start disaster recovery operations, to warn the administrators or the users.

   Finally, a special kind of ringbuffer, having just one cell, may be used just
   to queue several requests from different sources, and allow them to pass just
   one at a time.

   \todo variable length ringbuffers

*/

template < typename _T >
class RingBuffer: public CleanupHandler
{
private:
   Mutex m_mutex;
   Condition m_rCond;
   Condition m_wCond;

   /** The buffer */
   _T *m_buffer;

   /** The size of the buffer */
   unsigned long m_size;

   /** write pointer */
   unsigned long m_wPos;
   /** read pointer */
   unsigned long m_rPos;

   /** writers waiting */
   int m_wWaiting;
   /** readers waiting */
   int m_rWaiting;

   /** Tells if a ringbuffer is empty.
      This function is private as trying to see if a ringbuffer is
      full or empty makes sense only from within a read or write
      call (inside a locked mutex area).
   */
   bool empty() const {
      return ( m_wPos == m_rPos + 1||
         (m_size > 1 &&m_wPos == 0 && m_rPos == m_size-1) );
   }

   /** Tells if a ringbuffer is empty.
      This function is private as trying to see if a ringbuffer is
      full or empty makes sense only from within a read or write
      call (inside a locked mutex area).
   */
   bool full() const {
      return (m_wPos == m_rPos);
   }

   /** Does the raw job of putting the data into the buffer.
      Call it only once a thread knows that a write can be done,
      and while the thread is holding the mutex.
   */

   void put( _T data ) {

      bool was_empty = empty();
      if ( m_size == 1 ) {
         *m_buffer = data;
         m_wPos = 0;
      }
      else {
         m_buffer[ m_wPos ++ ] = data;
         if ( m_wPos == m_size ) m_wPos = 0;
      }

      if( was_empty && m_rWaiting != 0 )
         m_rCond.signal(); // tell the readers situation has changed.
   }


   /** Does the raw job of getting the data from the buffer.
      Call it only once a thread knows that a write can be done,
      and while the thread is holding the mutex.
   */
   _T get() {
      bool was_full = full();

      if ( m_rPos == m_size -1)
         m_rPos = 0;
      else
         m_rPos++;

      if( was_full && m_wWaiting != 0 ) {
         m_wCond.signal();
      }
      if ( m_size == 1 ) m_wPos = 1;

      return m_buffer[ m_rPos ];
   }


public:

   /** Creates the buffer.
      A size greater than zero must be given; if the size is
      so big that the required memory can't be allocated, or
      if zero is given as an argument, the constructor throws
      an InitError.
   */
   RingBuffer ( const unsigned long size ) throw( InitError )
   {
      if ( size == 0 ) throw InitError();
      m_buffer = new _T[ size ];
      if ( m_buffer == 0 ) throw InitError();

      m_size = size;

      m_wPos = 1;
      m_rPos = 0;
      m_wWaiting = 0;
      m_rWaiting = 0;

      m_wCond.setMutex( &m_mutex );
      m_rCond.setMutex( &m_mutex );
   }

   ~RingBuffer() { delete m_buffer; }

   /** Returns the allocated size of the ringbuffer */
   unsigned long size() const { return m_size; }

   /** Free elements in the buffer.
      If writers and readers are running this number normally does not make 
      sense; it is provided just to debug the code
      or to have a status when no other thread is working on this object.

      Anyhow, it makes a lot of sense if used to periodically
      check the status of the buffer, or to produce statistical data, 
      or to monitor the status of a process etc. 
      
      In other words it gets significance if used in statistical analysis
      of the buffer status, while it's punctual value is meaningless.
      \return number of free elemnts in the ring buffer.
   */
   unsigned long free() {
      unsigned long ret;

      m_mutex.lock();
      if ( m_wPos > m_rPos )
         ret = m_size -m_wPos + m_rPos + 1;
      else
         ret = m_rPos - m_wPos;
      m_mutex.unlock();

      return ret;
   }

   /** Waits until space is available in the buffer, and then writes the parameter.
      \param data the element to write in the buffer.
   */
   void write( _T data )
   {
      m_mutex.lock();

      // have we to wait?
      if( full() ) {
         m_wWaiting++;
         while ( full() ) {
            // position == 0 --> cleanup a writer
            m_wCond.wait( this, 0 );
         }
         m_wWaiting--;
      }
      put( data );

      m_mutex.unlock();
   }

   /* Waits until some data may be read and returns the read data. 
   \return The element that has been read from the buffer.
   */
   _T read()
   {
      m_mutex.lock();

      // have we to wait?
      if( empty() ) {
         m_rWaiting++;
         while ( empty() ) {
            // position == 1 --> cleanup a reader
            m_rCond.wait( this, 1 );
         }
         m_rWaiting--;
      }
      _T data = get();
      m_mutex.unlock();
      return data;
   }


   /** Tries to write the data.
      This method never waits; 
      if the data can't be written because the buffer is full, it returns false,
      else it returns true.
      \param data the data to be put in the buffer.
      \return true if data can be written.
   */
   bool tryWrite( _T data ) {
      bool ret;

      m_mutex.lock();
      if ( ! full() ) {
         put( data );
         ret = true;
      }
      else
         ret = false;
      m_mutex.unlock();

      return ret;
   }

   /** Tries to read some data from the buffer.
      This method never waits; if some data is immediately available to be pulled out
      from the buffer, the parameter value is overwritten and the method retunrs true;
      else, it returns false, and the parameter is left untouched.
      \param data a variable that will contain the read data on success.
      \return true if some data has been read from the buffer.
   */
   bool tryRead( _T &data ) {
      bool ret;

      m_mutex.lock();
      if ( ! empty() ) {
         data = get();
         ret = true;
      }
      else
         ret = false;
      m_mutex.unlock();

      return ret;
   }

   /** Cleanup for deferred cancellation. 
      Users must never call this method.
   */
   virtual void handleCleanup( int pos, void * )
   {
      if ( pos == 0 ) 
         // cleanup a writer
         m_wWaiting--;
      else
         // cleanup a reader
         m_rWaiting--;

      m_mutex.unlock();
   }
};

}
#endif

/* end wefts_ringbuffer.h */
