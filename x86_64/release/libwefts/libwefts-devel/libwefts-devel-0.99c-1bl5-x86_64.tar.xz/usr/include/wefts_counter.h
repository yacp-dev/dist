/*
   wefts_counter.h
   Shared counter.

   $Id: wefts_counter.h,v 1.4 2003/12/14 09:07:55 jonnymind Exp $
----------------------------------------------
   Begin      : 2003-08-02 00:10
   Author     : Giancarlo Niccolai

   Last modified because:

*/

/**************************************************************************
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU Library General Public License as       *
*   published by the Free Software Foundation; either version 2.1 of the  *
*   License, or (at your option) any later version.                       *
***************************************************************************/

#ifndef WT_COUNTER_H
#define WT_COUNTER_H

#include <wefts_fastcond.h>

namespace Wefts {

/** Syncrhonizable counter.
   This syncronization objects implements a mutex and a condition plus
   an integer counter. Thraeds synchronizing on this object can just test
   the value of the integer value, or lock the mutex and change it,
   or wait for the counter to have reached any value.

   This is an object that should usually created by the user, but as
   the Thread class must use a couple of synchronized counters to do
   some internal tasks, this class is then published also for final
   user availability.

   Moreover, it's internal strucuture can suggest how to implement
   similar synchronized objects as strings, structures or user
   defined classes.

   \note Counter is derived from FastCondition, this means that the
      mutex used by counter is not reentrant. It is this way as the
      mutex is thought just to lock access to very small section
      of code where the internal integer counter is updated.
*/

class Counter: public FastCondition
{
private:
   /** Internal integer counter */
   volatile int m_count;

public:
   /** Initializes the counter to a given value
      @param count the initial count of the internal counter
         (if not given defaults to 0) */
   Counter( int count = 0 ) { m_count = count; }

   /** Retunrs the current value of the counter.
      The returned value could change before the calling thread has a chance
      to use it, unless this object is locked.
   */
   int count() { return m_count; }

   /** Sets the internal counter value without locking or signaling.
      The caller must provide proper lock/signal actions.
      @param value the new value to be set.
   */
   void set( int value ) { m_count = value; }

   /** Sets the count to a given value.
      The object is not locked while the count is assigned, but it is
      signaled so waiting threads are woken up.
      @param value the new value to be set.
   */
   void count( int value ) { lock(); m_count = value; signal(); unlock();}

   /** Increments the value of the counter of the given amount.
      A signal is also broadcasted so waiting threads are notified.
      @param amount the amount to be added to the current count.
   */
   void increment( int amount ) { lock(); m_count += amount; signal(); unlock();}

   /** Increments the value of the counter of one unit.
      A signal is also broadcasted so waiting threads are notified.
   */
   void increment() { lock(); m_count ++; signal(); unlock(); }

   /** Decrements the value of the counter of one unit.
      A signal is also broadcasted so waiting threads are notified.
   */
   void decrement() { lock(); m_count --; signal(); unlock();}

   /** Wait for the counter to reach a certain value.
      @param level the value that the counter must match before continue.
      @param time seconds to wait for the condition to be reached (or 0 forever).
      @return true if condition is matched false on timeout or interrupt
   */
   bool until( int level, double time = 0 );
   
};

}

#endif
/* end of wefts_counter.h */
