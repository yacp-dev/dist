/*
   wefts_xmutex.h
   Advanced mutex

   $Id: wefts_xmutex.h,v 1.3 2004/03/28 21:45:40 jonnymind Exp $
---------------------------------------------
   Begin      : 2003-08-16 21:07
   Author     : Giancarlo Niccolai

   Last modified because:

*/

/**************************************************************************
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU Library General Public License as       *
*   published by the Free Software Foundation; either version 2.1 of the  *
*   License, or (at your option) any later version.                       *
***************************************************************************/

#ifndef WT_XMUTEX_H
#define WT_XMUTEX_H

#include <wefts_mutex.h>
#include <wefts_cond.h>
#include <wefts_cleanup.h>


namespace Wefts {

/** Advanced mutex class.

   \ingroup mutexes

   This class implements a mutex with advanced behavior, that can also be
   used as a base to build even more complex syncrhonization objects.
   Among the capabilities of this class are:

      - Recursive spin lock count
      - Test for locks
      - Timed lock blocking
      - Interruptable locks

   An XMutex can be used to try to lock and return immediately on failure,
   to try to lock for a given amount of time, and then return on
   failure, or to wait indefinitely for a lock. In this two latter cases,
   an XMutex can be stopped from another thread; by all means, XMutex::lock()
   is a valid "deferred cancellation point" (see \ref howto_cancel);
   care must be taken to 1) arrive at this point ready to be cancelled or
   2) disable cancellation before trying a lock.

   XMutex takes care that on lock method exit the mutex is either locked or
   unlocked, and that cancellation may happen only when mutex is unlocked. As
   there aren't undefined outcomes, the mutex can be considered cancellation safe.

   Anyhow, XMutex has a major drawback in efficiency; lock and unlock requests
   are relatively slow, so it must be used to synchronize time-sparse operations,
   or operations having an heavy set of instructions to be mutexed, so that the
   ovherhead of this class is transcurable.


   \todo write how a cancellable mutex can be used.
*/
class XMutex: public CleanupHandler {
private:
   Condition m_cond;
   Mutex m_mutex;
   int m_locked;
   int m_waiting;
   OSThread m_owner;

public:
   /** Initializes the mutex */
   XMutex();

   /** Lock the mutex.
      The calling thread is suspended until the lock is achived; another thread
      may stop this one cleanly, preventing it from gainig the lock.

      The lock owner can also lock the mutex more than one time, allowing this
      method to be used in recursive calls. The unlock() method must be called
      the same amount of times lock() has been called to release the mutex.
   */
   void lock();

   /** Try to lock a mutex for a given amount of seconds.
      If the timeout expires and the lock can't be achived, the thread is
      resumed and the function returns false.
   */
   bool lock( double seconds );

   /** Try to lock a mutex and returns immediately.
      On success, retruns true
   */
   bool tryLock();

   /** Unlock a mutex.
      Requests to unlock a mutex from a thread that is not owning the lock
      are ignored.
   */
   void unlock();

   /** Returns true if current thread owns the mutex */
   bool own() { return m_owner.same(); }

   /** Returns true if the mutex has been locked.
      This data may change even before the reading thread has a chance
      to test its value, so it must not be relied on; it is provided
      for debugging reasons.
   */
   bool locked() { return m_locked > 0; }

   /** Cleanup routines */
   void handleCleanup( int, void *caller = 0 );
};

}

#endif

/* end of wefts_xmutex.h  */
