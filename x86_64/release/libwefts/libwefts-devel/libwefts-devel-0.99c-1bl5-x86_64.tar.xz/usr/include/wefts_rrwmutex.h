/*
   wefts_rrwmutex.h
   Read/write Reentrant/advanced Mutex object header file.

   $Id: wefts_rrwmutex.h,v 1.10 2004/03/28 21:45:40 jonnymind Exp $
---------------------------------------------
   Begin      : 2003-08-02 20:58
   Author     : Giancarlo Niccolai

   Last modified because:

*/

/**************************************************************************
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU Library General Public License as       *
*   published by the Free Software Foundation; either version 2.1 of the  *
*   License, or (at your option) any later version.                       *
***************************************************************************/


#ifndef WT_RRWMUTEX_H
#define WT_RRWMUTEX_H

#include <wefts_rwmutex.h>
#ifndef NO_ASSERTIONS
#include <cassert>
#endif

namespace Wefts {

/** This is an advanced (and fully reentrant) read/write mutex.

   \ingroup mutexes

   Read locks can be achieved as long as only read locks have been achieved;
   write locks can be achieved only by one thread at a time, and only if no
   read locks are currently held.

   In this mutex kind, write locks are reentrant. Also, a write locker can
   require to rise a read lock fence, thus blocking any further request of new
   read lockers. This means that no new read lock will be allowed on the mutex,
   and the write locker will take ownership as soon as the last
   reader that had control over it finishes its operations.

   This mutex class inherit the read lock promotion ability of its
   ancestor. It is also possible to promote a read-lock to write-lock
   while rising the read lock fence.

   Also, this mutex lock() requests can be canceled by another thread using
   deferred cancellation schemes; RRWMutex()::lock() are cancellation points,
   and care must be taken to 1) arrive at this point ready to be canceled or
   2) disable cancellation.

   \see howto_cancel
*/

class RRWMutex: public RWMutex  {
private:
   int m_fence;
   OSThread m_owner;

public:
   /** Initializes the internal members of the mutex */
   RRWMutex(): RWMutex() {
      m_fence = 0;
   }

   /** Try to lock for reading this mutex for a certain time, or forever.

      Any amount of read locks can be achieved by the calling thread or by
      other read-locking threads. After that a read lock has been achieved,
      write lock requests will be blocked until all the read lockers have
      released their locks.

      If a write locker has risen the read fence, this function will block the
      calling thread also if the writer is WAITING to achieve the lock.

      If the time parameter is given, and if the lock can be achieved
      during the given time, the method returns true, else the method return false.

      If the parameter is 0, this method returns always true.

      This method is a cancellation point, so actions must be taken
      to prevent cancellation, or to be canceled cleanly.
      \param seconds seconds to wait for (0 = forever)
      \
      \return true if lock is achieved, false otherwise
   */
   virtual bool lockRead( double seconds=0.0 );
   
   /** Try to lock a mutex for reading and returns immediately.
      \return true if the lock is achieved, false otherwise.
   */
   virtual bool tryLockRead();

   /** Rises the fence; after this call, promote
   */

   /** Promotes a mutex to Write Lock.
      This methods works like the RWMutex::promote() provided in its ancestor,
      but it has also the ability to rise the fence, to prevent further
      readers to gain control of the mutex while this thread is waiting
      to be promoted.

      \note This mutex must be locked for reading before issuing a promote,
      or an assertion error will be risen.
      
      \param time maximum time to wait for the promotion, or 0 to wait forever.
      \param fence if true, rises the read lock fence: any call to read lock
         after this one will be blocked.
   */

   virtual bool promoteFence( double time = 0.0, bool fence=true )
            throw( InvalidError );

   /** Promotes a mutex to Write Lock, rising the fence
      Calls promoteFence( 0.0, true ), that is waits forever to acquire a write lock
      and rises the fence preventing readers from locking again.
      
      \note This mutex must be locked for reading before issuing a promote,
      or an assertion error will be risen.
      
      \param time maximum time to wait for the promotion, or 0 to wait forever.
   */
   virtual bool promote( double time = 0.0 )  throw( InvalidError )
   {
      return promoteFence( time, false );
   }
     
  
   /** Locks the mutex for writing, possibly rising the fence.
      After this call has returned any request of lock (both read or write)
      will cause blocking of the caller until the owner of this thread releases
      the lock. This method is not reentrant, so never call lockWrite() twice
      from the same thread.

      Works as the RWMutex::lockWrite(), but with the ability to rise the 
      reader's fence.
      
      \param fence if true, prevents any reader to acquire the lock thereafter.
      \param time maximum time to wait for the promotion, or 0 to wait forever.
   */
   virtual bool lockWriteFence( double time =0.0, bool fence = true);

   /** Locks the mutex for writing, without rising the fence.
      Calls lockWrite( seconds, false ).
      
      \param seconds maximum time in seconds to wait for the promotion, or 0 to wait forever.
   */
   
   virtual bool lockWrite( double seconds=0.0 ) { 
      return lockWriteFence( seconds, false );
   }
   

   /** Degrade the mutex from read-write to read only.
      Releases the write lock held by the calling thread, but maintain grip as
      a reader, without giving away the lock. This will prevent writers from
      locking the mutex in the meanwhile, so a degraded mutex will still grant
      that the locked data are not changed, while this cannot be granted if
      the mutex is unlocked and then reacquired read-only.
      
      This function does checks if the calling thread is the
      rightful owner of the mutex, and issues an exception if it isn't.
      
      Being reentrant, this function must be called a number of time equal
      to the write locks acquired on the mutex to drop the write-only rights.
      Also, unlock() calls have the same effect as degrade() until the last
      lock is being held; is the last call (degrade or unlock) to determine
      if the mutex is retained read-only or not.
      
      \throw InvalidError if the mutex is not locked for writing.
   */
   void degrade() throw( InvalidError );
   
   /** Unlocks the mutex.
      Releases the lock held by the calling thread (be it a read-only lock
      or a write lock).
      If the mutex is locked for writing and the calling thread is not the
      owner of the lock, this call is ignored.
      \throw InvalidError if the mutex is not locked.
   */
   virtual void unlock() throw( InvalidError );

   virtual void handleCleanup( int code, void *caller = 0 );
};

}

#endif
/* end of wefts_rrwmutex.h */
