/*
   wefts_queue.h
   Waitable template FIFO structure.

   $Id: wefts_queue.h,v 1.5 2004/04/05 12:42:06 jonnymind Exp $
---------------------------------------------
   Begin      : 2003-08-03 17:50
   Author     : Giancarlo Niccolai

   Last modified because:

*/

/**************************************************************************
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU Library General Public License as       *
*   published by the Free Software Foundation; either version 2.1 of the  *
*   License, or (at your option) any later version.                       *
***************************************************************************/


#ifndef WT_QUEUE_H
#define WT_QUEUE_H

#include <wefts_fastcond.h>
#include <list>

namespace Wefts {

/** Waitable template FIFO structure.

   \ingroup adv_sync

   A Queue, in Wefts++ context, is an object where one or more thread are
   posting data, and one or more thread are waiting for data to become
   available to process it.

   Queue is a fast and clean way to pass arbitrary data in a 1:1 scheme
   from a producer to a consumer (or from a master to a worker) even if
   there are more producer/masters and consumer/workers running at the same
   time.

   Queues have not any scheduling poicies; the first thread that is able
   to wake up will take the first element available.

   By default, queues have infinite length. You can set a maximum length
   and in that case, a thread willing to post a new data will be blocked
   until the queue becomes free again, or will immediately return an
   error (depending on user preferences).

   \note It is illegal to destroy a Queue while there are threads waiting.
      Class SmartQueue has a mechanism to prevent this problem, but this
      is somewhat more expensive in terms of speed.
*/

template <class T>
class Queue {
private:
   void p_waitForFree() {
      while ( m_list.size() >= m_maxLen )
         m_cond.wait();
   }

   void p_waitForFull() {
      while ( m_list.size() == 0 )
         m_cond.wait();
   }

protected:
   FastCondition m_cond;
   unsigned long m_maxLen;
   std::list<T> m_list;

public:
   /** Creates a queue.
      If the parameter is zero, the queue will have infinite length; if
      it is not zero, push() method will block or return immediately
      false when the maximum length is reached.
      \param maxLen maximum length of the queue or 0.
   */
   Queue( unsigned int maxLen = 0) {
      m_maxLen = maxLen;
   }

   /** Pushes data in the queue.

      Queues are FIFO, that is First in, First out. The first element
      you push will be served first to the waiters.

      \param elem the data to be pushed in the Queue
      \param wait true to wait in case the queue is full, false to
         return immediately
      \return true if operation suceeded, false if queue is full and
         \e wait parameter is false
   */
   bool push( T elem, const bool wait=false)
   {
      m_cond.lock();
      if ( m_maxLen > 0 && m_list.size() >= m_maxLen )
      {
         if ( wait ) {
            // this is for compilers that canno expand loops inline
            p_waitForFree();
         }
         else {
            m_cond.unlock();
            return false;
         }
      }
      m_list.push_back( elem );
      m_cond.signal();
      m_cond.unlock();
      return true;
   }


   /** Pops data from the queue.

      Queues are FIFO, that is First in, First out. The first element
      you push will be served first to the waiters.

      Note that the default behavior of pop() is to wait until there
      is some data to be placed in the parameter, but you can also
      set wait parameter to false to have an immediate return in case
      of the queue being empty in that moment.

      A blocking pop() is a cancellation point; be sure you have a proper
      cleanup scheme set up before to call a blocking pop.

      \param elem an element that will receive the popped value.
      \param wait if false, returns immediately if the queue is empty.
      \return true if operation suceeded, false if queue is full and
         \e wait parameter is false
   */

   bool pop( T &elem, const bool wait=true)
   {
      m_cond.lock();
      if ( m_list.size() == 0 )
      {
         if ( wait ) {
            // this is for compilers that canno expand loops inline
            p_waitForFull();
         }
         else {
            m_cond.unlock();
            return false;
         }
      }
      elem = m_list.front();
      m_list.pop_front();
      m_cond.signal();
      m_cond.unlock();
      return true;
   }

   /** Check wether a queue is empty or not.
      Notice that this operation has no sense if the queue is currently used in various threads.
      This is meant to be used by applications that are able to demonstrate that no thread is
      currently helding the queue, or by subclasses.
      
      \return true if the queue is empty.
   */

   bool empty() const
   {
      Queue<T> *Self = const_cast<Queue<T> *>(this);
      Self->m_cond.lock();
      bool res = m_list.empty();
      Self->m_cond.unlock();
      return res;
   }
   
};

}

#endif
/* end of wefts_queue.h */
