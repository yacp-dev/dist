/*
   wefts_cleanup.h
   Cleanup interface.

   $Id: wefts_cleanup.h,v 1.4 2004/03/28 08:28:10 jonnymind Exp $
---------------------------------------------
   Begin      : 2003-08-14 23:45
   Author     : Giancarlo Niccolai

   Last modified because:

*/

/**************************************************************************
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU Library General Public License as       *
*   published by the Free Software Foundation; either version 2.1 of the  *
*   License, or (at your option) any later version.                       *
***************************************************************************/

#ifndef WT_CLEANUP_H
#define WT_CLEANUP_H
#include <list>

namespace Wefts {

/** Cleanup handler interface.
This is a pure abstract interface that is used to create classes that will
handle cleanup requests at some point.
\see \ref howto_cleanup
*/

class CleanupHandler
{
public:
   /** Callback method called on cleanup.
      
      When a thread is terminated (stopped or finished), and a cleanup request
      have been set, this method is called. Use the code parameter to decide
      what action among the possible ones must be taken.
      
      \param code an integer that is passed to determine the kind of action to take
      
      \param caller a pointer to the object that requested cleanup; this allows
         to create generic cleanup routines for several different classes,
         if the actions to take are somehow repetetive.
   */
   virtual void handleCleanup( int code, void *caller=0 )=0;
};

/** Item representing a cleanup handler and its parameters. */
class CleanupItem
{
public:
   /** The pointer to the handler object of which handler->handleCleanup() must be called */
   CleanupHandler *handler;
   /** Position passed as first parameter to handler->handleCleanup() */
   int position;
   /** Object of which cleanup is requested */
   void *caller;
   
   /** Empty constructor that leaves the fields uninitialized. */
   CleanupItem() {}
   
   /** Basic Constructor.
      Initializes only the handler. Faster and to be used if the handler
      handleCleanup routine does not needs its parameters.
      @param h the cleanup handler object pointer
   */
   CleanupItem( CleanupHandler *h )
   {
      handler = h;
   }
   
   /** Position constructor
      To be used when the handler does not use the object pointer referring the cleared
      object; usually, this happens when the object to be cleared is "this", so the
      handler's handleCleanup() routine can access "this" to get the object to clear.
      
      This leaves caller member uninitialized, sparing time.
      
      @param h the cleanup handler object pointer
      @param p the position in cleanup sequence (action to be taken)
   */
   CleanupItem( CleanupHandler *h, int p )
   {
      handler = h;
      position = p;
   }
   
   /** Complete constructor.
      Fills all the three elements of the class.
      @param h the cleanup handler object pointer
      @param p the position in cleanup sequence (action to be taken)
      @param c the object that has to be cleaned
   */
   CleanupItem( CleanupHandler *h, int p, void *c )
   {
      handler = h;
      position = p;
      caller = c;
   }
}; 

/** List of cleanup actions to be taken */
typedef std::list< CleanupItem > CleanupList;

}

#endif
/* end of wefts_cleanup.h */
