/*
   wefts.h
   Header files including all the needed headers for wefts

   $Id: wefts.h,v 1.9 2004/03/10 19:53:30 jonnymind Exp $
---------------------------------------------
   Begin      : 2003-08-02 23:45
   Author     : Giancarlo Niccolai

   Last modified because:

*/

/**************************************************************************
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU Library General Public License as       *
*   published by the Free Software Foundation; either version 2.1 of the  *
*   License, or (at your option) any later version.                       *
***************************************************************************/

#ifndef WEFTS_H
#define WEFTS_H

#include <wefts_mutex.h>
#include <wefts_rmutex.h>
#include <wefts_rwmutex.h>
#include <wefts_rrwmutex.h>

#include <wefts_cleanup.h>
#include <wefts_cleancond.h>

#include <wefts_cond.h>
#include <wefts_fastcond.h>
#include <wefts_rcond.h>

#include <wefts_semaphore.h>
#include <wefts_critical.h>
#include <wefts_barrier.h>
#include <wefts_subscription.h>

#include <wefts_thread.h>
#include <wefts_moaning.h>
#include <wefts_sleep.h>
#include <wefts_referenced.h>

#include <wefts_specific.h>

#include <wefts_queue.h>
#include <wefts_stack.h>

#include <wefts_xmutex.h>
#include <wefts_ringbuffer.h>

#endif
/* end of wefts.h */
