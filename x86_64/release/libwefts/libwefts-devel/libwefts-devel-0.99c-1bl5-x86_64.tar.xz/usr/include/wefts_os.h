/*
   wefts_os.h
   Select correct OS dependant libraries.

   $Id: wefts_os.h,v 1.9 2004/03/28 11:41:21 jonnymind Exp $
---------------------------------------------
   Begin      : 2003-08-03 17:50
   Author     : Giancarlo Niccolai

   Last modified because:

*/

/**************************************************************************
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU Library General Public License as       *
*   published by the Free Software Foundation; either version 2.1 of the  *
*   License, or (at your option) any later version.                       *
***************************************************************************/


#ifndef WT_OS_H
#define WT_OS_H

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#ifdef _MSC_VER
   #pragma warning ( disable : 4786 )
#endif

// Detect OSTAIL used (underlying threading library)
#if defined( HAVE_LIBPTHREAD )
#include <wefts_os_pthread.h>
#include <wefts_proc_pthread.h>
#elif defined( HAVE_WIN_THREADS )
#include <wefts_os_windows.h>
#include <wefts_proc_win.h>
#else
#error "Current system still not implemented"
#endif

// Detect OS-COFFEE used (underlying filesystem interface)
// Currently, windows threads are available only under windows
#if defined( HAVE_WIN_THREADS )
#include <wefts_coffee_win.h>
#elif defined( HAVE_UNISTD_H )
#include <wefts_coffee_unix.h>
#endif


// COFFEE is NOT essential, so no error if we can't find it.

#endif
/* end of wefts_os.h */
