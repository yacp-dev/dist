/*
   wefts_os_base.h
   Abstract base class for os dependant implementations

   $Id: wefts_os_base.h,v 1.12 2004/03/28 21:45:40 jonnymind Exp $
---------------------------------------------
   Begin      : 2003-08-15 16:30
   Author     : Giancarlo Niccolai

   Last modified because:

*/

/**************************************************************************
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU Library General Public License as       *
*   published by the Free Software Foundation; either version 2.1 of the  *
*   License, or (at your option) any later version.                       *
***************************************************************************/


#ifndef WT_OS_BASE_H
#define WT_OS_BASE_H

#include <wefts_cleanup.h>
#include <string>

/** \file
   Base OS dependant layer; to be overloaded by OS dependant implementations.

   This file contains a set of definitions and abstract base class that must
   be implemented by specific OS layers. At a first look, it may seem superfluous,
   as it would be enough to include the correct header for the given implementation,
   but this file is here for two reasons: first of all, to document the layer
   only once, so to have a main reference guide, and secondly to provide a
   template that forces OS layer implementors to respect Wefts base OS layer
   model.

   See \ref howto_oslevel for a description.
*/

namespace Wefts {

/** \addtogroup oslevel
@{
*/

/** Portable priority concept.
   This is a set of priorities that can be used to modify
   a thread priority in the internal scheduling policy.
*/
typedef enum 
{
   /** Realtime priority. 
      Theads in this class should be rescheduled and executed as fast
      as the operating system is able to do, pre-empting even the Kernel,
      if the OS is able to cope with this.
   */
   PrioRealTime = 0,
   /** High priority.
      Theads in this class should be rescheduled and executed as fast
      as the operating system is able to do, but the kernel is not
      pre-empted under any condition.
   */
   PrioHigh = 1,
   /** Normal priority.
      The thread is just scheduled in the normal thread queues, which means that
      it's waken as soon as possible, after that system kernel, interrupts/signal
      handlers and device driver/service routines have completed or are
      considered "idle".
   */
   PrioNormal = 2,
   /** Low priority.
      Threads in this class are considered low priority, and awaken only if/when the
      normal priority threads are idle; anyhow, care is taken not to starve this
      thread class, so a little space should be found for them anyway, maybe with
      big delays.
   */
   PrioLow = 3,
   /** Idle threads.
      Threads in this class are waken up only during the system Idle cycle, so that
      they are actually running only if no other process (including the kernel) is
      actively demanding CPU. Idle thread class may be starved indefinitely, if the
      CPU is so intensely exploited that it never enters the idle loop.
   */
   PrioIdle = 4
} OSPriority ;

/** Utility structure to pass around a thread object along with its return.
   As the only function able to know if a thread is detached, and that then can
   rightfully delete the thread object, is the cancellation cleanup handler,
   it is also the only function that is able to set the thread run return value
   member if the thread is NOT detached. To let the cleanup handler have this
   value, this structure holds a pointer to the thread and a pointer to the 
   run return value (or zero, if the run() method had not a chance to return).
   
   OSThreadBase::osRun() is responsible to fill correctly this value and let
   the cleanup routine have it.
*/
typedef struct tag_ThreadAndReturn
{
   void *thread;
   void *runReturn;
} ThreadAndReturn;

/** Implements an OS specific mutex
   This mutex class is not supposed to be reentrant, but it is supposed to
   have an trylock() feature at OS level.
\see \ref howto_oslevel
*/

class OSMutexBase {
protected:
   /** Initializes the internal data of the mutex */
   OSMutexBase(){}

public:
   /** Locks the mutex. */
   virtual inline void lock()=0;

   /** Try to lock the mutex. */
   virtual inline bool trylock()=0;

   /** Unlocks the mutex. */
   virtual inline void unlock()=0;
};

/** This class implement an os-dependant condition.
Supposition about OS condition that must be respected by implementations:
- condition signaling is made rising a flag that wakes <B>all</B> the threads
  that are currently waiting; threads trying to wait after a cond singal
  are <B>safely</B> blocked (even if some unsignaled thread must still
  be awaken).
- To enter the wait, the waiter must give off a mutex that is used to
  check if a predicate has become true.
- Timed wait is expressed in seconds and nanoseconds.
- Upon cancellation the mutex used in signaling is locked before cancellation
  sequence is called.
\note All OS dependant classes should be completely inline.
\see \ref howto_oslevel
*/

class OSConditionBase {
protected:
   /** Intializes pthread condition */
   OSConditionBase() {}

public:
   /** Signal a condition variable on ALL waiting threads.
      This correspond roughly to pthread_cond_broadcast.
   */
   virtual void signal()=0;
   
   /** Signal a condition variable on ONE waiting thread.
      This correspond roughly to pthread_cond_signal.
   */
   virtual void signalOne()=0;

   /** Waiting for a condition (giving off an already held mutex).
      The mutex must be held on entrance. Also notice that the
      guard parameter is passed by value to make a copy of it
      in the thread stack, so that, after return of the function
      (and subquesent unlocking of the mutex), another thread can
      change safely the guard object, and still the cleanup
      function for this thread will refer to the desired one.

      \param mtx the mutex to be used with this condition
      \param guard a cleanup item (pair of cleanup object pointer plus integer
      parameter
      \return true on condition signaled, false on timeout or interrupted wait.
   */
   virtual bool wait( OSMutexBase &mtx, CleanupItem &guard )=0;

   /** Timed wait.
      \param mtx the mutex to be used with this condition
      \param guard a cleanup item (pair of cleanup object pointer plus integer
      parameter
      \param seconds count of second
      \param nanoseconds count of nanoseconds
      \return true on condition signaled, false on timeout or interrupted wait.
   */
   virtual bool timedWait( OSMutexBase &mtx, long seconds,
         long nanoseconds, CleanupItem &guard )=0;
};

/** Thread OS layer abstraction
This class can be rewritten in other header files to implement different
os specific threading system.
\see \ref howto_oslevel
*/
class OSThreadBase {
protected:
   /** Newly created thread.
      Subclassess must calll invalidate() member to specify that the
      current thread is still not running.
   */
   OSThreadBase() {}

   /** Already running thread.
   Call this constructor if you need to have a reference to the thread that is
   currently running; this will set the OSThreadBase internal data as if a
   start were called at some point. */
   OSThreadBase( bool ) {}

protected:
   /** Exit the thread.
      Run() can call this method instead of retunring a void *;
      the effect is the same.
   */
   virtual void exit( void *data )=0;

public:
   /** Sets thread priority.
      Thread priority is defined by a class and a boost throttle. System may
      implement this differently, or even ignore it, if there isn't any low
      level mean to determine thread priority; wefts itself does not enforce
      any priority, but it tries to get the OS to act as near as possible to
      the required class and thread boost. The thread class defines how the
      thread is rescheduled after a wait, or after a swap; the boost level
      is a value that tells the system scheduler to prefer some thread with
      respect to the others in the same thread class. The higher is the boost
      level, the better are the chance of the thread to be rescheduled before
      the same threads with lower boost. Boost value can also be negative, meaning
      that the thread may be scheduled less often than other threads in the same
      class having boost 0.
      
      Wefts will try to arrange the theoretical model of Wefts priorities 
      (\ref OSPriority ) into the available threading model and OS capabilties.
      
      \note Often, OS have a concept of priority that works the other way round;
      i.e. the "nice" level of a process in unix is so that the higher, the worst,
      the lower (even negative), the better. Do not confuse this with wefts boost
      number.
      
      Boost levels may be any positive or negative number; wefts will try to fit
      the boost level into the underlying OS and threading scheme; usually a value
      ranging from -20 to 20 is the maximum range that you may proficiently used.
      If you give a boost level that wefts cannot request to the underlying system,
      this will be truncated to the maximum or minimum available.
           
      The method returns ture if the priority may be set, or false otherwise; on some
      systems, the request to set a priority may fail due the need for higher system
      privilege to do so.      
   */
   virtual bool priority( OSPriority prio_class, int boost = 0) = 0;
      
   /** Starts OS specific thread
   OS dependant implementation must provide a valid function to
   execute the thread; Thread.cpp has already some valid ones.
   \param func the function to be executed in parallel thread.
   \param data the data to be passed to os-level thread function
   */
   virtual bool start( void *(*func)(void *), void *data )=0;

   /** Stop this OS specific thread. */
   virtual bool stop()=0;

   /** Joins this OS Specific threads. */
   virtual void *join()=0;

   /** Enables cancellation:
      This function returns the old status on success, that can
      be later reset with setCancelStatus. On error, return type
      is undefined.
      \note a candidate for exception rising.
      \todo write a low-level exception system.
   */
   virtual int enableCancel()=0;

   /** Disables cancellation.
      Wokrs like enableCancel.
      \see enableCancel()
   */
   virtual int disableCancel()=0;

   /** Raw function to set the cancel type.
      This function should be used only with the integer returned by enableCancel()
      and disableCancel(), as no assumption can be made about what the meaning
      of the parameter could be in different environments.
      \param state system dependant (that is to say: don't touch it).
      \return true on success
   */
   virtual bool setCancelState( int state )=0;

   /** Kill the thread on OS level cancellation */
   virtual void testCancel()=0;
   /** Tells the thread that it must use deferred cancellation.
      The OS may provide deferred cancellation schemes natively, or not.
      In the latter case, deferred cancellation must be emulated; See
      \ref howto_cancel. When OS does not provides inbound deferred
      cancellation, this routine must do nothing.
   */
   virtual void setCancelDeferred()=0;
   
   /** Detach thread.
      \note Wefts detaching differs from pthread detaching; a wefts detached
      thread is just a thread whose class data will be automatically destroyed
      on termination (and that can't be joined).
      \see Thread::detach()
   */
   virtual void detach()=0;

   /** Starts emulated deferred cancellation.
   In base class, it does nothing. If the os does support natively the deferred
   cancellation scheme, this function is useless.
   \see \ref howto_cancel 
   */
   virtual void emuDeferredStart() {}
   
   /** End emulated deferred cancellation.
   In base class, it does nothing. If the os does support natively the deferred
   cancellation scheme, this function is useless. 
   \see \ref howto_cancel
   */
   virtual void emuDeferredEnd() {}

   /** Executes a procedure under the hood of a cleanup procedure 
      This method requires the underlying OS threading system to set up a
      single cleanup procedure, execute the procedure "func" and then call
      the cleanup procedure; if the thread is canceled, os system must provide. 
      "data" to the cleanup procedure and exit cleanly.
      
      Paramere data is actually a Thread or derived class isntance, 
      but it must be considered opaque to os layer. 
      
      The parameter for clanup, that must be called inside this method, is 
      must be a ThreadAndReturn structure, which contains a
      pointer to a Wefts::Thread or derived object, and the return value of the
      func parameter. Derived classes are responsible to fill correctly this
      structrue: the thread member of ThreadAndReturn must be set to the
      data parameter; before func is called, the runReturn element
      of the ThreadAndReturn structure must be set to zero, and then it must
      be set to func call return value.
      
      Currently func() is only a wrapper to call data->run(), but this may
      change in the future.
      \param func a wrapper that calls data->run() and returns its value.
      \param data a pointer to a Thread class or Thread derived class instance
      \param cleanup a pointer to a cleanup routine, accepting ThreadAndReturn 
             structure pointer as a parameter
   */
   virtual void *osRun( void * (*func)(void *), void *data, void (*cleanup)(void *) )=0;

   /** Returns true if the currently running thread and this objects are
       the same. */
   virtual bool same() const=0;

   /** Returns true if this object is equal (on OS opinion) to the parameter */
   virtual bool equal( const OSThreadBase &th ) const =0;

   /** Change this thread object to the current OS dependant thread.
      It makes so that all the internal variables are set to reflect this
      current thread. In some implementation, updating of some variables
      my be deferred to a later moment; the important thing is to change
      the thread type.
   */
   virtual bool setCurrent()=0;

   /* Invalidate current thread.
      This function must make so that the invalidated thread always returns
      false when same() or equal() are called. If equal() method is called
      upon another invalid thread, the result is undefined.
   */
   virtual void invalidate()=0;

   /** Pass the test to equal() */
   virtual bool operator==( OSThreadBase &th ) { return equal( th ); }

   /** Pass the test to ! equal() */
   virtual bool operator!=( OSThreadBase &th ) { return ! equal( th ); }
};

/** Wrapper class for thread specific data access (tsd/tls) */
class OSSpecificDataBase
{
protected:
   /** Prepares the internal data.*/
   OSSpecificDataBase() {}

public:

   /** Get the specific data */
   virtual void *data() const =0;

   /** Set the specific data */
   virtual void data(const void *dt) =0;
};


/** Function to report OS specific error */
std::string OSErrorDescription( int osCode );

/** Function to provide a wefts-interruptable wait */
bool OSSleep( long nSeconds, long nNanoseconds );

/** Function that returns the thread object running in the current OS thread. 

It may be null if current OS thread has not be started with Thread::run(); tipically
calling this from the main thread will return 0. If you use only Wefts to start
threads, you can safely use the return vaule of 0 as a marker for the main application
thread.

\return a pointer that can be casted into a Wefts::Thread object.
*/
void *getCurrentThreadObject();

/** Function used to set current thread object.
OSTAIL providers must provide this function, that is called by threads right before
calling the Thread::run() method. This is used internally for various reasons.a
\param thread the object whose Thread::run() method is going to be called.
*/
void setCurrentThreadObject(void *thread);

/*@}*/
} // namespace

#endif

/* end of wefts_os_pthread.h */
