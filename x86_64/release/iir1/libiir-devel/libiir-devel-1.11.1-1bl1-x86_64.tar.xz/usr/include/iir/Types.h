/**
 *
 * "A Collection of Useful C++ Classes for Digital Signal Processing"
 * By Vinnie Falco and Bernd Porr
 *
 * Official project location:
 * https://github.com/berndporr/iir1
 *
 * See Documentation.cpp for contact information, notes, and bibliography.
 *
 * -----------------------------------------------------------------
 *
 * License: MIT License (http://www.opensource.org/licenses/mit-license.php)
 * Copyright (c) 2009 by Vinnie Falco
 * Copyright (c) 2011 by Bernd Porr
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 **/

#pragma once

#include "Common.h"
#include "MathSupplement.h"

namespace Iir
{

/**
 * A conjugate or real pair
 **/
struct IIR_EXPORT ComplexPair : complex_pair_t
{
    ComplexPair () = default;

    static constexpr double epsilon = 1E-10;

    explicit ComplexPair (const complex_t &c1) : complex_pair_t (c1, complex_t(0))
    {
        if (!isReal ())
            throw_invalid_argument (
                "A single complex number needs to be real.");
    }

    ComplexPair (const complex_t &c1, const complex_t &c2)
        : complex_pair_t (c1, c2)
    {
    }

    bool isReal () const
    {
        return (std::abs (first.imag ()) < epsilon)
               && (std::abs (second.imag ()) < epsilon);
    }

    /**
	 * Returns true if this is either a conjugate pair,
	 * or a pair of reals where neither is zero.
	 */
    bool isMatchedPair () const
    {
        if ((isReal () && (std::abs (first.real ()) > epsilon))
            && (std::abs (second.real ()) > epsilon))
            return true;
        return std::abs(second - std::conj (first)) < epsilon;
    }

    bool is_nan () const
    {
        return Iir::is_nan (first) || Iir::is_nan (second);
    }
};

/**
 * A pair of pole/zeros. This fits in a biquad (but is missing the gain)
 **/
struct IIR_EXPORT PoleZeroPair
{
    ComplexPair poles = ComplexPair ();
    ComplexPair zeros = ComplexPair ();

    PoleZeroPair () = default;

    static constexpr double epsilon = 1E-10;

    // single pole/zero
    PoleZeroPair (const complex_t &p, const complex_t &z)
        : poles (p), zeros (z)
    {
    }

    // pole/zero pair
    PoleZeroPair (const complex_t &p1, const complex_t &z1,
                  const complex_t &p2, const complex_t &z2)
        : poles (p1, p2), zeros (z1, z2)
    {
    }

    bool isSinglePole () const
    {
        return (std::abs(poles.second) < epsilon) && (std::abs(zeros.second) < epsilon);
    }

    bool is_nan () const { return poles.is_nan () || zeros.is_nan (); }
};

}
