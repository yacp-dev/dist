#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "iir::iir" for configuration "RelWithDebInfo"
set_property(TARGET iir::iir APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(iir::iir PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libiir.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygiir-1.dll"
  )

list(APPEND _cmake_import_check_targets iir::iir )
list(APPEND _cmake_import_check_files_for_iir::iir "${_IMPORT_PREFIX}/lib/libiir.dll.a" "${_IMPORT_PREFIX}/bin/cygiir-1.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
