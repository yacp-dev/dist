get_filename_component(LIBSEDML_CMAKE_DIR "${CMAKE_CURRENT_LIST_FILE}" PATH)
include(CMakeFindDependencyMacro)

list(APPEND CMAKE_MODULE_PATH "/usr/share/cmake/Modules")

set(LIBNUML_LIBRARY_NAME numl-static)
find_dependency(LIBNUML)

set(LIBSBML_LIBRARY_NAME sbml-static)
find_dependency(LIBSBML)

foreach (library )

  string(FIND "${library}" "::" index)

  if (${index} GREATER 0)
    # found dependent library
    string(SUBSTRING "${library}" 0 ${index} DEPENDENT_NAME)
    message(VERBOSE "Looking for dependent library: ${DEPENDENT_NAME}")
    find_dependency(${DEPENDENT_NAME})
  endif()

endforeach()

if(NOT TARGET sedml)
    include("${LIBSEDML_CMAKE_DIR}/sedml-targets.cmake")
endif()

set(LIBSEDML_LIBRARIES sedml)
