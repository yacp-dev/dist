#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "sedml" for configuration "RelWithDebInfo"
set_property(TARGET sedml APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(sedml PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libsedml.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygsedml-2.dll"
  )

list(APPEND _cmake_import_check_targets sedml )
list(APPEND _cmake_import_check_files_for_sedml "${_IMPORT_PREFIX}/lib/libsedml.dll.a" "${_IMPORT_PREFIX}/bin/cygsedml-2.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
