#if 1
#define LOGNORM_REGEX_SUPPORTED 1
#endif

#if 0
#define LOGNORM_TURBO_SUPPORTED 1
#endif
