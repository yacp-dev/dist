#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "qt5keychain" for configuration "RelWithDebInfo"
set_property(TARGET qt5keychain APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(qt5keychain PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libqt5keychain.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygqt5keychain-1.dll"
  )

list(APPEND _cmake_import_check_targets qt5keychain )
list(APPEND _cmake_import_check_files_for_qt5keychain "${_IMPORT_PREFIX}/lib/libqt5keychain.dll.a" "${_IMPORT_PREFIX}/bin/cygqt5keychain-1.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
