/*
 * Library to provide basic file overlay support
 *
 * Copyright (C) 2020-2024, Joachim Metz <joachim.metz@gmail.com>
 *
 * Refer to AUTHORS for acknowledgements.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#if !defined( _LIBBFOVERLAY_H )
#define _LIBBFOVERLAY_H

#include <libbfoverlay/definitions.h>
#include <libbfoverlay/codepage.h>
#include <libbfoverlay/error.h>
#include <libbfoverlay/extern.h>
#include <libbfoverlay/features.h>
#include <libbfoverlay/types.h>

#include <stdio.h>

#if defined( LIBBFOVERLAY_HAVE_BFIO )
#include <libbfio.h>
#endif

#if defined( __cplusplus )
extern "C" {
#endif

/* -------------------------------------------------------------------------
 * Support functions
 * ------------------------------------------------------------------------- */

/* Returns the library version
 */
LIBBFOVERLAY_EXTERN \
const char *libbfoverlay_get_version(
             void );

/* Retrieves the narrow system string codepage
 * A value of 0 represents no codepage, UTF-8 encoding is used instead
 * Returns 1 if successful or -1 on error
 */
LIBBFOVERLAY_EXTERN \
int libbfoverlay_get_codepage(
     int *codepage,
     libbfoverlay_error_t **error );

/* Sets the narrow system string codepage
 * A value of 0 represents no codepage, UTF-8 encoding is used instead
 * Returns 1 if successful or -1 on error
 */
LIBBFOVERLAY_EXTERN \
int libbfoverlay_set_codepage(
     int codepage,
     libbfoverlay_error_t **error );

/* -------------------------------------------------------------------------
 * Notify functions
 * ------------------------------------------------------------------------- */

/* Sets the verbose notification
 */
LIBBFOVERLAY_EXTERN \
void libbfoverlay_notify_set_verbose(
      int verbose );

/* Sets the notification stream
 * Returns 1 if successful or -1 on error
 */
LIBBFOVERLAY_EXTERN \
int libbfoverlay_notify_set_stream(
     FILE *stream,
     libbfoverlay_error_t **error );

/* Opens the notification stream using a filename
 * The stream is opened in append mode
 * Returns 1 if successful or -1 on error
 */
LIBBFOVERLAY_EXTERN \
int libbfoverlay_notify_stream_open(
     const char *filename,
     libbfoverlay_error_t **error );

/* Closes the notification stream if opened using a filename
 * Returns 0 if successful or -1 on error
 */
LIBBFOVERLAY_EXTERN \
int libbfoverlay_notify_stream_close(
     libbfoverlay_error_t **error );

/* -------------------------------------------------------------------------
 * Error functions
 * ------------------------------------------------------------------------- */

/* Frees an error
 */
LIBBFOVERLAY_EXTERN \
void libbfoverlay_error_free(
      libbfoverlay_error_t **error );

/* Prints a descriptive string of the error to the stream
 * Returns the number of printed characters if successful or -1 on error
 */
LIBBFOVERLAY_EXTERN \
int libbfoverlay_error_fprint(
     libbfoverlay_error_t *error,
     FILE *stream );

/* Prints a descriptive string of the error to the string
 * Returns the number of printed characters if successful or -1 on error
 */
LIBBFOVERLAY_EXTERN \
int libbfoverlay_error_sprint(
     libbfoverlay_error_t *error,
     char *string,
     size_t size );

/* Prints a backtrace of the error to the stream
 * Returns the number of printed characters if successful or -1 on error
 */
LIBBFOVERLAY_EXTERN \
int libbfoverlay_error_backtrace_fprint(
     libbfoverlay_error_t *error,
     FILE *stream );

/* Prints a backtrace of the error to the string
 * Returns the number of printed characters if successful or -1 on error
 */
LIBBFOVERLAY_EXTERN \
int libbfoverlay_error_backtrace_sprint(
     libbfoverlay_error_t *error,
     char *string,
     size_t size );

/* -------------------------------------------------------------------------
 * Handle functions
 * ------------------------------------------------------------------------- */

/* Creates a handle
 * Make sure the value handle is referencing, is set to NULL
 * Returns 1 if successful or -1 on error
 */
LIBBFOVERLAY_EXTERN \
int libbfoverlay_handle_initialize(
     libbfoverlay_handle_t **handle,
     libbfoverlay_error_t **error );

/* Frees a handle
 * Returns 1 if successful or -1 on error
 */
LIBBFOVERLAY_EXTERN \
int libbfoverlay_handle_free(
     libbfoverlay_handle_t **handle,
     libbfoverlay_error_t **error );

/* Signals a handle to abort its current activity
 * Returns 1 if successful or -1 on error
 */
LIBBFOVERLAY_EXTERN \
int libbfoverlay_handle_signal_abort(
     libbfoverlay_handle_t *handle,
     libbfoverlay_error_t **error );

/* Opens a handle
 * Returns 1 if successful or -1 on error
 */
LIBBFOVERLAY_EXTERN \
int libbfoverlay_handle_open(
     libbfoverlay_handle_t *handle,
     const char *filename,
     int access_flags,
     libbfoverlay_error_t **error );

#if defined( LIBBFOVERLAY_HAVE_WIDE_CHARACTER_TYPE )

/* Opens a handle
 * Returns 1 if successful or -1 on error
 */
LIBBFOVERLAY_EXTERN \
int libbfoverlay_handle_open_wide(
     libbfoverlay_handle_t *handle,
     const wchar_t *filename,
     int access_flags,
     libbfoverlay_error_t **error );

#endif /* defined( LIBBFOVERLAY_HAVE_WIDE_CHARACTER_TYPE ) */

#if defined( LIBBFOVERLAY_HAVE_BFIO )

/* Opens a handle using a Basic File IO (bfio) handle
 * Returns 1 if successful or -1 on error
 */
LIBBFOVERLAY_EXTERN \
int libbfoverlay_handle_open_file_io_handle(
     libbfoverlay_handle_t *handle,
     libbfio_handle_t *file_io_handle,
     int access_flags,
     libbfoverlay_error_t **error );

#endif /* defined( LIBBFOVERLAY_HAVE_BFIO ) */

LIBBFOVERLAY_EXTERN \
int libbfoverlay_handle_open_data_files(
     libbfoverlay_handle_t *handle,
     libbfoverlay_error_t **error );

#if defined( LIBBFOVERLAY_HAVE_BFIO )

LIBBFOVERLAY_EXTERN \
int libbfoverlay_handle_open_data_files_file_io_pool(
     libbfoverlay_handle_t *handle,
     libbfio_pool_t *file_io_pool,
     libbfoverlay_error_t **error );

#endif /* defined( LIBBFOVERLAY_HAVE_BFIO ) */

/* Closes the handle
 * Returns 0 if successful or -1 on error
 */
LIBBFOVERLAY_EXTERN \
int libbfoverlay_handle_close(
     libbfoverlay_handle_t *handle,
     libbfoverlay_error_t **error );

/* Reads a buffer
 * Returns the number of bytes read if successful, or -1 on error
 */
LIBBFOVERLAY_EXTERN \
ssize_t libbfoverlay_handle_read_buffer(
         libbfoverlay_handle_t *handle,
         uint8_t *buffer,
         size_t size,
         libbfoverlay_error_t **error );

/* Reads a buffer at a specific offset
 * Returns the number of bytes read if successful, or -1 on error
 */
LIBBFOVERLAY_EXTERN \
ssize_t libbfoverlay_handle_read_buffer_at_offset(
         libbfoverlay_handle_t *handle,
         uint8_t *buffer,
         size_t buffer_size,
         off64_t offset,
         libbfoverlay_error_t **error );

/* Writes data from buffer at the current offset
 * Returns the number of bytes written if successful, or -1 on error
 */
LIBBFOVERLAY_EXTERN \
ssize_t libbfoverlay_handle_write_buffer(
         libbfoverlay_handle_t *handle,
         const uint8_t *buffer,
         size_t size,
         libbfoverlay_error_t **error );

/* Writes data at a specific offset
 * Returns the number of bytes written or -1 on error
 */
LIBBFOVERLAY_EXTERN \
ssize_t libbfoverlay_handle_write_buffer_at_offset(
         libbfoverlay_handle_t *handle,
         const uint8_t *buffer,
         size_t buffer_size,
         off64_t offset,
         libbfoverlay_error_t **error );

/* Seeks a specific offset
 * Returns the offset if the seek is successful or -1 on error
 */
LIBBFOVERLAY_EXTERN \
off64_t libbfoverlay_handle_seek_offset(
         libbfoverlay_handle_t *handle,
         off64_t offset,
         int whence,
         libbfoverlay_error_t **error );

/* Resizes the data of the handle
 * Returns 1 if successful or -1 on error
 */
LIBBFOVERLAY_EXTERN \
int libbfoverlay_handle_resize(
     libbfoverlay_handle_t *handle,
     size64_t size,
     libbfoverlay_error_t **error );

/* Retrieves the current offset
 * Returns 1 if successful or -1 on error
 */
LIBBFOVERLAY_EXTERN \
int libbfoverlay_handle_get_offset(
     libbfoverlay_handle_t *handle,
     off64_t *offset,
     libbfoverlay_error_t **error );

/* Returns the size of the data of the handle
 * Returns 1 if successful or -1 on error
 */
LIBBFOVERLAY_EXTERN \
int libbfoverlay_handle_get_size(
     libbfoverlay_handle_t *handle,
     size64_t *size,
     libbfoverlay_error_t **error );

#if defined( __cplusplus )
}
#endif

#endif /* !defined( _LIBBFOVERLAY_H ) */

