#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "ethash::keccak" for configuration "RelWithDebInfo"
set_property(TARGET ethash::keccak APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(ethash::keccak PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libethash-keccak.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygethash-keccak-1.dll"
  )

list(APPEND _cmake_import_check_targets ethash::keccak )
list(APPEND _cmake_import_check_files_for_ethash::keccak "${_IMPORT_PREFIX}/lib/libethash-keccak.dll.a" "${_IMPORT_PREFIX}/bin/cygethash-keccak-1.dll" )

# Import target "ethash::ethash" for configuration "RelWithDebInfo"
set_property(TARGET ethash::ethash APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(ethash::ethash PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libethash.dll.a"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELWITHDEBINFO "ethash::keccak"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygethash-1.dll"
  )

list(APPEND _cmake_import_check_targets ethash::ethash )
list(APPEND _cmake_import_check_files_for_ethash::ethash "${_IMPORT_PREFIX}/lib/libethash.dll.a" "${_IMPORT_PREFIX}/bin/cygethash-1.dll" )

# Import target "ethash::global-context" for configuration "RelWithDebInfo"
set_property(TARGET ethash::global-context APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(ethash::global-context PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libethash-global-context.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygethash-global-context-1.dll"
  )

list(APPEND _cmake_import_check_targets ethash::global-context )
list(APPEND _cmake_import_check_files_for_ethash::global-context "${_IMPORT_PREFIX}/lib/libethash-global-context.dll.a" "${_IMPORT_PREFIX}/bin/cygethash-global-context-1.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
