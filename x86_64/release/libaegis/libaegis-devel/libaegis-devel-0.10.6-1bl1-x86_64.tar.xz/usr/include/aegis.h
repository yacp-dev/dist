#ifndef aegis_H
#define aegis_H

#include <stdint.h>

#if !defined(__clang__) && !defined(__GNUC__)
#    ifdef __attribute__
#        undef __attribute__
#    endif
#    define __attribute__(a)
#endif

#ifndef CRYPTO_ALIGN
#    if defined(__INTEL_COMPILER) || defined(_MSC_VER)
#        define CRYPTO_ALIGN(x) __declspec(align(x))
#    else
#        define CRYPTO_ALIGN(x) __attribute__((aligned(x)))
#    endif
#endif

#ifndef AEGIS_WARN_UNUSED_RESULT
#    if defined(__GNUC__) || defined(__clang__)
#        define AEGIS_WARN_UNUSED_RESULT __attribute__((warn_unused_result))
#    elif defined(_MSC_VER)
#        define AEGIS_WARN_UNUSED_RESULT _Check_return_
#    else
#        define AEGIS_WARN_UNUSED_RESULT
#    endif
#endif

#ifndef AEGIS_DEPRECATED
#    if defined(__GNUC__) || defined(__clang__)
#        define AEGIS_DEPRECATED(msg) __attribute__((deprecated(msg)))
#    elif defined(_MSC_VER)
#        define AEGIS_DEPRECATED(msg) __declspec(deprecated(msg))
#    else
#        define AEGIS_DEPRECATED(msg)
#    endif
#endif

#include "aegis128l.h"
#include "aegis128x2.h"
#include "aegis128x4.h"
#include "aegis256.h"
#include "aegis256x2.h"
#include "aegis256x4.h"

#include "aegis_raf.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Initialize the AEGIS library.
 *
 * This function does runtime CPU capability detection, and must be called once
 * in your application before doing anything else with the library.
 *
 * If you don't, AEGIS will still work, but it may be much slower.
 *
 * The function can be called multiple times but is not thread-safe.
 */
int aegis_init(void);

/* Compare two 16-byte blocks for equality.
 *
 * This function is designed to be used in constant-time code.
 *
 * Returns 0 if the blocks are equal, -1 otherwise.
 */
AEGIS_WARN_UNUSED_RESULT
int aegis_verify_16(const uint8_t *x, const uint8_t *y);

/* Compare two 32-byte blocks for equality.
 *
 * This function is designed to be used in constant-time code.
 *
 * Returns 0 if the blocks are equal, -1 otherwise.
 */
AEGIS_WARN_UNUSED_RESULT
int aegis_verify_32(const uint8_t *x, const uint8_t *y);

#ifdef __cplusplus
}
#endif

#endif
