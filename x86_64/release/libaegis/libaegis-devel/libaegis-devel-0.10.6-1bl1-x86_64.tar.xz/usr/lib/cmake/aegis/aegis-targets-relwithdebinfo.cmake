#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "aegis::aegis" for configuration "RelWithDebInfo"
set_property(TARGET aegis::aegis APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(aegis::aegis PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libaegis.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygaegis-0.dll"
  )

list(APPEND _cmake_import_check_targets aegis::aegis )
list(APPEND _cmake_import_check_files_for_aegis::aegis "${_IMPORT_PREFIX}/lib/libaegis.dll.a" "${_IMPORT_PREFIX}/bin/cygaegis-0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
