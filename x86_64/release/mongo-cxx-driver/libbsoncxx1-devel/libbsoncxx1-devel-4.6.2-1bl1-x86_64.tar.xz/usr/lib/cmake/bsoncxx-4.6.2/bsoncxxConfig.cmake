include(CMakeFindDependencyMacro)
find_dependency(bson 2.5.8)
include("${CMAKE_CURRENT_LIST_DIR}/bsoncxx_targets.cmake")
