// Copyright 2009-present MongoDB, Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#pragma once

#include <bsoncxx/v1/types/view-fwd.hpp> // IWYU pragma: export

#include <bsoncxx/config/prelude.hpp>

namespace bsoncxx {
namespace v_noabi {
namespace types {
namespace bson_value {

class view;

} // namespace bson_value

///
/// Equivalent to @ref bsoncxx::v_noabi::types::bson_value::view.
///
/// To support incremental migration to @ref bsoncxx::v1::types::view.
///
using view = v_noabi::types::bson_value::view;

} // namespace types
} // namespace v_noabi
} // namespace bsoncxx

namespace bsoncxx {
namespace types {
namespace bson_value {

using v_noabi::types::bson_value::view;

} // namespace bson_value

using v_noabi::types::view;

} // namespace types
} // namespace bsoncxx

#include <bsoncxx/config/postlude.hpp>

///
/// @file
/// Declares @ref bsoncxx::v_noabi::types::bson_value::view.
///
/// @deprecated Use @ref bsoncxx/types/view-fwd.hpp instead (renamed).
///
/// @par Includes
/// - @ref bsoncxx/v1/types/view-fwd.hpp
///
