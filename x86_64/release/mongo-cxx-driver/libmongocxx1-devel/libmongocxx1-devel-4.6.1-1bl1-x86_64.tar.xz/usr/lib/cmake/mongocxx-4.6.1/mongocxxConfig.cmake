include(CMakeFindDependencyMacro)
find_dependency(mongoc 2.5.6)
find_dependency(bsoncxx 4.6.1)
include("${CMAKE_CURRENT_LIST_DIR}/mongocxx_targets.cmake")
