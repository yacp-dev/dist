// Copyright 2009-present MongoDB, Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#pragma once

#include <mongocxx/options/find_one_common_options-fwd.hpp> // IWYU pragma: export

//

#include <mongocxx/v1/return_document.hpp> // IWYU pragma: export

///
/// @file
/// Provides @ref mongocxx::v_noabi::options::return_document.
///
/// @par Includes
/// - @ref mongocxx/v1/return_document.hpp
///
