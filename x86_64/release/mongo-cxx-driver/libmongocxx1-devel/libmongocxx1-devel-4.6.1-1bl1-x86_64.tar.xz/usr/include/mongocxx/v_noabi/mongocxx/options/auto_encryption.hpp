// Copyright 2009-present MongoDB, Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#pragma once

#include <mongocxx/options/auto_encryption-fwd.hpp> // IWYU pragma: export

//

#include <mongocxx/v1/client-fwd.hpp>
#include <mongocxx/v1/pool-fwd.hpp>

#include <mongocxx/v1/auto_encryption_options.hpp> // IWYU pragma: export

#include <string> // IWYU pragma: keep: backward compatibility, to be removed.
#include <utility>

#include <mongocxx/client-fwd.hpp>
#include <mongocxx/pool-fwd.hpp>

#include <bsoncxx/document/view_or_value.hpp>
#include <bsoncxx/stdx/optional.hpp>

#include <mongocxx/config/prelude.hpp>

namespace mongocxx {
namespace v_noabi {
namespace options {

///
/// Used by @ref mongocxx::v_noabi::options::client::auto_encryption_opts.
///
class auto_encryption {
   public:
    ///
    /// Default constructs a new auto_encryption object.
    ///
    auto_encryption() noexcept {}

    ///
    /// When the key vault collection is on a separate MongoDB cluster,
    /// sets the optional client to use to route data key queries to
    /// that cluster.
    ///
    /// The given key vault client MUST outlive any client that has
    /// been enabled to use it through these options.
    ///
    /// @param client
    ///   A client to use for routing queries to the key vault collection.
    ///
    /// @return
    ///   A reference to this object to facilitate method chaining.
    ///
    /// @see
    /// - https://www.mongodb.com/docs/manual/core/security-client-side-encryption/
    ///
    auto_encryption& key_vault_client(v_noabi::client* client) {
        _key_vault_client = client;
        return *this;
    }

    ///
    /// Gets the key vault client.
    ///
    /// @return
    ///   An optional pointer to the key vault client.
    ///
    bsoncxx::v_noabi::stdx::optional<v_noabi::client*> const& key_vault_client() const {
        return _key_vault_client;
    }

    ///
    /// When the key vault collection is on a separate MongoDB cluster,
    /// sets the optional client pool to use to route data key queries to
    /// that cluster.
    ///
    /// This option may not be used if a key_vault_client is set.
    ///
    /// The given key vault pool MUST outlive any pool that has
    /// been enabled to use it through these options.
    ///
    /// May only be set when enabling automatic encryption on a pool.
    ///
    /// @param pool
    ///   A pool to use for routing queries to the key vault collection.
    ///
    /// @return
    ///   A reference to this object to facilitate method chaining.
    ///
    /// @see
    /// - https://www.mongodb.com/docs/manual/core/security-client-side-encryption/
    ///
    auto_encryption& key_vault_pool(v_noabi::pool* pool) {
        _key_vault_pool = pool;
        return *this;
    }

    ///
    /// Gets the key vault pool.
    ///
    /// @return
    ///   An optional pointer to the key vault pool.
    ///
    bsoncxx::v_noabi::stdx::optional<v_noabi::pool*> const& key_vault_pool() const {
        return _key_vault_pool;
    }

    ///
    /// Represents the name of a database and a collection.
    ///
    using ns_pair = v1::auto_encryption_options::ns_pair;

    ///
    /// Sets the namespace to use to access the key vault collection, which
    /// contains all data keys used for encryption and decryption. This
    /// option must be set:
    ///
    ///   auto_encryption.key_vault_namespace({ "db", "coll" });
    ///
    /// @param ns
    ///   A std::pair of strings representing the db and collection to use
    ///   to access the key vault.
    ///
    /// @return
    ///   A reference to this object to facilitate method chaining.
    ///
    /// @see
    /// - https://www.mongodb.com/docs/manual/core/security-client-side-encryption/
    ///
    auto_encryption& key_vault_namespace(ns_pair ns) {
        _key_vault_namespace = std::move(ns);
        return *this;
    }

    ///
    /// Gets the key vault namespace.
    ///
    /// @return
    ///   An optional pair of strings representing the namespace of the
    ///   key vault collection.
    ///
    bsoncxx::v_noabi::stdx::optional<ns_pair> const& key_vault_namespace() const {
        return _key_vault_namespace;
    }

    ///
    /// Sets the KMS providers to use for client side encryption.
    ///
    /// Multiple KMS providers may be specified. KMS providers are specified as a string of the form
    /// `<KMS-provider-type>` or `<KMS-provider-type>:<KMS-provider-name>`. The supported KMS provider types are `aws`,
    /// `azure`, `gcp`, `local`, and `kmip`. The optional name enables configuring multiple KMS providers with the same
    /// KMS provider type (e.g. `aws:name1` and `aws:name2` can refer to different AWS accounts). At least one KMS
    /// provider must be specified.
    ///
    /// Supported forms of the KMS provider type `aws` include:
    ///
    /// ```
    /// aws: {
    ///    accessKeyId: String,
    ///    secretAccessKey: String
    /// }
    ///
    /// // To pass temporary credentials:
    /// aws: {
    ///    accessKeyId: String,
    ///    secretAccessKey: String,
    ///    sessionToken: String
    /// }
    ///
    /// // To request credentials from the environment:
    /// aws: {}
    /// ```
    ///
    /// Supported forms of the KMS provider type `local` include:
    /// ```
    /// local: {
    ///    // key is used to encrypt/decrypt data keys:
    ///    key: "<96 byte BSON binary of subtype 0>" or String // May be passed as a base64 encoded string.
    /// }
    /// ```
    ///
    /// Supported forms of the KMS provider type `azure` include:
    /// ```
    /// azure: {
    ///    tenantId: String,
    ///    clientId: String,
    ///    clientSecret: String,
    ///    identityPlatformEndpoint: Optional<String> // Defaults to login.microsoftonline.com
    /// }
    ///
    /// // To pass an accessToken directly:
    /// azure: {
    ///    accessToken: String
    /// }
    ///
    /// // To request credentials from the environment:
    /// azure: {}
    /// ```
    ///
    /// Supported forms of the KMS provider type `gcp` include:
    /// ```
    /// gcp: {
    ///    email: String,
    ///    privateKey: byte[] or String, // May be passed as a base64 encoded string.
    ///    endpoint: Optional<String> // Defaults to oauth2.googleapis.com
    /// }
    ///
    /// // To pass an accessToken directly:
    /// gcp: {
    ///    accessToken: String
    /// }
    ///
    /// // To request credentials from the environment:
    /// gcp: {}
    /// ```
    ///
    /// Supported forms of the KMS provider type `kmip` include:
    /// ```
    /// kmip: {
    ///    endpoint: String
    /// }
    /// ```
    ///
    /// KMS providers may include an optional name suffix separated with a colon. This enables configuring multiple KMS
    /// providers with the same KMS provider type. Example:
    /// ```
    /// "aws:name1": {
    ///    accessKeyId: String,
    ///    secretAccessKey: String
    /// },
    /// "aws:name2": {
    ///    accessKeyId: String,
    ///    secretAccessKey: String
    /// }
    /// ```
    ///
    /// @param kms_providers
    ///   A document containing the KMS providers.
    ///
    /// @return
    ///   A reference to this object to facilitate method chaining.
    ///
    /// @see
    /// - https://www.mongodb.com/docs/manual/core/security-client-side-encryption/
    ///
    auto_encryption& kms_providers(bsoncxx::v_noabi::document::view_or_value kms_providers) {
        _kms_providers = std::move(kms_providers);
        return *this;
    }

    ///
    /// Gets the KMS providers.
    ///
    /// @return
    ///   An optional document containing the KMS providers.
    ///
    bsoncxx::v_noabi::stdx::optional<bsoncxx::v_noabi::document::view_or_value> const& kms_providers() const {
        return _kms_providers;
    }

    ///
    /// Sets the TLS options to use for client side encryption with a given KMS provider.
    ///
    /// Multiple KMS providers may be specified. Supported KMS providers are "aws", "azure", "gcp",
    /// and "kmip". The map value has the same form for all supported providers:
    ///
    /// ```
    /// <KMS provider name>: {
    ///     tlsCaFile: Optional<String>
    ///     tlsCertificateKeyFile: Optional<String>
    ///     tlsCertificateKeyFilePassword: Optional<String>
    /// }
    /// ```
    ///
    /// @param tls_opts
    ///   A document containing the TLS options.
    ///
    /// @return
    ///   A reference to this object to facilitate method chaining.
    ///
    /// @see
    /// - https://www.mongodb.com/docs/manual/core/security-client-side-encryption/
    ///
    auto_encryption& tls_opts(bsoncxx::v_noabi::document::view_or_value tls_opts) {
        _tls_opts = std::move(tls_opts);
        return *this;
    }

    ///
    /// Gets the TLS options.
    ///
    /// @return
    ///   An optional document containing the TLS options.
    ///
    bsoncxx::v_noabi::stdx::optional<bsoncxx::v_noabi::document::view_or_value> const& tls_opts() const {
        return _tls_opts;
    }

    ///
    /// Sets a local JSON schema.
    ///
    /// Supplying a schemaMap provides more security than relying on
    /// JSON schemas obtained from the server. It protects against a
    /// malicious server advertising a false JSON Schema, which could
    /// trick the client into sending unencrypted data that should be
    /// encrypted.
    ///
    /// Schemas supplied in the schemaMap only apply to configuring
    /// automatic encryption for client side encryption. Other validation
    /// rules in the JSON schema will not be enforced by the driver and
    /// will result in an error.
    ///
    /// @param schema_map
    ///   The JSON schema to use.
    ///
    /// @return
    ///   A reference to this object to facilitate method chaining.
    ///
    /// @see
    /// - https://www.mongodb.com/docs/manual/core/security-client-side-encryption/
    ///
    auto_encryption& schema_map(bsoncxx::v_noabi::document::view_or_value schema_map) {
        _schema_map = std::move(schema_map);
        return *this;
    }

    ///
    /// Gets the schema map.
    ///
    /// @return
    ///   An optional document containing the schema map.
    ///
    bsoncxx::v_noabi::stdx::optional<bsoncxx::v_noabi::document::view_or_value> const& schema_map() const {
        return _schema_map;
    }

    ///
    /// Sets the local encrypted fields map.
    ///
    /// Supplying an encryptedFieldsMap provides more security than relying on
    /// an encryptedFields obtained from the server. It protects against a
    /// malicious server advertising a false encryptedFields.
    ///
    /// @param encrypted_fields_map
    ///   The mapping of which fields to encrypt.
    ///
    /// @see
    /// - https://www.mongodb.com/docs/manual/core/security-client-side-encryption/
    ///
    /// @return
    ///   A reference to this object to facilitate method chaining.
    ///
    /// @see
    /// - https://www.mongodb.com/docs/manual/core/security-client-side-encryption/
    ///
    auto_encryption& encrypted_fields_map(bsoncxx::v_noabi::document::view_or_value encrypted_fields_map) {
        _encrypted_fields_map = std::move(encrypted_fields_map);
        return *this;
    }

    ///
    /// Get encrypted fields map
    ///
    /// @return
    ///   An optional document containing the encrypted fields map
    ///
    bsoncxx::v_noabi::stdx::optional<bsoncxx::v_noabi::document::view_or_value> const& encrypted_fields_map() const {
        return _encrypted_fields_map;
    }

    ///
    /// Automatic encryption is disabled when the 'bypassAutoEncryption'
    /// option is true. Default is 'false,' so auto encryption is enabled.
    ///
    /// @param should_bypass
    ///   Whether or not to bypass automatic encryption.
    ///
    /// @return
    ///   A reference to this object to facilitate method chaining.
    ///
    /// @see
    /// - https://www.mongodb.com/docs/manual/core/security-client-side-encryption/
    ///
    auto_encryption& bypass_auto_encryption(bool should_bypass) {
        _bypass = should_bypass;
        return *this;
    }

    ///
    /// Gets a boolean specifying whether or not auto encryption is bypassed.
    ///
    /// @return
    ///   A boolean specifying whether auto encryption is bypassed.
    ///
    bool bypass_auto_encryption() const {
        return _bypass;
    }

    ///
    /// Query analysis is disabled when the 'bypassQueryAnalysis'
    /// option is true. Default is 'false' (i.e. query analysis is enabled).
    ///
    /// @param should_bypass
    ///   Whether or not to bypass query analysis.
    ///
    /// @return
    ///   A reference to this object to facilitate method chaining.
    ///
    /// @see
    /// - https://www.mongodb.com/docs/manual/core/security-client-side-encryption/
    ///
    auto_encryption& bypass_query_analysis(bool should_bypass) {
        _bypass_query_analysis = should_bypass;
        return *this;
    }

    ///
    /// Gets a boolean specifying whether or not query analysis is bypassed.
    ///
    /// @return
    ///   A boolean specifying whether query analysis is bypassed.
    ///
    bool bypass_query_analysis() const {
        return _bypass_query_analysis;
    }

    ///
    /// Set extra options related to the mongocryptd process. This options
    /// document may include the following fields:
    ///
    /// - mongocryptdURI: string, defaults to "mongodb://localhost:27020".
    ///
    /// - mongocryptdBypassSpawn: bool, defaults to false.
    ///
    /// - mongocryptdSpawnPath: string, defaults to "" and spawns mongocryptd
    ///   from the system path.
    ///
    /// - mongocryptdSpawnArgs: array[strings], options passed to mongocryptd
    ///   when spawing. Defaults to ["--idleShutdownTimeoutSecs=60"].
    ///
    /// - cryptSharedLibPath - Set a filepath string referring to a crypt_shared library file. Unset
    ///   by default. If not set (the default), libmongocrypt will attempt to load crypt_shared
    ///   using the host system’s default dynamic-library-search system.
    ///
    ///   If set, the given path should identify the crypt_shared dynamic library file itself, not
    ///   the directory that contains it.
    ///
    ///   If the given path is a relative path and the first path component is $ORIGIN, the $ORIGIN
    ///   component will be replaced with the absolute path to the directory containing the
    ///   libmongocrypt library in use by the application.
    ///
    ///   Note No other RPATH/RUNPATH-style substitutions are available.
    ///   If the given path is a relative path, the path will be resolved relative to the working
    ///   directory of the operating system process.
    ///
    ///   If this option is set and libmongocrypt fails to load crypt_shared from the given
    ///   filepath, libmongocrypt will fail to initialize and will not attempt to search for
    ///   crypt_shared in any other locations.
    ///
    /// - cryptSharedLibRequired - If set to true, and libmongocrypt fails to load a crypt_shared
    ///   library, initialization of auto-encryption will fail immediately and will not attempt to
    ///   spawn mongocryptd.
    ///
    ///   If set to false (the default), cryptSharedLibPath is not set, and libmongocrypt fails to
    ///   load crypt_shared, then libmongocrypt will proceed without crypt_shared and fall back to
    ///   using mongocryptd.
    ///
    /// @param extra
    ///   The extra options to set.
    ///
    /// @return
    ///   A reference to this object to facilitate method chaining.
    ///
    /// @see
    /// - https://www.mongodb.com/docs/manual/core/security-client-side-encryption/
    ///
    auto_encryption& extra_options(bsoncxx::v_noabi::document::view_or_value extra) {
        _extra_options = std::move(extra);
        return *this;
    }

    ///
    /// Gets extra options related to the mongocryptd process.
    ///
    /// @return
    ///   An optional document containing the extra options.
    ///
    bsoncxx::v_noabi::stdx::optional<bsoncxx::v_noabi::document::view_or_value> const& extra_options() const {
        return _extra_options;
    }

    class internal;

   private:
    bool _bypass = false;
    bool _bypass_query_analysis = false;
    bsoncxx::v_noabi::stdx::optional<v_noabi::client*> _key_vault_client;
    bsoncxx::v_noabi::stdx::optional<v_noabi::pool*> _key_vault_pool;
    bsoncxx::v_noabi::stdx::optional<ns_pair> _key_vault_namespace;
    bsoncxx::v_noabi::stdx::optional<bsoncxx::v_noabi::document::view_or_value> _kms_providers;
    bsoncxx::v_noabi::stdx::optional<bsoncxx::v_noabi::document::view_or_value> _tls_opts;
    bsoncxx::v_noabi::stdx::optional<bsoncxx::v_noabi::document::view_or_value> _schema_map;
    bsoncxx::v_noabi::stdx::optional<bsoncxx::v_noabi::document::view_or_value> _encrypted_fields_map;
    bsoncxx::v_noabi::stdx::optional<bsoncxx::v_noabi::document::view_or_value> _extra_options;

    /* explicit(false) */ auto_encryption(v1::auto_encryption_options opts);

    explicit operator v1::auto_encryption_options() const;
};

} // namespace options
} // namespace v_noabi
} // namespace mongocxx

namespace mongocxx {
namespace v_noabi {

///
/// Convert to the @ref mongocxx::v_noabi equivalent of `v`.
///
/// @important The `key_vault_client` and `key_vault_pool` fields in the resulting object are unset when not explicitly
/// provided as an argument to this conversion function.
///
/// @{
MONGOCXX_ABI_EXPORT_CDECL_UNSTABLE(v_noabi::options::auto_encryption) from_v1(v1::auto_encryption_options v);

inline v_noabi::options::auto_encryption from_v1(v1::auto_encryption_options v, v_noabi::client* client) {
    auto ret = from_v1(std::move(v));
    ret.key_vault_client(client);
    return ret;
}

inline v_noabi::options::auto_encryption from_v1(v1::auto_encryption_options v, v_noabi::pool* pool) {
    auto ret = from_v1(std::move(v));
    ret.key_vault_pool(pool);
    return ret;
}
/// @}
///

///
/// Convert to the @ref mongocxx::v1 equivalent of `v`.
///
/// @important The `key_vault_client` and `key_vault_pool` fields in the resulting object are unset when not explicitly
/// provided as an argument to this conversion function.
///
/// @{
MONGOCXX_ABI_EXPORT_CDECL_UNSTABLE(v1::auto_encryption_options) to_v1(v_noabi::options::auto_encryption const& v);

inline v1::auto_encryption_options to_v1(v_noabi::options::auto_encryption const& v, v1::client* client) {
    auto ret = to_v1(v);
    ret.key_vault_client(client);
    return ret;
}

inline v1::auto_encryption_options to_v1(v_noabi::options::auto_encryption const& v, v1::pool* pool) {
    auto ret = to_v1(v);
    ret.key_vault_pool(pool);
    return ret;
}
/// @}
///

} // namespace v_noabi
} // namespace mongocxx

#include <mongocxx/config/postlude.hpp>

///
/// @file
/// Provides @ref mongocxx::v_noabi::options::auto_encryption.
///
/// @par Includes
/// - @ref mongocxx/v1/auto_encryption_options.hpp
///
