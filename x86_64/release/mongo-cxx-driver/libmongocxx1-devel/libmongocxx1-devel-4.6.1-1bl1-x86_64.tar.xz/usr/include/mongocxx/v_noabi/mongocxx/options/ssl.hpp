// Copyright 2009-present MongoDB, Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#pragma once

#include <string> // IWYU pragma: keep: backward compatibility, to be removed.

#include <mongocxx/options/tls.hpp> // IWYU pragma: export

#include <mongocxx/config/prelude.hpp>

namespace mongocxx {
namespace v_noabi {
namespace options {

///
/// Equivalent to @ref mongocxx::v_noabi::options::tls.
///
/// To be removed in an upcoming major release.
///
/// @deprecated Use @ref mongocxx::v_noabi::options::tls instead.
///
MONGOCXX_DEPRECATED typedef tls ssl;

} // namespace options
} // namespace v_noabi
} // namespace mongocxx

#include <mongocxx/config/postlude.hpp>

///
/// @file
/// Provides @ref mongocxx::v_noabi::options::ssl.
///
/// @deprecated Use @ref mongocxx/v_noabi/mongocxx/options/tls.hpp instead.
///
