// Copyright 2009-present MongoDB, Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#pragma once

#include <mongocxx/pipeline-fwd.hpp> // IWYU pragma: export

//

#include <mongocxx/v1/pipeline.hpp> // IWYU pragma: export

#include <cstdint>
#include <memory> // IWYU pragma: keep: backward compatibility, to be removed.
#include <string>
#include <utility>

#include <mongocxx/client-fwd.hpp>     // IWYU pragma: keep: backward compatibility, to be removed.
#include <mongocxx/collection-fwd.hpp> // IWYU pragma: keep: backward compatibility, to be removed.
#include <mongocxx/database-fwd.hpp>   // IWYU pragma: keep: backward compatibility, to be removed.

#include <bsoncxx/array/view.hpp>
#include <bsoncxx/array/view_or_value.hpp>
#include <bsoncxx/document/view.hpp>
#include <bsoncxx/document/view_or_value.hpp>

#include <mongocxx/config/prelude.hpp>

namespace mongocxx {
namespace v_noabi {

///
/// A MongoDB aggregation pipeline.
///
class pipeline {
   private:
    v1::pipeline _pipeline;

   public:
    ///
    /// Creates a new aggregation pipeline.
    ///
    /// @see
    /// - https://www.mongodb.com/docs/manual/core/aggregation-pipeline/
    ///
    pipeline() = default;

    ///
    /// Move constructs a pipeline.
    ///
    pipeline(pipeline&& other) noexcept = default;

    ///
    /// Move assigns a pipeline.
    ///
    pipeline& operator=(pipeline&& other) noexcept = default;

    ///
    /// Destroys a pipeline.
    ///
    ~pipeline() = default;

    pipeline(pipeline const& other) = delete;
    pipeline& operator=(pipeline const& other) = delete;

    ///
    /// Construct with the @ref mongocxx::v1 equivalent.
    ///
    /* explicit(false) */ pipeline(v1::pipeline pipeline) : _pipeline{std::move(pipeline)} {}

    ///
    /// Convert to the @ref mongocxx::v1 equivalent.
    ///
    /// @par Postconditions:
    /// - `*this` is in an assign-or-destroy-only state.
    ///
    /// @warning Invalidates all associated views.
    ///
    explicit operator v1::pipeline() && {
        return std::move(_pipeline);
    }

    ///
    /// Convert to the @ref mongocxx::v1 equivalent.
    ///
    explicit operator v1::pipeline() const& {
        return _pipeline;
    }

    ///
    /// Adds new fields to documents.
    ///
    /// @see
    /// - https://www.mongodb.com/docs/manual/reference/operator/aggregation/addFields/
    ///
    /// @param fields_to_add
    ///   A document specifying the fields to add.  For each field specified in this parameter, a
    ///   corresponding field will be added to the documents, where the value of the added field is
    ///   the result of evaluating the specified expression.
    ///
    /// @return
    ///   A reference to the object on which this member function is being called.  This facilitates
    ///   method chaining.
    ///
    pipeline& add_fields(bsoncxx::v_noabi::document::view_or_value fields_to_add) {
        _pipeline.add_fields(bsoncxx::v_noabi::to_v1(fields_to_add.view()));
        return *this;
    }

    ///
    /// Categorizes documents into groups, called buckets, based on a specified expression and
    /// bucket boundaries.
    ///
    /// @see
    /// - https://www.mongodb.com/docs/manual/reference/operator/aggregation/bucket/
    ///
    /// @param bucket_args
    ///   The specification for the bucket operation.  The required fields `groupBy` and
    ///   `boundaries` must be included.
    ///
    /// @return
    ///   A reference to the object on which this member function is being called.  This facilitates
    ///   method chaining.
    ///
    pipeline& bucket(bsoncxx::v_noabi::document::view_or_value bucket_args) {
        _pipeline.bucket(bsoncxx::v_noabi::to_v1(bucket_args.view()));
        return *this;
    }

    ///
    /// Categorizes documents into a specific number of groups, called buckets, based on a
    /// specified expression.  Bucket boundaries are automatically determined in an attempt to
    /// evenly distribute the documents into the specified number of buckets.
    ///
    /// @see
    /// - https://www.mongodb.com/docs/manual/reference/operator/aggregation/bucketAuto/
    ///
    /// @param bucket_auto_args
    ///   The specification for the bucket_auto operation.  This required fields `groupBy` and
    ///   `buckets` must be included.
    ///
    /// @return
    ///   A reference to the object on which this member function is being called.  This facilitates
    ///   method chaining.
    ///
    pipeline& bucket_auto(bsoncxx::v_noabi::document::view_or_value bucket_auto_args) {
        _pipeline.bucket_auto(bsoncxx::v_noabi::to_v1(bucket_auto_args.view()));
        return *this;
    }

    ///
    /// Returns statistics regarding a collection or view.
    ///
    /// @see
    /// - https://www.mongodb.com/docs/manual/reference/operator/aggregation/collStats/
    ///
    /// @param coll_stats_args
    ///   The specification for the coll_stats operation.  See link above for a list of valid
    ///   options.
    ///
    /// @return
    ///   A reference to the object on which this member function is being called.  This facilitates
    ///   method chaining.
    ///
    pipeline& coll_stats(
        bsoncxx::v_noabi::document::view_or_value coll_stats_args = bsoncxx::v_noabi::document::view{}) {
        _pipeline.coll_stats(bsoncxx::v_noabi::to_v1(coll_stats_args.view()));
        return *this;
    }

    ///
    /// Returns a document containing a count of the number of documents input to the stage.
    ///
    /// @see
    /// - https://www.mongodb.com/docs/manual/reference/operator/aggregation/count/
    ///
    /// @param field
    ///   Name of the field for the count to be written to.
    ///
    /// @return
    ///   A reference to the object on which this member function is being called.  This facilitates
    ///   method chaining.
    ///
    pipeline& count(std::string field) {
        _pipeline.count(field);
        return *this;
    }

    ///
    /// Returns a stream of documents containing information on active and/or dormant
    /// operations as well as inactive sessions that are holding locks as part of a
    /// transaction. The stage returns a document for each operation or session.
    ///
    /// This stage must be used with database aggregate on the 'admin' database.
    ///
    /// @see
    /// - https://www.mongodb.com/docs/manual/reference/operator/aggregation/currentOp/
    ///
    /// @param current_op_args
    ///   A document containing the arguments for the current_op operation.
    ///
    /// @return
    ///   A reference to the object on which this method is being called.
    ///
    pipeline& current_op(bsoncxx::v_noabi::document::view_or_value current_op_args) {
        _pipeline.current_op(bsoncxx::v_noabi::to_v1(current_op_args.view()));
        return *this;
    }

    ///
    /// Processes multiple aggregation pipelines within a single stage on the same set of input
    /// documents.
    ///
    /// @see
    /// - https://www.mongodb.com/docs/manual/reference/operator/aggregation/facet/
    ///
    /// @param facet_args
    ///   The specification for the facet operation.  Each field in the the provided document should
    ///   specify an aggregation pipeline, as an array.
    ///
    /// @return
    ///   A reference to the object on which this member function is being called.  This facilitates
    ///   method chaining.
    ///
    pipeline& facet(bsoncxx::v_noabi::document::view_or_value facet_args) {
        _pipeline.facet(bsoncxx::v_noabi::to_v1(facet_args.view()));
        return *this;
    }

    ///
    /// Appends a stage to this pipeline object.
    ///
    /// Use this method to run new pipeline stages that are not yet offered as
    /// explicit methods on this class. Pass in a document describing a
    /// pipeline stage:
    ///
    ///    { "$addFields" : { "field" : 0 }}
    ///
    /// @param stage
    ///   A bson document view or value describing a pipeline stage.
    ///
    /// @return
    ///   A reference to this object on which this member function is being called.
    ///
    pipeline& append_stage(bsoncxx::v_noabi::document::view_or_value stage) {
        _pipeline.append_stage(bsoncxx::v_noabi::to_v1(stage.view()));
        return *this;
    }

    ///
    /// Appends stages to this pipeline object from the given bson array.
    ///
    /// Use this method to run new pipeline stages that are not yet offered as
    /// explicit methods on this class. Pass in an array of documents, where each
    /// document in the array describes a pipeline stage:
    ///
    ///    [ { "$addFields" : { "field" : 0 } }, { "$newStage" : ... }, ... ]
    ///
    /// @param stages
    ///   A bson array containing documents describing pipeline stages.
    ///
    /// @return
    ///   A reference to the object on which this member function is being called.
    ///
    pipeline& append_stages(bsoncxx::v_noabi::array::view_or_value stages) {
        _pipeline.append_stages(bsoncxx::v_noabi::to_v1(stages.view()));
        return *this;
    }

    ///
    /// Outputs documents in order of nearest to farthest from a specified point.
    ///
    /// @see
    /// - https://www.mongodb.com/docs/manual/reference/operator/aggregation/geoNear/
    ///
    /// @param geo_near_args
    ///   The specification for the geo_near operation.  The required fields `near` and
    ///   `distanceField` must be included.
    ///
    /// @return
    ///   A reference to the object on which this member function is being called.  This facilitates
    ///   method chaining.
    ///
    pipeline& geo_near(bsoncxx::v_noabi::document::view_or_value geo_near_args) {
        _pipeline.geo_near(bsoncxx::v_noabi::to_v1(geo_near_args.view()));
        return *this;
    }

    ///
    /// Performs a recursive search on a collection.
    ///
    /// @see
    /// - https://www.mongodb.com/docs/manual/reference/operator/aggregation/graphLookup/
    ///
    /// @param graph_lookup_args
    ///   The specification for the graph_lookup operation.  The required fields `from`,
    ///   `connectFromField`, `startWith`, `connectToField`, and `as` must be included.
    ///
    /// @return
    ///   A reference to the object on which this member function is being called.  This facilitates
    ///   method chaining.
    ///
    pipeline& graph_lookup(bsoncxx::v_noabi::document::view_or_value graph_lookup_args) {
        _pipeline.graph_lookup(bsoncxx::v_noabi::to_v1(graph_lookup_args.view()));
        return *this;
    }

    ///
    /// Groups documents by some specified expression and outputs to the next stage a
    /// document for each distinct grouping. The output documents contain an `_id` field
    /// which contains the the distinct key for that group. The output documents can also
    /// contain computed fields that hold the values of some accumulator expression grouped
    /// by the group's `_id` field.
    ///
    /// @note group does not order output documents.
    ///
    /// @see
    /// - https://www.mongodb.com/docs/manual/reference/operator/aggregation/group/
    ///
    /// @param group_args
    ///   The specification for the group operation.  The required field `_id` must be included.
    ///
    /// @return
    ///   A reference to the object on which this member function is being called.  This facilitates
    ///   method chaining.
    ///
    pipeline& group(bsoncxx::v_noabi::document::view_or_value group_args) {
        _pipeline.group(bsoncxx::v_noabi::to_v1(group_args.view()));
        return *this;
    }

    ///
    /// Returns statistics regarding the use of each index for the collection.
    ///
    /// @return
    ///   A reference to the object on which this member function is being called.  This facilitates
    ///   method chaining.
    ///
    /// @see
    /// - https://www.mongodb.com/docs/manual/reference/operator/aggregation/indexStats/
    ///
    pipeline& index_stats() {
        _pipeline.index_stats();
        return *this;
    }

    ///
    /// Limits the number of documents passed to the next stage in the pipeline.
    ///
    /// @see
    /// - https://www.mongodb.com/docs/manual/reference/operator/aggregation/limit/
    ///
    /// @param limit
    ///   The number of documents to which output should be limited.
    ///
    /// @return
    ///   A reference to the object on which this member function is being called.  This facilitates
    ///   method chaining.
    ///
    pipeline& limit(std::int32_t limit) {
        _pipeline.limit(limit);
        return *this;
    }

    ///
    /// Lists the sessions cached in memory by the mongod or mongos instance.
    ///
    /// This option must be used with database aggregate.
    ///
    /// @see
    /// - https://www.mongodb.com/docs/manual/reference/operator/aggregation/listLocalSessions/
    ///
    /// @param list_local_sessions_args
    ///   A document containing the arguments for list_local_sessions.
    ///
    /// @return
    ///   A reference to the object on which this method is being called.
    ///
    pipeline& list_local_sessions(bsoncxx::v_noabi::document::view_or_value list_local_sessions_args) {
        _pipeline.list_local_sessions(bsoncxx::v_noabi::to_v1(list_local_sessions_args.view()));
        return *this;
    }

    ///
    /// Lists all sessions stored in the system.sessions collection in the config database.
    /// These sessions are visible to all members of the MongoDB deployment.
    ///
    /// @see
    /// - https://www.mongodb.com/docs/manual/reference/operator/aggregation/listSessions/
    ///
    /// @param list_sessions_args
    ///   A document containing the arguments for list_sessions.
    ///
    /// @return
    ///   A reference to the object on which this method is being called.
    ///
    pipeline& list_sessions(bsoncxx::v_noabi::document::view_or_value list_sessions_args) {
        _pipeline.list_sessions(bsoncxx::v_noabi::to_v1(list_sessions_args.view()));
        return *this;
    }

    ///
    /// Performs a left outer join to an unsharded collection in the same database to filter in
    /// documents from the "joined" collection for processing.
    ///
    /// @see
    /// - https://www.mongodb.com/docs/manual/reference/operator/aggregation/lookup/
    ///
    /// @param lookup_args
    ///   The specification for the lookup operation.  The required fields `from`, `localField`,
    ///   `foreignField`, and `as` must be included.
    ///
    /// @return
    ///   A reference to the object on which this member function is being called.  This facilitates
    ///   method chaining.
    ///
    pipeline& lookup(bsoncxx::v_noabi::document::view_or_value lookup_args) {
        _pipeline.lookup(bsoncxx::v_noabi::to_v1(lookup_args.view()));
        return *this;
    }

    ///
    /// Filters the documents. Only the documents that match the condition(s) specified by the
    /// `filter` will continue to the next pipeline stage.
    ///
    /// @see
    /// - https://www.mongodb.com/docs/manual/reference/operator/aggregation/match/
    ///
    /// @param filter
    ///   The filter.
    ///
    /// @return
    ///   A reference to the object on which this member function is being called.  This facilitates
    ///   method chaining.
    ///
    pipeline& match(bsoncxx::v_noabi::document::view_or_value filter) {
        _pipeline.match(bsoncxx::v_noabi::to_v1(filter.view()));
        return *this;
    }

    ///
    /// Outputs the aggregation results to a collection.
    ///
    /// @see
    /// - https://www.mongodb.com/docs/manual/reference/operator/aggregation/merge/
    ///
    /// @param merge_args
    ///   The specification for the merge options. Must include an `into` field that
    ///   is either a collection name or a subdocument of the form:
    ///   { `db` : &lt;db name&gt;, `coll` : &lt;collection name&gt; }.
    ///
    /// @return
    ///   A reference to the object on which this member function is being called.
    ///
    pipeline& merge(bsoncxx::v_noabi::document::view_or_value merge_args) {
        _pipeline.merge(bsoncxx::v_noabi::to_v1(merge_args.view()));
        return *this;
    }

    ///
    /// Takes documents returned by the aggregation pipeline and writes them to a specified
    /// collection. This stage must be the last stage in the pipeline. The out operator lets the
    /// aggregation framework return result sets of any size.
    ///
    /// @see
    /// - https://www.mongodb.com/docs/manual/reference/operator/aggregation/out/
    ///
    /// @param collection_name
    ///   The name of the collection where the output documents should go.
    ///
    /// @return
    ///   A reference to the object on which this member function is being called.  This facilitates
    ///   method chaining.
    ///
    pipeline& out(std::string collection_name) {
        _pipeline.out(collection_name);
        return *this;
    }

    ///
    /// Projects a subset of the fields in the documents to the next stage of the pipeline.
    ///
    /// @see
    /// - https://www.mongodb.com/docs/manual/reference/operator/aggregation/project/
    ///
    /// @param projection
    ///   The projection specification.
    ///
    /// @return
    ///   A reference to the object on which this member function is being called.  This facilitates
    ///   method chaining.
    ///
    pipeline& project(bsoncxx::v_noabi::document::view_or_value projection) {
        _pipeline.project(bsoncxx::v_noabi::to_v1(projection.view()));
        return *this;
    }

    ///
    /// Restricts the contents of the documents based on information stored in the documents
    /// themselves.
    ///
    /// @see
    /// - https://www.mongodb.com/docs/manual/reference/operator/aggregation/redact/
    ///
    /// @param restrictions
    ///   The document restrictions.
    ///
    /// @return
    ///   A reference to the object on which this member function is being called.  This facilitates
    ///   method chaining.
    ///
    pipeline& redact(bsoncxx::v_noabi::document::view_or_value restrictions) {
        _pipeline.redact(bsoncxx::v_noabi::to_v1(restrictions.view()));
        return *this;
    }

    ///
    /// Promotes a specified document to the top level and replaces all other fields.
    ///
    /// @see
    /// - https://www.mongodb.com/docs/manual/reference/operator/aggregation/replaceRoot/
    ///
    /// @param replace_root_args
    ///   The specification for the replace_root operation.  The required field `newRoot` must be
    ///   included.
    ///
    /// @return
    ///   A reference to the object on which this member function is being called.  This facilitates
    ///   method chaining.
    ///
    pipeline& replace_root(bsoncxx::v_noabi::document::view_or_value replace_root_args) {
        _pipeline.replace_root(bsoncxx::v_noabi::to_v1(replace_root_args.view()));
        return *this;
    }

    ///
    /// Randomly selects the specified number of documents that pass into the stage and passes the
    /// remaining documents to the next stage in the pipeline.
    ///
    /// @see
    /// - https://www.mongodb.com/docs/manual/reference/operator/aggregation/sample/
    ///
    /// @param size
    ///   The number of input documents to select.
    ///
    /// @return
    ///   A reference to the object on which this member function is being called.  This facilitates
    ///   method chaining.
    ///
    pipeline& sample(std::int32_t size) {
        _pipeline.sample(size);
        return *this;
    }

    ///
    /// Skips over the specified number of documents that pass into the stage and passes the
    /// remaining documents to the next stage in the pipeline.
    ///
    /// @see
    /// - https://www.mongodb.com/docs/manual/reference/operator/aggregation/skip/
    ///
    /// @param docs_to_skip
    ///   The number of input documents to skip.
    ///
    /// @return
    ///   A reference to the object on which this member function is being called.  This facilitates
    ///   method chaining.
    ///
    pipeline& skip(std::int32_t docs_to_skip) {
        _pipeline.skip(docs_to_skip);
        return *this;
    }

    ///
    /// Sorts all input documents and returns them to the pipeline in sorted order.
    ///
    /// @see
    /// - https://www.mongodb.com/docs/manual/reference/operator/aggregation/sort/
    ///
    /// @param ordering
    ///   Document specifying the ordering by which the documents are sorted.
    ///
    /// @return
    ///   A reference to the object on which this member function is being called.  This facilitates
    ///   method chaining.
    ///
    pipeline& sort(bsoncxx::v_noabi::document::view_or_value ordering) {
        _pipeline.sort(bsoncxx::v_noabi::to_v1(ordering.view()));
        return *this;
    }

    ///
    /// Groups incoming documents based on the value of a specified expression, then computes the
    /// count of documents in each distinct group.
    ///
    /// @see
    /// - https://www.mongodb.com/docs/manual/reference/operator/aggregation/sortByCount/
    ///
    /// @param field_expression
    ///   The expression to group by, as an object.  The expression can not evaluate to an object.
    ///
    /// @return
    ///   A reference to the object on which this member function is being called.  This facilitates
    ///   method chaining.
    ///
    /// @note
    ///   This overload of sort_by_count() is intended to be used when the desired sort is over a
    ///   grouping of the result of a complex expression computed from the input documents.
    ///
    pipeline& sort_by_count(bsoncxx::v_noabi::document::view_or_value field_expression) {
        _pipeline.sort_by_count(bsoncxx::v_noabi::to_v1(field_expression.view()));
        return *this;
    }

    ///
    /// Groups incoming documents based on the value of a specified expression, then computes the
    /// count of documents in each distinct group.
    ///
    /// @see
    /// - https://www.mongodb.com/docs/manual/reference/operator/aggregation/sortByCount/
    ///
    /// @param field_expression
    ///   The expression to group by, as a string.  To specify a field path, prefix the field path
    ///   with a dollar sign (`$`).
    ///
    /// @return
    ///   A reference to the object on which this member function is being called.  This facilitates
    ///   method chaining.
    ///
    /// @note
    ///   This overload of sort_by_count() is intended to be used when the desired sort is over a
    ///   grouping of the value of a particular element in the input documents.
    ///
    pipeline& sort_by_count(std::string field_expression) {
        _pipeline.sort_by_count(field_expression);
        return *this;
    }

    ///
    /// Deconstructs an array field from the input documents to output a document for each element.
    /// Each output document is an input document with the value of its array field replaced by
    /// an element from the unwound array.
    ///
    /// @see
    /// - https://www.mongodb.com/docs/manual/reference/operator/aggregation/unwind/
    ///
    /// @param unwind_args
    ///   The specification for the unwind operation.  The required field path must be included.
    ///
    /// @return
    ///   A reference to the object on which this member function is being called.  This facilitates
    ///   method chaining.
    ///
    /// @note
    ///   This overload of unwind() is intended to be used when additional options other than the
    ///   field name need to be specified.
    ///
    pipeline& unwind(bsoncxx::v_noabi::document::view_or_value unwind_args) {
        _pipeline.unwind(bsoncxx::v_noabi::to_v1(unwind_args.view()));
        return *this;
    }

    ///
    /// Deconstructs an array field from the input documents to output a document for each element.
    /// Each output document is an input document with the value of its array field replaced by
    /// an element from the unwound array.
    ///
    /// @see
    /// - https://www.mongodb.com/docs/manual/reference/operator/aggregation/unwind/
    ///
    /// @param field_name
    ///   The name of the field to unwind.
    ///
    /// @return
    ///   A reference to the object on which this member function is being called.  This facilitates
    ///   method chaining.
    ///
    /// @note
    ///   This overload of unwind() is intended to be used when no options other than the field name
    ///   need to be specified.
    ///
    pipeline& unwind(std::string field_name) {
        _pipeline.unwind(field_name);
        return *this;
    }

    ///
    /// @return A view of the underlying BSON array this pipeline represents.
    ///
    bsoncxx::v_noabi::array::view view_array() const {
        return _pipeline.view_array();
    }

    class internal;
};

///
/// Convert from the @ref mongocxx::v1 equivalent of `v`.
///
inline v_noabi::pipeline from_v1(v1::pipeline v) {
    return {std::move(v)};
}

///
/// Convert to the @ref mongocxx::v1 equivalent of `v`.
///
inline v1::pipeline to_v1(v_noabi::pipeline v) {
    return v1::pipeline{std::move(v)};
}

} // namespace v_noabi
} // namespace mongocxx

#include <mongocxx/config/postlude.hpp>

///
/// @file
/// Provides @ref mongocxx::v_noabi::pipeline.
///
