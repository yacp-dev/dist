// Copyright 2009-present MongoDB, Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#pragma once

#include <mongocxx/options/pool-fwd.hpp> // IWYU pragma: export

//

#include <mongocxx/v1/pool.hpp> // IWYU pragma: export

#include <utility>

#include <mongocxx/options/client.hpp>

#include <mongocxx/config/prelude.hpp>

namespace mongocxx {
namespace v_noabi {
namespace options {

///
/// Used by @ref mongocxx::v_noabi::pool.
///
class pool {
   public:
    ///
    /// Default initialization.
    ///
    pool() = default;

    ///
    /// Constructs a new pool options object. Note that options::pool is implictly convertible from
    /// options::client.
    ///
    /// @param client_opts
    ///   The client options.
    ///
    pool(v_noabi::options::client client_opts) : _client_opts{std::move(client_opts)} {}

    ///
    /// The current client options.
    ///
    /// @return The client options.
    ///
    v_noabi::options::client const& client_opts() const {
        return _client_opts;
    }

   private:
    v_noabi::options::client _client_opts;
};

} // namespace options
} // namespace v_noabi
} // namespace mongocxx

#include <mongocxx/config/postlude.hpp>

///
/// @file
/// Provides @ref mongocxx::v_noabi::options::pool.
///
/// @par Includes
/// - @ref mongocxx/v1/pool.hpp
///
