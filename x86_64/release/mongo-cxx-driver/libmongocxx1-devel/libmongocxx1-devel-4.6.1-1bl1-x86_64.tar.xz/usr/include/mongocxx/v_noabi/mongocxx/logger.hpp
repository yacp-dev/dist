// Copyright 2009-present MongoDB, Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#pragma once

#include <mongocxx/logger-fwd.hpp> // IWYU pragma: export

//

#include <mongocxx/v1/logger.hpp> // IWYU pragma: export

#include <mongocxx/config/prelude.hpp>

namespace mongocxx {
namespace v_noabi {

using v1::to_string;

using v1::log_handler;

using v1::set_global_logger;

} // namespace v_noabi
} // namespace mongocxx

namespace mongocxx {

using v1::to_string;

using v1::log_handler;

using v1::set_global_logger;

} // namespace mongocxx

#include <mongocxx/config/postlude.hpp>

///
/// @file
/// Provides utilities related to mongocxx logging.
///
/// @par Includes
/// - @ref mongocxx/v1/logger.hpp
///
