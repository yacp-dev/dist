// Copyright 2009-present MongoDB, Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#pragma once

#include <mongocxx/write_concern-fwd.hpp> // IWYU pragma: export

//

#include <mongocxx/v1/write_concern.hpp>

#include <chrono>
#include <cstdint>
#include <memory>    // IWYU pragma: keep: backward compatibility, to be removed.
#include <stdexcept> // IWYU pragma: keep: backward compatibility, to be removed.
#include <string>
#include <utility>

#include <mongocxx/bulk_write-fwd.hpp>          // IWYU pragma: keep: backward compatibility, to be removed.
#include <mongocxx/client-fwd.hpp>              // IWYU pragma: keep: backward compatibility, to be removed.
#include <mongocxx/collection-fwd.hpp>          // IWYU pragma: keep: backward compatibility, to be removed.
#include <mongocxx/database-fwd.hpp>            // IWYU pragma: keep: backward compatibility, to be removed.
#include <mongocxx/options/transaction-fwd.hpp> // IWYU pragma: keep: backward compatibility, to be removed.
#include <mongocxx/uri-fwd.hpp>                 // IWYU pragma: keep: backward compatibility, to be removed.

#include <bsoncxx/document/value.hpp>
#include <bsoncxx/stdx/optional.hpp>
#include <bsoncxx/stdx/string_view.hpp>

#include <mongocxx/options/transaction.hpp> // IWYU pragma: keep: backward compatibility, to be removed.

#include <mongocxx/config/prelude.hpp>

namespace mongocxx {
namespace v_noabi {

///
/// The level of acknowledgment requested for write operations to a MongoDB server.
///
/// @see
/// - [Write Concern (MongoDB Manual)](https://www.mongodb.com/docs/manual/core/write-concern/)
///
class write_concern {
   private:
    v1::write_concern _wc;

   public:
    ///
    /// A class to represent the write concern level for write operations.
    ///
    /// @see
    /// - [Write Concern (MongoDB Manual)](https://www.mongodb.com/docs/manual/reference/write-concern/)
    /// - [Default MongoDB Read Concerns/Write Concerns](https://www.mongodb.com/docs/manual/reference/mongodb-defaults/#write-concern)
    ///
    enum class level {
        k_default,        ///< Represent the implicit default write concern.
        k_majority,       ///< Represent write concern with `w: "majority"`.
        k_tag,            ///< Represent write concern with `w: <custom write concern name>`.
        k_unacknowledged, ///< Represent write concern with `w: 0`.
        k_acknowledged,   ///< Represent write concern with `w: 1`.
    };

    ///
    /// Constructs a new write_concern.
    ///
    write_concern() = default;

    ///
    /// Construct with the @ref mongocxx::v1 equivalent.
    ///
    /* explicit(false) */ write_concern(v1::write_concern rc) : _wc{std::move(rc)} {}

    ///
    /// Convert to the @ref mongocxx::v1 equivalent.
    ///
    /// @par Postconditions:
    /// - `*this` is in an assign-or-destroy-only state.
    ///
    /// @warning Invalidates all associated views.
    ///
    explicit operator v1::write_concern() && {
        return std::move(_wc);
    }

    ///
    /// Convert to the @ref mongocxx::v1 equivalent.
    ///
    explicit operator v1::write_concern() const& {
        return _wc;
    }

    ///
    /// Sets the journal parameter for this write concern.
    ///
    /// @param journal
    ///   If @c true confirms that the mongod instance has written the data to the on-disk journal
    ///   before reporting a write operations was successful. This ensures that data is not lost if
    ///   the mongod instance shuts down unexpectedly.
    ///
    void journal(bool journal) {
        _wc.journal(journal);
    }

    ///
    /// Sets the number of nodes that are required to acknowledge the write before the operation is
    /// considered successful. Write operations will block until they have been replicated to the
    /// specified number of servers in a replica set.
    ///
    /// @param confirm_from
    ///   The number of replica set nodes that must acknowledge the write.
    ///
    /// @warning Setting the number of nodes to 0 disables write acknowledgment and all other
    /// write concern options.
    ///
    /// @warning Setting the number of nodes required to an amount greater than the number of
    /// available nodes will cause writes using this write concern to block forever if no timeout
    /// is set.
    ///
    MONGOCXX_ABI_EXPORT_CDECL_UNSTABLE(void) nodes(std::int32_t confirm_from);

    ///
    /// Sets the acknowledge level.
    /// @see
    /// - https://www.mongodb.com/docs/manual/reference/write-concern/#w-option
    ///
    /// @param confirm_level
    ///   Either level::k_unacknowledged, level::k_acknowledged, level::k_default, or
    ///   level::k_majority.
    ///
    /// @note
    ///   the acknowledge level of level::k_tag is set automatically when a tag is set.
    ///
    /// @warning
    ///   Setting this to level::k_unacknowledged disables write acknowledgment and all other
    ///   write concern options.
    ///
    /// @warning
    ///   Unacknowledged writes using dollar-prefixed or dotted keys may be silently rejected by
    ///   pre-5.0 servers.
    ///
    /// @exception
    ///   Throws mongocxx::v_noabi::exception for setting a tag acknowledge level. Use tag()
    ///   instead.
    ///
    MONGOCXX_ABI_EXPORT_CDECL_UNSTABLE(void) acknowledge_level(level confirm_level);

    ///
    /// Requires that a majority of the nodes in a replica set acknowledge a write operation before
    /// it is considered a success.
    ///
    /// @param timeout
    ///   The amount of time to wait before the write operation times out if it cannot reach
    ///   the majority of nodes in the replica set. If the value is zero, then no timeout is set.
    ///
    /// @throws mongocxx::v_noabi::logic_error for an invalid timeout value.
    ///
    void majority(std::chrono::milliseconds timeout) {
        this->timeout(timeout);
        this->acknowledge_level(level::k_majority);
    }

    ///
    /// Sets the name representing the server-side getLastErrorMode entry containing the list of
    /// nodes that must acknowledge a write operation before it is considered a success.
    ///
    /// @note the acknowledge level of level::k_tag is set automatically when a tag is set.
    ///
    /// @param tag
    ///   The string representing on of the "getLastErrorModes" in the replica set configuration.
    ///
    void tag(bsoncxx::v_noabi::stdx::string_view tag) {
        _wc.tag(tag);
    }

    ///
    /// Sets an upper bound on the time a write concern can take to be satisfied. If the write
    /// concern cannot be satisfied within the timeout, the operation is considered a failure.
    ///
    /// @param timeout
    ///   The timeout (in milliseconds) for this write concern. If the value is zero, then no
    ///   timeout is set.
    ///
    /// @throws mongocxx::v_noabi::logic_error for an invalid timeout value.
    ///
    MONGOCXX_ABI_EXPORT_CDECL_UNSTABLE(void) timeout(std::chrono::milliseconds timeout);

    ///
    /// Gets the current status of the journal parameter.
    ///
    /// @return @c true if journal is required, @c false if not.
    ///
    bool journal() const {
        return _wc.journal().value_or(false);
    }

    ///
    /// Gets the current number of nodes that this write_concern requires operations to reach.
    /// This value will be unset if the acknowledge_level is set to majority, default, or tag.
    ///
    /// This is unset by default.
    ///
    /// @see
    /// - https://www.mongodb.com/docs/manual/reference/write-concern/#w-option
    ///
    /// @return The number of required nodes.
    ///
    bsoncxx::v_noabi::stdx::optional<std::int32_t> nodes() const {
        return _wc.nodes();
    }

    ///
    /// Gets the current acknowledgment level.
    ///
    /// @see
    /// - https://www.mongodb.com/docs/manual/reference/write-concern/#w-option
    ///
    /// @return The acknowledgment level.
    ///
    level acknowledge_level() const {
        return static_cast<level>(_wc.acknowledge_level());
    }

    ///
    /// Gets the current getLastErrorMode that is required by this write_concern.
    ///
    /// @return The current getLastErrorMode.
    ///
    bsoncxx::v_noabi::stdx::optional<std::string> tag() const {
        bsoncxx::v_noabi::stdx::optional<std::string> ret;
        if (auto const opt = _wc.tag()) {
            ret.emplace(*opt);
        }
        return ret;
    }

    ///
    /// Gets whether the majority of nodes is currently required by this write_concern.
    ///
    /// @return The current majority setting.
    ///
    bool majority() const {
        return _wc.acknowledge_level() == v1::write_concern::level::k_majority;
    }

    ///
    /// Gets the current timeout for this write_concern.
    ///
    /// @return Current timeout in milliseconds.
    ///
    std::chrono::milliseconds timeout() const {
        return _wc.timeout();
    }

    ///
    /// Gets whether this write_concern requires an acknowledged write.
    ///
    /// @return Whether this write concern requires an acknowledged write.
    ///
    bool is_acknowledged() const {
        return _wc.is_acknowledged();
    }

    ///
    /// Gets the document form of this write_concern.
    ///
    /// @return
    ///   Document representation of this write_concern.
    ///
    bsoncxx::v_noabi::document::value to_document() const {
        return bsoncxx::v_noabi::from_v1(_wc.to_document());
    }

    ///
    /// @relates mongocxx::v_noabi::write_concern
    ///
    /// Compares two write_concern objects for (in)-equality.
    ///
    /// @{
    friend MONGOCXX_ABI_EXPORT_CDECL_UNSTABLE(bool) operator==(write_concern const& lhs, write_concern const& rhs);

    friend bool operator!=(write_concern const& lhs, write_concern const& rhs) {
        return !(lhs == rhs);
    }
    /// @}
    ///

    class internal;
};

///
/// Convert to the @ref mongocxx::v_noabi equivalent of `v`.
///
inline v_noabi::write_concern from_v1(v1::write_concern v) {
    return {std::move(v)};
}

///
/// Convert to the @ref mongocxx::v1 equivalent of `v`.
///
inline v1::write_concern to_v1(v_noabi::write_concern v) {
    return v1::write_concern{std::move(v)};
}

} // namespace v_noabi
} // namespace mongocxx

#include <mongocxx/config/postlude.hpp>

///
/// @file
/// Provides @ref mongocxx::v_noabi::write_concern.
///
/// @par Includes
/// - @ref mongocxx/v1/write_concern-fwd.hpp
///
