include(CMakeFindDependencyMacro)
find_dependency(mongoc 2.5.8)
find_dependency(bsoncxx 4.6.2)
include("${CMAKE_CURRENT_LIST_DIR}/mongocxx_targets.cmake")
