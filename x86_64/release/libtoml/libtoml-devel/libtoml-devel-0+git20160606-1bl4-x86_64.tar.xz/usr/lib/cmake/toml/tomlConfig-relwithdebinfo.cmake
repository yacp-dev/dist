#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "toml" for configuration "RelWithDebInfo"
set_property(TARGET toml APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(toml PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libtoml.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygtoml-0.dll"
  )

list(APPEND _cmake_import_check_targets toml )
list(APPEND _cmake_import_check_files_for_toml "${_IMPORT_PREFIX}/lib/libtoml.dll.a" "${_IMPORT_PREFIX}/bin/cygtoml-0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
