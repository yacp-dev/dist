/*
 *  connector.h - public library interface
 *  
 *  EAP-IKEv2
 *
 *  This library implements ideas of draft-tschofenig-eap-ikev2-10.txt
 *  Internet-Draft. Version of the document that this library corresponds
 *  to you can find at
 *  http://tools.ietf.org/wg/eap/draft-tschofenig-eap-ikev2-10.txt.
 *
 *  This file is part of libeap-ikev2.
 *
 *  libeap-ikev2 is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  libeap-ikev2 is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with libeap-ikev2; if not, write to the Free Software
 *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  Copyright (C) 2005-2006 Krzysztof Rzecki <krzysztof.rzecki@ccns.pl>      
 *  Copyright (C) 2005-2006 Rafal Mijal <rafal.mijal@ccns.pl>                
 *  Copyright (C) 2005-2006 Piotr Marnik <piotr.marnik@ccns.pl>              
 *  Copyright (C) 2005-2006 Pawel Matejski <pawel.matejski@ccns.pl>          
 *  Copyright (C) 2003      Udo Schilcher <udo.schilcher@edu.uni-klu.ac.at>
 *  Copyright (C) 2003      Thomas Hambrusch <thambrus@edu.uni-klu.ac.at>          
 *
 */

#ifndef CONNECTOR_H
#define CONNECTOR_H

#ifdef __cplusplus
extern "C" {
#endif

#include "common.h"

#include <stdlib.h>
#include <stdio.h>

#include <openssl/rand.h>

#include "session.h"
#include "payload.h"
#include "message.h"
#include "IKEv2.h"
#include "payload.h"
#include "conf_utils.h"
#include "enums.h"
#include "auth.h"



// eap message codes (to remove!!!!!!!!!!!!!!!!!!!!!!!!!!!)

#define EAP_CODE_REQUEST      1
#define EAP_CODE_RESPONSE     2
#define EAP_CODE_SUCCESS      3
#define EAP_CODE_FAILURE      4

/**
 *   eap header flags
 *
 *   \verbatim
 *   0 1 2 3 4 5 6 7
 *  +-+-+-+-+-+-+-+-+
 *  |L M I 0 0 0 0 0|
 *  +-+-+-+-+-+-+-+-+
 *  \endverbatim
 *
 *  L = Length included
 *  M = More fragments
 *  I = Integrity Checksum Data included
 */

#define EAP_HDF_LENGTHINCLUDED     (1<<0)
#define EAP_HDF_MOREFRAGMENTS      (1<<1)
#define EAP_HDF_INTEGRITYINCLUDED  (1<<2)

/**
 * @brief EAP header structure.
 */
struct EAPHeader 
{
	uint8_t Code;
	uint8_t Id;
	uint16_t Length;         
	uint8_t Type;
	uint8_t Flags;
}__attribute__((packed));

/**
 * @brief IKEv2 data structure.
 * 
 * This structure group together IKEv2 context data and current session
 */
struct IKEv2Data 
{
    struct ikev2_ctx *i2;		///< IKEv2 context data
    struct IKEv2Session *session;       ///< current IKEv2 session
};

#define EAPIKEv2_TYPE 47

int CertInit( struct ikev2_ctx *i2 );
int IKEv2Init( struct ikev2_ctx *i2 );

void IKEv2Shutdown(void);
int GenEapKeys(struct IKEv2Session *s, int len);

uint32_t CreateIKEv2Message(const ikev2_ctx *i2, uint8_t *ikemsg, uint32_t imlen, bool response, uint8_t msgid,
			     struct IKEv2Session *session, uint8_t **out );

int ExtractData(const uint8_t *in, uint8_t **data, uint32_t *dlen, uint32_t ilen );

int ParseIKEv2Message(const uint8_t *in, uint8_t **ikemsg, uint32_t *imlen, struct IKEv2Session *session );

uint32_t CreateResultMessage( bool succ, struct IKEv2Session *session, uint8_t **out );

uint16_t CreateFragmentAck(const uint8_t *in, uint8_t **out, struct IKEv2Session *session );

int ParseFragmentAck(const uint8_t *in, struct IKEv2Session *session );

struct IKEv2Data * IKEv2Data_new(struct ikev2_ctx *i2, struct IKEv2Session *s);

#ifdef __cplusplus
}
#endif

#endif //CONNECTOR_H
