/*
 *  enums.h - enumeration values defined by IKEv2 protocol specification
 *  
 *  EAP-IKEv2
 *
 *  This library implements ideas of draft-tschofenig-eap-ikev2-10.txt
 *  Internet-Draft. Version of the document that this library corresponds
 *  to you can find at
 *  http://tools.ietf.org/wg/eap/draft-tschofenig-eap-ikev2-10.txt.
 *
 *  This file is part of libeap-ikev2.
 *
 *  libeap-ikev2 is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  libeap-ikev2 is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with libeap-ikev2; if not, write to the Free Software
 *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  Copyright (C) 2005-2006 Krzysztof Rzecki <krzysztof.rzecki@ccns.pl>      
 *  Copyright (C) 2005-2006 Rafal Mijal <rafal.mijal@ccns.pl>                
 *  Copyright (C) 2005-2006 Piotr Marnik <piotr.marnik@ccns.pl>              
 *  Copyright (C) 2005-2006 Pawel Matejski <pawel.matejski@ccns.pl>          
 *
 */

#ifndef ENUMS_H
#define ENUMS_H

/// authentication method types
typedef enum {
    IKEv2_AMT_RSA_DS                       = 1,
    IKEv2_AMT_SKMIC                        = 2,
    IKEv2_AMT_DSS_DS                       = 3
} IKEv2_AMT;

/// certificate types
typedef enum {
    IKEv2_CET_PKCS7_X509                   = 1,
    IKEv2_CET_PGP                          = 2,
    IKEv2_CET_DNS_SIGNED_KEY               = 3,
    IKEv2_CET_X509_SIGNATURE               = 4,
    IKEv2_CET_KERBEROS_TOKEN               = 6,
    IKEv2_CET_CRL                          = 7,
    IKEv2_CET_ARL                          = 8,
    IKEv2_CET_SPKI                         = 9,
    IKEv2_CET_X509_ATTRIBUTE               = 10,
    IKEv2_CET_RAW_RSA_KEY                  = 11,
    IKEv2_CET_PKIX_CERT                    = 12,
    IKEv2_CET_PKIX_BUNDLE                  = 13
} IKEv2_CET;


/// transform type value
typedef enum {
    IKEv2_TRT_ENCRYPTION_ALGORITHM         = 1,
    IKEv2_TRT_PSEUDO_RANDOM_FUNCTION       = 2,
    IKEv2_TRT_INTEGRITY_ALGORITHM          = 3,
    IKEv2_TRT_DIFFIE_HELLMAN_GROUP         = 4,
    IKEv2_TRT_EXTENDED_SEQUENCE_NUMBERS    = 5
} IKEv2_TRT;

/// DH Group constants
typedef enum {
    IKEv2_TID_DHG_NONE                     = 0,
    IKEv2_TID_DHG_768MODP                  = 1,
    IKEv2_TID_DHG_1024MODP                 = 2,
    IKEv2_TID_DHG_155EC2N                  = 3,
    IKEv2_TID_DHG_185EC2N                  = 4,
    IKEv2_TID_DHG_1536MODP                 = 5,
    IKEv2_TID_DHG_2048MODP                 = 14,
    IKEv2_TID_DHG_3072MODP                 = 15,
    IKEv2_TID_DHG_4096MODP                 = 16,
    IKEv2_TID_DHG_6144MODP                 = 17,
    IKEv2_TID_DHG_8192MODP                 = 18
} IKEv2_TID_DHG;


/// encryption algorithms
typedef enum {
    IKEv2_TID_ENCR_DES_IV64                = 1,
    IKEv2_TID_ENCR_DES                     = 2,
    IKEv2_TID_ENCR_3DES                    = 3,
    IKEv2_TID_ENCR_RC5                     = 4,
    IKEv2_TID_ENCR_IDEA                    = 5,
    IKEv2_TID_ENCR_CAST                    = 6,
    IKEv2_TID_ENCR_BLOWFISH                = 7,
    IKEv2_TID_ENCR_3IDEA                   = 8,
    IKEv2_TID_ENCR_DES_IV32                = 9,
    IKEv2_TID_ENCR_RC4                     = 10,
    IKEv2_TID_ENCR_NULL                    = 11,
    IKEv2_TID_ENCR_AES_CBC                 = 12,
    IKEv2_TID_ENCR_AES_CTR                 = 13
} IKEv2_TID_ENCR;

/// transform IDs
typedef enum {
    IKEv2_TID_PRF_HMAC_MD5                 = 1,
    IKEv2_TID_PRF_HMAC_SHA1                = 2,
    IKEv2_TID_PRF_HMAC_TIGER               = 3,
    IKEv2_TID_PRF_AES_CBC                  = 4
} IKEv2_TID_PRF;

/// integrity algorithm
typedef enum {
    IKEv2_TID_AUTH_NONE                    = 0,
    IKEv2_TID_AUTH_HMAC_MD5_96             = 1,
    IKEv2_TID_AUTH_HMAC_SHA1_96            = 2,
    IKEv2_TID_AUTH_DES_MAC                 = 3,
    IKEv2_TID_AUTH_KPDK_MD5                = 4,
    IKEv2_TID_AUTH_AES_XCBC_96             = 5
} IKEv2_TID_AUTH;

/// Extended sequence numbers 
typedef enum {
    IKEv2_TID_ESN_NO                       = 0,
    IKEv2_TID_ESN_YES                      = 1
} IKEv2_TID_ESN;

/// attribute types
typedef enum {
    IKEv2_ATT_KEY_LENGTH                   = 14
} IKEv2_ATT;

/// Protocol IDs
typedef enum {
    IKEv2_PID_IKE_SA                       = 1,
    IKEv2_PID_AH                           = 2,
    IKEv2_PID_ESP                          = 3
} IKEv2_PID;




/// Next Payload Type
///  - 49-127 Reserved to IANA
///  - 128-255 Private Use
///  - 1-32 Reserved
typedef enum {
    IKEv2_NPT_NONE                         = 0,
    IKEv2_NPT_SA                           = 33,
    IKEv2_NPT_KE                           = 34,
    IKEv2_NPT_IDI                          = 35,
    IKEv2_NPT_IDR                          = 36,
    IKEv2_NPT_CERT                         = 37,
    IKEv2_NPT_CERTREQ                      = 38,
    IKEv2_NPT_AUTH                         = 39,
    IKEv2_NPT_NONCE                        = 40,
    IKEv2_NPT_NOTIFY                       = 41,
    IKEv2_NPT_DELETE                       = 42,
    IKEv2_NPT_VENDORID                     = 43,
    IKEv2_NPT_TSI                          = 44,
    IKEv2_NPT_TSR                          = 45,
    IKEv2_NPT_ENCRYPTED                    = 46,
    IKEv2_NPT_CONFIG                       = 47,
    IKEv2_NPT_EAP                          = 48
} IKEv2_NPT;


/// Identification Types
typedef enum {
    IKEv2_IDT_RESERVED                     = 0,
    IKEv2_IDT_IPV4_ADDR                    = 1,
    IKEv2_IDT_FQDN                         = 2,
    IKEv2_IDT_RFC822_ADDR                  = 3,
    IKEv2_IDT_IPV6_ADDR                    = 5,
    IKEv2_IDT_DER_ASN1_DN                  = 9,
    IKEv2_IDT_DER_ASN1_GN                  = 10,
    IKEv2_IDT_KEY_ID                       = 11
} IKEv2_IDT;

/// Notify Message Type
typedef enum {
    IKEv2_NMT_UNSUPPORTED_CRITICAL_PAYLOAD = 1,
    IKEv2_NMT_INVALID_IKE_SPI              = 4,
    IKEv2_NMT_INVALID_MAJOR_VERSION        = 5,
    IKEv2_NMT_INVALID_SYNTAX               = 7,
    IKEv2_NMT_INVALID_MESSAGE_ID           = 9,
    IKEv2_NMT_INVALID_SPI                  = 11,
    IKEv2_NMT_NO_PROPOSAL_CHOSEN           = 14,
    IKEv2_NMT_INVALID_KE_PAYLOAD           = 17,
    IKEv2_NMT_AUTHENTICATION_FAILED        = 24,
    IKEv2_NMT_SINGLE_PAIR_REQUIRED         = 34,
    IKEv2_NMT_NO_ADDITIONAL_SAS            = 35,
    IKEv2_NMT_INTERNAL_ADDRESS_FAILURE     = 36,
    IKEv2_NMT_FAILED_CP_REQUIRED           = 37,
    IKEv2_NMT_TS_UNACCEPTABLE              = 38,
    IKEv2_NMT_INITIAL_CONTACT              = 16384,
    IKEv2_NMT_SET_WINDOW_SIZE              = 16385,
    IKEv2_NMT_ADDITIONAL_TS_POSSIBLE       = 16386,
    IKEv2_NMT_IPCOMP_SUPPORTED             = 16387,
    IKEv2_NMT_NAT_DETECTION_SOURCE_IP      = 16388,
    IKEv2_NMT_NAT_DETECTION_DESTINATION_ID = 16389,
    IKEv2_NMT_COOKIE                       = 16390,
    IKEv2_NMT_USE_TRANSPORT_MODE           = 16391,
    IKEv2_NMT_HTTP_CERT_LOOKUP_SUPPORTED   = 16392,
    IKEv2_NMT_REKEY_SA                     = 16393
} IKEv2_NMT;


/// auth types
typedef enum {
    IKEv2_AUTH_NONE                        = 0x00,
    IKEv2_AUTH_SK                          = 0x01,
    IKEv2_AUTH_CERT                        = 0x02,
    IKEv2_AUTH_BOTH                        = IKEv2_AUTH_CERT|IKEv2_AUTH_SK
} IKEv2_AUTH;

#endif //ENUMS_H
