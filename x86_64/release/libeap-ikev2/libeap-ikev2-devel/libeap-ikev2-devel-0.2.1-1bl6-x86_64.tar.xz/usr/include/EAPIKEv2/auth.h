/*
 *  auth.h  -  functions for authentication and certificates
 *  
 *  EAP-IKEv2
 *
 *  This library implements ideas of draft-tschofenig-eap-ikev2-10.txt
 *  Internet-Draft. Version of the document that this library corresponds
 *  to you can find at
 *  http://tools.ietf.org/wg/eap/draft-tschofenig-eap-ikev2-10.txt.
 *
 *  This file is part of libeap-ikev2.
 *
 *  libeap-ikev2 is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  libeap-ikev2 is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with libeap-ikev2; if not, write to the Free Software
 *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  Copyright (C) 2005-2006 Krzysztof Rzecki <krzysztof.rzecki@ccns.pl>      
 *  Copyright (C) 2005-2006 Rafal Mijal <rafal.mijal@ccns.pl>                
 *  Copyright (C) 2005-2006 Piotr Marnik <piotr.marnik@ccns.pl>              
 *  Copyright (C) 2005-2006 Pawel Matejski <pawel.matejski@ccns.pl>          
 *  Copyright (C) 2003      Udo Schilcher <udo.schilcher@edu.uni-klu.ac.at>
 *  Copyright (C) 2003      Thomas Hambrusch <thambrus@edu.uni-klu.ac.at>          
 *
 */

#ifndef __auth_h
#define __auth_h

#ifdef __cplusplus
extern "C" {
#endif
    
#include "common.h"

// for cert list struct
#include "message.h" 



/**
 * @brief Structure which is used for acceptable id/password lists.
 */
struct sharedSecList
{
  struct sharedSecList *next;   ///< next field

  uint8_t *id;                  ///< user ID
  int idlen;                    ///< id length
  int idtype;                   ///< ID type
  uint8_t *pwd;                 ///< password corresponding to ID
  int pwdlen;                   ///< pwd length
  int authtype;                 ///< allowed auth type
};

// function prototypes
uint16_t GenerateAuthData( const struct ikev2_ctx *i2, uint8_t type, struct IKEv2Session *session, uint8_t *id, uint16_t idlen, uint8_t *p );
int Authenticate( const struct ikev2_ctx *i2,struct CertList *cert, uint8_t type, uint8_t *data, uint16_t dlen, struct IKEv2Session *session,
     uint8_t *idData, uint16_t idlen);
int LoadCertData( int type, char *filename, unsigned char **cert );

void AddSharedSec( struct sharedSecList **list, int idt, char *id, char *pwd, int authtype );
int UpdateSharedSec(struct sharedSecList **list,int id_type, char *id, char *secret, int authtype);
int IsAcceptable( struct sharedSecList *list, char *id, int idlen, char *pwd, int pwdlen );
void FreeSharedSecList(struct sharedSecList *list);
int AuthorizeCert(struct sharedSecList *sslist, X509 *x509);
uint32_t CreateCAHashString(X509_STORE *x509_store,uint8_t **result);
int GetCertAuthMethod(EVP_PKEY *pkey);

#ifdef __cplusplus
}
#endif

#endif
