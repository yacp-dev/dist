/*
 *  common.h - common includes and definitions
 *  
 *  EAP-IKEv2
 *
 *  This library implements ideas of draft-tschofenig-eap-ikev2-10.txt
 *  Internet-Draft. Version of the document that this library corresponds
 *  to you can find at
 *  http://tools.ietf.org/wg/eap/draft-tschofenig-eap-ikev2-10.txt.
 *
 *  This file is part of libeap-ikev2.
 *
 *  libeap-ikev2 is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  libeap-ikev2 is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with libeap-ikev2; if not, write to the Free Software
 *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  Copyright (C) 2005-2006 Krzysztof Rzecki <krzysztof.rzecki@ccns.pl>      
 *  Copyright (C) 2005-2006 Rafal Mijal <rafal.mijal@ccns.pl>                
 *  Copyright (C) 2005-2006 Piotr Marnik <piotr.marnik@ccns.pl>              
 *  Copyright (C) 2005-2006 Pawel Matejski <pawel.matejski@ccns.pl>          
 *
 */

#ifndef __COMMON_H
#define __COMMON_H

#ifdef __cplusplus
extern "C" {
#endif

#include "config.h"

#ifdef HAVE_STDINT_H
#include <stdint.h>
#endif //HAVE_STDINT_H

///Purpose: for testing DHCount behaviour
///Uncomment it to force intiator for using the same everytime dhgroup
///#define IKE_FORCE_SAME_DHG
///#define IKE_FORCE_SAME_REKEYING_DHG

// Error codes
#define IKEv2_RET_OK              0
#define IKEv2_RET_ERRMEMALLOC     1
#define IKEv2_RET_ERRWRONGSPI     2
#define IKEv2_RET_ERRPARAMETERS   3
#define IKEv2_RET_ERRNOSESSION    4
#define IKEv2_RET_FAILED          5
#define IKEv2_RET_ERRCONFIGFILE   6

#define EAP_IKEv2_KEY_LEN 256

typedef enum { false = 0, true = -1 } bool;

#include <openssl/bn.h>

#include "logging.h"
#include "utils.h"


#ifdef __cplusplus
}
#endif

#endif // __COMMON_H
