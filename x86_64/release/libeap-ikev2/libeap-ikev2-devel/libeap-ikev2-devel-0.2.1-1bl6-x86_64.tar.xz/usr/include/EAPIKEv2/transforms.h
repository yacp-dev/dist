/*
 *  transforms.h  -  functions supporting the negotiation of crypto-algorithms
 *  
 *  EAP-IKEv2
 *
 *  This library implements ideas of draft-tschofenig-eap-ikev2-10.txt
 *  Internet-Draft. Version of the document that this library corresponds
 *  to you can find at
 *  http://tools.ietf.org/wg/eap/draft-tschofenig-eap-ikev2-10.txt.
 *
 *  This file is part of libeap-ikev2.
 *
 *  libeap-ikev2 is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  libeap-ikev2 is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with libeap-ikev2; if not, write to the Free Software
 *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  Copyright (C) 2005-2006 Krzysztof Rzecki <krzysztof.rzecki@ccns.pl>      
 *  Copyright (C) 2005-2006 Rafal Mijal <rafal.mijal@ccns.pl>                
 *  Copyright (C) 2005-2006 Piotr Marnik <piotr.marnik@ccns.pl>              
 *  Copyright (C) 2005-2006 Pawel Matejski <pawel.matejski@ccns.pl>          
 *  Copyright (C) 2003      Udo Schilcher <udo.schilcher@edu.uni-klu.ac.at>
 *  Copyright (C) 2003      Thomas Hambrusch <thambrus@edu.uni-klu.ac.at>          
 *
 */

#ifndef __transforms_h
#define __transforms_h

#ifdef __cplusplus
extern "C" {
#endif

#include"common.h"

// struct for transforms
/**
 * @brief Structure which contains transform types
 */
struct Transform
{
  struct Transform *next;  ///< next element
  
  uint8_t type;            ///< type of transform
  uint16_t id;             ///< id of algo
  uint16_t keyLen;         ///< key length (optional)
};

/**
 * @brief Structure which contains protocol types and list of associated
 * transforms.
 */
struct Protocol
{
  struct Protocol *next;    ///< ptr to next protocol

  uint8_t protocol;         ///< protocol id
  struct Transform *transforms; ///< transform types
  uint8_t SPISize;          ///< SPI size
  uint64_t SPI;             ///< SPI value. If it is 32 bit, then & 0xFFFFFFFF
};

/**
 * @brief Structure which contains list of proposals and associated protocols
 */
struct Proposal
{
  struct Proposal *next;      ///< next proposals
  struct Protocol *protocols; ///< list of protocols
};

// function prototypes

struct Proposal *AddProposal( struct Proposal **list );
void RemoveProposal( struct Proposal *prop, struct Proposal **list );
void DeleteProposal( struct Proposal *prop );
void DeleteProposalList( struct Proposal *prop );
struct Protocol *AddProtocol( struct Proposal *prop, uint8_t protocol, uint8_t SPISize,
  uint32_t SPI );
void RemoveProtocol( struct Protocol *protocol, struct Proposal *prop );
void DeleteProtocol( struct Protocol *protocol );
int AddTransform( struct Protocol *protocol, uint8_t type, uint16_t id, uint16_t keyLen );
void RemoveTransform( struct Transform *trans, struct Protocol *protocol );
uint16_t GetTransformID( uint8_t type, uint8_t protocol, struct Protocol *list );
uint16_t GetTransformKeyLen( uint8_t type, uint8_t protocol, struct Protocol *list );
int CheckNeededTransforms( struct Proposal *prop );
struct Proposal *FindFirstSupportedProposal( struct Proposal *prop, struct Proposal *list );
int CmpProposal( struct Proposal *p1, struct Proposal *p2 );
struct Proposal *FindProposal( struct Proposal *prop, struct Proposal *list );

#ifdef __cplusplus
}
#endif

#endif
