/*
 *  utils.h  -  some useful functions (data conversion, ...)
 *  
 *  EAP-IKEv2
 *
 *  This library implements ideas of draft-tschofenig-eap-ikev2-10.txt
 *  Internet-Draft. Version of the document that this library corresponds
 *  to you can find at
 *  http://tools.ietf.org/wg/eap/draft-tschofenig-eap-ikev2-10.txt.
 *
 *  This file is part of libeap-ikev2.
 *
 *  libeap-ikev2 is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  libeap-ikev2 is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with libeap-ikev2; if not, write to the Free Software
 *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  Copyright (C) 2005-2006 Krzysztof Rzecki <krzysztof.rzecki@ccns.pl>      
 *  Copyright (C) 2005-2006 Rafal Mijal <rafal.mijal@ccns.pl>                
 *  Copyright (C) 2005-2006 Piotr Marnik <piotr.marnik@ccns.pl>              
 *  Copyright (C) 2005-2006 Pawel Matejski <pawel.matejski@ccns.pl>          
 *  Copyright (C) 2003      Udo Schilcher <udo.schilcher@edu.uni-klu.ac.at>
 *  Copyright (C) 2003      Thomas Hambrusch <thambrus@edu.uni-klu.ac.at>          
 *
 */

#ifndef __utils_h
#define __utils_h

#ifdef __cplusplus
extern "C" {
#endif

#include"common.h"

   
#  define STRINGIFY(x) # x
#  define TOSTRING(x) STRINGIFY(x)
 // goodies
// hton? for uint64_t
#define hton64(x) ((uint64_t)((htonl(((uint32_t)((x)>>32)&0xFFFFFFFF))))|((uint64_t)(htonl((uint32_t)((x)&0xFFFFFFFF)))<<32))
#define ntoh64(x) ((uint64_t)((ntohl(((uint32_t)((x)>>32)&0xFFFFFFFF))))|((uint64_t)(ntohl((uint32_t)((x)&0xFFFFFFFF)))<<32))

// Seperate TypeHF in struct IKEv2Attribute
#define Attribute_GetType(x) ((x)>>1)
#define Attribute_GetHF(x) ((x)&1)
#define Attribute_GetTypeHF(x,y) (((x)<<1)|((y)&1))

// hex numbers utils
#define hextobin(x) ((x)>'9'?((x)>'Z'?(((x)-0x27)&0x0F):(((x)-0x07)&0x0F)):((x)&0x0F))
#define ishex(x) ((((x)>='0')&&((x)<='9'))||(((x)>='A')&&((x)<='Z'))||(((x)>='a')&&((x)<='z')))

// function prototypes

unsigned hex2bytes(char *s, uint8_t **dest);
const char* bin2str(const uint8_t *data,uint32_t len);
void hexalize(uint8_t **data,unsigned *len);
BIGNUM *HexToBignum( const uint8_t *hex, uint32_t len );
uint8_t *Clone( const uint8_t *data, uint32_t len );
void PrintBuffer( unsigned char *buf, unsigned long len );
void PrintBignum(const BIGNUM *a);
uint32_t StringToIP( char *str_ip );
char *IPToString( uint32_t ip );

#ifdef __cplusplus
}
#endif

#endif
