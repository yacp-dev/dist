/*
 *  IKEv2.h  -  IKEv2 interface
 *  
 *  EAP-IKEv2
 *
 *  This library implements ideas of draft-tschofenig-eap-ikev2-10.txt
 *  Internet-Draft. Version of the document that this library corresponds
 *  to you can find at
 *  http://tools.ietf.org/wg/eap/draft-tschofenig-eap-ikev2-10.txt.
 *
 *  This file is part of libeap-ikev2.
 *
 *  libeap-ikev2 is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  libeap-ikev2 is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with libeap-ikev2; if not, write to the Free Software
 *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  Copyright (C) 2005-2006 Krzysztof Rzecki <krzysztof.rzecki@ccns.pl>      
 *  Copyright (C) 2005-2006 Rafal Mijal <rafal.mijal@ccns.pl>                
 *  Copyright (C) 2005-2006 Piotr Marnik <piotr.marnik@ccns.pl>              
 *  Copyright (C) 2005-2006 Pawel Matejski <pawel.matejski@ccns.pl>          
 *  Copyright (C) 2003      Udo Schilcher <udo.schilcher@edu.uni-klu.ac.at>
 *  Copyright (C) 2003      Thomas Hambrusch <thambrus@edu.uni-klu.ac.at>          
 *
 */

#ifndef __IKEv2_h
#define __IKEv2_h

#ifdef __cplusplus
extern "C" {
#endif

#include"common.h"

#include "message.h"

// Function Prototypes

int IKEv2BeginSession( struct ikev2_ctx *i2, struct IKEv2Session **session, uint32_t type );
int IKEv2EndSession( struct ikev2_ctx *i2, struct IKEv2Session *session );
int IKEv2ProcessMsg(const struct ikev2_ctx *i2, uint8_t *in, uint8_t **out, uint32_t *olen, struct IKEv2Session *session);
void *IKEv2GetSession(struct ikev2_ctx *i2, uint8_t *in );

#ifdef __cplusplus
}
#endif

#endif
