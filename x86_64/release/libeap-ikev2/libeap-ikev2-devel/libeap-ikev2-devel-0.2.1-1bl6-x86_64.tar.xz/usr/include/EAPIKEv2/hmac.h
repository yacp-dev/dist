/*
 *  hmac.h  -  implementation of hmac
 *  
 *  EAP-IKEv2
 *
 *  This library implements ideas of draft-tschofenig-eap-ikev2-10.txt
 *  Internet-Draft. Version of the document that this library corresponds
 *  to you can find at
 *  http://tools.ietf.org/wg/eap/draft-tschofenig-eap-ikev2-10.txt.
 *
 *  This file is part of libeap-ikev2.
 *
 *  libeap-ikev2 is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  libeap-ikev2 is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with libeap-ikev2; if not, write to the Free Software
 *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  Copyright (C) 2005-2006 Krzysztof Rzecki <krzysztof.rzecki@ccns.pl>      
 *  Copyright (C) 2005-2006 Rafal Mijal <rafal.mijal@ccns.pl>                
 *  Copyright (C) 2005-2006 Piotr Marnik <piotr.marnik@ccns.pl>              
 *  Copyright (C) 2005-2006 Pawel Matejski <pawel.matejski@ccns.pl>          
 *  Copyright (C) 2003      Udo Schilcher <udo.schilcher@edu.uni-klu.ac.at>
 *  Copyright (C) 2003      Thomas Hambrusch <thambrus@edu.uni-klu.ac.at>          
 *
 */

#ifndef __hmac_h
#define __hmac_h

#ifdef __cplusplus
extern "C" {
#endif

#include"common.h"

// digest size

#define MD5DIGEST_SIZE  16
#define SHA1DIGEST_SIZE  20
#define TIGERDIGEST_SIZE 24
#define DESMACDIGEST_SIZE 8

void i2_hmac_md5( const unsigned char *text, int text_len, const unsigned char* key, int key_len, uint8_t *digest );
void i2_hmac_sha1( const unsigned char *text, int text_len, const unsigned char* key, int key_len, uint8_t *digest );
void i2_hmac_tiger(const uint8_t *text, int text_len, const uint8_t *key, int key_len, uint8_t *digest);
void i2_des_mac(const uint8_t *msg,uint32_t mlen,const uint8_t *key, uint8_t *digest);


#ifdef __cplusplus
}
#endif

#endif
