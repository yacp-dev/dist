/*
 *  message.h  -  functions to generate / parse all msg'es
 *  
 *  EAP-IKEv2
 *
 *  This library implements ideas of draft-tschofenig-eap-ikev2-10.txt
 *  Internet-Draft. Version of the document that this library corresponds
 *  to you can find at
 *  http://tools.ietf.org/wg/eap/draft-tschofenig-eap-ikev2-10.txt.
 *
 *  This file is part of libeap-ikev2.
 *
 *  libeap-ikev2 is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  libeap-ikev2 is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with libeap-ikev2; if not, write to the Free Software
 *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  Copyright (C) 2005-2006 Krzysztof Rzecki <krzysztof.rzecki@ccns.pl>      
 *  Copyright (C) 2005-2006 Rafal Mijal <rafal.mijal@ccns.pl>                
 *  Copyright (C) 2005-2006 Piotr Marnik <piotr.marnik@ccns.pl>              
 *  Copyright (C) 2005-2006 Pawel Matejski <pawel.matejski@ccns.pl>          
 *  Copyright (C) 2003      Udo Schilcher <udo.schilcher@edu.uni-klu.ac.at>
 *  Copyright (C) 2003      Thomas Hambrusch <thambrus@edu.uni-klu.ac.at>          
 *
 */

#ifndef __message_h
#define __message_h

#ifdef __cplusplus
extern "C" {
#endif

#include"common.h"

#include"session.h"


// Version of IKE 
#define IKEv2_MAJOR_VERSION 2
#define IKEv2_MINOR_VERSION 0


#define NONCE_LEN 128         // should be variable???
#define TB_SIZE  4092


// Exchange types
#define IKEv2_EXT_IKE_SA_INIT       34
#define IKEv2_EXT_IKE_AUTH          35
#define IKEv2_EXT_CREATE_CHILD_SA   36
#define IKEv2_EXT_INFORMATIONAL     37

// Header Flags
#define IKEv2_HDF_INITIATOR   (1<<3)
#define IKEv2_HDF_VERSION     (1<<4)
#define IKEv2_HDF_RESPONSE    (1<<5)

// structures

/**
 * @brief Structure for storing certifacate list in raw format.
 */
struct CertList
{
  struct CertList *next;  ///< next 
  uint8_t *cdata;         ///< certificate data
  uint32_t cdlen;         ///< cdate length
  uint8_t ctype;          ///< certificate type
};

/** 
 * @brief Result structure for ParseMsg function
 * 
 * @warning
 * if you change this struct, don't forgent 
 * to change MergeParseMsgResults function    
 */
struct ParseMsgResult
{
  struct Proposal *SA;     ///< Cryptocgrafic suite (SA payload)
  BIGNUM *KE;              ///< public DH value form KE payload
  uint16_t DHGroup;        ///< DH group from KE payload
  BIGNUM *Nonce;           ///< value from Nonce payload
  uint8_t *IDiData;        ///< data from IDi payload 
  uint16_t IDiLen;         ///< IDiData length
  uint8_t *IDrData;        ///< data from IDr payload
  uint16_t IDrLen;         ///< IDrData length
  uint8_t *authData;       ///< AUTH payload content
  uint32_t adlen;          ///< authData length
  uint8_t authMeth;        ///< authentication method (from AUTH payload)



  struct CertList *cert;   ///< list of certificates (from CERT payload)

  uint8_t enc;             ///< is message encrypted?
  uint8_t failed;          ///< set if last request has failed

  uint8_t error;           ///< error indicator
  uint8_t unsuppCritPl;    ///< unsuported critical payload
  uint8_t plType;          ///< payload type
  uint8_t Authfailed;      ///< authentication failed
  uint8_t NoPropAcceptable;///< no acceptable proposals in SA payload 
  uint8_t KEInvalid;       ///< invalid DH group guess
  uint16_t ChosenDHGroup;  ///< DH group hint
};

/** 
 * @brief Structure which represent IKEv2 header.
 * The format of the IKE header (see IKEv2 Protocol):
\verbatim
  0                   1                   2                   3
  0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 |                       InitiatorSPI                            |
 |                                                               |
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 |                       ResponderSPI                            |
 |                                                               |
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 |  NextPayload  | MjVer | MnVer |  ExchangeType |    Flags      |
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 |                         MessageID                             |
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 |                          Length                               |
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+ 
\endverbatim
 */

struct IKEv2Header
{
  uint64_t InitiatorSPI;
  uint64_t ResponderSPI;
  uint8_t NextPayload;
  union
  {
    struct
    {
      uint8_t MjVersion:4;
      uint8_t MnVersion:4;
    }__attribute__((packed));
    uint8_t Version;
  }__attribute__((packed));
  uint8_t ExchangeType;
  uint8_t Flags;
  uint32_t MessageID;
  uint32_t Length;
}__attribute__((packed));

// function prototypes

int IKEv2IBuild_SA_Init( const struct ikev2_ctx *i2, uint8_t **out, uint32_t *olen, struct IKEv2Session *session, uint16_t DHGroup );
int IKEv2RBuild_SA_Init( const struct ikev2_ctx *i2, uint8_t *oldMsg, uint8_t **out, uint32_t *olen,
    struct Proposal *selTrans, struct IKEv2Session *session, BIGNUM *pubk );
int IKEv2IBuild_Auth( const struct ikev2_ctx *i2, uint8_t **out, uint32_t *olen, struct IKEv2Session *session );
int IKEv2RBuild_Auth( const struct ikev2_ctx *i2, uint8_t **out, uint32_t *olen, uint8_t *in, struct IKEv2Session *session );
int IKEv2Build_Informational( uint8_t **out, uint32_t *olen, struct IKEv2Session *session,
    uint8_t first, uint8_t *payloads, uint32_t plsize );
int IKEv2RespondInformational( uint8_t **out, uint32_t *olen, uint8_t *inf );
#if 0
int IKEv2BuildEndSession( uint8_t **out, uint32_t *olen, struct IKEv2Session *session, uint64_t SPI );
#endif
int IKEv2BuildErrorMsg( uint8_t **out, uint32_t *olen, struct IKEv2Session *session,
    struct ParseMsgResult *res );
int IKEv2BuildErrorResponseMsg( uint8_t **out, uint32_t *olen, uint8_t *in, struct ParseMsgResult *res,
    struct IKEv2Session *session, int enc );
int IKEv2ICreateChildSA( const struct ikev2_ctx *i2, uint8_t **out, uint32_t *olen, struct IKEv2Session *session, int DHGroup );
int IKEv2RCreateChildSA( uint8_t *oldMsg, uint8_t **out, uint32_t *olen, struct IKEv2Session *session,
    struct Proposal *selTrans, int DHGroup );

struct ParseMsgResult *ParseSAInitMsg( const struct ikev2_ctx *i2, struct IKEv2Session *session, uint8_t *p );
struct ParseMsgResult *ParseAuthMsg( const struct ikev2_ctx *i2, struct IKEv2Session *session, uint8_t *p );
struct ParseMsgResult *ParseInformationalMsg( const struct ikev2_ctx *i2, struct IKEv2Session *session, uint8_t *p );
struct ParseMsgResult *ParseChildSAMsg( const struct ikev2_ctx *i2, struct IKEv2Session *session, uint8_t *p );
void FreeMsgResult(struct ParseMsgResult *res);

#ifdef __cplusplus
}
#endif

#endif
