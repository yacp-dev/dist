/*
 *  payload.h  -  generate / parse all payloads
 *  
 *  EAP-IKEv2
 *
 *  This library implements ideas of draft-tschofenig-eap-ikev2-10.txt
 *  Internet-Draft. Version of the document that this library corresponds
 *  to you can find at
 *  http://tools.ietf.org/wg/eap/draft-tschofenig-eap-ikev2-10.txt.
 *
 *  This file is part of libeap-ikev2.
 *
 *  libeap-ikev2 is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  libeap-ikev2 is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with libeap-ikev2; if not, write to the Free Software
 *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  Copyright (C) 2005-2006 Krzysztof Rzecki <krzysztof.rzecki@ccns.pl>      
 *  Copyright (C) 2005-2006 Rafal Mijal <rafal.mijal@ccns.pl>                
 *  Copyright (C) 2005-2006 Piotr Marnik <piotr.marnik@ccns.pl>              
 *  Copyright (C) 2005-2006 Pawel Matejski <pawel.matejski@ccns.pl>          
 *  Copyright (C) 2003      Udo Schilcher <udo.schilcher@edu.uni-klu.ac.at>
 *  Copyright (C) 2003      Thomas Hambrusch <thambrus@edu.uni-klu.ac.at>          
 *
 */

#ifndef __payload_h
#define __payload_h

#ifdef __cplusplus
extern "C" {
#endif

#include"common.h"

#include"session.h"


/** 
 * @brief Key Exchange Payload
 \verbatim

  0                   1                   2                   3
  0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 | Next Payload  |C|   RESERVED  |        Payload Length         |
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 |           DH Group #          |          RESERVED             |
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 \endverbatim
 */

struct IKEv2KeyExchangePayload
{
  uint8_t NextPayload;
  uint8_t C:1;
  uint8_t Reserved1:7;
  uint16_t Length;
  uint16_t DHGroupNr;
  uint16_t Reserved2;
}__attribute__((packed));

/**
 * @brief Generic Payload Header
 \verbatim

  0                   1                   2                   3
  0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 |  NextPayload  |C|   RESERVED  |         PayloadLength         |
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+ 
 \endverbatim 
 */

struct IKEv2PayloadHeader
{
  uint8_t NextPayload;
  uint8_t C:1;
  uint8_t Reserved:7;
  uint16_t PayloadLength;
}__attribute__((packed));

/**
 * @brief Proposal Substructure
 \verbatim

  0                   1                   2                   3
  0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 + 0 (last) or 2 |    RESERVED   |       ProposalLength          |
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *  Proposal #   |  Protocol-Id  |   SPI Size    |# of Transforms|
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 +                        SPI (variable)                         +
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+ 
 \endverbatim
 */


struct IKEv2Proposal
{
  uint8_t IsLast;
  uint8_t Reserved;
  uint16_t ProposalLength;
  uint8_t ProposalNr;
  uint8_t ProtocolId;
  uint8_t SPISize;
  uint8_t TransformsCount;
}__attribute__((packed));

/**
 * @brief Transform Substructure
 \verbatim
  0                   1                   2                   3
  0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 | 0 (last) or 3 |    RESERVED   |         Transform Length      |
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 |Transform Type |    RESERVED   |         Transform ID          |
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 |                  Transform Attributes                         |
 |                                                               |
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 \endverbatim
 */ 

struct IKEv2Transform
{
  uint8_t IsLast;
  uint8_t Reserved1;
  uint16_t TransformLength;
  uint8_t TransformType;
  uint8_t Reserved2;
  uint16_t TransformID;
}__attribute__((packed));

/** 
 * @brief Data Attributes
 \verbatim
  0                   1                   2                   3
  0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 |A|      Attribute Type         |    AF = 0 Attribute Length    |
 |F|                             |    AF = 1 Attribute Value     |
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+ 
 \endverbatim
 */

struct IKEv2Attribute
{
  uint16_t TypeAF;
  union
  {
    uint16_t Length;
    uint16_t Value;
  };
}__attribute__((packed));


/**
 * @brief Identification Payload
 \verbatim
  0                   1                   2                   3
  0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 | Next Payload  |C|   RESERVED  |          Payload Length       |
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 |   ID Type     |                    RESERVED                   |
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 |                                                               |
 ~                     Identification Data                       ~
 |                                                               |
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+ 
 \endverbatim
 */

struct IKEv2IdentificationPayload
{
  uint8_t NextPayload;
  uint8_t C:1;
  uint8_t Reserved1:7;
  uint16_t Length;
  uint32_t IDType:8;
  uint32_t Reserved2:24;
}__attribute__((packed));


/**
 * @brief Identification payload body. Data which do not belongs to generic
 * payload header.
 */
struct IKEv2IdentificationPayloadBody
{
  uint32_t IDType:8;
  uint32_t Reserved2:24;
}__attribute__((packed));


#define IKEv2_GET_IDTYPE(x) ((struct IKEv2IdentificationPayloadBody*)(x))->IDType
#define IKEv2_GET_ID(x)  ((x)+sizeof (struct IKEv2IdentificationPayloadBody))

/**
 * @brief Authentication Payload
 \verbatim
  0                   1                   2                   3
  0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 | Next Payload  |C|   RESERVED  |          Payload Length       |
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 |  AuthMethod   |                    RESERVED                   |
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 |                                                               |
 ~                     Authentication Data                       ~
 |                                                               |
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+ 
 \endverbatim
 */

struct IKEv2AuthenticationPayload
{
  uint8_t NextPayload;
  uint8_t C:1;
  uint8_t Reserved1:7;
  uint16_t Length;
  uint32_t AuthMethod:8;
  uint32_t Reserved2:24;
}__attribute__((packed));


/**
 * @brief Notify Payload
 \verbatim

  0                   1                   2                   3
  0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 |  Next Payload |C|   RESERVED  |        Payload Length         |
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 | S_PROTOCOL_ID |   SPI Size    |        Notify Msg Type        |
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 |                                                               |
 ~                Secutrity Parameter Index (SPI)                ~
 |                                                               |
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 |                                                               |
 ~                      Notification Data                        ~
 |                                                               |
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+ 
 \endverbatim
 */
 

struct IKEv2NotifyPayload
{
  uint8_t NextPayload;
  uint8_t C:1;
  uint8_t Reserved:7;
  uint16_t Length;
  uint8_t SProtocolID;
  uint8_t SPISize;
  uint16_t MsgType;
}__attribute__((packed));

/** 
 * @brief Delete Payload
 \verbatim

  0                   1                   2                   3
  0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 |  Next Payload |C|   RESERVED  |       Payload Length          |
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 | S_PROTOCOL_ID |  SPI Size     |        # of SPIs              |
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 |                                                               |
 ~                Secutrity Parameter Index (SPI)                ~
 |                                                               |
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+ 
 \endverbatim
 */

struct IKEv2DeletePayload
{
  uint8_t NextPayload;
  uint8_t C:1;
  uint8_t Reserved:7;
  uint16_t Length;
  uint8_t SProtocolID;
  uint8_t SPISize;
  uint16_t SPICount;
}__attribute__((packed));

/**
 * @brief Certificate Request Payload
 \verbatim

  0                   1                   2                   3
  0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 ! Next Payload  !C!  RESERVED   !         Payload Length        !
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 ! Cert Encoding !                                               !
 +-+-+-+-+-+-+-+-+                                               !
 ~                    Certification Authority                    ~
 !                                                               !
 +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 \endverbatim
 */


struct IKEv2CertReqPayload
{
  uint8_t NextPayload;
  uint8_t C:1;
  uint8_t Reserved:7;
  uint16_t Length;
  uint8_t Encoding;
}__attribute__((packed));


// function prototypes

// create packages
uint32_t CreateSAPayload( uint8_t **next, struct Proposal *suppProp, uint8_t *p );
uint32_t CreateKEPayload( uint8_t **next, uint16_t DHGroup, struct IKEv2Session *session, uint8_t *p );
uint32_t CreateNoncePayload( uint8_t **next, struct IKEv2Session *s, uint32_t len, uint8_t *p );
uint32_t CreateEncryptedPayload( uint8_t **next, uint8_t inner_next, uint8_t *data, uint32_t dlen, uint8_t *sigdata,
    struct IKEv2Session *session, uint8_t *p );
uint32_t CreateIDPayload( uint8_t **next, uint8_t initiator, uint8_t type, uint8_t *id, uint16_t idlen, uint8_t *p );
uint32_t CreateAuthPayload( const struct ikev2_ctx *i2, uint8_t **next, struct IKEv2Session *session, uint8_t *id,
    uint16_t idlen, uint8_t *p );
uint32_t CreateCertPayload( const struct ikev2_ctx *i2, uint8_t **next, uint8_t type, uint8_t *p );
uint32_t CreateNotifyPayload( uint8_t **next, uint16_t type, uint8_t *ndata, uint16_t ndlen, uint8_t *p );
uint32_t CreateDeletePayload( uint8_t **next, uint8_t SProtocolID,
    uint8_t *SPIs, uint16_t count, uint8_t *p );
uint32_t CreateCertReqPayload(const struct ikev2_ctx *i2,uint8_t **next,uint8_t *p );

// parse packages
struct Proposal *ParseSAPayload( uint8_t *p );
BIGNUM *ParseKEPayload( uint16_t *DHGroup, uint8_t *p );
BIGNUM *ParseNoncePayload( uint8_t *p );
uint32_t ParseEncryptedPayload( uint8_t **data, struct IKEv2Session *session, uint8_t *p );
uint16_t ParseIDPayload( uint8_t **data, uint8_t *p );
int ParseAuthPayload( uint8_t *AuthMethod, uint8_t **data, uint8_t *p );
int ParseCertPayload(uint8_t **cdata, uint32_t *cdlen,uint8_t *ctype, uint8_t *p );
int ParseNotifyPayload( uint8_t *p, uint16_t *data );
#if 0
void ParseDeletePayload( const struct ikev2_ctx *i2, uint8_t *p );
#endif
void ParseCertReqPayload(const struct ikev2_ctx *i2, uint8_t *p);

#ifdef __cplusplus
}
#endif

#endif
