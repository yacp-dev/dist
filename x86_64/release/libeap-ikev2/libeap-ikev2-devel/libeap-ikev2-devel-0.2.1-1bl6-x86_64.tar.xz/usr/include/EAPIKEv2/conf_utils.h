/*
 *  conf_utils.c - functions used to parse config options
 *  
 *  EAP-IKEv2
 *
 *  This library implements ideas of draft-tschofenig-eap-ikev2-10.txt
 *  Internet-Draft. Version of the document that this library corresponds
 *  to you can find at
 *  http://tools.ietf.org/wg/eap/draft-tschofenig-eap-ikev2-10.txt.
 *
 *  This file is part of libeap-ikev2.
 *
 *  libeap-ikev2 is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  libeap-ikev2 is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with libeap-ikev2; if not, write to the Free Software
 *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  Copyright (C) 2005-2006 Krzysztof Rzecki <krzysztof.rzecki@ccns.pl>      
 *  Copyright (C) 2005-2006 Rafal Mijal <rafal.mijal@ccns.pl>                
 *  Copyright (C) 2005-2006 Piotr Marnik <piotr.marnik@ccns.pl>              
 *  Copyright (C) 2005-2006 Pawel Matejski <pawel.matejski@ccns.pl>          
 *
 */

#ifndef CONF_UTILS_H
#define CONF_UTILS_H

#ifdef __cplusplus
extern "C" {
#endif
#include "common.h"

/**
 * @brief Structure which is used to map descriptive transform name to numeric
 * ID and vice versa. This structure also contains information about kind of
 * encryption key, which is used with sepceyfic algorithm. If variable key
 * length is allowed, then last field, contains also default key length
 */
struct TransformConfigItem
{
    uint8_t type;           ///< transform type
    uint16_t id;            ///< transform ID
    const char *name;       ///< descriptive name
    int variable_key_len;   ///< is variable key allowed?
    int default_key_len;    ///< default key len, when length ommited
};


/**
 * @brief Structure which is used to map descriptive ID type name to numeric ID
 * and vice versa
 */
struct IdTypeConfigItem
{
    uint8_t type;          ///< ID type
    const char *name;      ///< descriptive name
};

const char* GetTransformName(int type,int alg);
int TransformFromName(const char *name, uint8_t type, uint8_t *id,uint16_t *keylen);
int IdTypeFromName(const char *name);
int AuthtypeFromName(const char *authtype_name);
uint16_t extractKeyLen(const char *alg);
const struct TransformConfigItem* GetAvailableTransformsTypes(void);
const struct IdTypeConfigItem* GetAvailableIdTypes(void);


#ifdef __cplusplus
}
#endif

#endif //CONF_UTILS_H
