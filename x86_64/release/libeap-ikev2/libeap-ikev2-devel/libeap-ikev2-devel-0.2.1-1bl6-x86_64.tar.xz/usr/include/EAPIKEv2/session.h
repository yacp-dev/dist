/*
 *  session.h  -  session control structure
 *  
 *  EAP-IKEv2
 *
 *  This library implements ideas of draft-tschofenig-eap-ikev2-10.txt
 *  Internet-Draft. Version of the document that this library corresponds
 *  to you can find at
 *  http://tools.ietf.org/wg/eap/draft-tschofenig-eap-ikev2-10.txt.
 *
 *  This file is part of libeap-ikev2.
 *
 *  libeap-ikev2 is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  libeap-ikev2 is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with libeap-ikev2; if not, write to the Free Software
 *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  Copyright (C) 2005-2006 Krzysztof Rzecki <krzysztof.rzecki@ccns.pl>      
 *  Copyright (C) 2005-2006 Rafal Mijal <rafal.mijal@ccns.pl>                
 *  Copyright (C) 2005-2006 Piotr Marnik <piotr.marnik@ccns.pl>              
 *  Copyright (C) 2005-2006 Pawel Matejski <pawel.matejski@ccns.pl>          
 *  Copyright (C) 2003      Udo Schilcher <udo.schilcher@edu.uni-klu.ac.at>
 *  Copyright (C) 2003      Thomas Hambrusch <thambrus@edu.uni-klu.ac.at>          
 *
 */

#ifndef __session_h
#define __session_h

#ifdef __cplusplus
extern "C" {
#endif

#include"common.h"

#include <openssl/dh.h>


#include"transforms.h"

#ifdef HAVE_PTHREAD_H 
#include <pthread.h>
#endif

// defines

#define IKEv2_STY_INITIATOR         1
#define IKEv2_STY_RESPONDER         2

// session status
typedef enum {
 IKEv2_SST_NORMAL=0,
 IKEv2_SST_FAILED,
 IKEv2_SST_ESTABLISHED,
 IKEv2_SST_REKEYING,
} IKEv2_SST;


// default option values

#define IKEv2_DEFAULT_DH_COUNTER_MAX 3
#define IKEv2_DEFAULT_DH_COUNTER_MAX_STR TOSTRING(IKEv2_DEFAULT_DH_COUNTER_MAX)

#define IKEv2_DEFAULT_MAX_FRAGMENT_SIZE 1398
#define IKEv2_DEFAULT_MAX_FRAGMENT_SIZE_STR TOSTRING(IKEv2_DEFAULT_MAX_FRAGMENT_SIZE)

#define IKEv2_DEFAULT_IDTYPE  IKEv2_IDT_KEY_ID
#define IKEv2_DEFAULT_IDTYPE_STR "KEY_ID"



#define RAW_FASTID_LEN 20
    
// structures


/**
 * @brief IKEv2 Session data. This structure is also used as a element of linked
 * list with all active IKEv2 sessions.
 */
struct IKEv2Session
{
  uint32_t timestamp;          ///< last session activity time
  struct IKEv2Session *next;  ///< next session entry

  int Type;                    ///< i am initator of responder?
  
  uint64_t iSPI;               ///< SPI of initiator
  uint64_t rSPI;               ///< SPI of responder
  uint32_t State;              ///< current state
  uint32_t MsgID;              ///< MsgID for next IKEv2 msg to send
  uint32_t recvMsgID;          ///< MsgID for next msg received, which is not a response.

  uint32_t Status;             ///< Status of session
  
  int WaitResponse;            ///< am i waiting for a response? (only for initiator)
  uint32_t respMsgID;          ///< MsgID for response

  struct Protocol *UsedTransforms; ///< used algorithms
    
  DH *dh;                      ///< dh structure for temporary data needed by openssl
  uint8_t *DHKey;              ///< DH-Key for session
  uint32_t DHKeyLen;           ///< Length of DH-Key
  uint32_t DHCounter;          ///< INVALID_KE response counter, if 0 initator send EAP-Fail immediatly
  BIGNUM *Ni;                  ///< Nonce from initiator
  BIGNUM *Nr;                  ///< Nonce from responder
  
  uint8_t *fmsg;               ///< first send msg, needed for auth
  uint32_t fmlen;              ///< length of fmsg
  uint8_t *rmsg;               ///< first received message, needed for verifying auth
  uint32_t rmlen;              ///< length of rmsg
  int include_integ;           ///< include integ checksum?
  int expect_integ;            ///< expect integ checksum in a next messages?

  uint8_t *IDr;                ///< used in only in initiator, stores IDr from SK{IDr}
  int IDrLen;                  ///< IDr length
  uint8_t *pwd;                ///< password (in case of password based auth)
  uint16_t pwdlen;             ///< length of pwd (in bytes)

  int SK_ready;                ///< SK_* keys ready?
  uint8_t *SK_d;               ///< Session key for further key derivation
  uint8_t *SK_ai;              ///< Session key for initiator auth algo
  uint8_t *SK_ar;              ///< Session key for responder auth algo
  uint8_t *SK_ei;              ///< Session key for initiator encr algo
  uint8_t *SK_er;              ///< Session key for responder encr algo
  uint8_t *SK_pi;              ///< Session key for initiator AUTH generation
  uint8_t *SK_pr;              ///< Session key for responder AUTH generation
  char *fastID;                ///< EAP ID used for session matching in case of fast rekeying (base64)


  uint8_t *fragdata;           ///< recent fragments
  uint32_t fdlen;              ///< length of fragdata
  uint32_t fragment;           ///< which fragment is next
  bool sendfrag;               ///< send fragment?

  //bool hasinteg;             ///< insert an integrity checksum?
  uint8_t *integkey;           ///< key for integrity algorithm
  uint32_t iklen;              ///< length of key
  uint32_t integtype;          ///< used algorithm for integrity check

  uint8_t *ointegkey;          ///< last key for integrity algorithm
  uint32_t oiklen;             ///< length of last key

  uint8_t eapMsgID;            ///< msg id for current EAP request
  uint8_t *eapKeyData;         ///< EAP exported keys data

  bool fFastReconnect;         ///< fast reconnect?
  bool fDHExchange;            ///< DH exchange needed?
};


/**
 * @brief IKEv2 context structure. Used for storing global configuration
 * options and list of active IKEv2 sessions.
 */
typedef struct ikev2_ctx
{
   uint32_t max_fragment_size;   ///< for fragmentatnion support, must be initialized!!!!
   struct IKEv2Session *SessionList;  ///< linked list of active IKEv2 sessions
   struct Proposal *suppProp;    ///< list of supported proposals

   uint8_t *id;                  ///< side identity
   unsigned int idlen;           ///< id length
   int idtype;                   ///< id type
   int authtype;                 ///< authentication type
   char *certfile;               ///< certificates file
   char *crl_file;               ///< CRL file
   char *trusted;                ///< CA cert file
   uint8_t *pwd;                 ///< password
   int pwdlen;                   ///< password length
   char *pkfile;                 ///< private key file
   char *pkfile_pwd;             ///< password to private key file

   EVP_PKEY *rpk;                ///< private key
   uint8_t *cert;                ///< cert data
   int certlen;                  ///< cert data len
   int send_sk_idr;              ///< send SK{IDr} payload? (responder option)
   
   uint32_t DHCounterMax;        ///< initial value for IKEv2Session.DHCounter
   uint8_t sendCertReq;          ///< send Cert Req payload?
   X509_STORE *x509_store;       ///< openssl cert lookup
   uint8_t *CAsHashString;       ///< concatenated SHA1 hashes of public keys of trusted CA's
   uint32_t CAsHashStringLen;    ///< CAsHashString length
   struct sharedSecList *sslist; ///< list of shared secrets
   bool enableFastReconnect;	 ///< enable fast rekeying protocol run
   bool enableFastDHEx;          ///< enable DH exchange in fast rekeying procedure
   uint32_t fastExpire;          ///< fast reconnect session expiration time (in seconds)
#ifdef HAVE_PTHREAD_H 
   pthread_mutex_t mutex;
#endif
} ikev2_ctx;
 

// function prototypes

struct IKEv2Session *NewSession( struct ikev2_ctx *i2, uint64_t iSPI, uint64_t rSPI, int Type );
struct IKEv2Session *FindISession( struct ikev2_ctx *i2, uint64_t iSPI );
struct IKEv2Session *FindRSession( struct ikev2_ctx *i2, uint64_t rSPI );
struct IKEv2Session *FindSession( struct ikev2_ctx *i2, uint64_t SPI );
struct IKEv2Session *FindSessionByFastid( struct ikev2_ctx *i2, const char* fastid);
void DeleteSession( struct ikev2_ctx *i2, struct IKEv2Session *s );
void ComputeSessionKeys( struct IKEv2Session *s );
void ComputeNewKeys( struct IKEv2Session *s,int dhex );
struct ikev2_ctx * Create_ikev2_ctx(void);
void Free_ikev2_ctx(struct ikev2_ctx *i2);
void FreeSession( struct IKEv2Session *s );
void FreeSessionList(struct IKEv2Session *s);
int FreeSessionIfExpired(struct ikev2_ctx *i2,uint32_t currentTime);

void DumpIKEv2SessionKeys(const struct IKEv2Session *s) ;
#ifdef __cplusplus
}
#endif

#endif
