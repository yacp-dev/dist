/*
 *  logging.h  -  functions for logging
 *  
 *  EAP-IKEv2
 *
 *  This library implements ideas of draft-tschofenig-eap-ikev2-10.txt
 *  Internet-Draft. Version of the document that this library corresponds
 *  to you can find at
 *  http://tools.ietf.org/wg/eap/draft-tschofenig-eap-ikev2-10.txt.
 *
 *  This file is part of libeap-ikev2.
 *
 *  libeap-ikev2 is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  libeap-ikev2 is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with libeap-ikev2; if not, write to the Free Software
 *
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  Copyright (C) 2005-2006 Krzysztof Rzecki <krzysztof.rzecki@ccns.pl>      
 *  Copyright (C) 2005-2006 Rafal Mijal <rafal.mijal@ccns.pl>                
 *  Copyright (C) 2005-2006 Piotr Marnik <piotr.marnik@ccns.pl>              
 *  Copyright (C) 2005-2006 Pawel Matejski <pawel.matejski@ccns.pl>          
 *  Copyright (C) 2003      Udo Schilcher <udo.schilcher@edu.uni-klu.ac.at>
 *  Copyright (C) 2003      Thomas Hambrusch <thambrus@edu.uni-klu.ac.at>          
 *
 */

#ifndef __logging_h
#define __logging_h

#ifdef __cplusplus
extern "C" {
#endif

#include "common.h"

#include <stdarg.h>
 
#define I2L_DBG                   1
#define I2L_INFO                  2
#define I2L_ERR                   3

#define IKE_PRETTY_LOCATION
//#define IKE_SHOW_LOCATION
#ifdef IKE_SHOW_LOCATION
#  ifdef IKE_PRETTY_LOCATION
     char * log_pretty_location(char *func, char *file, int line, char *text);
#    define LOCATION(x) log_pretty_location(__PRETTY_FUNCTION__,__FILE__,__LINE__,(x))
#  else
#    define LOCATION(x)   __FILE__ ":"  TOSTRING(__LINE__) ":" x
#  endif
#else //NOT IKE_SHOW_LOCATION
#  define LOCATION(x) x
#endif //IKE_SHOW_LOCATION

typedef void (*t_ikev2_log_vcallback)(int,const char *,va_list ap);

void ikev2_set_log_callback(t_ikev2_log_vcallback callback);

void xlogf(int level, const  char *, ...);


#ifdef __cplusplus
}
#endif

#endif
