set(CMAKE_IMPORT_FILE_VERSION 1)

set(
  TBLITE_INCLUDEDIRS
  "/usr/include"
  "/usr/include/tblite/modules"
)
find_library(
  TBLITE_LIBRARIES
  "tblite"
  PATHS "/usr/lib"
  NO_DEFAULT_PATH
)
set(
  TBLITE_DEPENDENCIES
  "$<$<BOOL:${TBLITE_USE_MCTCLIB}>:mctc-lib::mctc-lib>"
  "$<$<BOOL:${TBLITE_USE_MULTICHARGE}>:multicharge::multicharge>"
  "$<$<BOOL:${TBLITE_USE_TOMLF}>:toml-f::toml-f>"
  "$<$<BOOL:${TBLITE_USE_DFTD4}>:dftd4::dftd4>"
  "$<$<BOOL:${TBLITE_USE_SDFTD3}>:s-dftd3::s-dftd3>"
  "$<$<BOOL:${TBLITE_USE_DDX}>:ddx::ddx>"
  "$<$<BOOL:${TBLITE_WITH_OpenMP}>:OpenMP::OpenMP_Fortran>"
  "$<$<BOOL:${TBLITE_WITH_HDF5}>:HDF5::HDF5>"
  "$<$<BOOL:${TBLITE_WITH_TREXIO}>:TREXIO::TREXIO>"
  "$<$<BOOL:${TBLITE_WITH_MPI}>:MPI::MPI_Fortran>"
  "$<$<BOOL:${TBLITE_WITH_SCALAPACK}>:SCALAPACK::SCALAPACK>"
  "LAPACK::LAPACK"
)

add_library(tblite::tblite-lib INTERFACE IMPORTED)
add_library(tblite::tblite ALIAS tblite::tblite-lib)
target_link_libraries(tblite::tblite-lib INTERFACE ${TBLITE_LIBRARIES} ${TBLITE_DEPENDENCIES})
target_include_directories(tblite::tblite-lib INTERFACE ${TBLITE_INCLUDEDIRS})
