

set("TBLITE_WITH_API" ON)
set("TBLITE_WITH_OpenMP" ON)
set("TBLITE_WITH_DDX" ON)
set("TBLITE_WITH_TREXIO" ON)
set("TBLITE_WITH_HDF5" OFF)
set("TBLITE_WITH_MPI" OFF)
set("TBLITE_WITH_SCALAPACK" OFF)
set("TBLITE_USE_MCTCLIB" ON)
set("TBLITE_USE_MULTICHARGE" ON)
set("TBLITE_USE_TOMLF" ON)
set("TBLITE_USE_SDFTD3" ON)
set("TBLITE_USE_DFTD4" ON)
set("TBLITE_USE_DDX" ON)

enable_language("Fortran")
enable_language("C")

if(NOT TARGET "tblite::tblite")
  include(CMakeFindDependencyMacro)
  list(APPEND CMAKE_MODULE_PATH "${CMAKE_CURRENT_LIST_DIR}")

  if(NOT TARGET "OpenMP::OpenMP_Fortran" AND TBLITE_WITH_OpenMP)
    find_dependency("OpenMP")
  endif()

  if(NOT TARGET "LAPACK::LAPACK")
    find_dependency("LAPACK")
  endif()

  if(NOT TARGET "ddx" AND TBLITE_USE_DDX)
    find_dependency("ddX" 1.0.0)
  endif()

  if(NOT TARGET "HDF5::HDF5" AND TBLITE_WITH_HDF5)
     find_dependency("HDF5")
  endif()

  if(NOT TARGET "MPI::MPI_Fortran" AND TBLITE_WITH_MPI)
    find_dependency("MPI" COMPONENTS Fortran)
  endif()

  if(NOT TARGET "SCALAPACK::SCALAPACK" AND TBLITE_WITH_SCALAPACK)
    find_dependency("Scalapack")
  endif()

  if(NOT TARGET "TREXIO::TREXIO" AND TBLITE_WITH_TREXIO)
    find_dependency("TREXIO")
  endif()

  if(NOT TARGET "toml-f::toml-f" AND TBLITE_USE_TOMLF)
    find_dependency("toml-f")
  endif()

  if(NOT TARGET "mctc-lib::mctc-lib" AND TBLITE_USE_MCTCLIB)
    find_dependency("mctc-lib")
  endif()

  if(NOT TARGET "multicharge::multicharge" AND TBLITE_USE_MULTICHARGE)
    find_dependency("multicharge")
  endif()

  if(NOT TARGET "dftd4::dftd4" AND TBLITE_USE_DFTD4)
    find_dependency("dftd4" 4.3.0)
  endif()

  if(NOT TARGET "s-dftd3::s-dftd3" AND TBLITE_USE_SDFTD3)
    find_dependency("s-dftd3")
  endif()

  list(REMOVE_AT CMAKE_MODULE_PATH -1)
  include("${CMAKE_CURRENT_LIST_DIR}/tblite-targets.cmake")
endif()
