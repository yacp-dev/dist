/*
 * Library to access the Exchange MAPI database format
 *
 * Copyright (C) 2011-2024, Joachim Metz <joachim.metz@gmail.com>
 *
 * Refer to AUTHORS for acknowledgements.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#if !defined( _LIBMAPIDB_H )
#define _LIBMAPIDB_H

#include <libmapidb/codepage.h>
#include <libmapidb/definitions.h>
#include <libmapidb/error.h>
#include <libmapidb/extern.h>
#include <libmapidb/features.h>
#include <libmapidb/types.h>

#include <stdio.h>

#if defined( __cplusplus )
extern "C" {
#endif

/* -------------------------------------------------------------------------
 * Support functions
 * ------------------------------------------------------------------------- */

/* Returns the library version as a string
 */
LIBMAPIDB_EXTERN \
const char *libmapidb_get_version(
             void );

/* -------------------------------------------------------------------------
 * Error functions
 * ------------------------------------------------------------------------- */

/* Frees an error
 */
LIBMAPIDB_EXTERN \
void libmapidb_error_free(
      libmapidb_error_t **error );

/* Prints a descriptive string of the error to the stream
 * Returns the number of printed characters if successful or -1 on error
 */
LIBMAPIDB_EXTERN \
int libmapidb_error_fprint(
     libmapidb_error_t *error,
     FILE *stream );

/* Prints a descriptive string of the error to the string
 * Returns the number of printed characters if successful or -1 on error
 */
LIBMAPIDB_EXTERN \
int libmapidb_error_sprint(
     libmapidb_error_t *error,
     char *string,
     size_t size );

/* Prints a backtrace of the error to the stream
 * Returns the number of printed characters if successful or -1 on error
 */
LIBMAPIDB_EXTERN \
int libmapidb_error_backtrace_fprint(
     libmapidb_error_t *error,
     FILE *stream );

/* Prints a backtrace of the error to the string
 * Returns the number of printed characters if successful or -1 on error
 */
LIBMAPIDB_EXTERN \
int libmapidb_error_backtrace_sprint(
     libmapidb_error_t *error,
     char *string,
     size_t size );

#if defined( __cplusplus )
}
#endif

#endif /* !defined( _LIBMAPIDB_H ) */

