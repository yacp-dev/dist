/*
** Copyright (C) 2016-2026 Cisco and/or its affiliates. All rights reserved.
** Author: Michael R. Altizer <mialtize@cisco.com>
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License Version 2 as
** published by the Free Software Foundation.  You may not use, modify or
** distribute this program under any other version of the GNU General
** Public License.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

#ifndef _DAQ_VERSION_H
#define _DAQ_VERSION_H

#ifdef __cplusplus
extern "C" {
#endif

#define DAQ_VERSION_MAJOR 3
#define DAQ_VERSION_MINOR 0
#define DAQ_VERSION_PATCH 29
#define DAQ_VERSION_SUBLEVEL 0

#define DAQ_VERSION_NUMERIC ((DAQ_VERSION_MAJOR << 24) | (DAQ_VERSION_MINOR << 16) | (DAQ_VERSION_PATCH << 8) | DAQ_VERSION_SUBLEVEL)

#define DAQ_VERSION_STRING_C_(major, minor, patch, sublevel) \
            #major "." #minor "." #patch "." #sublevel

#define DAQ_VERSION_STRING_C(major, minor, patch, sublevel) \
            DAQ_VERSION_STRING_C_(major, minor, patch, sublevel)

#define DAQ_VERSION_STRING DAQ_VERSION_STRING_C( \
                DAQ_VERSION_MAJOR, DAQ_VERSION_MINOR, \
                DAQ_VERSION_PATCH, DAQ_VERSION_SUBLEVEL)

#ifdef __cplusplus
}
#endif

#endif /* _DAQ_VERSION_H */
