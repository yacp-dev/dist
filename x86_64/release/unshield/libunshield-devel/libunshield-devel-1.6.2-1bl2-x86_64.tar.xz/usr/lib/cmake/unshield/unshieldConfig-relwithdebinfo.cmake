#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "unshield::libunshield" for configuration "RelWithDebInfo"
set_property(TARGET unshield::libunshield APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(unshield::libunshield PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libunshield.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygunshield-1.dll"
  )

list(APPEND _cmake_import_check_targets unshield::libunshield )
list(APPEND _cmake_import_check_files_for_unshield::libunshield "${_IMPORT_PREFIX}/lib/libunshield.dll.a" "${_IMPORT_PREFIX}/bin/cygunshield-1.dll" )

# Import target "unshield::unshield" for configuration "RelWithDebInfo"
set_property(TARGET unshield::unshield APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(unshield::unshield PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/unshield.exe"
  )

list(APPEND _cmake_import_check_targets unshield::unshield )
list(APPEND _cmake_import_check_files_for_unshield::unshield "${_IMPORT_PREFIX}/bin/unshield.exe" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
