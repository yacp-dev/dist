/*
 *  gexecutor.h
 *  Copyright (C) 2003 Giovanni Pardini
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Library General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */


#ifndef _GEXECUTOR_H_
#define _GEXECUTOR_H_

#include <glib-object.h>
#include <sys/types.h>
#include <sys/wait.h>

G_BEGIN_DECLS


/**
 * GExecutor
 *
 * All fields are private and should be only accessed by available functions.
 */
typedef		struct _GExecutor		GExecutor;

typedef		struct _GExecutorClass		GExecutorClass;

/**
 * GExecutorChannel
 * @G_EXECUTOR_CHANNEL_INPUT: standard input.
 * @G_EXECUTOR_CHANNEL_OUTPUT: standard output.
 * @G_EXECUTOR_CHANNEL_ERROR: standard error.
 *
 * These are the standard I/O channels (streams) available for the child process.
 */
typedef enum {
	G_EXECUTOR_CHANNEL_INPUT = 1 << 0,
	G_EXECUTOR_CHANNEL_OUTPUT = 1 << 1,
	G_EXECUTOR_CHANNEL_ERROR = 1 << 2
} GExecutorChannel;


struct _GExecutor {
	GObject object;
	
	/*< private >*/
	
	gchar          *working_directory;
	gchar         **argv;
	gchar         **envp;
	
	gboolean	running;
	pid_t		child_pid; /* It is not -1 as long as the process is running or is a zombie */
	int		child_status;

	
	/* STANDARD_OUTPUT */
	GIOChannel	*out_channel;		/* NULL-encoded channel */
	/* STANDARD_ERROR */
	GIOChannel	*err_channel;		/* NULL-encoded channel */
	/* STANDARD_INPUT */
	GIOChannel	*in_channel;		/* NULL-encoded channel */

	gboolean	joined_output;		/* TRUE if all output from child process should be directed only to stdout */

	guint		monitor_idle_id;
};

struct _GExecutorClass {
	GObjectClass parent_class;
	
	void (*child_exited)(GExecutor *executor);
};


GType		g_executor_get_type		(void);

#define G_EXECUTOR(obj)          G_TYPE_CHECK_INSTANCE_CAST(obj, g_executor_get_type(), GExecutor)
#define G_EXECUTOR_CLASS(klass)  G_TYPE_CHECK_CLASS_CAST(klass, g_executor_get_type(), GExecutorClass)
#define IS_G_EXECUTOR(obj)       G_TYPE_CHECK_INSTANCE_TYPE(obj, g_executor_get_type())



/*  PUBLIC FUCNTIONS  */
GExecutor*	g_executor_new			(void);

void		g_executor_setup		(GExecutor *executor,
						 const gchar *working_directory,
						 const gchar *const argv[],
						 const gchar *const envp[]);

gboolean	g_executor_run			(GExecutor *executor,
						 GExecutorChannel channels,
						 GError **error);

gboolean	g_executor_run_sync		(GExecutor *executor,
						 gchar **standard_output,
						 gchar **standard_error,
						 GError **error);

gboolean	g_executor_wait			(GExecutor *executor);

gboolean	g_executor_kill			(GExecutor *executor,
						 int sig);


gboolean	g_executor_is_running		(GExecutor *executor);

GIOChannel*	g_executor_get_output_channel	(GExecutor *executor);

GIOChannel*	g_executor_get_error_channel	(GExecutor *executor);

GIOChannel*	g_executor_get_input_channel	(GExecutor *executor);

gint		g_executor_get_status		(GExecutor *executor);


const gchar *	g_executor_get_working_dir	(GExecutor *executor);

gboolean	g_executor_get_joined_output	(GExecutor *executor);

const gchar**	g_executor_get_argv		(GExecutor *executor);

const gchar**	g_executor_get_envp		(GExecutor *executor);

void		g_executor_set_working_dir	(GExecutor *executor,
						 const gchar *working_directory);

void		g_executor_set_joined_output	(GExecutor *executor,
						 gboolean joined_output);

void		g_executor_set_argv		(GExecutor *executor,
						 const gchar *const argv[]);

void		g_executor_set_envp		(GExecutor *executor,
						 const gchar *const envp[]);




G_END_DECLS

#endif
