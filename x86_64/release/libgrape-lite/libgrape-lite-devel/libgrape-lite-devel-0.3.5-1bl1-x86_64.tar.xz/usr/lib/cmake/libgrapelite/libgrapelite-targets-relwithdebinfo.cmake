#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "grape-lite" for configuration "RelWithDebInfo"
set_property(TARGET grape-lite APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(grape-lite PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libgrape-lite.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cyggrape-lite-0.dll"
  )

list(APPEND _cmake_import_check_targets grape-lite )
list(APPEND _cmake_import_check_files_for_grape-lite "${_IMPORT_PREFIX}/lib/libgrape-lite.dll.a" "${_IMPORT_PREFIX}/bin/cyggrape-lite-0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
