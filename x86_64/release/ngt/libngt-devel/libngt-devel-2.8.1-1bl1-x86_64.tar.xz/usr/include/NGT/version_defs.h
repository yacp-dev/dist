//
// Do *NOT* edit this file.
//
#define	NGT_BUILD_DATE		"2026/10/27 07:36:01"
#define	NGT_VERSION		"2.8.1"
