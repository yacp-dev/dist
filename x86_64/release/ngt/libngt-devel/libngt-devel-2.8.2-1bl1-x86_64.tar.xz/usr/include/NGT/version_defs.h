//
// Do *NOT* edit this file.
//
#define	NGT_BUILD_DATE		"2026/11/18 14:49:52"
#define	NGT_VERSION		"2.8.2"
