#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Yder::Yder" for configuration "RelWithDebInfo"
set_property(TARGET Yder::Yder APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(Yder::Yder PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libyder.dll.a"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELWITHDEBINFO "Orcania::Orcania"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygyder-1.4.dll"
  )

list(APPEND _cmake_import_check_targets Yder::Yder )
list(APPEND _cmake_import_check_files_for_Yder::Yder "${_IMPORT_PREFIX}/lib/libyder.dll.a" "${_IMPORT_PREFIX}/bin/cygyder-1.4.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
