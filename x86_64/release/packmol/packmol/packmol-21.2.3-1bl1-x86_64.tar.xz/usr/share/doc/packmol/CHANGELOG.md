packmol changelog
===========================
  
[badge-breaking]: https://img.shields.io/badge/BREAKING-red.svg
[badge-deprecation]: https://img.shields.io/badge/Deprecation-orange.svg
[badge-feature]: https://img.shields.io/badge/Feature-green.svg
[badge-experimental]: https://img.shields.io/badge/Experimental-yellow.svg
[badge-enhancement]: https://img.shields.io/badge/Enhancement-blue.svg
[badge-bugfix]: https://img.shields.io/badge/Bugfix-purple.svg
[badge-fix]: https://img.shields.io/badge/Fix-purple.svg
[badge-info]: https://img.shields.io/badge/Info-gray.svg

Version 21.2.3
--------------
- ![INFO][badge-info] Update versions of CellListMap.jl and PDBTools.jl packages in test infraestructure.

Version 21.2.2
--------------
- ![INFO][badge-info] Fix code typos.
- ![INFO][badge-info] Add changelog verification CI run.

Version 21.2.1
--------------
- ![INFO][badge-info] Avoid looping above `maxkeywords` in input file reading of radii.

Version 21.2.0
--------------
- ![ENHANCEMENT][badge-enhancement]: Add `ignore_conect` and `non_standard_conect` options. The first
will just make packmol ignore all CONECT lines. The second will use a non-standard reading of the 
lines, in which the atom indices are expected to be separated by spaces. The default is `ignore_conect = .false.`
and `non_standard_conect = .false.`, such that the CONECT lines are not ignored and the standard PDB
format is expected. 
- ![INFO][badge-info] add test to pipy distribution.

Version 21.1.4
--------------
- ![INFO][badge-info] add test to pipy distribution.

Version 21.1.2
--------------
- ![INFO][badge-info] add pip install packmol installation option.
- ![INFO][badge-info] The `release.sh` script was renamed to `update_version.sh` and just updates version numbers in the files, without tagging a release.

Version 21.1.1
--------------
- ![INFO][badge-info] Update minimum CMake compatibility to 3.5.0.
- ![INFO][badge-info] Add a remark to what is written as `CRYST1` information when no-PBCs are used. Suggest using PBCs Fixes [103](https://github.com/m3g/packmol/issues/103). Update the documentation accordingly.

Version 21.1.0
--------------
- ![FEATURE][badge-feature] Support CLI input and output file specifications (i. e. `-i input.inp -o output.pdb`) ([PR](https://github.com/m3g/packmol/pull/101)).

Version 21.0.4
--------------
- For older versions, see the [releases page](https://github.com/m3g/packmol/releases).
