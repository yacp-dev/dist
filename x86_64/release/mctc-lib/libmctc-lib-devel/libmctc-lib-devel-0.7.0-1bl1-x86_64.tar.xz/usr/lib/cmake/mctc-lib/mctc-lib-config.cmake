

set(MCTCLIB_WITH_OpenMP OFF)
set(MCTCLIB_WITH_JSON ON)
set(MCTCLIB_USE_JONQUIL ON)
set(MCTCLIB_USE_TOMLF ON)

enable_language("Fortran")

if(NOT TARGET "mctc-lib::mctc-lib")
  include(CMakeFindDependencyMacro)

  if(NOT TARGET "OpenMP::OpenMP_Fortran" AND MCTCLIB_WITH_OpenMP)
    find_dependency("OpenMP")
  endif()

  if(NOT TARGET "toml-f::toml-f" AND MCTCLIB_USE_TOMLF)
    find_dependency("toml-f")
  endif()

  if(NOT TARGET "jonquil::jonquil" AND MCTCLIB_USE_JONQUIL)
    find_dependency("jonquil")
  endif()

  include("${CMAKE_CURRENT_LIST_DIR}/mctc-lib-targets.cmake")
endif()
