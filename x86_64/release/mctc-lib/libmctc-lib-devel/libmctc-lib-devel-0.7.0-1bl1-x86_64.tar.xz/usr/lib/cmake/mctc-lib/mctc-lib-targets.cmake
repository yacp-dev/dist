set(CMAKE_IMPORT_FILE_VERSION 1)

set(
  MCTCLIB_INCLUDEDIRS
  "/usr/include"
  "/usr/include/mctc-lib/modules"
)
find_library(
  MCTCLIB_LIBRARIES
  "mctc-lib"
  PATHS "/usr/lib"
  NO_DEFAULT_PATH
)
set(
  MCTCLIB_DEPENDENCIES
  "$<$<BOOL:${MCTCLIB_USE_JONQUIL}>:jonquil::jonquil>"
  "$<$<BOOL:${MCTCLIB_USE_TOMLF}>:toml-f::toml-f>"
  "$<$<BOOL:${MCTCLIB_WITH_OpenMP}>:OpenMP::OpenMP_Fortran>"
)

add_library(mctc-lib::mctc-lib-lib INTERFACE IMPORTED)
add_library(mctc-lib::mctc-lib ALIAS mctc-lib::mctc-lib-lib)
target_link_libraries(mctc-lib::mctc-lib-lib INTERFACE ${MCTCLIB_LIBRARIES} ${MCTCLIB_DEPENDENCIES})
target_include_directories(mctc-lib::mctc-lib-lib INTERFACE ${MCTCLIB_INCLUDEDIRS})
