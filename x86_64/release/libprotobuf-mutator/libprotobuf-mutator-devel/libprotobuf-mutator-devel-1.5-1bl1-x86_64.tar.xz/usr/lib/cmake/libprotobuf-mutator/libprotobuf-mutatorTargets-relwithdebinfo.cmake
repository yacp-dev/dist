#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "libprotobuf-mutator::protobuf-mutator-libfuzzer" for configuration "RelWithDebInfo"
set_property(TARGET libprotobuf-mutator::protobuf-mutator-libfuzzer APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(libprotobuf-mutator::protobuf-mutator-libfuzzer PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libprotobuf-mutator-libfuzzer.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygprotobuf-mutator-libfuzzer-0.dll"
  )

list(APPEND _cmake_import_check_targets libprotobuf-mutator::protobuf-mutator-libfuzzer )
list(APPEND _cmake_import_check_files_for_libprotobuf-mutator::protobuf-mutator-libfuzzer "${_IMPORT_PREFIX}/lib/libprotobuf-mutator-libfuzzer.dll.a" "${_IMPORT_PREFIX}/bin/cygprotobuf-mutator-libfuzzer-0.dll" )

# Import target "libprotobuf-mutator::protobuf-mutator" for configuration "RelWithDebInfo"
set_property(TARGET libprotobuf-mutator::protobuf-mutator APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(libprotobuf-mutator::protobuf-mutator PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libprotobuf-mutator.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygprotobuf-mutator-0.dll"
  )

list(APPEND _cmake_import_check_targets libprotobuf-mutator::protobuf-mutator )
list(APPEND _cmake_import_check_files_for_libprotobuf-mutator::protobuf-mutator "${_IMPORT_PREFIX}/lib/libprotobuf-mutator.dll.a" "${_IMPORT_PREFIX}/bin/cygprotobuf-mutator-0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
