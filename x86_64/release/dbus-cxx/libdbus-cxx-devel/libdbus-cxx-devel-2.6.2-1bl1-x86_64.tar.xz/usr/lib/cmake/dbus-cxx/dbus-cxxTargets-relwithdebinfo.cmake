#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "dbus-cxx::dbus-cxx-glib" for configuration "RelWithDebInfo"
set_property(TARGET dbus-cxx::dbus-cxx-glib APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(dbus-cxx::dbus-cxx-glib PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libdbus-cxx-glib.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygdbus-cxx-glib-2.dll"
  )

list(APPEND _cmake_import_check_targets dbus-cxx::dbus-cxx-glib )
list(APPEND _cmake_import_check_files_for_dbus-cxx::dbus-cxx-glib "${_IMPORT_PREFIX}/lib/libdbus-cxx-glib.dll.a" "${_IMPORT_PREFIX}/bin/cygdbus-cxx-glib-2.dll" )

# Import target "dbus-cxx::dbus-cxx" for configuration "RelWithDebInfo"
set_property(TARGET dbus-cxx::dbus-cxx APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(dbus-cxx::dbus-cxx PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libdbus-cxx.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygdbus-cxx-2.dll"
  )

list(APPEND _cmake_import_check_targets dbus-cxx::dbus-cxx )
list(APPEND _cmake_import_check_files_for_dbus-cxx::dbus-cxx "${_IMPORT_PREFIX}/lib/libdbus-cxx.dll.a" "${_IMPORT_PREFIX}/bin/cygdbus-cxx-2.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
