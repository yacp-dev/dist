set(CMAKE_IMPORT_FILE_VERSION 1)

set(
  DFTD4_INCLUDEDIRS
  "/usr/include"
  "/usr/include/dftd4/modules"
)
find_library(
  DFTD4_LIBRARIES
  "dftd4"
  PATHS "/usr/lib"
  NO_DEFAULT_PATH
)
set(
  DFTD4_DEPENDENCIES
  "$<$<BOOL:${DFTD4_USE_MCTCLIB}>:mctc-lib::mctc-lib>"
  "$<$<BOOL:${DFTD4_USE_MULTICHARGE}>:multicharge::multicharge>"
  "$<$<BOOL:${DFTD4_WITH_OpenMP}>:OpenMP::OpenMP_Fortran>"
  "LAPACK::LAPACK"
)

add_library(dftd4::dftd4-lib INTERFACE IMPORTED)
add_library(dftd4::dftd4 ALIAS dftd4::dftd4-lib)
target_link_libraries(dftd4::dftd4-lib INTERFACE ${DFTD4_LIBRARIES} ${DFTD4_DEPENDENCIES})
target_include_directories(dftd4::dftd4-lib INTERFACE ${DFTD4_INCLUDEDIRS})
