

set(DFTD4_WITH_OpenMP ON)
set(DFTD4_WITH_API ON)
set(DFTD4_WITH_API_V2 OFF)
set(DFTD4_WITH_ILP64 OFF)
set(DFTD4_USE_MCTCLIB ON)
set(DFTD4_USE_MULTICHARGE ON)

enable_language("Fortran")
if(DFTD4_WITH_API)
  enable_language("C")
endif()

if(NOT TARGET "dftd4::dftd4")
  include(CMakeFindDependencyMacro)
  list(APPEND CMAKE_MODULE_PATH "${CMAKE_CURRENT_LIST_DIR}")

  if(NOT TARGET "OpenMP::OpenMP_Fortran" AND DFTD4_WITH_OpenMP)
    find_dependency("OpenMP")
  endif()

  if(NOT TARGET "LAPACK::LAPACK")
    find_dependency("LAPACK")
  endif()

  if(NOT TARGET "mctc-lib::mctc-lib" AND DFTD4_USE_MCTCLIB)
    find_dependency("mctc-lib")
  endif()

  if(NOT TARGET "multicharge::multicharge" AND DFTD4_USE_MULTICHARGE)
    find_dependency("multicharge")
  endif()

  list(REMOVE_AT CMAKE_MODULE_PATH -1)
  include("${CMAKE_CURRENT_LIST_DIR}/dftd4-targets.cmake")
endif()
