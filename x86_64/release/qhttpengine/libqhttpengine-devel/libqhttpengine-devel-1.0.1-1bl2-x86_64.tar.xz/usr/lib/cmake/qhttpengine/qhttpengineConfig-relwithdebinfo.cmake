#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "qhttpengine" for configuration "RelWithDebInfo"
set_property(TARGET qhttpengine APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(qhttpengine PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libqhttpengine.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygqhttpengine-1.dll"
  )

list(APPEND _cmake_import_check_targets qhttpengine )
list(APPEND _cmake_import_check_files_for_qhttpengine "${_IMPORT_PREFIX}/lib/libqhttpengine.dll.a" "${_IMPORT_PREFIX}/bin/cygqhttpengine-1.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
