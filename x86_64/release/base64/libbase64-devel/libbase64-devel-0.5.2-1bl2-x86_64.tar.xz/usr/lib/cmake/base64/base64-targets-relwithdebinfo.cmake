#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "aklomp::base64" for configuration "RelWithDebInfo"
set_property(TARGET aklomp::base64 APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(aklomp::base64 PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libbase64.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygbase64-0.dll"
  )

list(APPEND _cmake_import_check_targets aklomp::base64 )
list(APPEND _cmake_import_check_files_for_aklomp::base64 "${_IMPORT_PREFIX}/lib/libbase64.dll.a" "${_IMPORT_PREFIX}/bin/cygbase64-0.dll" )

# Import target "aklomp::base64-bin" for configuration "RelWithDebInfo"
set_property(TARGET aklomp::base64-bin APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(aklomp::base64-bin PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/base64.exe"
  )

list(APPEND _cmake_import_check_targets aklomp::base64-bin )
list(APPEND _cmake_import_check_files_for_aklomp::base64-bin "${_IMPORT_PREFIX}/bin/base64.exe" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
