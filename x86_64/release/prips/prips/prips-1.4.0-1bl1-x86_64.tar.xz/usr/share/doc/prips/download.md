<!--
SPDX-FileCopyrightText: Peter Pentchev <roam@ringlet.net>
SPDX-License-Identifier: GPL-2.0-or-later
-->

# Download

These are the released versions of [prips](index.md) available for download.

## [1.4.0] - 2026-11-16

### Source tarball

- [prips-1.4.0.tar.gz](https://devel.ringlet.net/files/sys/prips/prips-1.4.0.tar.gz)
  (with [a PGP signature](https://devel.ringlet.net/files/sys/prips/prips-1.4.0.tar.gz.asc))
- [prips-1.4.0.tar.bz2](https://devel.ringlet.net/files/sys/prips/prips-1.4.0.tar.bz2)
  (with [a PGP signature](https://devel.ringlet.net/files/sys/prips/prips-1.4.0.tar.bz2.asc))
- [prips-1.4.0.tar.xz](https://devel.ringlet.net/files/sys/prips/prips-1.4.0.tar.xz)
  (with [a PGP signature](https://devel.ringlet.net/files/sys/prips/prips-1.4.0.tar.xz.asc))

## [1.3.1] - 2026-01-17

### Source tarball

- [prips-1.3.1.tar.gz](https://devel.ringlet.net/files/sys/prips/prips-1.3.1.tar.gz)
  (with [a PGP signature](https://devel.ringlet.net/files/sys/prips/prips-1.3.1.tar.gz.asc))
- [prips-1.3.1.tar.bz2](https://devel.ringlet.net/files/sys/prips/prips-1.3.1.tar.bz2)
  (with [a PGP signature](https://devel.ringlet.net/files/sys/prips/prips-1.3.1.tar.bz2.asc))
- [prips-1.3.1.tar.xz](https://devel.ringlet.net/files/sys/prips/prips-1.3.1.tar.xz)
  (with [a PGP signature](https://devel.ringlet.net/files/sys/prips/prips-1.3.1.tar.xz.asc))

## [1.2.2] - 2025-04-12

### Source tarball

- [prips-1.2.2.tar.gz](https://devel.ringlet.net/files/sys/prips/prips-1.2.2.tar.gz)
  (with [a PGP signature](https://devel.ringlet.net/files/sys/prips/prips-1.2.2.tar.gz.asc))
- [prips-1.2.2.tar.bz2](https://devel.ringlet.net/files/sys/prips/prips-1.2.2.tar.bz2)
  (with [a PGP signature](https://devel.ringlet.net/files/sys/prips/prips-1.2.2.tar.bz2.asc))
- [prips-1.2.2.tar.xz](https://devel.ringlet.net/files/sys/prips/prips-1.2.2.tar.xz)
  (with [a PGP signature](https://devel.ringlet.net/files/sys/prips/prips-1.2.2.tar.xz.asc))

## [1.2.0] - 2021-12-18

### Source tarball

- [prips-1.2.0.tar.gz](https://devel.ringlet.net/files/sys/prips/prips-1.2.0.tar.gz)
  (with [a PGP signature](https://devel.ringlet.net/files/sys/prips/prips-1.2.0.tar.gz.asc))
- [prips-1.2.0.tar.bz2](https://devel.ringlet.net/files/sys/prips/prips-1.2.0.tar.bz2)
  (with [a PGP signature](https://devel.ringlet.net/files/sys/prips/prips-1.2.0.tar.bz2.asc))
- [prips-1.2.0.tar.xz](https://devel.ringlet.net/files/sys/prips/prips-1.2.0.tar.xz)
  (with [a PGP signature](https://devel.ringlet.net/files/sys/prips/prips-1.2.0.tar.xz.asc))

## [1.1.1] - 2018-12-25

### Source tarball

- [prips-1.1.1.tar.gz](https://devel.ringlet.net/files/sys/prips/prips-1.1.1.tar.gz)
  (with [a PGP signature](https://devel.ringlet.net/files/sys/prips/prips-1.1.1.tar.gz.asc))
- [prips-1.1.1.tar.bz2](https://devel.ringlet.net/files/sys/prips/prips-1.1.1.tar.bz2)
  (with [a PGP signature](https://devel.ringlet.net/files/sys/prips/prips-1.1.1.tar.bz2.asc))
- [prips-1.1.1.tar.xz](https://devel.ringlet.net/files/sys/prips/prips-1.1.1.tar.xz)
  (with [a PGP signature](https://devel.ringlet.net/files/sys/prips/prips-1.1.1.tar.xz.asc))

## [1.1.0] - 2018-05-14

### Source tarball

- [prips-1.1.0.tar.gz](https://devel.ringlet.net/files/sys/prips/prips-1.1.0.tar.gz)
  (with [a PGP signature](https://devel.ringlet.net/files/sys/prips/prips-1.1.0.tar.gz.asc))
- [prips-1.1.0.tar.bz2](https://devel.ringlet.net/files/sys/prips/prips-1.1.0.tar.bz2)
  (with [a PGP signature](https://devel.ringlet.net/files/sys/prips/prips-1.1.0.tar.bz2.asc))
- [prips-1.1.0.tar.xz](https://devel.ringlet.net/files/sys/prips/prips-1.1.0.tar.xz)
  (with [a PGP signature](https://devel.ringlet.net/files/sys/prips/prips-1.1.0.tar.xz.asc))

## [1.0.2] - 2018-01-15

### Source tarball

- [prips-1.0.2.tar.gz](https://devel.ringlet.net/files/sys/prips/prips-1.0.2.tar.gz)
  (with [a PGP signature](https://devel.ringlet.net/files/sys/prips/prips-1.0.2.tar.gz.asc))
- [prips-1.0.2.tar.bz2](https://devel.ringlet.net/files/sys/prips/prips-1.0.2.tar.bz2)
  (with [a PGP signature](https://devel.ringlet.net/files/sys/prips/prips-1.0.2.tar.bz2.asc))
- [prips-1.0.2.tar.xz](https://devel.ringlet.net/files/sys/prips/prips-1.0.2.tar.xz)
  (with [a PGP signature](https://devel.ringlet.net/files/sys/prips/prips-1.0.2.tar.xz.asc))

## [1.0.1] - 2017-01-03

### Source tarball

- [prips-1.0.1.tar.gz](https://devel.ringlet.net/files/sys/prips/prips-1.0.1.tar.gz)
  (with [a PGP signature](https://devel.ringlet.net/files/sys/prips/prips-1.0.1.tar.gz.asc))
- [prips-1.0.1.tar.bz2](https://devel.ringlet.net/files/sys/prips/prips-1.0.1.tar.bz2)
  (with [a PGP signature](https://devel.ringlet.net/files/sys/prips/prips-1.0.1.tar.bz2.asc))
- [prips-1.0.1.tar.xz](https://devel.ringlet.net/files/sys/prips/prips-1.0.1.tar.xz)
  (with [a PGP signature](https://devel.ringlet.net/files/sys/prips/prips-1.0.1.tar.xz.asc))

## [1.0.0] - 2016-04-11

### Source tarball

- [prips-1.0.0.tar.gz](https://devel.ringlet.net/files/sys/prips/prips-1.0.0.tar.gz)
  (with [a PGP signature](https://devel.ringlet.net/files/sys/prips/prips-1.0.0.tar.gz.asc))
- [prips-1.0.0.tar.bz2](https://devel.ringlet.net/files/sys/prips/prips-1.0.0.tar.bz2)
  (with [a PGP signature](https://devel.ringlet.net/files/sys/prips/prips-1.0.0.tar.bz2.asc))
- [prips-1.0.0.tar.xz](https://devel.ringlet.net/files/sys/prips/prips-1.0.0.tar.xz)
  (with [a PGP signature](https://devel.ringlet.net/files/sys/prips/prips-1.0.0.tar.xz.asc))

## [0.9.9] - 2011-03-10

### Source tarball

- [prips-0.9.9.tar.gz](https://devel.ringlet.net/files/sys/prips/prips-0.9.9.tar.gz)
  (with [a PGP signature](https://devel.ringlet.net/files/sys/prips/prips-0.9.9.tar.gz.asc))
- [prips-0.9.9.tar.bz2](https://devel.ringlet.net/files/sys/prips/prips-0.9.9.tar.bz2)
  (with [a PGP signature](https://devel.ringlet.net/files/sys/prips/prips-0.9.9.tar.bz2.asc))

## [0.9.8] - 2011-03-01

### Source tarball

- [prips-0.9.8.tar.gz](https://devel.ringlet.net/files/sys/prips/prips-0.9.8.tar.gz)
  (with [a PGP signature](https://devel.ringlet.net/files/sys/prips/prips-0.9.8.tar.gz.asc))
- [prips-0.9.8.tar.bz2](https://devel.ringlet.net/files/sys/prips/prips-0.9.8.tar.bz2)
  (with [a PGP signature](https://devel.ringlet.net/files/sys/prips/prips-0.9.8.tar.bz2.asc))

## [0.9.7] - 2010-06-23

### Source tarball

- [prips-0.9.7.tar.gz](https://devel.ringlet.net/files/sys/prips/prips-0.9.7.tar.gz)
  (with [a PGP signature](https://devel.ringlet.net/files/sys/prips/prips-0.9.7.tar.gz.asc))

## [0.9.6] - 2009-04-04

### Source tarball

- [prips-0.9.6.tar.gz](https://devel.ringlet.net/files/sys/prips/prips-0.9.6.tar.gz)
  (with [a PGP signature](https://devel.ringlet.net/files/sys/prips/prips-0.9.6.tar.gz.asc))

## [0.9.5] - 2009-03-27

### Source tarball

- [prips-0.9.5.tar.gz](https://devel.ringlet.net/files/sys/prips/prips-0.9.5.tar.gz)
  (with [a PGP signature](https://devel.ringlet.net/files/sys/prips/prips-0.9.5.tar.gz.asc))

## [0.9.4]

### Source tarball

- [prips-0.9.4.tar.gz](https://devel.ringlet.net/files/sys/prips/prips-0.9.4.tar.gz)
  (with [a PGP signature](https://devel.ringlet.net/files/sys/prips/prips-0.9.4.tar.gz.asc))

[1.4.0]: https://git.sr.ht/~ppentchev/prips/refs/tags/release/1.4.0
[1.3.1]: https://git.sr.ht/~ppentchev/prips/refs/tags/release/1.3.1
[1.2.2]: https://git.sr.ht/~ppentchev/prips/refs/tags/release/1.2.2
[1.2.0]: https://git.sr.ht/~ppentchev/prips/refs/tags/release/1.2.0
[1.1.1]: https://git.sr.ht/~ppentchev/prips/refs/tags/release/1.1.1
[1.1.0]: https://git.sr.ht/~ppentchev/prips/refs/tags/release/1.1.0
[1.0.2]: https://git.sr.ht/~ppentchev/prips/refs/tags/release/1.0.2
[1.0.1]: https://git.sr.ht/~ppentchev/prips/refs/tags/release/1.0.1
[1.0.0]: https://git.sr.ht/~ppentchev/prips/refs/tags/release/1.0.0
[0.9.9]: https://git.sr.ht/~ppentchev/prips/refs/tags/release/0.9.9
[0.9.8]: https://git.sr.ht/~ppentchev/prips/refs/tags/release/0.9.8
[0.9.7]: https://git.sr.ht/~ppentchev/prips/refs/tags/release/0.9.7
[0.9.6]: https://git.sr.ht/~ppentchev/prips/refs/tags/release/0.9.6
[0.9.5]: https://git.sr.ht/~ppentchev/prips/refs/tags/release/0.9.5
[0.9.4]: https://git.sr.ht/~ppentchev/prips/refs/tags/release/0.9.4
