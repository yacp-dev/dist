#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Spglib::symspg" for configuration "RelWithDebInfo"
set_property(TARGET Spglib::symspg APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(Spglib::symspg PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libsymspg.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygsymspg-2.dll"
  )

list(APPEND _cmake_import_check_targets Spglib::symspg )
list(APPEND _cmake_import_check_files_for_Spglib::symspg "${_IMPORT_PREFIX}/lib/libsymspg.dll.a" "${_IMPORT_PREFIX}/bin/cygsymspg-2.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
