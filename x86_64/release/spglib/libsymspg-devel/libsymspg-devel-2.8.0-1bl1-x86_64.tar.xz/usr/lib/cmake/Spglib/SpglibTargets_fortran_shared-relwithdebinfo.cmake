#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Spglib::fortran_mod" for configuration "RelWithDebInfo"
set_property(TARGET Spglib::fortran_mod APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(Spglib::fortran_mod PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libspglib_f08.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygspglib_f08-2.dll"
  )

list(APPEND _cmake_import_check_targets Spglib::fortran_mod )
list(APPEND _cmake_import_check_files_for_Spglib::fortran_mod "${_IMPORT_PREFIX}/lib/libspglib_f08.dll.a" "${_IMPORT_PREFIX}/bin/cygspglib_f08-2.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
