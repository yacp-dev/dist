#ifndef RESIP_TransportFailure_hxx
#define RESIP_TransportFailure_hxx

#include <iosfwd>
#include "resip/stack/TransactionMessage.hxx"
#include "rutil/Data.hxx"
#include "rutil/HeapInstanceCounter.hxx"

namespace resip
{

/** This message is used to indicate that the TransportSelector has sent a sip
    message using either reliable or unreliable transport
*/
class TransportFailure : public TransactionMessage
{
   public:
      RESIP_HeapCount(TransportFailure);
      enum FailureReason
      {
         None = 0, //invalid
         TransportNoExistConn,
         Failure,
         TransportNoSocket,
         TransportBadConnect,
         TransportShutdown,
         ConnectionUnknown,
         ConnectionException,
         NoTransport,
         NoRoute,
         CertNameMismatch,
         CertValidationFailure
      };

      TransportFailure(const Data& transactionId, FailureReason f, int subCode=0);

      virtual const Data& getTransactionId() const;
      virtual bool isClientTransaction() const;

      FailureReason getFailureReason() const { return mFailureReason; }
      int getFailureSubCode() const { return mFailureSubCode; }

      static const char* failureReasonToString(FailureReason failureReason);

      virtual EncodeStream& encodeBrief(EncodeStream& str) const;
      virtual EncodeStream& encode(EncodeStream& strm) const;

   private:
      Data mTransactionId;
      FailureReason mFailureReason;
      int mFailureSubCode;
};

}

#endif

/* ====================================================================
 * The Vovida Software License, Version 1.0
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The names "VOCAL", "Vovida Open Communication Application Library",
 *    and "Vovida Open Communication Application Library (VOCAL)" must
 *    not be used to endorse or promote products derived from this
 *    software without prior written permission. For written
 *    permission, please contact vocal@vovida.org.
 *
 * 4. Products derived from this software may not be called "VOCAL", nor
 *    may "VOCAL" appear in their name, without prior written
 *    permission of Vovida Networks, Inc.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE AND
 * NON-INFRINGEMENT ARE DISCLAIMED.  IN NO EVENT SHALL VOVIDA
 * NETWORKS, INC. OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT DAMAGES
 * IN EXCESS OF $1,000, NOR FOR ANY INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
 * USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
 * DAMAGE.
 *
 * ====================================================================
 *
 * This software consists of voluntary contributions made by Vovida
 * Networks, Inc. and many individuals on behalf of Vovida Networks,
 * Inc.  For more information on Vovida Networks, Inc., please see
 * <http://www.vovida.org/>.
 *
 * vi: set shiftwidth=3 expandtab:
 */
