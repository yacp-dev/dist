/*
 More information can be obtained from
 http://www.cmake.org/Wiki/CMake:How_To_Write_Platform_Checks
*/

#define GPERF_SIZE_TYPE size_t
/* #undef HAVE_EPOLL */
#define USE_MYSQL
#define USE_POSTGRESQL
#define USE_MAXMIND_GEOIP
#define HAVE_CLOCK_GETTIME_MONOTONIC 1
#define DEFAULT_BRIDGE_MAX_IN_OUTPUTS 20
/* #undef SIPX_NO_RECORD */

/* #undef ENABLE_LOG_REPOSITORY_DETAILS */
/* #undef RESIPROCATE_GIT_ID */
/* #undef RESIPROCATE_BRANCH_NAME */
/* #undef USE_FQDN_FOR_JSON_CEE_HOSTNAME */
/* #undef RESIP_BIG_ENDIAN */
/* #undef REPRO_BUILD_REV */
/* #undef REPRO_BUILD_HOST */
#define DB_HEADER "db_cxx.h"
#define RESIP_SIP_MSG_MAX_BYTES 10485760
/* #undef USE_SIGCOMP */
#define RESIP_HAVE_STRING_VIEW 1

// TIME_WITH_SYS_TIME
// STDC_HEADERS
// more ...
