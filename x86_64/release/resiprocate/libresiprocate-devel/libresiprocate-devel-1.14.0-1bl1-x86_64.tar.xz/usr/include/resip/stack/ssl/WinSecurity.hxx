#if !defined(RESIP_WINSECURITY_HXX)
#define RESIP_WINSECURITY_HXX

#if defined(HAVE_CONFIG_H)
  #include "config.h"
#endif


#include "resip/stack/ssl/Security.hxx"
#include <wincrypt.h>

namespace resip
{

/**
   WARNING - This class is only appropriate for client TLS connections, as it 
   only loads root certs.  There is currently no logic to load domain or 
   user certificates.
*/

class WinSecurity : public Security
{
   public:

      typedef enum
      {
         ROOT_CA_STORE=1, //"ROOT": predefined system store
         CA_STORE=2,      //"CA": predefined system store 
         PRIVATE_STORE=3, //"MY": predefined system store; should store the domain certificate/private key
         USERS_STORE=4    //"DOMAIN_USERS" (only for server):
                          //administrator-defined system store; should store the
                          //certificate/private keys for the users associated
                          //with the domain
      } MsCertStoreType;
      //for details on certificate stores, see
      //http://msdn.microsoft.com/en-us/library/windows/desktop/aa376539(v=vs.85).aspx
      //http://msdn.microsoft.com/en-us/library/windows/desktop/aa386971(v=vs.85).aspx
      
      WinSecurity(const CipherList& cipherList = ExportableSuite, 
                  const Data& defaultPrivateKeyPassPhrase = Data::Empty, 
                  const Data& dHParamsFilename = Data::Empty) : 
         Security(cipherList, defaultPrivateKeyPassPhrase, dHParamsFilename) {}
      WinSecurity(const Data& pathToCerts, 
                  const CipherList& cipherList = ExportableSuite,
                  const Data & defaultPrivateKeyPassPhrase = Data::Empty,
                  const Data & dHParamsFilename = Data::Empty) :
         Security(pathToCerts, cipherList, defaultPrivateKeyPassPhrase, dHParamsFilename) {}

      virtual void preload();
      virtual void onReadPEM(const Data& name, PEMType type, Data& buffer) const;
      virtual void onWritePEM(const Data& name, PEMType type, const Data& buffer) const;
      virtual void onRemovePEM(const Data& name, PEMType type) const;


   protected:
      HCERTSTORE openSystemCertStore(const Data& name);
      void getCerts(MsCertStoreType eType);
      void getCredentials(MsCertStoreType eType);
      void closeCertifStore(HCERTSTORE);
};

}
#endif

/* ====================================================================
 * The Vovida Software License, Version 1.0 
 * 
 * Copyright (c) 2000 Vovida Networks, Inc.  All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The names "VOCAL", "Vovida Open Communication Application Library",
 *    and "Vovida Open Communication Application Library (VOCAL)" must
 *    not be used to endorse or promote products derived from this
 *    software without prior written permission. For written
 *    permission, please contact vocal@vovida.org.
 *
 * 4. Products derived from this software may not be called "VOCAL", nor
 *    may "VOCAL" appear in their name, without prior written
 *    permission of Vovida Networks, Inc.
 * 
 * THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE AND
 * NON-INFRINGEMENT ARE DISCLAIMED.  IN NO EVENT SHALL VOVIDA
 * NETWORKS, INC. OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT DAMAGES
 * IN EXCESS OF $1,000, NOR FOR ANY INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
 * USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
 * DAMAGE.
 * 
 * ====================================================================
 * 
 * This software consists of voluntary contributions made by Vovida
 * Networks, Inc. and many individuals on behalf of Vovida Networks,
 * Inc.  For more information on Vovida Networks, Inc., please see
 * <http://www.vovida.org/>.
 *
 */
