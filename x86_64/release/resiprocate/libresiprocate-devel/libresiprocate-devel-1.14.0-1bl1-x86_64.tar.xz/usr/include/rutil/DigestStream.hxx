#if !defined(RESIP_DigestSTREAM_HXX)
#define RESIP_DigestSTREAM_HXX 

#include <iostream>
#include "rutil/Data.hxx"

namespace resip
{

enum DigestType
{
   MD5,
   SHA1
#ifdef USE_SSL
   , SHA256
   , SHA512
   , SHA512_256
#endif
};

/** 
    @brief Implementation of std::streambuf used to back the DigestStream.
*/
class DigestBuffer : public std::streambuf
{
public:
   DigestBuffer(DigestType digestType = MD5);
   virtual ~DigestBuffer();

   /** @returns the Digest hexadecimal representation of the data from the buffer */
   Data getHex();

   /** @returns the Digest binary representation of the data from the buffer */
   const Data& getBin();

   size_t bytesTaken() { return mBytesTaken; }

protected:
   virtual int sync();
   virtual int overflow(int c = -1);

private:
   DigestType mDigestType;
   char mBuf[64];
   void* mContext;
   size_t mBytesTaken;
   Data mFinalBin;
};

/** 
    @brief Used to accumlate data written to the stream in a DigestBuffer and
    convert the data to Digest.
*/
class DigestStream : private DigestBuffer, public std::ostream
{
public:
   DigestStream(DigestType digestType = MD5);
   ~DigestStream();
   /** Calls flush() on itself and returns the Digest data in hex format.
       @returns the Digest hexadecimal representation of the data written to the
       stream and convert the data to Digest.
   */
   Data getHex();
   const Data& getBin();

   size_t bytesTaken();

   static const Data& getDigestName(DigestType digestType);
};

}

#endif
/* ====================================================================
 * The Vovida Software License, Version 1.0 
 * 
 * Copyright (c) 2026 SIP Spectrum, Inc. https://www.sipspectrum.com
 * Copyright (c) 2000 Vovida Networks, Inc.  All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 
 * 3. The names "VOCAL", "Vovida Open Communication Application Library",
 *    and "Vovida Open Communication Application Library (VOCAL)" must
 *    not be used to endorse or promote products derived from this
 *    software without prior written permission. For written
 *    permission, please contact vocal@vovida.org.
 *
 * 4. Products derived from this software may not be called "VOCAL", nor
 *    may "VOCAL" appear in their name, without prior written
 *    permission of Vovida Networks, Inc.
 * 
 * THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE AND
 * NON-INFRINGEMENT ARE DISCLAIMED.  IN NO EVENT SHALL VOVIDA
 * NETWORKS, INC. OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT DAMAGES
 * IN EXCESS OF $1,000, NOR FOR ANY INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
 * USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
 * DAMAGE.
 * 
 * ====================================================================
 * 
 * This software consists of voluntary contributions made by Vovida
 * Networks, Inc. and many individuals on behalf of Vovida Networks,
 * Inc.  For more information on Vovida Networks, Inc., please see
 * <http://www.vovida.org/>.
 *
 */
