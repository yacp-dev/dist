#pragma once

/* #undef OPENTRACING_BUILD_DYNAMIC_LOADING */
