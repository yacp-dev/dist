#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "OpenTracing::opentracing" for configuration "RelWithDebInfo"
set_property(TARGET OpenTracing::opentracing APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(OpenTracing::opentracing PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libopentracing.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygopentracing-1.dll"
  )

list(APPEND _cmake_import_check_targets OpenTracing::opentracing )
list(APPEND _cmake_import_check_files_for_OpenTracing::opentracing "${_IMPORT_PREFIX}/lib/libopentracing.dll.a" "${_IMPORT_PREFIX}/bin/cygopentracing-1.dll" )

# Import target "OpenTracing::opentracing_mocktracer" for configuration "RelWithDebInfo"
set_property(TARGET OpenTracing::opentracing_mocktracer APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(OpenTracing::opentracing_mocktracer PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libopentracing_mocktracer.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygopentracing_mocktracer-1.dll"
  )

list(APPEND _cmake_import_check_targets OpenTracing::opentracing_mocktracer )
list(APPEND _cmake_import_check_files_for_OpenTracing::opentracing_mocktracer "${_IMPORT_PREFIX}/lib/libopentracing_mocktracer.dll.a" "${_IMPORT_PREFIX}/bin/cygopentracing_mocktracer-1.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
