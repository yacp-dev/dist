#ifndef __TESTING_HPP__
#define __TESTING_HPP__

/*
 * Test this with something like:
 * g++ -std=c++17 -x c++ -DTEST_TESTING testing.hpp -o testing_test
 * ./testing_test
 */


#include <string>
#include <exception>
#include <stdexcept>
#include <iostream>
#include <iomanip>

#include <cstdlib>
#include <cstring>

#include <chrono>
#include <thread>

#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#else
#include <sys/wait.h>
#include <unistd.h>
#endif

#define TEST_CASE(x) #x, x
#define SUBPROCESS_TEST_CASE(x) #x, x, true

namespace testing{

// prevents the running test suite from hanging indefinitely by terminating after the configured timeout
inline void set_timeout(unsigned int seconds) {
  std::thread([seconds]() {
    std::this_thread::sleep_for(std::chrono::seconds(seconds));
    std::abort();
  }).detach();
}

//function pointer to run as a test
using test_function = void (*)(void);
// forward declare to keep important stuff up top
inline void subprocess_test(const std::string& test_name, test_function function);

struct suite {
 public:
  //initializes the test suite
  explicit suite(const std::string& test_suite_name): failed(0) {
    std::cout << "=== Testing " << test_suite_name << " ===" << std::endl;
  }
  //run the test
  void test(const std::string& test_name, test_function function, bool subprocess = false) {
    std::cout << std::setw(32) << test_name << std::flush;
    try {
      //run the test
      if (subprocess)
        subprocess_test(test_name, function);
      else
        function();
      //it didnt throw
      std::cout << " [PASS]" << std::endl;
    }//it threw so log the issue
    catch (const std::exception& e) {
      std::cout << " [FAIL: " << e.what() << "]" << std::endl;
      ++failed;
    }//it threw something that wasn't derived from std::exception?
    catch (...) {
      std::cerr << " [FAIL: Unexpected error]" << std::endl;
      throw;
    }
  }
  //returns EXIT_FAILURE if any tests failed otherwise returns EXIT_SUCCESS
  int tear_down() {
    std::cout << "=== Failed " << failed << " tests ===" << std::endl;
    if(failed > 0)
      return EXIT_FAILURE;
    else
      return EXIT_SUCCESS;
  }
  
 private:
  //number of failed tests
  size_t failed;
};

// some tests (those that bother with signals, process-global state, etc) are best run in a child
// process for isolation. on POSIX we fork; on Windows we re-invoke the executable via CreateProcess.
// the test_name parameter is unused on POSIX (fork clones the function pointer) but required on
// Windows to tell the child process which test to run.
#ifndef _WIN32
inline void subprocess_test(const std::string& /*test_name*/, test_function test_fn) {
  // create a pipe to communicate the test result back to the parent
  int pipefd[2];
  if (pipe(pipefd) != 0) throw std::runtime_error("pipe() failed");
  // fork a child process to run the test
  pid_t pid = fork();
  if (pid < 0) throw std::runtime_error("fork() failed");

  // child process
  if (pid == 0) {
    // child doesnt read from the pipe
    close(pipefd[0]);
    try {
      test_fn();
      _exit(0);
    } catch (const std::exception& e) {
      [[maybe_unused]] auto _ = write(pipefd[1], e.what(), std::strlen(e.what()));
      _exit(1);
    } catch (...) {
      const char* msg = "unknown exception caught";
      [[maybe_unused]] auto _ = write(pipefd[1], msg, std::strlen(msg));
      _exit(1);
    }
  }

  // parent doesnt write to the pipe
  close(pipefd[1]);
  // wait for the child to finish
  int status = 0;
  waitpid(pid, &status, 0);

  // check if it told us of any failures
  char buf[4096];
  ssize_t n = read(pipefd[0], buf, sizeof(buf) - 1);
  close(pipefd[0]);

  // looks like its good
  if (WIFEXITED(status) && WEXITSTATUS(status) == 0)
    return;

  // if we got a message throw it to the user
  if (n > 0) {
    buf[n] = '\0';
    throw std::runtime_error(buf);
  } // let them know it was killed
  else if (WIFSIGNALED(status)) {
    throw std::runtime_error("child killed by signal " + std::to_string(WTERMSIG(status)));
  } // all we have is the exit code at this point
  else {
    throw std::runtime_error("child exited with code " + std::to_string(WEXITSTATUS(status)));
  }
}
#else
inline void subprocess_test(const std::string& test_name, test_function function) {
  // in the child process the env var is already set -- run the matching test and exit
  const char* target = std::getenv("SUBPROCESS_TEST");
  if (target) {
    if (test_name != target)
      std::exit(0); // silently ignore the wrong test
    try {
      function();
    } catch (const std::exception& e) {
      std::cerr << e.what();
      std::exit(1);
    } catch (...) {
      std::cerr << "unknown exception caught";
      std::exit(1);
    }
    std::exit(0);
  }

  // get path to our own executable so we can re-invoke it
  char exe_path[MAX_PATH];
  if (!GetModuleFileNameA(nullptr, exe_path, MAX_PATH))
    throw std::runtime_error("GetModuleFileName failed");

  // tell the child which test to run via env var (suite::test checks this)
  SetEnvironmentVariableA("SUBPROCESS_TEST", test_name.c_str());

  // create a pipe for the child to report errors through
  SECURITY_ATTRIBUTES sa{sizeof(SECURITY_ATTRIBUTES), nullptr, TRUE};
  HANDLE read_pipe, write_pipe;
  if (!CreatePipe(&read_pipe, &write_pipe, &sa, 0))
    throw std::runtime_error("CreatePipe failed");
  SetHandleInformation(read_pipe, HANDLE_FLAG_INHERIT, 0);

  // launch the child in its own process group so GenerateConsoleCtrlEvent stays contained
  STARTUPINFOA si{};
  si.cb = sizeof(si);
  si.dwFlags = STARTF_USESTDHANDLES;
  si.hStdInput = GetStdHandle(STD_INPUT_HANDLE);
  si.hStdOutput = GetStdHandle(STD_OUTPUT_HANDLE);
  si.hStdError = write_pipe;

  PROCESS_INFORMATION pi{};
  std::string cmd(exe_path);
  if (!CreateProcessA(nullptr, cmd.data(), nullptr, nullptr, TRUE,
                      CREATE_NEW_PROCESS_GROUP, nullptr, nullptr, &si, &pi)) {
    CloseHandle(read_pipe);
    CloseHandle(write_pipe);
    throw std::runtime_error("CreateProcess failed");
  }
  // parent doesn't write to the pipe
  CloseHandle(write_pipe);

  WaitForSingleObject(pi.hProcess, INFINITE);
  DWORD exit_code = 0;
  GetExitCodeProcess(pi.hProcess, &exit_code);
  CloseHandle(pi.hProcess);
  CloseHandle(pi.hThread);

  // clean up the env var
  SetEnvironmentVariableA("SUBPROCESS_TEST", nullptr);

  // read any error message the child wrote
  char buf[4096];
  DWORD n = 0;
  ReadFile(read_pipe, buf, sizeof(buf) - 1, &n, nullptr);
  CloseHandle(read_pipe);

  if (exit_code == 0)
    return;

  if (n > 0) {
    buf[n] = '\0';
    throw std::runtime_error(buf);
  }
  throw std::runtime_error("child exited with code " + std::to_string(exit_code));
}
#endif

}

#endif //__TESTING_HPP__

#ifdef TEST_TESTING

namespace {
    
  void passing_test() {
    //we didn't throw an unhandled exception
    //therefore we pass
  }
  
  void failing_test() {
    //this will bomb the test
    throw std::runtime_error("You've found a failing test");
  }
    
}

int main() {
  test::suite suite("sample_test_suite");
  
  //run each test
  suite.test(TEST_CASE(passing_test));
  suite.test(TEST_CASE(failing_test));
  
  return suite.tear_down();
}

#endif
