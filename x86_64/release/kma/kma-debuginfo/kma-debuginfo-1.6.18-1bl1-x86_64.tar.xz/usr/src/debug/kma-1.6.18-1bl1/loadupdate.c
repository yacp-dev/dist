/* Philip T.L.C. Clausen Jan 2017 plan@dtu.dk */

/*
 * Copyright (c) 2017, Philip Clausen, Technical University of Denmark
 * All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
*/
#define _XOPEN_SOURCE 600
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "loadupdate.h"
#include "pherror.h"
#include "hashmap.h"
#include "hashmapkma.h"
#include "merge.h"
#include "middlelayer.h"
#include "tmp.h"
#include "updateindex.h"

void * memdup(const void * src, size_t size) {
	
	void *dest;
	
	dest = smalloc(size);
	memcpy(dest, src, size);
	
	return dest;
}

int CP(char *templatefilename, char *outputfilename) {
	
	int bytes, buffSize;
	char *buffer;
	FILE *file_in, *file_out;
	
	if(strcmp(templatefilename, outputfilename) == 0) {
		return 1;
	}
	
	file_in = sfopen(templatefilename, "rb");
	file_out = sfopen(outputfilename, "wb");
	buffer = smalloc((buffSize = 1048576));
	
	while((bytes = fread(buffer, 1, buffSize, file_in))) {
		cfwrite(buffer, 1, bytes, file_out);
	}
	
	fclose(file_in);
	fclose(file_out);
	free(buffer);
	
	return 0;
}

HashMap * hashMapKMA_openChains(HashMapKMA *src) {
	
	long unsigned i, key;
	unsigned *values;
	HashMap *dest;
	
	if(src->mask != src->size) {
		free(src->exist);
	}
	dest = hashMap_initialize(src->size + 1, src->kmersize, src->mlen, src->flag);
	dest->prefix = src->prefix;
	dest->prefix_len = src->prefix_len;
	dest->DB_size = src->DB_size;
	
	if(dest->size == dest->mask) {
		addUniqueValues = &megaMap_addUniqueValues;
	} else {
		addUniqueValues = &hashMap_addUniqueValues;
	}
	
	if(src->mask != src->size) {
		/* norm */
		i = src->n;
		while(i--) {
			key = getKeyPtr(src->key_index, i);
			values = getValuePtr(src, getValueIndexPtr(src->value_index, i));
			values = memdup(values, getSizePtr(values));
			addUniqueValues(dest, key, values);
		}
		free(src->key_index);
		free(src->value_index);
	} else {
		/* mega */
		i = src->size + 1;
		while(i--) {
			if((key = getExistPtr(src->exist, i)) != 1) {
				values = getValuePtr(src, key);
				values = memdup(values, getSizePtr(values));
				
				addUniqueValues(dest, i, values);
			}
		}
		free(src->exist);
	}
	free(src->values);
	free(src);
	
	return dest;
}

unsigned ** hashMapKMA_openValues(HashMapKMA *src) {
	
	long unsigned i, index, pos;
	unsigned *values, **Values;
	
	Values = smalloc(src->n * sizeof(unsigned *));
	index = src->n;
	if(src->mask != (src->size - 1)) {
		/* norm */
		i = src->n;
		while(i--) {
			/* get key and values */
			values = getValuePtr(src, getValueIndexPtr(src->value_index, i));
			Values[i] = memdup(values, getSizePtr(values));
			hashMapKMA_addValue_ptr(src, i, i);
		}
	} else {
		/* mega */
		i = src->size;
		getSizePtr = &getSizeS;
		while(i--) {
			if((pos = getExistPtr(src->exist, i)) != 1) {
				/* get key and values */
				values = getValuePtr(src, pos);
				Values[--index] = memdup(values, getSizePtr(values));
				hashMapKMA_addExist_ptr(src, i, index);
			} else {
				hashMapKMA_addExist_ptr(src, i, src->n);
			}
		}
	}
	free(src->values);
	src->values = 0;
	
	return Values;
}

unsigned load_DBs(char *templatefilename, char *outputfilename, unsigned **template_lengths, unsigned **template_ulengths, unsigned **template_slengths, HashMapKMA *finalDB) {
	
	int file_len, out_len, DB_size, kmerindex;
	FILE *infile;
	
	file_len = strlen(templatefilename);
	out_len = strlen(outputfilename);
	
	/* load hash */
	strcat(templatefilename, ".comp.b");
	infile = sfopen(templatefilename, "rb");
	if(hashMapKMAload(finalDB, infile)) {
		fprintf(stderr, "Wrong format of DB\n");
		exit(1);
	} else {
		finalDB->size--;
	}
	templatefilename[file_len] = 0;
	fclose(infile);
	
	/* load lengths */
	strcat(templatefilename, ".length.b");
	infile = sfopen(templatefilename, "rb");
	templatefilename[file_len] = 0;
	sfread(&DB_size, sizeof(unsigned), 1, infile);
	if(finalDB->prefix) {
		*template_lengths = smalloc((DB_size << 1) * sizeof(unsigned));
		*template_slengths = smalloc((DB_size << 1) * sizeof(unsigned));
		*template_ulengths = smalloc((DB_size << 1) * sizeof(unsigned));
		sfread(*template_lengths, sizeof(unsigned), DB_size, infile);
		sfread(*template_slengths, sizeof(unsigned), DB_size, infile);
		sfread(*template_ulengths, sizeof(unsigned), DB_size, infile);
		kmerindex = **template_slengths;
		**template_ulengths = DB_size << 1;
		**template_slengths = DB_size << 1;
	} else {
		*template_lengths = smalloc((DB_size << 1) * sizeof(unsigned));
		*template_slengths = 0;
		*template_ulengths = 0;
		sfread(*template_lengths, sizeof(unsigned), DB_size, infile);
		kmerindex = **template_lengths;
		**template_lengths = DB_size << 1;
	}
	fclose(infile);
	
	/* cp name, seq and index */
	strcat(templatefilename, ".name");
	strcat(outputfilename, ".name");
	CP(templatefilename, outputfilename);
	templatefilename[file_len] = 0;
	outputfilename[out_len] = 0;
	
	strcat(templatefilename, ".seq.b");
	strcat(outputfilename, ".seq.b");
	CP(templatefilename, outputfilename);
	templatefilename[file_len] = 0;
	outputfilename[out_len] = 0;
	
	return kmerindex;
}

int extendPrefix(HashMapKMA *src, long unsigned prefix, int prefix_len) {
	
	int kmersize, shift;
	unsigned *exist, *key_index, *value_index, *values;
	long unsigned i, j, offset, n, key, v_index, mask, null_index, size;
	long unsigned *layer, *exist_l, *key_index_l, *value_index_l, buff[2];
	MiddleLayer *middle;
	FILE *tmp;
	
	/* check if prefixes are compatible */
	if(src->flag || src->kmersize != src->mlen || (prefix == 0 && prefix_len == 0) || (!src->prefix && !src->prefix_len) || (src->prefix == prefix && src->prefix_len == prefix_len) || (src->prefix_len && src->prefix != (prefix >> ((prefix_len - src->prefix_len) << 1)))) {
		/* not compatible */
		return 0;
	} else {
		fprintf(stderr, "# Subsampling k-mers\n");
	}
	
	/* init */
	kmersize = src->kmersize - (prefix_len - src->prefix_len);
	shift = kmersize << 1;
	mask = 1;
	mask <<= shift;
	--mask;
	null_index = src->null_index;
	
	/* get prefix of variable k-mer part */
	src->prefix = prefix;
	i = src->prefix_len;
	src->prefix_len = prefix_len;
	prefix_len -= i;
	size = 1;
	size <<= (prefix_len << 1);
	prefix &= --size;
	
	/* Subsample k-mers */
	if(src->size == src->mask) { /* direct indexing */
		/* update exist */
		size = (mask + 1); /* size of new exist */
		offset = prefix * (mask + 1); /* part where new prefix matches old k-mers */
		if(src->v_index <= UINT_MAX) {
			size *= sizeof(unsigned);
			memcpy(src->exist, src->exist + offset, size);
		} else {
			size *= sizeof(long unsigned);
			memcpy(src->exist, src->exist_l + offset, size);
		}
		
		/* free-up unused part */
		src->exist = realloc(src->exist, size);
		if(!(src->exist_l = (long unsigned *)(src->exist))) {
			ERROR();
		}
		src->size = mask;
		
		/* get middlelayer */
		middle = MiddleLayer_init(src->n);
		MiddleLayer_populate(middle, src, 0);
		
		/* get unique values */
		n= 0;
		v_index = 0;
		tmp = tmpF(0);
		if(src->v_index <= UINT_MAX) {
			exist = src->exist - 1;
			exist_l = 0;
		} else {
			exist = 0;
			exist_l = src->exist_l - 1;
		}
		size = src->size + 1;
		do {
			key = exist ? *++exist : *++exist_l;
			if(key != null_index) {
				/* get new value_index */
				i = MiddleLayer_search(middle, key);
				if(i == middle->n) {
					fprintf(stderr, "Middlelayer corruption.\n");
					exit(1);
				}
				layer = middle->layer + (i << 1);
				
				/* check if alreadye in use */
				if(!layer[1]) {
					/* dump values */
					values = getValuePtr(src, key);
					sfwrite(values, 1, getSizePtr(values), tmp);
					
					/* update v_index */
					layer[1] = v_index + 1;
					v_index += (src->DB_size < USHRT_MAX) ? *((short unsigned *)(values)) : *values;
					++v_index;
				}
				
				/* udpate exist */
				if(exist) {
					*exist = layer[1] - 1;
				} else {
					*exist_l = layer[1] - 1;
				}
				
				/* update number of k-mers */
				++n;
			}
		} while(--size);
		src->n = n;
		MiddleLayer_free(middle);
		
		/* update values */
		rewind(tmp);
		size = (src->DB_size < USHRT_MAX) ? sizeof(short unsigned) : sizeof(unsigned);
		sfread(src->values, size, v_index, tmp);
		fclose(tmp);
		
		/* adjust size of new index */
		src->values = realloc(src->values, v_index * size);
		if(!(src->values_s = (short unsigned *)(src->values))) {
			ERROR();
		}
		if(exist_l && v_index <= UINT_MAX) {
			/* convert to lu to u */
			size = src->size + 1;
			exist = src->exist;
			exist_l = src->exist_l;
			key = *exist_l;
			*exist = key;
			while(--size) {
				*++exist = *++exist_l;
			}
			
			/* readjust exist */
			src->exist = realloc(src->exist, (src->size + 1) * sizeof(unsigned));
			if(!(src->exist_l = (long unsigned *)(src->exist))) {
				ERROR();
			}
		}
	} else { /* hashmap indexing */
		/* get number of subsampled k-mers */
		n = 0;
		if(src->mlen <= 16) {
			key_index = src->key_index - 1;
			key_index_l = 0;
		} else {
			key_index = 0;
			key_index_l = src->key_index_l - 1;
		}
		size = src->n + 1;
		while(--size) {
			key = key_index ? *++key_index : *++key_index_l;
			if((key >> shift) == prefix) {
				++n;
			}
		}
		
		/* get new size */
		size = (n << 1) + 1;
		size |= size >> 1;
		size |= size >> 2;
		size |= size >> 4;
		size |= size >> 8;
		size |= size >> 16;
		size |= size >> 32;
		++size;
		
		/* get new key-value indexes */
		tmp = tmpF(0);
		v_index = 0;
		if(src->n <= UINT_MAX) {
			exist = src->exist;
			exist_l = 0;
		} else {
			exist = 0;
			exist_l = src->exist_l;
		}
		for(i = 0; i < size; ++i) { /* go over new index */
			offset = null_index;
			for(j = i; j <= src->size; j += size) { /* go over org index */
				key = exist ? exist[j] : exist_l[j];
				if(key != null_index) {
					/* get k-mers matchin new prefix */
					if(src->kmersize <= 16) {
						key_index = src->key_index + key;
						key_index_l = 0;
					} else {
						key_index = 0;
						key_index_l = src->key_index_l + key;
					}
					if(src->v_index < UINT_MAX) {
						value_index = src->value_index + key;
						value_index_l = 0;
					} else {
						value_index = 0;
						value_index_l = src->value_index_l + key;
					}
					
					/* go over k-mers */
					key = key_index ? *key_index : *key_index_l;
					while(j == (key & src->size)) {
						/* match prefix */
						if((key >> shift) == prefix) {
							/* dump key-value pair */
							buff[0] = key;
							buff[1] = value_index ? *value_index : *value_index_l;
							sfwrite(buff, sizeof(long unsigned), 2, tmp);
							
							/* check if k-mer is first on new chain */
							if(offset == null_index) {
								offset = v_index;
							}
							++v_index;
						}
						
						/* get next k-mer */
						if(value_index) {
							++value_index;
						} else {
							++value_index_l;
						}
						key = key_index ? *++key_index : *++key_index_l;
					}
				}
			}
			
			/* update exist */
			if(n <= UINT_MAX) {
				src->exist[i] = offset;
			} else {
				src->exist_l[i] = offset;
			}
		}
		
		/* readjust sizes */
		src->size = size;
		src->n = n;
		size = (n <= UINT_MAX) ? sizeof(unsigned) : sizeof(long unsigned);
		src->exist = realloc(src->exist, src->size-- * size);
		if(!(src->exist_l = (long unsigned *)(src->exist))) {
			ERROR();
		}
		free(src->key_index);
		free(src->value_index);
		size = (kmersize <= 16) ? sizeof(unsigned) : sizeof(long unsigned);
		src->key_index = smalloc((n+1) * size);
		src->key_index_l = (long unsigned *)(src->key_index);
		size = (src->v_index <= UINT_MAX) ? sizeof(unsigned) : sizeof(long unsigned);
		src->value_index = smalloc(n * size);
		src->value_index_l = (long unsigned *)(src->value_index);
		
		/* load new key-value pairs */
		if(kmersize <= 16) {
			key_index = src->key_index - 1;
			key_index_l = 0;
		} else {
			key_index = 0;
			key_index_l = src->key_index_l - 1;
		}
		if(src->v_index <= UINT_MAX) {
			value_index = src->value_index - 1;
			value_index_l = 0;
		} else {
			value_index = 0;
			value_index_l = src->value_index_l - 1;
		}
		rewind(tmp);
		while(fread(buff, sizeof(long unsigned), 2, tmp)) {
			if(key_index) {
				*++key_index = buff[0] & mask;
			} else {
				*++key_index_l = buff[0] & mask;
			}
			if(value_index) {
				*++value_index = buff[1];
			} else {
				*++value_index_l = buff[1];
			}
			--n;
		}
		if(key_index) {
			key_index[1] = *key_index + 1;
		} else {
			key_index_l[1] = *key_index_l + 1;
		}
		
		if(n) {
			fprintf(stderr, "Error loading new key-value pairs.\n");
			exit(1);
		}
		
		/* get middlelayer */
		middle = MiddleLayer_init(src->n);
		MiddleLayer_populate(middle, src, 0);
		
		/* get unique values */
		v_index = 0;
		rewind(tmp);
		if(src->v_index <= UINT_MAX) {
			value_index = src->value_index - 1;
			value_index_l = 0;
		} else {
			value_index = 0;
			value_index_l = src->value_index_l - 1;
		}
		n = src->n + 1;
		while(--n) {
			/* get new value_index */
			key = value_index ? *++value_index : *++value_index_l;
			i = MiddleLayer_search(middle, key);
			if(i == middle->n) {
				fprintf(stderr, "Middlelayer corruption.\n");
				exit(1);
			}
			layer = middle->layer + (i << 1);
			
			/* check if alreadye in use */
			if(!layer[1]) {
				/* dump values */
				values = getValuePtr(src, key);
				size = getSizePtr(values);
				sfwrite(values, 1, size, tmp);
				
				/* update v_index */
				layer[1] = v_index + 1;
				v_index += (src->DB_size < USHRT_MAX) ? *((short unsigned *)(values)) : *values;
				++v_index;
			}
			
			/* udpate value_index */
			if(value_index) {
				*value_index = layer[1] - 1;
			} else {
				*value_index_l = layer[1] - 1;
			}
		}
		MiddleLayer_free(middle);
		
		/* update values */
		rewind(tmp);
		size = (src->DB_size < USHRT_MAX) ? sizeof(short unsigned) : sizeof(unsigned);
		sfread(src->values, size, v_index, tmp);
		fclose(tmp);
		
		/* adjust size of value_index */
		src->values = realloc(src->values, v_index * size);
		if(!(src->values_s = (short unsigned *)(src->values))) {
			ERROR();
		}
		if(UINT_MAX < src->v_index && v_index <= UINT_MAX) {
			/* convert to lu to u */
			size = v_index;
			value_index = src->value_index;
			value_index_l = src->value_index_l;
			key = *value_index_l;
			*value_index = *value_index_l;
			while(--size) {
				*++value_index = *++value_index_l;
			}
			
			/* readjust value_index */
			src->value_index = realloc(src->value_index, v_index * sizeof(unsigned));
			if(!(src->value_index_l = (long unsigned *)(src->value_index))) {
				ERROR();
			}
		}
	}
	
	/* update src */
	src->mask = mask;
	src->v_index = v_index;
	src->kmersize = kmersize;
	src->mlen = kmersize;
	
	return 1;
}

unsigned * getUlenghts(HashMapKMA *src) {
	
	int template, type;
	unsigned *lenghts, *value_index, *values;
	short unsigned *values_s;
	long unsigned size, key, null_index, *value_index_l;
	
	lenghts = calloc(src->DB_size, sizeof(unsigned));
	if(!lenghts) {
		ERROR();
	}
	type = src->DB_size <= USHRT_MAX;
	null_index = src->null_index;
	
	if((src->size - 1) == src->mask) { /* direct indexing */
		/* go over key-value pairs */
		if(src->v_index <= UINT_MAX) {
			value_index = src->exist - 1;
			value_index_l = 0;
		} else {
			value_index = 0;
			value_index_l = src->exist_l - 1;
		}
		size = src->size;
		do {
			key = value_index ? *++value_index : *++value_index_l;
			if(key != null_index) {
				if(type) {
					values_s = src->values_s + key;
					values = 0;
				} else {
					values_s = 0;
					values = src->values;
				}
				key = values ? *values : *values_s;
				do {
					template = values ? *++values : *++values_s;
					lenghts[template]++;
				} while(--key);
			}
		} while(--size);
	} else { /* hashmap indexing */
		/* go over key-value pairs */
		if(src->v_index <= UINT_MAX) {
			value_index = src->value_index - 1;
			value_index_l = 0;
		} else {
			value_index = 0;
			value_index_l = src->value_index_l - 1;
		}
		size = src->n;
		do {
			key = value_index ? *++value_index : *++value_index_l;
			if(type) {
				values_s = src->values_s + key;
				values = 0;
			} else {
				values_s = 0;
				values = src->values;
			}
			key = values ? *values : *values_s;
			do {
				template = values ? *++values : *++values_s;
				lenghts[template]++;
			} while(--key);
		} while(--size);
	}
	
	return lenghts;
}
