[![install with bioconda](https://img.shields.io/badge/install%20with-bioconda-brightgreen.svg?style=flat)](http://bioconda.github.io/recipes/kma/README.html)
# Getting Started #

```
git clone https://bitbucket.org/genomicepidemiology/kma
cd kma && make

./kma index -i templates.fsa.gz -o templates
./kma -i reads_se.fq.gz -o output/name -t_db templates
./kma -ipe reads_1.fq.gz reads_2.fq.gz -o output/name -t_db templates
```

# Introduction #
KMA is a mapping method designed to map raw reads directly against redundant databases, in an 
ultra-fast manner using seed and extend. KMA is particulary good at aligning 
high quality reads against highly redundant databases, where unique matches often does 
not exist. It works for long low quality reads as well, such as those from Nanopore. 
Non-unique matches are resolved using the "ConClave" sorting scheme, and a consensus sequence are outputtet
in addition to other common attributes, based on our users demands.

If you use KMA for your published research, then please cite:
Philip T.L.C. Clausen, Malte B. Hallgrten, Søren Overballe-Petersen, Vanessa R. Marcelino, Henrik Hasm & Frank M. Aarestrup,
"Assembly-free typing of Nanopore and Illumina data through proximity scoring with KMA",
NAR Genomics and Bioinformatics, Volume 7, Issue 3, September 2025, https://doi.org/10.1093/nargab/lqaf116.

# Usage #
A more detailed guide on KMA and its options can be found in the pdf "KMAspecification.pdf".
For practical reasons you might want to add kma to your path, this might be done with:

```
mv kma ~/bin/
```

## Indexing ##
In order to use KMA for mapping, the databases need to indexed. 
This is done with kma index, the most important options are described below:

```
-i Input fasta file(s), space separated. By default kma index reads from stdin.
-o Output name, the name given to the database.
-k k-mer size used for indexing the database.
-m minimizer size.
-Sparse Only include k-mers with a given prefix.
-ME Preallocate the maximum amount of k-mers.
-hq Homology threshold on query coverage (Hobohm1)
-ht Homology threshold on template coverage (Hobohm1)
-and Both hq and ht must be fullfilled before adding new sequences.
```

## Mapping and Alignment ##
The default settings of KMA is set so that it should work on most cases, 
but it is evident to use the right options for the right problems.
Some of the most important options:

```
-i Inputfile(s), default is read from stdin. All input options takes as many files as you wish in fastq or fasta format, space separated.
-ipe Inputfile(s), paired end. The file pairs should be placed right after each other.
-int Inputfile(s), interleaved.
-o Output destination.
-t_db Database from indexing.
-mem_mode ConClave scores will be computed on mapping scores rather than alignment scores, which saves memory and increase speed.
-1t1 One read to one template, no splicing performed. Well suited for short reads and whole genome mappings.
-asm Preset for gene finding with assembly data.
-ill Preset for gene finding with raw 2nd generation data.
-ont Preset for gene finding with raw 3rd generation data.
```

## Examples of running KMA ##

Finding highly similar genes from small databases, such as ResFinder and MLST alleles:
```
# indexing
kma index -i target/db.fna -o target/db

# mapping and alignment
kma -i singleEndReads.fq.gz -ipe pairedEnd_*.fq.gz -o output/name -t_db target/db -ill -reassign # short read data
kma -i longReads.fq.gz -o output/name -t_db target/db -ont -reassign # long read data
kma -i assembly.fna.gz -o output/name -t_db target/db -asm -reassign # assembly data
```

Finding highly similar genes from large databases, such as Silva and cgMLST:
```
# indexing
kma index -i target/db.fna -o target/db -Sparse TG

# mapping and alignment
kma -i singleEndReads.fq.gz -ipe pairedEnd_*.fq.gz -o output/name -t_db target/db -ill -reassign -mem_mode # short read data
kma -i longReads.fq.gz -o output/name -t_db target/db -ont -reassign -mem_mode # long read data
kma -i assembly.fna.gz -o output/name -t_db target/db -asm -reassign -mem_mode # assembly data
```

Identifying whole genome references from very large databases, such as RefSeq or complete bacterial genome collections:
```
# indexing
kma index -i target/db.fna -o target/db -Sparse TG -ME

# mapping and alignment
kma -i singleEndReads.fq.gz -ipe pairedEnd_*.fq.gz -o output/name -t_db target/db -ill -1t1 -mem_mode # short read data
kma -i longReads.fq.gz -o output/name -t_db target/db -ont -1t1 -mem_mode # long read data
kma -i assembly.fna.gz -o output/name -t_db target/db -asm -1t1 -mem_mode # assembly data
```

Combine mappings from different indexes, note the commands are executed in parallel below.
```
# indexing
kma index -i target/db1.fna -o target/db1 -Sparse TG
kma index -i target/db2.fna -o target/db2 -Sparse TG
kma index -i target/db3.fna -o target/db3 -Sparse TG

# mapping and alignment
kma -i singleEndReads.fq.gz -ipe pairedEnd_*.fq.gz -o output/name -t_db target/db1 target/db2 target/db3 -ill -1t1 -mem_mode -spltDB | bash # short read data
kma -i longReads.fq.gz -o output/name -t_db target/db1 target/db2 target/db3 -ont -1t1 -mem_mode -spltDB | bash # long read data
kma -i assembly.fna.gz -o output/name -t_db target/db1 target/db2 target/db3 -asm -1t1 -mem_mode -spltDB | bash # assembly data
```

Update indexes.
```
# add sequences to existing index, if they are less similar than 90% to any reference in the current db
kma index -i target/new/sequences.fna -t_db target/current/db -o target/new/db -hq 0.9 -ht 0.9 -and

# merge two indexes
kma index -i target/db1.fna -o target/db1
kma index -i target/db2.fna -o target/db2
kma merge -t_db target/db1 -s_db target/db2 -o target/merged/db
```

# Result Explanation #
When the mapping is done KMA will produce the following files:

1. \*.res A result overview giving the most common statistics for each mapped template.
2. \*.fsa The consensus sequences drawn from the alignments.
3. \*.aln The consensus alignment of the reads against their template.
4. \*.frag.gz Mapping information on each mapped read, columns are: read, number of equally well mapping templates, mapping score, start position, end position (w.r.t. template), the choosen template.
5. \*.mat.gz Base counts on each position in each template, (only if -matrix is enabled)

# Shared memory #
The databases of KMA can be put into shared memory, this enables you to align several 
samples at ones while only having the database loaded in one place. 
KMA_SHM can be used to put the databases into shared memory, and most importantly take them 
down afterwards. It is of the highest concern that these shared databases are used correctly, 
as they will take up a part of memory and they will exist there until they are taken down again, 
the computer is restarted or computer breaks down.

Example of setting up a database in shared memory.
```
kma shm -t_db database/name -shmLvl 1
```

-shmLvl specifies how much of the database there should be stored in shared memory, use.
-shm-h to get an overview of the different levels.

Example of taking it down again, always remember to do this then it is no longer needed:
```
kma shm -t_db database/name -shmLvl 1 -destroy
```

# Installation Requirements #
In order to install KMA, you need to have a C-compiler and zlib development files installed.
Zlib development files can be installed on unix systems with:
```
sudo apt-get install libz-dev
```

# Help #
Usage and options are available with the "-h" option on all three programs.
If in doubt, please mail any concerns or problems to: *plan@dtu.dk*.

# Citation #
1. Philip T.L.C. Clausen, Malte B. Hallgrten, Søren Overballe-Petersen, Vanessa R. Marcelino, Henrik Hasm & Frank M. Aarestrup, "Assembly-free typing of Nanopore and Illumina data through proximity scoring with KMA", NAR Genomics and Bioinformatics, Volume 7, Issue 3, September 2025, https://doi.org/10.1093/nargab/lqaf116.
2. Philip T.L.C. Clausen, Frank M. Aarestrup & Ole Lund, "Rapid and precise alignment of raw reads against redundant databases with KMA", BMC Bioinformatics, 2018;19:307.

# License #
Copyright (c) 2017, Philip Clausen, Technical University of Denmark
All rights reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
