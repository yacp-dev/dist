#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "rotor::rotor" for configuration "RelWithDebInfo"
set_property(TARGET rotor::rotor APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(rotor::rotor PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/librotor.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygrotor-0.dll"
  )

list(APPEND _cmake_import_check_targets rotor::rotor )
list(APPEND _cmake_import_check_files_for_rotor::rotor "${_IMPORT_PREFIX}/lib/librotor.dll.a" "${_IMPORT_PREFIX}/bin/cygrotor-0.dll" )

# Import target "rotor::rotor_asio" for configuration "RelWithDebInfo"
set_property(TARGET rotor::rotor_asio APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(rotor::rotor_asio PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/librotor_asio.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygrotor_asio-0.dll"
  )

list(APPEND _cmake_import_check_targets rotor::rotor_asio )
list(APPEND _cmake_import_check_files_for_rotor::rotor_asio "${_IMPORT_PREFIX}/lib/librotor_asio.dll.a" "${_IMPORT_PREFIX}/bin/cygrotor_asio-0.dll" )

# Import target "rotor::rotor_wx" for configuration "RelWithDebInfo"
set_property(TARGET rotor::rotor_wx APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(rotor::rotor_wx PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/librotor_wx.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygrotor_wx-0.dll"
  )

list(APPEND _cmake_import_check_targets rotor::rotor_wx )
list(APPEND _cmake_import_check_files_for_rotor::rotor_wx "${_IMPORT_PREFIX}/lib/librotor_wx.dll.a" "${_IMPORT_PREFIX}/bin/cygrotor_wx-0.dll" )

# Import target "rotor::rotor_ev" for configuration "RelWithDebInfo"
set_property(TARGET rotor::rotor_ev APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(rotor::rotor_ev PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/librotor_ev.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygrotor_ev-0.dll"
  )

list(APPEND _cmake_import_check_targets rotor::rotor_ev )
list(APPEND _cmake_import_check_files_for_rotor::rotor_ev "${_IMPORT_PREFIX}/lib/librotor_ev.dll.a" "${_IMPORT_PREFIX}/bin/cygrotor_ev-0.dll" )

# Import target "rotor::rotor_thread" for configuration "RelWithDebInfo"
set_property(TARGET rotor::rotor_thread APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(rotor::rotor_thread PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/librotor_thread.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygrotor_thread-0.dll"
  )

list(APPEND _cmake_import_check_targets rotor::rotor_thread )
list(APPEND _cmake_import_check_files_for_rotor::rotor_thread "${_IMPORT_PREFIX}/lib/librotor_thread.dll.a" "${_IMPORT_PREFIX}/bin/cygrotor_thread-0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
