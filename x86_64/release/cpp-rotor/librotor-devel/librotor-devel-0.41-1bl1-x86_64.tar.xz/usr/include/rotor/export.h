
#ifndef ROTOR_API_H
#define ROTOR_API_H

#ifdef ROTOR_STATIC_DEFINE
#  define ROTOR_API
#  define ROTOR_NO_EXPORT
#else
#  ifndef ROTOR_API
#    ifdef rotor_EXPORTS
        /* We are building this library */
#      define ROTOR_API __declspec(dllexport)
#    else
        /* We are using this library */
#      define ROTOR_API __declspec(dllimport)
#    endif
#  endif

#  ifndef ROTOR_NO_EXPORT
#    define ROTOR_NO_EXPORT 
#  endif
#endif

#ifndef ROTOR_DEPRECATED
#  define ROTOR_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef ROTOR_DEPRECATED_EXPORT
#  define ROTOR_DEPRECATED_EXPORT ROTOR_API ROTOR_DEPRECATED
#endif

#ifndef ROTOR_DEPRECATED_NO_EXPORT
#  define ROTOR_DEPRECATED_NO_EXPORT ROTOR_NO_EXPORT ROTOR_DEPRECATED
#endif

/* NOLINTNEXTLINE(readability-avoid-unconditional-preprocessor-if) */
#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef ROTOR_NO_DEPRECATED
#    define ROTOR_NO_DEPRECATED
#  endif
#endif

#endif /* ROTOR_API_H */
