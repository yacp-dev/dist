
#ifndef ROTOR_THREAD_API_H
#define ROTOR_THREAD_API_H

#ifdef ROTOR_THREAD_STATIC_DEFINE
#  define ROTOR_THREAD_API
#  define ROTOR_THREAD_NO_EXPORT
#else
#  ifndef ROTOR_THREAD_API
#    ifdef rotor_thread_EXPORTS
        /* We are building this library */
#      define ROTOR_THREAD_API __declspec(dllexport)
#    else
        /* We are using this library */
#      define ROTOR_THREAD_API __declspec(dllimport)
#    endif
#  endif

#  ifndef ROTOR_THREAD_NO_EXPORT
#    define ROTOR_THREAD_NO_EXPORT 
#  endif
#endif

#ifndef ROTOR_THREAD_DEPRECATED
#  define ROTOR_THREAD_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef ROTOR_THREAD_DEPRECATED_EXPORT
#  define ROTOR_THREAD_DEPRECATED_EXPORT ROTOR_THREAD_API ROTOR_THREAD_DEPRECATED
#endif

#ifndef ROTOR_THREAD_DEPRECATED_NO_EXPORT
#  define ROTOR_THREAD_DEPRECATED_NO_EXPORT ROTOR_THREAD_NO_EXPORT ROTOR_THREAD_DEPRECATED
#endif

/* NOLINTNEXTLINE(readability-avoid-unconditional-preprocessor-if) */
#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef ROTOR_THREAD_NO_DEPRECATED
#    define ROTOR_THREAD_NO_DEPRECATED
#  endif
#endif

#endif /* ROTOR_THREAD_API_H */
