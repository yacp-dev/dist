#pragma once

//
// Copyright (c) 2019-2020 Ivan Baidakou (basiliscos) (the dot dmol at gmail dot com)
//
// Distributed under the MIT Software License
//

/** \file wx.hpp
 * A convenience header to include rotor support for wxWidgets
 */

#include "rotor/wx/supervisor_config_wx.h"
#include "rotor/wx/supervisor_wx.h"
#include "rotor/wx/system_context_wx.h"

namespace rotor {

/// namespace for wxWidgets adapters for `rotor`
namespace wx {}

} // namespace rotor
