
#ifndef ROTOR_WX_API_H
#define ROTOR_WX_API_H

#ifdef ROTOR_WX_STATIC_DEFINE
#  define ROTOR_WX_API
#  define ROTOR_WX_NO_EXPORT
#else
#  ifndef ROTOR_WX_API
#    ifdef rotor_wx_EXPORTS
        /* We are building this library */
#      define ROTOR_WX_API __declspec(dllexport)
#    else
        /* We are using this library */
#      define ROTOR_WX_API __declspec(dllimport)
#    endif
#  endif

#  ifndef ROTOR_WX_NO_EXPORT
#    define ROTOR_WX_NO_EXPORT 
#  endif
#endif

#ifndef ROTOR_WX_DEPRECATED
#  define ROTOR_WX_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef ROTOR_WX_DEPRECATED_EXPORT
#  define ROTOR_WX_DEPRECATED_EXPORT ROTOR_WX_API ROTOR_WX_DEPRECATED
#endif

#ifndef ROTOR_WX_DEPRECATED_NO_EXPORT
#  define ROTOR_WX_DEPRECATED_NO_EXPORT ROTOR_WX_NO_EXPORT ROTOR_WX_DEPRECATED
#endif

/* NOLINTNEXTLINE(readability-avoid-unconditional-preprocessor-if) */
#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef ROTOR_WX_NO_DEPRECATED
#    define ROTOR_WX_NO_DEPRECATED
#  endif
#endif

#endif /* ROTOR_WX_API_H */
