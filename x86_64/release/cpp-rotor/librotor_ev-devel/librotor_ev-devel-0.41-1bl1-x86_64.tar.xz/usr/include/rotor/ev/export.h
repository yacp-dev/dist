
#ifndef ROTOR_EV_API_H
#define ROTOR_EV_API_H

#ifdef ROTOR_EV_STATIC_DEFINE
#  define ROTOR_EV_API
#  define ROTOR_EV_NO_EXPORT
#else
#  ifndef ROTOR_EV_API
#    ifdef rotor_ev_EXPORTS
        /* We are building this library */
#      define ROTOR_EV_API __declspec(dllexport)
#    else
        /* We are using this library */
#      define ROTOR_EV_API __declspec(dllimport)
#    endif
#  endif

#  ifndef ROTOR_EV_NO_EXPORT
#    define ROTOR_EV_NO_EXPORT 
#  endif
#endif

#ifndef ROTOR_EV_DEPRECATED
#  define ROTOR_EV_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef ROTOR_EV_DEPRECATED_EXPORT
#  define ROTOR_EV_DEPRECATED_EXPORT ROTOR_EV_API ROTOR_EV_DEPRECATED
#endif

#ifndef ROTOR_EV_DEPRECATED_NO_EXPORT
#  define ROTOR_EV_DEPRECATED_NO_EXPORT ROTOR_EV_NO_EXPORT ROTOR_EV_DEPRECATED
#endif

/* NOLINTNEXTLINE(readability-avoid-unconditional-preprocessor-if) */
#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef ROTOR_EV_NO_DEPRECATED
#    define ROTOR_EV_NO_DEPRECATED
#  endif
#endif

#endif /* ROTOR_EV_API_H */
