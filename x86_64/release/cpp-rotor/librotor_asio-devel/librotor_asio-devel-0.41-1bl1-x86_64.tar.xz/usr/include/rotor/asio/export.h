
#ifndef ROTOR_ASIO_API_H
#define ROTOR_ASIO_API_H

#ifdef ROTOR_ASIO_STATIC_DEFINE
#  define ROTOR_ASIO_API
#  define ROTOR_ASIO_NO_EXPORT
#else
#  ifndef ROTOR_ASIO_API
#    ifdef rotor_asio_EXPORTS
        /* We are building this library */
#      define ROTOR_ASIO_API __declspec(dllexport)
#    else
        /* We are using this library */
#      define ROTOR_ASIO_API __declspec(dllimport)
#    endif
#  endif

#  ifndef ROTOR_ASIO_NO_EXPORT
#    define ROTOR_ASIO_NO_EXPORT 
#  endif
#endif

#ifndef ROTOR_ASIO_DEPRECATED
#  define ROTOR_ASIO_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef ROTOR_ASIO_DEPRECATED_EXPORT
#  define ROTOR_ASIO_DEPRECATED_EXPORT ROTOR_ASIO_API ROTOR_ASIO_DEPRECATED
#endif

#ifndef ROTOR_ASIO_DEPRECATED_NO_EXPORT
#  define ROTOR_ASIO_DEPRECATED_NO_EXPORT ROTOR_ASIO_NO_EXPORT ROTOR_ASIO_DEPRECATED
#endif

/* NOLINTNEXTLINE(readability-avoid-unconditional-preprocessor-if) */
#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef ROTOR_ASIO_NO_DEPRECATED
#    define ROTOR_ASIO_NO_DEPRECATED
#  endif
#endif

#endif /* ROTOR_ASIO_API_H */
