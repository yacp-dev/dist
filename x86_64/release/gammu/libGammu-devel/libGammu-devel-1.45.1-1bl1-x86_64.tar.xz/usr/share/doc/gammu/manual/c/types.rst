Types
=====

.. doxygentypedef:: gboolean
