Gammu Documentation Contents
----------------------------

.. toctree::
    :maxdepth: 2

    project/index
    quick/index
    faq/index
    python/index
    c/index
    internal/index
    formats/index
    config/index
    gammu/index
    smsd/index
    utils/index
    testing/index
    protocol/index
    glossary

Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
