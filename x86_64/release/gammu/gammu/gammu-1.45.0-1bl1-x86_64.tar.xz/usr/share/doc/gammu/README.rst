Gammu All Mobile Management Utilities
=====================================

Gammu is library and command line utility for mobile phones. It is
released under GNU GPL version 2.

It has been initiated by Marcin Wiacek and other people. Originally the
code was based on Gnokii <https://www.gnokii.org/> and later MyGnokii
<http://www.mwiacek.com/> projects. Gammu was formerly (up to version
0.58) called MyGnokii2.

Currently the project is led by Michal Cihar <michal@cihar.com> with
help of many contributors.

.. image:: https://hosted.weblate.org/widgets/gammu/-/svg-badge.svg
    :alt: Translation status
    :target: https://hosted.weblate.org/engage/gammu/?utm_source=widget

.. image:: https://img.shields.io/liberapay/receives/Gammu.svg
    :alt: Liberapay
    :target: https://liberapay.com/Gammu/donate

More information
================

You can find more information on <https://github.com/gammu/gammu/>.

There is also a Gammu manual available in docs/manual. You can build HTML
version of it using make manual-html which is viewable online at
<https://docs.gammu.org/>.


Feedback and bug reports
========================

Any feedback is welcome, see <https://github.com/gammu/gammu/> for information
how to contact developers.


Support developers
==================

You can appreciate developers' work at <https://wammu.eu/donate/>.
