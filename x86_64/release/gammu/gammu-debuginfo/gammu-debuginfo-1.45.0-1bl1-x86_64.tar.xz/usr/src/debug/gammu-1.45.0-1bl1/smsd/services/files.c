/* (c) 2002-2004 by Joergen Thomsen */
/* Copyright (c) 2009 - 2018 Michal Cihar <michal@cihar.com> */

#include <gammu.h>

#include <string.h>
#include <stdio.h>
#include <errno.h>
#include <limits.h>
#include <time.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>

#ifdef WIN32
#include <io.h>
#else
#include <unistd.h>
#endif
#if defined HAVE_DIRENT_H && defined HAVE_SCANDIR && defined HAVE_ALPHASORT
#define HAVE_DIRBROWSING
#include <dirent.h>
#endif

#include "../core.h"

#include "../../libgammu/misc/string.h"

#ifndef PATH_MAX
#ifdef MAX_PATH
#define PATH_MAX (MAX_PATH)
#else
#define PATH_MAX (4069)
#endif
#endif

/**
 * Helper define to check error code from fwrite.
 */
#define chk_fwrite(data, size, count, file) \
	if (fwrite(data, size, count, file) != count) goto fail;


static void SMSDFiles_EscapeNumber(char *string)
{
	char *pos = string;
	while (*pos) {
		/* Replace invalid filename characters
		 * * is replaced with X (for network service numbers, reversible)
		 * Other invalid chars (Windows: < > : " / \ | ?, control chars) replaced with _
		 */
		if (*pos == '*') {
			*pos = 'X';
		} else if (*pos == '<' || *pos == '>' || *pos == ':' || *pos == '"' ||
		           *pos == '/' || *pos == '\\' || *pos == '|' || *pos == '?' ||
		           ((unsigned char)*pos <= 0x1F) || *pos == 0x7F) {
			*pos = '_';
		}
		pos++;
	}
}

static void SMSDFiles_DecodeNumber(char *string)
{
	char *pos = string;
	while (*pos) {
		if (*pos == 'X') {
			*pos = '*';
		}
		pos++;
	}
}

static GSM_Error SMSDFiles_ValidatePath(size_t result_size,
					const char *path, const char *name,
					GSM_SMSDConfig *Config)
{
	size_t path_length = strlen(path);
	size_t name_length = strlen(name);

	if (path_length >= result_size || name_length >= result_size - path_length) {
		SMSD_Log(DEBUG_ERROR, Config, "Path is too long: %s%s", path, name);
		return ERR_CANTOPENFILE;
	}
	return ERR_NONE;
}

static GSM_Error SMSDFiles_BuildPath(char *result, size_t result_size,
				     const char *path, const char *name,
				     GSM_SMSDConfig *Config)
{
	GSM_Error error;

	error = SMSDFiles_ValidatePath(result_size, path, name, Config);
	if (error != ERR_NONE) {
		return error;
	}

	snprintf(result, result_size, "%s%s", path, name);
	return ERR_NONE;
}

/* Retry state belongs to the daemon, not to the user-provided spool files. */
struct SMSDFilesRetry {
	char ID[GSM_MAX_FILENAME_LENGTH + 1];
	unsigned int retries;
	struct SMSDFilesRetry *next;
};

static void SMSDFiles_ForgetRetries(GSM_SMSDConfig *Config, const char *ID)
{
	struct SMSDFilesRetry **entry = &Config->files_retries;

	while (*entry != NULL) {
		struct SMSDFilesRetry *current = *entry;

		if (strcmp(current->ID, ID) == 0) {
			*entry = current->next;
			free(current);
			return;
		}
		entry = &current->next;
	}
}

static GSM_Error SMSDFiles_Free(GSM_SMSDConfig *Config)
{
	while (Config->files_retries != NULL) {
		struct SMSDFilesRetry *entry = Config->files_retries;

		Config->files_retries = entry->next;
		free(entry);
	}
	return ERR_NONE;
}

static void SMSDFiles_PruneRetries(GSM_SMSDConfig *Config)
{
	struct SMSDFilesRetry **entry = &Config->files_retries;
	char path[PATH_MAX];
	struct stat status;

	while (*entry != NULL) {
		struct SMSDFilesRetry *current = *entry;

		/* Hooks and administrators can remove messages from the outbox. */
		if (SMSDFiles_BuildPath(path, sizeof(path), Config->outboxpath,
				       current->ID, Config) == ERR_NONE &&
		    stat(path, &status) != 0 && (errno == ENOENT || errno == ENOTDIR)) {
			*entry = current->next;
			free(current);
		} else {
			entry = &current->next;
		}
	}
}

static GSM_Error SMSDFiles_LoadRetries(GSM_SMSDConfig *Config, const char *ID)
{
	struct SMSDFilesRetry *entry;

	for (entry = Config->files_retries; entry != NULL; entry = entry->next) {
		if (strcmp(entry->ID, ID) == 0) {
			Config->retries = entry->retries;
			return ERR_NONE;
		}
	}
	entry = malloc(sizeof(*entry));
	if (entry == NULL) {
		return ERR_MOREMEMORY;
	}
	strcpy(entry->ID, ID);
	entry->retries = 0;
	entry->next = Config->files_retries;
	Config->files_retries = entry;
	Config->retries = 0;
	return ERR_NONE;
}

static GSM_Error SMSDFiles_UpdateRetries(GSM_SMSDConfig *Config, char *ID)
{
	struct SMSDFilesRetry *entry;

	for (entry = Config->files_retries; entry != NULL; entry = entry->next) {
		if (strcmp(entry->ID, ID) == 0) {
			/* SMSD_SendSMS increments the count before attempting delivery. */
			entry->retries = Config->retries;
			return ERR_NONE;
		}
	}
	return ERR_EMPTY;
}

/* Save SMS from phone (called Inbox sms - it's in phone Inbox) somewhere */
static GSM_Error SMSDFiles_SaveInboxSMS(GSM_MultiSMSMessage * sms, GSM_SMSDConfig * Config, GSM_StringArray *Locations, GSM_StringArray *SentIDs)
{
	GSM_Error error = ERR_NONE;
	int i, j;
	char FileName[PATH_MAX];
	unsigned char FullName[PATH_MAX], ext[4], buffer[64], buffer2[400];
	gboolean done;
	FILE *file;
#ifdef GSM_ENABLE_BACKUP
	GSM_SMS_Backup *backup;
#endif

	if (SentIDs != NULL) {
		for (i = 0; i < sms->Number; i++) {
			if (!GSM_StringArray_Add(SentIDs, "")) {
				return ERR_MOREMEMORY;
			}
		}
	}

	j = 0;
	done = FALSE;
	for (i = 0; i < sms->Number && !done; i++) {
		strcpy(ext, "txt");
		if (sms->SMS[i].Coding == SMS_Coding_8bit)
			strcpy(ext, "bin");
		DecodeUnicode(sms->SMS[i].Number, buffer2);
		SMSDFiles_EscapeNumber(buffer2);
		/* we loop on yy for the first SMS assuming that if xxxx_yy_00.ext is absent,
		   any xxxx_yy_01,02, must be garbage, that can be overwritten */
		file = NULL;
		do {
			sprintf(FileName,
				"IN%02d%02d%02d_%02d%02d%02d_%02i_%s_%02i.%s",
				sms->SMS[i].DateTime.Year, sms->SMS[i].DateTime.Month, sms->SMS[i].DateTime.Day,
				sms->SMS[i].DateTime.Hour, sms->SMS[i].DateTime.Minute, sms->SMS[i].DateTime.Second, j, buffer2, i, ext);
			strcpy(FullName, Config->inboxpath);
			strcat(FullName, FileName);
			if (file) {
				fclose(file);
			}
			file = fopen(FullName, "r");
		} while ((i == 0) && file != NULL && (++j < 100));

		if (file) {
			fclose(file);
			file = NULL;
			if (i == 0) {
				SMSD_Log(DEBUG_ERROR, Config, "Cannot save %s. No available file names", FileName);
				return ERR_CANTOPENFILE;
			}
		}
		errno = 0;

		if ((sms->SMS[i].PDU == SMS_Status_Report) && strcasecmp(Config->deliveryreport, "log") == 0) {
			strcpy(buffer, DecodeUnicodeString(sms->SMS[i].Number));
			SMSD_Log(DEBUG_NOTICE, Config, "Delivery report: %s to %s, message reference 0x%02x",
				 DecodeUnicodeString(sms->SMS[i].Text), buffer, sms->SMS[i].MessageReference);
		} else {
			if (!GSM_StringArray_Add(Locations, FileName)) {
				return ERR_MOREMEMORY;
			}

			if (strcasecmp(Config->inboxformat, "detail") == 0) {
#ifndef GSM_ENABLE_BACKUP
				SMSD_Log(DEBUG_ERROR, Config, "Saving in detail format not compiled in!");

#else
				backup = malloc(sizeof(GSM_SMS_Backup));
				if (backup == NULL) {
					return ERR_MOREMEMORY;
				}

				for (j = 0; j < sms->Number; j++) {
					backup->SMS[j] = &sms->SMS[j];
				}
				backup->SMS[sms->Number] = NULL;
				error = GSM_AddSMSBackupFile(FullName, backup);
				done = TRUE;
				free(backup);
#endif
			} else {
				file = fopen(FullName, "wb");
				if (file == NULL) {
					SMSD_LogErrno(Config, "Cannot save file!");
					return ERR_CANTOPENFILE;
				}

				switch (sms->SMS[i].Coding) {
					case SMS_Coding_Unicode_No_Compression:
					case SMS_Coding_Default_No_Compression:
						if (strcasecmp(Config->inboxformat, "unicode") == 0) {
							buffer[0] = 0xFE;
							buffer[1] = 0xFF;
							chk_fwrite(buffer, 1, 2, file);
							chk_fwrite(sms->SMS[i].Text, 1, UnicodeLength(sms->SMS[i].Text) * 2, file);
						} else {
							DecodeUnicode(sms->SMS[i].Text, buffer2);
							chk_fwrite(buffer2, 1, strlen(buffer2), file);
						}
						break;
					case SMS_Coding_8bit:
						chk_fwrite(sms->SMS[i].Text, 1, (size_t) sms->SMS[i].Length, file);
					default:
						break;
				}
				fclose(file);
				file = NULL;
			}

			if (error != ERR_NONE) {
				return error;
			}

			SMSD_Log(DEBUG_INFO, Config, "%s %s", (sms->SMS[i].PDU == SMS_Status_Report ? "Delivery report" : "Received"), FileName);
		}
	}
	return ERR_NONE;
fail:
	if (file) {
		fclose(file);
	}
	return ERR_WRITING_FILE;
}

/* Find one multi SMS to sending and return it (or return ERR_EMPTY)
 * There is also set ID for SMS
 * File extension convention:
 * OUTxxxxx.txt : normal text SMS
 * Options appended to the extension applying to this SMS only:
 * d: delivery report requested
 * f: flash SMS
 * b: WAP bookmark as name,URL
 * e.g. OUTG20040620_193810_123_+4512345678_xpq.txtdf
 * is a flash text SMS requesting delivery reports
 */
static GSM_Error SMSDFiles_FindOutboxSMS(GSM_MultiSMSMessage * sms, GSM_SMSDConfig * Config, char *ID)
{
	GSM_MultiPartSMSInfo SMSInfo;
	GSM_WAPBookmark Bookmark;
	char FileName[GSM_MAX_FILENAME_LENGTH + 1], FullName[PATH_MAX];
	unsigned char Buffer[(GSM_MAX_SMS_LENGTH * GSM_MAX_MULTI_SMS + 1) * 2];
	unsigned char Buffer2[(GSM_MAX_SMS_LENGTH * GSM_MAX_MULTI_SMS + 1) * 2];
	FILE *File;
	int i;
	size_t len, phlen;
	char *pos1, *pos2, *options = NULL;
	gboolean backup = FALSE;
	GSM_Error error;
#ifdef GSM_ENABLE_BACKUP
	GSM_SMS_Backup *smsbackup;
#endif
#ifdef WIN32
	struct _finddata_t c_file;
	intptr_t hFile;

	SMSDFiles_PruneRetries(Config);

	error = SMSDFiles_BuildPath(FullName, sizeof(FullName), Config->outboxpath, "OUT*.txt*", Config);
	if (error != ERR_NONE) {
		return error;
	}
	hFile = _findfirst(FullName, &c_file);
	if (hFile == -1) {
		error = SMSDFiles_BuildPath(FullName, sizeof(FullName), Config->outboxpath, "OUT*.smsbackup*", Config);
		if (error != ERR_NONE) {
			return error;
		}
		hFile = _findfirst(FullName, &c_file);
		backup = TRUE;
	}
	if (hFile == -1) {
		return ERR_EMPTY;
	} else {
		if (strlen(c_file.name) >= sizeof(FileName)) {
			_findclose(hFile);
			SMSD_Log(DEBUG_ERROR, Config, "Outbox filename is too long: %s", c_file.name);
			return ERR_CANTOPENFILE;
		}
		strcpy(FileName, c_file.name);
	}
	_findclose(hFile);
#elif defined(HAVE_DIRBROWSING)
	struct dirent **namelist = NULL;
	struct stat entryStatus;
	int outboxFd;
	int cur_file, num_files;
	char *pos;

	SMSDFiles_PruneRetries(Config);

	error = SMSDFiles_BuildPath(FullName, sizeof(FullName), Config->outboxpath, "", Config);
	if (error != ERR_NONE) {
		return error;
	}

	FullName[strlen(Config->outboxpath) - 1] = '\0';
	outboxFd = open(FullName, O_RDONLY | O_DIRECTORY);
	if (outboxFd < 0) {
		return ERR_CANTOPENFILE;
	}

	num_files = scandir(FullName, &namelist, 0, alphasort);

	for (cur_file = 0; cur_file < num_files; cur_file++) {
		/* Hidden file or current/parent directory */
		if (namelist[cur_file]->d_name[0] == '.') {
			continue;
		}
		/* We care only about files starting with out */
		if (strncasecmp(namelist[cur_file]->d_name, "out", 3) != 0) {
			continue;
		}
		/* Check extension */
		pos = strrchr(namelist[cur_file]->d_name, '.');
		if (pos == NULL) {
			continue;
		}
		if (strncasecmp(pos, ".txt", 4) == 0) {
			if (fstatat(outboxFd, namelist[cur_file]->d_name,
				    &entryStatus, AT_SYMLINK_NOFOLLOW) != 0 ||
			    !S_ISREG(entryStatus.st_mode)) {
				continue;
			}
			/* We have found text file */
			backup = FALSE;
			break;
		}
		if (strncasecmp(pos, ".smsbackup", 10) == 0) {
			if (fstatat(outboxFd, namelist[cur_file]->d_name,
				    &entryStatus, AT_SYMLINK_NOFOLLOW) != 0 ||
			    !S_ISREG(entryStatus.st_mode)) {
				continue;
			}
			/* We have found a SMS backup file */
			backup = TRUE;
			break;
		}
	}
	close(outboxFd);
	/* Remember file name */
	if (cur_file < num_files) {
		if (strlen(namelist[cur_file]->d_name) >= sizeof(FileName)) {
			error = ERR_CANTOPENFILE;
		} else {
			strcpy(FileName, namelist[cur_file]->d_name);
		}
	}
	/* Free scandir result */
	for (i = 0; i < num_files; i++) {
		free(namelist[i]);
	}
	free(namelist);
	namelist = NULL;
	/* Did we actually find something? */
	if (cur_file >= num_files) {
		return ERR_EMPTY;
	}
	if (error != ERR_NONE) {
		SMSD_Log(DEBUG_ERROR, Config, "Outbox filename exceeds the supported limit");
		return error;
	}
#else
	return ERR_NOTSUPPORTED;
#endif
	error = SMSDFiles_BuildPath(FullName, sizeof(FullName), Config->outboxpath, FileName, Config);
	if (error != ERR_NONE) {
		return error;
	}
	error = SMSDFiles_ValidatePath(sizeof(FullName), Config->sentsmspath, FileName, Config);
	if (error != ERR_NONE) {
		return error;
	}
	error = SMSDFiles_ValidatePath(sizeof(FullName), Config->errorsmspath, FileName, Config);
	if (error != ERR_NONE) {
		return error;
	}

	if (backup) {
#ifdef GSM_ENABLE_BACKUP
		smsbackup = malloc(sizeof(GSM_SMS_Backup));
		if (smsbackup == NULL) {
			return ERR_MOREMEMORY;
		}

		/* Remember ID */
		strcpy(ID, FileName);
		/* Load backup */
		GSM_ClearSMSBackup(smsbackup);
		error = GSM_ReadSMSBackupFile(FullName, smsbackup);
		if (error != ERR_NONE) {
			free(smsbackup);
			return error;
		}
		/* Copy it to our message */
		sms->Number = 0;
		for (i = 0; smsbackup->SMS[i] != NULL; i++) {
			sms->SMS[sms->Number++] = *(smsbackup->SMS[i]);
		}
		/* Free memory */
		GSM_FreeSMSBackup(smsbackup);
		free(smsbackup);

		/* Set delivery report flag */
		if (sms->SMS[0].PDU == SMS_Status_Report) {
			Config->currdeliveryreport = 1;
		} else {
			Config->currdeliveryreport = -1;
		}
#else
		SMSD_Log(DEBUG_ERROR, Config, "SMS backup loading disabled at compile time!");
		return ERR_DISABLED;

#endif
	} else {
		options = strrchr(FileName, '.') + 4;

		File = fopen(FullName, "rb");
		if (File == NULL) {
			return ERR_CANTOPENFILE;
		}
		len = fread(Buffer, 1, sizeof(Buffer) - 2, File);
		fclose(File);

		if ((len < 2) || (len >= 2 && ((Buffer[0] != 0xFF || Buffer[1] != 0xFE) && (Buffer[0] != 0xFE || Buffer[1] != 0xFF)))) {
			if (len > GSM_MAX_SMS_LENGTH * GSM_MAX_MULTI_SMS)
				len = GSM_MAX_SMS_LENGTH * GSM_MAX_MULTI_SMS;
			EncodeUnicode(Buffer2, Buffer, len);
			len = len * 2;
			memmove(Buffer, Buffer2, len);
			Buffer[len] = 0;
			Buffer[len + 1] = 0;
		} else {
			Buffer[len] = 0;
			Buffer[len + 1] = 0;
			/* Possibly convert byte order */
			ReadUnicodeFile(Buffer2, Buffer);
		}

		GSM_ClearMultiPartSMSInfo(&SMSInfo);
		sms->Number = 0;

		SMSInfo.ReplaceMessage = 0;
		SMSInfo.Entries[0].Buffer = Buffer2;
		SMSInfo.Class = -1;
		SMSInfo.EntriesNum = 1;
		Config->currdeliveryreport = -1;
		if (strchr(options, 'd'))
			Config->currdeliveryreport = 1;
		if (strchr(options, 'f'))
			SMSInfo.Class = 0;	/* flash SMS */

		if (strcasecmp(Config->transmitformat, "unicode") == 0) {
			SMSInfo.Entries[0].ID = SMS_ConcatenatedTextLong;
			SMSInfo.UnicodeCoding = TRUE;
		} else if (strcasecmp(Config->transmitformat, "7bit") == 0) {
			SMSInfo.Entries[0].ID = SMS_ConcatenatedTextLong;
			SMSInfo.UnicodeCoding = FALSE;
		} else {
			/* auto */
			SMSInfo.Entries[0].ID = SMS_ConcatenatedAutoTextLong;
		}

		if (strchr(options, 'b')) {	// WAP bookmark as title,URL
			/* Null-terminated comma character in UCS2 format */
			static const unsigned char unicode_comma[] = {0x00, 0x2C, 0x00, 0x00};
			SMSInfo.Entries[0].Buffer = NULL;
			SMSInfo.Entries[0].Bookmark = &Bookmark;
			SMSInfo.Entries[0].ID = SMS_NokiaWAPBookmarkLong;
			SMSInfo.Entries[0].Bookmark->Location = 0;
			pos2 = (char *)mywstrstr(Buffer2, unicode_comma);
			if (pos2 == NULL) {
				pos2 = Buffer2;
			} else {
				*pos2 = '\0';
				pos2++;
				*pos2 = '\0';
				pos2++;	// replace comma by zero
			}

			len = UnicodeLength(Buffer2);
			if (len > 50) {
				len = 50;
			}
			memmove(&SMSInfo.Entries[0].Bookmark->Title, Buffer2, len * 2);
			pos1 = &SMSInfo.Entries[0].Bookmark->Title[0] + len * 2;
			*pos1 = '\0';
			pos1++;
			*pos1 = '\0';

			len = UnicodeLength(pos2);
			if (len > 255) {
				len = 255;
			}
			memmove(&SMSInfo.Entries[0].Bookmark->Address, pos2, len * 2);
			pos1 = &SMSInfo.Entries[0].Bookmark->Address[0] + len * 2;
			*pos1 = '\0';
			pos1++;
			*pos1 = '\0';
		}

		GSM_EncodeMultiPartSMS(GSM_GetDebug(Config->gsm), &SMSInfo, sms);

		strcpy(ID, FileName);
		pos1 = FileName;
		for (i = 1; i <= 3 && pos1 != NULL; i++) {
			pos1 = strchr(++pos1, '_');
		}
		if (pos1 != NULL) {
			/* OUT<priority><date>_<time>_<serialno>_<phone number>_<anything>.txt */
			pos2 = strchr(++pos1, '_');
			if (pos2 != NULL) {
				phlen = strlen(pos1) - strlen(pos2);
			} else {
				/* something wrong */
				return ERR_UNKNOWN;
			}
		} else if (i == 2) {
			/* OUTxxxxxxx.txt or OUTxxxxxxx */
			pos1 = &FileName[3];
			pos2 = strchr(pos1, '.');
			if (pos2 == NULL) {
				phlen = strlen(pos1);
			} else {
				phlen = strlen(pos1) - strlen(pos2);
			}
		} else if (i == 4) {
			/* OUT<priority>_<phone number>_<serialno>.txt */
			pos1 = strchr(FileName, '_');
			if (pos1 == NULL) {
				return ERR_BUG;
			}
			pos2 = strchr(++pos1, '_');
			if (pos2 == NULL) {
				return ERR_BUG;
			}
			phlen = strlen(pos1) - strlen(pos2);
		} else {
			/* something wrong */
			return ERR_UNKNOWN;
		}

		if (phlen > GSM_MAX_NUMBER_LENGTH) {
			SMSD_Log(DEBUG_ERROR, Config, "Recipient in outbox filename is too long: %s", ID);
			return ERR_INVALIDDATA;
		}
		SMSDFiles_DecodeNumber(pos1);
		for (i = 0; i < sms->Number; i++) {
			EncodeUnicode(sms->SMS[i].Number, pos1, phlen);
		}
	}

	if (sms->Number != 0) {
		DecodeUnicode(sms->SMS[0].Number, Buffer);
		if (options != NULL && strchr(options, 'b')) {	// WAP bookmark as title,URL
			SMSD_Log(DEBUG_NOTICE, Config, "Found %i sms to \"%s\" with bookmark \"%s\" cod %i lgt %i udh: t %i l %i dlr: %i fls: %i",
				 sms->Number,
				 Buffer,
				 DecodeUnicodeString(SMSInfo.Entries[0].Bookmark->Address),
				 sms->SMS[0].Coding, sms->SMS[0].Length, sms->SMS[0].UDH.Type, sms->SMS[0].UDH.Length, Config->currdeliveryreport, SMSInfo.Class);
		} else {
			SMSD_Log(DEBUG_NOTICE, Config, "Found %i sms to \"%s\" with text \"%s\" cod %i lgt %i udh: t %i l %i dlr: %i fls: %i",
				 sms->Number,
				 Buffer,
				 DecodeUnicodeString(sms->SMS[0].Text),
				 sms->SMS[0].Coding, sms->SMS[0].Length, sms->SMS[0].UDH.Type, sms->SMS[0].UDH.Length, Config->currdeliveryreport, sms->SMS[0].Class);
		}
	} else {
		SMSD_Log(DEBUG_NOTICE, Config, "error: SMS-count = 0");
	}

	error = SMSDFiles_LoadRetries(Config, ID);
	if (error != ERR_NONE) {
		/* A transient allocation failure must not make the core discard a
		 * valid outbox message through its generic scan-error path. */
		ID[0] = '\0';
	}
	return error;
}

/* After sending SMS is moved to Sent Items or Error Items. */
static GSM_Error SMSDFiles_MoveSMS(GSM_MultiSMSMessage * sms UNUSED, GSM_SMSDConfig * Config, char *ID, gboolean alwaysDelete, gboolean sent)
{
	FILE *oFile, *iFile;
	size_t ilen = 0, olen = 0;
	char Buffer[(GSM_MAX_SMS_LENGTH * GSM_MAX_MULTI_SMS + 1) * 2], ifilename[PATH_MAX], ofilename[PATH_MAX];
	const char *sourcepath, *destpath;
	GSM_Error error;

	sourcepath = Config->outboxpath;

	// Determine target based on status
	if (sent) {
		destpath = Config->sentsmspath;
	} else {
		destpath = Config->errorsmspath;
	}

	// Calculate source path
	error = SMSDFiles_BuildPath(ifilename, sizeof(ifilename), sourcepath, ID, Config);
	if (error != ERR_NONE) {
		return error;
	}
	// Calculate destination path
	error = SMSDFiles_BuildPath(ofilename, sizeof(ofilename), destpath, ID, Config);
	if (error != ERR_NONE) {
		return error;
	}

	// Do move only if paths are not same
	if (strcmp(ifilename, ofilename) != 0) {
		// First try rename
		if (rename(ifilename, ofilename) == 0) {
			SMSD_Log(DEBUG_INFO, Config, "Renamed %s to %s", ifilename, ofilename);
			SMSDFiles_ForgetRetries(Config, ID);
			return ERR_NONE;
		}

		// Move across devices
		if (errno != EXDEV) {
			SMSD_LogErrno(Config, "Can not move file");
			SMSD_Log(DEBUG_INFO, Config, "Could move %s to %s", ifilename, ofilename);
			return ERR_UNKNOWN;
		}

		// Read source file
		iFile = fopen(ifilename, "r");
		if (iFile == NULL) {
			SMSD_LogErrno(Config, "Can not open file");
			return ERR_CANTOPENFILE;
		}
		ilen = fread(Buffer, 1, sizeof(Buffer), iFile);
		fclose(iFile);

		// Write target file
		oFile = fopen(ofilename, "w");
		if (oFile == NULL) {
			SMSD_LogErrno(Config, "Can not open file");
			return ERR_CANTOPENFILE;
		}
		olen = fwrite(Buffer, 1, ilen, oFile);
		fclose(oFile);
	}

	// Did we write all data?
	error = ERR_NONE;
	if (ilen != olen) {
		SMSD_Log(DEBUG_ERROR, Config, "Failed to copy %s to %s", ifilename, ofilename);
		error = ERR_UNKNOWN;
	} else {
		SMSD_Log(DEBUG_INFO, Config, "Copied %s to %s", ifilename, ofilename);
	}

	// Remove source file
	if (error == ERR_NONE || alwaysDelete) {
		if (unlink(ifilename) != 0) {
			SMSD_LogErrno(Config, "Can not remove file");
			return ERR_UNKNOWN;
		}
		SMSDFiles_ForgetRetries(Config, ID);
	}

	return error;
}

/* Adds SMS to Outbox */
static GSM_Error SMSDFiles_CreateOutboxSMS(GSM_MultiSMSMessage * sms, GSM_SMSDConfig * Config, char *NewID)
{
	int i, j;
	int fd;
	unsigned char FileName[PATH_MAX], FullName[PATH_MAX], ext[17], buffer[64], buffer2[400];
	FILE *file = NULL;
	time_t rawtime;
	struct tm *timeinfo;

#ifdef GSM_ENABLE_BACKUP
	GSM_Error error;
	GSM_SMS_Backup *backup;
#endif

	j = 0;
	time(&rawtime);
	timeinfo = localtime(&rawtime);

	for (i = 0; i < sms->Number; i++) {
		if (strcasecmp(Config->outboxformat, "detail") == 0) {
			strcpy(ext, "smsbackup");
		} else {
			strcpy(ext, "txt");
		}
		DecodeUnicode(sms->SMS[i].Number, buffer2);
		SMSDFiles_EscapeNumber(buffer2);

		for (j = 0; j < 100; j++) {
			sprintf(FileName,
				"OUTC%04d%02d%02d_%02d%02d%02d_00_%s_sms%d.%s",
				1900 + timeinfo->tm_year, timeinfo->tm_mon + 1, timeinfo->tm_mday, timeinfo->tm_hour, timeinfo->tm_min, timeinfo->tm_sec, buffer2, j, ext);
			strcpy(FullName, Config->outboxpath);
			strcat(FullName, FileName);
			fd = open(FullName, O_CREAT | O_EXCL, 0644);
			if (fd >= 0) {
				close(fd);
				break;
			}
		}

		if (j >= 100) {
			if (i == 0) {
				SMSD_Log(DEBUG_ERROR, Config, "Cannot save %s. No available file names", FileName);
				return ERR_CANTOPENFILE;
			}
		}

		if (strcasecmp(Config->outboxformat, "detail") == 0) {
#ifndef GSM_ENABLE_BACKUP
			SMSD_Log(DEBUG_ERROR, Config, "Saving in detail format not compiled in!");

#else
			backup = malloc(sizeof(GSM_SMS_Backup));
			if (backup == NULL) {
				return ERR_MOREMEMORY;
			}

			for (j = 0; j < sms->Number; j++) {
				backup->SMS[j] = &sms->SMS[j];
			}
			backup->SMS[sms->Number] = NULL;
			error = GSM_AddSMSBackupFile(FullName, backup);

			free(backup);

			if (error != ERR_NONE) {
				return error;
			}
#endif
			/* Force leaving the loop */
			i = sms->Number;
		} else {
			file = fopen(FullName, "wb");
			if (file == NULL) {
				SMSD_LogErrno(Config, "Cannot save file!");
				return ERR_CANTOPENFILE;
			}
			switch (sms->SMS[i].Coding) {
				case SMS_Coding_Unicode_No_Compression:
				case SMS_Coding_Default_No_Compression:
					if (strcasecmp(Config->outboxformat, "unicode") == 0) {
						buffer[0] = 0xFE;
						buffer[1] = 0xFF;
						chk_fwrite(buffer, 1, 2, file);
						chk_fwrite(sms->SMS[i].Text, 1, UnicodeLength(sms->SMS[i].Text) * 2, file);
					} else {
						DecodeUnicode(sms->SMS[i].Text, buffer2);
						chk_fwrite(buffer2, 1, strlen(buffer2), file);
					}
					break;
				case SMS_Coding_8bit:
					chk_fwrite(sms->SMS[i].Text, 1, (size_t) sms->SMS[i].Length, file);
				default:
					break;
			}
			fclose(file);
			file = NULL;
		}

		SMSD_Log(DEBUG_INFO, Config, "Created outbox message %s", FileName);
	}

	if (NewID != NULL) {
		strcpy(NewID, FullName);
	}

	return ERR_NONE;
fail:
	if (file) {
		fclose(file);
	}
	return ERR_WRITING_FILE;
}

static GSM_Error SMSDFiles_WriteSentSMSInfo(FILE *file, GSM_File *GSMFile,
					    unsigned char *lineStart,
					    unsigned char *suffix,
					    size_t suffixLength, int TPMR)
{
	/* MessageReference TPMR maximum is "255" */
	char MessageReferenceBuffer[sizeof("MessageReference = \n") + 4];

	if (fwrite(GSMFile->Buffer, 1, lineStart - GSMFile->Buffer, file) !=
	    (size_t)(lineStart - GSMFile->Buffer)) {
		return ERR_WRITING_FILE;
	}

	snprintf(MessageReferenceBuffer, sizeof(MessageReferenceBuffer),
		 "MessageReference = %d\n", TPMR);

	if (fwrite(MessageReferenceBuffer, 1, strlen(MessageReferenceBuffer), file) !=
	    strlen(MessageReferenceBuffer)) {
		return ERR_WRITING_FILE;
	}
	if (suffixLength > 0 && fwrite(suffix, 1, suffixLength, file) != suffixLength) {
		return ERR_WRITING_FILE;
	}
	return ERR_NONE;
}

#ifndef WIN32
static GSM_Error SMSDFiles_ReadSentSMSInfo(int fd, GSM_File *GSMFile)
{
	ssize_t length;
	unsigned char *buffer;

	free(GSMFile->Buffer);
	GSMFile->Buffer = NULL;
	GSMFile->Used = 0;
	for (;;) {
		if (GSMFile->Used > (size_t)-1 - 1001) {
			free(GSMFile->Buffer);
			GSMFile->Buffer = NULL;
			GSMFile->Used = 0;
			return ERR_MOREMEMORY;
		}
		buffer = realloc(GSMFile->Buffer, GSMFile->Used + 1001);
		if (buffer == NULL) {
			free(GSMFile->Buffer);
			GSMFile->Buffer = NULL;
			GSMFile->Used = 0;
			return ERR_MOREMEMORY;
		}
		GSMFile->Buffer = buffer;
		do {
			length = read(fd, GSMFile->Buffer + GSMFile->Used, 1000);
		} while (length < 0 && errno == EINTR);
		if (length < 0) {
			free(GSMFile->Buffer);
			GSMFile->Buffer = NULL;
			GSMFile->Used = 0;
			return ERR_CANTOPENFILE;
		}
		if (length == 0) {
			break;
		}
		GSMFile->Used += (size_t)length;
	}
	GSMFile->Buffer[GSMFile->Used] = '\0';
	return ERR_NONE;
}
#endif

static GSM_Error SMSDFiles_AddSentSMSInfo(GSM_MultiSMSMessage * sms UNUSED, GSM_SMSDConfig * Config, char *ID UNUSED, int Part, GSM_SMSDSendingError err, int TPMR)
{
	FILE *file = NULL;
	GSM_File GSMFile;
	GSM_Error error;
	int i;
	int fd = -1;
	unsigned char FullPath[PATH_MAX];
	unsigned char *lineStart, *lineEnd, *suffix;
	size_t suffixLength;
	char TempPath[PATH_MAX];
#ifdef WIN32
	DWORD fileAttributes;
	gboolean readOnlyCleared = FALSE;
#else
	int originalFd = -1;
	int tempDirFd = -1;
	struct stat fileStatus;
	struct stat currentStatus;
	struct stat tempDirStatus;
#endif

	TempPath[0] = '\0';

	if (err == SMSD_SEND_OK) {
		SMSD_Log(DEBUG_INFO, Config, "Transmitted %s (%s: %i) to %s, message reference 0x%02x",
			 Config->SMSID, (Part == sms->Number ? "total" : "part"), Part, DecodeUnicodeString(sms->SMS[0].Number), TPMR);
	}

	error = SMSDFiles_BuildPath((char *)FullPath, sizeof(FullPath), Config->outboxpath, (char *)Config->SMSID, Config);
	if (error != ERR_NONE) {
		return error;
	}

	// Read file content
	GSMFile.Buffer = NULL;
	GSMFile.Used = 0;
#ifdef WIN32
	error = GSM_ReadFile(FullPath, &GSMFile);
#else
	originalFd = open((char *)FullPath, O_RDONLY | O_NOFOLLOW);
	if (originalFd < 0 || fstat(originalFd, &fileStatus) != 0 ||
	    !S_ISREG(fileStatus.st_mode)) {
		SMSD_LogErrno(Config, "AddSentSMSInfo: Failed to open original file");
		if (originalFd >= 0) {
			close(originalFd);
		}
		return ERR_CANTOPENFILE;
	}
	error = SMSDFiles_ReadSentSMSInfo(originalFd, &GSMFile);
#endif

	if (error != ERR_NONE) {
		SMSD_Log(DEBUG_ERROR, Config, "AddSentSMSInfo: Failed to read file!");
#ifndef WIN32
		close(originalFd);
#endif
		free(GSMFile.Buffer);
		return error;
	}

	// Allocate additional space for trailing zero
	GSMFile.Buffer = realloc(GSMFile.Buffer, GSMFile.Used + 1);

	if (GSMFile.Buffer == NULL) {
#ifndef WIN32
		close(originalFd);
#endif
		return ERR_MOREMEMORY;
	}

	GSMFile.Buffer[GSMFile.Used] = '\0';

	lineStart = GSMFile.Buffer;
	for (i = 0; i < Part; i++) {
		lineStart = strstr(lineStart, "\nMessageReference = ");
		if (lineStart == NULL) {
#ifndef WIN32
			close(originalFd);
#endif
			free(GSMFile.Buffer);
			return ERR_NONE;
		}
		lineStart++;
	}

	lineEnd = strchr(lineStart, '\n');
	if (lineEnd == NULL) {
		suffix = GSMFile.Buffer + GSMFile.Used;
		suffixLength = 0;
	} else {
		suffix = lineEnd + 1;
		suffixLength = GSMFile.Used - (suffix - GSMFile.Buffer);
	}

	/* Keep writable files on their original inode, as the files backend did
	 * historically. Besides avoiding the need for another inode, this preserves
	 * all metadata associated with the file. */
	/* Open only the file that was read above. Using fopen("wb") here could
	 * recreate it with default permissions if it disappeared in between. */
#ifdef WIN32
	fd = _open((char *)FullPath, _O_WRONLY | _O_BINARY);
#else
	fd = open((char *)FullPath, O_WRONLY);
	if (fd >= 0) {
		if (fstat(fd, &currentStatus) != 0 ||
		    currentStatus.st_dev != fileStatus.st_dev ||
		    currentStatus.st_ino != fileStatus.st_ino) {
			SMSD_Log(DEBUG_ERROR, Config,
				 "AddSentSMSInfo: Outbox entry changed while being processed");
			close(fd);
			fd = -1;
			errno = EAGAIN;
			goto fail;
		}
	}
#endif
	if (fd >= 0) {
		file = fdopen(fd, "wb");
		if (file == NULL) {
			goto fail;
		}
		fd = -1;
#ifdef WIN32
		if (_chsize(fileno(file), 0) != 0) {
#else
		/* fdopen does not truncate an existing descriptor. Do this only after
		 * the stream has been allocated so allocation failure leaves the
		 * successfully sent outbox entry intact. */
		if (ftruncate(fileno(file), 0) != 0) {
#endif
			goto fail;
		}
		error = SMSDFiles_WriteSentSMSInfo(file, &GSMFile, lineStart, suffix,
						       suffixLength, TPMR);
		if (error != ERR_NONE) {
			goto fail;
		}
		if (fclose(file) != 0) {
			file = NULL;
			goto close_failure;
		}
		file = NULL;
#ifndef WIN32
		close(originalFd);
		originalFd = -1;
#endif
		free(GSMFile.Buffer);
		return ERR_NONE;
	}

#ifdef WIN32
	fileAttributes = GetFileAttributesA((char *)FullPath);
	if (fileAttributes == INVALID_FILE_ATTRIBUTES) {
		SMSD_LogErrno(Config, "AddSentSMSInfo: Failed to get file attributes");
		free(GSMFile.Buffer);
		return ERR_CANTOPENFILE;
	}
#endif

	/* This basename is no longer than the shortest valid outbox filename
	 * (OUT.txt), and cannot be picked up by an OUT* scanner after a crash. */
	error = SMSDFiles_BuildPath(TempPath, sizeof(TempPath), Config->outboxpath,
				    ".XXXXXX", Config);
	if (error != ERR_NONE) {
#ifndef WIN32
		close(originalFd);
#endif
		free(GSMFile.Buffer);
		return error;
	}
#ifdef WIN32
	if (_mktemp_s(TempPath, sizeof(TempPath)) != 0) {
		SMSD_Log(DEBUG_ERROR, Config, "AddSentSMSInfo: Failed to create temporary filename");
		free(GSMFile.Buffer);
		return ERR_CANTOPENFILE;
	}
	fd = _open(TempPath, _O_WRONLY | _O_CREAT | _O_EXCL | _O_BINARY,
		   _S_IREAD | _S_IWRITE);
#else
	/* Keep the replacement in a private directory and address it through the
	 * directory descriptor. Submitters with access to the outbox parent can
	 * rename that directory, but cannot swap the entry used by linkat. */
	if (mkdtemp(TempPath) == NULL) {
		SMSD_Log(DEBUG_ERROR, Config,
			 "AddSentSMSInfo: Failed to create temporary directory: %s",
			 strerror(errno));
		close(originalFd);
		free(GSMFile.Buffer);
		return ERR_CANTOPENFILE;
	}
	tempDirFd = open(TempPath, O_RDONLY | O_DIRECTORY | O_NOFOLLOW);
	if (tempDirFd < 0 || fstat(tempDirFd, &tempDirStatus) != 0 ||
	    !S_ISDIR(tempDirStatus.st_mode) ||
	    tempDirStatus.st_uid != geteuid() ||
	    (tempDirStatus.st_mode & 077) != 0) {
		SMSD_Log(DEBUG_ERROR, Config,
			 "AddSentSMSInfo: Failed to open the created temporary directory");
		errno = EAGAIN;
		goto fail;
	}
	fd = openat(tempDirFd, "message", O_WRONLY | O_CREAT | O_EXCL, 0600);
#endif
	if (fd < 0) {
		SMSD_Log(DEBUG_ERROR, Config,
			 "AddSentSMSInfo: Failed to create temporary file: %s", strerror(errno));
#ifndef WIN32
		if (tempDirFd >= 0) {
			close(tempDirFd);
			tempDirFd = -1;
			if (rmdir(TempPath) == 0) {
				TempPath[0] = '\0';
			} else {
				SMSD_Log(DEBUG_INFO, Config,
					 "AddSentSMSInfo: Leaving temporary directory after create failure: %s",
					 TempPath);
			}
		}
		close(originalFd);
#endif
		free(GSMFile.Buffer);
		return ERR_CANTOPENFILE;
	}
#ifndef WIN32
	/* Replacing a non-writable inode only attempts to preserve its basic
	 * ownership and mode metadata. */
	if (fchown(fd, fileStatus.st_uid, fileStatus.st_gid) != 0) {
		SMSD_Log(DEBUG_INFO, Config,
			 "AddSentSMSInfo: Could not preserve file ownership: %s", strerror(errno));
	}
	if (fchmod(fd, fileStatus.st_mode & 07777) != 0) {
		SMSD_Log(DEBUG_INFO, Config,
			 "AddSentSMSInfo: Could not preserve file permissions: %s", strerror(errno));
	}
#endif
	file = fdopen(fd, "wb");
	if (file == NULL) {
		SMSD_Log(DEBUG_ERROR, Config,
			 "AddSentSMSInfo: Failed to open temporary file: %s", strerror(errno));
		goto fail;
	}
	fd = -1;

	error = SMSDFiles_WriteSentSMSInfo(file, &GSMFile, lineStart, suffix,
					       suffixLength, TPMR);
	if (error != ERR_NONE) {
		goto fail;
	}
	if (fclose(file) != 0) {
		file = NULL;
		goto close_failure;
	}
	file = NULL;

#ifdef WIN32
	if ((fileAttributes & FILE_ATTRIBUTE_READONLY) != 0) {
		DWORD writableAttributes = fileAttributes & ~FILE_ATTRIBUTE_READONLY;

		if (writableAttributes == 0) {
			writableAttributes = FILE_ATTRIBUTE_NORMAL;
		}
		if (!SetFileAttributesA((char *)FullPath,
					writableAttributes)) {
			SMSD_LogErrno(Config, "AddSentSMSInfo: Failed to clear read-only attribute");
			goto fail;
		}
		readOnlyCleared = TRUE;
	}
	if (!ReplaceFileA((char *)FullPath, TempPath, NULL, 0, NULL, NULL)) {
		DWORD replaceError = GetLastError();

		if (readOnlyCleared) {
			DWORD currentAttributes = GetFileAttributesA((char *)FullPath);

			if (currentAttributes != INVALID_FILE_ATTRIBUTES) {
				SetFileAttributesA((char *)FullPath,
						   currentAttributes | FILE_ATTRIBUTE_READONLY);
			}
		}
		SetLastError(replaceError);
		SMSD_LogErrno(Config, "AddSentSMSInfo: Failed to replace file");
		goto fail;
	}
	TempPath[0] = '\0';
#else
	/* Atomically claim the current directory entry in the protected directory,
	 * then verify that it is the inode read above. This avoids a check/use gap
	 * at FullPath: a replacement submitted before this rename is preserved in
	 * the private directory rather than overwritten. */
	if (renameat(AT_FDCWD, (char *)FullPath, tempDirFd, "original") != 0) {
		SMSD_LogErrno(Config, "AddSentSMSInfo: Failed to claim original file");
		goto fail;
	}
	if (fstatat(tempDirFd, "original", &currentStatus,
		    AT_SYMLINK_NOFOLLOW) != 0 ||
	    currentStatus.st_dev != fileStatus.st_dev ||
	    currentStatus.st_ino != fileStatus.st_ino) {
		SMSD_Log(DEBUG_ERROR, Config,
			 "AddSentSMSInfo: Outbox entry changed before replacement");
		/* Restore the claimed entry only if no newer producer has reused the
		 * pathname. Otherwise leave it protected for manual recovery. */
		if (linkat(tempDirFd, "original", AT_FDCWD,
			   (char *)FullPath, 0) == 0) {
			unlinkat(tempDirFd, "original", 0);
		}
		errno = EAGAIN;
		goto fail;
	}
	/* linkat fails rather than overwriting a message submitted after the claim.
	 * Both source names are protected by tempDirFd. */
	if (linkat(tempDirFd, "message", AT_FDCWD, (char *)FullPath, 0) != 0) {
		int replaceError = errno;

		SMSD_LogErrno(Config, "AddSentSMSInfo: Failed to replace file");
		/* The claim removed FullPath. Put the original entry back whenever no
		 * producer has occupied that pathname in the meantime. */
		if (linkat(tempDirFd, "original", AT_FDCWD,
			   (char *)FullPath, 0) == 0) {
			unlinkat(tempDirFd, "original", 0);
		}
		errno = replaceError;
		goto fail;
	}
	if (unlinkat(tempDirFd, "message", 0) != 0) {
		SMSD_LogErrno(Config,
				 "AddSentSMSInfo: Failed to unlink temporary replacement");
	}
	if (unlinkat(tempDirFd, "original", 0) != 0) {
		SMSD_LogErrno(Config,
				 "AddSentSMSInfo: Failed to unlink replaced original");
	}
	close(tempDirFd);
	tempDirFd = -1;
	if (rmdir(TempPath) != 0) {
		SMSD_Log(DEBUG_INFO, Config,
			 "AddSentSMSInfo: Could not remove temporary directory: %s",
			 strerror(errno));
	}
	TempPath[0] = '\0';
	close(originalFd);
	originalFd = -1;
#endif

	free(GSMFile.Buffer);
	return ERR_NONE;
fail:
	SMSD_LogErrno(Config, "AddSentSMSInfo: Failed to write");
	if (file) {
		fclose(file);
	}
	if (fd >= 0) {
#ifdef WIN32
		_close(fd);
#else
		close(fd);
#endif
	}
#ifndef WIN32
	if (tempDirFd >= 0) {
		close(tempDirFd);
	}
	if (originalFd >= 0) {
		close(originalFd);
	}
#endif
	if (TempPath[0] != '\0') {
		/* The outbox directory can be writable by message submitters. Leave the
		 * hidden temporary entry for safe manual cleanup rather than deleting a
		 * pathname that might have been swapped. */
		SMSD_Log(DEBUG_INFO, Config,
			 "AddSentSMSInfo: Leaving temporary file after failure: %s",
			 TempPath);
	}
	free(GSMFile.Buffer);
	return ERR_WRITING_FILE;
close_failure:
	SMSD_LogErrno(Config,
			 "AddSentSMSInfo: Could not flush sent-info update; treating message as sent");
#ifndef WIN32
	if (tempDirFd >= 0) {
		close(tempDirFd);
	}
	if (originalFd >= 0) {
		close(originalFd);
	}
#endif
	if (TempPath[0] != '\0') {
		SMSD_Log(DEBUG_INFO, Config,
			 "AddSentSMSInfo: Leaving temporary file after close failure: %s",
			 TempPath);
	}
	free(GSMFile.Buffer);
	return ERR_NONE;
}

GSM_Error SMSD_Check_Dir(GSM_SMSDConfig *Config, const char *path, const char *name)
{
#ifndef WIN32
	struct stat s;

	if (stat(path, &s) < 0) {
		SMSD_Log(DEBUG_ERROR, Config, "Failed to stat \"%s\" (%s)", path, name);
		return ERR_FILENOTEXIST;
	}

	if (!S_ISDIR(s.st_mode)) {
		SMSD_Log(DEBUG_ERROR, Config, "The path \"%s\" (%s) is not a folder", path, name);
		return ERR_FILENOTEXIST;
	}
#else
	DWORD dwAttrib;

	dwAttrib = GetFileAttributes(path);
	if (dwAttrib == INVALID_FILE_ATTRIBUTES) {
		SMSD_Log(DEBUG_ERROR, Config, "Failed to stat \"%s\" (%s)", path, name);
		return ERR_FILENOTEXIST;
	}

	if ((dwAttrib & FILE_ATTRIBUTE_DIRECTORY) == 0) {
		SMSD_Log(DEBUG_ERROR, Config, "The path \"%s\" (%s) is not a folder", path, name);
		return ERR_FILENOTEXIST;
	}
#endif
	return ERR_NONE;
}

GSM_Error SMSDFiles_ReadConfiguration(GSM_SMSDConfig *Config)
{
	static unsigned char	emptyPath[1] = "\0";
	GSM_Error error;

	Config->inboxpath=INI_GetValue(Config->smsdcfgfile, "smsd", "inboxpath", FALSE);
	if (Config->inboxpath == NULL) {
		Config->inboxpath = emptyPath;
	} else {
		error = SMSD_Check_Dir(Config, Config->inboxpath, "inboxpath");
		if (error != ERR_NONE) {
			return error;
		}
	}

	Config->inboxformat=INI_GetValue(Config->smsdcfgfile, "smsd", "inboxformat", FALSE);
	if (Config->inboxformat == NULL ||
			(strcasecmp(Config->inboxformat, "detail") != 0 &&
			strcasecmp(Config->inboxformat, "standard") != 0 &&
			strcasecmp(Config->inboxformat, "unicode") != 0)) {
		Config->inboxformat = "standard";
	}
	SMSD_Log(DEBUG_NOTICE, Config, "Inbox is \"%s\" with format \"%s\"", Config->inboxpath, Config->inboxformat);


	Config->outboxpath=INI_GetValue(Config->smsdcfgfile, "smsd", "outboxpath", FALSE);
	if (Config->outboxpath == NULL) {
		Config->outboxpath = emptyPath;
	} else {
		error = SMSD_Check_Dir(Config, Config->outboxpath, "outboxpath");
		if (error != ERR_NONE) {
			return error;
		}
	}

	Config->transmitformat=INI_GetValue(Config->smsdcfgfile, "smsd", "transmitformat", FALSE);
	if (Config->transmitformat == NULL || (strcasecmp(Config->transmitformat, "auto") != 0 && strcasecmp(Config->transmitformat, "unicode") != 0)) {
		Config->transmitformat = "7bit";
	}
	Config->outboxformat=INI_GetValue(Config->smsdcfgfile, "smsd", "outboxformat", FALSE);
	if (Config->outboxformat == NULL ||
			(strcasecmp(Config->outboxformat, "detail") != 0 &&
			strcasecmp(Config->outboxformat, "standard") != 0 &&
			strcasecmp(Config->outboxformat, "unicode") != 0)) {
#ifdef GSM_ENABLE_BACKUP
		Config->outboxformat = "detail";
#else
		Config->outboxformat = "standard";
#endif
	}
	SMSD_Log(DEBUG_NOTICE, Config, "Outbox is \"%s\" with format \"%s\" and transmission format \"%s\"",
		Config->outboxpath,
		Config->outboxformat,
		Config->transmitformat);

	Config->sentsmspath=INI_GetValue(Config->smsdcfgfile, "smsd", "sentsmspath", FALSE);
	if (Config->sentsmspath == NULL) {
		Config->sentsmspath = Config->outboxpath;
	} else {
		error = SMSD_Check_Dir(Config, Config->sentsmspath, "sentsmspath");
		if (error != ERR_NONE) {
			return error;
		}
	}
	SMSD_Log(DEBUG_NOTICE, Config, "Sent SMS moved to \"%s\"",Config->sentsmspath);

	Config->errorsmspath=INI_GetValue(Config->smsdcfgfile, "smsd", "errorsmspath", FALSE);
	if (Config->errorsmspath == NULL) {
		Config->errorsmspath = Config->sentsmspath;
	} else {
		error = SMSD_Check_Dir(Config, Config->errorsmspath, "errorsmspath");
		if (error != ERR_NONE) {
			return error;
		}
	}
	SMSD_Log(DEBUG_NOTICE, Config, "SMS with errors moved to \"%s\"",Config->errorsmspath);

	return ERR_NONE;
}

GSM_SMSDService SMSDFiles = {
	NONEFUNCTION,		/* Init                 */
	SMSDFiles_Free,		/* Free                 */
	NONEFUNCTION,		/* InitAfterConnect     */
	SMSDFiles_SaveInboxSMS,
	SMSDFiles_FindOutboxSMS,
	SMSDFiles_MoveSMS,
	SMSDFiles_CreateOutboxSMS,
	SMSDFiles_AddSentSMSInfo,
	NOTIMPLEMENTED,		/* RefreshSendStatus    */
	SMSDFiles_UpdateRetries,	/* UpdateRetries        */
	NOTIMPLEMENTED,		/* RefreshPhoneStatus   */
	SMSDFiles_ReadConfiguration
};

/* How should editor handle tabs in this file? Add editor commands here.
 * vim: noexpandtab sw=8 ts=8 sts=8:
 */
