/*
 * This file is part of the ESO C Extension Library
 * Copyright (C) 2001-2026 European Southern Observatory
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, see <https://www.gnu.org/licenses/>.
 */

#ifndef CX_VERSION_H
#define CX_VERSION_H

/* clang-format off */
#define CX_VERSION_STRING "1.3.2"

#define CX_VERSION_MAJOR  1
#define CX_VERSION_MINOR  3
#define CX_VERSION_MICRO  2

#define CX_BINARY_VERSION 66306
/* clang-format on */

#define CX_VERSION(major, minor, micro) \
    (((major) * 65536) + ((minor) * 256) + (micro))

#endif /* CX_VERSION_H */
