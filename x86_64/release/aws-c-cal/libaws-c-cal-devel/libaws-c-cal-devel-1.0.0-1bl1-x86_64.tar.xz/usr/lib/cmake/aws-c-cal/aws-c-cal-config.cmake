include(CMakeFindDependencyMacro)

find_dependency(aws-c-common)

if (NOT OFF AND (OFF OR (NOT WIN32 AND NOT APPLE)))
    if (ON AND NOT ANDROID)
        # aws-c-cal has been built with a dependency on OpenSSL::Crypto,
        # therefore consumers of this library have a dependency on OpenSSL and must have it found
        find_dependency(OpenSSL REQUIRED)
        find_dependency(Threads REQUIRED)
    else()
        list(APPEND CMAKE_MODULE_PATH "${CMAKE_CURRENT_LIST_DIR}/modules")
        find_dependency(crypto)
    endif()
endif()

include(${CMAKE_CURRENT_LIST_DIR}/aws-c-cal-targets.cmake)
