#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "simdutf::simdutf" for configuration "RelWithDebInfo"
set_property(TARGET simdutf::simdutf APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(simdutf::simdutf PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libsimdutf.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygsimdutf-37.dll"
  )

list(APPEND _cmake_import_check_targets simdutf::simdutf )
list(APPEND _cmake_import_check_files_for_simdutf::simdutf "${_IMPORT_PREFIX}/lib/libsimdutf.dll.a" "${_IMPORT_PREFIX}/bin/cygsimdutf-37.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
