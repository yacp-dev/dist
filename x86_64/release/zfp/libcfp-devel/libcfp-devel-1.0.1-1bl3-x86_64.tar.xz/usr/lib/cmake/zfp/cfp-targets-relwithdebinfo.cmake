#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "zfp::cfp" for configuration "RelWithDebInfo"
set_property(TARGET zfp::cfp APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(zfp::cfp PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libcfp.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygcfp-1.dll"
  )

list(APPEND _cmake_import_check_targets zfp::cfp )
list(APPEND _cmake_import_check_files_for_zfp::cfp "${_IMPORT_PREFIX}/lib/libcfp.dll.a" "${_IMPORT_PREFIX}/bin/cygcfp-1.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
