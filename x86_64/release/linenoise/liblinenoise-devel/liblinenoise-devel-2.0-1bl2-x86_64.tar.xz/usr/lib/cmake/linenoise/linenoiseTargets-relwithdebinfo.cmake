#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "linenoise::linenoise" for configuration "RelWithDebInfo"
set_property(TARGET linenoise::linenoise APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(linenoise::linenoise PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/liblinenoise.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cyglinenoise-0.dll"
  )

list(APPEND _cmake_import_check_targets linenoise::linenoise )
list(APPEND _cmake_import_check_files_for_linenoise::linenoise "${_IMPORT_PREFIX}/lib/liblinenoise.dll.a" "${_IMPORT_PREFIX}/bin/cyglinenoise-0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
