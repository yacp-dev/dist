/*
 * Author Jerry Lundström <jerry@dns-oarc.net>
 * Copyright (c) 2019-2026 OARC, Inc.
 * All rights reserved.
 *
 * This file is part of the dnswire library.
 *
 * dnswire library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * dnswire library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with dnswire library.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef __dnswire_h_trace
#define __dnswire_h_trace 1

#if 0
#define DNSWIRE_TRACE 1

#include <stdio.h>
#include <ctype.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

const char* __printable_string(const uint8_t* data, size_t len);
#define __trace(x...)                                \
    fprintf(stderr, "dnswire %s(): ", __func__); \
    fprintf(stderr, x);                            \
    fprintf(stderr, "\n"); \
    fflush(stderr);

#ifdef __cplusplus
}
#endif

#else
#define __trace(x...)
#define __printable_string(x...)
#endif

#endif
