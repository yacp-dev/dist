#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "BML::bml" for configuration "RelWithDebInfo"
set_property(TARGET BML::bml APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(BML::bml PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libbml.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygbml-2.4.0.dll"
  )

list(APPEND _cmake_import_check_targets BML::bml )
list(APPEND _cmake_import_check_files_for_BML::bml "${_IMPORT_PREFIX}/lib/libbml.dll.a" "${_IMPORT_PREFIX}/bin/cygbml-2.4.0.dll" )

# Import target "BML::bml_fortran" for configuration "RelWithDebInfo"
set_property(TARGET BML::bml_fortran APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(BML::bml_fortran PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libbml_fortran.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygbml_fortran-2.4.0.dll"
  )

list(APPEND _cmake_import_check_targets BML::bml_fortran )
list(APPEND _cmake_import_check_files_for_BML::bml_fortran "${_IMPORT_PREFIX}/lib/libbml_fortran.dll.a" "${_IMPORT_PREFIX}/bin/cygbml_fortran-2.4.0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
