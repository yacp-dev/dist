#ifndef SPATIALAUDIO_HRTF_SOFA_HRTF_H
#define SPATIALAUDIO_HRTF_SOFA_HRTF_H

#include "hrtf.h"

#if SPATIALAUDIO_SUPPORTS_SOFA

#include <string>

#include <mysofa.h>

namespace spaudio {

    class SPAUDIO_API SOFA_HRTF : public HRTF
    {
    public:
        SOFA_HRTF(std::string path, unsigned i_sampleRate);
        ~SOFA_HRTF();
        bool get(float f_azimuth, float f_elevation, float** pfHRTF);

    private:
        struct MYSOFA_EASY* hrtf;

        unsigned i_filterExtraLength;
        int i_internalLength;
    };

} // namespace spaudio

#endif

#endif // SPATIALAUDIO_HRTF_SOFA_HRTF_H
