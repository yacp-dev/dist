#pragma once
/*
 *  $Id: gwyddion.h 30298 2026-08-10 18:35:22Z yeti-dn $
 *  Copyright (C) 2003-2026 David Necas (Yeti), Petr Klapetek.
 *  E-mail: yeti@gwyddion.net, klapetek@gwyddion.net.
 *
 *  This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public
 *  License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any
 *  later version.
 *
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 *  details.
 *
 *  You should have received a copy of the GNU General Public License along with this program; if not, write to the
 *  Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#ifndef __GWY_GWYDDION_H__
#define __GWY_GWYDDION_H__

#include <gwyconfig3.h>

#include <libgwyddion/arithmetic.h>
#include <libgwyddion/brick.h>
#include <libgwyddion/cdline.h>
#include <libgwyddion/correct.h>
#include <libgwyddion/correlation.h>
#include <libgwyddion/cwt.h>
#include <libgwyddion/deserialize.h>
#include <libgwyddion/derived-units.h>
#include <libgwyddion/dict.h>
#include <libgwyddion/distance-transform.h>
#include <libgwyddion/dwt.h>
#include <libgwyddion/enum.h>
#include <libgwyddion/enums.h>
#include <libgwyddion/error-list.h>
#include <libgwyddion/expr.h>
#include <libgwyddion/extend.h>
#include <libgwyddion/field.h>
#include <libgwyddion/filters.h>
#include <libgwyddion/fractals.h>
#include <libgwyddion/gl-material.h>
#include <libgwyddion/gradient.h>
#include <libgwyddion/grains.h>
#include <libgwyddion/grain-quantities.h>
#include <libgwyddion/grain-value.h>
#include <libgwyddion/gwyfdcurvepreset.h>
#include <libgwyddion/nl-fitter.h>
#include <libgwyddion/gwynlfitpreset.h>
#include <libgwyddion/rand-gen-set.h>
#include <libgwyddion/hough.h>
#include <libgwyddion/interpolation.h>
#include <libgwyddion/inttrans.h>
#include <libgwyddion/inventory.h>
#include <libgwyddion/lawn.h>
#include <libgwyddion/level.h>
#include <libgwyddion/line.h>
#include <libgwyddion/linestats.h>
#include <libgwyddion/macros.h>
#include <libgwyddion/math.h>
#include <libgwyddion/mfm.h>
#include <libgwyddion/nield.h>
#include <libgwyddion/peaks.h>
#include <libgwyddion/resource.h>
#include <libgwyddion/results.h>
#include <libgwyddion/rgba.h>
#include <libgwyddion/scatter.h>
#include <libgwyddion/selection-axis.h>
#include <libgwyddion/selection-ellipse.h>
#include <libgwyddion/selection.h>
#include <libgwyddion/selection-lattice.h>
#include <libgwyddion/selection-line.h>
#include <libgwyddion/selection-path.h>
#include <libgwyddion/selection-point.h>
#include <libgwyddion/selection-quad.h>
#include <libgwyddion/selection-range.h>
#include <libgwyddion/selection-rectangle.h>
#include <libgwyddion/serializable-boxed.h>
#include <libgwyddion/serializable.h>
#include <libgwyddion/serializable-utils.h>
#include <libgwyddion/serialize.h>
#include <libgwyddion/shape-fit-preset.h>
#include <libgwyddion/shaped.h>
#include <libgwyddion/simplefft.h>
#include <libgwyddion/spectra.h>
#include <libgwyddion/spline.h>
#include <libgwyddion/stats.h>
#include <libgwyddion/string-list.h>
#include <libgwyddion/synth.h>
#include <libgwyddion/threads.h>
#include <libgwyddion/tip.h>
#include <libgwyddion/tip-model.h>
#include <libgwyddion/triangulation.h>
#include <libgwyddion/types.h>
#include <libgwyddion/unit.h>
#include <libgwyddion/utils.h>
#include <libgwyddion/value-format.h>
#include <libgwyddion/version.h>
#include <libgwyddion/watershed.h>
#include <libgwyddion/xy.h>
#include <libgwyddion/xyz.h>

G_BEGIN_DECLS

void gwy_init           (void);
void gwy_load_resources (void);
void gwy_tune_algorithms(const gchar *key,
                         const gchar *value);

G_END_DECLS

#endif

/* vim: set cin columns=120 tw=118 et ts=4 sw=4 cino=>1s,e0,n0,f0,{0,}0,^0,\:1s,=0,g1s,h0,t0,+1s,c3,(0,u0 : */
