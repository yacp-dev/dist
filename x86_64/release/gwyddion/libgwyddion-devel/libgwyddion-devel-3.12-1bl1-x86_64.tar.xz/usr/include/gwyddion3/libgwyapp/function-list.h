#pragma once
/*
 *  $Id: function-list.h 30091 2026-06-19 13:11:33Z yeti-dn $
 *  Copyright (C) 2026 David Necas (Yeti).
 *  E-mail: yeti@gwyddion.net.
 *
 *  This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public
 *  License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any
 *  later version.
 *
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 *  details.
 *
 *  You should have received a copy of the GNU General Public License along with this program; if not, write to the
 *  Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#ifndef __GWYAPP_FUNCTION_LIST_H__
#define __GWYAPP_FUNCTION_LIST_H__

#include <gtk/gtk.h>

G_BEGIN_DECLS

#define GWY_TYPE_FUNCTION_LIST            (gwy_function_list_get_type())
#define GWY_FUNCTION_LIST(obj)            (G_TYPE_CHECK_INSTANCE_CAST((obj), GWY_TYPE_FUNCTION_LIST, GwyFunctionList))
#define GWY_FUNCTION_LIST_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST((klass), GWY_TYPE_FUNCTION_LIST, GwyFunctionListClass))
#define GWY_IS_FUNCTION_LIST(obj)         (G_TYPE_CHECK_INSTANCE_TYPE((obj), GWY_TYPE_FUNCTION_LIST))
#define GWY_IS_FUNCTION_LIST_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE((klass), GWY_TYPE_FUNCTION_LIST))
#define GWY_FUNCTION_LIST_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS((obj), GWY_TYPE_FUNCTION_LIST, GwyFunctionListClass))

typedef struct _GwyFunctionList        GwyFunctionList;
typedef struct _GwyFunctionListClass   GwyFunctionListClass;
typedef struct _GwyFunctionListPrivate GwyFunctionListPrivate;

struct _GwyFunctionList {
    GtkTreeView parent_instance;
    GwyFunctionListPrivate *priv;
};

struct _GwyFunctionListClass {
    GtkTreeViewClass parent_class;

    /*<private>*/
    void (*reserved1)(void);
    void (*reserved2)(void);
    void (*reserved3)(void);
    void (*reserved4)(void);
};

GType        gwy_function_list_get_type               (void)                    G_GNUC_CONST;
GtkWidget*   gwy_function_list_new                    (const gchar *kind);
const gchar* gwy_function_list_get_kind               (GwyFunctionList *flist);
void         gwy_function_list_set_kind               (GwyFunctionList *flist,
                                                       const gchar *kind);
const gchar* gwy_function_list_get_selected           (GwyFunctionList *flist);
gboolean     gwy_function_list_select                 (GwyFunctionList *flist,
                                                       const gchar *name,
                                                       gboolean scroll_to);
void         gwy_function_list_refresh_row            (GwyFunctionList *flist,
                                                       const gchar *name);
void         gwy_function_list_set_show_remaning_tools(GwyFunctionList *flist,
                                                       gboolean setting);
gboolean     gwy_function_list_get_show_remaning_tools(GwyFunctionList *flist);

G_END_DECLS

#endif

/* vim: set cin columns=120 tw=118 et ts=4 sw=4 cino=>1s,e0,n0,f0,{0,}0,^0,\:1s,=0,g1s,h0,t0,+1s,c3,(0,u0 : */
