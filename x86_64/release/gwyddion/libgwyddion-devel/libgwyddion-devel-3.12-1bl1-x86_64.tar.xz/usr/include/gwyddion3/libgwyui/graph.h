#pragma once
/*
 *  $Id: graph.h 30343 2026-08-18 17:03:44Z yeti-dn $
 *  Copyright (C) 2003-2024 David Necas (Yeti), Petr Klapetek.
 *  E-mail: yeti@gwyddion.net, klapetek@gwyddion.net.
 *
 *  This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public
 *  License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any
 *  later version.
 *
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 *  details.
 *
 *  You should have received a copy of the GNU General Public License along with this program; if not, write to the
 *  Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#ifndef __GWYUI_GRAPH_H__
#define __GWYUI_GRAPH_H__

#include <gdk-pixbuf/gdk-pixbuf.h>
#include <gtk/gtk.h>

#include <libgwyui/graph-model.h>
#include <libgwyui/graph-axis.h>
#include <libgwyui/graph-key.h>
#include <libgwyui/graph-corner.h>
#include <libgwyui/graph-area.h>

G_BEGIN_DECLS

#define GWY_TYPE_GRAPH            (gwy_graph_get_type())
#define GWY_GRAPH(obj)            (G_TYPE_CHECK_INSTANCE_CAST((obj), GWY_TYPE_GRAPH, GwyGraph))
#define GWY_GRAPH_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST((klass), GWY_TYPE_GRAPH, GwyGraphClass))
#define GWY_IS_GRAPH(obj)         (G_TYPE_CHECK_INSTANCE_TYPE((obj), GWY_TYPE_GRAPH))
#define GWY_IS_GRAPH_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE((klass), GWY_TYPE_GRAPH))
#define GWY_GRAPH_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS((obj), GWY_TYPE_GRAPH, GwyGraphClass))

typedef struct _GwyGraph             GwyGraph;
typedef struct _GwyGraphClass        GwyGraphClass;
typedef struct _GwyGraphPrivate      GwyGraphPrivate;

struct _GwyGraph {
    GtkGrid parent_instance;
    GwyGraphPrivate *priv;
};

struct _GwyGraphClass {
    GtkGridClass parent_class;

    void (*reserved1)(void);
    void (*reserved2)(void);
    void (*reserved3)(void);
    void (*reserved4)(void);
};

GType              gwy_graph_get_type         (void)                       G_GNUC_CONST;
GtkWidget*         gwy_graph_new              (GwyGraphModel *gmodel);
GtkWidget*         gwy_graph_get_axis         (GwyGraph *graph,
                                               GtkPositionType edge);
void               gwy_graph_set_axis_visible (GwyGraph *graph,
                                               GtkPositionType edge,
                                               gboolean is_visible);
void               gwy_graph_set_axes_visible (GwyGraph *graph,
                                               gboolean is_visible);
GtkWidget*         gwy_graph_get_area         (GwyGraph *graph);
void               gwy_graph_set_model        (GwyGraph *graph,
                                               GwyGraphModel *gmodel);
GwyGraphModel*     gwy_graph_get_model        (GwyGraph *graph);
void               gwy_graph_set_status       (GwyGraph *graph,
                                               GwyGraphStatusType status);
GwyGraphStatusType gwy_graph_get_status       (GwyGraph *graph);
void               gwy_graph_enable_user_input(GwyGraph *graph,
                                               gboolean enable);

G_END_DECLS

#endif

/* vim: set cin columns=120 tw=118 et ts=4 sw=4 cino=>1s,e0,n0,f0,{0,}0,^0,\:1s,=0,g1s,h0,t0,+1s,c3,(0,u0 : */
