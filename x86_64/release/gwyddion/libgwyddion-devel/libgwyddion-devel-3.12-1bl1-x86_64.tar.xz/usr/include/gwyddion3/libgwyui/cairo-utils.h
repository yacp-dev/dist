#pragma once
/*
 *  $Id: cairo-utils.h 30146 2026-06-25 12:51:18Z yeti-dn $
 *  Copyright (C) 2012-2026 David Nečas (Yeti).
 *  E-mail: yeti@gwyddion.net.
 *
 *  This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public
 *  License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any
 *  later version.
 *
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 *  details.
 *
 *  You should have received a copy of the GNU General Public License along with this program; if not, write to the
 *  Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#ifndef __GWYUI_CAIRO_UTILS_H__
#define __GWYUI_CAIRO_UTILS_H__

#include <cairo/cairo.h>
#include <gtk/gtk.h>

#include "libgwyddion/xy.h"
#include "libgwyddion/rgba.h"
#include "libgwyddion/gradient.h"

G_BEGIN_DECLS

typedef enum {
   GWY_SYMBOL_SQUARE                = 0,
   GWY_SYMBOL_CROSS                 = 1,
   GWY_SYMBOL_CIRCLE                = 2,
   GWY_SYMBOL_STAR                  = 3,
   GWY_SYMBOL_TIMES                 = 4,
   GWY_SYMBOL_TRIANGLE_UP           = 5,
   GWY_SYMBOL_TRIANGLE_DOWN         = 6,
   GWY_SYMBOL_DIAMOND               = 7,
   GWY_SYMBOL_FILLED_SQUARE         = 8,
   GWY_SYMBOL_DISC                  = 9,
   GWY_SYMBOL_FILLED_CIRCLE         = GWY_SYMBOL_DISC,
   GWY_SYMBOL_FILLED_TRIANGLE_UP    = 10,
   GWY_SYMBOL_FILLED_TRIANGLE_DOWN  = 11,
   GWY_SYMBOL_FILLED_DIAMOND        = 12,
   GWY_SYMBOL_TRIANGLE_LEFT         = 13,
   GWY_SYMBOL_FILLED_TRIANGLE_LEFT  = 14,
   GWY_SYMBOL_TRIANGLE_RIGHT        = 15,
   GWY_SYMBOL_FILLED_TRIANGLE_RIGHT = 16,
   GWY_SYMBOL_ASTERISK              = 17
} GwySymbolType;

typedef enum {
    GWY_LINE_SOLID       = 0,
    GWY_LINE_DASH        = 1,
    GWY_LINE_DASH_SPARSE = 2,
    GWY_LINE_DASH_DENSE  = 3,
    GWY_LINE_DOT         = 4,
    GWY_LINE_DOT_SPARSE  = 5,
    GWY_LINE_DASH_DOT    = 6,
} GwyLineStyle;

void             gwy_cairo_set_source_rgba        (cairo_t *cr,
                                                   const GwyRGBA *rgba);
cairo_pattern_t* gwy_cairo_pattern_create_gradient(GwyGradient *gradient,
                                                   GtkPositionType towards,
                                                   gboolean use_alpha)           G_GNUC_MALLOC;
void             gwy_cairo_checker_rectangle      (cairo_t *cr,
                                                   const GwyRGBA *even,
                                                   const GwyRGBA *odd,
                                                   gint width,
                                                   gint height,
                                                   gint size);
void             gwy_cairo_line                   (cairo_t *cr,
                                                   gdouble xfrom,
                                                   gdouble yfrom,
                                                   gdouble xto,
                                                   gdouble yto);
void             gwy_cairo_ellipse                (cairo_t *cr,
                                                   gdouble x,
                                                   gdouble y,
                                                   gdouble xr,
                                                   gdouble yr);
void             gwy_cairo_cross                  (cairo_t *cr,
                                                   gdouble x,
                                                   gdouble y,
                                                   gdouble halfside);
void             gwy_cairo_times                  (cairo_t *cr,
                                                   gdouble x,
                                                   gdouble y,
                                                   gdouble halfside);
void             gwy_cairo_asterisk               (cairo_t *cr,
                                                   gdouble x,
                                                   gdouble y,
                                                   gdouble halfside);
void             gwy_cairo_square                 (cairo_t *cr,
                                                   gdouble x,
                                                   gdouble y,
                                                   gdouble halfside);
void             gwy_cairo_diamond                (cairo_t *cr,
                                                   gdouble x,
                                                   gdouble y,
                                                   gdouble halfside);
void             gwy_cairo_triangle_up            (cairo_t *cr,
                                                   gdouble x,
                                                   gdouble y,
                                                   gdouble halfside);
void             gwy_cairo_triangle_down          (cairo_t *cr,
                                                   gdouble x,
                                                   gdouble y,
                                                   gdouble halfside);
void             gwy_cairo_triangle_left          (cairo_t *cr,
                                                   gdouble x,
                                                   gdouble y,
                                                   gdouble halfside);
void             gwy_cairo_triangle_right         (cairo_t *cr,
                                                   gdouble x,
                                                   gdouble y,
                                                   gdouble halfside);
void             gwy_cairo_draw_symbol            (cairo_t *cr,
                                                   gdouble x,
                                                   gdouble y,
                                                   GwySymbolType symbol_type,
                                                   gdouble size,
                                                   const GwyRGBA *color);
void             gwy_cairo_draw_symbols           (cairo_t *cr,
                                                   const GwyXY *coords,
                                                   guint n,
                                                   GwySymbolType symbol_type,
                                                   gdouble size,
                                                   const GwyRGBA *color);
void             gwy_cairo_draw_line              (cairo_t *cr,
                                                   gdouble x_from,
                                                   gdouble y_from,
                                                   gdouble x_to,
                                                   gdouble y_to,
                                                   GwyLineStyle line_style,
                                                   gdouble width,
                                                   const GwyRGBA *color);
void             gwy_cairo_region_add_line        (cairo_region_t *region,
                                                   gdouble xfrom,
                                                   gdouble yfrom,
                                                   gdouble xto,
                                                   gdouble yto,
                                                   gdouble lw);
void             gwy_cairo_region_add_crectangle  (cairo_region_t *region,
                                                   gdouble xc,
                                                   gdouble yc,
                                                   gdouble xr,
                                                   gdouble yr,
                                                   gdouble lw);
void             gwy_cairo_region_add_erectangle  (cairo_region_t *region,
                                                   gdouble x1,
                                                   gdouble y1,
                                                   gdouble x2,
                                                   gdouble y2,
                                                   gdouble lw);
void             gwy_cairo_region_add_ellipse     (cairo_region_t *region,
                                                   gdouble xc,
                                                   gdouble yc,
                                                   gdouble xr,
                                                   gdouble yr,
                                                   gdouble lw);
void             gwy_cairo_region_add_layout      (cairo_region_t *region,
                                                   PangoLayout *layout,
                                                   gdouble x,
                                                   gdouble y);
void             gwy_cairo_draw_or_add_thin_line  (cairo_t *cr,
                                                   cairo_region_t *region,
                                                   gdouble xfrom,
                                                   gdouble yfrom,
                                                   gdouble xto,
                                                   gdouble yto);
void             gwy_cairo_draw_or_add_layout     (cairo_t *cr,
                                                   cairo_region_t *region,
                                                   PangoLayout *layout,
                                                   gdouble x,
                                                   gdouble y);

G_END_DECLS

#endif

/* vim: set cin columns=120 tw=118 et ts=4 sw=4 cino=>1s,e0,n0,f0,{0,}0,^0,\:1s,=0,g1s,h0,t0,+1s,c3,(0,u0 : */
