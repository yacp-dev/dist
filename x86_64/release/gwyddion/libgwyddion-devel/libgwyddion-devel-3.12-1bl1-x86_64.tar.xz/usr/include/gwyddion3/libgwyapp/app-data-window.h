#pragma once
/*
 *  $Id: app-data-window.h 30091 2026-06-19 13:11:33Z yeti-dn $
 *  Copyright (C) 2026 David Necas (Yeti)
 *  E-mail: yeti@gwyddion.net
 *
 *  This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public
 *  License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any
 *  later version.
 *
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 *  details.
 *
 *  You should have received a copy of the GNU General Public License along with this program; if not, write to the
 *  Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#ifndef __GWYAPP_APP_DATA_WINDOW_H__
#define __GWYAPP_APP_DATA_WINDOW_H__

#include <libgwyapp/file.h>

G_BEGIN_DECLS

#define GWY_TYPE_APP_DATA_WINDOW               (gwy_app_data_window_get_type())
#define GWY_APP_DATA_WINDOW(obj)               (G_TYPE_CHECK_INSTANCE_CAST((obj), GWY_TYPE_APP_DATA_WINDOW, GwyAppDataWindow))
#define GWY_IS_APP_DATA_WINDOW(obj)            (G_TYPE_CHECK_INSTANCE_TYPE((obj), GWY_TYPE_APP_DATA_WINDOW))
#define GWY_APP_DATA_WINDOW_GET_INTERFACE(obj) (G_TYPE_INSTANCE_GET_INTERFACE((obj), GWY_TYPE_APP_DATA_WINDOW, GwyAppDataWindowInterface))

typedef struct _GwyAppDataWindowInterface GwyAppDataWindowInterface;
typedef struct _GwyAppDataWindow          GwyAppDataWindow;           // dummy

struct _GwyAppDataWindowInterface {
    /*<private>*/
    GTypeInterface g_interface;

    /* virtual table */
    /*<public>*/
    GwyFile*     (*get_file)      (GwyAppDataWindow *app_data_window);
    GwyDataKind  (*get_data_kind) (GwyAppDataWindow *app_data_window);
    gint         (*get_id)        (GwyAppDataWindow *app_data_window);
    const gchar* (*get_accel_root)(GwyAppDataWindow *app_data_window);

    /*<private>*/
    void (*reserved1)(void);
    void (*reserved2)(void);
    void (*reserved3)(void);
    void (*reserved4)(void);
    void (*reserved5)(void);
};

GType        gwy_app_data_window_get_type      (void)                      G_GNUC_CONST;
GwyFile*     gwy_app_data_window_get_file      (GwyAppDataWindow *window);
GwyDataKind  gwy_app_data_window_get_data_kind (GwyAppDataWindow *window);
gint         gwy_app_data_window_get_id        (GwyAppDataWindow *window);
const gchar* gwy_app_data_window_get_accel_root(GwyAppDataWindow *window);

G_END_DECLS

#endif

/* vim: set cin columns=120 tw=118 et ts=4 sw=4 cino=>1s,e0,n0,f0,{0,}0,^0,\:1s,=0,g1s,h0,t0,+1s,c3,(0,u0 : */
