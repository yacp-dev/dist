#pragma once
/*
 *  $Id: rect-selection-labels.h 30254 2026-08-05 07:38:57Z yeti-dn $
 *  Copyright (C) 2006-2026 David Necas (Yeti).
 *  E-mail: yeti@gwyddion.net.
 *
 *  This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public
 *  License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any
 *  later version.
 *
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 *  details.
 *
 *  You should have received a copy of the GNU General Public License along with this program; if not, write to the
 *  Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#ifndef __GWYAPP_RECT_SELECTION_LABELS_H__
#define __GWYAPP_RECT_SELECTION_LABELS_H__

#include <gtk/gtk.h>
#include <libgwyddion/selection.h>
#include <libgwyddion/field.h>

G_BEGIN_DECLS

typedef struct _GwyRectSelectionLabels GwyRectSelectionLabels;

// GUI helper. Useful thanks to the ubiquity of rectangular selections. It should probably be a widget. We may also
// want a treeview widget showing line (point) selection coordinates because it is quite common.
GwyRectSelectionLabels* gwy_rect_selection_labels_new          (gboolean none_is_full,
                                                                GCallback callback,
                                                                gpointer cbdata);
GtkWidget*              gwy_rect_selection_labels_get_table    (GwyRectSelectionLabels *rlabels);
void                    gwy_rect_selection_labels_select       (GwyRectSelectionLabels *rlabels,
                                                                GwySelection *selection,
                                                                GwyField *field);
gboolean                gwy_rect_selection_labels_fill         (GwyRectSelectionLabels *rlabels,
                                                                GwySelection *selection,
                                                                GwyField *field,
                                                                gdouble *selreal,
                                                                gint *selpix);

G_END_DECLS

#endif

/* vim: set cin columns=120 tw=118 et ts=4 sw=4 cino=>1s,e0,n0,f0,{0,}0,^0,\:1s,=0,g1s,h0,t0,+1s,c3,(0,u0 : */
