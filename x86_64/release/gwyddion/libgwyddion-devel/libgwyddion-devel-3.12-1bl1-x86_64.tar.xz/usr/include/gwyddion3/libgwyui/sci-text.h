#pragma once
/*
 *  $Id: sci-text.h 28348 2025-08-11 16:29:06Z yeti-dn $
 *  Copyright (C) 2003-2024 David Necas (Yeti), Petr Klapetek.
 *  E-mail: yeti@gwyddion.net, klapetek@gwyddion.net.
 *
 *  This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public
 *  License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any
 *  later version.
 *
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 *  details.
 *
 *  You should have received a copy of the GNU General Public License along with this program; if not, write to the
 *  Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#ifndef __GWYUI_SCI_TEXT_H__
#define __GWYUI_SCI_TEXT_H__

#include <gtk/gtk.h>

G_BEGIN_DECLS

#define GWY_TYPE_SCI_TEXT            (gwy_sci_text_get_type())
#define GWY_SCI_TEXT(obj)            (G_TYPE_CHECK_INSTANCE_CAST((obj), GWY_TYPE_SCI_TEXT, GwySciText))
#define GWY_SCI_TEXT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST((klass), GWY_TYPE_SCI_TEXT, GwySciTextClass))
#define GWY_IS_SCI_TEXT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE((obj), GWY_TYPE_SCI_TEXT))
#define GWY_IS_SCI_TEXT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE((klass), GWY_TYPE_SCI_TEXT))
#define GWY_SCI_TEXT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS((obj), GWY_TYPE_SCI_TEXT, GwySciTextClass))

typedef struct _GwySciText             GwySciText;
typedef struct _GwySciTextClass        GwySciTextClass;
typedef struct _GwySciTextPrivate      GwySciTextPrivate;

struct _GwySciText {
    GtkBox box;
    GwySciTextPrivate *priv;
};

struct _GwySciTextClass {
    GtkBoxClass parent_class;

    /* Signals */
    void (*edited)(GwySciText *sci_text);

    void (*reserved1)(void);
    void (*reserved2)(void);
    void (*reserved3)(void);
    void (*reserved4)(void);
};

GType      gwy_sci_text_get_type       (void)                  G_GNUC_CONST;
GtkWidget* gwy_sci_text_new            (void);
gchar*     gwy_sci_text_get_markup     (GwySciText *scitext);
void       gwy_sci_text_set_markup     (GwySciText *scitext,
                                        const gchar *markup);
gboolean   gwy_sci_text_get_has_preview(GwySciText *scitext);
void       gwy_sci_text_set_has_preview(GwySciText *scitext,
                                        gboolean has_preview);
GtkWidget* gwy_sci_text_get_entry      (GwySciText *scitext);

G_END_DECLS

#endif

/* vim: set cin columns=120 tw=118 et ts=4 sw=4 cino=>1s,e0,n0,f0,{0,}0,^0,\:1s,=0,g1s,h0,t0,+1s,c3,(0,u0 : */
