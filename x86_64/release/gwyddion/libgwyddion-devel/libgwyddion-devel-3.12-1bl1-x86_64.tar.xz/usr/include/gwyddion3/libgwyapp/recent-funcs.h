#pragma once
/*
 *  $Id: recent-funcs.h 30092 2026-06-20 21:38:03Z yeti-dn $
 *  Copyright (C) 2026 David Necas (Yeti).
 *  E-mail: yeti@gwyddion.net.
 *
 *  This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public
 *  License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any
 *  later version.
 *
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 *  details.
 *
 *  You should have received a copy of the GNU General Public License along with this program; if not, write to the
 *  Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#ifndef __GWYAPP_RECENT_FUNCS_H__
#define __GWYAPP_RECENT_FUNCS_H__

#include <glib.h>

G_BEGIN_DECLS

void     gwy_recent_funcs_record_use(const gchar *kind,
                                     const gchar *name);
guint    gwy_recent_funcs_get_head  (const gchar *kind,
                                     const gchar **names,
                                     guint n);
gboolean gwy_recent_funcs_load      (const gchar *filename,
                                     GError **error);
gboolean gwy_recent_funcs_save      (const gchar *filename,
                                     GError **error);

G_END_DECLS

#endif

/* vim: set cin columns=120 tw=118 et ts=4 sw=4 cino=>1s,e0,n0,f0,{0,}0,^0,\:1s,=0,g1s,h0,t0,+1s,c3,(0,u0 : */
