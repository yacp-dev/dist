#pragma once
/*
 *  $Id: shape-fit-preset.h 30185 2026-07-16 17:30:20Z yeti-dn $
 *  Copyright (C) 2016-2022 David Necas (Yeti).
 *  E-mail: yeti@gwyddion.net.
 *
 *  This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public
 *  License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any
 *  later version.
 *
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 *  details.
 *
 *  You should have received a copy of the GNU General Public License along with this program; if not, write to the
 *  Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#ifndef __GWY_SHAPE_FIT_PRESET_H__
#define __GWY_SHAPE_FIT_PRESET_H__

#include <libgwyddion/math.h>
#include <libgwyddion/unit.h>
#include <libgwyddion/nl-fitter.h>
#include <libgwyddion/resource.h>
#include <libgwyddion/inventory.h>

G_BEGIN_DECLS

#define GWY_TYPE_SHAPE_FIT_PRESET             (gwy_shape_fit_preset_get_type())
#define GWY_SHAPE_FIT_PRESET(obj)             (G_TYPE_CHECK_INSTANCE_CAST((obj), GWY_TYPE_SHAPE_FIT_PRESET, GwyShapeFitPreset))
#define GWY_SHAPE_FIT_PRESET_CLASS(klass)     (G_TYPE_CHECK_CLASS_CAST((klass), GWY_TYPE_SHAPE_FIT_PRESET, GwyShapeFitPresetClass))
#define GWY_IS_SHAPE_FIT_PRESET(obj)          (G_TYPE_CHECK_INSTANCE_TYPE((obj), GWY_TYPE_SHAPE_FIT_PRESET))
#define GWY_IS_SHAPE_FIT_PRESET_CLASS(klass)  (G_TYPE_CHECK_CLASS_TYPE((klass), GWY_TYPE_SHAPE_FIT_PRESET))
#define GWY_SHAPE_FIT_PRESET_GET_CLASS(obj)   (G_TYPE_INSTANCE_GET_CLASS((obj), GWY_TYPE_SHAPE_FIT_PRESET, GwyShapeFitPresetClass))

typedef struct _GwyShapeFitPreset        GwyShapeFitPreset;
typedef struct _GwyShapeFitPresetClass   GwyShapeFitPresetClass;
typedef struct _GwyShapeFitPresetPrivate GwyShapeFitPresetPrivate;

struct _GwyShapeFitPreset {
    GwyResource parent_instance;
    GwyShapeFitPresetPrivate *priv;
};

struct _GwyShapeFitPresetClass {
    GwyResourceClass parent_class;
};

GwyInventory*      gwy_shape_fit_presets                         (void)                        G_GNUC_PURE;
GType              gwy_shape_fit_preset_get_type                 (void)                        G_GNUC_CONST;
gboolean           gwy_shape_fit_preset_needs_same_units         (GwyShapeFitPreset *preset);
guint              gwy_shape_fit_preset_get_n_params             (GwyShapeFitPreset *preset);
const gchar*       gwy_shape_fit_preset_get_param_name           (GwyShapeFitPreset *preset,
                                                                  guint i);
const gchar*       gwy_shape_fit_preset_get_param_description    (GwyShapeFitPreset *preset,
                                                                  guint i);
GwyNLFitParamFlags gwy_shape_fit_preset_get_param_flags          (GwyShapeFitPreset *preset,
                                                                  guint i);
GwyUnit*           gwy_shape_fit_preset_get_param_units          (GwyShapeFitPreset *preset,
                                                                  guint i,
                                                                  GwyUnit *unit_xy,
                                                                  GwyUnit *unit_z);
gint               gwy_shape_fit_preset_get_param_power_xy       (GwyShapeFitPreset *preset,
                                                                  guint i);
gint               gwy_shape_fit_preset_get_param_power_z        (GwyShapeFitPreset *preset,
                                                                  guint i);
guint              gwy_shape_fit_preset_get_n_secondary          (GwyShapeFitPreset *preset);
const gchar*       gwy_shape_fit_preset_get_secondary_name       (GwyShapeFitPreset *preset,
                                                                  guint i);
const gchar*       gwy_shape_fit_preset_get_secondary_description(GwyShapeFitPreset *preset,
                                                                  guint i);
GwyNLFitParamFlags gwy_shape_fit_preset_get_secondary_flags      (GwyShapeFitPreset *preset,
                                                                  guint i);
gdouble            gwy_shape_fit_preset_get_secondary_value      (GwyShapeFitPreset *preset,
                                                                  guint i,
                                                                  const gdouble *param);
gdouble            gwy_shape_fit_preset_get_secondary_error      (GwyShapeFitPreset *preset,
                                                                  guint i,
                                                                  const gdouble *param,
                                                                  const gdouble *error,
                                                                  const gdouble *correl);
GwyUnit*           gwy_shape_fit_preset_get_secondary_units      (GwyShapeFitPreset *preset,
                                                                  guint i,
                                                                  GwyUnit *unit_xy,
                                                                  GwyUnit *unit_z);
gint               gwy_shape_fit_preset_get_secondary_power_xy   (GwyShapeFitPreset *preset,
                                                                  guint i);
gint               gwy_shape_fit_preset_get_secondary_power_z    (GwyShapeFitPreset *preset,
                                                                  guint i);
void               gwy_shape_fit_preset_setup                    (GwyShapeFitPreset *preset,
                                                                  const GwyXYZ *points,
                                                                  gsize n,
                                                                  gdouble *params);
gboolean           gwy_shape_fit_preset_guess                    (GwyShapeFitPreset *preset,
                                                                  const GwyXYZ *points,
                                                                  gsize n,
                                                                  gdouble *params);
gdouble            gwy_shape_fit_preset_get_value                (GwyShapeFitPreset *preset,
                                                                  gdouble x,
                                                                  gdouble y,
                                                                  const gdouble *params);
void               gwy_shape_fit_preset_calculate_z              (GwyShapeFitPreset *preset,
                                                                  const GwyXYZ *points,
                                                                  gdouble *z,
                                                                  gsize n,
                                                                  const gdouble *params);
void               gwy_shape_fit_preset_calculate_xyz            (GwyShapeFitPreset *preset,
                                                                  GwyXYZ *points,
                                                                  gsize n,
                                                                  const gdouble *params);
GwyNLFitter*       gwy_shape_fit_preset_create_fitter            (GwyShapeFitPreset *preset);
GwyNLFitter*       gwy_shape_fit_preset_fit                      (GwyShapeFitPreset *preset,
                                                                  GwyNLFitter *fitter,
                                                                  const GwyXYZ *points,
                                                                  gsize n,
                                                                  gdouble *params,
                                                                  const gboolean *fixed_param,
                                                                  gdouble *rss);
GwyNLFitter*       gwy_shape_fit_preset_quick_fit                (GwyShapeFitPreset *preset,
                                                                  GwyNLFitter *fitter,
                                                                  const GwyXYZ *points,
                                                                  gsize n,
                                                                  gdouble *params,
                                                                  const gboolean *fixed_param,
                                                                  gdouble *rss);

G_END_DECLS

#endif

/* vim: set cin columns=120 tw=118 et ts=4 sw=4 cino=>1s,e0,n0,f0,{0,}0,^0,\:1s,=0,g1s,h0,t0,+1s,c3,(0,u0 : */
