#pragma once
/*
 *  $Id: tool.h 30407 2026-08-27 16:30:11Z yeti-dn $
 *  Copyright (C) 2026 David Necas (Yeti).
 *  E-mail: yeti@gwyddion.net.
 *
 *  This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public
 *  License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any
 *  later version.
 *
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 *  details.
 *
 *  You should have received a copy of the GNU General Public License along with this program; if not, write to the
 *  Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#ifndef __GWYAPP_TOOL_H__
#define __GWYAPP_TOOL_H__

#include <libgwyddion/value-format.h>
#include <libgwyddion/nield.h>
#include <libgwyui/data-view.h>
#include <libgwyapp/file.h>
#include <libgwyapp/params.h>

G_BEGIN_DECLS

typedef enum {
    GWY_TOOL_MODIFIES_DATA      = 1u << 0,
    GWY_TOOL_NEEDS_MASK         = 1u << 1,
    GWY_TOOL_HIDDEN_ACTIVE      = 1u << 2,
    GWY_TOOL_NO_LAYER           = 1u << 3,
    GWY_TOOL_PRIMARY_IS_PRIMARY = 1u << 4,
} GwyToolFlags;

typedef enum {
    GWY_TOOL_CHANGED_PRIMARY       = 1u << 0,
    GWY_TOOL_CHANGED_MASK          = 1u << 1,
    GWY_TOOL_CHANGED_PICTURE       = 1u << 2,
    GWY_TOOL_CHANGED_SELECTION     = 1u << 3,
    GWY_TOOL_CHANGED_FINISHED      = 1u << 4,
    GWY_TOOL_CHANGED_COLOR_MAPPING = 1u << 5,
    GWY_TOOL_CHANGED_MASK_COLOR    = 1u << 6,
} GwyToolChangedFlags;

typedef enum {
    GWY_HOLD_SELECTION_HOLD         = 1u << 0,
    GWY_HOLD_SELECTION_OVERWRITE    = 1u << 1,
    GWY_HOLD_SELECTION_CLEAR        = 1u << 2,
} GwyHoldSelectionFlags;

#define GWY_TYPE_TOOL             (gwy_tool_get_type())
#define GWY_TOOL(obj)             (G_TYPE_CHECK_INSTANCE_CAST((obj), GWY_TYPE_TOOL, GwyTool))
#define GWY_TOOL_CLASS(klass)     (G_TYPE_CHECK_CLASS_CAST((klass), GWY_TYPE_TOOL, GwyToolClass))
#define GWY_IS_TOOL(obj)          (G_TYPE_CHECK_INSTANCE_TYPE((obj), GWY_TYPE_TOOL))
#define GWY_IS_TOOL_CLASS(klass)  (G_TYPE_CHECK_CLASS_TYPE((klass), GWY_TYPE_TOOL))
#define GWY_TOOL_GET_CLASS(obj)   (G_TYPE_INSTANCE_GET_CLASS((obj), GWY_TYPE_TOOL, GwyToolClass))

typedef struct _GwyTool             GwyTool;
typedef struct _GwyToolClass        GwyToolClass;
typedef struct _GwyToolPrivate      GwyToolPrivate;
typedef struct _GwyToolClassPrivate GwyToolClassPrivate;

typedef void (*GwyToolFunc)(GwyTool *tool);
typedef void (*GwyToolSelectionFunc)(GwyTool *tool,
                                     gint hint);
typedef void (*GwyToolUpdateFunc)(GwyTool *tool,
                                  GwyToolChangedFlags changed);

struct _GwyTool {
    /*< private >*/
    GObject parent_instance;
    GwyToolPrivate *priv;
};

struct _GwyToolClass {
    /*< private >*/
    GObjectClass parent_class;
    GwyToolClassPrivate *priv;
};

GType           gwy_tool_get_type                 (void)                                    G_GNUC_CONST;
GwyToolClass*   gwy_register_tool                 (const gchar *name);
void            gwy_tool_class_set_info           (GwyToolClass *tool_class,
                                                   const gchar *icon_name,
                                                   const gchar *title,
                                                   const gchar *tooltip);
void            gwy_tool_class_set_basics         (GwyToolClass *tool_class,
                                                   GwyToolFlags flags,
                                                   gsize tool_data_size,
                                                   GwyParamDef *paramdef,
                                                   gint selection_max_objects);
void            gwy_tool_class_set_functions      (GwyToolClass *tool_class,
                                                   GwyToolFunc setup,
                                                   GwyToolFunc shutdown,
                                                   GwyToolFunc switch_data);
void            gwy_tool_class_set_selection_setup(GwyToolClass *tool_class,
                                                   GwyToolFunc setup_selection);
void            gwy_tool_class_set_updates        (GwyToolClass *tool_class,
                                                   GwyToolChangedFlags changes_mask,
                                                   GwyToolUpdateFunc update,
                                                   GwyToolSelectionFunc selection_changed);
void            gwy_tool_class_set_default_size   (GwyToolClass *tool_class,
                                                   gint width,
                                                   gint height);
void            gwy_tool_class_set_format_styles  (GwyToolClass *tool_class,
                                                   GwyUnitFormatStyle xystyle,
                                                   GwyUnitFormatStyle zstyle);
void            gwy_tool_class_set_data_kinds     (GwyToolClass *tool_class,
                                                   const GwyDataKind *data_kinds,
                                                   guint nkinds);
const gchar*    gwy_tool_class_get_name           (GwyToolClass *tool_class);
const gchar*    gwy_tool_class_get_title          (GwyToolClass *tool_class);
const gchar*    gwy_tool_class_get_icon_name      (GwyToolClass *tool_class);
const gchar*    gwy_tool_class_get_tooltip        (GwyToolClass *tool_class);
GwyToolFlags    gwy_tool_class_get_flags          (GwyToolClass *tool_class);
void            gwy_tool_switch_data              (GwyTool *tool,
                                                   GwyDataView *dataview);
GwyVectorLayer* gwy_tool_provide_layer            (GwyTool *tool,
                                                   GType layer_type);
void            gwy_tool_set_layer                (GwyTool *tool,
                                                   GwyVectorLayer *layer,
                                                   const gchar *name);
void            gwy_tool_show                     (GwyTool *tool);
void            gwy_tool_hide                     (GwyTool *tool);
gboolean        gwy_tool_is_visible               (GwyTool *tool);
gpointer        gwy_tool_get_tool_data            (GwyTool *tool);
GwyParams*      gwy_tool_get_params               (GwyTool *tool);
GtkWindow*      gwy_tool_get_window               (GwyTool *tool);
GwySelection*   gwy_tool_get_selection            (GwyTool *tool);
GwyDataView*    gwy_tool_get_data_view            (GwyTool *tool);
GwyVectorLayer* gwy_tool_get_layer                (GwyTool *tool);
GwyDataKind     gwy_tool_get_data_kind            (GwyTool *tool);
GwyFile*        gwy_tool_get_file                 (GwyTool *tool);
gint            gwy_tool_get_data_id              (GwyTool *tool);
GwyValueFormat* gwy_tool_get_format_xy            (GwyTool *tool);
GwyValueFormat* gwy_tool_get_format_z             (GwyTool *tool);
gpointer        gwy_tool_get_primary_data         (GwyTool *tool);
GwyField*       gwy_tool_get_field                (GwyTool *tool);
GwyNield*       gwy_tool_get_mask                 (GwyTool *tool);
void            gwy_tool_queue_update             (GwyTool *tool,
                                                   GwyToolChangedFlags changed);
void            gwy_tool_set_can_update           (GwyTool *tool,
                                                   gboolean can_update);
void            gwy_tool_set_can_apply            (GwyTool *tool,
                                                   gboolean can_apply);
gboolean        gwy_tool_is_switching_data        (GwyTool *tool);
void            gwy_tool_enable_deletion          (GwyTool *tool,
                                                   GtkTreeView *treeview);
const gchar*    gwy_tool_get_qualified_name       (GwyTool *tool);
GwyToolClass*   gwy_tool_class_from_name          (const gchar *name);
void            gwy_tool_produce_graph_curves     (GwyTool *tool,
                                                   GwyGraphModel *gmodel,
                                                   gint target_graph_id,
                                                   gboolean separate);

G_END_DECLS

#endif

/* vim: set cin columns=120 tw=118 et ts=4 sw=4 cino=>1s,e0,n0,f0,{0,}0,^0,\:1s,=0,g1s,h0,t0,+1s,c3,(0,u0 : */
