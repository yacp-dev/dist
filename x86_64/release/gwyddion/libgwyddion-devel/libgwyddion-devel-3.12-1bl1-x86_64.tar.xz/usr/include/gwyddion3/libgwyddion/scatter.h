#pragma once
/*
 *  $Id: scatter.h 30174 2026-07-13 19:40:56Z vojtakl4 $
 *  Copyright (C) 2011-2026 David Necas (Yeti).
 *  E-mail: yeti@gwyddion.net.
 *
 *  This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public
 *  License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any
 *  later version.
 *
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 *  details.
 *
 *  You should have received a copy of the GNU General Public License along with this program; if not, write to the
 *  Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#ifndef __GWY_SCATTER_H__
#define __GWY_SCATTER_H__

#include <libgwyddion/math.h>
#include <libgwyddion/enums.h>
#include <libgwyddion/field.h>

G_BEGIN_DECLS

#define GWY_TYPE_SCATTER            (gwy_scatter_get_type())
#define GWY_SCATTER(obj)            (G_TYPE_CHECK_INSTANCE_CAST((obj), GWY_TYPE_SCATTER, GwyScatter))
#define GWY_SCATTER_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST((klass), GWY_TYPE_SCATTER, GwyScatterClass))
#define GWY_IS_SCATTER(obj)         (G_TYPE_CHECK_INSTANCE_TYPE((obj), GWY_TYPE_SCATTER))
#define GWY_IS_SCATTER_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE((klass), GWY_TYPE_SCATTER))
#define GWY_SCATTER_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS((obj), GWY_TYPE_SCATTER, GwyScatterClass))

typedef struct _GwyScatter        GwyScatter;
typedef struct _GwyScatterClass   GwyScatterClass;
typedef struct _GwyScatterPrivate GwyScatterPrivate;

struct _GwyScatter {
    GObject parent_instance;
    GwyScatterPrivate *priv;

    /*<public>*/
    gsize n;
};

struct _GwyScatterClass {
    GObjectClass parent_class;

    void (*xy_changed)(GwyScatter *scatter);
    void (*data_changed)(GwyScatter *scatter);

    /*< private >*/
    void (*reserved1)(void);
    void (*reserved2)(void);
    void (*reserved3)(void);
};

typedef gboolean (*GwyScatterFilterFunc)(const GwyXY *xy,
                                         const gdouble *values,
                                         gpointer user_data);
typedef gint     (*GwyScatterCompareFunc)(const gdouble *xydataa,
                                          const gdouble *xydatab,
                                          gpointer user_data);

GType           gwy_scatter_get_type             (void)                      G_GNUC_CONST;
GwyScatter*     gwy_scatter_new                  (gint nvalues);
GwyScatter*     gwy_scatter_new_sized            (gint nvalues,
                                                  gsize n);
GwyScatter*     gwy_scatter_new_from_data        (const GwyXY *points,
                                                  const gdouble *data,
                                                  gint nvalues,
                                                  gsize n);
GwyScatter*     gwy_scatter_new_from_xyz         (const GwyXYZ *xyz,
                                                  gsize n);
GwyScatter*     gwy_scatter_new_alike            (GwyScatter *model);
GwyScatter*     gwy_scatter_new_part             (GwyScatter *scatter,
                                                  gdouble xfrom,
                                                  gdouble xto,
                                                  gdouble yfrom,
                                                  gdouble yto);
gint            gwy_scatter_get_n_values         (GwyScatter *scatter);
GwyXY*          gwy_scatter_get_xy               (GwyScatter *scatter);
const GwyXY*    gwy_scatter_get_xy_const         (GwyScatter *scatter);
gdouble*        gwy_scatter_get_data             (GwyScatter *scatter,
                                                  gint i);
const gdouble*  gwy_scatter_get_data_const       (GwyScatter *scatter,
                                                  gint i);
gdouble*        gwy_scatter_pack                 (GwyScatter *scatter,
                                                  gint i);
gsize           gwy_scatter_get_n_points         (GwyScatter *scatter);
void            gwy_scatter_copy_data            (GwyScatter *scatter,
                                                  GwyScatter *target);
void            gwy_scatter_invalidate           (GwyScatter *scatter);
void            gwy_scatter_xy_changed           (GwyScatter *scatter);
void            gwy_scatter_data_changed         (GwyScatter *scatter);
GwyScatter*     gwy_scatter_copy                 (GwyScatter *scatter);
void            gwy_scatter_assign               (GwyScatter *destination,
                                                  GwyScatter *source);
void            gwy_scatter_set_from_field       (GwyScatter *scatter,
                                                  GwyField *field);
void            gwy_scatter_set_from_field_area  (GwyScatter *scatter,
                                                  GwyField *field,
                                                  GwyNield *mask,
                                                  GwyMaskingType masking,
                                                  gint col,
                                                  gint row,
                                                  gint width,
                                                  gint height);
void            gwy_scatter_set_from_packed      (GwyScatter *scatter,
                                                  const gdouble *data,
                                                  gint nvalues,
                                                  gsize n);
void            gwy_scatter_set_data_label       (GwyScatter *scatter,
                                                  gint i,
                                                  const gchar *label);
const gchar*    gwy_scatter_get_data_label       (GwyScatter *scatter,
                                                  gint i);
gint            gwy_scatter_find_data_by_label   (GwyScatter *scatter,
                                                  const gchar *label);
void            gwy_scatter_clear_data_labels    (GwyScatter *scatter);
GwyUnit*        gwy_scatter_get_unit_xy          (GwyScatter *scatter);
GwyUnit*        gwy_scatter_get_unit_data        (GwyScatter *scatter,
                                                  gint i);
GwyValueFormat* gwy_scatter_get_value_format_xy  (GwyScatter *scatter,
                                                  GwyUnitFormatStyle style,
                                                  GwyValueFormat *format);
GwyValueFormat* gwy_scatter_get_value_format_data(GwyScatter *scatter,
                                                  gint i,
                                                  GwyUnitFormatStyle style,
                                                  GwyValueFormat *format);
void            gwy_scatter_copy_units           (GwyScatter *scatter,
                                                  GwyScatter *target);
void            gwy_field_copy_units_to_scatter  (GwyField *field,
                                                  GwyScatter *scatter,
                                                  gint i);
void            gwy_scatter_copy_units_to_field  (GwyScatter *scatter,
                                                  gint i,
                                                  GwyField *field);
void            gwy_scatter_xrange               (GwyScatter *scatter,
                                                  gdouble *min,
                                                  gdouble *max);
void            gwy_scatter_yrange               (GwyScatter *scatter,
                                                  gdouble *min,
                                                  gdouble *max);
void            gwy_scatter_min_max              (GwyScatter *scatter,
                                                  gint i,
                                                  gdouble *min,
                                                  gdouble *max);
void            gwy_scatter_multiply             (GwyScatter *scatter,
                                                  gint i,
                                                  gdouble value);
void            gwy_scatter_add                  (GwyScatter *scatter,
                                                  gint i,
                                                  gdouble value);
void            gwy_scatter_scale_xy             (GwyScatter *scatter,
                                                  gdouble xfactor,
                                                  gdouble yfactor,
                                                  gdouble xoffset,
                                                  gdouble yoffset);
const gdouble*  gwy_scatter_get_xy_full          (GwyScatter *scatter,
                                                  gsize *n);
const gdouble*  gwy_scatter_get_xy_pointer       (GwyScatter *scatter);
void            gwy_scatter_set_xy_full          (GwyScatter *scatter,
                                                  const gdouble *points,
                                                  gsize n);
const gdouble*  gwy_scatter_get_data_full        (GwyScatter *scatter,
                                                  gint i,
                                                  gsize *n);
void            gwy_scatter_set_data_full        (GwyScatter *scatter,
                                                  gint i,
                                                  const gdouble *data,
                                                  gsize n);
GwyScatter*     gwy_scatter_new_reduced_points   (GwyScatter *scatter,
                                                  gsize n);
void            gwy_scatter_reduce_points        (GwyScatter *scatter,
                                                  gsize n);
void            gwy_scatter_resize               (GwyScatter *scatter,
                                                  gsize n);
gsize           gwy_scatter_filter               (GwyScatter *scatter,
                                                  GwyScatterFilterFunc filter,
                                                  gpointer user_data);
GwyScatter*     gwy_scatter_new_filtered         (GwyScatter *scatter,
                                                  GwyScatterFilterFunc filter,
                                                  gpointer user_data);
gsize           gwy_scatter_reduce_to_subset     (GwyScatter *scatter,
                                                  const guint32 *keepbits);
GwyScatter*     gwy_scatter_new_subset           (GwyScatter *scatter,
                                                  const guint32 *keepbits);
void            gwy_scatter_sort                 (GwyScatter *scatter,
                                                  GwyScatterCompareFunc compare,
                                                  gpointer user_data);
void            gwy_scatter_sort_by_value        (GwyScatter *scatter,
                                                  gint i,
                                                  gboolean ascending);
void            gwy_scatter_stack                (GwyScatter *scatter,
                                                  GwyScatter **operands,
                                                  guint n);
void            gwy_scatter_insert_values        (GwyScatter *scatter,
                                                  gint i,
                                                  gint nvalues);
void            gwy_scatter_remove_values        (GwyScatter *scatter,
                                                  gint i,
                                                  gint nvalues);

G_END_DECLS

#endif

/* vim: set cin columns=120 tw=118 et ts=4 sw=4 cino=>1s,e0,n0,f0,{0,}0,^0,\:1s,=0,g1s,h0,t0,+1s,c3,(0,u0 : */
