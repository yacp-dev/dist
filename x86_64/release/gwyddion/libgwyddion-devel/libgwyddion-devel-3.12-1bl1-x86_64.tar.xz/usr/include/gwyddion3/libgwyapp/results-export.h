#pragma once
/*
 *  $Id: results-export.h 30091 2026-06-19 13:11:33Z yeti-dn $
 *  Copyright (C) 2017-2025 David Necas (Yeti).
 *  E-mail: yeti@gwyddion.net.
 *
 *  This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public
 *  License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any
 *  later version.
 *
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 *  details.
 *
 *  You should have received a copy of the GNU General Public License along with this program; if not, write to the
 *  Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#ifndef __GWYAPP_RESULTS_EXPORT_H__
#define __GWYAPP_RESULTS_EXPORT_H__

#include <gtk/gtk.h>
#include <libgwyddion/results.h>
#include <libgwyddion/lawn.h>
#include <libgwyui/graph-model.h>
#include <libgwyapp/file.h>

G_BEGIN_DECLS

typedef enum {
    GWY_RESULTS_EXPORT_PARAMETERS   = 0,
    GWY_RESULTS_EXPORT_TABULAR_DATA = 1,
    GWY_RESULTS_EXPORT_FIXED_FORMAT = 2,
} GwyResultsExportStyle;

typedef gchar* (*GwyResultsFormatFunc)(gpointer user_data);

#define GWY_TYPE_RESULTS_EXPORT            (gwy_results_export_get_type())
#define GWY_RESULTS_EXPORT(obj)            (G_TYPE_CHECK_INSTANCE_CAST((obj), GWY_TYPE_RESULTS_EXPORT, GwyResultsExport))
#define GWY_RESULTS_EXPORT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST((klass), GWY_TYPE_RESULTS_EXPORT, GwyResultsExportClass))
#define GWY_IS_RESULTS_EXPORT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE((obj), GWY_TYPE_RESULTS_EXPORT))
#define GWY_IS_RESULTS_EXPORT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE((klass), GWY_TYPE_RESULTS_EXPORT))
#define GWY_RESULTS_EXPORT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS((obj), GWY_TYPE_RESULTS_EXPORT, GwyResultsExportClass))

typedef struct _GwyResultsExport        GwyResultsExport;
typedef struct _GwyResultsExportClass   GwyResultsExportClass;
typedef struct _GwyResultsExportPrivate GwyResultsExportPrivate;

struct _GwyResultsExport {
    GtkBox hbox;
    GwyResultsExportPrivate *priv;
};

struct _GwyResultsExportClass {
    GtkBoxClass parent_class;

    /* Signals */
    void (*copy)(GwyResultsExport *results_export);
    void (*save)(GwyResultsExport *results_export);
    void (*format_changed)(GwyResultsExport *results_export);

    /*<private>*/
    void (*reserved1)(void);
    void (*reserved2)(void);
    void (*reserved3)(void);
    void (*reserved4)(void);
};

GType                 gwy_results_export_get_type             (void)                            G_GNUC_CONST;
GtkWidget*            gwy_results_export_new                  (GwyResultsReportType format);
void                  gwy_results_export_set_format           (GwyResultsExport *rexport,
                                                               GwyResultsReportType format);
GwyResultsReportType  gwy_results_export_get_format           (GwyResultsExport *rexport);
void                  gwy_results_export_set_results          (GwyResultsExport *rexport,
                                                               GwyResults *results);
GwyResults*           gwy_results_export_get_results          (GwyResultsExport *rexport);
void                  gwy_results_export_set_format_func      (GwyResultsExport *rexport,
                                                               GwyResultsFormatFunc func,
                                                               gpointer user_data);
void                  gwy_results_export_set_title            (GwyResultsExport *rexport,
                                                               const gchar *title);
void                  gwy_results_export_set_style            (GwyResultsExport *rexport,
                                                               GwyResultsExportStyle style);
GwyResultsExportStyle gwy_results_export_get_style            (GwyResultsExport *rexport);
void                  gwy_results_export_set_actions_sensitive(GwyResultsExport *rexport,
                                                               gboolean sensitive);
void                  gwy_results_fill_filename               (GwyResults *results,
                                                               const gchar *resid,
                                                               GwyFile *file);
void                  gwy_results_fill_data_name              (GwyResults *results,
                                                               const gchar *resid,
                                                               GwyFile *file,
                                                               GwyDataKind data_kind,
                                                               gint dataid);
void                  gwy_results_fill_graph_curve            (GwyResults *results,
                                                               const gchar *resid,
                                                               GwyGraphCurveModel *curvemodel);
void                  gwy_results_fill_lawn_curve             (GwyResults *results,
                                                               const gchar *resid,
                                                               GwyLawn *lawn,
                                                               gint i);

G_END_DECLS

#endif

/* vim: set cin columns=120 tw=118 et ts=4 sw=4 cino=>1s,e0,n0,f0,{0,}0,^0,\:1s,=0,g1s,h0,t0,+1s,c3,(0,u0 : */
