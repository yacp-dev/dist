#pragma once
/*
 *  $Id: utils.h 30376 2026-08-24 18:37:31Z yeti-dn $
 *  Copyright (C) 2003-2026 David Necas (Yeti), Petr Klapetek.
 *  E-mail: yeti@gwyddion.net, klapetek@gwyddion.net.
 *
 *  This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public
 *  License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any
 *  later version.
 *
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 *  details.
 *
 *  You should have received a copy of the GNU General Public License along with this program; if not, write to the
 *  Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#ifndef __GWYUI_UTILS_H__
#define __GWYUI_UTILS_H__

#include <math.h>
#include <gtk/gtk.h>
#include <libgwyddion/value-format.h>
#include <libgwyui/color-button.h>

G_BEGIN_DECLS

#define gwy_adjustment_get_int(adj) ((gint)floor(gtk_adjustment_get_value(GTK_ADJUSTMENT(adj)) + 0.5))

typedef enum {
    GWY_STOCK_NONE     = 0,
    GWY_STOCK_APPLY    = 1,
    GWY_STOCK_CANCEL   = 2,
    GWY_STOCK_CLEAR    = 3,
    GWY_STOCK_CLOSE    = 4,
    GWY_STOCK_COPY     = 5,
    GWY_STOCK_DELETE   = 6,
    GWY_STOCK_EDIT     = 7,
    GWY_STOCK_ESTIMATE = 8,
    GWY_STOCK_EXPORT   = 9,
    GWY_STOCK_FIT      = 10,
    GWY_STOCK_HELP     = 11,
    GWY_STOCK_HIDE     = 12,
    GWY_STOCK_LOAD     = 13,
    GWY_STOCK_NEW      = 14,
    GWY_STOCK_OK       = 15,
    GWY_STOCK_OPEN     = 16,
    GWY_STOCK_REFINE   = 17,
    GWY_STOCK_REMOVE   = 18,
    GWY_STOCK_RESET    = 19,
    GWY_STOCK_SAVE     = 20,
    GWY_STOCK_UPDATE   = 21,
} GwyStockItem;

/* TODO GTK3 remove the entire hscale set of functions after we use something better in Gwy3DWindow and graph curve
 * dialog. The only other user is roddeposit_synth.c which Petr has to port to ParamTable. */
typedef enum {
    GWY_HSCALE_DEFAULT          = 0,
    GWY_HSCALE_LOG              = 1,
    GWY_HSCALE_SQRT             = 2,
    GWY_HSCALE_LINEAR           = 3,
    GWY_HSCALE_NO_SCALE         = 6,
    GWY_HSCALE_WIDGET           = 7,
    GWY_HSCALE_WIDGET_NO_EXPAND = 8,
    GWY_HSCALE_CHECK            = 1024,
    GWY_HSCALE_SNAP             = 2048,
} GwyHScaleStyle;

typedef enum {
    GWY_RESPONSE_RESET       = 1,
    GWY_RESPONSE_UPDATE      = 2,
    GWY_RESPONSE_CLEAR       = 3,
    GWY_RESPONSE_COPY        = 4,
    GWY_RESPONSE_DELETE      = 5,
    GWY_RESPONSE_SAVE        = 6,
    GWY_RESPONSE_EXECUTE     = 7,
    GWY_RESPONSE_OPEN        = 8,
    GWY_RESPONSE_HELP        = 9,
    GWY_RESPONSE_NEW         = 10,
    GWY_RESPONSE_EDIT        = 11,
    GWY_RESPONSE_REFINE      = 12,
    GWY_RESPONSE_USER        = 1024,
} GwyResponseType;

GtkWidget*   gwy_gtkgrid_attach_adjbar           (GtkGrid *grid,
                                                  gint row,
                                                  const gchar *name,
                                                  const gchar *units,
                                                  GObject *pivot,
                                                  GwyHScaleStyle style);
void         gwy_gtkgrid_hscale_set_sensitive    (GObject *pivot,
                                                  gboolean sensitive);
GtkWidget*   gwy_gtkgrid_hscale_get_scale        (GObject *pivot);
GtkWidget*   gwy_gtkgrid_hscale_get_check        (GObject *pivot);
GtkWidget*   gwy_gtkgrid_hscale_get_label        (GObject *pivot);
GtkWidget*   gwy_gtkgrid_hscale_get_units        (GObject *pivot);
GtkWidget*   gwy_gtkgrid_hscale_get_middle_widget(GObject *pivot);
void         gwy_mask_color_selector_run         (const gchar *dialog_title,
                                                  GtkWindow *parent,
                                                  GwyColorButton *color_button,
                                                  GwyDict *container,
                                                  GQuark quark);
void         gwy_list_store_row_changed          (GtkListStore *store,
                                                  GtkTreeIter *iter,
                                                  GtkTreePath *path,
                                                  gint row);
GtkWidget*   gwy_label_new_header                (const gchar *text);
GtkWidget*   gwy_create_stock_like_button        (const gchar *label_text,
                                                  const gchar *icon_name);
GtkWidget*   gwy_create_image_menu_item          (const gchar *label_text,
                                                  const gchar *icon_name,
                                                  gboolean always_show);
void         gwy_set_image_menu_item_icon        (GtkMenuItem *item,
                                                  const gchar *icon_name);
void         gwy_set_image_menu_item_pixbuf      (GtkMenuItem *item,
                                                  GdkPixbuf *pixbuf);
const gchar* gwy_stock_label                     (GwyStockItem item)            G_GNUC_CONST;
const gchar* gwy_stock_icon_name                 (GwyStockItem item)            G_GNUC_CONST;
gint         gwy_stock_response                  (GwyStockItem item)            G_GNUC_CONST;
GtkWidget*   gwy_stock_add_button_to_dialog      (GtkDialog *dialog,
                                                  GwyStockItem item);
GtkWidget*   gwy_create_stock_button             (GwyStockItem item);
gboolean     gwy_widget_get_activate_on_unfocus  (GtkWidget *widget);
void         gwy_widget_set_activate_on_unfocus  (GtkWidget *widget,
                                                  gboolean activate);
void         gwy_widget_sync_sensitivity         (GtkWidget *master,
                                                  GtkWidget *slave);
gboolean     gwy_widget_is_hbox                  (GtkWidget *widget);
GtkWidget*   gwy_add_button_to_dialog            (GtkDialog *dialog,
                                                  const gchar *label_text,
                                                  const gchar *icon_name,
                                                  gint response_id);
void         gwy_set_message_label               (GtkLabel *label,
                                                  const gchar *text,
                                                  GtkMessageType type,
                                                  gboolean is_markup);
void         gwy_set_label_value_format          (GtkLabel *label,
                                                  gdouble value,
                                                  const GwyValueFormat *vf,
                                                  gboolean with_units);
void         gwy_set_label_printf                (GtkLabel *label,
                                                  gboolean use_markup,
                                                  const gchar *format,
                                                  ...);
void         gwy_set_cell_renderer_value_format  (GtkCellRenderer *renderer,
                                                  gdouble value,
                                                  const GwyValueFormat *vf,
                                                  gboolean with_units);
void         gwy_set_cell_renderer_printf        (GtkCellRenderer *renderer,
                                                  gboolean use_markup,
                                                  const gchar *format,
                                                  ...);
void         gwy_set_widget_margins              (GtkWidget *widget,
                                                  gint start,
                                                  gint end,
                                                  gint top,
                                                  gint bottom);
gboolean     gwy_get_screen_size                 (GtkWidget *widget,
                                                  gint *width,
                                                  gint *height);
gchar*       gwy_strip_menu_item_label           (gchar *label);
void         gwy_select_and_show_tree_iter       (GtkTreeView *treeview,
                                                  GtkTreeIter *iter,
                                                  gboolean use_valign,
                                                  gdouble valign);

G_END_DECLS

#endif

/* vim: set cin columns=120 tw=118 et ts=4 sw=4 cino=>1s,e0,n0,f0,{0,}0,^0,\:1s,=0,g1s,h0,t0,+1s,c3,(0,u0 : */
