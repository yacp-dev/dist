#pragma once
/*
 *  $Id: derived-units.h 30370 2026-08-24 14:25:39Z yeti-dn $
 *  Copyright (C) 2026 David Necas (Yeti).
 *  E-mail: yeti@gwyddion.net.
 *
 *  This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public
 *  License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any
 *  later version.
 *
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 *  details.
 *
 *  You should have received a copy of the GNU General Public License along with this program; if not, write to the
 *  Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#ifndef __GWY_DERIVED_UNITS_H__
#define __GWY_DERIVED_UNITS_H__

#include <glib.h>
#include <libgwyddion/unit.h>

G_BEGIN_DECLS

typedef enum {
    GWY_DERIVED_MEAN,
    GWY_DERIVED_MEDIAN,
    GWY_DERIVED_MINIMUM,
    GWY_DERIVED_MAXIMUM,
    GWY_DERIVED_RANGE,
    GWY_DERIVED_RMS,
    GWY_DERIVED_RA,
    GWY_DERIVED_SKEW,
    GWY_DERIVED_KURTOSIS,
    GWY_DERIVED_OFFSET,
    GWY_DERIVED_SLOPE,
    GWY_DERIVED_GRADIENT,
    GWY_DERIVED_RMS_SLOPE,
    GWY_DERIVED_SLOPE_ANGLE,
    GWY_DERIVED_DIRECTION,
    GWY_DERIVED_PEAK,
    GWY_DERIVED_VALLEY,
    GWY_DERIVED_COUNT,
    GWY_DERIVED_SPATIAL_DENSITY,
    GWY_DERIVED_CURVATURE_RADIUS,
    GWY_DERIVED_CURVATURE,
    GWY_DERIVED_DEVELOPED,
    GWY_DERIVED_PROJECTED,
    GWY_DERIVED_VARIATION,
    GWY_DERIVED_INTEGRAL,
    GWY_DERIVED_VOLUME,
    GWY_DERIVED_ENTROPY,
    GWY_DERIVED_VALUE_DIST_ARG,
    GWY_DERIVED_VALUE_DIST,
    GWY_DERIVED_VALUE_CDIST,
    GWY_DERIVED_SLOPE_DIST_ARG,
    GWY_DERIVED_SLOPE_DIST,
    GWY_DERIVED_SLOPE_CDIST,
    GWY_DERIVED_DISTANCE,
    GWY_DERIVED_POSITION,
    GWY_DERIVED_ACF,
    GWY_DERIVED_HHCF,
    GWY_DERIVED_IDF,
    GWY_DERIVED_ASG,
    GWY_DERIVED_PSDF_ARG,
    GWY_DERIVED_PSDF_1D,
    GWY_DERIVED_PSDF_FULLD,
    GWY_DERIVED_ANGULAR_SPECTRUM,
    GWY_DERIVED_MINKOVSKI_ARG,
    GWY_DERIVED_MINKOVSKI,
} GwyDerivedQuantity;

gboolean gwy_derive_units                  (GwyUnit *unit,
                                            GwyDerivedQuantity quantity,
                                            gint dimension,
                                            GwyUnit *spatial,
                                            GwyUnit *value);
gint     gwy_derived_quantity_spatial_power(GwyDerivedQuantity quantity,
                                            gint dimension);
gint     gwy_derived_quantity_value_power  (GwyDerivedQuantity quantity);
gint     gwy_derived_quantity_angle_power  (GwyDerivedQuantity quantity);
gboolean gwy_derived_quantity_same_units   (GwyDerivedQuantity quantity);

G_END_DECLS

#endif

/* vim: set cin columns=120 tw=118 et ts=4 sw=4 cino=>1s,e0,n0,f0,{0,}0,^0,\:1s,=0,g1s,h0,t0,+1s,c3,(0,u0 : */
