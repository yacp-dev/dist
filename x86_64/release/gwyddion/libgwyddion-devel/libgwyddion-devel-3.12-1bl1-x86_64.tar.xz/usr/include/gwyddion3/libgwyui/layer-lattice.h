#pragma once
/*
 *  $Id: layer-lattice.h 29656 2026-03-26 10:21:10Z yeti-dn $
 *  Copyright (C) 2024 David Necas (Yeti), Petr Klapetek.
 *  E-mail: yeti@gwyddion.net, klapetek@gwyddion.net.
 *
 *  This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public
 *  License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any
 *  later version.
 *
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 *  details.
 *
 *  You should have received a copy of the GNU General Public License along with this program; if not, write to the
 *  Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#ifndef __GWYUI_LAYER_LATTICE_H__
#define __GWYUI_LAYER_LATTICE_H__

#include <libgwyui/vector-layer.h>

G_BEGIN_DECLS

#define GWY_TYPE_LAYER_LATTICE            (gwy_layer_lattice_get_type())
#define GWY_LAYER_LATTICE(obj)            (G_TYPE_CHECK_INSTANCE_CAST((obj), GWY_TYPE_LAYER_LATTICE, GwyLayerLattice))
#define GWY_LAYER_LATTICE_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST((klass), GWY_TYPE_LAYER_LATTICE, GwyLayerLatticeClass))
#define GWY_IS_LAYER_LATTICE(obj)         (G_TYPE_CHECK_INSTANCE_TYPE((obj), GWY_TYPE_LAYER_LATTICE))
#define GWY_IS_LAYER_LATTICE_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE((klass), GWY_TYPE_LAYER_LATTICE))
#define GWY_LAYER_LATTICE_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS((obj), GWY_TYPE_LAYER_LATTICE, GwyLayerLatticeClass))

typedef struct _GwyLayerLattice             GwyLayerLattice;
typedef struct _GwyLayerLatticeClass        GwyLayerLatticeClass;
typedef struct _GwyLayerLatticePrivate      GwyLayerLatticePrivate;

struct _GwyLayerLattice {
    GwyVectorLayer parent_instance;
    GwyLayerLatticePrivate *priv;
};

struct _GwyLayerLatticeClass {
    GwyVectorLayerClass parent_class;
};

GType           gwy_layer_lattice_get_type   (void)                    G_GNUC_CONST;
GwyVectorLayer* gwy_layer_lattice_new        (void);
gint            gwy_layer_lattice_get_n_lines(GwyLayerLattice *layer);
void            gwy_layer_lattice_set_n_lines(GwyLayerLattice *layer,
                                              gint n_lines);

G_END_DECLS

#endif

/* vim: set cin columns=120 tw=118 et ts=4 sw=4 cino=>1s,e0,n0,f0,{0,}0,^0,\:1s,=0,g1s,h0,t0,+1s,c3,(0,u0 : */
