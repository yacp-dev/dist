#pragma once
/*
 *  $Id: extend.h 29187 2026-01-13 15:59:00Z yeti-dn $
 *  Copyright (C) 2003-2026 David Necas (Yeti), Petr Klapetek.
 *  E-mail: yeti@gwyddion.net, klapetek@gwyddion.net.
 *
 *  This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public
 *  License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any
 *  later version.
 *
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 *  details.
 *
 *  You should have received a copy of the GNU General Public License along with this program; if not, write to the
 *  Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#ifndef __GWY_EXTEND_H__
#define __GWY_EXTEND_H__

#include <libgwyddion/line.h>
#include <libgwyddion/field.h>
#include <libgwyddion/enums.h>

G_BEGIN_DECLS

GwyField* gwy_field_extend(GwyField *field,
                           guint left,
                           guint right,
                           guint up,
                           guint down,
                           GwyExteriorType exterior,
                           gdouble fill_value,
                           gboolean keep_offsets);
GwyNield* gwy_nield_extend(GwyNield *nield,
                           guint left,
                           guint right,
                           guint up,
                           guint down,
                           GwyExteriorType exterior,
                           gint fill_value);
GwyLine*  gwy_line_extend (GwyLine *line,
                           guint left,
                           guint right,
                           GwyExteriorType exterior,
                           gdouble fill_value,
                           gboolean keep_offsets);

G_END_DECLS

#endif

/* vim: set cin columns=120 tw=118 et ts=4 sw=4 cino=>1s,e0,n0,f0,{0,}0,^0,\:1s,=0,g1s,h0,t0,+1s,c3,(0,u0 : */
