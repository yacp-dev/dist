#pragma once
/*
 *  $Id: thumbnail.h 30432 2026-08-28 16:22:11Z yeti-dn $
 *  Copyright (C) 2025-2026 David Necas (Yeti)
 *  E-mail: yeti@gwyddion.net
 *
 *  This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public
 *  License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any
 *  later version.
 *
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 *  details.
 *
 *  You should have received a copy of the GNU General Public License along with this program; if not, write to the
 *  Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#ifndef __GWYAPP_THUMBNAIL_H__
#define __GWYAPP_THUMBNAIL_H__

#include <gtk/gtk.h>
#include <libgwyapp/file.h>

G_BEGIN_DECLS

/* Odd libgwyapp utility functions, i.e. not really used outside. Could even make them private. */
GdkPixbuf* gwy_render_image_thumbnail (GwyFile *file,
                                       gint id,
                                       gint max_width,
                                       gint max_height);
GdkPixbuf* gwy_render_graph_thumbnail (GwyFile *file,
                                       gint id,
                                       gint max_width,
                                       gint max_height);
GdkPixbuf* gwy_render_spectra_thumbnail(GwyFile *file,
                                       gint id,
                                       gint max_width,
                                       gint max_height);
GdkPixbuf* gwy_render_volume_thumbnail(GwyFile *file,
                                       gint id,
                                       gint max_width,
                                       gint max_height);
GdkPixbuf* gwy_render_xyz_thumbnail   (GwyFile *file,
                                       gint id,
                                       gint max_width,
                                       gint max_height);
GdkPixbuf* gwy_render_cmap_thumbnail  (GwyFile *file,
                                       gint id,
                                       gint max_width,
                                       gint max_height);

G_END_DECLS

#endif

/* vim: set cin columns=120 tw=118 et ts=4 sw=4 cino=>1s,e0,n0,f0,{0,}0,^0,\:1s,=0,g1s,h0,t0,+1s,c3,(0,u0 : */
