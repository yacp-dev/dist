#pragma once
/*
 *  $Id: layer-cross.h 29656 2026-03-26 10:21:10Z yeti-dn $
 *  Copyright (C) 2024 David Necas (Yeti), Petr Klapetek.
 *  E-mail: yeti@gwyddion.net, klapetek@gwyddion.net.
 *
 *  This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public
 *  License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any
 *  later version.
 *
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 *  details.
 *
 *  You should have received a copy of the GNU General Public License along with this program; if not, write to the
 *  Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#ifndef __GWYUI_LAYER_CROSS_H__
#define __GWYUI_LAYER_CROSS_H__

#include <libgwyddion/enums.h>
#include <libgwyui/vector-layer.h>

G_BEGIN_DECLS

#define GWY_TYPE_LAYER_CROSS            (gwy_layer_cross_get_type())
#define GWY_LAYER_CROSS(obj)            (G_TYPE_CHECK_INSTANCE_CAST((obj), GWY_TYPE_LAYER_CROSS, GwyLayerCross))
#define GWY_LAYER_CROSS_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST((klass), GWY_TYPE_LAYER_CROSS, GwyLayerCrossClass))
#define GWY_IS_LAYER_CROSS(obj)         (G_TYPE_CHECK_INSTANCE_TYPE((obj), GWY_TYPE_LAYER_CROSS))
#define GWY_IS_LAYER_CROSS_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE((klass), GWY_TYPE_LAYER_CROSS))
#define GWY_LAYER_CROSS_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS((obj), GWY_TYPE_LAYER_CROSS, GwyLayerCrossClass))

typedef struct _GwyLayerCross             GwyLayerCross;
typedef struct _GwyLayerCrossClass        GwyLayerCrossClass;
typedef struct _GwyLayerCrossPrivate      GwyLayerCrossPrivate;

struct _GwyLayerCross {
    GwyVectorLayer parent_instance;
    GwyLayerCrossPrivate *priv;
};

struct _GwyLayerCrossClass {
    GwyVectorLayerClass parent_class;
};

GType             gwy_layer_cross_get_type      (void)                          G_GNUC_CONST;
GwyVectorLayer*   gwy_layer_cross_new           (void);
GwyDirectionFlags gwy_layer_cross_get_directions(GwyLayerCross *layer);
void              gwy_layer_cross_set_directions(GwyLayerCross *layer,
                                                 GwyDirectionFlags directions);
gdouble           gwy_layer_cross_get_thickness (GwyLayerCross *layer);
void              gwy_layer_cross_set_thickness (GwyLayerCross *layer,
                                                 gdouble thickness);

G_END_DECLS

#endif

/* vim: set cin columns=120 tw=118 et ts=4 sw=4 cino=>1s,e0,n0,f0,{0,}0,^0,\:1s,=0,g1s,h0,t0,+1s,c3,(0,u0 : */
