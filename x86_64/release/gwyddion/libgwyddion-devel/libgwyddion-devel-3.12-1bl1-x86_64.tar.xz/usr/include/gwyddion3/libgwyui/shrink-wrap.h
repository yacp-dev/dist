#pragma once
/*
 *  $Id: shrink-wrap.h 30189 2026-07-17 11:47:16Z yeti-dn $
 *  Copyright (C) 2026 David Necas (Yeti).
 *  E-mail: yeti@gwyddion.net.
 *
 *  This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public
 *  License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any
 *  later version.
 *
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 *  details.
 *
 *  You should have received a copy of the GNU General Public License along with this program; if not, write to the
 *  Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#ifndef __GWYUI_SHRINK_WRAP_H__
#define __GWYUI_SHRINK_WRAP_H__

#include <gtk/gtk.h>

G_BEGIN_DECLS

#define GWY_TYPE_SHRINK_WRAP            (gwy_shrink_wrap_get_type())
#define GWY_SHRINK_WRAP(obj)            (G_TYPE_CHECK_INSTANCE_CAST((obj), GWY_TYPE_SHRINK_WRAP, GwyShrinkWrap))
#define GWY_SHRINK_WRAP_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST((klass), GWY_TYPE_SHRINK_WRAP, GwyShrinkWrapClass))
#define GWY_IS_SHRINK_WRAP(obj)         (G_TYPE_CHECK_INSTANCE_TYPE((obj), GWY_TYPE_SHRINK_WRAP))
#define GWY_IS_SHRINK_WRAP_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE((klass), GWY_TYPE_SHRINK_WRAP))
#define GWY_SHRINK_WRAP_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS((obj), GWY_TYPE_SHRINK_WRAP, GwyShrinkWrapClass))

typedef struct _GwyShrinkWrap             GwyShrinkWrap;
typedef struct _GwyShrinkWrapClass        GwyShrinkWrapClass;
typedef struct _GwyShrinkWrapPrivate      GwyShrinkWrapPrivate;

struct _GwyShrinkWrap {
    GtkBin parent_instance;
    GwyShrinkWrapPrivate *priv;
};

struct _GwyShrinkWrapClass {
    GtkBinClass parent_class;

    /*<private>*/
    void (*reserved1)(void);
    void (*reserved2)(void);
    void (*reserved3)(void);
};

GType            gwy_shrink_wrap_get_type(void)                       G_GNUC_CONST;
GtkWidget*       gwy_shrink_wrap_new     (GtkSizeGroupMode mode);
void             gwy_shrink_wrap_set_mode(GwyShrinkWrap *shrinkwrap,
                                          GtkSizeGroupMode mode);
GtkSizeGroupMode gwy_shrink_wrap_get_mode(GwyShrinkWrap *shrinkwrap);

G_END_DECLS

#endif

/* vim: set cin columns=120 tw=118 et ts=4 sw=4 cino=>1s,e0,n0,f0,{0,}0,^0,\:1s,=0,g1s,h0,t0,+1s,c3,(0,u0 : */
