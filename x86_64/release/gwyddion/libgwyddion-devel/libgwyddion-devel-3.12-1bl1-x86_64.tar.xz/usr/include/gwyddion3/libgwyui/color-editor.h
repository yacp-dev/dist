#pragma once
/*
 *  $Id: color-editor.h 30090 2026-06-18 18:22:29Z yeti-dn $
 *  Copyright (C) 2003-2024 David Necas (Yeti), Petr Klapetek.
 *  E-mail: yeti@gwyddion.net, klapetek@gwyddion.net.
 *
 *  This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public
 *  License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any
 *  later version.
 *
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 *  details.
 *
 *  You should have received a copy of the GNU General Public License along with this program; if not, write to the
 *  Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#ifndef __GWYUI_COLOR_EDITOR_H__
#define __GWYUI_COLOR_EDITOR_H__

#include <gtk/gtk.h>
#include <libgwyddion/rgba.h>

G_BEGIN_DECLS

#define GWY_TYPE_COLOR_EDITOR            (gwy_color_editor_get_type())
#define GWY_COLOR_EDITOR(obj)            (G_TYPE_CHECK_INSTANCE_CAST((obj), GWY_TYPE_COLOR_EDITOR, GwyColorEditor))
#define GWY_COLOR_EDITOR_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST((klass), GWY_TYPE_COLOR_EDITOR, GwyColorEditorClass))
#define GWY_IS_COLOR_EDITOR(obj)         (G_TYPE_CHECK_INSTANCE_TYPE((obj), GWY_TYPE_COLOR_EDITOR))
#define GWY_IS_COLOR_EDITOR_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE((klass), GWY_TYPE_COLOR_EDITOR))
#define GWY_COLOR_EDITOR_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS((obj), GWY_TYPE_COLOR_EDITOR, GwyColorEditorClass))

typedef struct _GwyColorEditor             GwyColorEditor;
typedef struct _GwyColorEditorClass        GwyColorEditorClass;
typedef struct _GwyColorEditorPrivate      GwyColorEditorPrivate;

struct _GwyColorEditor {
    GtkBox box;
    GwyColorEditorPrivate *priv;
};

struct _GwyColorEditorClass {
    GtkBoxClass parent_class;

    /* Signals */
    void (*color_changed)(GwyColorEditor *editor);

    /*<private>*/
    void (*reserved1)(void);
    void (*reserved2)(void);
    void (*reserved3)(void);
    void (*reserved4)(void);
};

GType      gwy_color_editor_get_type          (void)                    G_GNUC_CONST;
GtkWidget* gwy_color_editor_new               (void);
void       gwy_color_editor_get_color         (GwyColorEditor *editor,
                                               GwyRGBA *color);
void       gwy_color_editor_set_color         (GwyColorEditor *editor,
                                               const GwyRGBA *color);
void       gwy_color_editor_get_previous_color(GwyColorEditor *editor,
                                               GwyRGBA *color);
void       gwy_color_editor_set_previous_color(GwyColorEditor *editor,
                                               const GwyRGBA *color);
gboolean   gwy_color_editor_get_use_alpha     (GwyColorEditor *editor);
void       gwy_color_editor_set_use_alpha     (GwyColorEditor *editor,
                                               gboolean use_alpha);

G_END_DECLS

#endif

/* vim: set cin columns=120 tw=118 et ts=4 sw=4 cino=>1s,e0,n0,f0,{0,}0,^0,\:1s,=0,g1s,h0,t0,+1s,c3,(0,u0 : */
