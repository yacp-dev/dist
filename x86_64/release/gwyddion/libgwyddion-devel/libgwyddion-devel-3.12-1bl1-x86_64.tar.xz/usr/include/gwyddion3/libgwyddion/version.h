/*
 *  $Id: version.h.in 27853 2025-04-18 09:03:14Z yeti-dn $
 *  Copyright (C) 2006 David Necas (Yeti), Petr Klapetek.
 *  E-mail: yeti@gwyddion.net, klapetek@gwyddion.net.
 *
 *  This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public
 *  License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any
 *  later version.
 *
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 *  details.
 *
 *  You should have received a copy of the GNU General Public License along with this program; if not, write to the
 *  Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#ifndef __GWY_VERSION_H__
#define __GWY_VERSION_H__

#include <glib.h>

G_BEGIN_DECLS

#define GWY_VERSION_MAJOR 3
#define GWY_VERSION_MINOR 12
#define GWY_VERSION_STRING "3.12"

gint         gwy_version_major (void) G_GNUC_CONST;
gint         gwy_version_minor (void) G_GNUC_CONST;
const gchar* gwy_version_string(void) G_GNUC_CONST;

G_END_DECLS

#endif

/* vim: set cin columns=120 tw=118 et ts=4 sw=4 cino=>1s,e0,n0,f0,{0,}0,^0,\:1s,=0,g1s,h0,t0,+1s,c3,(0,u0 : */
