#pragma once
/*
 *  $Id: gwyui.h 30143 2026-06-25 12:17:11Z yeti-dn $
 *  Copyright (C) 2003-2026 David Necas (Yeti), Petr Klapetek.
 *  E-mail: yeti@gwyddion.net, klapetek@gwyddion.net.
 *
 *  This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public
 *  License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any
 *  later version.
 *
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 *  details.
 *
 *  You should have received a copy of the GNU General Public License along with this program; if not, write to the
 *  Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#ifndef __GWYUI_GWYUI_H__
#define __GWYUI_GWYUI_H__

#include <libgwyddion/gwyddion.h>

#include <libgwyui/types.h>
#include <libgwyui/adjust-bar.h>
#include <libgwyui/cairo-utils.h>
#include <libgwyui/cell-renderer-color.h>
#include <libgwyui/cell-renderer-gradient.h>
#include <libgwyui/check-boxes.h>
#include <libgwyui/color-axis.h>
#include <libgwyui/color-button.h>
#include <libgwyui/color-dialog.h>
#include <libgwyui/color-editor.h>
#include <libgwyui/color-swatch.h>
#include <libgwyui/color-wheel.h>
#include <libgwyui/combo-boxes.h>
#include <libgwyui/correl-table.h>
#include <libgwyui/data-view.h>
#include <libgwyui/data-view-layer.h>
#include <libgwyui/data-window.h>
#include <libgwyui/fit-table.h>
#include <libgwyui/gl-label.h>
#include <libgwyui/gl-setup.h>
#include <libgwyui/gradient-swatch.h>
#include <libgwyui/grain-value-tree-view.h>
#include <libgwyui/graph-area.h>
#include <libgwyui/graph-axis.h>
#include <libgwyui/graph-corner.h>
#include <libgwyui/graph-corner.h>
#include <libgwyui/graph-curve-dialog.h>
#include <libgwyui/graph-curve-model.h>
#include <libgwyui/graph-curves.h>
#include <libgwyui/graph-data.h>
#include <libgwyui/graph.h>
#include <libgwyui/graph-key.h>
#include <libgwyui/graph-model.h>
#include <libgwyui/graph-window.h>
#include <libgwyui/gwyglview.h>
#include <libgwyui/gwyglwindow.h>
#include <libgwyui/icons.h>
#include <libgwyui/inventory-store.h>
#include <libgwyui/layer-axis.h>
#include <libgwyui/layer-cross.h>
#include <libgwyui/layer-ellipse.h>
#include <libgwyui/layer-lattice.h>
#include <libgwyui/layer-line.h>
#include <libgwyui/layer-path.h>
#include <libgwyui/layer-point.h>
#include <libgwyui/layer-quad.h>
#include <libgwyui/layer-rectangle.h>
#include <libgwyui/null-store.h>
#include <libgwyui/option-menus.h>
#include <libgwyui/pixbuf-render.h>
#include <libgwyui/radio-buttons.h>
#include <libgwyui/ruler.h>
#include <libgwyui/sci-text.h>
#include <libgwyui/sensitivity-group.h>
#include <libgwyui/shader.h>
#include <libgwyui/shrink-wrap.h>
#include <libgwyui/utils.h>
#include <libgwyui/vector-layer.h>

G_BEGIN_DECLS

void gwy_ui_init(void);

G_END_DECLS

#endif

/* vim: set cin columns=120 tw=118 et ts=4 sw=4 cino=>1s,e0,n0,f0,{0,}0,^0,\:1s,=0,g1s,h0,t0,+1s,c3,(0,u0 : */
