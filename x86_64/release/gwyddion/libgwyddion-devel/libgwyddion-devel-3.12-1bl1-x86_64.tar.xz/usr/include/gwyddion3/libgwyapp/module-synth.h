#pragma once
/*
 *  $Id: module-synth.h 28779 2025-11-04 17:00:29Z yeti-dn $
 *  Copyright (C) 2025 David Necas (Yeti).
 *  E-mail: yeti@gwyddion.net.
 *
 *  This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public
 *  License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any
 *  later version.
 *
 *  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
 *  warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 *  details.
 *
 *  You should have received a copy of the GNU General Public License along with this program; if not, write to the
 *  Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#ifndef __GWYAPP_MODULE_SYNTH_H__
#define __GWYAPP_MODULE_SYNTH_H__

#include <libgwyapp/module-loader.h>
#include <libgwyapp/file.h>

G_BEGIN_DECLS

typedef void (*GwySynthFunc)(GwyFile *data, GwyRunModeFlags run);

gboolean        gwy_synth_func_register     (const gchar *name,
                                             GwySynthFunc func,
                                             const gchar *menu_path,
                                             const gchar *icon_name,
                                             GwyRunModeFlags modes,
                                             const gchar *tooltip);
void            gwy_synth_func_run          (const gchar *name,
                                             GwyFile *data,
                                             GwyRunModeFlags mode);
gboolean        gwy_synth_func_exists       (const gchar *name);
GwyRunModeFlags gwy_synth_func_get_run_modes(const gchar *name);
const gchar*    gwy_synth_func_get_menu_path(const gchar *name);
const gchar*    gwy_synth_func_get_icon_name(const gchar *name);
const gchar*    gwy_synth_func_get_tooltip  (const gchar *name);
void            gwy_synth_func_foreach      (GwyNameFunc function,
                                             gpointer user_data);
const gchar*    gwy_synth_func_current      (void);

G_END_DECLS

#endif

/* vim: set cin columns=120 tw=118 et ts=4 sw=4 cino=>1s,e0,n0,f0,{0,}0,^0,\:1s,=0,g1s,h0,t0,+1s,c3,(0,u0 : */
