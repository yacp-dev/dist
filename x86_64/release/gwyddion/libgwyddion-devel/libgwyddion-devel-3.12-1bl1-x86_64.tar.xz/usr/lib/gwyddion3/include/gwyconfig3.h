/*
 * gwyconfig3.h
 *
 * This is a generated file.  Please modify 'configure.ac'.
 *
 * It contains system-dependent information which can influence public Gwyddion headers.
 */

#ifndef __GWY_CONFIG3_H__
#define __GWY_CONFIG3_H__

#undef GWYDDION_HAS_OPENGL

#define GWY_SHARED_LIBRARY_EXTENSION "dll"


/* Define to 1 if you have the exp10() function. */
#define GWY_HAVE_EXP10 1

/* Define to 1 if you have the sincos() function. */
#define GWY_HAVE_SINCOS 1

#endif
