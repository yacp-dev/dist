#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "miniz::miniz" for configuration "RelWithDebInfo"
set_property(TARGET miniz::miniz APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(miniz::miniz PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libminiz.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygminiz-3.dll"
  )

list(APPEND _cmake_import_check_targets miniz::miniz )
list(APPEND _cmake_import_check_files_for_miniz::miniz "${_IMPORT_PREFIX}/lib/libminiz.dll.a" "${_IMPORT_PREFIX}/bin/cygminiz-3.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
