//  ************************************************************************************************
//
//  BornAgain: simulate and fit reflection and scattering
//
//! @file      ff/Make.h
//! @brief     Defines factory functions in namespace make
//!
//! @homepage  https://jugit.fz-juelich.de/mlz/libformfactor
//! @license   GNU General Public License v3 or higher (see COPYING)
//! @copyright Forschungszentrum Jülich GmbH 2022
//! @authors   Scientific Computing Group at MLZ (see CITATION, AUTHORS)
//
//  ************************************************************************************************

#ifndef FF_MAKE_H
#define FF_MAKE_H

#include "ff/Box.h"
#include "ff/Polyhedron.h"
#include "ff/Prism.h"

namespace ff::make {

ff::Box* Box(double length, double width, double height);
ff::Prism* Prism3(double base_edge, double height);
ff::Prism* Prism6(double base_edge, double height);

ff::Polyhedron* Tetrahedron(double edge);
ff::Polyhedron* Octahedron(double edge);
ff::Polyhedron* Dodecahedron(double edge);
ff::Polyhedron* Icosahedron(double edge);

//! All pyramid factories below treat terminal dimensions within 1e-14 of their
//! construction scale as zero, matching the relative short-edge resolution of
//! the face geometry. For Pyramid2, the orthogonal terminal extent is part of
//! that scale as well.
//! alpha_length and alpha_width are the dihedral angles in (0, pi) of the faces
//! tapering those dimensions; obtuse angles widen the top instead of narrowing it.
ff::Polyhedron* Pyramid2(double length, double width, double height, double alpha_length,
                         double alpha_width);
//! Pyramid3, Pyramid4, and Pyramid6 also accept dihedral taper angles in (0, pi).
ff::Polyhedron* Pyramid3(double base_edge, double height, double alpha);
ff::Polyhedron* Pyramid4(double base_edge, double height, double alpha);
ff::Polyhedron* Pyramid6(double base_edge, double height, double alpha);

//! If height_ratio*height remains positive after topology classification, the
//! lower and upper ends independently retain a terminal square or collapse to
//! an apex, covering all four combinations: square/square, apex/square,
//! square/apex, and apex/apex.
//! If the classified upper height is zero, the upper half is absent; the lower
//! half is either a capped square frustum or a capped square pyramid.
ff::Polyhedron* Bipyramid4(double length, double height, double height_ratio, double alpha);

ff::Polyhedron* CantellatedCube(double length, double removed_length);
ff::Polyhedron* TruncatedCube(double length, double removed_length);

} // namespace ff::make

#endif // FF_MAKE_H
