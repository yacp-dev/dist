#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "formfactor::formfactor" for configuration "RelWithDebInfo"
set_property(TARGET formfactor::formfactor APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(formfactor::formfactor PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libformfactor.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygformfactor-0.dll"
  )

list(APPEND _cmake_import_check_targets formfactor::formfactor )
list(APPEND _cmake_import_check_files_for_formfactor::formfactor "${_IMPORT_PREFIX}/lib/libformfactor.dll.a" "${_IMPORT_PREFIX}/bin/cygformfactor-0.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
