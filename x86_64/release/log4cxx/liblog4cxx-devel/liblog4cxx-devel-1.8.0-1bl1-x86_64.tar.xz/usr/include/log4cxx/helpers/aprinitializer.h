/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef _LOG4CXX_HELPERS_APRINITIALIZER_H
#define _LOG4CXX_HELPERS_APRINITIALIZER_H

#ifndef LOG4CXX
	#error "aprinitializer.h should only be included by log4cxx implementation"
#endif

#include <log4cxx/helpers/object.h>
#include <log4cxx/helpers/widelife.h>

extern "C" {
	struct apr_threadkey_t;
	struct apr_pool_t;
}
#include <functional>

namespace LOG4CXX_NS
{
namespace helpers
{
#if LOG4CXX_ABI_VERSION <= 15
class FileWatchdog;
#endif

class APRInitializer
{
	public:
#if LOG4CXX_ABI_VERSION <= 15
		static log4cxx_time_t initialize();
		static bool isDestructed;
#endif
		static apr_pool_t* getRootPool();
		static log4cxx_time_t getStartTime();
		static apr_threadkey_t* getTlsKey();

#if LOG4CXX_ABI_VERSION <= 15
		/**
		 *  Register a FileWatchdog for deletion prior to termination.
		 *    FileWatchdog must be
		 *    allocated on heap and not deleted elsewhere.
		 */
		static void registerCleanup(FileWatchdog* watchdog);
		static void unregisterCleanup(FileWatchdog* watchdog);
		static void unregisterAll();
#endif
		/**
		 *  Store a single instance type ObjectPtr for deletion prior to termination
		 */
		template <class T> static void setUnique(const std::shared_ptr<T>& pObject)
		{
			getInstance().addObject(typeid(T).hash_code(), pObject);
		}
		/**
		 *  Fetch or add a single instance type ObjectPtr for deletion prior to termination
		 */
		template <class T> static std::shared_ptr<T> getOrAddUnique(std::function<ObjectPtr()> creator)
		{
			return cast<T>(getInstance().findOrAddObject(typeid(T).hash_code(), creator));
		}


	private: // Constructors
		friend class helpers::WideLife<APRInitializer>;
		APRInitializer();
		APRInitializer(const APRInitializer&) = delete;
		APRInitializer& operator=(const APRInitializer&) = delete;
	private: // Modifiers
		void addObject(size_t key, const ObjectPtr& pObject);
		const ObjectPtr& findOrAddObject(size_t key, std::function<ObjectPtr()> creator);
	private: // Attributes
		LOG4CXX_DECLARE_PRIVATE_MEMBER_PTR(APRInitializerPrivate, m_priv)
	private: // Class methods
		static APRInitializer& getInstance();

	public: // Destructor
		~APRInitializer();
};
} // namespace helpers
} // namespace log4cxx

#endif //_LOG4CXX_HELPERS_APRINITIALIZER_H
