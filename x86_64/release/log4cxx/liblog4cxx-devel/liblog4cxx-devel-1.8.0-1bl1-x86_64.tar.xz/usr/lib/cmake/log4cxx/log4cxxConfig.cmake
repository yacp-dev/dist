
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was Config.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

# Use original install prefix when loaded through a "/usr move"
# cross-prefix symbolic link such as /lib -> /usr/lib.
get_filename_component(_realCurr "${CMAKE_CURRENT_LIST_DIR}" REALPATH)
get_filename_component(_realOrig "/usr/lib/cmake/log4cxx" REALPATH)
if(_realCurr STREQUAL _realOrig)
  set(PACKAGE_PREFIX_DIR "/usr")
endif()
unset(_realOrig)
unset(_realCurr)

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

include("${CMAKE_CURRENT_LIST_DIR}/${CMAKE_FIND_PACKAGE_NAME}Targets.cmake")

# The components that can specified in find_package
set(_${CMAKE_FIND_PACKAGE_NAME}_supported_components qt)

foreach(component ${${CMAKE_FIND_PACKAGE_NAME}_FIND_COMPONENTS})
  # if we couldn't find the component, set the ${CMAKE_FIND_PACKAGE_NAME} library to no
  # longer be found and notify the user about the missing component
  if (NOT ${component} IN_LIST _${CMAKE_FIND_PACKAGE_NAME}_supported_components)
    set(${CMAKE_FIND_PACKAGE_NAME}_FOUND False)
    set(${CMAKE_FIND_PACKAGE_NAME}_NOT_FOUND_MESSAGE "Unsupported component: ${component}")
  else()
    include(${CMAKE_CURRENT_LIST_DIR}/${CMAKE_FIND_PACKAGE_NAME}-${component}Targets.cmake)
    set(${CMAKE_FIND_PACKAGE_NAME}_${component}_FOUND True)
  endif()
endforeach()

check_required_components(${CMAKE_FIND_PACKAGE_NAME})
