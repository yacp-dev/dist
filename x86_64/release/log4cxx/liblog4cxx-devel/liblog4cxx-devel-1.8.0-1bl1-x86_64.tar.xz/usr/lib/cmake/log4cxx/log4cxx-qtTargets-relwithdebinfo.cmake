#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "log4cxx-qt" for configuration "RelWithDebInfo"
set_property(TARGET log4cxx-qt APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(log4cxx-qt PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/liblog4cxx-qt.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cyglog4cxx-qt-15.dll"
  )

list(APPEND _cmake_import_check_targets log4cxx-qt )
list(APPEND _cmake_import_check_files_for_log4cxx-qt "${_IMPORT_PREFIX}/lib/liblog4cxx-qt.dll.a" "${_IMPORT_PREFIX}/bin/cyglog4cxx-qt-15.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
