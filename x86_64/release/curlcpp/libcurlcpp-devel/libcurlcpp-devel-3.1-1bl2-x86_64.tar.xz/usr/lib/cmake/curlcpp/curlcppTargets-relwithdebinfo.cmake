#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "curlcpp::curlcpp" for configuration "RelWithDebInfo"
set_property(TARGET curlcpp::curlcpp APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(curlcpp::curlcpp PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libcurlcpp.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygcurlcpp-3.dll"
  )

list(APPEND _cmake_import_check_targets curlcpp::curlcpp )
list(APPEND _cmake_import_check_files_for_curlcpp::curlcpp "${_IMPORT_PREFIX}/lib/libcurlcpp.dll.a" "${_IMPORT_PREFIX}/bin/cygcurlcpp-3.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
