#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "PhysFS::PhysFS" for configuration "RelWithDebInfo"
set_property(TARGET PhysFS::PhysFS APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(PhysFS::PhysFS PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libphysfs.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygphysfs-1.dll"
  )

list(APPEND _cmake_import_check_targets PhysFS::PhysFS )
list(APPEND _cmake_import_check_files_for_PhysFS::PhysFS "${_IMPORT_PREFIX}/lib/libphysfs.dll.a" "${_IMPORT_PREFIX}/bin/cygphysfs-1.dll" )

# Import target "PhysFS::test_physfs" for configuration "RelWithDebInfo"
set_property(TARGET PhysFS::test_physfs APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(PhysFS::test_physfs PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/test_physfs.exe"
  )

list(APPEND _cmake_import_check_targets PhysFS::test_physfs )
list(APPEND _cmake_import_check_files_for_PhysFS::test_physfs "${_IMPORT_PREFIX}/bin/test_physfs.exe" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
