/*
 * Library to support the Object Linking and Embedding (OLE) data types
 *
 * Copyright (C) 2008-2026, Joachim Metz <joachim.metz@gmail.com>
 *
 * Refer to AUTHORS for acknowledgements.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#if !defined( _LIBFOLE_H )
#define _LIBFOLE_H

#include <libfole/definitions.h>
#include <libfole/error.h>
#include <libfole/extern.h>
#include <libfole/features.h>
#include <libfole/types.h>

#include <stdio.h>

#if defined( __cplusplus )
extern "C" {
#endif

/* -------------------------------------------------------------------------
 * Support functions
 * ------------------------------------------------------------------------- */

/* Returns the library version
 */
LIBFOLE_EXTERN \
const char *libfole_get_version(
             void );

/* -------------------------------------------------------------------------
 * Error functions
 * ------------------------------------------------------------------------- */

/* Frees an error
 */
LIBFOLE_EXTERN \
void libfole_error_free(
      libfole_error_t **error );

/* Prints a descriptive string of the error to the stream
 * Returns the amount of printed characters if successful or -1 on error
 */
LIBFOLE_EXTERN \
int libfole_error_fprint(
     libfole_error_t *error,
     FILE *stream );

/* Prints a descriptive string of the error to the string
 * The end-of-string character is not included in the return value
 * Returns the amount of printed characters if successful or -1 on error
 */
LIBFOLE_EXTERN \
int libfole_error_sprint(
     libfole_error_t *error,
     char *string,
     size_t size );

/* Prints a backtrace of the error to the stream
 * Returns the amount of printed characters if successful or -1 on error
 */
LIBFOLE_EXTERN \
int libfole_error_backtrace_fprint(
     libfole_error_t *error,
     FILE *stream );

/* Prints a backtrace of the error to the string
 * The end-of-string character is not included in the return value
 * Returns the amount of printed characters if successful or -1 on error
 */
LIBFOLE_EXTERN \
int libfole_error_backtrace_sprint(
     libfole_error_t *error,
     char *string,
     size_t size );

/* -------------------------------------------------------------------------
 * Value type functions
 * ------------------------------------------------------------------------- */

/* Retrieves a string containing the value type identifier
 */
LIBFOLE_EXTERN \
const char *libfole_value_type_get_identifier(
             uint32_t value_type );

/* Retrieves a string containing the value type description
 */
LIBFOLE_EXTERN \
const char *libfole_value_type_get_description(
             uint32_t value_type );

#if defined( __cplusplus )
}
#endif

#endif /* !defined( _LIBFOLE_H ) */

