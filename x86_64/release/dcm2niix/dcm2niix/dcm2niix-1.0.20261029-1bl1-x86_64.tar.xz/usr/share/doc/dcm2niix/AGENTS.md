## Prime Directive

dcm2niix handles real scanner DICOMs, including malformed/vendor-specific data. Assume quirks are load-bearing. Make surgical changes only. Do not refactor, simplify, reorder, or remove adjacent logic unless you understand the real dataset it protects. Correctness means handling scanner output, not just the DICOM standard. When unsure, leave it.

## Reference Docs

Domain hazards live in on-demand docs — read the relevant one before changing that area. Each is the authoritative gotcha list for its domain; keep new gotchas there, not here.

- `docs/ARCHITECTURE.md` — module boundaries, save-chain ownership, source-list fanout. Read before broad module/save-chain changes.
- `docs/BUILD.md` — CMake, CI, Docker, PyPI, test runners, formatting. Read before changing any of those.
- `docs/PARSER_GOTCHAS.md` — DICOM tag descent, transfer syntax, encapsulation, slice geometry, vendor-private parsing.
- `docs/BIDS_REPROIN.md` — BIDS sidecars, physio output, classification, `BidsGuess`, `-f %h/%H`, `reproin.cpp`, `tools/reproinx.py`.
- `docs/MRS.md` — MR Spectroscopy, NIfTI-MRS ecode 44, `tools/mrs_post.py`.
- `docs/siemens.md` — reference table for `setBidsSiemens()` BIDS-guess cascade + the `MRWeightingGuess()` T1/PD/T2/FLAIR heuristic.

## Build / Test / Lint

- Full CMake: `mkdir build && cd build && cmake -DZLIB_IMPLEMENTATION=Cloudflare -DUSE_JPEGLS=ON -DUSE_OPENJPEG=ON .. && make` -> `build/bin/dcm2niix`.
- Deployment build standard for repo-controlled channels: `-DZLIB_IMPLEMENTATION=zlib-ng -DUSE_JPEGLS=ON -DUSE_OPENJPEG=GitHub`; zlib-ng `2.3.3` and OpenJPEG `2.5.3` are static pinned source builds; use `GitHub`, not `ON`, for OpenJPEG.
- Makefile: `cd console && make`; targets include `debug`, `sanitize`, `jp2`, `turbo`, `wasm`.
- CMake options: `-DZLIB_IMPLEMENTATION=Miniz|System|Cloudflare|zlib-ng|Custom`, `-DUSE_OPENJPEG=OFF|GitHub|System`, `-DUSE_JPEGLS=ON|OFF`, `-DUSE_TURBOJPEG=ON|OFF`, `-DUSE_ZSTD=ON|OFF`, `-DBATCH_VERSION=ON`.
- In-tree regression:
  ```bash
  git submodule update --init
  export PATH="$PWD/build/bin:$PATH"
  for d in dcm_qa dcm_qa_nih dcm_qa_uih; do (cd "$d" && ./batch.sh) || { echo "FAIL: $d"; exit 1; }; done
  ```
- Release validation uses sibling `dcm_validate`; edge cases, validation data, and regression tests belong there rather than in this root project. Pre-push minimum is `dcm_qa` plus `git ls-files | xargs codespell`.
- CMRR physio + `CMRRMeasurementUUID` regression in sibling `dcm_qa_physio`: `./batch.sh`.
- MRS regression in sibling `dcm_qa_mrs`: `python3 batch.py --corpus={local,spec2nii,both}`, `python3 compare_spec2nii.py --corpus={local,spec2nii,both}`; `$SPEC2NII_DATA` must point at spec2nii test data.
- reproinx self-check: `python3 tools/test_reproinx_sbref.py`.
- Sibling `dcm_validate` scripts: `python3 test_jpeg_header_mismatch.py <dcm2niix>` (JPEG-LS/J2K build, pydicom >= 3), `python3 test_ge_missing_images.py <dcm2niix>`.
- Browser package `js/` (`@niivue/dcm2niix`): build with `pixi run wasm` (pinned emcc); `npm run build` recompiles WASM via `prebuild`, so run it only inside `pixi shell` (Homebrew emcc is the wrong version). Test: `cd js && npm test` (needs submodules and `npx playwright install chromium`) and `npm run test:consumer` (Vite app from the packed tarball). Release: `pixi run pack-npm` (build, both tests, `npm pack`), then `npm publish <tgz> --tag rc|latest` by hand. WASM magnifies per-file parser cost; see `docs/BUILD.md`.
- Format C/C++ when needed: `clang-format -i -style="{BasedOnStyle: LLVM, IndentWidth: 4, IndentCaseLabels: false, TabWidth: 4, UseTab: Always, ColumnLimit: 0}" *.cpp *.h`.
- C/C++ indentation may be inconsistent; contributors need not match local style by hand because periodic clang-format normalizes it.
- Markdown convention: no hard-wrapping.
- `temp/` is PHI scratch; clean it after cycles that write there.

## Architecture Map

- All core C/C++ source is in `console/`; data flow is `main_console.cpp` -> `nii_dicom_batch.cpp` -> `nii_dicom.cpp` -> `nii_dicom_batch.cpp` -> `nifti1_io_core.cpp`.
- `nii_dicom.cpp` parses DICOM and vendor tags into `TDICOMdata`; most scanner gotchas live here.
- `nii_dicom_batch.cpp` groups series, assembles volumes, writes NIfTI/BIDS, physio, reproin, and MRS paths; treat it as load-bearing.
- `nifti1_io_core.cpp` writes NIfTI/JSON/reorientation; `nii_foreign.cpp` handles PAR/REC; `nii_ortho.cpp` handles orientation/crop/resample.
- `dicom_fragments.{h,cpp}` is the multi-fragment single-frame encapsulation helper for issue #1017.
- `cmrr_uuid.h` is a header-only helper parsing the CMRR measurement UUID (Phoenix `sWipMemBlock.tFree` or physio payload header) for the `CMRRMeasurementUUID` sidecar key, and redacting it from `WipMemBlock` under `-ba y`.
- Adding a `.cpp` requires updating all source-list surfaces: `console/CMakeLists.txt` (3 blocks), `console/makefile`, `console/windows.bat`, `console/notarize.sh`, `COMPILE.md`.

## Project Conventions

- `TDICOMdata` is passed by value through the save chain; growing it by about 4 KB can crash macOS stacks. New per-file payloads use lazy heap pointers plus idempotent `free_TDICOMdata_*` helpers at every `free(dcmList)` site.
- `deID_CS` is owned only by the `dcmList[]` entry from `readDICOMx`; shallow retained copies must set `.deID_CS = NULL; .deID_CS_n = 0`; direct `readDICOM()` callers must free it.
- Inline `TDICOMdata` additions must be tiny; `slabOrient[7] + slabOrientCount` (+32 B) is the accepted scale, not a precedent for arrays.
- Stack budget: macOS (`AppleClang` gate), WASM (`STACK_SIZE=16MB`) set 16 MB explicitly and Windows (all compilers, issue 1040) reserves 32 MB; only Linux/BSD run on the 8 MB default, and there linker flags are ignored so users need `setrlimit`. Keep all three gates.
- Never declare a `struct TDTI4D` local: `sizeof(TDTI4D)` is 8.36 MB where `kMaxSlice2D` is 98303 and 5.57 MB on Linux (65535); every per-volume field adds `kMaxDTI4D` bytes per byte of element, so prefer one `unsigned char` code over several bool arrays (issue 1038 `dixonType`). The MRS/MRSI sidecar pass takes it from the heap in `mrsSaveBIDS` (malloc, `initTDTI4D`, `nii_SaveBIDSX`, free, skipping the sidecar if allocation fails); as locals, the ones in `saveDcm2NiiMRS` inlined into `saveDcm2Nii` under clang, charging *every* conversion, and all three stacked to about 25 MB for MRSI under MSVC. The deepest chain (`nii_loadDir` -> `nii_loadDirCore` -> `saveDcm2Nii` -> `saveDcm2NiiCore` -> `nii_SaveBIDSX`) is now about 265 KB with clang 14 on x86-64; the floor for any DICOM is the `readDICOMx` frame (1.05 MB on Linux, 1.58 MB elsewhere) and `nii_readParRec` still has a `TDTI4D`-sized frame, so the raised-stack gates stay. A `static` helper inlines into `saveDcm2NiiCore` and is likewise charged to every conversion, so heap a large buffer there (a `kDICOMStrExtraLarge` 64 KB `wipMemBlock` is the trap) rather than declaring an array. Verify with `clang++ -O3 -fstack-usage -c console/nii_dicom_batch.cpp`.
- The `readKey*` family scans from `keyPos` (the `memmem` hit) but takes `remLength` for the whole buffer, so every loop must bound on `remLength - (keyPos - buffer)`; using `remLength` directly runs off the end of the CSA allocation. `readKeyStr` hardcodes a `kDICOMStrLarge` write bound regardless of the caller's array, and `siemensCsaAscii` fills `wipMemBlock` with a `kDICOMStrExtraLarge` bound, so destinations must be sized to the bound, not to the expected value. Indexed Phoenix keys (`alTI`, `alTE`, `alFree`/`adFree`, free-diffusion `asDiffDirVector[k].dSag/dCor/dTra`) go through `readKeyArray` (one pass over prefix hits); a per-index `memmem` loop rescans the whole ASCII protocol per absent index and was ~55% of XA conversion time.
- `json_Str` escapes into a heap buffer sized `2 * strlen + 1`; every input byte can expand to two. Do not put that buffer back on the stack, `sWipMemBlock.tFree` reaches 64 KB.
- `-ba` levels are not interchangeable: `-ba y` strips dates, patient PII *and* `SeriesInstanceUID`/`StudyInstanceUID` as persistent source links; `-ba o` strips PII only and deliberately keeps those UIDs. Gate a new source-linking key on `isAnonymizeBIDS` alone unless there is a reason to be stricter. For CMRR sequences the same measurement UUID leads `WipMemBlock`, so key-level suppression alone does not remove the value: `-ba y` also redacts it there, while `-ba o` and `-ba n` emit `WipMemBlock` verbatim. `-ba y` deliberately keeps `ImageComments` (sidecar and NIfTI `aux_file`): `-ba y` is the default and downstream tools read it (e.g. OpenRecon filter notes); dropping it was tried and reverted.
- Output writers must fail closed: check short writes/close/compressor status, remove partial files, and never emit sidecars next to missing/truncated images.
- Rename mode (`-r y`) shares that contract: `copyFile` treats an unreadable source or a failed write/close as fatal and aborts with `kEXIT_RENAME_ERROR`, never counting the file as renamed. An existing target is byte-compared: identical inputs are skipped and summarized in one line, distinct inputs collide and return `kEXIT_SOME_OK_SOME_BAD`. Both were fail-open regressions this cycle; do not relax them.
- Decoders size output from the codestream; check it against the header before callers copy header-sized slices (see `docs/PARSER_GOTCHAS.md`).
- `writeNiiGz`/`writeMghGz` return status and never free caller-owned buffers; `writeMghGz` must `Z_FINISH` on the footer, not the image.
- `initTDTI4D()` is required for fresh sidecar-only/MRS locals, but must NOT be called in `saveDcm2NiiCore` where enhanced/PAR per-frame data is already live.
- `-n -2` (`kSeriesListJSON`) writes `<outdir>/dcm2niix_series.json` (read by the JS `listSeries`) and converts nothing (no pixel decode); fields follow the sidecar `-ba` contract; `CRC` is the exact value the `-n` filter compares (`seriesSelectValue`; matches the `-n -1` text below 10 echoes/segments). It must have no side effects: never call `nii_createFilename` there. The physio and MRS writers run before the main `-n` filter, so each applies `isSeriesSelected` itself and writes nothing for any negative `-n` (so the `-n -1` text omits them; `-n -2` lists them). The `-n -1` text report does call `nii_createFilename` for the planned name; there `isListOnly` (`numSeries < 0`, not rename mode, which ignores `-n`) suppresses every file-system effect (`-w 1` delete, `-w 0` skip, `%h`/`%H` folders and boilerplate, `-f a/b` folders).

## Git

- `master` is stable releases only; PRs target `development`.
