#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "OpenCoarrays::opencoarrays_mod" for configuration "RelWithDebInfo"
set_property(TARGET OpenCoarrays::opencoarrays_mod APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(OpenCoarrays::opencoarrays_mod PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libopencoarrays_mod.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygopencoarrays_mod-2.dll"
  )

list(APPEND _cmake_import_check_targets OpenCoarrays::opencoarrays_mod )
list(APPEND _cmake_import_check_files_for_OpenCoarrays::opencoarrays_mod "${_IMPORT_PREFIX}/lib/libopencoarrays_mod.dll.a" "${_IMPORT_PREFIX}/bin/cygopencoarrays_mod-2.dll" )

# Import target "OpenCoarrays::caf_mpi" for configuration "RelWithDebInfo"
set_property(TARGET OpenCoarrays::caf_mpi APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(OpenCoarrays::caf_mpi PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libcaf_mpi.dll.a"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/cygcaf_mpi-3.dll"
  )

list(APPEND _cmake_import_check_targets OpenCoarrays::caf_mpi )
list(APPEND _cmake_import_check_files_for_OpenCoarrays::caf_mpi "${_IMPORT_PREFIX}/lib/libcaf_mpi.dll.a" "${_IMPORT_PREFIX}/bin/cygcaf_mpi-3.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
