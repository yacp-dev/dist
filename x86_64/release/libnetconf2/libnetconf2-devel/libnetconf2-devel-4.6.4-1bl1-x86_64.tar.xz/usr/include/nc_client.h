/**
 * @file nc_client.h
 * @author Radek Krejci <rkrejci@cesnet.cz>
 * @author Michal Vasko
 * @brief libnetconf2 main public header for NETCONF clients.
 *
 * @copyright
 * Copyright (c) 2015 - 2025 CESNET, z.s.p.o.
 *
 * This source code is licensed under BSD 3-Clause License (the "License").
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://opensource.org/licenses/BSD-3-Clause
 */

#ifndef NC_CLIENT_H_
#define NC_CLIENT_H_

#ifdef __cplusplus
extern "C" {
#endif

#ifndef NC_ENABLED_SSH_TLS
#define NC_ENABLED_SSH_TLS
#endif

#include <libnetconf2/netconf.h>
#include <libnetconf2/log.h>
#include <libnetconf2/messages_client.h>
#include <libnetconf2/session_client.h>
#include <libnetconf2/session_client_ch.h>
#include <libnetconf2/proxy_unix.h>

#ifdef __cplusplus
}
#endif

#endif /* NC_CLIENT_H_ */
