/*
 * Copyright (c) 2014, Julien Bernard
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
#ifndef ES_SUPPORT_H
#define ES_SUPPORT_H

/*
 * If set, the library was compiled by a non-C++11 compiler. It means that
 * some functions may not be available in the library and that the other
 * functions may be implemented with old style constructs instead of more
 * optimized constructs.
 */
#define COMPILER_IS_NOT_CXX11_READY


// Detect whether the compiler supports C++11 virtual override specifiers.
#if (defined(__GNUC__) && (__GNUC__ == 4) && ((__GNUC_MINOR__ < 7) || !defined(__GXX_EXPERIMENTAL_CXX0X__)))
  /// GCC 4.7 and following have "override" and "final" support when called with -std=c++0x (or -std=c++11 starting with GCC 4.7)
  /// GCC 4.6 and below does not know the "override" specifier, so we define it as nothing
  #define override  // nothing
#endif

#endif // ES_SUPPORT_H
